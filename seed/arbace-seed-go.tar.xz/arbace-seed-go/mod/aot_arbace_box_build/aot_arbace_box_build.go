//line aot_arbace_box_build.ae:1
package aot_arbace_box_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New() *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_Init(); t := &A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_5; tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_303)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_304)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_305)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp17 != nil { panic(tmp17) }; return tmp3 }
//line :4:1
func A_arbace_box_build_eval598000008_fn__598000009_A_New() *A_arbace_box_build_eval598000008_fn__598000009_A { A_arbace_box_build_eval598000008_fn__598000009_A_Init(); t := &A_arbace_box_build_eval598000008_fn__598000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }







































func A_arbace_box_build_fail_A_New() *A_arbace_box_build_fail_A { A_arbace_box_build_fail_A_Init(); t := &A_arbace_box_build_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_build_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_build_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_13; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(msg__0, tmp4.Invoke_O_O_O__O(data__1, tmp6, tmp7.Ref()))))) }


func A_arbace_box_build_sha256_hex_A_New() *A_arbace_box_build_sha256_hex_A { A_arbace_box_build_sha256_hex_A_Init(); t := &A_arbace_box_build_sha256_hex_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_340).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_598000013__4 any; var tmp1 *lang.Var;


	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; seq_598000013__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__2); var chunk_598000014__5 any; var count_598000015__6 int64 = 0; var i_598000016__7 int64 = 0; L1:
//line :47:1
	for {


		if lang.Numbers_Lt_J_J__Z(i_598000016__7, count_598000015__6) { var b__8 any = lang.Indexed_Cast(chunk_598000014__5).Nth_I__O(lang.RT_IntCast_J__I(i_598000016__7)); var x__9 int64 = lang.Numbers_And_O_J__J(b__8, 255)

			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__9, 4)), lang.RT_IntCast_J__I(16)))
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__9, 15)), lang.RT_IntCast_J__I(16)))
//line :50:1
			seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = seq_598000013__4, chunk_598000014__5, count_598000015__6, lang.Numbers_Unchecked_inc_J__J(i_598000016__7); continue L1 } else { var temp__1927000414__auto____8 any; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_15; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq_598000013__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_598000013__9 any = temp__1927000414__auto____8; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq_598000013__9)) { var c__1927000678__auto____10 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_17; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq_598000013__9); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_19; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_598000013__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var b__10 any; var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_18; b__10 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_598000013__9); var x__11 int64 = lang.Numbers_And_O_J__J(b__10, 255)

				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__11, 4)), lang.RT_IntCast_J__I(16)))
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__11, 15)), lang.RT_IntCast_J__I(16)))
//line :50:1
				var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_20; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_598000013__9), nil, 0, 0; continue L1 } } }
//line :47:1
		break L1 }; var tmp8 /*line :54:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_14; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(sb__3) }




func A_arbace_box_build_source_tree_A_New() *A_arbace_box_build_source_tree_A { A_arbace_box_build_source_tree_A_Init(); t := &A_arbace_box_build_source_tree_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Ctor() {}
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Invoke_O_O__O(self, d__0 any) any { var fs__2 any = jrt.NN(jrt.File_Cast(d__0)).ListFiles__File1().Ref(); var headers__3 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_A_New(); var tmp2 *jrt.Class;




	A_arbace_box_build_source_tree_headers__598000018_A_Init(); tmp2 = A_arbace_box_build_source_tree_headers__598000018_A_fn_class; headers__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 /*line :73:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 any; var iter__1927001039__auto____4 any; var tmp10 any = A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(headers__3); var tmp11 *jrt.Class;

	A_arbace_box_build_source_tree_iter__598000030__598000034_A_Init(); tmp11 = A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__2); return /*line :73:1*/ tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, tmp9)) }
//line :64:1
func A_arbace_box_build_source_tree_headers__598000018_A_New() *A_arbace_box_build_source_tree_headers__598000018_A { A_arbace_box_build_source_tree_headers__598000018_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Invoke_O_O__O(self, s__1 any) any { var m__2 any; var tmp1 *lang.Var;
												A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(self); var tmp7 *jrt.Class;
												A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_Init(); tmp7 = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(jrt.NN(jrt.File_Cast(s__1)).ListFiles__File1().Ref()); m__2 = /*line :65:1*/tmp2.Invoke_O_O__O(tmp4, tmp5); var tmp8 /*line :72:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(m__2)) { var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_22; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(m__2) } else { return nil } }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(p0 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Invoke_O_O__O(self, s__598000020__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(self, t.F_headers, s__598000020__1); var tmp2 *jrt.Class; A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_Init(); tmp2 = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ctor_O_O_O(c__iter__598000019, c__headers, c__s__598000020 any) { t.F_iter__598000019 = c__iter__598000019; t.F_headers = c__headers; t.F_s__598000020 = c__s__598000020 }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Invoke_O__O(self any) any { { var s__598000020__1 any; var t_ any = t.F_s__598000020; t.F_s__598000020 = nil; s__598000020__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000020__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000020__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000020__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000020__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000022__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000022__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(t.F_headers, b__598000022__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_Init(); tmp6 = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000022__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000020__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000022__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000020__3); var e__5 any
																	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4); if jrt.A2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; var tmp17 *lang.Keyword; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_26; e__5 = lang.Tuple_Create_O_O__IPersistentVector(tmp17.Ref(), h__6) } else { e__5 = nil } } else { var tmp18 *lang.Var; A_arbace_box_build_A_Init(); tmp18 = A_arbace_box_build_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_345)) {

		var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_25; e__5 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref()) } else {
//line :67:1
			e__5 = nil } }
//line :66:1
	if jrt.A2g_Truth(e__5) { var tmp20 *lang.Var; A_arbace_box_build_A_Init(); tmp20 = A_arbace_box_build_A_const_29; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_31; return tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__598000020__3))) } else { var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_31; s__598000020__1 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__598000020__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ctor_O_O_I_O(c__headers, c__b__598000022 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000022 = c__b__598000022; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Invoke_O__O(self any) any { { var i__598000021__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000021__1)); var e__3 any
																		if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2); if jrt.A2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; var tmp2 *lang.Keyword; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_26; e__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2.Ref(), h__4) } else { e__3 = nil } } else { var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_345)) {

		var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_25; e__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()) } else {
//line :67:1
			e__3 = nil } }
//line :66:1
	if jrt.A2g_Truth(e__3) { var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_27; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = t.F_b__598000022; tmp6.Invoke_O_O__O(tmp7, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3)); i__598000021__1 = lang.Numbers_Unchecked_inc_J__J(i__598000021__1); continue L1 } else { i__598000021__1 = lang.Numbers_Unchecked_inc_J__J(i__598000021__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(p0 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { A_arbace_box_build_source_tree_iter__598000030__598000034_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Invoke_O_O__O(self, s__598000031__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(t.F_headers, self, s__598000031__1); var tmp2 *jrt.Class; A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_Init(); tmp2 = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ctor_O_O_O(c__headers, c__iter__598000030, c__s__598000031 any) { t.F_headers = c__headers; t.F_iter__598000030 = c__iter__598000030; t.F_s__598000031 = c__s__598000031 }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Invoke_O__O(self any) any { { var s__598000031__1 any; var t_ any = t.F_s__598000031; t.F_s__598000031 = nil; s__598000031__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000031__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000031__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000031__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000031__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000033__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000033__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(t.F_headers, b__598000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_Init(); tmp6 = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000033__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000031__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000033__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000031__3); var e__5 any
														if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4)
															if jrt.A2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; var tmp17 *lang.Keyword; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_26; e__5 = lang.Tuple_Create_O_O__IPersistentVector(tmp17.Ref(), h__6) } else { e__5 = nil } } else {
																var tmp18 *lang.Var; A_arbace_box_build_A_Init(); tmp18 = A_arbace_box_build_A_const_25; e__5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref()) }
//line :75:1
	if jrt.A2g_Truth(e__5) { var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_29; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp23 *lang.Var; A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_31; return tmp20.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__598000031__3))) } else { var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_31; s__598000031__1 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__598000031__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ctor_O_O_I_O(c__headers, c__b__598000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000033 = c__b__598000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Invoke_O__O(self any) any { { var i__598000032__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000032__1)); var e__3 any
																if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2)
																	if jrt.A2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; var tmp2 *lang.Keyword; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_26; e__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2.Ref(), h__4) } else { e__3 = nil } } else {
																		var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_25; e__3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()) }
//line :75:1
	if jrt.A2g_Truth(e__3) { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_27; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_b__598000033; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3)); i__598000032__1 = lang.Numbers_Unchecked_inc_J__J(i__598000032__1); continue L1 } else { i__598000032__1 = lang.Numbers_Unchecked_inc_J__J(i__598000032__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_box_build_import_plan_A_New() *A_arbace_box_build_import_plan_A { A_arbace_box_build_import_plan_A_Init(); t := &A_arbace_box_build_import_plan_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O_O__O(self, plan__0, goroot__1 any) any { var p__3 any; var tmp1 *lang.Var;




	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(plan__0)) { p__3 = plan__0 } else { var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_39; p__3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(plan__0)) }; var dirs__4 any; var tmp5 /*line :82:1*/*lang.Var;





	A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_34; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; dirs__4 = tmp6.Invoke_O__O(tmp7.Ref()); var src__5 any; var tmp8 any = /*line :82:1*/A_arbace_box_build_import_plan_src__598000042_A_New_O(dirs__4); var tmp9 *jrt.Class;






	A_arbace_box_build_import_plan_src__598000042_A_Init(); tmp9 = A_arbace_box_build_import_plan_src__598000042_A_fn_class; src__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var p__6 any; var tmp10 /*line :82:1*/*lang.Var;









	A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_37; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_12; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_44; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_45; var tmp17 any = tmp13.Invoke_O_O_O__O(p__3, tmp15, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_313), jrt.RefArrayOf(jrt.Object_class, goroot__1, nil)).Ref())); var tmp18 *lang.Keyword; A_arbace_box_build_A_Init(); tmp18 = A_arbace_box_build_A_const_40; var tmp19 any = tmp18.Ref(); var tmp20 any = A_arbace_box_build_import_plan_fn__598000044_A_New_O(src__5); var tmp21 *jrt.Class; A_arbace_box_build_import_plan_fn__598000044_A_Init(); tmp21 = A_arbace_box_build_import_plan_fn__598000044_A_fn_class; p__6 = tmp11.Invoke_O_O_O__O(tmp17, tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)); var tmp22 /*line :93:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_38; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_46; return tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(p__6)) }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O__O(self, plan__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_47; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(plan__0, Lit_314)
}


func A_arbace_box_build_import_plan_src__598000042_A_New_O(p0 any) *A_arbace_box_build_import_plan_src__598000042_A { A_arbace_box_build_import_plan_src__598000042_A_Init(); t := &A_arbace_box_build_import_plan_src__598000042_A{}; t.Ctor_O(p0); return t }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Invoke_O_O__O(self, dir__1 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_7; or__1927000174__auto____2 = lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_dirs)).Invoke_O__O(dir__1); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var h__3 any; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_35; h__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(dir__1))); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_36; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_dirs; var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_12; tmp4.Invoke_O_O_O_O__O(tmp5, jrt.NN(tmp6).GetRawRoot__O(), dir__1, h__3); return h__3 } }


func A_arbace_box_build_import_plan_fn__598000044_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_A { A_arbace_box_build_import_plan_fn__598000044_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Invoke_O_O__O(self, ps__1 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_41; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(t.F_src); var tmp4 *jrt.Class; A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_Init(); tmp4 = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ps__1) }
//line :92:1
func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Invoke_O_O__O(self, p1__598000041_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_42; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_43; var tmp6 any = tmp5.Ref(); var tmp7 lang.IFn = lang.IFn_Cast(t.F_src); var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_26; var tmp9 any = tmp4.Invoke_O_O_O__O(p1__598000041_SHARP___1, tmp6, tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(p1__598000041_SHARP___1))); var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_26; return tmp2.Invoke_O_O__O(tmp9, tmp10.Ref()) }







func A_arbace_box_build_log_A_New() *A_arbace_box_build_log_A { A_arbace_box_build_log_A_Init(); t := &A_arbace_box_build_log_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_box_build_log_A) Ctor() {}
//line :100:1
func (t *A_arbace_box_build_log_A) DoInvoke_O_O__O(self, xs__0 any) any {
	var tmp1 *lang.Keyword; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_48; var tmp2 lang.IFn = Up_Keyword_IFn(tmp1); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_49; var tmp4 any = jrt.NN(tmp3).Get__O(); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_50; var tmp6 lang.IFn = lang.IFn_Cast(tmp2.Invoke_O_O__O(tmp4, jrt.NN(tmp5).GetRawRoot__O())); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_51; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_14; return tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(jrt.NN(tmp9).GetRawRoot__O(), xs__0))
}
func A_arbace_box_build_cache_ref_A_New() *A_arbace_box_build_cache_ref_A { A_arbace_box_build_cache_ref_A_Init(); t := &A_arbace_box_build_cache_ref_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Ctor() {}
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Invoke_O_O__O(self, req__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_276, nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_52; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_53; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_56; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_42; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_57; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_58; var tmp13 any = tmp5.Invoke_O__O(tmp7.Invoke_O__O(tmp9.Invoke_O_O_O__O(req__0, tmp11, tmp12.Ref()))); var tmp14 any; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_54; var tmp15 any = tmp14; var tmp16 any; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_55; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O_O__O(tmp13, tmp15, tmp16))).Ref()
}
func A_arbace_box_build_action_STAR__A_New() *A_arbace_box_build_action_STAR__A { A_arbace_box_build_action_STAR__A_Init(); t := &A_arbace_box_build_action_STAR__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Ctor() {}
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Invoke_O_O_O__O(self, what__0, req__1 any) any { var cref__3 any; var tmp1 *lang.Var;

	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_59; cref__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(req__1); var cached__4 any; var tmp2 /*line :106:1*/*lang.Keyword;


	A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_60; var tmp3 lang.IFn = Up_Keyword_IFn(tmp2); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_49; var tmp5 any = jrt.NN(tmp4).Get__O(); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(tmp5, tmp6.Ref())) { var temp__1927000414__auto____4 any; var tmp7 *lang.Var
		A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_61; temp__1927000414__auto____4 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(cref__3); if jrt.A2g_Truth(temp__1927000414__auto____4) { var h__5 any = temp__1927000414__auto____4; var tmp8 *lang.Var
			A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_62; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(h__5)) { var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_63; cached__4 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(h__5) } else { cached__4 = nil } } else {
//line :110:1
				cached__4 = nil } } else {
//line :109:1
					cached__4 = nil }; var t0__5 int64 = /*line :106:1*/jrt.System_NanoTime__J(); var res__6 any; var or__1927000174__auto____6 any = cached__4; if






	jrt.A2g_Truth(or__1927000174__auto____6) { res__6 = or__1927000174__auto____6 } else { var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_64; var tmp11 lang.IFn = Up_Keyword_IFn(tmp10); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_49; var tmp13 any = jrt.NN(tmp12).Get__O(); var tmp14 *lang.Var; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_65; res__6 = lang.IFn_Cast(tmp11.Invoke_O_O__O(tmp13, jrt.NN(tmp14).GetRawRoot__O())).Invoke_O__O(req__1) }; var tmp15 /*line :114:1*/*lang.Keyword; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_66; if lang.Util_Equiv_J_O__Z(0, jrt.NN(tmp15).Invoke_O__O(res__6)) { } else {
		var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_67; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_185, nil, Lit_186, nil, Lit_187, nil); var tmp19 *jrt.String; var tmp20 *lang.Keyword; A_arbace_box_build_A_Init(); tmp20 = A_arbace_box_build_A_const_71; if jrt.A2g_Truth(jrt.NN(tmp20).Invoke_O__O(res__6)) { var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_188, nil); var tmp22 *lang.Keyword; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_71; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp22).Invoke_O__O(res__6))) } else { var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_189, nil); var tmp24 *lang.Keyword; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_66; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp24).Invoke_O__O(res__6))) }; var tmp25 any = tmp19.Ref(); var tmp26 *lang.Var; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_72; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_box_build_A_Init(); tmp28 = A_arbace_box_build_A_const_75; var tmp29 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, what__0, nil, tmp25, nil, tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(res__6)))).Ref(); var tmp30 *lang.Keyword; A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_73; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Keyword; A_arbace_box_build_A_Init(); tmp32 = A_arbace_box_build_A_const_74; tmp17.Invoke_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, what__0, tmp32.Ref(), res__6))) }; var tmp33 any; var and__1927000168__auto____7 any; var tmp34 /*line :118:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp34 = A_arbace_box_build_A_const_68; and__1927000168__auto____7 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(cached__4); if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp35 *lang.Keyword; A_arbace_box_build_A_Init(); tmp35 = A_arbace_box_build_A_const_60; var tmp36 lang.IFn = Up_Keyword_IFn(tmp35); var tmp37 *lang.Var; A_arbace_box_build_A_Init(); tmp37 = A_arbace_box_build_A_const_49; var tmp38 any = jrt.NN(tmp37).Get__O(); var tmp39 *jrt.Boolean; jrt.Boolean_Init(); tmp39 = jrt.Boolean_TRUE; tmp33 = tmp36.Invoke_O_O__O(tmp38, tmp39.Ref()) } else { tmp33 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp33) {
			var tmp40 *lang.Var; A_arbace_box_build_A_Init(); tmp40 = A_arbace_box_build_A_const_69; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Keyword; A_arbace_box_build_A_Init(); tmp42 = A_arbace_box_build_A_const_76; tmp41.Invoke_O_O__O(cref__3, jrt.NN(tmp42).Invoke_O__O(res__6)) }; var tmp43 /*line :120:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp43 = A_arbace_box_build_A_const_70; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_box_build_A_Init(); tmp45 = A_arbace_box_build_A_const_77; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_box_build_A_Init(); tmp47 = A_arbace_box_build_A_const_18; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_box_build_A_Init(); tmp49 = A_arbace_box_build_A_const_78; var tmp50 any = tmp48.Invoke_O__O(jrt.NN(tmp49).Invoke_O__O(req__1)); var tmp51 any; if
	jrt.A2g_Truth(cached__4) { tmp51 = Lit_191 } else { var tmp52 *lang.Var; A_arbace_box_build_A_Init(); tmp52 = A_arbace_box_build_A_const_77; tmp51 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O_O__O(Lit_192, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref()) }; /*line :120:1*/tmp44.Invoke_O__O(tmp46.Invoke_O_O_O_O__O(Lit_190, tmp50, what__0, tmp51)); return res__6 }



func A_arbace_box_build_action_A_New() *A_arbace_box_build_action_A { A_arbace_box_build_action_A_Init(); t := &A_arbace_box_build_action_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_build_action_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O_O__O(self, what__0, req__1, opts__2 any) any {




	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_81; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_82; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_49; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), opts__2))
//line :124:1
	var tmp6 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_79; tmp6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(what__0, req__1) }
//line :124:1
		return nil }(); var tmp9 *lang.Var




	A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_80; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke__O()
//line :124:1
	if tmp8 != nil { panic(tmp8) }; return tmp6 }
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O__O(self, what__0, req__1 any) any {



	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_79; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(what__0, req__1)
}

func A_arbace_box_build_out_file_A_New() *A_arbace_box_build_out_file_A { A_arbace_box_build_out_file_A_Init(); t := &A_arbace_box_build_out_file_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_box_build_out_file_A) Ctor() {}
//line :131:1
func (t *A_arbace_box_build_out_file_A) Invoke_O_O_O_O__O(self, res__0, what__1, name__2 any) any { var or__1927000174__auto____4 any; var tmp1 *lang.Var;


	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_84; or__1927000174__auto____4 = tmp2.Invoke_O_O__O(jrt.NN(tmp3).Invoke_O__O(res__0), name__2); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_67; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_185, nil, Lit_335, nil, Lit_336), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil, name__2, nil)).Ref(); var tmp7 *lang.Keyword; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_74; return tmp5.Invoke_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), res__0))) } }

func A_arbace_box_build_file_tree_A_New() *A_arbace_box_build_file_tree_A { A_arbace_box_build_file_tree_A_Init(); t := &A_arbace_box_build_file_tree_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Ctor() {}
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 any; var iter__1927001039__auto____2 any; var tmp8 any = A_arbace_box_build_file_tree_iter__598000054__598000058_A_New(); var tmp9 *jrt.Class; A_arbace_box_build_file_tree_iter__598000054__598000058_A_Init(); tmp9 = A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_A_New() *A_arbace_box_build_file_tree_iter__598000054__598000058_A { A_arbace_box_build_file_tree_iter__598000054__598000058_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ctor() {}
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Invoke_O_O__O(self, s__598000055__1 any) any { var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(s__598000055__1, self); var tmp2 *jrt.Class; A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_Init(); tmp2 = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(p0, p1 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ctor_O_O(c__s__598000055, c__iter__598000054 any) { t.F_s__598000055 = c__s__598000055; t.F_iter__598000054 = c__iter__598000054 }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Invoke_O__O(self any) any { { var s__598000055__1 any; var t_ any = t.F_s__598000055; t.F_s__598000055 = nil; s__598000055__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000055__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000055__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000055__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000055__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000057__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000057__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(b__598000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_Init(); tmp6 = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000057__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000055__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000057__6), nil) } } else { var vec__598000065__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; vec__598000065__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000055__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__598000065__4, lang.RT_IntCast_J__I(0), nil); var x__6 any = lang.RT_Nth_O_I_O__O(vec__598000065__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_25; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__6)); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp22 *lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__598000055__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ctor_O_I_O(c__b__598000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000057 = c__b__598000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Invoke_O__O(self any) any { { var i__598000056__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000056__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__598000061__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__598000061__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000057; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_25; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__3, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__4))); i__598000056__1 = lang.Numbers_Unchecked_inc_J__J(i__598000056__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_arch_defines_A_New() *A_arbace_box_build_arch_defines_A { A_arbace_box_build_arch_defines_A_Init(); t := &A_arbace_box_build_arch_defines_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Ctor() {}
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Invoke_O_O__O(self, plan__0 any) any { var a__2 any; var tmp1 *lang.Keyword;
											A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_85; a__2 = jrt.NN(tmp1).Invoke_O__O(plan__0); var tmp2 /*line :144:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_86; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_201, nil); var tmp5 *lang.Keyword; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_88; var tmp6 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_200, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp5).Invoke_O__O(plan__0))).Ref(), Lit_200, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_202, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__2)).Ref()); var tmp7 any; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_87; var tmp8 any = tmp7; var tmp9 lang.IPersistentVector; var G__598000071__3_ any = a__2; L1:

	switch { default: switch lang.Util_Hash_O__I(G__598000071__3_) { case 92926582: if lang.Util_Equiv_O_O__Z(G__598000071__3_, Lit_203) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_204, nil); var tmp11 *lang.Keyword; A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_89; tmp9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_200, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp11).Invoke_O__O(plan__0))).Ref()); break L1 }; default:}; lang.PersistentVector_Init(); tmp9 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY)}; return /*line :144:1*/ tmp3.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }





func A_arbace_box_build_asm_args_A_New() *A_arbace_box_build_asm_args_A { A_arbace_box_build_asm_args_A_Init(); t := &A_arbace_box_build_asm_args_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_box_build_asm_args_A) Ctor() {}
//line :150:1
func (t *A_arbace_box_build_asm_args_A) DoInvoke_O_O_O_O_O__O(self, plan__0, pkg__1, out__2, more__3 any) any {
	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_90; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_86; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_91; var tmp6 any = jrt.NN(tmp5).Invoke_O__O(pkg__1); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_224, nil, Lit_225); var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_91; var tmp9 any = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, Lit_135, Lit_222, tmp6, Lit_223, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp8).Invoke_O__O(pkg__1), nil)).Ref(), Lit_226, Lit_227, Lit_226, Lit_228)); var tmp10 *lang.Var; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_92; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_box_build_asm_args_fn__598000074_A_New_O(pkg__1); var tmp13 *jrt.Class; A_arbace_box_build_asm_args_fn__598000074_A_Init(); tmp13 = A_arbace_box_build_asm_args_fn__598000074_A_fn_class; var tmp14 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_95; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp9, tmp11.Invoke_O_O__O(tmp14, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(plan__0)), more__3, lang.Tuple_Create_O_O__IPersistentVector(Lit_229, out__2)))
}
func A_arbace_box_build_asm_args_fn__598000074_A_New_O(p0 any) *A_arbace_box_build_asm_args_fn__598000074_A { A_arbace_box_build_asm_args_fn__598000074_A_Init(); t := &A_arbace_box_build_asm_args_fn__598000074_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Invoke_O_O__O(self, p1__598000073_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_93; if lang.Util_Equiv_O_O__Z(p1__598000073_SHARP___1, tmp1.Ref()) { var tmp2 *lang.Keyword; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_93; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(t.F_pkg)) { A_arbace_box_build_A_Init(); return A_arbace_box_build_A_const_94 } else { return nil } } else { return lang.Tuple_Create_O__IPersistentVector(p1__598000073_SHARP___1) } }




func A_arbace_box_build_ar_member_A_New() *A_arbace_box_build_ar_member_A { A_arbace_box_build_ar_member_A_Init(); t := &A_arbace_box_build_ar_member_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Ctor() {}
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Invoke_O_O_O__O(self, name__0, data__1 any) any { var pad__3 any; var tmp1 any = A_arbace_box_build_ar_member_pad__598000077_A_New(); var tmp2 *jrt.Class;
												A_arbace_box_build_ar_member_pad__598000077_A_Init(); tmp2 = A_arbace_box_build_ar_member_pad__598000077_A_fn_class; pad__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var hdr__4 any; var tmp3 /*line :158:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil, Lit_195); var tmp4 lang.IFn = lang.IFn_Cast(pad__3); var tmp5 *lang.Var;

	A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_52; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_54; var tmp8 any = tmp7; var tmp9 any = tmp6.Invoke_O_O_O__O(name__0, tmp8, jrt.Long_ValueOf_J__Long(lang.Numbers_Min_J_J__J(16, int64(lang.RT_Count_O__I(name__0)))).Ref()); var tmp10 any; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_98; var tmp11 any = tmp4.Invoke_O_O__O(tmp9, tmp10); var tmp12 lang.IFn = lang.IFn_Cast(pad__3); var tmp13 any; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_99; var tmp14 any = tmp12.Invoke_O_O__O(Lit_196, tmp13); var tmp15 lang.IFn = lang.IFn_Cast(pad__3); var tmp16 any; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_100; var tmp17 any = tmp15.Invoke_O_O__O(Lit_196, tmp16); var tmp18 lang.IFn = lang.IFn_Cast(pad__3); var tmp19 any; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_100; var tmp20 any = tmp18.Invoke_O_O__O(Lit_196, tmp19); var tmp21 lang.IFn = lang.IFn_Cast(pad__3); var tmp22 any; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_101; var tmp23 any = tmp21.Invoke_O_O__O(Lit_197, tmp22); var tmp24 lang.IFn = lang.IFn_Cast(pad__3); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_14; var tmp26 any = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref()); var tmp27 any; A_arbace_box_build_A_Init(); tmp27 = A_arbace_box_build_A_const_102; hdr__4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp11, tmp14, tmp17, tmp20, tmp23, tmp24.Invoke_O_O__O(tmp26, tmp27), nil)).Ref(); var o__5 any = /*line :158:1*/jrt.ByteArrayOutputStream_New();



	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.NN(jrt.String_Cast(hdr__4)).GetBytes_Charset__B1(jrt.StandardCharsets_US_ASCII));
	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass())); var tmp28 /*line :164:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp28 = A_arbace_box_build_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref())) { jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).Write_I__V(lang.RT_IntCast_J__I(10)) }; return /*line :165:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).ToByteArray__B1().Ref() }
//line :159:1
func A_arbace_box_build_ar_member_pad__598000077_A_New() *A_arbace_box_build_ar_member_pad__598000077_A { A_arbace_box_build_ar_member_pad__598000077_A_Init(); t := &A_arbace_box_build_ar_member_pad__598000077_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ctor() {}
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Invoke_O_O_O__O(self, s__1, n__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_51; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_14; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_96; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = lang.Numbers_Minus_O_J__Number(n__2, int64(lang.RT_Count_O__I(s__1))); var tmp9 any; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_97; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp8, tmp9)))).Ref() }







func A_arbace_box_build_append_members_A_New() *A_arbace_box_build_append_members_A { A_arbace_box_build_append_members_A_Init(); t := &A_arbace_box_build_append_members_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_box_build_append_members_A) Ctor() {}
//line :167:1
func (t *A_arbace_box_build_append_members_A) Invoke_O_O_O__O(self, archive__0, members__1 any) any { var o__3 any = jrt.ByteArrayOutputStream_New();

	jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](archive__0, jrt.Prim_byte.ArrayClass())); var seq_598000080__4 any; var tmp1 /*line :167:1*/*lang.Var;


	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; seq_598000080__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(members__1); var chunk_598000081__5 any; var count_598000082__6 int64 = 0; var i_598000083__7 int64 = 0; L1:
//line :167:1
	for {


		if lang.Numbers_Lt_J_J__Z(i_598000083__7, count_598000082__6) { var vec__598000084__8 any = lang.Indexed_Cast(chunk_598000081__5).Nth_I__O(lang.RT_IntCast_J__I(i_598000083__7)); var n__9 any = lang.RT_Nth_O_I_O__O(vec__598000084__8, lang.RT_IntCast_J__I(0), nil); var data__10 any = lang.RT_Nth_O_I_O__O(vec__598000084__8, lang.RT_IntCast_J__I(1), nil); var tmp2 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_104; tmp2.Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(n__9, data__10), jrt.Prim_byte.ArrayClass())); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = seq_598000080__4, chunk_598000081__5, count_598000082__6, lang.Numbers_Unchecked_inc_J__J(i_598000083__7); continue L1 } else { var temp__1927000414__auto____8 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_15; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq_598000080__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_598000080__9 any = temp__1927000414__auto____8; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_598000080__9)) { var c__1927000678__auto____10 any; var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_17; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_598000080__9); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_19; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_598000080__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__598000087__10 any; var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_18; vec__598000087__10 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_598000080__9); var n__11 any = lang.RT_Nth_O_I_O__O(vec__598000087__10, lang.RT_IntCast_J__I(0), nil); var data__12 any = lang.RT_Nth_O_I_O__O(vec__598000087__10, lang.RT_IntCast_J__I(1), nil); var tmp9 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp10 *lang.Var; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_104; tmp9.Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(n__11, data__12), jrt.Prim_byte.ArrayClass())); var tmp11 *lang.Var; A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_20; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_598000080__9), nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; return /*line :171:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__3)).ToByteArray__B1().Ref() }






func A_arbace_box_build_complete_QMARK__A_New() *A_arbace_box_build_complete_QMARK__A { A_arbace_box_build_complete_QMARK__A_Init(); t := &A_arbace_box_build_complete_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;


	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_105; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_106; and__1927000168__auto____2 = tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(pkg__0)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_68; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var and__1927000168__auto____3 any; var tmp7 *lang.Keyword; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_93; and__1927000168__auto____3 = jrt.NN(tmp7).Invoke_O__O(pkg__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_107; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_91; tmp6 = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(pkg__0)) } else { tmp6 = and__1927000168__auto____3 }; return tmp5.Invoke_O__O(tmp6) } else { return and__1927000168__auto____2 } }

func A_arbace_box_build_deps_tree_A_New() *A_arbace_box_build_deps_tree_A { A_arbace_box_build_deps_tree_A_Init(); t := &A_arbace_box_build_deps_tree_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Ctor() {}
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Invoke_O_O_O_O__O(self, archives__0, index__1, paths__2 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 any; var iter__1927001039__auto____4 any; var tmp8 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(archives__0, index__1); var tmp9 *jrt.Class;



	A_arbace_box_build_deps_tree_iter__598000092__598000096_A_Init(); tmp9 = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(paths__2); var tmp10 any = /*line :183:1*/tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7)); var tmp11 any; var iter__1927001039__auto____4_2 any; var tmp12 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(index__1); var tmp13 *jrt.Class;




	A_arbace_box_build_deps_tree_iter__598000102__598000106_A_Init(); tmp13 = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp11 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(paths__2); return /*line :183:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) }



func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(p0, p1 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { A_arbace_box_build_deps_tree_iter__598000092__598000096_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ctor_O_O(c__archives, c__index any) { t.F_archives = c__archives; t.F_index = c__index }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Invoke_O_O__O(self, s__598000093__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(t.F_archives, t.F_index, self, s__598000093__1); var tmp2 *jrt.Class; A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_Init(); tmp2 = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ctor_O_O_O_O(c__archives, c__index, c__iter__598000092, c__s__598000093 any) { t.F_archives = c__archives; t.F_index = c__index; t.F_iter__598000092 = c__iter__598000092; t.F_s__598000093 = c__s__598000093 }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Invoke_O__O(self any) any { { var s__598000093__1 any; var t_ any = t.F_s__598000093; t.F_s__598000093 = nil; s__598000093__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000093__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000093__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000093__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000093__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000095__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000095__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(b__598000095__6, t.F_archives, t.F_index, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_Init(); tmp6 = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000095__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000093__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000095__6), nil) } } else { var p__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; p__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000093__3); var a__5 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__4); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_281), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), a__5); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__598000093__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ctor_O_O_O_I_O(c__b__598000095, c__archives, c__index any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000095 = c__b__598000095; t.F_archives = c__archives; t.F_index = c__index; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Invoke_O__O(self any) any { { var i__598000094__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000094__1)); var a__3 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__2); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000095; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_281), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(), a__3)); i__598000094__1 = lang.Numbers_Unchecked_inc_J__J(i__598000094__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(p0 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { A_arbace_box_build_deps_tree_iter__598000102__598000106_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ctor_O(c__index any) { t.F_index = c__index }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Invoke_O_O__O(self, s__598000103__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(s__598000103__1, t.F_index, self); var tmp2 *jrt.Class; A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_Init(); tmp2 = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ctor_O_O_O(c__s__598000103, c__index, c__iter__598000102 any) { t.F_s__598000103 = c__s__598000103; t.F_index = c__index; t.F_iter__598000102 = c__iter__598000102 }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Invoke_O__O(self any) any { { var s__598000103__1 any; var t_ any = t.F_s__598000103; t.F_s__598000103 = nil; s__598000103__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000103__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000103__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000103__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000103__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000105__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000105__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(t.F_index, b__598000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_Init(); tmp6 = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000105__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000103__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000105__6), nil) } } else { var p__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; p__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000103__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_285, nil, Lit_286, nil, Lit_281), jrt.RefArrayOf(jrt.Object_class, nil, p__4, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__598000103__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ctor_O_O_I_O(c__index, c__b__598000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_b__598000105 = c__b__598000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Invoke_O__O(self any) any { { var i__598000104__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000104__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000105; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_285, nil, Lit_286, nil, Lit_281), jrt.RefArrayOf(jrt.Object_class, nil, p__2, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref()); i__598000104__1 = lang.Numbers_Unchecked_inc_J__J(i__598000104__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_json_str_A_New() *A_arbace_box_build_json_str_A { A_arbace_box_build_json_str_A_Init(); t := &A_arbace_box_build_json_str_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_build_json_str_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_build_json_str_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_319, nil, Lit_319); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_51; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_14; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_108; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_box_build_json_str_fn__598000113_A_New(); var tmp9 *jrt.Class; A_arbace_box_build_json_str_fn__598000113_A_Init(); tmp9 = A_arbace_box_build_json_str_fn__598000113_A_fn_class; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), s__0)), nil)).Ref() }
//line :193:1
func A_arbace_box_build_json_str_fn__598000113_A_New() *A_arbace_box_build_json_str_fn__598000113_A { A_arbace_box_build_json_str_fn__598000113_A_Init(); t := &A_arbace_box_build_json_str_fn__598000113_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Ctor() {}
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 any; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_109; if lang.Util_Equiv_O_O__Z(c__1, tmp1) { return Lit_321 } else { var tmp2 any; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_110; if lang.Util_Equiv_O_O__Z(c__1, tmp2) { return Lit_322 } else { if lang.Numbers_Lt_J_J__Z(int64(lang.RT_IntCast_O__I(c__1)), 32) {
											var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_77; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(Lit_323, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__1)).Ref()) } else {
//line :193:1
		var tmp4 *lang.Keyword; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_111; if tmp4 != nil {

			var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_14; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(c__1) } else {
//line :193:1
				return nil } } } } }





func A_arbace_box_build_embed_config_A_New() *A_arbace_box_build_embed_config_A { A_arbace_box_build_embed_config_A_Init(); t := &A_arbace_box_build_embed_config_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Ctor() {}
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Invoke_O_O__O(self, patterns__0 any) any { var files__2 any; var tmp1 *lang.Var;



	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_112; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_113; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_92; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_114; files__2 = tmp2.Invoke_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), patterns__0))); var tmp8 /*line :204:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_289, nil, Lit_290, nil, Lit_291); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_51; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_14; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_115; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var iter__1927001039__auto____8 any; var tmp16 any = A_arbace_box_build_embed_config_iter__598000116__598000120_A_New(); var tmp17 *jrt.Class;
	A_arbace_box_build_embed_config_iter__598000116__598000120_A_Init(); tmp17 = A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_117; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_118; tmp15 = tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(jrt.NN(tmp21).GetRawRoot__O(), patterns__0)); var tmp22 any = /*line :204:1*/tmp10.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O__O(Lit_292, tmp15)); var tmp23 *lang.Var; A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_51; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_14; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_box_build_A_Init(); tmp27 = A_arbace_box_build_A_const_115; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; var iter__1927001039__auto____8_2 any; var tmp30 any = A_arbace_box_build_embed_config_iter__598000132__598000136_A_New(); var tmp31 *jrt.Class;



	A_arbace_box_build_embed_config_iter__598000132__598000136_A_Init(); tmp31 = A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); tmp29 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(files__2); return /*line :204:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, nil, tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O__O(Lit_292, tmp29)), nil)).Ref() }
func A_arbace_box_build_embed_config_iter__598000116__598000120_A_New() *A_arbace_box_build_embed_config_iter__598000116__598000120_A { A_arbace_box_build_embed_config_iter__598000116__598000120_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ctor() {}
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Invoke_O_O__O(self, s__598000117__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(self, s__598000117__1); var tmp2 *jrt.Class; A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_Init(); tmp2 = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ctor_O_O(c__iter__598000116, c__s__598000117 any) { t.F_iter__598000116 = c__iter__598000116; t.F_s__598000117 = c__s__598000117 }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Invoke_O__O(self any) any { { var s__598000117__1 any; var t_ any = t.F_s__598000117; t.F_s__598000117 = nil; s__598000117__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000117__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000117__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000117__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000117__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000119__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000119__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(b__598000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_Init(); tmp6 = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000119__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000117__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000119__6), nil) } } else { var vec__598000127__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; vec__598000127__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000117__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__598000127__4, lang.RT_IntCast_J__I(0), nil); var fs__6 any = lang.RT_Nth_O_I_O__O(vec__598000127__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_295, nil, Lit_296); var tmp20 *lang.Var; A_arbace_box_build_A_Init(); tmp20 = A_arbace_box_build_A_const_116; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(p__5); var tmp22 *lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_51; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_14; var tmp25 any = jrt.NN(tmp24).GetRawRoot__O(); var tmp26 *lang.Var; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_115; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_box_build_A_Init(); tmp28 = A_arbace_box_build_A_const_108; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_116; var tmp31 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, tmp23.Invoke_O_O__O(tmp25, tmp27.Invoke_O_O__O(Lit_292, tmp29.Invoke_O_O__O(jrt.NN(tmp30).GetRawRoot__O(), fs__6))), nil)).Ref(); var tmp32 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp33 *lang.Var; A_arbace_box_build_A_Init(); tmp33 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp31, tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__598000117__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ctor_O_I_O(c__b__598000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000119 = c__b__598000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Invoke_O__O(self any) any { { var i__598000118__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000123__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000118__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__598000123__2, lang.RT_IntCast_J__I(0), nil); var fs__4 any = lang.RT_Nth_O_I_O__O(vec__598000123__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000119; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_295, nil, Lit_296); var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_116; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p__3); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_51; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_14; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_115; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_108; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_116; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, tmp9.Invoke_O_O__O(tmp11, tmp13.Invoke_O_O__O(Lit_292, tmp15.Invoke_O_O__O(jrt.NN(tmp16).GetRawRoot__O(), fs__4))), nil)).Ref()); i__598000118__1 = lang.Numbers_Unchecked_inc_J__J(i__598000118__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_embed_config_iter__598000132__598000136_A_New() *A_arbace_box_build_embed_config_iter__598000132__598000136_A { A_arbace_box_build_embed_config_iter__598000132__598000136_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ctor() {}
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Invoke_O_O__O(self, s__598000133__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(s__598000133__1, self); var tmp2 *jrt.Class; A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_Init(); tmp2 = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ctor_O_O(c__s__598000133, c__iter__598000132 any) { t.F_s__598000133 = c__s__598000133; t.F_iter__598000132 = c__iter__598000132 }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Invoke_O__O(self any) any { { var s__598000133__1 any; var t_ any = t.F_s__598000133; t.F_s__598000133 = nil; s__598000133__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000133__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000133__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000133__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000133__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000135__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000135__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(b__598000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_Init(); tmp6 = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000135__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000133__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000135__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000133__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_300, nil); var tmp20 *lang.Var; A_arbace_box_build_A_Init(); tmp20 = A_arbace_box_build_A_const_116; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(f__4); var tmp22 *lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_116; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_253, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref()))).Ref(); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__598000133__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ctor_O_I_O(c__b__598000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000135 = c__b__598000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Invoke_O__O(self any) any { { var i__598000134__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000134__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000135; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_300, nil); var tmp6 *lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_116; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(f__2); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_116; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_253, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref()))).Ref()); i__598000134__1 = lang.Numbers_Unchecked_inc_J__J(i__598000134__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_build_package_A_New() *A_arbace_box_build_build_package_A { A_arbace_box_build_build_package_A_Init(); t := &A_arbace_box_build_build_package_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_build_build_package_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_build_build_package_A) Invoke_O_O_O_O_O__O(self, plan__0, pkg__1, archives__2, index__3 any) any { var map__598000145__5 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_49; map__598000145__5 = jrt.NN(tmp1).Get__O(); var map__598000145__6 any; if


	lang.ISeq_InstanceOf(map__598000145__5) { var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__598000145__5)) { var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_119; map__598000145__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__598000145__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__598000145__5)) { var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_18; map__598000145__6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__598000145__5) } else { lang.PersistentArrayMap_Init(); map__598000145__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__598000145__6 = map__598000145__5 }; var tools__7 any; var tmp6 /*line :211:1*/*lang.Keyword;


	A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_120; tools__7 = lang.RT_Get_O_O__O(map__598000145__6, tmp6.Ref()); var P__8_ any; var tmp7 /*line :211:1*/*lang.Keyword;



	A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_91; P__8_ = jrt.NN(tmp7).Invoke_O__O(pkg__1); var imports__9 any; var tmp8 /*line :211:1*/*lang.Keyword;




	A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_121; imports__9 = jrt.NN(tmp8).Invoke_O__O(pkg__1); var vec__598000147__10 any; var tmp9 /*line :211:1*/*lang.Var;





	A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_122; vec__598000147__10 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O__O(archives__2, index__3, imports__9); var dtree__11 any = /*line :211:1*/lang.RT_Nth_O_I_O__O(vec__598000147__10, lang.RT_IntCast_J__I(0), nil); var lines__12 any = lang.RT_Nth_O_I_O__O(vec__598000147__10, lang.RT_IntCast_J__I(1), nil); var importcfg__13 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_235, nil, nil); var tmp11 *lang.Var;






	A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_51; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_14; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 any; var iter__1927001039__auto____16 any; var tmp16 any = A_arbace_box_build_build_package_iter__598000150__598000154_A_New(); var tmp17 *jrt.Class;
	A_arbace_box_build_build_package_iter__598000150__598000154_A_Init(); tmp17 = A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____16); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_112; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_135; tmp15 = tmp18.Invoke_O__O(tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(pkg__1))); var tmp22 any = /*line :218:1*/tmp12.Invoke_O_O__O(tmp14, tmp15); var tmp23 *lang.Var; A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_51; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_14; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 any; var iter__1927001039__auto____16_2 any; var tmp28 any = A_arbace_box_build_build_package_iter__598000166__598000170_A_New(); var tmp29 *jrt.Class;

	A_arbace_box_build_build_package_iter__598000166__598000170_A_Init(); tmp29 = A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lines__12); importcfg__13 = /*line :218:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, tmp24.Invoke_O_O__O(tmp26, tmp27))).Ref(); var sfiles__14 any; var tmp30 /*line :211:1*/*lang.Keyword;









	A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_106; sfiles__14 = jrt.NN(tmp30).Invoke_O__O(pkg__1); var res_of__15 any; var tmp31 any = /*line :211:1*/A_arbace_box_build_build_package_res_of__598000176_A_New_O(P__8_); var tmp32 *jrt.Class;










	A_arbace_box_build_build_package_res_of__598000176_A_Init(); tmp32 = A_arbace_box_build_build_package_res_of__598000176_A_fn_class; res_of__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var rsc__16 any; var or__1927000174__auto____16 any; var tmp33 /*line :211:1*/*lang.Keyword;














	A_arbace_box_build_A_Init(); tmp33 = A_arbace_box_build_A_const_125; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Var; A_arbace_box_build_A_Init(); tmp35 = A_arbace_box_build_A_const_49; or__1927000174__auto____16 = lang.RT_Get_O_O__O(jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Get__O()), P__8_); if jrt.A2g_Truth(or__1927000174__auto____16) { rsc__16 = or__1927000174__auto____16 } else {
		var tmp36 *lang.Var; A_arbace_box_build_A_Init(); tmp36 = A_arbace_box_build_A_const_126; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any = A_arbace_box_build_build_package_fn__598000179_A_New_O(P__8_); var tmp39 *jrt.Class; A_arbace_box_build_build_package_fn__598000179_A_Init(); tmp39 = A_arbace_box_build_build_package_fn__598000179_A_fn_class; var tmp40 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var tmp41 *lang.Var; A_arbace_box_build_A_Init(); tmp41 = A_arbace_box_build_A_const_117; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_box_build_A_Init(); tmp43 = A_arbace_box_build_A_const_138; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_box_build_A_Init(); tmp45 = A_arbace_box_build_A_const_139; var tmp46 any = jrt.NN(tmp45).GetRawRoot__O(); var tmp47 *lang.Var; A_arbace_box_build_A_Init(); tmp47 = A_arbace_box_build_A_const_140; var tmp48 any = jrt.NN(tmp47).GetRawRoot__O(); var tmp49 *lang.Var; A_arbace_box_build_A_Init(); tmp49 = A_arbace_box_build_A_const_14; var tmp50 any = jrt.NN(tmp49).GetRawRoot__O(); var tmp51 *lang.Var; A_arbace_box_build_A_Init(); tmp51 = A_arbace_box_build_A_const_118; var tmp52 any = tmp44.Invoke_O_O_O_O__O(tmp46, tmp48, tmp50, jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Keyword; A_arbace_box_build_A_Init(); tmp53 = A_arbace_box_build_A_const_125; var tmp54 *lang.Keyword = tmp53; var tmp55 *lang.Var; A_arbace_box_build_A_Init(); tmp55 = A_arbace_box_build_A_const_49; rsc__16 = tmp37.Invoke_O_O__O(tmp40, tmp42.Invoke_O_O__O(tmp52, jrt.NN(tmp54).Invoke_O__O(jrt.NN(tmp55).Get__O()))) }; var ___17 any; var tmp56 any; var and__1927000168__auto____17 any; var tmp57 /*line :211:1*/*lang.Keyword; _ = ___17;



















	A_arbace_box_build_A_Init(); tmp57 = A_arbace_box_build_A_const_127; and__1927000168__auto____17 = jrt.NN(tmp57).Invoke_O__O(pkg__1); if jrt.A2g_Truth(and__1927000168__auto____17) { var tmp58 *lang.Var; A_arbace_box_build_A_Init(); tmp58 = A_arbace_box_build_A_const_68; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Keyword; A_arbace_box_build_A_Init(); tmp60 = A_arbace_box_build_A_const_129; tmp56 = tmp59.Invoke_O__O(jrt.NN(tmp60).Invoke_O__O(pkg__1)) } else { tmp56 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp56) {
		var tmp61 *lang.Var; A_arbace_box_build_A_Init(); tmp61 = A_arbace_box_build_A_const_67; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_185, nil, Lit_236), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp64 *lang.Keyword; A_arbace_box_build_A_Init(); tmp64 = A_arbace_box_build_A_const_91; ___17 = tmp62.Invoke_O_O__O(tmp63, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64.Ref(), P__8_))) } else {
//line :231:1
			___17 = nil }; var embedcfg__18 any; var temp__1927000414__auto____18 any; var tmp65 /*line :211:1*/*lang.Keyword;





















	A_arbace_box_build_A_Init(); tmp65 = A_arbace_box_build_A_const_128; var tmp66 *lang.Keyword = tmp65; var tmp67 *lang.Keyword; A_arbace_box_build_A_Init(); tmp67 = A_arbace_box_build_A_const_129; temp__1927000414__auto____18 = jrt.NN(tmp66).Invoke_O__O(jrt.NN(tmp67).Invoke_O__O(pkg__1)); if jrt.A2g_Truth(temp__1927000414__auto____18) { var pats__19 any = temp__1927000414__auto____18; var tmp68 *lang.Var
		A_arbace_box_build_A_Init(); tmp68 = A_arbace_box_build_A_const_130; embedcfg__18 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(pats__19) } else {
//line :233:1
			embedcfg__18 = nil }; var symabis__19 any; var tmp69 /*line :211:1*/*lang.Var;























	A_arbace_box_build_A_Init(); tmp69 = A_arbace_box_build_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(sfiles__14)) {
		var tmp70 *lang.Var; A_arbace_box_build_A_Init(); tmp70 = A_arbace_box_build_A_const_131; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 lang.IFn = lang.IFn_Cast(res_of__15); var tmp73 *lang.Keyword; A_arbace_box_build_A_Init(); tmp73 = A_arbace_box_build_A_const_141; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Keyword; A_arbace_box_build_A_Init(); tmp75 = A_arbace_box_build_A_const_142; var tmp76 any = jrt.NN(tmp75).Invoke_O__O(tools__7); var tmp77 *lang.Keyword; A_arbace_box_build_A_Init(); tmp77 = A_arbace_box_build_A_const_78; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_box_build_A_Init(); tmp79 = A_arbace_box_build_A_const_21; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Var; A_arbace_box_build_A_Init(); tmp81 = A_arbace_box_build_A_const_144; var tmp82 any = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O_O_O_O__O(plan__0, pkg__1, Lit_238, Lit_239); var tmp83 *lang.Var; A_arbace_box_build_A_Init(); tmp83 = A_arbace_box_build_A_const_108; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any = A_arbace_box_build_build_package_fn__598000184_A_New(); var tmp86 *jrt.Class; A_arbace_box_build_build_package_fn__598000184_A_Init(); tmp86 = A_arbace_box_build_build_package_fn__598000184_A_fn_class; var tmp87 any = tmp80.Invoke_O_O__O(tmp82, tmp84.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil), sfiles__14)); var tmp88 *lang.Keyword; A_arbace_box_build_A_Init(); tmp88 = A_arbace_box_build_A_const_143; var tmp89 any = tmp88.Ref(); var tmp90 *lang.Keyword; A_arbace_box_build_A_Init(); tmp90 = A_arbace_box_build_A_const_43; var tmp91 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_117, jrt.NN(tmp90).Invoke_O__O(pkg__1)); var tmp92 *lang.Keyword; A_arbace_box_build_A_Init(); tmp92 = A_arbace_box_build_A_const_44; var tmp93 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_228, jrt.NN(tmp92).Invoke_O__O(plan__0)); var tmp94 *lang.Var; A_arbace_box_build_A_Init(); tmp94 = A_arbace_box_build_A_const_145; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 any; A_arbace_box_build_A_Init(); tmp96 = A_arbace_box_build_A_const_146; symabis__19 = tmp71.Invoke_O_O_O__O(tmp72.Invoke_O_O__O(Lit_237, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp76, tmp78, tmp87, tmp89, lang.Tuple_Create_O_O_O__IPersistentVector(tmp91, tmp93, lang.Tuple_Create_O_O__IPersistentVector(Lit_240, tmp95.Invoke_O__O(tmp96)))))), P__8_, Lit_237) } else {
//line :235:1
			symabis__19 = nil }; var compile__20 any; var tmp97 lang.IFn = /*line :211:1*/lang.IFn_Cast(res_of__15); var tmp98 *lang.Var;





























	A_arbace_box_build_A_Init(); tmp98 = A_arbace_box_build_A_const_123; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 *lang.Keyword; A_arbace_box_build_A_Init(); tmp100 = A_arbace_box_build_A_const_141; var tmp101 any = tmp100.Ref(); var tmp102 *lang.Keyword; A_arbace_box_build_A_Init(); tmp102 = A_arbace_box_build_A_const_147; var tmp103 any = jrt.NN(tmp102).Invoke_O__O(tools__7); var tmp104 *lang.Keyword; A_arbace_box_build_A_Init(); tmp104 = A_arbace_box_build_A_const_78; var tmp105 any = tmp104.Ref(); var tmp106 *lang.Var; A_arbace_box_build_A_Init(); tmp106 = A_arbace_box_build_A_const_90; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Var; A_arbace_box_build_A_Init(); tmp108 = A_arbace_box_build_A_const_86; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_224, nil, Lit_242), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp111 any; var tmp112 *lang.Keyword;



	A_arbace_box_build_A_Init(); tmp112 = A_arbace_box_build_A_const_149; if lang.Util_Equiv_O_O__Z(Lit_175, jrt.NN(tmp112).Invoke_O__O(pkg__1)) { tmp111 = Lit_175 } else { tmp111 = P__8_ }; var tmp113 any = tmp111; var tmp114 /*line :241:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_243, nil); var tmp115 *lang.Keyword; A_arbace_box_build_A_Init(); tmp115 = A_arbace_box_build_A_const_150; var tmp116 any = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, Lit_141, Lit_229, Lit_241, Lit_223, tmp110, Lit_222, tmp113, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp114, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp115).Invoke_O__O(pkg__1))).Ref())); var tmp117 any; var tmp118 *lang.Keyword;




	A_arbace_box_build_A_Init(); tmp118 = A_arbace_box_build_A_const_93; if jrt.A2g_Truth(jrt.NN(tmp118).Invoke_O__O(pkg__1)) { A_arbace_box_build_A_Init(); tmp117 = A_arbace_box_build_A_const_151 } else { tmp117 = nil }; var tmp119 any = tmp117; var tmp120 any; var tmp121 /*line :241:1*/*lang.Var;





	A_arbace_box_build_A_Init(); tmp121 = A_arbace_box_build_A_const_152; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()).Invoke_O__O(pkg__1)) { A_arbace_box_build_A_Init(); tmp120 = A_arbace_box_build_A_const_153 } else { tmp120 = nil }; var tmp122 any = tmp120; var tmp123 any; /*line :241:1*/A_arbace_box_build_A_Init(); tmp123 = A_arbace_box_build_A_const_154; var tmp124 any = tmp123; var tmp125 any; if







	jrt.A2g_Truth(symabis__19) { A_arbace_box_build_A_Init(); tmp125 = A_arbace_box_build_A_const_155 } else { tmp125 = nil }; var tmp126 any = tmp125; var tmp127 any; /*line :241:1*/A_arbace_box_build_A_Init(); tmp127 = A_arbace_box_build_A_const_156; var tmp128 any = tmp127; var tmp129 any; if









	jrt.A2g_Truth(embedcfg__18) { A_arbace_box_build_A_Init(); tmp129 = A_arbace_box_build_A_const_157 } else { tmp129 = nil }; var tmp130 any = tmp129; var tmp131 any; if
	jrt.A2g_Truth(symabis__19) { A_arbace_box_build_A_Init(); tmp131 = A_arbace_box_build_A_const_158 } else { tmp131 = nil }; var tmp132 any = tmp131; var tmp133 /*line :241:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp133 = A_arbace_box_build_A_const_108; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 any = A_arbace_box_build_build_package_fn__598000186_A_New(); var tmp136 *jrt.Class; A_arbace_box_build_build_package_fn__598000186_A_Init(); tmp136 = A_arbace_box_build_build_package_fn__598000186_A_fn_class; var tmp137 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp135, tmp136, nil); var tmp138 *lang.Keyword; A_arbace_box_build_A_Init(); tmp138 = A_arbace_box_build_A_const_159; var tmp139 any = tmp107.Invoke_O__O(tmp109.Invoke_O_O_O_O_O_O_O_O_O__O(tmp116, tmp119, tmp122, tmp124, tmp126, tmp128, tmp130, tmp132, tmp134.Invoke_O_O__O(tmp137, jrt.NN(tmp138).Invoke_O__O(pkg__1)))); var tmp140 *lang.Keyword; A_arbace_box_build_A_Init(); tmp140 = A_arbace_box_build_A_const_143; var tmp141 any = tmp140.Ref(); var tmp142 *lang.Var; A_arbace_box_build_A_Init(); tmp142 = A_arbace_box_build_A_const_90; var tmp143 lang.IFn = lang.IFn_Cast(jrt.NN(tmp142).GetRawRoot__O()); var tmp144 *lang.Var; A_arbace_box_build_A_Init(); tmp144 = A_arbace_box_build_A_const_86; var tmp145 lang.IFn = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()); var tmp146 *lang.Keyword; A_arbace_box_build_A_Init(); tmp146 = A_arbace_box_build_A_const_43; var tmp147 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_117, jrt.NN(tmp146).Invoke_O__O(pkg__1)); var tmp148 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_244, dtree__11); var tmp149 *lang.Var; A_arbace_box_build_A_Init(); tmp149 = A_arbace_box_build_A_const_22; var tmp150 lang.IFn = lang.IFn_Cast(jrt.NN(tmp149).GetRawRoot__O()); var tmp151 any; var G__598000188__20_ any; var tmp152 *lang.Var;













	A_arbace_box_build_A_Init(); tmp152 = A_arbace_box_build_A_const_25; G__598000188__20_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_245, lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()).Invoke_O__O(importcfg__13))); var G__598000188__21_ any; if jrt.A2g_Truth(symabis__19) {
		var tmp153 *lang.Var; A_arbace_box_build_A_Init(); tmp153 = A_arbace_box_build_A_const_12; G__598000188__21_ = lang.IFn_Cast(jrt.NN(tmp153).GetRawRoot__O()).Invoke_O_O_O__O(G__598000188__20_, Lit_237, symabis__19) } else {
//line :255:1
			G__598000188__21_ = G__598000188__20_ }; if jrt.A2g_Truth(embedcfg__18) {

				var tmp154 *lang.Var; A_arbace_box_build_A_Init(); tmp154 = A_arbace_box_build_A_const_12; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 *lang.Var; A_arbace_box_build_A_Init(); tmp156 = A_arbace_box_build_A_const_25; tmp151 = tmp155.Invoke_O_O_O__O(G__598000188__21_, Lit_246, lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(embedcfg__18)) } else {
//line :255:1
					tmp151 = G__598000188__21_ }; var tmp157 any = /*line :241:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp101, tmp103, tmp105, tmp139, tmp141, tmp143.Invoke_O__O(tmp145.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp147, tmp148, lang.Tuple_Create_O_O__IPersistentVector(Lit_240, tmp150.Invoke_O__O(tmp151))))))); var tmp158 *lang.Var; A_arbace_box_build_A_Init(); tmp158 = A_arbace_box_build_A_const_148; var tmp159 lang.IFn = lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()); var tmp160 any; A_arbace_box_build_A_Init(); tmp160 = A_arbace_box_build_A_const_160; compile__20 = tmp97.Invoke_O_O__O(Lit_141, tmp99.Invoke_O_O__O(tmp157, tmp159.Invoke_O_O__O(rsc__16, tmp160))); var archive__21 any; var tmp161 /*line :211:1*/*lang.Var;















































	A_arbace_box_build_A_Init(); tmp161 = A_arbace_box_build_A_const_131; archive__21 = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O_O_O__O(compile__20, P__8_, Lit_247); var tmp162 /*line :260:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp162 = A_arbace_box_build_A_const_105; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()).Invoke_O__O(sfiles__14)) { return archive__21 } else { var asmh__22 any; var tmp163 *lang.Var

		A_arbace_box_build_A_Init(); tmp163 = A_arbace_box_build_A_const_131; asmh__22 = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke_O_O_O__O(compile__20, P__8_, Lit_139)
//line :260:1
		var ctree__23 any; var tmp164 *lang.Var


		A_arbace_box_build_A_Init(); tmp164 = A_arbace_box_build_A_const_22; ctree__23 = lang.IFn_Cast(jrt.NN(tmp164).GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_139, asmh__22)))
//line :260:1
		var objs__24 any; var tmp165 *lang.Var



		A_arbace_box_build_A_Init(); tmp165 = A_arbace_box_build_A_const_132; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 any; var iter__1927001039__auto____24 any; var tmp168 any = A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(res_of__15, P__8_, plan__0, ctree__23, pkg__1, tools__7); var tmp169 *jrt.Class
		A_arbace_box_build_build_package_iter__598000189__598000193_A_Init(); tmp169 = A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp168, tmp169, nil); tmp167 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(sfiles__14)
//line :264:1
		objs__24 = tmp166.Invoke_O__O(tmp167)
//line :260:1
		var members__25 any; var iter__1927001039__auto____25 any; var tmp170 any = A_arbace_box_build_build_package_iter__598000203__598000207_A_New(); var tmp171 *jrt.Class












		A_arbace_box_build_build_package_iter__598000203__598000207_A_Init(); tmp171 = A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp170, tmp171, nil); members__25 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(objs__24)
		var tmp172 *lang.Var; A_arbace_box_build_A_Init(); tmp172 = A_arbace_box_build_A_const_25; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Var; A_arbace_box_build_A_Init(); tmp174 = A_arbace_box_build_A_const_162; var tmp175 lang.IFn = lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()); var tmp176 *lang.Var; A_arbace_box_build_A_Init(); tmp176 = A_arbace_box_build_A_const_133; var tmp177 lang.IFn = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()); var tmp178 *lang.Var; A_arbace_box_build_A_Init(); tmp178 = A_arbace_box_build_A_const_134; return tmp173.Invoke_O__O(tmp175.Invoke_O_O__O(tmp177.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()).Invoke_O__O(archive__21)), members__25)) } }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_A_New() *A_arbace_box_build_build_package_iter__598000150__598000154_A { A_arbace_box_build_build_package_iter__598000150__598000154_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ctor() {}
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Invoke_O_O__O(self, s__598000151__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(self, s__598000151__1); var tmp2 *jrt.Class; A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_Init(); tmp2 = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ctor_O_O(c__iter__598000150, c__s__598000151 any) { t.F_iter__598000150 = c__iter__598000150; t.F_s__598000151 = c__s__598000151 }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Invoke_O__O(self any) any { { var s__598000151__1 any; var t_ any = t.F_s__598000151; t.F_s__598000151 = nil; s__598000151__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000151__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000151__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000151__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000151__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000153__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000153__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(b__598000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_Init(); tmp6 = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000153__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000151__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000153__6), nil) } } else { var vec__598000161__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; vec__598000161__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000151__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__598000161__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__598000161__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_256, nil, Lit_257, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, v__6, nil)).Ref(); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__598000151__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ctor_O_I_O(c__b__598000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000153 = c__b__598000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Invoke_O__O(self any) any { { var i__598000152__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000152__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000157__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__598000157__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000153; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_256, nil, Lit_257, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, v__4, nil)).Ref()); i__598000152__1 = lang.Numbers_Unchecked_inc_J__J(i__598000152__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_box_build_build_package_iter__598000166__598000170_A_New() *A_arbace_box_build_build_package_iter__598000166__598000170_A { A_arbace_box_build_build_package_iter__598000166__598000170_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ctor() {}
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Invoke_O_O__O(self, s__598000167__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(s__598000167__1, self); var tmp2 *jrt.Class; A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_Init(); tmp2 = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ctor_O_O(c__s__598000167, c__iter__598000166 any) { t.F_s__598000167 = c__s__598000167; t.F_iter__598000166 = c__iter__598000166 }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Invoke_O__O(self any) any { { var s__598000167__1 any; var t_ any = t.F_s__598000167; t.F_s__598000167 = nil; s__598000167__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000167__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000167__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000167__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000167__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000169__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000169__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(b__598000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_Init(); tmp6 = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000169__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000167__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000169__6), nil) } } else { var l__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; l__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000167__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__598000167__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ctor_O_I_O(c__b__598000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000169 = c__b__598000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Invoke_O__O(self any) any { { var i__598000168__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000168__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000169; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref()); i__598000168__1 = lang.Numbers_Unchecked_inc_J__J(i__598000168__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_build_package_res_of__598000176_A_New_O(p0 any) *A_arbace_box_build_build_package_res_of__598000176_A { A_arbace_box_build_build_package_res_of__598000176_A_Init(); t := &A_arbace_box_build_build_package_res_of__598000176_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Invoke_O_O_O__O(self, what__1, req__2 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_79; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_274, nil), jrt.RefArrayOf(jrt.Object_class, t.F_P, nil, what__1)).Ref(); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_123; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_124; return tmp2.Invoke_O_O__O(tmp3, tmp5.Invoke_O_O__O(tmp6, req__2)) }




func A_arbace_box_build_build_package_fn__598000179_A_New_O(p0 any) *A_arbace_box_build_build_package_fn__598000179_A { A_arbace_box_build_build_package_fn__598000179_A_Init(); t := &A_arbace_box_build_build_package_fn__598000179_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Invoke_O_O__O(self, p__598000178__1 any) any { var vec__598000180__2 any = p__598000178__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000180__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__598000180__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_136; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(k__3); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_24; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(k__3, Lit_249); if jrt.A2g_Truth(and__1927000168__auto____6) {
													var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_137; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_P; var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_52; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_54; var tmp10 any = tmp9; tmp1 = tmp5.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O_O__O(k__3, tmp10, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(k__3)))).Ref())) } else {
//line :227:1
		tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) { return v__4 } else { return nil } }










func A_arbace_box_build_build_package_fn__598000184_A_New() *A_arbace_box_build_build_package_fn__598000184_A { A_arbace_box_build_build_package_fn__598000184_A_Init(); t := &A_arbace_box_build_build_package_fn__598000184_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Invoke_O_O__O(self, p1__598000143_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_251, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000143_SHARP___1)).Ref() }














func A_arbace_box_build_build_package_fn__598000186_A_New() *A_arbace_box_build_build_package_fn__598000186_A { A_arbace_box_build_build_package_fn__598000186_A_Init(); t := &A_arbace_box_build_build_package_fn__598000186_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Ctor() {}
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Invoke_O_O__O(self, p1__598000144_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_253, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000144_SHARP___1)).Ref() }











func A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { A_arbace_box_build_build_package_iter__598000189__598000193_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ctor_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Invoke_O_O__O(self, s__598000190__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, s__598000190__1, self); var tmp2 *jrt.Class; A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_Init(); tmp2 = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools, c__s__598000190, c__iter__598000189 any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_s__598000190 = c__s__598000190; t.F_iter__598000189 = c__iter__598000189 }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Invoke_O__O(self any) any { { var s__598000190__1 any; var t_ any = t.F_s__598000190; t.F_s__598000190 = nil; s__598000190__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000190__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000190__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000190__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000190__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000192__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000192__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(b__598000192__6, t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_Init(); tmp6 = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000192__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000190__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000192__6), nil) } } else { var s__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; s__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000190__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 lang.IPersistentVector; var o__5 any; var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_264); var tmp21 *lang.Var
														A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_52; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_54; var tmp24 any = tmp23; o__5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22.Invoke_O_O_O__O(s__4, tmp24, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(s__4)), 2)).Ref()), nil)).Ref()
//line :265:1
	var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_161; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, o__5, t.F_ctree, t.F_pkg, s__4, t.F_tools); var tmp28 *jrt.Class; A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_Init(); tmp28 = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class; tmp19 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp26.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil))); var tmp29 any = tmp19; var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp31 *lang.Var; A_arbace_box_build_A_Init(); tmp31 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp29, tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(s__598000190__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ctor_O_O_O_O_O_O_O_I_O(c__b__598000192, c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000192 = c__b__598000192; t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Invoke_O__O(self any) any { { var i__598000191__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000191__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000192; var tmp5 lang.IPersistentVector; var o__3 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_264); var tmp7 *lang.Var
																A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_52; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_54; var tmp10 any = tmp9; o__3 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8.Invoke_O_O_O__O(s__2, tmp10, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(s__2)), 2)).Ref()), nil)).Ref()
//line :265:1
	var tmp11 *lang.Var; A_arbace_box_build_A_Init(); tmp11 = A_arbace_box_build_A_const_161; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, o__3, s__2, t.F_tools); var tmp14 *jrt.Class; A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_Init(); tmp14 = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class; tmp5 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp12.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil))); tmp3.Invoke_O_O__O(tmp4, tmp5); i__598000191__1 = lang.Numbers_Unchecked_inc_J__J(i__598000191__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__o, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_o = c__o; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_131; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp3 = t_; var tmp4 lang.IFn = lang.IFn_Cast(tmp3); var tmp5 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_267, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp6 *lang.Keyword; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_141; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_142; var tmp9 *lang.Keyword = tmp8; var tmp10 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp10 = t__2
//line :268:1
	var tmp11 any = jrt.NN(tmp9).Invoke_O__O(tmp10); var tmp12 *lang.Keyword; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_78; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_8; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_144; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_plan; var tmp19 any = t.F_pkg; var tmp20 any = tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_268, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_251, nil); var tmp22 any; var t__3 any = t.F_s

	t.F_s = nil; tmp22 = t__3
//line :268:1
	var tmp23 any = tmp15.Invoke_O_O__O(tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref()); var tmp24 *lang.Keyword; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_143; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Keyword; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_43; var tmp27 *lang.Keyword = tmp26; var tmp28 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp28 = t__4
//line :268:1
	var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_117, jrt.NN(tmp27).Invoke_O__O(tmp28)); var tmp30 *lang.Keyword; A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_44; var tmp31 *lang.Keyword = tmp30; var tmp32 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp32 = t__5
//line :268:1
	var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_228, jrt.NN(tmp31).Invoke_O__O(tmp32)); var tmp34 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp34 = t__6; var tmp35 any = tmp4.Invoke_O_O__O(tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp11, tmp13, tmp23, tmp25, lang.Tuple_Create_O_O_O__IPersistentVector(tmp29, tmp33, lang.Tuple_Create_O_O__IPersistentVector(Lit_240, tmp34))))); var tmp36 any; var t__7 any = t.F_P; t.F_P = nil; tmp36 = t__7; var tmp37 any = tmp36; var tmp38 any; var t__8 any = t.F_o; t.F_o = nil; tmp38 = t__8; return tmp2.Invoke_O_O_O__O(tmp35, tmp37, tmp38) }
//line :267:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__o, c__ctree, c__pkg, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_o = c__o; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_131; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp3 = t_; var tmp4 lang.IFn = lang.IFn_Cast(tmp3); var tmp5 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_267, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp6 *lang.Keyword; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_141; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_142; var tmp9 *lang.Keyword = tmp8; var tmp10 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp10 = t__2
//line :268:1
	var tmp11 any = jrt.NN(tmp9).Invoke_O__O(tmp10); var tmp12 *lang.Keyword; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_78; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_8; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_144; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_plan; var tmp19 any = t.F_pkg; var tmp20 any = tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_268, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_251, nil); var tmp22 any; var t__3 any = t.F_s

	t.F_s = nil; tmp22 = t__3
//line :268:1
	var tmp23 any = tmp15.Invoke_O_O__O(tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref()); var tmp24 *lang.Keyword; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_143; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Keyword; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_43; var tmp27 *lang.Keyword = tmp26; var tmp28 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp28 = t__4
//line :268:1
	var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_117, jrt.NN(tmp27).Invoke_O__O(tmp28)); var tmp30 *lang.Keyword; A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_44; var tmp31 *lang.Keyword = tmp30; var tmp32 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp32 = t__5
//line :268:1
	var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_228, jrt.NN(tmp31).Invoke_O__O(tmp32)); var tmp34 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp34 = t__6; var tmp35 any = tmp4.Invoke_O_O__O(tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp11, tmp13, tmp23, tmp25, lang.Tuple_Create_O_O_O__IPersistentVector(tmp29, tmp33, lang.Tuple_Create_O_O__IPersistentVector(Lit_240, tmp34))))); var tmp36 any; var t__7 any = t.F_P; t.F_P = nil; tmp36 = t__7; var tmp37 any = tmp36; var tmp38 any; var t__8 any = t.F_o; t.F_o = nil; tmp38 = t__8; return tmp2.Invoke_O_O_O__O(tmp35, tmp37, tmp38)
}



func A_arbace_box_build_build_package_iter__598000203__598000207_A_New() *A_arbace_box_build_build_package_iter__598000203__598000207_A { A_arbace_box_build_build_package_iter__598000203__598000207_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ctor() {}
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Invoke_O_O__O(self, s__598000204__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(self, s__598000204__1); var tmp2 *jrt.Class; A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_Init(); tmp2 = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ctor_O_O(c__iter__598000203, c__s__598000204 any) { t.F_iter__598000203 = c__iter__598000203; t.F_s__598000204 = c__s__598000204 }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Invoke_O__O(self any) any { { var s__598000204__1 any; var t_ any = t.F_s__598000204; t.F_s__598000204 = nil; s__598000204__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000204__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000204__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000204__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000204__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000206__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000206__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(b__598000206__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_Init(); tmp6 = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000206__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000204__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000206__6), nil) } } else { var vec__598000214__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; vec__598000214__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000204__3); var o__5 any = lang.RT_Nth_O_I_O__O(vec__598000214__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__598000214__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_133; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_134; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_7; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp20.Invoke_O__O(tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(f__6)))); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp26 *lang.Var; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__598000204__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ctor_O_I_O(c__b__598000206 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000206 = c__b__598000206; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Invoke_O__O(self any) any { { var i__598000205__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000205__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000210__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000205__1)); var o__3 any = lang.RT_Nth_O_I_O__O(vec__598000210__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__598000210__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000206; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_133; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_134; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_7; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp6.Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(f__4))))); i__598000205__1 = lang.Numbers_Unchecked_inc_J__J(i__598000205__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_read_plan_A_New() *A_arbace_box_build_read_plan_A { A_arbace_box_build_read_plan_A_Init(); t := &A_arbace_box_build_read_plan_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Ctor() {}
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Invoke_O_O__O(self, plan__0 any) any {
	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(plan__0)) { return plan__0 } else { var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_163; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_164; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(tmp4, plan__0)) {
		var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_33; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_72; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(plan__0)) } else {
//line :277:1
			var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_111; if tmp8 != nil {

				var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_33; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; var or__1927000174__auto____2 any; var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_165; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(plan__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp11 = or__1927000174__auto____2 } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_67; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_338, nil), jrt.RefArrayOf(jrt.Object_class, nil, plan__0)).Ref(); var tmp16 *lang.Keyword; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_166; tmp11 = tmp14.Invoke_O_O__O(tmp15, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16.Ref(), plan__0))) }; return tmp10.Invoke_O__O(tmp11) } else {
//line :277:1
					return nil
				}
		}
	} }
func A_arbace_box_build_with_tools_A_New() *A_arbace_box_build_with_tools_A { A_arbace_box_build_with_tools_A_Init(); t := &A_arbace_box_build_with_tools_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Ctor() {}
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Invoke_O_O_O__O(self, p__0, opts__1 any) any { var arch__3 any; var tmp1 *lang.Keyword;


	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_85; arch__3 = jrt.NN(tmp1).Invoke_O__O(p__0); var tools__4 any; var tmp2 /*line :281:1*/*lang.Var;



	A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_123; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_21; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 any; var iter__1927001039__auto____4 any; var tmp9 any = A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(arch__3); var tmp10 *jrt.Class; A_arbace_box_build_with_tools_iter__598000221__598000225_A_Init(); tmp10 = A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp12 any; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_168; tmp8 = tmp11.Invoke_O__O(tmp12); var tmp13 any = tmp5.Invoke_O_O__O(tmp7, tmp8); var tmp14 *lang.Keyword; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_120; tools__4 = tmp3.Invoke_O_O__O(tmp13, jrt.NN(tmp14).Invoke_O__O(opts__1)); var seq_598000231__5 any; var tmp15 /*line :281:1*/*lang.Var;






	A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_15; seq_598000231__5 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(tools__4); var chunk_598000232__6 any; var count_598000233__7 int64 = 0; var i_598000234__8 int64 = 0; L1:
//line :281:1
	for {






		if lang.Numbers_Lt_J_J__Z(i_598000234__8, count_598000233__7) { var vec__598000235__9 any = lang.Indexed_Cast(chunk_598000232__6).Nth_I__O(lang.RT_IntCast_J__I(i_598000234__8)); var t__10 any = lang.RT_Nth_O_I_O__O(vec__598000235__9, lang.RT_IntCast_J__I(0), nil); var h__11 any = lang.RT_Nth_O_I_O__O(vec__598000235__9, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(h__11) { } else { var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_67; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_167; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(t__10); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_167; var tmp22 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, nil, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(t__10), nil, arch__3, nil)).Ref(); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; tmp17.Invoke_O_O__O(tmp22, tmp23.Ref()) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = seq_598000231__5, chunk_598000232__6, count_598000233__7, lang.Numbers_Unchecked_inc_J__J(i_598000234__8); continue L1 } else { var temp__1927000414__auto____9 any; var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_15; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_598000231__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_598000231__10 any = temp__1927000414__auto____9; var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_598000231__10)) { var c__1927000678__auto____11 any; var tmp26 *lang.Var; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_17; c__1927000678__auto____11 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_598000231__10); var tmp27 *lang.Var; A_arbace_box_build_A_Init(); tmp27 = A_arbace_box_build_A_const_19; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_598000231__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__598000238__11 any; var tmp28 *lang.Var; A_arbace_box_build_A_Init(); tmp28 = A_arbace_box_build_A_const_18; vec__598000238__11 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_598000231__10); var t__12 any = lang.RT_Nth_O_I_O__O(vec__598000238__11, lang.RT_IntCast_J__I(0), nil); var h__13 any = lang.RT_Nth_O_I_O__O(vec__598000238__11, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(h__13) { } else { var tmp29 *lang.Var; A_arbace_box_build_A_Init(); tmp29 = A_arbace_box_build_A_const_67; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp32 *lang.Var; A_arbace_box_build_A_Init(); tmp32 = A_arbace_box_build_A_const_167; var tmp33 any = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(t__12); var tmp34 *lang.Var; A_arbace_box_build_A_Init(); tmp34 = A_arbace_box_build_A_const_167; var tmp35 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp33, nil, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(t__12), nil, arch__3, nil)).Ref(); var tmp36 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp36 = lang.PersistentArrayMap_EMPTY; tmp30.Invoke_O_O__O(tmp35, tmp36.Ref()) }; var tmp37 *lang.Var; A_arbace_box_build_A_Init(); tmp37 = A_arbace_box_build_A_const_20; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_598000231__10), nil, 0, 0; continue L1 } } }
//line :281:1
		break L1 }; var tmp38 /*line :289:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp38 = A_arbace_box_build_A_const_12; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Keyword; A_arbace_box_build_A_Init(); tmp40 = A_arbace_box_build_A_const_120; return tmp39.Invoke_O_O_O__O(opts__1, tmp40.Ref(), tools__4) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(p0 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { A_arbace_box_build_with_tools_iter__598000221__598000225_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ctor_O(c__arch any) { t.F_arch = c__arch }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Invoke_O_O__O(self, s__598000222__1 any) any { var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(s__598000222__1, t.F_arch, self); var tmp2 *jrt.Class; A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_Init(); tmp2 = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ctor_O_O_O(c__s__598000222, c__arch, c__iter__598000221 any) { t.F_s__598000222 = c__s__598000222; t.F_arch = c__arch; t.F_iter__598000221 = c__iter__598000221 }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Invoke_O__O(self any) any { { var s__598000222__1 any; var t_ any = t.F_s__598000222; t.F_s__598000222 = nil; s__598000222__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000222__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000222__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000222__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000222__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000224__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000224__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(b__598000224__6, t.F_arch, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_Init(); tmp6 = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000224__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000222__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000224__6), nil) } } else { var t__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; t__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000222__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_61; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_353, nil, Lit_354, nil); var tmp22 *lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_167; var tmp23 any = lang.Tuple_Create_O_O__IPersistentVector(t__4, tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(t__4), nil, t.F_arch)).Ref())); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__598000222__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ctor_O_O_I_O(c__b__598000224, c__arch any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000224 = c__b__598000224; t.F_arch = c__arch; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Invoke_O__O(self any) any { { var i__598000223__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000223__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000223__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000224; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_61; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_353, nil, Lit_354, nil); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_167; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(t__2, tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(t__2), nil, t.F_arch)).Ref()))); i__598000223__1 = lang.Numbers_Unchecked_inc_J__J(i__598000223__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_box_build_archives_A_New() *A_arbace_box_build_archives_A { A_arbace_box_build_archives_A_Init(); t := &A_arbace_box_build_archives_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_box_build_archives_A) Ctor() {}
//line :291:1
func (t *A_arbace_box_build_archives_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var tmp1 *lang.Var;




	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_169; p__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(plan__0); var opts__4 any; var tmp2 /*line :291:1*/*lang.Var;





	A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_170; opts__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p__3, opts__1); var pkgs__5 any; var tmp3 /*line :291:1*/*lang.Keyword;






	A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_40; pkgs__5 = jrt.NN(tmp3).Invoke_O__O(p__3); var index__6 any; var tmp4 /*line :291:1*/*lang.Var;







	A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_21; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_174; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_box_build_archives_fn__598000242_A_New(); var tmp11 *jrt.Class; A_arbace_box_build_archives_fn__598000242_A_Init(); tmp11 = A_arbace_box_build_archives_fn__598000242_A_fn_class; index__6 = tmp5.Invoke_O_O__O(tmp7, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), pkgs__5)); var given__7 any; var tmp12 /*line :291:1*/*lang.Keyword;








	A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_171; given__7 = jrt.NN(tmp12).Invoke_O__O(opts__4); var only__8 any; var tmp13 /*line :291:1*/*lang.Keyword;









	A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_172; only__8 = jrt.NN(tmp13).Invoke_O__O(opts__4); var futures__9 any; var tmp14 /*line :291:1*/*lang.Var;











	A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_34; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp16 = lang.PersistentArrayMap_EMPTY; futures__9 = tmp15.Invoke_O__O(tmp16.Ref()); var sem__10 any; var tmp17 /*line :291:1*/*lang.Keyword; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_173; var tmp18 lang.IFn = Up_Keyword_IFn(tmp17); var tmp19 any; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_175; sem__10 = jrt.Semaphore_New_I(lang.RT_IntCast_O__I(tmp18.Invoke_O_O__O(opts__4, tmp19))); var conveyed__11 any; var tmp20 any = A_arbace_box_build_archives_conveyed__598000244_A_New_O(opts__4); var tmp21 *jrt.Class;













	A_arbace_box_build_archives_conveyed__598000244_A_Init(); tmp21 = A_arbace_box_build_archives_conveyed__598000244_A_fn_class; conveyed__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp22 /*line :306:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_81; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_box_build_A_Init(); tmp24 = A_arbace_box_build_A_const_82; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_box_build_A_Init(); tmp26 = A_arbace_box_build_A_const_49; tmp23.Invoke_O__O(tmp25.Invoke_O_O__O(tmp26.Ref(), opts__4)); var tmp27 any; tmp90 := /*line :291:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_598000248__14 any; var tmp28 *lang.Var















		A_arbace_box_build_A_Init(); tmp28 = A_arbace_box_build_A_const_15; seq_598000248__14 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(pkgs__5)
//line :291:1
		var chunk_598000249__15 any; var count_598000250__16 int64 = 0; var i_598000251__17 int64 = 0; L1: for {















			if lang.Numbers_Lt_J_J__Z(i_598000251__17, count_598000250__16) { var q__18 any = lang.Indexed_Cast(chunk_598000249__15).Nth_I__O(lang.RT_IntCast_J__I(i_598000251__17)); var deps__19 any; var tmp29 *lang.Var
				A_arbace_box_build_A_Init(); tmp29 = A_arbace_box_build_A_const_108; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_box_build_A_Init(); tmp31 = A_arbace_box_build_A_const_7; var tmp32 any = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(futures__9); var tmp33 *lang.Keyword; A_arbace_box_build_A_Init(); tmp33 = A_arbace_box_build_A_const_121; deps__19 = tmp30.Invoke_O_O__O(tmp32, jrt.NN(tmp33).Invoke_O__O(q__18))
				var tmp34 *lang.Var; A_arbace_box_build_A_Init(); tmp34 = A_arbace_box_build_A_const_36; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_box_build_A_Init(); tmp36 = A_arbace_box_build_A_const_12; var tmp37 any = jrt.NN(tmp36).GetRawRoot__O(); var tmp38 *lang.Keyword; A_arbace_box_build_A_Init(); tmp38 = A_arbace_box_build_A_const_91; var tmp39 any = jrt.NN(tmp38).Invoke_O__O(q__18); var tmp40 any; var tmp41 any; var and__1927000168__auto____20 any = only__8
				if jrt.A2g_Truth(and__1927000168__auto____20) { var tmp42 *lang.Var; A_arbace_box_build_A_Init(); tmp42 = A_arbace_box_build_A_const_68; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 lang.IFn = lang.IFn_Cast(only__8); var tmp45 *lang.Keyword; A_arbace_box_build_A_Init(); tmp45 = A_arbace_box_build_A_const_91; tmp41 = tmp43.Invoke_O__O(tmp44.Invoke_O__O(jrt.NN(tmp45).Invoke_O__O(q__18))) } else { tmp41 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp41) { var tmp46 any = A_arbace_box_build_archives_fn__598000252_A_New_O_O(given__7, q__18); var tmp47 *jrt.Class; A_arbace_box_build_archives_fn__598000252_A_Init(); tmp47 = A_arbace_box_build_archives_fn__598000252_A_fn_class; tmp40 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil)) } else {

					var tmp48 *lang.Var; A_arbace_box_build_A_Init(); tmp48 = A_arbace_box_build_A_const_161; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any = A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(index__6, p__3, deps__19, sem__10, conveyed__11, q__18); var tmp51 *jrt.Class; A_arbace_box_build_archives_fn__598000254_A_Init(); tmp51 = A_arbace_box_build_archives_fn__598000254_A_fn_class; tmp40 = tmp49.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil)) }
//line :309:1
				tmp35.Invoke_O_O_O_O__O(futures__9, tmp37, tmp39, tmp40)
//line :307:1
				seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = seq_598000248__14, chunk_598000249__15, count_598000250__16, lang.Numbers_Unchecked_inc_J__J(i_598000251__17); continue L1 } else { var temp__1927000414__auto____18 any; var tmp52 *lang.Var; A_arbace_box_build_A_Init(); tmp52 = A_arbace_box_build_A_const_15; temp__1927000414__auto____18 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq_598000248__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_598000248__19 any = temp__1927000414__auto____18; var tmp53 *lang.Var; A_arbace_box_build_A_Init(); tmp53 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_598000248__19)) { var c__1927000678__auto____20 any; var tmp54 *lang.Var; A_arbace_box_build_A_Init(); tmp54 = A_arbace_box_build_A_const_17; c__1927000678__auto____20 = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq_598000248__19); var tmp55 *lang.Var; A_arbace_box_build_A_Init(); tmp55 = A_arbace_box_build_A_const_19; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq_598000248__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var q__20 any; var tmp56 *lang.Var; A_arbace_box_build_A_Init(); tmp56 = A_arbace_box_build_A_const_18; q__20 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(seq_598000248__19); var deps__21 any; var tmp57 *lang.Var
					A_arbace_box_build_A_Init(); tmp57 = A_arbace_box_build_A_const_108; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_box_build_A_Init(); tmp59 = A_arbace_box_build_A_const_7; var tmp60 any = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(futures__9); var tmp61 *lang.Keyword; A_arbace_box_build_A_Init(); tmp61 = A_arbace_box_build_A_const_121; deps__21 = tmp58.Invoke_O_O__O(tmp60, jrt.NN(tmp61).Invoke_O__O(q__20))
					var tmp62 *lang.Var; A_arbace_box_build_A_Init(); tmp62 = A_arbace_box_build_A_const_36; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_box_build_A_Init(); tmp64 = A_arbace_box_build_A_const_12; var tmp65 any = jrt.NN(tmp64).GetRawRoot__O(); var tmp66 *lang.Keyword; A_arbace_box_build_A_Init(); tmp66 = A_arbace_box_build_A_const_91; var tmp67 any = jrt.NN(tmp66).Invoke_O__O(q__20); var tmp68 any; var tmp69 any; var and__1927000168__auto____22 any = only__8
					if jrt.A2g_Truth(and__1927000168__auto____22) { var tmp70 *lang.Var; A_arbace_box_build_A_Init(); tmp70 = A_arbace_box_build_A_const_68; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 lang.IFn = lang.IFn_Cast(only__8); var tmp73 *lang.Keyword; A_arbace_box_build_A_Init(); tmp73 = A_arbace_box_build_A_const_91; tmp69 = tmp71.Invoke_O__O(tmp72.Invoke_O__O(jrt.NN(tmp73).Invoke_O__O(q__20))) } else { tmp69 = and__1927000168__auto____22 }; if jrt.A2g_Truth(tmp69) { var tmp74 any = A_arbace_box_build_archives_fn__598000260_A_New_O_O(given__7, q__20); var tmp75 *jrt.Class; A_arbace_box_build_archives_fn__598000260_A_Init(); tmp75 = A_arbace_box_build_archives_fn__598000260_A_fn_class; tmp68 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp74, tmp75, nil)) } else {

						var tmp76 *lang.Var; A_arbace_box_build_A_Init(); tmp76 = A_arbace_box_build_A_const_161; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 any = A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(index__6, p__3, deps__21, sem__10, conveyed__11, q__20); var tmp79 *jrt.Class; A_arbace_box_build_archives_fn__598000262_A_Init(); tmp79 = A_arbace_box_build_archives_fn__598000262_A_fn_class; tmp68 = tmp77.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp78, tmp79, nil)) }
//line :309:1
					tmp63.Invoke_O_O_O_O__O(futures__9, tmp65, tmp67, tmp68)
//line :307:1
					var tmp80 *lang.Var; A_arbace_box_build_A_Init(); tmp80 = A_arbace_box_build_A_const_20; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_598000248__19), nil, 0, 0; continue L1 } } }
//line :291:1
			break L1
		}



























		var tmp81 *lang.Var; A_arbace_box_build_A_Init(); tmp81 = A_arbace_box_build_A_const_21; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp83 = lang.PersistentArrayMap_EMPTY; var tmp84 any = tmp83.Ref(); var tmp85 any; var iter__1927001039__auto____14 any; var tmp86 any = A_arbace_box_build_archives_iter__598000268__598000272_A_New(); var tmp87 *jrt.Class; A_arbace_box_build_archives_iter__598000268__598000272_A_Init(); tmp87 = A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp86, tmp87, nil); var tmp88 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp89 *lang.Var; A_arbace_box_build_A_Init(); tmp89 = A_arbace_box_build_A_const_7; tmp85 = tmp88.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()).Invoke_O__O(futures__9)); tmp27 = tmp82.Invoke_O_O__O(tmp84, tmp85) }; return nil }(); var tmp91 /*line :291:1*/*lang.Var;














	A_arbace_box_build_A_Init(); tmp91 = A_arbace_box_build_A_const_80; lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()).Invoke__O(); if /*line :291:1*/ tmp90 != nil { panic(tmp90) }; return tmp27 }







func A_arbace_box_build_archives_fn__598000242_A_New() *A_arbace_box_build_archives_fn__598000242_A { A_arbace_box_build_archives_fn__598000242_A_Init(); t := &A_arbace_box_build_archives_fn__598000242_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Ctor() {}
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { var tmp1 *lang.Keyword; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_91; return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp1).Invoke_O__O(q__2), i__1) }





func A_arbace_box_build_archives_conveyed__598000244_A_New_O(p0 any) *A_arbace_box_build_archives_conveyed__598000244_A { A_arbace_box_build_archives_conveyed__598000244_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Invoke_O_O__O(self, f__1 any) any { var o__2 any = t.F_opts; var tmp1 any = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(f__1, o__2); var tmp2 *jrt.Class; A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_Init(); tmp2 = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :305:1
func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ctor_O_O(c__f, c__o any) { t.F_f = c__f; t.F_o = c__o }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_81; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_82; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_49; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), t.F_o)); var tmp6 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp6 = lang.IFn_Cast(t.F_f).Invoke__O(); return nil }(); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_80; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp6 }





func A_arbace_box_build_archives_fn__598000252_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000252_A { A_arbace_box_build_archives_fn__598000252_A_Init(); t := &A_arbace_box_build_archives_fn__598000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; var tmp2 any = tmp1; var tmp3 *lang.Keyword; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_91; or__1927000174__auto____1 = lang.RT_Get_O_O__O(tmp2, jrt.NN(tmp3).Invoke_O__O(t.F_q)); if jrt.A2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_67; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_210, nil); var tmp7 *lang.Keyword; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_91; var tmp8 *lang.Keyword = tmp7; var tmp9 any; var t__2 any = t.F_q; t.F_q = nil; tmp9 = t__2; var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp8).Invoke_O__O(tmp9))).Ref(); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; return tmp5.Invoke_O_O__O(tmp10, tmp11.Ref()) } }
//line :311:1
func A_arbace_box_build_archives_fn__598000260_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000260_A { A_arbace_box_build_archives_fn__598000260_A_Init(); t := &A_arbace_box_build_archives_fn__598000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; var tmp2 any = tmp1; var tmp3 *lang.Keyword; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_91; or__1927000174__auto____1 = lang.RT_Get_O_O__O(tmp2, jrt.NN(tmp3).Invoke_O__O(t.F_q)); if jrt.A2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_67; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_210, nil); var tmp7 *lang.Keyword; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_91; var tmp8 *lang.Keyword = tmp7; var tmp9 any; var t__2 any = t.F_q; t.F_q = nil; tmp9 = t__2; var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp8).Invoke_O__O(tmp9))).Ref(); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; return tmp5.Invoke_O_O__O(tmp10, tmp11.Ref()) } }
func A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000254_A { A_arbace_box_build_archives_fn__598000254_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; A_arbace_box_build_archives_fn__598000254_fn__598000255_A_Init(); tmp4 = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class; return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
//line :312:1
func A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000262_A { A_arbace_box_build_archives_fn__598000262_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; A_arbace_box_build_archives_fn__598000262_fn__598000263_A_Init(); tmp4 = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class; return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { A_arbace_box_build_archives_fn__598000254_fn__598000255_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Invoke_O__O(self any) any { var archives__1 any; var tmp1 *lang.Var;
												A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_108; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New(); var tmp8 *jrt.Class; A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_Init(); tmp8 = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_121; archives__1 = tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(t.F_q), t.F_deps));
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp11 any; tmp13 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_176; tmp11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_p, t.F_q, archives__1, t.F_index) }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp13 != nil { panic(tmp13) }; return tmp11 }
//line :314:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { A_arbace_box_build_archives_fn__598000262_fn__598000263_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Invoke_O__O(self any) any { var archives__1 any; var tmp1 *lang.Var;
												A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_108; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New(); var tmp8 *jrt.Class; A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_Init(); tmp8 = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Keyword; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_121; archives__1 = tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp9, jrt.NN(tmp10).Invoke_O__O(t.F_q), t.F_deps));
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp11 any; tmp13 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_176; tmp11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_p, t.F_q, archives__1, t.F_index) }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp13 != nil { panic(tmp13) }; return tmp11 }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New() *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_7; return lang.Tuple_Create_O_O__IPersistentVector(i__1, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__2)) }
//line :315:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New() *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_7; return lang.Tuple_Create_O_O__IPersistentVector(i__1, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__2)) }




func A_arbace_box_build_archives_iter__598000268__598000272_A_New() *A_arbace_box_build_archives_iter__598000268__598000272_A { A_arbace_box_build_archives_iter__598000268__598000272_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ctor() {}
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Invoke_O_O__O(self, s__598000269__1 any) any { var tmp1 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(self, s__598000269__1); var tmp2 *jrt.Class; A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_Init(); tmp2 = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ctor_O_O(c__iter__598000268, c__s__598000269 any) { t.F_iter__598000268 = c__iter__598000268; t.F_s__598000269 = c__s__598000269 }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Invoke_O__O(self any) any { { var s__598000269__1 any; var t_ any = t.F_s__598000269; t.F_s__598000269 = nil; s__598000269__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000269__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000269__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000269__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000269__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000271__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000271__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(b__598000271__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_Init(); tmp6 = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000271__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000269__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000271__6), nil) } } else { var vec__598000279__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; vec__598000279__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000269__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__598000279__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__598000279__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_box_build_A_Init(); tmp19 = A_arbace_box_build_A_const_7; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(f__6)); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp22 *lang.Var; A_arbace_box_build_A_Init(); tmp22 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__598000269__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ctor_O_I_O(c__b__598000271 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000271 = c__b__598000271; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Invoke_O__O(self any) any { { var i__598000270__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000275__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__598000275__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000271; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_7; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__4))); i__598000270__1 = lang.Numbers_Unchecked_inc_J__J(i__598000270__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_link_A_New() *A_arbace_box_build_link_A { A_arbace_box_build_link_A_Init(); t := &A_arbace_box_build_link_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_build_link_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_build_link_A) Invoke_O_O_O_O__O(self, plan__0, archives__1, opts__2 any) any { var p__4 any; var tmp1 *lang.Var;




	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_169; p__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(plan__0); var opts__5 any; var tmp2 /*line :322:1*/*lang.Var;





	A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_170; opts__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p__4, opts__2); var pkgs__6 any; var tmp3 /*line :322:1*/*lang.Keyword;






	A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_40; pkgs__6 = jrt.NN(tmp3).Invoke_O__O(p__4); var index__7 any; var tmp4 /*line :322:1*/*lang.Var;







	A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_21; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_174; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_box_build_link_fn__598000285_A_New(); var tmp11 *jrt.Class; A_arbace_box_build_link_fn__598000285_A_Init(); tmp11 = A_arbace_box_build_link_fn__598000285_A_fn_class; index__7 = tmp5.Invoke_O_O__O(tmp7, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), pkgs__6)); var tmp12 /*line :331:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_81; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_box_build_A_Init(); tmp14 = A_arbace_box_build_A_const_82; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_49; tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16.Ref(), opts__5)); var tmp17 any; tmp80 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var paths__10 any; var tmp18 *lang.Var









		A_arbace_box_build_A_Init(); tmp18 = A_arbace_box_build_A_const_108; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_box_build_A_Init(); tmp20 = A_arbace_box_build_A_const_91; paths__10 = tmp19.Invoke_O_O__O(tmp20.Ref(), pkgs__6)
//line :322:1
		var vec__598000287__11 any; var tmp21 *lang.Var










		A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_122; vec__598000287__11 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O_O__O(archives__1, index__7, paths__10)
//line :322:1
		var dtree__12 any = lang.RT_Nth_O_I_O__O(vec__598000287__11, lang.RT_IntCast_J__I(0), nil); var lines__13 any = lang.RT_Nth_O_I_O__O(vec__598000287__11, lang.RT_IntCast_J__I(1), nil); var cfg__14 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_235, nil); var tmp23 *lang.Var











		A_arbace_box_build_A_Init(); tmp23 = A_arbace_box_build_A_const_51; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_box_build_A_Init(); tmp25 = A_arbace_box_build_A_const_14; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 any; var iter__1927001039__auto____16 any; var tmp28 any = A_arbace_box_build_link_iter__598000290__598000294_A_New(); var tmp29 *jrt.Class; A_arbace_box_build_link_iter__598000290__598000294_A_Init(); tmp29 = A_arbace_box_build_link_iter__598000290__598000294_A_fn_class; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lines__13); cfg__14 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp24.Invoke_O_O__O(tmp26, tmp27))).Ref()
//line :322:1
		var res__15 any; var tmp30 *lang.Var












		A_arbace_box_build_A_Init(); tmp30 = A_arbace_box_build_A_const_79; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_325); var tmp33 *lang.Keyword; A_arbace_box_build_A_Init(); tmp33 = A_arbace_box_build_A_const_177; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp32, jrt.RefArrayOf(jrt.Object_class, jrt.NN(tmp33).Invoke_O__O(p__4), nil)).Ref(); var tmp35 *lang.Var; A_arbace_box_build_A_Init(); tmp35 = A_arbace_box_build_A_const_123; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Keyword; A_arbace_box_build_A_Init(); tmp37 = A_arbace_box_build_A_const_141; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_box_build_A_Init(); tmp39 = A_arbace_box_build_A_const_178; var tmp40 *lang.Keyword = tmp39; var tmp41 *lang.Keyword; A_arbace_box_build_A_Init(); tmp41 = A_arbace_box_build_A_const_120; var tmp42 any = jrt.NN(tmp40).Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(opts__5)); var tmp43 *lang.Keyword; A_arbace_box_build_A_Init(); tmp43 = A_arbace_box_build_A_const_78; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Var; A_arbace_box_build_A_Init(); tmp45 = A_arbace_box_build_A_const_90; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_box_build_A_Init(); tmp47 = A_arbace_box_build_A_const_86; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; A_arbace_box_build_A_Init(); tmp49 = A_arbace_box_build_A_const_180; var tmp50 any = tmp49; var tmp51 *lang.Keyword; A_arbace_box_build_A_Init(); tmp51 = A_arbace_box_build_A_const_181; var tmp52 lang.IFn = Up_Keyword_IFn(tmp51); var tmp53 any; A_arbace_box_build_A_Init(); tmp53 = A_arbace_box_build_A_const_182; var tmp54 any = tmp52.Invoke_O_O__O(opts__5, tmp53); var tmp55 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_326, nil, Lit_281); var tmp56 lang.IFn = lang.IFn_Cast(index__7); var tmp57 *lang.Keyword; A_arbace_box_build_A_Init(); tmp57 = A_arbace_box_build_A_const_177; var tmp58 any = tmp46.Invoke_O__O(tmp48.Invoke_O_O_O__O(tmp50, tmp54, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp55, jrt.RefArrayOf(jrt.Object_class, nil, tmp56.Invoke_O__O(jrt.NN(tmp57).Invoke_O__O(p__4)), nil)).Ref()))); var tmp59 *lang.Keyword; A_arbace_box_build_A_Init(); tmp59 = A_arbace_box_build_A_const_143; var tmp60 any = tmp59.Ref(); var tmp61 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_244, dtree__12); var tmp62 *lang.Var; A_arbace_box_build_A_Init(); tmp62 = A_arbace_box_build_A_const_145; var tmp63 any = lang.Tuple_Create_O_O__IPersistentVector(tmp61, lang.Tuple_Create_O_O__IPersistentVector(Lit_240, lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_327, cfg__14))))); var tmp64 *lang.Keyword; A_arbace_box_build_A_Init(); tmp64 = A_arbace_box_build_A_const_84; var tmp65 any = tmp64.Ref(); var tmp66 *lang.Keyword; A_arbace_box_build_A_Init(); tmp66 = A_arbace_box_build_A_const_179; var tmp67 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38, tmp42, tmp44, tmp58, tmp60, tmp63, tmp65, Lit_115, tmp66.Ref(), Lit_115)); var tmp68 *lang.Var; A_arbace_box_build_A_Init(); tmp68 = A_arbace_box_build_A_const_148; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Keyword; A_arbace_box_build_A_Init(); tmp70 = A_arbace_box_build_A_const_125; var tmp71 any = jrt.NN(tmp70).Invoke_O__O(opts__5); var tmp72 *lang.Keyword; A_arbace_box_build_A_Init(); tmp72 = A_arbace_box_build_A_const_178; var tmp73 any = lang.RT_Get_O_O__O(tmp71, tmp72.Ref()); var tmp74 any; A_arbace_box_build_A_Init(); tmp74 = A_arbace_box_build_A_const_183; res__15 = tmp31.Invoke_O_O__O(tmp34, tmp36.Invoke_O_O__O(tmp67, tmp69.Invoke_O_O__O(tmp73, tmp74)))








		var tmp75 *lang.Var; A_arbace_box_build_A_Init(); tmp75 = A_arbace_box_build_A_const_134; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_box_build_A_Init(); tmp77 = A_arbace_box_build_A_const_131; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Keyword; A_arbace_box_build_A_Init(); tmp79 = A_arbace_box_build_A_const_177; tmp17 = tmp76.Invoke_O__O(tmp78.Invoke_O_O_O__O(res__15, jrt.NN(tmp79).Invoke_O__O(p__4), Lit_328)) }; return nil }(); var tmp81 /*line :322:1*/*lang.Var;








	A_arbace_box_build_A_Init(); tmp81 = A_arbace_box_build_A_const_80; lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke__O(); if /*line :322:1*/ tmp80 != nil { panic(tmp80) }; return tmp17 }







func A_arbace_box_build_link_fn__598000285_A_New() *A_arbace_box_build_link_fn__598000285_A { A_arbace_box_build_link_fn__598000285_A_Init(); t := &A_arbace_box_build_link_fn__598000285_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Ctor() {}
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { var tmp1 *lang.Keyword; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_91; return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp1).Invoke_O__O(q__2), i__1) }



func A_arbace_box_build_link_iter__598000290__598000294_A_New() *A_arbace_box_build_link_iter__598000290__598000294_A { A_arbace_box_build_link_iter__598000290__598000294_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ctor() {}
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Invoke_O_O__O(self, s__598000291__1 any) any { var tmp1 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(self, s__598000291__1); var tmp2 *jrt.Class; A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_Init(); tmp2 = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(p0, p1 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ctor_O_O(c__iter__598000290, c__s__598000291 any) { t.F_iter__598000290 = c__iter__598000290; t.F_s__598000291 = c__s__598000291 }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Invoke_O__O(self any) any { { var s__598000291__1 any; var t_ any = t.F_s__598000291; t.F_s__598000291 = nil; s__598000291__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__598000291__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000291__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__598000291__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_17; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__598000291__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000293__6 any; var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_23; b__598000293__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(b__598000293__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_Init(); tmp6 = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_build_A_Init(); tmp7 = A_arbace_box_build_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_build_A_Init(); tmp9 = A_arbace_box_build_A_const_30; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__598000293__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp12 *lang.Var; A_arbace_box_build_A_Init(); tmp12 = A_arbace_box_build_A_const_19; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__598000291__3))) } else { var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_28; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_build_A_Init(); tmp15 = A_arbace_box_build_A_const_30; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__598000293__6), nil) } } else { var l__4 any; var tmp16 *lang.Var; A_arbace_box_build_A_Init(); tmp16 = A_arbace_box_build_A_const_18; l__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__598000291__3); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp21 *lang.Var; A_arbace_box_build_A_Init(); tmp21 = A_arbace_box_build_A_const_31; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__598000291__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ctor_O_I_O(c__b__598000293 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000293 = c__b__598000293; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Invoke_O__O(self any) any { { var i__598000292__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000292__1)); var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__598000293; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref()); i__598000292__1 = lang.Numbers_Unchecked_inc_J__J(i__598000292__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }











func A_arbace_box_build_build_A_New() *A_arbace_box_build_build_A { A_arbace_box_build_build_A_Init(); t := &A_arbace_box_build_build_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_box_build_build_A) Ctor() {}
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var tmp1 *lang.Var;



	A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_169; p__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(plan__0); var t0__4 int64 = /*line :346:1*/jrt.System_NanoTime__J(); var as__5 any; var tmp2 *lang.Var;





	A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_184; as__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p__3, opts__1); var image__6 any; var tmp3 /*line :346:1*/*lang.Var;






	A_arbace_box_build_A_Init(); tmp3 = A_arbace_box_build_A_const_185; image__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(p__3, as__5, opts__1); var temp__1927000414__auto____7 any; var tmp4 /*line :346:1*/*lang.Keyword;







	A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_186; temp__1927000414__auto____7 = jrt.NN(tmp4).Invoke_O__O(opts__1); if jrt.A2g_Truth(temp__1927000414__auto____7) { var r__8 any = temp__1927000414__auto____7; var tmp5 *lang.Var; A_arbace_box_build_A_Init(); tmp5 = A_arbace_box_build_A_const_69; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(r__8, image__6) }; var tmp6 /*line :355:1*/*lang.Var; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_81; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_82; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_box_build_A_Init(); tmp10 = A_arbace_box_build_A_const_49; tmp7.Invoke_O__O(tmp9.Invoke_O_O__O(tmp10.Ref(), opts__1)); var tmp11 any = A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p__3, image__6, t0__4); var tmp12 *jrt.Class; A_arbace_box_build_build_fn__598000301_A_Init(); tmp12 = A_arbace_box_build_build_fn__598000301_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O(); return image__6 }
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O__O(self, plan__0 any) any {

	var tmp1 *lang.Var; A_arbace_box_build_A_Init(); tmp1 = A_arbace_box_build_A_const_187; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O__O(plan__0, tmp3.Ref())
}





func A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_box_build_build_fn__598000301_A { A_arbace_box_build_build_fn__598000301_A_Init(); t := &A_arbace_box_build_build_fn__598000301_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Ctor_O_O_J(c__p, c__image any, c__t0 int64) { t.F_p = c__p; t.F_image = c__image; t.F_t0 = c__t0 }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *lang.Var; A_arbace_box_build_A_Init(); tmp2 = A_arbace_box_build_A_const_70; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_box_build_A_Init(); tmp4 = A_arbace_box_build_A_const_77; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_box_build_A_Init(); tmp6 = A_arbace_box_build_A_const_177; var tmp7 any = jrt.NN(tmp6).Invoke_O__O(t.F_p); var tmp8 *lang.Keyword; A_arbace_box_build_A_Init(); tmp8 = A_arbace_box_build_A_const_40; var tmp9 *lang.Keyword = tmp8; var tmp10 any; var t_ any = t.F_p; t.F_p = nil; tmp10 = t_; var tmp11 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(jrt.NN(tmp9).Invoke_O__O(tmp10))).Ref(); var tmp12 any = t.F_image; var tmp13 *lang.Var; A_arbace_box_build_A_Init(); tmp13 = A_arbace_box_build_A_const_62; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var t__2 any = t.F_image; t.F_image = nil; tmp15 = t__2; tmp1 = tmp3.Invoke_O__O(tmp5.Invoke_O_O_O_O_O_O__O(Lit_233, tmp7, tmp11, tmp12, tmp14.Invoke_O__O(tmp15), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t.F_t0), 1.0e9)).Ref())) }
//line :355:1
	return nil }(); var tmp17 *lang.Var; A_arbace_box_build_A_Init(); tmp17 = A_arbace_box_build_A_const_80; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }


























































































































































































































































type A_arbace_box_build_A struct{ jrt.Object }

var A_arbace_box_build_A_const_0 *lang.Var

var A_arbace_box_build_A_const_1 *lang.Var

var A_arbace_box_build_A_const_2 any

var A_arbace_box_build_A_const_3 any

var A_arbace_box_build_A_const_4 any

var A_arbace_box_build_A_const_5 any

var A_arbace_box_build_A_const_6 *lang.Var

var A_arbace_box_build_A_const_7 *lang.Var

var A_arbace_box_build_A_const_8 *lang.Var

var A_arbace_box_build_A_const_9 any

var A_arbace_box_build_A_const_10 *lang.Var

var A_arbace_box_build_A_const_11 *lang.Var

var A_arbace_box_build_A_const_12 *lang.Var

var A_arbace_box_build_A_const_13 *lang.Keyword

var A_arbace_box_build_A_const_14 *lang.Var

var A_arbace_box_build_A_const_15 *lang.Var

var A_arbace_box_build_A_const_16 *lang.Var

var A_arbace_box_build_A_const_17 *lang.Var

var A_arbace_box_build_A_const_18 *lang.Var

var A_arbace_box_build_A_const_19 *lang.Var

var A_arbace_box_build_A_const_20 *lang.Var

var A_arbace_box_build_A_const_21 *lang.Var

var A_arbace_box_build_A_const_22 *lang.Var

var A_arbace_box_build_A_const_23 *lang.Var

var A_arbace_box_build_A_const_24 *lang.Var

var A_arbace_box_build_A_const_25 *lang.Var

var A_arbace_box_build_A_const_26 *lang.Keyword

var A_arbace_box_build_A_const_27 *lang.Var

var A_arbace_box_build_A_const_28 *lang.Var

var A_arbace_box_build_A_const_29 *lang.Var

var A_arbace_box_build_A_const_30 *lang.Var

var A_arbace_box_build_A_const_31 *lang.Var

var A_arbace_box_build_A_const_32 *lang.Var

var A_arbace_box_build_A_const_33 *lang.Var

var A_arbace_box_build_A_const_34 *lang.Var

var A_arbace_box_build_A_const_35 *lang.Var

var A_arbace_box_build_A_const_36 *lang.Var

var A_arbace_box_build_A_const_37 *lang.Var

var A_arbace_box_build_A_const_38 *lang.Var

var A_arbace_box_build_A_const_39 *lang.Var

var A_arbace_box_build_A_const_40 *lang.Keyword

var A_arbace_box_build_A_const_41 *lang.Var

var A_arbace_box_build_A_const_42 *lang.Var

var A_arbace_box_build_A_const_43 *lang.Keyword

var A_arbace_box_build_A_const_44 *lang.Keyword

var A_arbace_box_build_A_const_45 *lang.Var

var A_arbace_box_build_A_const_46 *lang.Var

var A_arbace_box_build_A_const_47 *lang.Var

var A_arbace_box_build_A_const_48 *lang.Keyword

var A_arbace_box_build_A_const_49 *lang.Var

var A_arbace_box_build_A_const_50 *lang.Var

var A_arbace_box_build_A_const_51 *lang.Var

var A_arbace_box_build_A_const_52 *lang.Var

var A_arbace_box_build_A_const_53 *lang.Var

var A_arbace_box_build_A_const_54 any

var A_arbace_box_build_A_const_55 any

var A_arbace_box_build_A_const_56 *lang.Var

var A_arbace_box_build_A_const_57 *lang.Keyword

var A_arbace_box_build_A_const_58 *lang.Keyword

var A_arbace_box_build_A_const_59 *lang.Var

var A_arbace_box_build_A_const_60 *lang.Keyword

var A_arbace_box_build_A_const_61 *lang.Var

var A_arbace_box_build_A_const_62 *lang.Var

var A_arbace_box_build_A_const_63 *lang.Var

var A_arbace_box_build_A_const_64 *lang.Keyword

var A_arbace_box_build_A_const_65 *lang.Var

var A_arbace_box_build_A_const_66 *lang.Keyword

var A_arbace_box_build_A_const_67 *lang.Var

var A_arbace_box_build_A_const_68 *lang.Var

var A_arbace_box_build_A_const_69 *lang.Var

var A_arbace_box_build_A_const_70 *lang.Var

var A_arbace_box_build_A_const_71 *lang.Keyword

var A_arbace_box_build_A_const_72 *lang.Var

var A_arbace_box_build_A_const_73 *lang.Keyword

var A_arbace_box_build_A_const_74 *lang.Keyword

var A_arbace_box_build_A_const_75 *lang.Keyword

var A_arbace_box_build_A_const_76 *lang.Keyword

var A_arbace_box_build_A_const_77 *lang.Var

var A_arbace_box_build_A_const_78 *lang.Keyword

var A_arbace_box_build_A_const_79 *lang.Var

var A_arbace_box_build_A_const_80 *lang.Var

var A_arbace_box_build_A_const_81 *lang.Var

var A_arbace_box_build_A_const_82 *lang.Var

var A_arbace_box_build_A_const_83 *lang.Var

var A_arbace_box_build_A_const_84 *lang.Keyword

var A_arbace_box_build_A_const_85 *lang.Keyword

var A_arbace_box_build_A_const_86 *lang.Var

var A_arbace_box_build_A_const_87 any

var A_arbace_box_build_A_const_88 *lang.Keyword

var A_arbace_box_build_A_const_89 *lang.Keyword

var A_arbace_box_build_A_const_90 *lang.Var

var A_arbace_box_build_A_const_91 *lang.Keyword

var A_arbace_box_build_A_const_92 *lang.Var

var A_arbace_box_build_A_const_93 *lang.Keyword

var A_arbace_box_build_A_const_94 any

var A_arbace_box_build_A_const_95 *lang.Var

var A_arbace_box_build_A_const_96 *lang.Var

var A_arbace_box_build_A_const_97 any

var A_arbace_box_build_A_const_98 any

var A_arbace_box_build_A_const_99 any

var A_arbace_box_build_A_const_100 any

var A_arbace_box_build_A_const_101 any

var A_arbace_box_build_A_const_102 any

var A_arbace_box_build_A_const_103 *lang.Var

var A_arbace_box_build_A_const_104 *lang.Var

var A_arbace_box_build_A_const_105 *lang.Var

var A_arbace_box_build_A_const_106 *lang.Keyword

var A_arbace_box_build_A_const_107 *lang.Var

var A_arbace_box_build_A_const_108 *lang.Var

var A_arbace_box_build_A_const_109 any

var A_arbace_box_build_A_const_110 any

var A_arbace_box_build_A_const_111 *lang.Keyword

var A_arbace_box_build_A_const_112 *lang.Var

var A_arbace_box_build_A_const_113 *lang.Var

var A_arbace_box_build_A_const_114 *lang.Var

var A_arbace_box_build_A_const_115 *lang.Var

var A_arbace_box_build_A_const_116 *lang.Var

var A_arbace_box_build_A_const_117 *lang.Var

var A_arbace_box_build_A_const_118 *lang.Var

var A_arbace_box_build_A_const_119 *lang.Var

var A_arbace_box_build_A_const_120 *lang.Keyword

var A_arbace_box_build_A_const_121 *lang.Keyword

var A_arbace_box_build_A_const_122 *lang.Var

var A_arbace_box_build_A_const_123 *lang.Var

var A_arbace_box_build_A_const_124 any

var A_arbace_box_build_A_const_125 *lang.Keyword

var A_arbace_box_build_A_const_126 *lang.Var

var A_arbace_box_build_A_const_127 *lang.Keyword

var A_arbace_box_build_A_const_128 *lang.Keyword

var A_arbace_box_build_A_const_129 *lang.Keyword

var A_arbace_box_build_A_const_130 *lang.Var

var A_arbace_box_build_A_const_131 *lang.Var

var A_arbace_box_build_A_const_132 *lang.Var

var A_arbace_box_build_A_const_133 *lang.Var

var A_arbace_box_build_A_const_134 *lang.Var

var A_arbace_box_build_A_const_135 *lang.Keyword

var A_arbace_box_build_A_const_136 *lang.Var

var A_arbace_box_build_A_const_137 *lang.Var

var A_arbace_box_build_A_const_138 *lang.Var

var A_arbace_box_build_A_const_139 *lang.Var

var A_arbace_box_build_A_const_140 *lang.Var

var A_arbace_box_build_A_const_141 *lang.Keyword

var A_arbace_box_build_A_const_142 *lang.Keyword

var A_arbace_box_build_A_const_143 *lang.Keyword

var A_arbace_box_build_A_const_144 *lang.Var

var A_arbace_box_build_A_const_145 *lang.Var

var A_arbace_box_build_A_const_146 any

var A_arbace_box_build_A_const_147 *lang.Keyword

var A_arbace_box_build_A_const_148 *lang.Var

var A_arbace_box_build_A_const_149 *lang.Keyword

var A_arbace_box_build_A_const_150 *lang.Keyword

var A_arbace_box_build_A_const_151 any

var A_arbace_box_build_A_const_152 *lang.Var

var A_arbace_box_build_A_const_153 any

var A_arbace_box_build_A_const_154 any

var A_arbace_box_build_A_const_155 any

var A_arbace_box_build_A_const_156 any

var A_arbace_box_build_A_const_157 any

var A_arbace_box_build_A_const_158 any

var A_arbace_box_build_A_const_159 *lang.Keyword

var A_arbace_box_build_A_const_160 any

var A_arbace_box_build_A_const_161 *lang.Var

var A_arbace_box_build_A_const_162 *lang.Var

var A_arbace_box_build_A_const_163 *lang.Var

var A_arbace_box_build_A_const_164 any

var A_arbace_box_build_A_const_165 *lang.Var

var A_arbace_box_build_A_const_166 *lang.Keyword

var A_arbace_box_build_A_const_167 *lang.Var

var A_arbace_box_build_A_const_168 any

var A_arbace_box_build_A_const_169 *lang.Var

var A_arbace_box_build_A_const_170 *lang.Var

var A_arbace_box_build_A_const_171 *lang.Keyword

var A_arbace_box_build_A_const_172 *lang.Keyword

var A_arbace_box_build_A_const_173 *lang.Keyword

var A_arbace_box_build_A_const_174 *lang.Var

var A_arbace_box_build_A_const_175 any

var A_arbace_box_build_A_const_176 *lang.Var

var A_arbace_box_build_A_const_177 *lang.Keyword

var A_arbace_box_build_A_const_178 *lang.Keyword

var A_arbace_box_build_A_const_179 *lang.Keyword

var A_arbace_box_build_A_const_180 any

var A_arbace_box_build_A_const_181 *lang.Keyword

var A_arbace_box_build_A_const_182 any

var A_arbace_box_build_A_const_183 any

var A_arbace_box_build_A_const_184 *lang.Var

var A_arbace_box_build_A_const_185 *lang.Var

var A_arbace_box_build_A_const_186 *lang.Keyword

var A_arbace_box_build_A_const_187 *lang.Var

var A_arbace_box_build_A_init jrt.ClassInit

func A_arbace_box_build_A_Init() { if !A_arbace_box_build_A_init.Done() { A_arbace_box_build_A_init.Run(A_arbace_box_build_A_clinit) } }

func A_arbace_box_build_A_clinit() { A_arbace_box_build_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_box_build_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_box_build_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_build_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_box_build_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_box_build_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_box_build_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_box_build_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_box_build_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_box_build_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_box_build_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_box_build_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_box_build_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_box_build_A_const_13 = lang.RT_Keyword_String_String__Keyword(Lit_13, Lit_19); A_arbace_box_build_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_box_build_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_box_build_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_box_build_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_box_build_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_box_build_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_box_build_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_box_build_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_box_build_A_const_22 = lang.RT_Var_String_String__Var(Lit_3, Lit_27); A_arbace_box_build_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_box_build_A_const_24 = lang.RT_Var_String_String__Var(Lit_8, Lit_29); A_arbace_box_build_A_const_25 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_box_build_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_box_build_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_box_build_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_box_build_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_box_build_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_box_build_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_box_build_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_box_build_A_const_33 = lang.RT_Var_String_String__Var(Lit_6, Lit_38); A_arbace_box_build_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_box_build_A_const_35 = lang.RT_Var_String_String__Var(Lit_13, Lit_40); A_arbace_box_build_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_box_build_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_box_build_A_const_38 = lang.RT_Var_String_String__Var(Lit_3, Lit_43); A_arbace_box_build_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_box_build_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_box_build_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_box_build_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_box_build_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_box_build_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_box_build_A_const_45 = lang.RT_Var_String_String__Var(Lit_3, Lit_50); A_arbace_box_build_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_box_build_A_const_47 = lang.RT_Var_String_String__Var(Lit_13, Lit_52); A_arbace_box_build_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_box_build_A_const_49 = lang.RT_Var_String_String__Var(Lit_13, Lit_54); A_arbace_box_build_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_box_build_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_box_build_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_box_build_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_58); A_arbace_box_build_A_const_54 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_box_build_A_const_55 = jrt.Long_ValueOf_J__Long(61).Ref(); A_arbace_box_build_A_const_56 = lang.RT_Var_String_String__Var(Lit_3, Lit_59); A_arbace_box_build_A_const_57 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_box_build_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_box_build_A_const_59 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); A_arbace_box_build_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_box_build_A_const_61 = lang.RT_Var_String_String__Var(Lit_3, Lit_64); A_arbace_box_build_A_const_62 = lang.RT_Var_String_String__Var(Lit_3, Lit_65); A_arbace_box_build_A_const_63 = lang.RT_Var_String_String__Var(Lit_3, Lit_66); A_arbace_box_build_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_box_build_A_const_65 = lang.RT_Var_String_String__Var(Lit_3, Lit_67); A_arbace_box_build_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_box_build_A_const_67 = lang.RT_Var_String_String__Var(Lit_13, Lit_69); A_arbace_box_build_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_box_build_A_const_69 = lang.RT_Var_String_String__Var(Lit_3, Lit_71); A_arbace_box_build_A_const_70 = lang.RT_Var_String_String__Var(Lit_13, Lit_53); A_arbace_box_build_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_box_build_A_const_72 = lang.RT_Var_String_String__Var(Lit_3, Lit_73); A_arbace_box_build_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_box_build_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_box_build_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_box_build_A_const_76 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_box_build_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_box_build_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_box_build_A_const_79 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); A_arbace_box_build_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_box_build_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_box_build_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_box_build_A_const_83 = lang.RT_Var_String_String__Var(Lit_3, Lit_83); A_arbace_box_build_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_box_build_A_const_85 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_box_build_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_box_build_A_const_87 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref()); A_arbace_box_build_A_const_88 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_box_build_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_box_build_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_box_build_A_const_91 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_box_build_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_box_build_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_box_build_A_const_94 = lang.Tuple_Create_O__IPersistentVector(Lit_93); A_arbace_box_build_A_const_95 = lang.RT_Var_String_String__Var(Lit_13, Lit_94); A_arbace_box_build_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_box_build_A_const_97 = jrt.Character_ValueOf_C__Character(32).Ref(); A_arbace_box_build_A_const_98 = jrt.Long_ValueOf_J__Long(16).Ref(); A_arbace_box_build_A_const_99 = jrt.Long_ValueOf_J__Long(12).Ref(); A_arbace_box_build_A_const_100 = jrt.Long_ValueOf_J__Long(6).Ref(); A_arbace_box_build_A_const_101 = jrt.Long_ValueOf_J__Long(8).Ref(); A_arbace_box_build_A_const_102 = jrt.Long_ValueOf_J__Long(10).Ref(); A_arbace_box_build_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_box_build_A_const_104 = lang.RT_Var_String_String__Var(Lit_13, Lit_97); A_arbace_box_build_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_box_build_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_99); A_arbace_box_build_A_const_107 = lang.RT_Var_String_String__Var(Lit_13, Lit_100); A_arbace_box_build_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_box_build_A_const_109 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_box_build_A_const_110 = jrt.Character_ValueOf_C__Character(92).Ref(); A_arbace_box_build_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_box_build_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_box_build_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_box_build_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_box_build_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_box_build_A_const_116 = lang.RT_Var_String_String__Var(Lit_13, Lit_107); A_arbace_box_build_A_const_117 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_box_build_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_box_build_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_box_build_A_const_120 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_box_build_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_box_build_A_const_122 = lang.RT_Var_String_String__Var(Lit_13, Lit_113); A_arbace_box_build_A_const_123 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_box_build_A_const_124 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_115, lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), Lit_117)); A_arbace_box_build_A_const_125 = lang.RT_Keyword_String_String__Keyword(nil, Lit_118); A_arbace_box_build_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_box_build_A_const_127 = lang.RT_Keyword_String_String__Keyword(nil, Lit_120); A_arbace_box_build_A_const_128 = lang.RT_Keyword_String_String__Keyword(nil, Lit_121); A_arbace_box_build_A_const_129 = lang.RT_Keyword_String_String__Keyword(nil, Lit_122); A_arbace_box_build_A_const_130 = lang.RT_Var_String_String__Var(Lit_13, Lit_123); A_arbace_box_build_A_const_131 = lang.RT_Var_String_String__Var(Lit_13, Lit_124); A_arbace_box_build_A_const_132 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_box_build_A_const_133 = lang.RT_Var_String_String__Var(Lit_3, Lit_126); A_arbace_box_build_A_const_134 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_box_build_A_const_135 = lang.RT_Keyword_String_String__Keyword(nil, Lit_128); A_arbace_box_build_A_const_136 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_box_build_A_const_137 = lang.RT_Var_String_String__Var(Lit_8, Lit_130); A_arbace_box_build_A_const_138 = lang.RT_Var_String_String__Var(Lit_0, Lit_131); A_arbace_box_build_A_const_139 = lang.RT_Var_String_String__Var(Lit_0, Lit_132); A_arbace_box_build_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_box_build_A_const_141 = lang.RT_Keyword_String_String__Keyword(nil, Lit_134); A_arbace_box_build_A_const_142 = lang.RT_Keyword_String_String__Keyword(nil, Lit_135); A_arbace_box_build_A_const_143 = lang.RT_Keyword_String_String__Keyword(nil, Lit_136); A_arbace_box_build_A_const_144 = lang.RT_Var_String_String__Var(Lit_13, Lit_137); A_arbace_box_build_A_const_145 = lang.RT_Var_String_String__Var(Lit_13, Lit_138); A_arbace_box_build_A_const_146 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_139, Lit_140)); A_arbace_box_build_A_const_147 = lang.RT_Keyword_String_String__Keyword(nil, Lit_141); A_arbace_box_build_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_box_build_A_const_149 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); A_arbace_box_build_A_const_150 = lang.RT_Keyword_String_String__Keyword(nil, Lit_144); A_arbace_box_build_A_const_151 = lang.Tuple_Create_O__IPersistentVector(Lit_93); A_arbace_box_build_A_const_152 = lang.RT_Var_String_String__Var(Lit_13, Lit_145); A_arbace_box_build_A_const_153 = lang.Tuple_Create_O__IPersistentVector(Lit_146); A_arbace_box_build_A_const_154 = lang.Tuple_Create_O_O__IPersistentVector(Lit_147, Lit_148); A_arbace_box_build_A_const_155 = lang.Tuple_Create_O_O__IPersistentVector(Lit_149, Lit_150); A_arbace_box_build_A_const_156 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_151, Lit_152, Lit_153, Lit_154, Lit_155); A_arbace_box_build_A_const_157 = lang.Tuple_Create_O_O__IPersistentVector(Lit_156, Lit_157); A_arbace_box_build_A_const_158 = lang.Tuple_Create_O_O__IPersistentVector(Lit_158, Lit_159); A_arbace_box_build_A_const_159 = lang.RT_Keyword_String_String__Keyword(nil, Lit_160); A_arbace_box_build_A_const_160 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_61).Ref()); A_arbace_box_build_A_const_161 = lang.RT_Var_String_String__Var(Lit_0, Lit_161); A_arbace_box_build_A_const_162 = lang.RT_Var_String_String__Var(Lit_13, Lit_162); A_arbace_box_build_A_const_163 = lang.RT_Var_String_String__Var(Lit_0, Lit_163); A_arbace_box_build_A_const_164 = jrt.Pattern_Compile_String__Pattern(Lit_164).Ref(); A_arbace_box_build_A_const_165 = lang.RT_Var_String_String__Var(Lit_3, Lit_165); A_arbace_box_build_A_const_166 = lang.RT_Keyword_String_String__Keyword(nil, Lit_166); A_arbace_box_build_A_const_167 = lang.RT_Var_String_String__Var(Lit_0, Lit_143); A_arbace_box_build_A_const_168 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_167).Ref()); A_arbace_box_build_A_const_169 = lang.RT_Var_String_String__Var(Lit_13, Lit_168); A_arbace_box_build_A_const_170 = lang.RT_Var_String_String__Var(Lit_13, Lit_169); A_arbace_box_build_A_const_171 = lang.RT_Keyword_String_String__Keyword(nil, Lit_170); A_arbace_box_build_A_const_172 = lang.RT_Keyword_String_String__Keyword(nil, Lit_171); A_arbace_box_build_A_const_173 = lang.RT_Keyword_String_String__Keyword(nil, Lit_172); A_arbace_box_build_A_const_174 = lang.RT_Var_String_String__Var(Lit_0, Lit_173); A_arbace_box_build_A_const_175 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_box_build_A_const_176 = lang.RT_Var_String_String__Var(Lit_13, Lit_174); A_arbace_box_build_A_const_177 = lang.RT_Keyword_String_String__Keyword(nil, Lit_175); A_arbace_box_build_A_const_178 = lang.RT_Keyword_String_String__Keyword(nil, Lit_167); A_arbace_box_build_A_const_179 = lang.RT_Keyword_String_String__Keyword(nil, Lit_116); A_arbace_box_build_A_const_180 = lang.RT_Vector_O1__IPersistentVector(jrt.ConstRefArray("[0,7,s4:links2:-os8:/o/a.outs10:-importcfgs17:/c/importcfg.links14:-buildmode=exes9:-buildid=", []*jrt.Class{jrt.Object_class})); A_arbace_box_build_A_const_181 = lang.RT_Keyword_String_String__Keyword(nil, Lit_176); A_arbace_box_build_A_const_182 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_177, Lit_178, Lit_179, Lit_180, Lit_181); A_arbace_box_build_A_const_183 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_61).Ref()); A_arbace_box_build_A_const_184 = lang.RT_Var_String_String__Var(Lit_13, Lit_170); A_arbace_box_build_A_const_185 = lang.RT_Var_String_String__Var(Lit_13, Lit_167); A_arbace_box_build_A_const_186 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_box_build_A_const_187 = lang.RT_Var_String_String__Var(Lit_13, Lit_182) }

func A_arbace_box_build_A_New() *A_arbace_box_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_A) Ctor() {}

func (t *A_arbace_box_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_A_class }

func (t *A_arbace_box_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_A); return ok }

func A_arbace_box_build_A_Cast(x any) *A_arbace_box_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_A_class)) }; return v }



type A_arbace_box_build_action_A struct{ jrt.Object }

func (t *A_arbace_box_build_action_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_box_build_action_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_action_A_fn_class *jrt.Class

var A_arbace_box_build_action_A_init jrt.ClassInit

func A_arbace_box_build_action_A_Init() { if !A_arbace_box_build_action_A_init.Done() { A_arbace_box_build_action_A_init.Run(A_arbace_box_build_action_A_clinit) } }

func A_arbace_box_build_action_A_clinit() { A_arbace_box_build_action_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_action_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_action_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_action_A_class }

func (t *A_arbace_box_build_action_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_action_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_action_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_action_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_action_A); return ok }

func A_arbace_box_build_action_A_Cast(x any) *A_arbace_box_build_action_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_action_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_action_A_class)) }; return v }



type A_arbace_box_build_action_STAR__A struct{ jrt.Object }

func (t *A_arbace_box_build_action_STAR__A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_action_STAR__A_fn_class *jrt.Class

var A_arbace_box_build_action_STAR__A_init jrt.ClassInit

func A_arbace_box_build_action_STAR__A_Init() { if !A_arbace_box_build_action_STAR__A_init.Done() { A_arbace_box_build_action_STAR__A_init.Run(A_arbace_box_build_action_STAR__A_clinit) } }

func A_arbace_box_build_action_STAR__A_clinit() { A_arbace_box_build_action_STAR__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_action_STAR__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_action_STAR__A) GetClass__Class() *jrt.Class { return A_arbace_box_build_action_STAR__A_class }

func (t *A_arbace_box_build_action_STAR__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_action_STAR__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_action_STAR__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_action_STAR__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_action_STAR__A); return ok }

func A_arbace_box_build_action_STAR__A_Cast(x any) *A_arbace_box_build_action_STAR__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_action_STAR__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_action_STAR__A_class)) }; return v }



type A_arbace_box_build_append_members_A struct{ jrt.Object }

func (t *A_arbace_box_build_append_members_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_append_members_A_fn_class *jrt.Class

var A_arbace_box_build_append_members_A_init jrt.ClassInit

func A_arbace_box_build_append_members_A_Init() { if !A_arbace_box_build_append_members_A_init.Done() { A_arbace_box_build_append_members_A_init.Run(A_arbace_box_build_append_members_A_clinit) } }

func A_arbace_box_build_append_members_A_clinit() { A_arbace_box_build_append_members_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_append_members_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_append_members_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_append_members_A_class }

func (t *A_arbace_box_build_append_members_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_append_members_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_append_members_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_append_members_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_append_members_A); return ok }

func A_arbace_box_build_append_members_A_Cast(x any) *A_arbace_box_build_append_members_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_append_members_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_append_members_A_class)) }; return v }



type A_arbace_box_build_ar_member_A struct{ jrt.Object }

func (t *A_arbace_box_build_ar_member_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_ar_member_A_fn_class *jrt.Class

var A_arbace_box_build_ar_member_A_init jrt.ClassInit

func A_arbace_box_build_ar_member_A_Init() { if !A_arbace_box_build_ar_member_A_init.Done() { A_arbace_box_build_ar_member_A_init.Run(A_arbace_box_build_ar_member_A_clinit) } }

func A_arbace_box_build_ar_member_A_clinit() { A_arbace_box_build_ar_member_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_ar_member_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_ar_member_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_ar_member_A_class }

func (t *A_arbace_box_build_ar_member_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_ar_member_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_ar_member_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_ar_member_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_ar_member_A); return ok }

func A_arbace_box_build_ar_member_A_Cast(x any) *A_arbace_box_build_ar_member_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_ar_member_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_ar_member_A_class)) }; return v }



type A_arbace_box_build_ar_member_pad__598000077_A struct{ jrt.Object }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_ar_member_pad__598000077_A_fn_class *jrt.Class

var A_arbace_box_build_ar_member_pad__598000077_A_init jrt.ClassInit

func A_arbace_box_build_ar_member_pad__598000077_A_Init() { if !A_arbace_box_build_ar_member_pad__598000077_A_init.Done() { A_arbace_box_build_ar_member_pad__598000077_A_init.Run(A_arbace_box_build_ar_member_pad__598000077_A_clinit) } }

func A_arbace_box_build_ar_member_pad__598000077_A_clinit() { A_arbace_box_build_ar_member_pad__598000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_ar_member_pad__598000077_A_class }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_ar_member_pad__598000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_ar_member_pad__598000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_ar_member_pad__598000077_A); return ok }

func A_arbace_box_build_ar_member_pad__598000077_A_Cast(x any) *A_arbace_box_build_ar_member_pad__598000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_ar_member_pad__598000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_ar_member_pad__598000077_A_class)) }; return v }



type A_arbace_box_build_arch_defines_A struct{ jrt.Object }

func (t *A_arbace_box_build_arch_defines_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_arch_defines_A_fn_class *jrt.Class

var A_arbace_box_build_arch_defines_A_init jrt.ClassInit

func A_arbace_box_build_arch_defines_A_Init() { if !A_arbace_box_build_arch_defines_A_init.Done() { A_arbace_box_build_arch_defines_A_init.Run(A_arbace_box_build_arch_defines_A_clinit) } }

func A_arbace_box_build_arch_defines_A_clinit() { A_arbace_box_build_arch_defines_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_arch_defines_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_arch_defines_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_arch_defines_A_class }

func (t *A_arbace_box_build_arch_defines_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_arch_defines_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_arch_defines_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_arch_defines_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_arch_defines_A); return ok }

func A_arbace_box_build_arch_defines_A_Cast(x any) *A_arbace_box_build_arch_defines_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_arch_defines_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_arch_defines_A_class)) }; return v }



type A_arbace_box_build_archives_A struct{ jrt.Object }

func (t *A_arbace_box_build_archives_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_archives_A_fn_class *jrt.Class

var A_arbace_box_build_archives_A_init jrt.ClassInit

func A_arbace_box_build_archives_A_Init() { if !A_arbace_box_build_archives_A_init.Done() { A_arbace_box_build_archives_A_init.Run(A_arbace_box_build_archives_A_clinit) } }

func A_arbace_box_build_archives_A_clinit() { A_arbace_box_build_archives_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_A_class }

func (t *A_arbace_box_build_archives_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_A); return ok }

func A_arbace_box_build_archives_A_Cast(x any) *A_arbace_box_build_archives_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_A_class)) }; return v }



type A_arbace_box_build_archives_conveyed__598000244_A struct{ jrt.Object; F_opts any }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_archives_conveyed__598000244_A_fn_class *jrt.Class

var A_arbace_box_build_archives_conveyed__598000244_A_init jrt.ClassInit

func A_arbace_box_build_archives_conveyed__598000244_A_Init() { if !A_arbace_box_build_archives_conveyed__598000244_A_init.Done() { A_arbace_box_build_archives_conveyed__598000244_A_init.Run(A_arbace_box_build_archives_conveyed__598000244_A_clinit) } }

func A_arbace_box_build_archives_conveyed__598000244_A_clinit() { A_arbace_box_build_archives_conveyed__598000244_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_conveyed__598000244_A_class }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_conveyed__598000244_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_conveyed__598000244_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_conveyed__598000244_A); return ok }

func A_arbace_box_build_archives_conveyed__598000244_A_Cast(x any) *A_arbace_box_build_archives_conveyed__598000244_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_conveyed__598000244_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_conveyed__598000244_A_class)) }; return v }



type A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A struct{ jrt.Object; F_f, F_o any }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class *jrt.Class

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_init jrt.ClassInit

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_Init() { if !A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_init.Done() { A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_init.Run(A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_clinit) } }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_clinit() { A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_class }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A); return ok }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_Cast(x any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000242_A struct{ jrt.Object }

func (t *A_arbace_box_build_archives_fn__598000242_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_archives_fn__598000242_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000242_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000242_A_Init() { if !A_arbace_box_build_archives_fn__598000242_A_init.Done() { A_arbace_box_build_archives_fn__598000242_A_init.Run(A_arbace_box_build_archives_fn__598000242_A_clinit) } }

func A_arbace_box_build_archives_fn__598000242_A_clinit() { A_arbace_box_build_archives_fn__598000242_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000242_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000242_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000242_A_class }

func (t *A_arbace_box_build_archives_fn__598000242_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000242_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000242_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000242_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000242_A); return ok }

func A_arbace_box_build_archives_fn__598000242_A_Cast(x any) *A_arbace_box_build_archives_fn__598000242_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000242_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000242_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000252_A struct{ jrt.Object; F_given, F_q any }

func (t *A_arbace_box_build_archives_fn__598000252_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000252_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000252_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000252_A_Init() { if !A_arbace_box_build_archives_fn__598000252_A_init.Done() { A_arbace_box_build_archives_fn__598000252_A_init.Run(A_arbace_box_build_archives_fn__598000252_A_clinit) } }

func A_arbace_box_build_archives_fn__598000252_A_clinit() { A_arbace_box_build_archives_fn__598000252_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000252_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000252_A_class }

func (t *A_arbace_box_build_archives_fn__598000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000252_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000252_A); return ok }

func A_arbace_box_build_archives_fn__598000252_A_Cast(x any) *A_arbace_box_build_archives_fn__598000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000252_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000254_A struct{ jrt.Object; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

func (t *A_arbace_box_build_archives_fn__598000254_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000254_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000254_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000254_A_Init() { if !A_arbace_box_build_archives_fn__598000254_A_init.Done() { A_arbace_box_build_archives_fn__598000254_A_init.Run(A_arbace_box_build_archives_fn__598000254_A_clinit) } }

func A_arbace_box_build_archives_fn__598000254_A_clinit() { A_arbace_box_build_archives_fn__598000254_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000254_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000254_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000254_A_class }

func (t *A_arbace_box_build_archives_fn__598000254_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000254_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000254_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000254_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000254_A); return ok }

func A_arbace_box_build_archives_fn__598000254_A_Cast(x any) *A_arbace_box_build_archives_fn__598000254_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000254_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000254_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000254_fn__598000255_A struct{ jrt.Object; F_index, F_p, F_deps, F_sem, F_q any }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_Init() { if !A_arbace_box_build_archives_fn__598000254_fn__598000255_A_init.Done() { A_arbace_box_build_archives_fn__598000254_fn__598000255_A_init.Run(A_arbace_box_build_archives_fn__598000254_fn__598000255_A_clinit) } }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_clinit() { A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_A); return ok }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_Cast(x any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A struct{ jrt.Object }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_Init() { if !A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_init.Done() { A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_init.Run(A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_clinit) } }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_clinit() { A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_class }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A); return ok }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_Cast(x any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000260_A struct{ jrt.Object; F_given, F_q any }

func (t *A_arbace_box_build_archives_fn__598000260_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000260_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000260_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000260_A_Init() { if !A_arbace_box_build_archives_fn__598000260_A_init.Done() { A_arbace_box_build_archives_fn__598000260_A_init.Run(A_arbace_box_build_archives_fn__598000260_A_clinit) } }

func A_arbace_box_build_archives_fn__598000260_A_clinit() { A_arbace_box_build_archives_fn__598000260_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000260_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000260_A_class }

func (t *A_arbace_box_build_archives_fn__598000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000260_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000260_A); return ok }

func A_arbace_box_build_archives_fn__598000260_A_Cast(x any) *A_arbace_box_build_archives_fn__598000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000260_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000262_A struct{ jrt.Object; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

func (t *A_arbace_box_build_archives_fn__598000262_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000262_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000262_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000262_A_Init() { if !A_arbace_box_build_archives_fn__598000262_A_init.Done() { A_arbace_box_build_archives_fn__598000262_A_init.Run(A_arbace_box_build_archives_fn__598000262_A_clinit) } }

func A_arbace_box_build_archives_fn__598000262_A_clinit() { A_arbace_box_build_archives_fn__598000262_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000262_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000262_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000262_A_class }

func (t *A_arbace_box_build_archives_fn__598000262_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000262_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000262_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000262_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000262_A); return ok }

func A_arbace_box_build_archives_fn__598000262_A_Cast(x any) *A_arbace_box_build_archives_fn__598000262_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000262_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000262_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000262_fn__598000263_A struct{ jrt.Object; F_index, F_p, F_deps, F_sem, F_q any }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_Init() { if !A_arbace_box_build_archives_fn__598000262_fn__598000263_A_init.Done() { A_arbace_box_build_archives_fn__598000262_fn__598000263_A_init.Run(A_arbace_box_build_archives_fn__598000262_fn__598000263_A_clinit) } }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_clinit() { A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_A); return ok }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_Cast(x any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class)) }; return v }



type A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A struct{ jrt.Object }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class *jrt.Class

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_init jrt.ClassInit

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_Init() { if !A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_init.Done() { A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_init.Run(A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_clinit) } }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_clinit() { A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_class }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A); return ok }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_Cast(x any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_class)) }; return v }



type A_arbace_box_build_archives_iter__598000268__598000272_A struct{ jrt.Object }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class *jrt.Class

var A_arbace_box_build_archives_iter__598000268__598000272_A_init jrt.ClassInit

func A_arbace_box_build_archives_iter__598000268__598000272_A_Init() { if !A_arbace_box_build_archives_iter__598000268__598000272_A_init.Done() { A_arbace_box_build_archives_iter__598000268__598000272_A_init.Run(A_arbace_box_build_archives_iter__598000268__598000272_A_clinit) } }

func A_arbace_box_build_archives_iter__598000268__598000272_A_clinit() { A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_iter__598000268__598000272_A_class }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_iter__598000268__598000272_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_A); return ok }

func A_arbace_box_build_archives_iter__598000268__598000272_A_Cast(x any) *A_arbace_box_build_archives_iter__598000268__598000272_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_iter__598000268__598000272_A_class)) }; return v }



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A struct{ jrt.Object; F_iter__598000268, F_s__598000269 any }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class *jrt.Class

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_init jrt.ClassInit

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_Init() { if !A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_init.Done() { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_init.Run(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_clinit) } }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_clinit() { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A); return ok }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_Cast(x any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class)) }; return v }



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A struct{ jrt.Object; F_b__598000271 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class *jrt.Class

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_init jrt.ClassInit

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_Init() { if !A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_init.Done() { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_init.Run(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_clinit) } }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_clinit() { A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_class }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A); return ok }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_Cast(x any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_class)) }; return v }



type A_arbace_box_build_asm_args_A struct{ jrt.Object }

func (t *A_arbace_box_build_asm_args_A) Is_Compiler_AOTR3() {}

var A_arbace_box_build_asm_args_A_fn_class *jrt.Class

var A_arbace_box_build_asm_args_A_init jrt.ClassInit

func A_arbace_box_build_asm_args_A_Init() { if !A_arbace_box_build_asm_args_A_init.Done() { A_arbace_box_build_asm_args_A_init.Run(A_arbace_box_build_asm_args_A_clinit) } }

func A_arbace_box_build_asm_args_A_clinit() { A_arbace_box_build_asm_args_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_box_build_asm_args_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_asm_args_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_asm_args_A_class }

func (t *A_arbace_box_build_asm_args_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_asm_args_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_asm_args_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_asm_args_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_asm_args_A); return ok }

func A_arbace_box_build_asm_args_A_Cast(x any) *A_arbace_box_build_asm_args_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_asm_args_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_asm_args_A_class)) }; return v }



type A_arbace_box_build_asm_args_fn__598000074_A struct{ jrt.Object; F_pkg any }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_asm_args_fn__598000074_A_fn_class *jrt.Class

var A_arbace_box_build_asm_args_fn__598000074_A_init jrt.ClassInit

func A_arbace_box_build_asm_args_fn__598000074_A_Init() { if !A_arbace_box_build_asm_args_fn__598000074_A_init.Done() { A_arbace_box_build_asm_args_fn__598000074_A_init.Run(A_arbace_box_build_asm_args_fn__598000074_A_clinit) } }

func A_arbace_box_build_asm_args_fn__598000074_A_clinit() { A_arbace_box_build_asm_args_fn__598000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_230, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_asm_args_fn__598000074_A_class }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_asm_args_fn__598000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_asm_args_fn__598000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_asm_args_fn__598000074_A); return ok }

func A_arbace_box_build_asm_args_fn__598000074_A_Cast(x any) *A_arbace_box_build_asm_args_fn__598000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_asm_args_fn__598000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_asm_args_fn__598000074_A_class)) }; return v }



type A_arbace_box_build_build_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_box_build_build_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_A_fn_class *jrt.Class

var A_arbace_box_build_build_A_init jrt.ClassInit

func A_arbace_box_build_build_A_Init() { if !A_arbace_box_build_build_A_init.Done() { A_arbace_box_build_build_A_init.Run(A_arbace_box_build_build_A_clinit) } }

func A_arbace_box_build_build_A_clinit() { A_arbace_box_build_build_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_A_class }

func (t *A_arbace_box_build_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_A); return ok }

func A_arbace_box_build_build_A_Cast(x any) *A_arbace_box_build_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_A_class)) }; return v }



type A_arbace_box_build_build_fn__598000301_A struct{ jrt.Object; F_p, F_image any; F_t0 int64 }

func (t *A_arbace_box_build_build_fn__598000301_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_fn__598000301_A_fn_class *jrt.Class

var A_arbace_box_build_build_fn__598000301_A_init jrt.ClassInit

func A_arbace_box_build_build_fn__598000301_A_Init() { if !A_arbace_box_build_build_fn__598000301_A_init.Done() { A_arbace_box_build_build_fn__598000301_A_init.Run(A_arbace_box_build_build_fn__598000301_A_clinit) } }

func A_arbace_box_build_build_fn__598000301_A_clinit() { A_arbace_box_build_build_fn__598000301_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_fn__598000301_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_fn__598000301_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_fn__598000301_A_class }

func (t *A_arbace_box_build_build_fn__598000301_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_fn__598000301_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_fn__598000301_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_fn__598000301_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_fn__598000301_A); return ok }

func A_arbace_box_build_build_fn__598000301_A_Cast(x any) *A_arbace_box_build_build_fn__598000301_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_fn__598000301_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_fn__598000301_A_class)) }; return v }



type A_arbace_box_build_build_package_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_A) Is_Compiler_AOTF4() {}

var A_arbace_box_build_build_package_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_A_init jrt.ClassInit

func A_arbace_box_build_build_package_A_Init() { if !A_arbace_box_build_build_package_A_init.Done() { A_arbace_box_build_build_package_A_init.Run(A_arbace_box_build_build_package_A_clinit) } }

func A_arbace_box_build_build_package_A_clinit() { A_arbace_box_build_build_package_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_A_class }

func (t *A_arbace_box_build_build_package_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_A); return ok }

func A_arbace_box_build_build_package_A_Cast(x any) *A_arbace_box_build_build_package_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_A_class)) }; return v }



type A_arbace_box_build_build_package_fn__598000179_A struct{ jrt.Object; F_P any }

func (t *A_arbace_box_build_build_package_fn__598000179_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_fn__598000179_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_fn__598000179_A_init jrt.ClassInit

func A_arbace_box_build_build_package_fn__598000179_A_Init() { if !A_arbace_box_build_build_package_fn__598000179_A_init.Done() { A_arbace_box_build_build_package_fn__598000179_A_init.Run(A_arbace_box_build_build_package_fn__598000179_A_clinit) } }

func A_arbace_box_build_build_package_fn__598000179_A_clinit() { A_arbace_box_build_build_package_fn__598000179_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_fn__598000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_fn__598000179_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_fn__598000179_A_class }

func (t *A_arbace_box_build_build_package_fn__598000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_fn__598000179_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_fn__598000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_fn__598000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_fn__598000179_A); return ok }

func A_arbace_box_build_build_package_fn__598000179_A_Cast(x any) *A_arbace_box_build_build_package_fn__598000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_fn__598000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_fn__598000179_A_class)) }; return v }



type A_arbace_box_build_build_package_fn__598000184_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_fn__598000184_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_fn__598000184_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_fn__598000184_A_init jrt.ClassInit

func A_arbace_box_build_build_package_fn__598000184_A_Init() { if !A_arbace_box_build_build_package_fn__598000184_A_init.Done() { A_arbace_box_build_build_package_fn__598000184_A_init.Run(A_arbace_box_build_build_package_fn__598000184_A_clinit) } }

func A_arbace_box_build_build_package_fn__598000184_A_clinit() { A_arbace_box_build_build_package_fn__598000184_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_fn__598000184_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_fn__598000184_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_fn__598000184_A_class }

func (t *A_arbace_box_build_build_package_fn__598000184_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_fn__598000184_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_fn__598000184_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_fn__598000184_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_fn__598000184_A); return ok }

func A_arbace_box_build_build_package_fn__598000184_A_Cast(x any) *A_arbace_box_build_build_package_fn__598000184_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_fn__598000184_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_fn__598000184_A_class)) }; return v }



type A_arbace_box_build_build_package_fn__598000186_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_fn__598000186_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_fn__598000186_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_fn__598000186_A_init jrt.ClassInit

func A_arbace_box_build_build_package_fn__598000186_A_Init() { if !A_arbace_box_build_build_package_fn__598000186_A_init.Done() { A_arbace_box_build_build_package_fn__598000186_A_init.Run(A_arbace_box_build_build_package_fn__598000186_A_clinit) } }

func A_arbace_box_build_build_package_fn__598000186_A_clinit() { A_arbace_box_build_build_package_fn__598000186_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_fn__598000186_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_fn__598000186_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_fn__598000186_A_class }

func (t *A_arbace_box_build_build_package_fn__598000186_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_fn__598000186_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_fn__598000186_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_fn__598000186_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_fn__598000186_A); return ok }

func A_arbace_box_build_build_package_fn__598000186_A_Cast(x any) *A_arbace_box_build_build_package_fn__598000186_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_fn__598000186_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_fn__598000186_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000150__598000154_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000150__598000154_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000150__598000154_A_Init() { if !A_arbace_box_build_build_package_iter__598000150__598000154_A_init.Done() { A_arbace_box_build_build_package_iter__598000150__598000154_A_init.Run(A_arbace_box_build_build_package_iter__598000150__598000154_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_clinit() { A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000150__598000154_A_class }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_A); return ok }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000150__598000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000150__598000154_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A struct{ jrt.Object; F_iter__598000150, F_s__598000151 any }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_Init() { if !A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_init.Done() { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_init.Run(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_clinit() { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A); return ok }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A struct{ jrt.Object; F_b__598000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_Init() { if !A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_init.Done() { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_init.Run(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_clinit() { A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_258, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_class }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A); return ok }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000166__598000170_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000166__598000170_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000166__598000170_A_Init() { if !A_arbace_box_build_build_package_iter__598000166__598000170_A_init.Done() { A_arbace_box_build_build_package_iter__598000166__598000170_A_init.Run(A_arbace_box_build_build_package_iter__598000166__598000170_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_clinit() { A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000166__598000170_A_class }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_A); return ok }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000166__598000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000166__598000170_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A struct{ jrt.Object; F_s__598000167, F_iter__598000166 any }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_Init() { if !A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_init.Done() { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_init.Run(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_clinit() { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_260, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A); return ok }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A struct{ jrt.Object; F_b__598000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_Init() { if !A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_init.Done() { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_init.Run(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_clinit() { A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_class }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A); return ok }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000189__598000193_A struct{ jrt.Object; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000189__598000193_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000189__598000193_A_Init() { if !A_arbace_box_build_build_package_iter__598000189__598000193_A_init.Done() { A_arbace_box_build_build_package_iter__598000189__598000193_A_init.Run(A_arbace_box_build_build_package_iter__598000189__598000193_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_clinit() { A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000189__598000193_A_class }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_A); return ok }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000189__598000193_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A struct{ jrt.Object; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools, F_s__598000190, F_iter__598000189 any }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_Init() { if !A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_init.Done() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_init.Run(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_clinit() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_263, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A); return ok }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A struct{ jrt.Object; F_b__598000192, F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_Init() { if !A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_init.Done() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_init.Run(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_clinit() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_265, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A); return ok }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A struct{ jrt.Object; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_o, F_s, F_tools any }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_Init() { if !A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_init.Done() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_init.Run(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_clinit() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_266, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_class }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A); return ok }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A struct{ jrt.Object; F_res_of, F_P, F_plan, F_o, F_ctree, F_pkg, F_s, F_tools any }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_Init() { if !A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_init.Done() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_init.Run(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_clinit() { A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_269, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_class }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A); return ok }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000203__598000207_A struct{ jrt.Object }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000203__598000207_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000203__598000207_A_Init() { if !A_arbace_box_build_build_package_iter__598000203__598000207_A_init.Done() { A_arbace_box_build_build_package_iter__598000203__598000207_A_init.Run(A_arbace_box_build_build_package_iter__598000203__598000207_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_clinit() { A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_270, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000203__598000207_A_class }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_A); return ok }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000203__598000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000203__598000207_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A struct{ jrt.Object; F_iter__598000203, F_s__598000204 any }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_Init() { if !A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_init.Done() { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_init.Run(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_clinit() { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_271, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A); return ok }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class)) }; return v }



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A struct{ jrt.Object; F_b__598000206 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_init jrt.ClassInit

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_Init() { if !A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_init.Done() { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_init.Run(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_clinit) } }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_clinit() { A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_class }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A); return ok }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_Cast(x any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_class)) }; return v }



type A_arbace_box_build_build_package_res_of__598000176_A struct{ jrt.Object; F_P any }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_build_package_res_of__598000176_A_fn_class *jrt.Class

var A_arbace_box_build_build_package_res_of__598000176_A_init jrt.ClassInit

func A_arbace_box_build_build_package_res_of__598000176_A_Init() { if !A_arbace_box_build_build_package_res_of__598000176_A_init.Done() { A_arbace_box_build_build_package_res_of__598000176_A_init.Run(A_arbace_box_build_build_package_res_of__598000176_A_clinit) } }

func A_arbace_box_build_build_package_res_of__598000176_A_clinit() { A_arbace_box_build_build_package_res_of__598000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_build_package_res_of__598000176_A_class }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_build_package_res_of__598000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_build_package_res_of__598000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_build_package_res_of__598000176_A); return ok }

func A_arbace_box_build_build_package_res_of__598000176_A_Cast(x any) *A_arbace_box_build_build_package_res_of__598000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_build_package_res_of__598000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_build_package_res_of__598000176_A_class)) }; return v }



type A_arbace_box_build_cache_ref_A struct{ jrt.Object }

func (t *A_arbace_box_build_cache_ref_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_cache_ref_A_fn_class *jrt.Class

var A_arbace_box_build_cache_ref_A_init jrt.ClassInit

func A_arbace_box_build_cache_ref_A_Init() { if !A_arbace_box_build_cache_ref_A_init.Done() { A_arbace_box_build_cache_ref_A_init.Run(A_arbace_box_build_cache_ref_A_clinit) } }

func A_arbace_box_build_cache_ref_A_clinit() { A_arbace_box_build_cache_ref_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_cache_ref_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_cache_ref_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_cache_ref_A_class }

func (t *A_arbace_box_build_cache_ref_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_cache_ref_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_cache_ref_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_cache_ref_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_cache_ref_A); return ok }

func A_arbace_box_build_cache_ref_A_Cast(x any) *A_arbace_box_build_cache_ref_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_cache_ref_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_cache_ref_A_class)) }; return v }



type A_arbace_box_build_complete_QMARK__A struct{ jrt.Object }

func (t *A_arbace_box_build_complete_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_complete_QMARK__A_fn_class *jrt.Class

var A_arbace_box_build_complete_QMARK__A_init jrt.ClassInit

func A_arbace_box_build_complete_QMARK__A_Init() { if !A_arbace_box_build_complete_QMARK__A_init.Done() { A_arbace_box_build_complete_QMARK__A_init.Run(A_arbace_box_build_complete_QMARK__A_clinit) } }

func A_arbace_box_build_complete_QMARK__A_clinit() { A_arbace_box_build_complete_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_complete_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_complete_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_box_build_complete_QMARK__A_class }

func (t *A_arbace_box_build_complete_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_complete_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_complete_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_complete_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_complete_QMARK__A); return ok }

func A_arbace_box_build_complete_QMARK__A_Cast(x any) *A_arbace_box_build_complete_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_complete_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_complete_QMARK__A_class)) }; return v }



type A_arbace_box_build_deps_tree_A struct{ jrt.Object }

func (t *A_arbace_box_build_deps_tree_A) Is_Compiler_AOTF3() {}

var A_arbace_box_build_deps_tree_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_A_Init() { if !A_arbace_box_build_deps_tree_A_init.Done() { A_arbace_box_build_deps_tree_A_init.Run(A_arbace_box_build_deps_tree_A_clinit) } }

func A_arbace_box_build_deps_tree_A_clinit() { A_arbace_box_build_deps_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_A_class }

func (t *A_arbace_box_build_deps_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_A); return ok }

func A_arbace_box_build_deps_tree_A_Cast(x any) *A_arbace_box_build_deps_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000092__598000096_A struct{ jrt.Object; F_archives, F_index any }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000092__598000096_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000092__598000096_A_init.Run(A_arbace_box_build_deps_tree_iter__598000092__598000096_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_clinit() { A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_279, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A struct{ jrt.Object; F_archives, F_index, F_iter__598000092, F_s__598000093 any }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_init.Run(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_clinit() { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A struct{ jrt.Object; F_b__598000095, F_archives, F_index any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_init.Run(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_clinit() { A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000102__598000106_A struct{ jrt.Object; F_index any }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000102__598000106_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000102__598000106_A_init.Run(A_arbace_box_build_deps_tree_iter__598000102__598000106_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_clinit() { A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A struct{ jrt.Object; F_s__598000103, F_index, F_iter__598000102 any }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_init.Run(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_clinit() { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_284, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class)) }; return v }



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A struct{ jrt.Object; F_index, F_b__598000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class *jrt.Class

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_init jrt.ClassInit

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_Init() { if !A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_init.Done() { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_init.Run(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_clinit) } }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_clinit() { A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_287, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_class }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A); return ok }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_Cast(x any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_class)) }; return v }



type A_arbace_box_build_embed_config_A struct{ jrt.Object }

func (t *A_arbace_box_build_embed_config_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_embed_config_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_A_Init() { if !A_arbace_box_build_embed_config_A_init.Done() { A_arbace_box_build_embed_config_A_init.Run(A_arbace_box_build_embed_config_A_clinit) } }

func A_arbace_box_build_embed_config_A_clinit() { A_arbace_box_build_embed_config_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_A_class }

func (t *A_arbace_box_build_embed_config_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_A); return ok }

func A_arbace_box_build_embed_config_A_Cast(x any) *A_arbace_box_build_embed_config_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000116__598000120_A struct{ jrt.Object }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_Init() { if !A_arbace_box_build_embed_config_iter__598000116__598000120_A_init.Done() { A_arbace_box_build_embed_config_iter__598000116__598000120_A_init.Run(A_arbace_box_build_embed_config_iter__598000116__598000120_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_clinit() { A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000116__598000120_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_A); return ok }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000116__598000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000116__598000120_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A struct{ jrt.Object; F_iter__598000116, F_s__598000117 any }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_Init() { if !A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_init.Done() { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_init.Run(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_clinit() { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_294, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A); return ok }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A struct{ jrt.Object; F_b__598000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_Init() { if !A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_init.Done() { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_init.Run(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_clinit() { A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_297, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A); return ok }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000132__598000136_A struct{ jrt.Object }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_Init() { if !A_arbace_box_build_embed_config_iter__598000132__598000136_A_init.Done() { A_arbace_box_build_embed_config_iter__598000132__598000136_A_init.Run(A_arbace_box_build_embed_config_iter__598000132__598000136_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_clinit() { A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_298, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000132__598000136_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_A); return ok }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000132__598000136_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000132__598000136_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A struct{ jrt.Object; F_s__598000133, F_iter__598000132 any }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_Init() { if !A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_init.Done() { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_init.Run(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_clinit() { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_299, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A); return ok }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class)) }; return v }



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A struct{ jrt.Object; F_b__598000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class *jrt.Class

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_init jrt.ClassInit

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_Init() { if !A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_init.Done() { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_init.Run(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_clinit) } }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_clinit() { A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_301, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_class }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A); return ok }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_Cast(x any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_class)) }; return v }



type A_arbace_box_build_eval598000004_A struct{ jrt.Object }

func A_arbace_box_build_eval598000004_A_New() *A_arbace_box_build_eval598000004_A { t := &A_arbace_box_build_eval598000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000004_A) Ctor() {}

func (t *A_arbace_box_build_eval598000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_A_class }

func (t *A_arbace_box_build_eval598000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_A); return ok }

func A_arbace_box_build_eval598000004_A_Cast(x any) *A_arbace_box_build_eval598000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_A_class)) }; return v }



type A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A struct{ jrt.Object }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class *jrt.Class

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_init jrt.ClassInit

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_Init() { if !A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_init.Done() { A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_init.Run(A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_clinit) } }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_clinit() { A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_302, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_class }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A); return ok }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_Cast(x any) *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_class)) }; return v }



type A_arbace_box_build_eval598000008_A struct{ jrt.Object }

func A_arbace_box_build_eval598000008_A_New() *A_arbace_box_build_eval598000008_A { t := &A_arbace_box_build_eval598000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000008_A) Ctor() {}

func (t *A_arbace_box_build_eval598000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_A_class }

func (t *A_arbace_box_build_eval598000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_A); return ok }

func A_arbace_box_build_eval598000008_A_Cast(x any) *A_arbace_box_build_eval598000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_A_class)) }; return v }



type A_arbace_box_build_eval598000008_fn__598000009_A struct{ jrt.Object }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_eval598000008_fn__598000009_A_fn_class *jrt.Class

var A_arbace_box_build_eval598000008_fn__598000009_A_init jrt.ClassInit

func A_arbace_box_build_eval598000008_fn__598000009_A_Init() { if !A_arbace_box_build_eval598000008_fn__598000009_A_init.Done() { A_arbace_box_build_eval598000008_fn__598000009_A_init.Run(A_arbace_box_build_eval598000008_fn__598000009_A_clinit) } }

func A_arbace_box_build_eval598000008_fn__598000009_A_clinit() { A_arbace_box_build_eval598000008_fn__598000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_306, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_fn__598000009_A_class }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_fn__598000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_fn__598000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_fn__598000009_A); return ok }

func A_arbace_box_build_eval598000008_fn__598000009_A_Cast(x any) *A_arbace_box_build_eval598000008_fn__598000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_fn__598000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_fn__598000009_A_class)) }; return v }



type A_arbace_box_build_fail_A struct{ jrt.Object }

func (t *A_arbace_box_build_fail_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_fail_A_fn_class *jrt.Class

var A_arbace_box_build_fail_A_init jrt.ClassInit

func A_arbace_box_build_fail_A_Init() { if !A_arbace_box_build_fail_A_init.Done() { A_arbace_box_build_fail_A_init.Run(A_arbace_box_build_fail_A_clinit) } }

func A_arbace_box_build_fail_A_clinit() { A_arbace_box_build_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_307, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_fail_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_fail_A_class }

func (t *A_arbace_box_build_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_fail_A); return ok }

func A_arbace_box_build_fail_A_Cast(x any) *A_arbace_box_build_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_fail_A_class)) }; return v }



type A_arbace_box_build_file_tree_A struct{ jrt.Object }

func (t *A_arbace_box_build_file_tree_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_file_tree_A_fn_class *jrt.Class

var A_arbace_box_build_file_tree_A_init jrt.ClassInit

func A_arbace_box_build_file_tree_A_Init() { if !A_arbace_box_build_file_tree_A_init.Done() { A_arbace_box_build_file_tree_A_init.Run(A_arbace_box_build_file_tree_A_clinit) } }

func A_arbace_box_build_file_tree_A_clinit() { A_arbace_box_build_file_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_308, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_file_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_file_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_file_tree_A_class }

func (t *A_arbace_box_build_file_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_file_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_file_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_file_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_file_tree_A); return ok }

func A_arbace_box_build_file_tree_A_Cast(x any) *A_arbace_box_build_file_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_file_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_file_tree_A_class)) }; return v }



type A_arbace_box_build_file_tree_iter__598000054__598000058_A struct{ jrt.Object }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class *jrt.Class

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_init jrt.ClassInit

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_Init() { if !A_arbace_box_build_file_tree_iter__598000054__598000058_A_init.Done() { A_arbace_box_build_file_tree_iter__598000054__598000058_A_init.Run(A_arbace_box_build_file_tree_iter__598000054__598000058_A_clinit) } }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_clinit() { A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_309, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_file_tree_iter__598000054__598000058_A_class }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_A); return ok }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_Cast(x any) *A_arbace_box_build_file_tree_iter__598000054__598000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_file_tree_iter__598000054__598000058_A_class)) }; return v }



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A struct{ jrt.Object; F_s__598000055, F_iter__598000054 any }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class *jrt.Class

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_init jrt.ClassInit

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_Init() { if !A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_init.Done() { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_init.Run(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_clinit) } }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_clinit() { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_310, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A); return ok }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_Cast(x any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class)) }; return v }



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A struct{ jrt.Object; F_b__598000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class *jrt.Class

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_init jrt.ClassInit

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_Init() { if !A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_init.Done() { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_init.Run(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_clinit) } }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_clinit() { A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_311, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_class }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A); return ok }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_Cast(x any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_class)) }; return v }



type A_arbace_box_build_import_plan_A struct{ jrt.Object }

func (t *A_arbace_box_build_import_plan_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_box_build_import_plan_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_import_plan_A_fn_class *jrt.Class

var A_arbace_box_build_import_plan_A_init jrt.ClassInit

func A_arbace_box_build_import_plan_A_Init() { if !A_arbace_box_build_import_plan_A_init.Done() { A_arbace_box_build_import_plan_A_init.Run(A_arbace_box_build_import_plan_A_clinit) } }

func A_arbace_box_build_import_plan_A_clinit() { A_arbace_box_build_import_plan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_312, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_import_plan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_import_plan_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_import_plan_A_class }

func (t *A_arbace_box_build_import_plan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_import_plan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_import_plan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_import_plan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_import_plan_A); return ok }

func A_arbace_box_build_import_plan_A_Cast(x any) *A_arbace_box_build_import_plan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_import_plan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_import_plan_A_class)) }; return v }



type A_arbace_box_build_import_plan_fn__598000044_A struct{ jrt.Object; F_src any }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_import_plan_fn__598000044_A_fn_class *jrt.Class

var A_arbace_box_build_import_plan_fn__598000044_A_init jrt.ClassInit

func A_arbace_box_build_import_plan_fn__598000044_A_Init() { if !A_arbace_box_build_import_plan_fn__598000044_A_init.Done() { A_arbace_box_build_import_plan_fn__598000044_A_init.Run(A_arbace_box_build_import_plan_fn__598000044_A_clinit) } }

func A_arbace_box_build_import_plan_fn__598000044_A_clinit() { A_arbace_box_build_import_plan_fn__598000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_315, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_import_plan_fn__598000044_A_class }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_import_plan_fn__598000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_import_plan_fn__598000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_import_plan_fn__598000044_A); return ok }

func A_arbace_box_build_import_plan_fn__598000044_A_Cast(x any) *A_arbace_box_build_import_plan_fn__598000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_import_plan_fn__598000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_import_plan_fn__598000044_A_class)) }; return v }



type A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A struct{ jrt.Object; F_src any }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class *jrt.Class

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_init jrt.ClassInit

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_Init() { if !A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_init.Done() { A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_init.Run(A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_clinit) } }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_clinit() { A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_316, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_class }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A); return ok }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_Cast(x any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_class)) }; return v }



type A_arbace_box_build_import_plan_src__598000042_A struct{ jrt.Object; F_dirs any }

func (t *A_arbace_box_build_import_plan_src__598000042_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_import_plan_src__598000042_A_fn_class *jrt.Class

var A_arbace_box_build_import_plan_src__598000042_A_init jrt.ClassInit

func A_arbace_box_build_import_plan_src__598000042_A_Init() { if !A_arbace_box_build_import_plan_src__598000042_A_init.Done() { A_arbace_box_build_import_plan_src__598000042_A_init.Run(A_arbace_box_build_import_plan_src__598000042_A_clinit) } }

func A_arbace_box_build_import_plan_src__598000042_A_clinit() { A_arbace_box_build_import_plan_src__598000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_317, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_import_plan_src__598000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_import_plan_src__598000042_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_import_plan_src__598000042_A_class }

func (t *A_arbace_box_build_import_plan_src__598000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_import_plan_src__598000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_import_plan_src__598000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_import_plan_src__598000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_import_plan_src__598000042_A); return ok }

func A_arbace_box_build_import_plan_src__598000042_A_Cast(x any) *A_arbace_box_build_import_plan_src__598000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_import_plan_src__598000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_import_plan_src__598000042_A_class)) }; return v }



type A_arbace_box_build_json_str_A struct{ jrt.Object }

func (t *A_arbace_box_build_json_str_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_json_str_A_fn_class *jrt.Class

var A_arbace_box_build_json_str_A_init jrt.ClassInit

func A_arbace_box_build_json_str_A_Init() { if !A_arbace_box_build_json_str_A_init.Done() { A_arbace_box_build_json_str_A_init.Run(A_arbace_box_build_json_str_A_clinit) } }

func A_arbace_box_build_json_str_A_clinit() { A_arbace_box_build_json_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_318, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_json_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_json_str_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_json_str_A_class }

func (t *A_arbace_box_build_json_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_json_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_json_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_json_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_json_str_A); return ok }

func A_arbace_box_build_json_str_A_Cast(x any) *A_arbace_box_build_json_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_json_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_json_str_A_class)) }; return v }



type A_arbace_box_build_json_str_fn__598000113_A struct{ jrt.Object }

func (t *A_arbace_box_build_json_str_fn__598000113_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_json_str_fn__598000113_A_fn_class *jrt.Class

var A_arbace_box_build_json_str_fn__598000113_A_init jrt.ClassInit

func A_arbace_box_build_json_str_fn__598000113_A_Init() { if !A_arbace_box_build_json_str_fn__598000113_A_init.Done() { A_arbace_box_build_json_str_fn__598000113_A_init.Run(A_arbace_box_build_json_str_fn__598000113_A_clinit) } }

func A_arbace_box_build_json_str_fn__598000113_A_clinit() { A_arbace_box_build_json_str_fn__598000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_320, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_json_str_fn__598000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_json_str_fn__598000113_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_json_str_fn__598000113_A_class }

func (t *A_arbace_box_build_json_str_fn__598000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_json_str_fn__598000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_json_str_fn__598000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_json_str_fn__598000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_json_str_fn__598000113_A); return ok }

func A_arbace_box_build_json_str_fn__598000113_A_Cast(x any) *A_arbace_box_build_json_str_fn__598000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_json_str_fn__598000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_json_str_fn__598000113_A_class)) }; return v }



type A_arbace_box_build_link_A struct{ jrt.Object }

func (t *A_arbace_box_build_link_A) Is_Compiler_AOTF3() {}

var A_arbace_box_build_link_A_fn_class *jrt.Class

var A_arbace_box_build_link_A_init jrt.ClassInit

func A_arbace_box_build_link_A_Init() { if !A_arbace_box_build_link_A_init.Done() { A_arbace_box_build_link_A_init.Run(A_arbace_box_build_link_A_clinit) } }

func A_arbace_box_build_link_A_clinit() { A_arbace_box_build_link_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_324, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_link_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_link_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_link_A_class }

func (t *A_arbace_box_build_link_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_link_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_link_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_link_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_link_A); return ok }

func A_arbace_box_build_link_A_Cast(x any) *A_arbace_box_build_link_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_link_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_link_A_class)) }; return v }



type A_arbace_box_build_link_fn__598000285_A struct{ jrt.Object }

func (t *A_arbace_box_build_link_fn__598000285_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_link_fn__598000285_A_fn_class *jrt.Class

var A_arbace_box_build_link_fn__598000285_A_init jrt.ClassInit

func A_arbace_box_build_link_fn__598000285_A_Init() { if !A_arbace_box_build_link_fn__598000285_A_init.Done() { A_arbace_box_build_link_fn__598000285_A_init.Run(A_arbace_box_build_link_fn__598000285_A_clinit) } }

func A_arbace_box_build_link_fn__598000285_A_clinit() { A_arbace_box_build_link_fn__598000285_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_329, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_link_fn__598000285_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_link_fn__598000285_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_link_fn__598000285_A_class }

func (t *A_arbace_box_build_link_fn__598000285_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_link_fn__598000285_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_link_fn__598000285_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_link_fn__598000285_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_link_fn__598000285_A); return ok }

func A_arbace_box_build_link_fn__598000285_A_Cast(x any) *A_arbace_box_build_link_fn__598000285_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_link_fn__598000285_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_link_fn__598000285_A_class)) }; return v }



type A_arbace_box_build_link_iter__598000290__598000294_A struct{ jrt.Object }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_link_iter__598000290__598000294_A_fn_class *jrt.Class

var A_arbace_box_build_link_iter__598000290__598000294_A_init jrt.ClassInit

func A_arbace_box_build_link_iter__598000290__598000294_A_Init() { if !A_arbace_box_build_link_iter__598000290__598000294_A_init.Done() { A_arbace_box_build_link_iter__598000290__598000294_A_init.Run(A_arbace_box_build_link_iter__598000290__598000294_A_clinit) } }

func A_arbace_box_build_link_iter__598000290__598000294_A_clinit() { A_arbace_box_build_link_iter__598000290__598000294_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_330, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_link_iter__598000290__598000294_A_class }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_link_iter__598000290__598000294_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_A); return ok }

func A_arbace_box_build_link_iter__598000290__598000294_A_Cast(x any) *A_arbace_box_build_link_iter__598000290__598000294_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_link_iter__598000290__598000294_A_class)) }; return v }



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A struct{ jrt.Object; F_iter__598000290, F_s__598000291 any }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class *jrt.Class

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_init jrt.ClassInit

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_Init() { if !A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_init.Done() { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_init.Run(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_clinit) } }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_clinit() { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_331, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A); return ok }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_Cast(x any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class)) }; return v }



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A struct{ jrt.Object; F_b__598000293 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class *jrt.Class

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_init jrt.ClassInit

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_Init() { if !A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_init.Done() { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_init.Run(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_clinit) } }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_clinit() { A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_332, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_class }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A); return ok }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_Cast(x any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_class)) }; return v }



type A_arbace_box_build_log_A struct{ jrt.Object }

func (t *A_arbace_box_build_log_A) Is_Compiler_AOTR0() {}

var A_arbace_box_build_log_A_fn_class *jrt.Class

var A_arbace_box_build_log_A_init jrt.ClassInit

func A_arbace_box_build_log_A_Init() { if !A_arbace_box_build_log_A_init.Done() { A_arbace_box_build_log_A_init.Run(A_arbace_box_build_log_A_clinit) } }

func A_arbace_box_build_log_A_clinit() { A_arbace_box_build_log_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_333, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_box_build_log_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_log_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_log_A_class }

func (t *A_arbace_box_build_log_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_log_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_log_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_log_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_log_A); return ok }

func A_arbace_box_build_log_A_Cast(x any) *A_arbace_box_build_log_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_log_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_log_A_class)) }; return v }



type A_arbace_box_build_out_file_A struct{ jrt.Object }

func (t *A_arbace_box_build_out_file_A) Is_Compiler_AOTF3() {}

var A_arbace_box_build_out_file_A_fn_class *jrt.Class

var A_arbace_box_build_out_file_A_init jrt.ClassInit

func A_arbace_box_build_out_file_A_Init() { if !A_arbace_box_build_out_file_A_init.Done() { A_arbace_box_build_out_file_A_init.Run(A_arbace_box_build_out_file_A_clinit) } }

func A_arbace_box_build_out_file_A_clinit() { A_arbace_box_build_out_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_334, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_out_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_out_file_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_out_file_A_class }

func (t *A_arbace_box_build_out_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_out_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_out_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_out_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_out_file_A); return ok }

func A_arbace_box_build_out_file_A_Cast(x any) *A_arbace_box_build_out_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_out_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_out_file_A_class)) }; return v }



type A_arbace_box_build_read_plan_A struct{ jrt.Object }

func (t *A_arbace_box_build_read_plan_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_read_plan_A_fn_class *jrt.Class

var A_arbace_box_build_read_plan_A_init jrt.ClassInit

func A_arbace_box_build_read_plan_A_Init() { if !A_arbace_box_build_read_plan_A_init.Done() { A_arbace_box_build_read_plan_A_init.Run(A_arbace_box_build_read_plan_A_clinit) } }

func A_arbace_box_build_read_plan_A_clinit() { A_arbace_box_build_read_plan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_337, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_read_plan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_read_plan_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_read_plan_A_class }

func (t *A_arbace_box_build_read_plan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_read_plan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_read_plan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_read_plan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_read_plan_A); return ok }

func A_arbace_box_build_read_plan_A_Cast(x any) *A_arbace_box_build_read_plan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_read_plan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_read_plan_A_class)) }; return v }



type A_arbace_box_build_sha256_hex_A struct{ jrt.Object }

func (t *A_arbace_box_build_sha256_hex_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_sha256_hex_A_fn_class *jrt.Class

var A_arbace_box_build_sha256_hex_A_init jrt.ClassInit

func A_arbace_box_build_sha256_hex_A_Init() { if !A_arbace_box_build_sha256_hex_A_init.Done() { A_arbace_box_build_sha256_hex_A_init.Run(A_arbace_box_build_sha256_hex_A_clinit) } }

func A_arbace_box_build_sha256_hex_A_clinit() { A_arbace_box_build_sha256_hex_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_339, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_sha256_hex_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_sha256_hex_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_sha256_hex_A_class }

func (t *A_arbace_box_build_sha256_hex_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_sha256_hex_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_sha256_hex_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_sha256_hex_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_sha256_hex_A); return ok }

func A_arbace_box_build_sha256_hex_A_Cast(x any) *A_arbace_box_build_sha256_hex_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_sha256_hex_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_sha256_hex_A_class)) }; return v }



type A_arbace_box_build_source_tree_A struct{ jrt.Object }

func (t *A_arbace_box_build_source_tree_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_source_tree_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_A_Init() { if !A_arbace_box_build_source_tree_A_init.Done() { A_arbace_box_build_source_tree_A_init.Run(A_arbace_box_build_source_tree_A_clinit) } }

func A_arbace_box_build_source_tree_A_clinit() { A_arbace_box_build_source_tree_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_341, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_A_class }

func (t *A_arbace_box_build_source_tree_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_A); return ok }

func A_arbace_box_build_source_tree_A_Cast(x any) *A_arbace_box_build_source_tree_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_A_class)) }; return v }



type A_arbace_box_build_source_tree_headers__598000018_A struct{ jrt.Object }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_source_tree_headers__598000018_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_headers__598000018_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_headers__598000018_A_Init() { if !A_arbace_box_build_source_tree_headers__598000018_A_init.Done() { A_arbace_box_build_source_tree_headers__598000018_A_init.Run(A_arbace_box_build_source_tree_headers__598000018_A_clinit) } }

func A_arbace_box_build_source_tree_headers__598000018_A_clinit() { A_arbace_box_build_source_tree_headers__598000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_342, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_headers__598000018_A_class }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_headers__598000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_A); return ok }

func A_arbace_box_build_source_tree_headers__598000018_A_Cast(x any) *A_arbace_box_build_source_tree_headers__598000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_headers__598000018_A_class)) }; return v }



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A struct{ jrt.Object; F_headers any }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_Init() { if !A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_init.Done() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_init.Run(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_clinit) } }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_clinit() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_343, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A); return ok }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_Cast(x any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class)) }; return v }



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A struct{ jrt.Object; F_iter__598000019, F_headers, F_s__598000020 any }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_Init() { if !A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_init.Done() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_init.Run(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_clinit) } }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_clinit() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_344, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A); return ok }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_Cast(x any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class)) }; return v }



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A struct{ jrt.Object; F_headers, F_b__598000022 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_Init() { if !A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_init.Done() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_init.Run(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_clinit) } }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_clinit() { A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_346, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_class }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A); return ok }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_Cast(x any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_class)) }; return v }



type A_arbace_box_build_source_tree_iter__598000030__598000034_A struct{ jrt.Object; F_headers any }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_Init() { if !A_arbace_box_build_source_tree_iter__598000030__598000034_A_init.Done() { A_arbace_box_build_source_tree_iter__598000030__598000034_A_init.Run(A_arbace_box_build_source_tree_iter__598000030__598000034_A_clinit) } }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_clinit() { A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_347, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_iter__598000030__598000034_A_class }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_A); return ok }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_Cast(x any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_iter__598000030__598000034_A_class)) }; return v }



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A struct{ jrt.Object; F_headers, F_iter__598000030, F_s__598000031 any }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_Init() { if !A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_init.Done() { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_init.Run(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_clinit) } }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_clinit() { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_348, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A); return ok }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_Cast(x any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class)) }; return v }



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A struct{ jrt.Object; F_headers, F_b__598000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class *jrt.Class

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_init jrt.ClassInit

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_Init() { if !A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_init.Done() { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_init.Run(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_clinit) } }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_clinit() { A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_349, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_class }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A); return ok }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_Cast(x any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_class)) }; return v }



type A_arbace_box_build_with_tools_A struct{ jrt.Object }

func (t *A_arbace_box_build_with_tools_A) Is_Compiler_AOTF2() {}

var A_arbace_box_build_with_tools_A_fn_class *jrt.Class

var A_arbace_box_build_with_tools_A_init jrt.ClassInit

func A_arbace_box_build_with_tools_A_Init() { if !A_arbace_box_build_with_tools_A_init.Done() { A_arbace_box_build_with_tools_A_init.Run(A_arbace_box_build_with_tools_A_clinit) } }

func A_arbace_box_build_with_tools_A_clinit() { A_arbace_box_build_with_tools_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_350, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_with_tools_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_with_tools_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_with_tools_A_class }

func (t *A_arbace_box_build_with_tools_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_with_tools_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_with_tools_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_with_tools_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_with_tools_A); return ok }

func A_arbace_box_build_with_tools_A_Cast(x any) *A_arbace_box_build_with_tools_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_with_tools_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_with_tools_A_class)) }; return v }



type A_arbace_box_build_with_tools_iter__598000221__598000225_A struct{ jrt.Object; F_arch any }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Is_Compiler_AOTF1() {}

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class *jrt.Class

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_init jrt.ClassInit

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_Init() { if !A_arbace_box_build_with_tools_iter__598000221__598000225_A_init.Done() { A_arbace_box_build_with_tools_iter__598000221__598000225_A_init.Run(A_arbace_box_build_with_tools_iter__598000221__598000225_A_clinit) } }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_clinit() { A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_351, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_with_tools_iter__598000221__598000225_A_class }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_A); return ok }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_Cast(x any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_with_tools_iter__598000221__598000225_A_class)) }; return v }



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A struct{ jrt.Object; F_s__598000222, F_arch, F_iter__598000221 any }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class *jrt.Class

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_init jrt.ClassInit

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_Init() { if !A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_init.Done() { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_init.Run(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_clinit) } }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_clinit() { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_352, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A); return ok }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_Cast(x any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class)) }; return v }



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A struct{ jrt.Object; F_b__598000224, F_arch any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Is_Compiler_AOTF0() {}

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class *jrt.Class

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_init jrt.ClassInit

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_Init() { if !A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_init.Done() { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_init.Run(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_clinit) } }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_clinit() { A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_355, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_class }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A); return ok }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_Cast(x any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_class)) }; return v }
