//line j2g_up.ae:1
package aot_arbace_box_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_PersistentVector_IPersistentVector(p *lang.PersistentVector) lang.IPersistentVector { if p == nil { return nil }; return p }

func Up_Long_Number(p *jrt.Long) jrt.Number_I { if p == nil { return nil }; return p }
