//line aot_arbace_box_build__init.ae:1
package aot_arbace_box_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build__init_A_Unit0__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_build__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_build__init_A_const_1) }
//line :4:1
func A_arbace_box_build__init_A_Unit1__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_build__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_2)) }
//line :4:1
func A_arbace_box_build__init_A_Unit2__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); var tmp1 any = A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_Init(); tmp2 = A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :4:1
func A_arbace_box_build__init_A_Unit3__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_build__init_A_const_1)).Equals_O__Z(A_arbace_box_build__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_build_eval598000008_fn__598000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_build_eval598000008_fn__598000009_A_Init(); tmp2 = A_arbace_box_build_eval598000008_fn__598000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
func A_arbace_box_build__init_A_Load__O() any { A_arbace_box_build__init_A_Init(); A_arbace_box_build__init_A_Unit0__O(); A_arbace_box_build__init_A_Unit1__O(); A_arbace_box_build__init_A_Unit2__O(); A_arbace_box_build__init_A_Unit3__O(); A_arbace_box_build__init_A_Unit4__O(); A_arbace_box_build__init_A_Unit5__O(); A_arbace_box_build__init_A_Unit6__O(); A_arbace_box_build__init_A_Unit7__O(); A_arbace_box_build__init_A_Unit8__O(); A_arbace_box_build__init_A_Unit9__O(); A_arbace_box_build__init_A_Unit10__O(); A_arbace_box_build__init_A_Unit11__O(); A_arbace_box_build__init_A_Unit12__O(); A_arbace_box_build__init_A_Unit13__O(); A_arbace_box_build__init_A_Unit14__O(); A_arbace_box_build__init_A_Unit15__O(); A_arbace_box_build__init_A_Unit16__O(); A_arbace_box_build__init_A_Unit17__O(); A_arbace_box_build__init_A_Unit18__O(); A_arbace_box_build__init_A_Unit19__O(); A_arbace_box_build__init_A_Unit20__O(); A_arbace_box_build__init_A_Unit21__O(); A_arbace_box_build__init_A_Unit22__O(); A_arbace_box_build__init_A_Unit23__O(); A_arbace_box_build__init_A_Unit24__O(); A_arbace_box_build__init_A_Unit25__O(); A_arbace_box_build__init_A_Unit26__O(); A_arbace_box_build__init_A_Unit27__O(); A_arbace_box_build__init_A_Unit28__O(); A_arbace_box_build__init_A_Unit29__O(); return nil }






































func A_arbace_box_build__init_A_Unit4__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_4; var tmp2 any = A_arbace_box_build_fail_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_fail_A_Init(); tmp3 = A_arbace_box_build_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_5)); return A_arbace_box_build__init_A_const_4.Ref() }


func A_arbace_box_build__init_A_Unit5__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_6; var tmp2 any = A_arbace_box_build_sha256_hex_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_sha256_hex_A_Init(); tmp3 = A_arbace_box_build_sha256_hex_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_7)); return A_arbace_box_build__init_A_const_6.Ref() }











func A_arbace_box_build__init_A_Unit6__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_8; var tmp2 any = A_arbace_box_build_source_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_source_tree_A_Init(); tmp3 = A_arbace_box_build_source_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_9)); return A_arbace_box_build__init_A_const_8.Ref() }






















func A_arbace_box_build__init_A_Unit7__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_10; var tmp2 any = A_arbace_box_build_import_plan_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_import_plan_A_Init(); tmp3 = A_arbace_box_build_import_plan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_11)); return A_arbace_box_build__init_A_const_10.Ref() }















func A_arbace_box_build__init_A_Unit8__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(98, 1); jrt.NN(A_arbace_box_build__init_A_const_12).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_13)); return jrt.NN(A_arbace_box_build__init_A_const_12).SetDynamic_Z__Var(true).Ref() }

func A_arbace_box_build__init_A_Unit9__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_14; var tmp2 any = A_arbace_box_build_log_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_log_A_Init(); tmp3 = A_arbace_box_build_log_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_15)); return A_arbace_box_build__init_A_const_14.Ref() }


func A_arbace_box_build__init_A_Unit10__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_16; var tmp2 any = A_arbace_box_build_cache_ref_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_cache_ref_A_Init(); tmp3 = A_arbace_box_build_cache_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_17)); return A_arbace_box_build__init_A_const_16.Ref() }


func A_arbace_box_build__init_A_Unit11__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_18; var tmp2 any = A_arbace_box_build_action_STAR__A_New(); var tmp3 *jrt.Class; A_arbace_box_build_action_STAR__A_Init(); tmp3 = A_arbace_box_build_action_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_19)); return A_arbace_box_build__init_A_const_18.Ref() }

















func A_arbace_box_build__init_A_Unit12__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_20; var tmp2 any = A_arbace_box_build_action_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_action_A_Init(); tmp3 = A_arbace_box_build_action_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_21)); return A_arbace_box_build__init_A_const_20.Ref() }






func A_arbace_box_build__init_A_Unit13__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_22; var tmp2 any = A_arbace_box_build_out_file_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_out_file_A_Init(); tmp3 = A_arbace_box_build_out_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_23)); return A_arbace_box_build__init_A_const_22.Ref() }





func A_arbace_box_build__init_A_Unit14__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_24; var tmp2 any = A_arbace_box_build_file_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_file_tree_A_Init(); tmp3 = A_arbace_box_build_file_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_25)); return A_arbace_box_build__init_A_const_24.Ref() }




func A_arbace_box_build__init_A_Unit15__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_26; var tmp2 any = A_arbace_box_build_arch_defines_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_arch_defines_A_Init(); tmp3 = A_arbace_box_build_arch_defines_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_27)); return A_arbace_box_build__init_A_const_26.Ref() }







func A_arbace_box_build__init_A_Unit16__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_28; var tmp2 any = A_arbace_box_build_asm_args_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_asm_args_A_Init(); tmp3 = A_arbace_box_build_asm_args_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_29)); return A_arbace_box_build__init_A_const_28.Ref() }







func A_arbace_box_build__init_A_Unit17__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_30; var tmp2 any = A_arbace_box_build_ar_member_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_ar_member_A_Init(); tmp3 = A_arbace_box_build_ar_member_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_31)); return A_arbace_box_build__init_A_const_30.Ref() }








func A_arbace_box_build__init_A_Unit18__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_32; var tmp2 any = A_arbace_box_build_append_members_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_append_members_A_Init(); tmp3 = A_arbace_box_build_append_members_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_33)); return A_arbace_box_build__init_A_const_32.Ref() }





func A_arbace_box_build__init_A_Unit19__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); jrt.NN(A_arbace_box_build__init_A_const_34).BindRoot_O__V(A_arbace_box_build__init_A_const_35); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_34; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_36)); return A_arbace_box_build__init_A_const_34.Ref() }




func A_arbace_box_build__init_A_Unit20__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_37; var tmp2 any = A_arbace_box_build_complete_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_box_build_complete_QMARK__A_Init(); tmp3 = A_arbace_box_build_complete_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_38)); return A_arbace_box_build__init_A_const_37.Ref() }




func A_arbace_box_build__init_A_Unit21__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_39; var tmp2 any = A_arbace_box_build_deps_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_deps_tree_A_Init(); tmp3 = A_arbace_box_build_deps_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_40)); return A_arbace_box_build__init_A_const_39.Ref() }






func A_arbace_box_build__init_A_Unit22__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_41; var tmp2 any = A_arbace_box_build_json_str_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_json_str_A_Init(); tmp3 = A_arbace_box_build_json_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_42)); return A_arbace_box_build__init_A_const_41.Ref() }








func A_arbace_box_build__init_A_Unit23__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(199, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_43; var tmp2 any = A_arbace_box_build_embed_config_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_embed_config_A_Init(); tmp3 = A_arbace_box_build_embed_config_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_44)); return A_arbace_box_build__init_A_const_43.Ref() }











func A_arbace_box_build__init_A_Unit24__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(211, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_45; var tmp2 any = A_arbace_box_build_build_package_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_build_package_A_Init(); tmp3 = A_arbace_box_build_build_package_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_46)); return A_arbace_box_build__init_A_const_45.Ref() }
































































func A_arbace_box_build__init_A_Unit25__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(276, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_47; var tmp2 any = A_arbace_box_build_read_plan_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_read_plan_A_Init(); tmp3 = A_arbace_box_build_read_plan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_48)); return A_arbace_box_build__init_A_const_47.Ref() }




func A_arbace_box_build__init_A_Unit26__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(281, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_49; var tmp2 any = A_arbace_box_build_with_tools_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_with_tools_A_Init(); tmp3 = A_arbace_box_build_with_tools_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_50)); return A_arbace_box_build__init_A_const_49.Ref() }









func A_arbace_box_build__init_A_Unit27__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(291, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_51; var tmp2 any = A_arbace_box_build_archives_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_archives_A_Init(); tmp3 = A_arbace_box_build_archives_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_52)); return A_arbace_box_build__init_A_const_51.Ref() }






























func A_arbace_box_build__init_A_Unit28__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_53; var tmp2 any = A_arbace_box_build_link_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_link_A_Init(); tmp3 = A_arbace_box_build_link_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_54)); return A_arbace_box_build__init_A_const_53.Ref() }























func A_arbace_box_build__init_A_Unit29__O() any { A_arbace_box_build__init_A_Init(); lang.Compiler_AOT_At_I_I__V(346, 1); var tmp1 *lang.Var = A_arbace_box_build__init_A_const_55; var tmp2 any = A_arbace_box_build_build_A_New(); var tmp3 *jrt.Class; A_arbace_box_build_build_A_Init(); tmp3 = A_arbace_box_build_build_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_build__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_build__init_A_const_56)); return A_arbace_box_build__init_A_const_55.Ref() }



type A_arbace_box_build__init_A struct{ jrt.Object }

var A_arbace_box_build__init_A_const_0 *lang.Var

var A_arbace_box_build__init_A_const_1 any

var A_arbace_box_build__init_A_const_2 any

var A_arbace_box_build__init_A_const_3 any

var A_arbace_box_build__init_A_const_4 *lang.Var

var A_arbace_box_build__init_A_const_5 any

var A_arbace_box_build__init_A_const_6 *lang.Var

var A_arbace_box_build__init_A_const_7 any

var A_arbace_box_build__init_A_const_8 *lang.Var

var A_arbace_box_build__init_A_const_9 any

var A_arbace_box_build__init_A_const_10 *lang.Var

var A_arbace_box_build__init_A_const_11 any

var A_arbace_box_build__init_A_const_12 *lang.Var

var A_arbace_box_build__init_A_const_13 any

var A_arbace_box_build__init_A_const_14 *lang.Var

var A_arbace_box_build__init_A_const_15 any

var A_arbace_box_build__init_A_const_16 *lang.Var

var A_arbace_box_build__init_A_const_17 any

var A_arbace_box_build__init_A_const_18 *lang.Var

var A_arbace_box_build__init_A_const_19 any

var A_arbace_box_build__init_A_const_20 *lang.Var

var A_arbace_box_build__init_A_const_21 any

var A_arbace_box_build__init_A_const_22 *lang.Var

var A_arbace_box_build__init_A_const_23 any

var A_arbace_box_build__init_A_const_24 *lang.Var

var A_arbace_box_build__init_A_const_25 any

var A_arbace_box_build__init_A_const_26 *lang.Var

var A_arbace_box_build__init_A_const_27 any

var A_arbace_box_build__init_A_const_28 *lang.Var

var A_arbace_box_build__init_A_const_29 any

var A_arbace_box_build__init_A_const_30 *lang.Var

var A_arbace_box_build__init_A_const_31 any

var A_arbace_box_build__init_A_const_32 *lang.Var

var A_arbace_box_build__init_A_const_33 any

var A_arbace_box_build__init_A_const_34 *lang.Var

var A_arbace_box_build__init_A_const_35 any

var A_arbace_box_build__init_A_const_36 any

var A_arbace_box_build__init_A_const_37 *lang.Var

var A_arbace_box_build__init_A_const_38 any

var A_arbace_box_build__init_A_const_39 *lang.Var

var A_arbace_box_build__init_A_const_40 any

var A_arbace_box_build__init_A_const_41 *lang.Var

var A_arbace_box_build__init_A_const_42 any

var A_arbace_box_build__init_A_const_43 *lang.Var

var A_arbace_box_build__init_A_const_44 any

var A_arbace_box_build__init_A_const_45 *lang.Var

var A_arbace_box_build__init_A_const_46 any

var A_arbace_box_build__init_A_const_47 *lang.Var

var A_arbace_box_build__init_A_const_48 any

var A_arbace_box_build__init_A_const_49 *lang.Var

var A_arbace_box_build__init_A_const_50 any

var A_arbace_box_build__init_A_const_51 *lang.Var

var A_arbace_box_build__init_A_const_52 any

var A_arbace_box_build__init_A_const_53 *lang.Var

var A_arbace_box_build__init_A_const_54 any

var A_arbace_box_build__init_A_const_55 *lang.Var

var A_arbace_box_build__init_A_const_56 any

var A_arbace_box_build__init_A_init jrt.ClassInit

func A_arbace_box_build__init_A_Init() { if !A_arbace_box_build__init_A_init.Done() { A_arbace_box_build__init_A_init.Run(A_arbace_box_build__init_A_clinit) } }

func A_arbace_box_build__init_A_clinit() { A_arbace_box_build__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_356); A_arbace_box_build__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_box_build__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_box_build__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_build__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_69); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_build__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_359).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_360).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_13, Lit_58); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_box_build__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_13, Lit_40); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_box_build__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_367)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_368).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_369, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_13, Lit_52); A_arbace_box_build__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_370).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_371, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_13, Lit_54); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_box_build__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(98).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_13, Lit_53); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_box_build__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_373).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_374).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_box_build__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(103).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_box_build__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(106).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_13, Lit_376); A_arbace_box_build__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_378, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_13, Lit_124); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_box_build__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_379).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_380, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_13, Lit_138); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_box_build__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_381).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_382, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(137).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_13, Lit_94); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_box_build__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_13, Lit_137); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_box_build__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_383).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_373).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_384).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_97); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_box_build__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_143)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_360)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_385).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_385).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_13, Lit_162); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_box_build__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_386)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_385).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_387).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_385).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_13, Lit_100); A_arbace_box_build__init_A_const_35 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,10,s2:oss3:nets4:syncs7:syscalls13:runtime/pprofs5:bytess4:times13:internal/polls15:runtime/metricss13:runtime/trace", []*jrt.Class{jrt.Object_class})).Ref(); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_box_build__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_388)); A_arbace_box_build__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_13, Lit_145); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_box_build__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_383).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_389, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_13, Lit_113); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_box_build__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_390).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_391).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_392, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(183).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_13, Lit_107); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_box_build__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_365).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_393, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_123); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_box_build__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_394, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(199).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_13, Lit_174); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_box_build__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_383).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_390).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_395, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(211).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_13, Lit_168); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_box_build__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(276).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_13, Lit_169); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_357).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_box_build__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_396).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_397, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(281).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_13, Lit_170); A_arbace_box_build__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_398, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(291).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_167); A_arbace_box_build__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_399, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(322).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)); A_arbace_box_build__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_13, Lit_182); A_arbace_box_build__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_358).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_400, lang.RT_Keyword_String_String__Keyword(nil, Lit_361).Ref(), jrt.Integer_ValueOf_I__Integer(346).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), Lit_364)) }

func A_arbace_box_build__init_A_New() *A_arbace_box_build__init_A { A_arbace_box_build__init_A_Init(); t := &A_arbace_box_build__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build__init_A) Ctor() {}

func (t *A_arbace_box_build__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_build__init_A_class }

func (t *A_arbace_box_build__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build__init_A); return ok }

func A_arbace_box_build__init_A_Cast(x any) *A_arbace_box_build__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build__init_A_class)) }; return v }
