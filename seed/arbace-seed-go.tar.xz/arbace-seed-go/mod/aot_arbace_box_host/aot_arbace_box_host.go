//line aot_arbace_box_host.ae:1
package aot_arbace_box_host

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_New() *A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A{}; t.Ctor(); return t }
//line :6:1
func (t *A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A) Ctor() {}
//line :6:1
func (t *A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_host_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_host_A_const_1, A_arbace_box_host_A_const_2, A_arbace_box_host_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :6:1
func A_arbace_box_host_eval26000008_fn__26000009_A_New() *A_arbace_box_host_eval26000008_fn__26000009_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_eval26000008_fn__26000009_A{}; t.Ctor(); return t }
//line :6:1
func (t *A_arbace_box_host_eval26000008_fn__26000009_A) Ctor() {}
//line :6:1
func (t *A_arbace_box_host_eval26000008_fn__26000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_host_A_const_4.GetRawRoot__O()); var tmp2 any; var root_13 any = A_arbace_box_host_A_const_5.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_15 lang.IFn; if linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_box_host_A_const_6; if linked_14 == nil { tmp2 = ifn_15.Invoke_O__O(arg_16) } else { tmp2 = linked_14.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_13, arg_16) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_host_A_const_7.GetRawRoot__O(), A_arbace_box_host_A_const_8) }





func A_arbace_box_host_status_A_New() *A_arbace_box_host_status_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_status_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_box_host_status_A) Ctor() {}
//line :12:1
func (t *A_arbace_box_host_status_A) Invoke_O__O(self any) any {


	return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.HostStore_Status__I()).Ref()
}
func A_arbace_box_host_put_A_New() *A_arbace_box_host_put_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_put_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_box_host_put_A) Ctor() {}
//line :17:1
func (t *A_arbace_box_host_put_A) Invoke_O_O_O__O(self, b__0, h__1 any) any {


	return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.HostStore_Put_B1_I_I_B1__I(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)), jrt.ByteArray_Cast(h__1))).Ref()
}
func A_arbace_box_host_size_A_New() *A_arbace_box_host_size_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_size_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_box_host_size_A) Ctor() {}
//line :22:1
func (t *A_arbace_box_host_size_A) Invoke_O_O__O(self, h__0 any) any {


	return jrt.Long_ValueOf_J__Long_NoInit(jrt.HostStore_Size_B1__J(jrt.ByteArray_Cast(h__0))).Ref()
}
func A_arbace_box_host_read_A_New() *A_arbace_box_host_read_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_read_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_box_host_read_A) Ctor() {}
//line :27:1
func (t *A_arbace_box_host_read_A) Invoke_O_O__O(self, h__0 any) any {


	return jrt.HostStore_Read_B1__B1(jrt.ByteArray_Cast(h__0)).Ref()
}
func A_arbace_box_host_ref_A_New() *A_arbace_box_host_ref_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_ref_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_host_ref_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_host_ref_A) Invoke_O_O_O__O(self, name__0, h__1 any) any {


	return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.HostStore_Ref_String_B1__I(jrt.String_Cast(name__0), jrt.ByteArray_Cast(h__1))).Ref()
}
func A_arbace_box_host_set_ref_A_New() *A_arbace_box_host_set_ref_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_set_ref_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_box_host_set_ref_A) Ctor() {}
//line :37:1
func (t *A_arbace_box_host_set_ref_A) Invoke_O_O_O_O__O(self, name__0, h__1, old__2 any) any {



	return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.HostStore_SetRef_String_B1_B1__I(jrt.String_Cast(name__0), jrt.ByteArray_Cast(h__1), jrt.ByteArray_Cast(old__2))).Ref()
}
func A_arbace_box_host_tar_A_New() *A_arbace_box_host_tar_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_tar_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_box_host_tar_A) Ctor() {}
//line :43:1
func (t *A_arbace_box_host_tar_A) Invoke_O_O_O__O(self, dir__0, err__1 any) any {


	return jrt.HostStore_Tar_String_String1__B1(jrt.String_Cast(dir__0), jrt.RefArray_Cast(err__1, jrt.String_class)).Ref()
}
func A_arbace_box_host_untar_A_New() *A_arbace_box_host_untar_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_untar_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_box_host_untar_A) Ctor() {}
//line :48:1
func (t *A_arbace_box_host_untar_A) Invoke_O_O_O__O(self, tar__0, dir__1 any) any {


	return jrt.HostStore_Untar_B1_String__String(jrt.ByteArray_Cast(tar__0), jrt.String_Cast(dir__1)).Ref()
}
func A_arbace_box_host_spawn_A_New() *A_arbace_box_host_spawn_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_spawn_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_host_spawn_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_host_spawn_A) InvokePrim_O_O__J(self, h__0 any) int64 {


	return jrt.HostSpawn_Start_B1__J(jrt.ByteArray_Cast(h__0)) }
//line :53:1
func (t *A_arbace_box_host_spawn_A) Invoke_O_O__O(self, h__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, h__0)).Ref() }




func A_arbace_box_host_spawn_poll_A_New() *A_arbace_box_host_spawn_poll_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_spawn_poll_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_box_host_spawn_poll_A) Ctor() {}
//line :58:1
func (t *A_arbace_box_host_spawn_poll_A) InvokePrim_O_J_O__J(self any, n__0 int64, h__1 any) int64 {



	return int64(jrt.HostSpawn_Poll_J_B1__I(n__0, jrt.ByteArray_Cast(h__1))) }
//line :58:1
func (t *A_arbace_box_host_spawn_poll_A) Invoke_O_O_O__O(self, p_n__0, h__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_O__J(self, lang.RT_LongCast_O__J_NoInit(p_n__0), h__1)).Ref() }





func A_arbace_box_host_spawn_await_A_New() *A_arbace_box_host_spawn_await_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_spawn_await_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_host_spawn_await_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_host_spawn_await_A) InvokePrim_O_J_O__J(self any, n__0 int64, h__1 any) int64 {


	return int64(jrt.HostSpawn_Await_J_B1__I(n__0, jrt.ByteArray_Cast(h__1))) }
//line :64:1
func (t *A_arbace_box_host_spawn_await_A) Invoke_O_O_O__O(self, p_n__0, h__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_O__J(self, lang.RT_LongCast_O__J_NoInit(p_n__0), h__1)).Ref() }



























type A_arbace_box_host_A struct{ jrt.Object }

var A_arbace_box_host_A_const_pool *jrt.RefArray

var A_arbace_box_host_A_const_0 *lang.Var

var A_arbace_box_host_A_const_1 any

var A_arbace_box_host_A_const_2 *lang.Keyword

var A_arbace_box_host_A_const_3 any

var A_arbace_box_host_A_const_4 *lang.Var

var A_arbace_box_host_A_const_5 *lang.Var

var A_arbace_box_host_A_const_6 *lang.Var

var A_arbace_box_host_A_const_7 *lang.Var

var A_arbace_box_host_A_const_8 any

var A_arbace_box_host_A_init jrt.ClassInit

func A_arbace_box_host_A_Init() { if !A_arbace_box_host_A_init.Done() { A_arbace_box_host_A_init.Run(A_arbace_box_host_A_clinit) } }

func A_arbace_box_host_A_clinit() { jrt.StartCheck(); A_arbace_box_host_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 14); A_arbace_box_host_A_const_0 = lang.Var_Cast(A_arbace_box_host_A_const_pool.A[5]); A_arbace_box_host_A_const_1 = A_arbace_box_host_A_const_pool.A[6]; A_arbace_box_host_A_const_2 = lang.Keyword_Cast(A_arbace_box_host_A_const_pool.A[7]); A_arbace_box_host_A_const_3 = A_arbace_box_host_A_const_pool.A[8]; A_arbace_box_host_A_const_4 = lang.Var_Cast(A_arbace_box_host_A_const_pool.A[9]); A_arbace_box_host_A_const_5 = lang.Var_Cast(A_arbace_box_host_A_const_pool.A[10]); A_arbace_box_host_A_const_6 = lang.Var_Cast(A_arbace_box_host_A_const_pool.A[11]); A_arbace_box_host_A_const_7 = lang.Var_Cast(A_arbace_box_host_A_const_pool.A[12]); A_arbace_box_host_A_const_8 = A_arbace_box_host_A_const_pool.A[13] }

func A_arbace_box_host_A_New() *A_arbace_box_host_A { A_arbace_box_host_A_Init(); t := &A_arbace_box_host_A{}; t.Ctor(); return t }

func (t *A_arbace_box_host_A) Ctor() {}

func (t *A_arbace_box_host_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_host_A) GetClass__Class() *jrt.Class { return A_arbace_box_host_A_class }

func (t *A_arbace_box_host_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_host_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_host_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_host_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_host_A); return ok }

func A_arbace_box_host_A_Cast(x any) *A_arbace_box_host_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_host_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_host_A_class)) }; return v }



type A_arbace_box_host_eval26000004_A struct{ jrt.Object }

func A_arbace_box_host_eval26000004_A_New() *A_arbace_box_host_eval26000004_A { t := &A_arbace_box_host_eval26000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_host_eval26000004_A) Ctor() {}

func (t *A_arbace_box_host_eval26000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_host_eval26000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_host_eval26000004_A_class }

func (t *A_arbace_box_host_eval26000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_host_eval26000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_host_eval26000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_host_eval26000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_host_eval26000004_A); return ok }

func A_arbace_box_host_eval26000004_A_Cast(x any) *A_arbace_box_host_eval26000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_host_eval26000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_host_eval26000004_A_class)) }; return v }



type A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A struct{ j2g_header uint64 }

var A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_fn_class *jrt.Class



type A_arbace_box_host_eval26000008_A struct{ jrt.Object }

func A_arbace_box_host_eval26000008_A_New() *A_arbace_box_host_eval26000008_A { t := &A_arbace_box_host_eval26000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_host_eval26000008_A) Ctor() {}

func (t *A_arbace_box_host_eval26000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_host_eval26000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_host_eval26000008_A_class }

func (t *A_arbace_box_host_eval26000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_host_eval26000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_host_eval26000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_host_eval26000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_host_eval26000008_A); return ok }

func A_arbace_box_host_eval26000008_A_Cast(x any) *A_arbace_box_host_eval26000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_host_eval26000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_host_eval26000008_A_class)) }; return v }



type A_arbace_box_host_eval26000008_fn__26000009_A struct{ j2g_header uint64 }

var A_arbace_box_host_eval26000008_fn__26000009_A_fn_class *jrt.Class



type A_arbace_box_host_put_A struct{ j2g_header uint64 }

var A_arbace_box_host_put_A_fn_class *jrt.Class



type A_arbace_box_host_read_A struct{ j2g_header uint64 }

var A_arbace_box_host_read_A_fn_class *jrt.Class



type A_arbace_box_host_ref_A struct{ j2g_header uint64 }

var A_arbace_box_host_ref_A_fn_class *jrt.Class



type A_arbace_box_host_set_ref_A struct{ j2g_header uint64 }

var A_arbace_box_host_set_ref_A_fn_class *jrt.Class



type A_arbace_box_host_size_A struct{ j2g_header uint64 }

var A_arbace_box_host_size_A_fn_class *jrt.Class



type A_arbace_box_host_spawn_A struct{ j2g_header uint64 }

var A_arbace_box_host_spawn_A_fn_class *jrt.Class



type A_arbace_box_host_spawn_await_A struct{ j2g_header uint64 }

var A_arbace_box_host_spawn_await_A_fn_class *jrt.Class



type A_arbace_box_host_spawn_poll_A struct{ j2g_header uint64 }

var A_arbace_box_host_spawn_poll_A_fn_class *jrt.Class



type A_arbace_box_host_status_A struct{ j2g_header uint64 }

var A_arbace_box_host_status_A_fn_class *jrt.Class



type A_arbace_box_host_tar_A struct{ j2g_header uint64 }

var A_arbace_box_host_tar_A_fn_class *jrt.Class



type A_arbace_box_host_untar_A struct{ j2g_header uint64 }

var A_arbace_box_host_untar_A_fn_class *jrt.Class
