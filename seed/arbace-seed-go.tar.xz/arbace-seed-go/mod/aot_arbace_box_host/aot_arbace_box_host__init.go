//line aot_arbace_box_host__init.ae:1
package aot_arbace_box_host

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_host__init_A_Load__O() any { A_arbace_box_host__init_A_Init(); A_arbace_box_host__init_A_Unit0__O(); A_arbace_box_host__init_A_Unit1__O(); A_arbace_box_host__init_A_Unit2__O(); A_arbace_box_host__init_A_Unit3__O(); A_arbace_box_host__init_A_Unit4__O(); A_arbace_box_host__init_A_Unit5__O(); A_arbace_box_host__init_A_Unit6__O(); A_arbace_box_host__init_A_Unit7__O(); A_arbace_box_host__init_A_Unit8__O(); A_arbace_box_host__init_A_Unit9__O(); A_arbace_box_host__init_A_Unit10__O(); A_arbace_box_host__init_A_Unit11__O(); A_arbace_box_host__init_A_Unit12__O(); A_arbace_box_host__init_A_Unit13__O(); A_arbace_box_host__init_A_Unit14__O(); return nil }
func A_arbace_box_host__init_A_Unit0__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_host__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_host__init_A_const_1) }
//line :6:1
func A_arbace_box_host__init_A_Unit1__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_host__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_2)) }
//line :6:1
func A_arbace_box_host__init_A_Unit2__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6, 1); var tmp1 any = A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_Init(); tmp2 = A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :6:1
func A_arbace_box_host__init_A_Unit3__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_host__init_A_const_1)).Equals_O__Z(A_arbace_box_host__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_host_eval26000008_fn__26000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_host_eval26000008_fn__26000009_A_Init(); tmp2 = A_arbace_box_host_eval26000008_fn__26000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_box_host__init_A_Unit4__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_4; var tmp2 any = A_arbace_box_host_status_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_status_A_Init(); tmp3 = A_arbace_box_host_status_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_5)); return A_arbace_box_host__init_A_const_4.Ref() }




func A_arbace_box_host__init_A_Unit5__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_6; var tmp2 any = A_arbace_box_host_put_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_put_A_Init(); tmp3 = A_arbace_box_host_put_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_7)); return A_arbace_box_host__init_A_const_6.Ref() }




func A_arbace_box_host__init_A_Unit6__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_8; var tmp2 any = A_arbace_box_host_size_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_size_A_Init(); tmp3 = A_arbace_box_host_size_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_9)); return A_arbace_box_host__init_A_const_8.Ref() }




func A_arbace_box_host__init_A_Unit7__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_10; var tmp2 any = A_arbace_box_host_read_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_read_A_Init(); tmp3 = A_arbace_box_host_read_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_11)); return A_arbace_box_host__init_A_const_10.Ref() }




func A_arbace_box_host__init_A_Unit8__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_12; var tmp2 any = A_arbace_box_host_ref_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_ref_A_Init(); tmp3 = A_arbace_box_host_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_13)); return A_arbace_box_host__init_A_const_12.Ref() }




func A_arbace_box_host__init_A_Unit9__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_14; var tmp2 any = A_arbace_box_host_set_ref_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_set_ref_A_Init(); tmp3 = A_arbace_box_host_set_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_15)); return A_arbace_box_host__init_A_const_14.Ref() }





func A_arbace_box_host__init_A_Unit10__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_16; var tmp2 any = A_arbace_box_host_tar_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_tar_A_Init(); tmp3 = A_arbace_box_host_tar_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_17)); return A_arbace_box_host__init_A_const_16.Ref() }




func A_arbace_box_host__init_A_Unit11__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_18; var tmp2 any = A_arbace_box_host_untar_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_untar_A_Init(); tmp3 = A_arbace_box_host_untar_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_19)); return A_arbace_box_host__init_A_const_18.Ref() }




func A_arbace_box_host__init_A_Unit12__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_20; var tmp2 any = A_arbace_box_host_spawn_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_spawn_A_Init(); tmp3 = A_arbace_box_host_spawn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_21)); return A_arbace_box_host__init_A_const_20.Ref() }




func A_arbace_box_host__init_A_Unit13__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_22; var tmp2 any = A_arbace_box_host_spawn_poll_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_spawn_poll_A_Init(); tmp3 = A_arbace_box_host_spawn_poll_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_23)); return A_arbace_box_host__init_A_const_22.Ref() }





func A_arbace_box_host__init_A_Unit14__O() any { A_arbace_box_host__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_box_host__init_A_const_24; var tmp2 any = A_arbace_box_host_spawn_await_A_New(); var tmp3 *jrt.Class; A_arbace_box_host_spawn_await_A_Init(); tmp3 = A_arbace_box_host_spawn_await_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_host__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_host__init_A_const_25)); return A_arbace_box_host__init_A_const_24.Ref() }



type A_arbace_box_host__init_A struct{ jrt.Object }

var A_arbace_box_host__init_A_const_0 *lang.Var

var A_arbace_box_host__init_A_const_1 any

var A_arbace_box_host__init_A_const_2 any

var A_arbace_box_host__init_A_const_3 any

var A_arbace_box_host__init_A_const_4 *lang.Var

var A_arbace_box_host__init_A_const_5 any

var A_arbace_box_host__init_A_const_6 *lang.Var

var A_arbace_box_host__init_A_const_7 any

var A_arbace_box_host__init_A_const_8 *lang.Var

var A_arbace_box_host__init_A_const_9 any

var A_arbace_box_host__init_A_const_10 *lang.Var

var A_arbace_box_host__init_A_const_11 any

var A_arbace_box_host__init_A_const_12 *lang.Var

var A_arbace_box_host__init_A_const_13 any

var A_arbace_box_host__init_A_const_14 *lang.Var

var A_arbace_box_host__init_A_const_15 any

var A_arbace_box_host__init_A_const_16 *lang.Var

var A_arbace_box_host__init_A_const_17 any

var A_arbace_box_host__init_A_const_18 *lang.Var

var A_arbace_box_host__init_A_const_19 any

var A_arbace_box_host__init_A_const_20 *lang.Var

var A_arbace_box_host__init_A_const_21 any

var A_arbace_box_host__init_A_const_22 *lang.Var

var A_arbace_box_host__init_A_const_23 any

var A_arbace_box_host__init_A_const_24 *lang.Var

var A_arbace_box_host__init_A_const_25 any

var A_arbace_box_host__init_A_init jrt.ClassInit

func A_arbace_box_host__init_A_Init() { if !A_arbace_box_host__init_A_init.Done() { A_arbace_box_host__init_A_init.Run(A_arbace_box_host__init_A_clinit) } }

func A_arbace_box_host__init_A_clinit() { A_arbace_box_host__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_box_host__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10))); A_arbace_box_host__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_box_host__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_host__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_8, Lit_28); A_arbace_box_host__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_8, Lit_35); A_arbace_box_host__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_36)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_8, Lit_41); A_arbace_box_host__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_42, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_8, Lit_3); A_arbace_box_host__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_8, Lit_4); A_arbace_box_host__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_8, Lit_47); A_arbace_box_host__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_48)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_49, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_8, Lit_50); A_arbace_box_host__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_51)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_53, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_8, Lit_54); A_arbace_box_host__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_50)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_51)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_55, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_8, Lit_56); A_arbace_box_host__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_58, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_8, Lit_59); A_arbace_box_host__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)); A_arbace_box_host__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_8, Lit_62); A_arbace_box_host__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_63, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), Lit_34)) }

func A_arbace_box_host__init_A_New() *A_arbace_box_host__init_A { A_arbace_box_host__init_A_Init(); t := &A_arbace_box_host__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_host__init_A) Ctor() {}

func (t *A_arbace_box_host__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_host__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_host__init_A_class }

func (t *A_arbace_box_host__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_host__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_host__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_host__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_host__init_A); return ok }

func A_arbace_box_host__init_A_Cast(x any) *A_arbace_box_host__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_host__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_host__init_A_class)) }; return v }
