//line a2g_classes.ae:1
package aot_arbace_box_host

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_host_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_A_New()}; return nil }

var A_arbace_box_host_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_A_new}

var A_arbace_box_host_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_host.A_arbace_box_host_A"})

func init() { i := A_arbace_box_host_A_class.Info(); i.IsInstance = A_arbace_box_host_A_InstanceOf; i.Init = A_arbace_box_host_A_Init; i.Table = A_arbace_box_host_A_members; jrt.RegisterGoType(A_arbace_box_host_A_class, reflect.TypeFor[A_arbace_box_host_A]()) }

func A_arbace_box_host_eval26000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000004_A_New()}; return nil }

var A_arbace_box_host_eval26000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_eval26000004_A_new}

var A_arbace_box_host_eval26000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_host_A_class, Simple: "eval26000004", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000004_A"})

func init() { i := A_arbace_box_host_eval26000004_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000004_A_InstanceOf; i.Table = A_arbace_box_host_eval26000004_A_members; jrt.RegisterGoType(A_arbace_box_host_eval26000004_A_class, reflect.TypeFor[A_arbace_box_host_eval26000004_A]()) }

func A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_New()}; return nil }

func A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_fn_class)}; return nil }

var A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_invoke, New: A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_new, Get: A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_get}

var A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000004$loading__1927001464__auto____26000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_host_eval26000004_A_class, Simple: "loading__1927001464__auto____26000005", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_InstanceOf; i.Init = A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_Init; i.Table = A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_members; jrt.RegisterGoType(A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_class, reflect.TypeFor[A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A]()) }

func A_arbace_box_host_eval26000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000008_A_New()}; return nil }

var A_arbace_box_host_eval26000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_eval26000008_A_new}

var A_arbace_box_host_eval26000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_host_A_class, Simple: "eval26000008", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000008_A"})

func init() { i := A_arbace_box_host_eval26000008_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000008_A_InstanceOf; i.Table = A_arbace_box_host_eval26000008_A_members; jrt.RegisterGoType(A_arbace_box_host_eval26000008_A_class, reflect.TypeFor[A_arbace_box_host_eval26000008_A]()) }

func A_arbace_box_host_eval26000008_fn__26000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_eval26000008_fn__26000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_host_eval26000008_fn__26000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000008_fn__26000009_A_New()}; return nil }

func A_arbace_box_host_eval26000008_fn__26000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_eval26000008_fn__26000009_A_fn_class)}; return nil }

var A_arbace_box_host_eval26000008_fn__26000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_eval26000008_fn__26000009_A_invoke, New: A_arbace_box_host_eval26000008_fn__26000009_A_new, Get: A_arbace_box_host_eval26000008_fn__26000009_A_get}

var A_arbace_box_host_eval26000008_fn__26000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000008$fn__26000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_host_eval26000008_A_class, Simple: "fn__26000009", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000008_fn__26000009_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_eval26000008_fn__26000009_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000008_fn__26000009_A_InstanceOf; i.Init = A_arbace_box_host_eval26000008_fn__26000009_A_Init; i.Table = A_arbace_box_host_eval26000008_fn__26000009_A_members; jrt.RegisterGoType(A_arbace_box_host_eval26000008_fn__26000009_A_class, reflect.TypeFor[A_arbace_box_host_eval26000008_fn__26000009_A]()) }

func A_arbace_box_host_put_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_put_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_put_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_put_A_New()}; return nil }

func A_arbace_box_host_put_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_put_A_fn_class)}; return nil }

var A_arbace_box_host_put_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_put_A_invoke, New: A_arbace_box_host_put_A_new, Get: A_arbace_box_host_put_A_get}

var A_arbace_box_host_put_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$put", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "put", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_put_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_put_A_class.Info(); i.IsInstance = A_arbace_box_host_put_A_InstanceOf; i.Init = A_arbace_box_host_put_A_Init; i.Table = A_arbace_box_host_put_A_members; jrt.RegisterGoType(A_arbace_box_host_put_A_class, reflect.TypeFor[A_arbace_box_host_put_A]()) }

func A_arbace_box_host_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_read_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_host_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_read_A_New()}; return nil }

func A_arbace_box_host_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_read_A_fn_class)}; return nil }

var A_arbace_box_host_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_read_A_invoke, New: A_arbace_box_host_read_A_new, Get: A_arbace_box_host_read_A_get}

var A_arbace_box_host_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_host_A_class, Simple: "read", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_read_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_read_A_class.Info(); i.IsInstance = A_arbace_box_host_read_A_InstanceOf; i.Init = A_arbace_box_host_read_A_Init; i.Table = A_arbace_box_host_read_A_members; jrt.RegisterGoType(A_arbace_box_host_read_A_class, reflect.TypeFor[A_arbace_box_host_read_A]()) }

func A_arbace_box_host_ref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_ref_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_ref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_ref_A_New()}; return nil }

func A_arbace_box_host_ref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_ref_A_fn_class)}; return nil }

var A_arbace_box_host_ref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_ref_A_invoke, New: A_arbace_box_host_ref_A_new, Get: A_arbace_box_host_ref_A_get}

var A_arbace_box_host_ref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$ref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "ref", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_ref_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_ref_A_class.Info(); i.IsInstance = A_arbace_box_host_ref_A_InstanceOf; i.Init = A_arbace_box_host_ref_A_Init; i.Table = A_arbace_box_host_ref_A_members; jrt.RegisterGoType(A_arbace_box_host_ref_A_class, reflect.TypeFor[A_arbace_box_host_ref_A]()) }

func A_arbace_box_host_set_ref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_set_ref_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_host_set_ref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_set_ref_A_New()}; return nil }

func A_arbace_box_host_set_ref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_set_ref_A_fn_class)}; return nil }

var A_arbace_box_host_set_ref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_set_ref_A_invoke, New: A_arbace_box_host_set_ref_A_new, Get: A_arbace_box_host_set_ref_A_get}

var A_arbace_box_host_set_ref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$set_ref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_host_A_class, Simple: "set_ref", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_set_ref_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_set_ref_A_class.Info(); i.IsInstance = A_arbace_box_host_set_ref_A_InstanceOf; i.Init = A_arbace_box_host_set_ref_A_Init; i.Table = A_arbace_box_host_set_ref_A_members; jrt.RegisterGoType(A_arbace_box_host_set_ref_A_class, reflect.TypeFor[A_arbace_box_host_set_ref_A]()) }

func A_arbace_box_host_size_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_size_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_host_size_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_size_A_New()}; return nil }

func A_arbace_box_host_size_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_size_A_fn_class)}; return nil }

var A_arbace_box_host_size_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_size_A_invoke, New: A_arbace_box_host_size_A_new, Get: A_arbace_box_host_size_A_get}

var A_arbace_box_host_size_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$size", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_host_A_class, Simple: "size", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_size_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_size_A_class.Info(); i.IsInstance = A_arbace_box_host_size_A_InstanceOf; i.Init = A_arbace_box_host_size_A_Init; i.Table = A_arbace_box_host_size_A_members; jrt.RegisterGoType(A_arbace_box_host_size_A_class, reflect.TypeFor[A_arbace_box_host_size_A]()) }

func A_arbace_box_host_spawn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_spawn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_host_spawn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_spawn_A_New()}; return nil }

func A_arbace_box_host_spawn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_spawn_A_fn_class)}; return nil }

var A_arbace_box_host_spawn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_spawn_A_invoke, New: A_arbace_box_host_spawn_A_new, Get: A_arbace_box_host_spawn_A_get}

var A_arbace_box_host_spawn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$spawn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_host_A_class, Simple: "spawn", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_spawn_A_class.Info(); i.IsInstance = A_arbace_box_host_spawn_A_InstanceOf; i.Init = A_arbace_box_host_spawn_A_Init; i.Table = A_arbace_box_host_spawn_A_members; jrt.RegisterGoType(A_arbace_box_host_spawn_A_class, reflect.TypeFor[A_arbace_box_host_spawn_A]()) }

func A_arbace_box_host_spawn_await_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_spawn_await_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_spawn_await_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_spawn_await_A_New()}; return nil }

func A_arbace_box_host_spawn_await_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_spawn_await_A_fn_class)}; return nil }

var A_arbace_box_host_spawn_await_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_spawn_await_A_invoke, New: A_arbace_box_host_spawn_await_A_new, Get: A_arbace_box_host_spawn_await_A_get}

var A_arbace_box_host_spawn_await_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$spawn_await", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "spawn_await", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_await_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_spawn_await_A_class.Info(); i.IsInstance = A_arbace_box_host_spawn_await_A_InstanceOf; i.Init = A_arbace_box_host_spawn_await_A_Init; i.Table = A_arbace_box_host_spawn_await_A_members; jrt.RegisterGoType(A_arbace_box_host_spawn_await_A_class, reflect.TypeFor[A_arbace_box_host_spawn_await_A]()) }

func A_arbace_box_host_spawn_poll_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_spawn_poll_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_spawn_poll_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_spawn_poll_A_New()}; return nil }

func A_arbace_box_host_spawn_poll_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_spawn_poll_A_fn_class)}; return nil }

var A_arbace_box_host_spawn_poll_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_spawn_poll_A_invoke, New: A_arbace_box_host_spawn_poll_A_new, Get: A_arbace_box_host_spawn_poll_A_get}

var A_arbace_box_host_spawn_poll_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$spawn_poll", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "spawn_poll", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_poll_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_spawn_poll_A_class.Info(); i.IsInstance = A_arbace_box_host_spawn_poll_A_InstanceOf; i.Init = A_arbace_box_host_spawn_poll_A_Init; i.Table = A_arbace_box_host_spawn_poll_A_members; jrt.RegisterGoType(A_arbace_box_host_spawn_poll_A_class, reflect.TypeFor[A_arbace_box_host_spawn_poll_A]()) }

func A_arbace_box_host_status_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_status_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_host_status_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_status_A_New()}; return nil }

func A_arbace_box_host_status_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_status_A_fn_class)}; return nil }

var A_arbace_box_host_status_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_status_A_invoke, New: A_arbace_box_host_status_A_new, Get: A_arbace_box_host_status_A_get}

var A_arbace_box_host_status_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$status", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_host_A_class, Simple: "status", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_status_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_status_A_class.Info(); i.IsInstance = A_arbace_box_host_status_A_InstanceOf; i.Init = A_arbace_box_host_status_A_Init; i.Table = A_arbace_box_host_status_A_members; jrt.RegisterGoType(A_arbace_box_host_status_A_class, reflect.TypeFor[A_arbace_box_host_status_A]()) }

func A_arbace_box_host_tar_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_tar_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_tar_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_tar_A_New()}; return nil }

func A_arbace_box_host_tar_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_tar_A_fn_class)}; return nil }

var A_arbace_box_host_tar_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_tar_A_invoke, New: A_arbace_box_host_tar_A_new, Get: A_arbace_box_host_tar_A_get}

var A_arbace_box_host_tar_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$tar", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "tar", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_tar_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_tar_A_class.Info(); i.IsInstance = A_arbace_box_host_tar_A_InstanceOf; i.Init = A_arbace_box_host_tar_A_Init; i.Table = A_arbace_box_host_tar_A_members; jrt.RegisterGoType(A_arbace_box_host_tar_A_class, reflect.TypeFor[A_arbace_box_host_tar_A]()) }

func A_arbace_box_host_untar_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_host_untar_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_host_untar_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_untar_A_New()}; return nil }

func A_arbace_box_host_untar_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_host_untar_A_fn_class)}; return nil }

var A_arbace_box_host_untar_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_host_untar_A_invoke, New: A_arbace_box_host_untar_A_new, Get: A_arbace_box_host_untar_A_get}

var A_arbace_box_host_untar_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$untar", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_host_A_class, Simple: "untar", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_untar_A", Source: "host.ae"})

func init() { i := A_arbace_box_host_untar_A_class.Info(); i.IsInstance = A_arbace_box_host_untar_A_InstanceOf; i.Init = A_arbace_box_host_untar_A_Init; i.Table = A_arbace_box_host_untar_A_members; jrt.RegisterGoType(A_arbace_box_host_untar_A_class, reflect.TypeFor[A_arbace_box_host_untar_A]()) }

func A_arbace_box_host__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_host__init_A_Load__O(); case 1: return A_arbace_box_host__init_A_Unit0__O(); case 2: return A_arbace_box_host__init_A_Unit1__O(); case 3: return A_arbace_box_host__init_A_Unit10__O(); case 4: return A_arbace_box_host__init_A_Unit11__O(); case 5: return A_arbace_box_host__init_A_Unit12__O(); case 6: return A_arbace_box_host__init_A_Unit13__O(); case 7: return A_arbace_box_host__init_A_Unit14__O(); case 8: return A_arbace_box_host__init_A_Unit2__O(); case 9: return A_arbace_box_host__init_A_Unit3__O(); case 10: return A_arbace_box_host__init_A_Unit4__O(); case 11: return A_arbace_box_host__init_A_Unit5__O(); case 12: return A_arbace_box_host__init_A_Unit6__O(); case 13: return A_arbace_box_host__init_A_Unit7__O(); case 14: return A_arbace_box_host__init_A_Unit8__O(); case 15: return A_arbace_box_host__init_A_Unit9__O()}; return nil }

func A_arbace_box_host__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host__init_A_New()}; return nil }

var A_arbace_box_host__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_host__init_A_invoke, New: A_arbace_box_host__init_A_new}

var A_arbace_box_host__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_host.A_arbace_box_host__init_A", Source: "host.ae"})

func init() { i := A_arbace_box_host__init_A_class.Info(); i.IsInstance = A_arbace_box_host__init_A_InstanceOf; i.Init = A_arbace_box_host__init_A_Init; i.Table = A_arbace_box_host__init_A_members; jrt.RegisterGoType(A_arbace_box_host__init_A_class, reflect.TypeFor[A_arbace_box_host__init_A]()) }
