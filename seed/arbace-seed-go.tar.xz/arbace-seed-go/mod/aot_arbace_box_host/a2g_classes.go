//line a2g_classes.ae:1
package aot_arbace_box_host

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_class, Name: "arbace.box.host$eval26000004$loading__1927001464__auto____26000005", Modifiers: 25, Simple: "loading__1927001464__auto____26000005", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A", Source: "host.ae", Declaring: &A_arbace_box_host_eval26000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_eval26000008_fn__26000009_A_class, Name: "arbace.box.host$eval26000008$fn__26000009", Modifiers: 25, Simple: "fn__26000009", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000008_fn__26000009_A", Source: "host.ae", Declaring: &A_arbace_box_host_eval26000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_put_A_class, Name: "arbace.box.host$put", Modifiers: 25, Simple: "put", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_put_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_read_A_class, Name: "arbace.box.host$read", Modifiers: 25, Simple: "read", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_read_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_ref_A_class, Name: "arbace.box.host$ref", Modifiers: 25, Simple: "ref", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_ref_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_set_ref_A_class, Name: "arbace.box.host$set_ref", Modifiers: 25, Simple: "set_ref", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_set_ref_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_size_A_class, Name: "arbace.box.host$size", Modifiers: 25, Simple: "size", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_size_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_spawn_A_class, Name: "arbace.box.host$spawn", Modifiers: 25, Simple: "spawn", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_spawn_await_A_class, Name: "arbace.box.host$spawn_await", Modifiers: 25, Simple: "spawn_await", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_await_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_spawn_poll_A_class, Name: "arbace.box.host$spawn_poll", Modifiers: 25, Simple: "spawn_poll", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_spawn_poll_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_status_A_class, Name: "arbace.box.host$status", Modifiers: 25, Simple: "status", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_status_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_tar_A_class, Name: "arbace.box.host$tar", Modifiers: 25, Simple: "tar", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_tar_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_host_untar_A_class, Name: "arbace.box.host$untar", Modifiers: 25, Simple: "untar", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_untar_A", Source: "host.ae", Declaring: &A_arbace_box_host_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_box_host_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_A_New()}; return nil }

var A_arbace_box_host_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_A_new}

var A_arbace_box_host_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_host.A_arbace_box_host_A"})

func init() { i := A_arbace_box_host_A_class.Info(); i.IsInstance = A_arbace_box_host_A_InstanceOf; i.Init = A_arbace_box_host_A_Init; i.Table = A_arbace_box_host_A_members }

func A_arbace_box_host_eval26000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000004_A_New()}; return nil }

var A_arbace_box_host_eval26000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_eval26000004_A_new}

var A_arbace_box_host_eval26000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_host_A_class, Simple: "eval26000004", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000004_A"})

func init() { i := A_arbace_box_host_eval26000004_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000004_A_InstanceOf; i.Table = A_arbace_box_host_eval26000004_A_members }

var A_arbace_box_host_eval26000004_loading__1927001464__auto____26000005_A_class *jrt.Class

func A_arbace_box_host_eval26000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host_eval26000008_A_New()}; return nil }

var A_arbace_box_host_eval26000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_host_eval26000008_A_new}

var A_arbace_box_host_eval26000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host$eval26000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_host_A_class, Simple: "eval26000008", Go: "arbace/aot_arbace_box_host.A_arbace_box_host_eval26000008_A"})

func init() { i := A_arbace_box_host_eval26000008_A_class.Info(); i.IsInstance = A_arbace_box_host_eval26000008_A_InstanceOf; i.Table = A_arbace_box_host_eval26000008_A_members }

var A_arbace_box_host_eval26000008_fn__26000009_A_class *jrt.Class

var A_arbace_box_host_put_A_class *jrt.Class

var A_arbace_box_host_read_A_class *jrt.Class

var A_arbace_box_host_ref_A_class *jrt.Class

var A_arbace_box_host_set_ref_A_class *jrt.Class

var A_arbace_box_host_size_A_class *jrt.Class

var A_arbace_box_host_spawn_A_class *jrt.Class

var A_arbace_box_host_spawn_await_A_class *jrt.Class

var A_arbace_box_host_spawn_poll_A_class *jrt.Class

var A_arbace_box_host_status_A_class *jrt.Class

var A_arbace_box_host_tar_A_class *jrt.Class

var A_arbace_box_host_untar_A_class *jrt.Class

func A_arbace_box_host__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_host__init_A_Load__O()}; return nil }

func A_arbace_box_host__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_host__init_A_New()}; return nil }

var A_arbace_box_host__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_host__init_A_invoke, New: A_arbace_box_host__init_A_new}

var A_arbace_box_host__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.host__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_host.A_arbace_box_host__init_A", Source: "host.ae"})

func init() { i := A_arbace_box_host__init_A_class.Info(); i.IsInstance = A_arbace_box_host__init_A_InstanceOf; i.Init = A_arbace_box_host__init_A_Init; i.Table = A_arbace_box_host__init_A_members }
