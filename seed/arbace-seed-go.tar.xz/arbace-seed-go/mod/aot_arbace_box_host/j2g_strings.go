//line j2g_strings.ae:1
package aot_arbace_box_host

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn4,readyn3,refkn3,docv11,arbace.core5,referR0,R1,V2,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.box.hostm2,R4,s162,arbace.box's host layer: jdk.internal.jrt.HostStore's answers (0, or -1 none\n  or refused, -2 a failed compare-and-set, -3 no store, -4 too large, -5 a bad name).v11,arbace.core13,*loaded-libs*")

var Lit_1 *jrt.String = jrt.Intern("jdk.internal.jrt.HostSpawn")

var Lit_2 *jrt.String = jrt.Intern("jdk.internal.jrt.HostStore")

var Lit_3 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn4,linekn6,columnkn4,filekn3,tagyn5,bytesyn6,Stringyn3,erryn4,longv11,arbace.core5,in-nsMyn15,arbace.box.hostm2,R0,s162,arbace.box's host layer: jdk.internal.jrt.HostStore's answers (0, or -1 none\n  or refused, -2 a failed compare-and-set, -3 no store, -4 too large, -5 a bad name).m2,R0,s162,arbace.box's host layer: jdk.internal.jrt.HostStore's answers (0, or -1 none\n  or refused, -2 a failed compare-and-set, -3 no store, -4 too large, -5 a bad name).R1,v15,arbace.box.host6,statusm10,R2,L1,V0,R0,s33,0 when there is a store, else -3.R3,i12,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host3,putm10,R2,L1,V2,Myn1,bm2,R6,R7,Myn1,hm2,R6,R7,R0,s83,Stores the bytes of b, writing their hash to h (32 bytes): 0, or a negative answer.R3,i17,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host4,sizem10,R2,L1,V1,Myn1,hm2,R6,R7,R0,s63,The size of blob h (32 bytes), or a negative answer (-1: none).R3,i22,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host4,readm10,R2,L1,V1,Myn1,hm2,R6,R7,R0,s37,Blob h whole, nil when there is none.R3,i27,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host3,refm10,R2,L1,V2,Myn4,namem2,R6,R8,Myn1,hm2,R6,R7,R0,s83,Writes the hash ref name points at to h: 0, or a negative answer (-1: no such ref).R3,i32,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host7,set-refm10,R2,L1,V3,Myn4,namem2,R6,R8,Myn1,hm2,R6,R7,Myn3,oldm2,R6,R7,R0,s163,Points ref name at blob h, only if it points at old when old is not nil (all zero: if there is\n  no such ref): 0, or a negative answer (-2: the comparison failed).R3,i37,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host3,tarm10,R2,L1,V2,Myn3,dirm2,R6,R8,R9,R0,s73,The snapshot of directory dir as a tar, or nil with the reason in err[0].R3,i43,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host5,untarm10,R2,L1,V2,Myn3,tarm2,R6,R7,Myn3,dirm2,R6,R8,R0,s73,Writes tar's directories and regular files under dir: nil, or the reason.R3,i48,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host5,spawnm10,R2,L1,MV1,Myn1,hm2,R6,R7,m2,R6,R10,R0,s90,Starts the guest the request blob h (32 bytes) asks for: a handle (0 up), or -1 (refused).R3,i53,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host10,spawn-pollm10,R2,L1,MV2,Myn1,nm2,R6,R10,Myn1,hm2,R6,R7,m2,R6,R10,R0,s121,Handle n's end: 0 once its guest has ended, its result's hash written to h (32 bytes); -11\n  while it runs; -1 (refused).R3,i58,R4,i1,R5,s18,arbace/box/host.aev15,arbace.box.host11,spawn-awaitm10,R2,L1,MV2,Myn1,nm2,R6,R10,Myn1,hm2,R6,R7,m2,R6,R10,R0,s88,Waits for handle n's end: 0, its result's hash written to h (32 bytes), or -1 (refused).R3,i64,R4,i1,R5,s18,arbace/box/host.ae")

var Lit_4 *jrt.String = jrt.Intern("arbace.box.host$eval26000004$loading__1927001464__auto____26000005")

var Lit_5 *jrt.String = jrt.Intern("arbace.box.host$eval26000008$fn__26000009")

var Lit_6 *jrt.String = jrt.Intern("arbace.box.host$status")

var Lit_7 *jrt.String = jrt.Intern("arbace.box.host$put")

var Lit_8 *jrt.String = jrt.Intern("arbace.box.host$size")

var Lit_9 *jrt.String = jrt.Intern("arbace.box.host$read")

var Lit_10 *jrt.String = jrt.Intern("arbace.box.host$ref")

var Lit_11 *jrt.String = jrt.Intern("arbace.box.host$set_ref")

var Lit_12 *jrt.String = jrt.Intern("arbace.box.host$tar")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.host$untar")

var Lit_14 *jrt.String = jrt.Intern("arbace.box.host$spawn")

var Lit_15 *jrt.String = jrt.Intern("arbace.box.host$spawn_poll")

var Lit_16 *jrt.String = jrt.Intern("arbace.box.host$spawn_await")
