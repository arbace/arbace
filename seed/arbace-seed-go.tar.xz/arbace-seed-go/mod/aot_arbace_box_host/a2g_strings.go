//line a2g_strings.ae:1
package aot_arbace_box_host

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("exclude")

var Lit_3 *jrt.String = jrt.Intern("read")

var Lit_4 *jrt.String = jrt.Intern("ref")

var Lit_5 *jrt.String = jrt.Intern("commute")

var Lit_6 *jrt.String = jrt.Intern("deref")

var Lit_7 *jrt.String = jrt.Intern("conj")

var Lit_8 *jrt.String = jrt.Intern("arbace.box.host")

var Lit_9 *jrt.String = jrt.Intern("doc")

var Lit_10 *jrt.String = jrt.Intern("arbace.box's host layer: jdk.internal.jrt.HostStore's answers (0, or -1 none\n  or refused, -2 a failed compare-and-set, -3 no store, -4 too large, -5 a bad name).")

var Lit_11 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_12 *jrt.String = jrt.Intern("arbace.box.host$eval26000004$loading__1927001464__auto____26000005")

var Lit_13 *jrt.String = jrt.Intern("jdk.internal.jrt.HostSpawn")

var Lit_14 *jrt.String = jrt.Intern("jdk.internal.jrt.HostStore")

var Lit_15 *jrt.String = jrt.Intern("arbace.box.host$eval26000008$fn__26000009")

var Lit_16 *jrt.String = jrt.Intern("arbace.box.host$put")

var Lit_17 *jrt.String = jrt.Intern("arbace.box.host$read")

var Lit_18 *jrt.String = jrt.Intern("arbace.box.host$ref")

var Lit_19 *jrt.String = jrt.Intern("arbace.box.host$set_ref")

var Lit_20 *jrt.String = jrt.Intern("arbace.box.host$size")

var Lit_21 *jrt.String = jrt.Intern("arbace.box.host$spawn")

var Lit_22 *jrt.String = jrt.Intern("arbace.box.host$spawn_await")

var Lit_23 *jrt.String = jrt.Intern("arbace.box.host$spawn_poll")

var Lit_24 *jrt.String = jrt.Intern("arbace.box.host$status")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.host$tar")

var Lit_26 *jrt.String = jrt.Intern("arbace.box.host$untar")

var Lit_27 *jrt.String = jrt.Intern("in-ns")

var Lit_28 *jrt.String = jrt.Intern("status")

var Lit_29 *jrt.String = jrt.Intern("arglists")

var Lit_30 *jrt.String = jrt.Intern("0 when there is a store, else -3.")

var Lit_31 *jrt.String = jrt.Intern("line")

var Lit_32 *jrt.String = jrt.Intern("column")

var Lit_33 *jrt.String = jrt.Intern("file")

var Lit_34 *jrt.String = jrt.Intern("arbace/box/host.ae")

var Lit_35 *jrt.String = jrt.Intern("put")

var Lit_36 *jrt.String = jrt.Intern("b")

var Lit_37 *jrt.String = jrt.Intern("tag")

var Lit_38 *jrt.String = jrt.Intern("bytes")

var Lit_39 *jrt.String = jrt.Intern("h")

var Lit_40 *jrt.String = jrt.Intern("Stores the bytes of b, writing their hash to h (32 bytes): 0, or a negative answer.")

var Lit_41 *jrt.String = jrt.Intern("size")

var Lit_42 *jrt.String = jrt.Intern("The size of blob h (32 bytes), or a negative answer (-1: none).")

var Lit_43 *jrt.String = jrt.Intern("Blob h whole, nil when there is none.")

var Lit_44 *jrt.String = jrt.Intern("name")

var Lit_45 *jrt.String = jrt.Intern("String")

var Lit_46 *jrt.String = jrt.Intern("Writes the hash ref name points at to h: 0, or a negative answer (-1: no such ref).")

var Lit_47 *jrt.String = jrt.Intern("set-ref")

var Lit_48 *jrt.String = jrt.Intern("old")

var Lit_49 *jrt.String = jrt.Intern("Points ref name at blob h, only if it points at old when old is not nil (all zero: if there is\n  no such ref): 0, or a negative answer (-2: the comparison failed).")

var Lit_50 *jrt.String = jrt.Intern("tar")

var Lit_51 *jrt.String = jrt.Intern("dir")

var Lit_52 *jrt.String = jrt.Intern("err")

var Lit_53 *jrt.String = jrt.Intern("The snapshot of directory dir as a tar, or nil with the reason in err[0].")

var Lit_54 *jrt.String = jrt.Intern("untar")

var Lit_55 *jrt.String = jrt.Intern("Writes tar's directories and regular files under dir: nil, or the reason.")

var Lit_56 *jrt.String = jrt.Intern("spawn")

var Lit_57 *jrt.String = jrt.Intern("long")

var Lit_58 *jrt.String = jrt.Intern("Starts the guest the request blob h (32 bytes) asks for: a handle (0 up), or -1 (refused).")

var Lit_59 *jrt.String = jrt.Intern("spawn-poll")

var Lit_60 *jrt.String = jrt.Intern("n")

var Lit_61 *jrt.String = jrt.Intern("Handle n's end: 0 once its guest has ended, its result's hash written to h (32 bytes); -11\n  while it runs; -1 (refused).")

var Lit_62 *jrt.String = jrt.Intern("spawn-await")

var Lit_63 *jrt.String = jrt.Intern("Waits for handle n's end: 0, its result's hash written to h (32 bytes), or -1 (refused).")
