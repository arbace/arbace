//line j2g_strings.ae:1
package aot_arbace_c_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.c.checkkn2,asyn3,chkyn13,arbace.stringyn3,strkn3,docys11,arbace.core7,bindingys14,arbace.c.check4,*cx*ys11,arbace.core5,mergekn12,ldouble-sizeys14,arbace.c.build5,*cfg*ks2,ci7,refusedkn4,enumkn1,kkn10,incompletekn6,int128kn7,uint128kn6,bitintkn1,nkn8,float128kn9,by-designkn7,complexkn7,float32kn8,float32xkn7,float64kn6,doublekn7,ldoublekn5,floatkn1,mkn4,voidkn1,vkn1,fkn1,wkn1,ikn2,ofkn5,arraykn9,float128xkn4,bf16kn6,dec128kn6,dec64xkn6,vectorkn5,dec32kn7,float16kn5,unionkn5,dec64kn2,fnkn6,structkn8,float64xkn5,scharkn4,charkn13,unsigned-charkn4,boolkn7,nullptrkn6,ullongkn4,longkn3,intkn5,shortkn5,llongkn1,ukn4,elsekn5,ucharkn6,ushortkn3,ptrkn5,ulongkn4,uintkn3,outkn3,fnskn8,fn-nameskn7,staticskn7,nstatickn7,stringskn5,initskn4,defskn7,aliaseskn9,undefinedkn7,entrieskn7,nativesyn2,fnyn6,staticyn4,datayn10,code-unitsyn11,byte-stringkn7,literalyn3,lityn4,charyn13,unsigned-charyn5,shortyn11,signed-charyn14,unsigned-shortkn7,resultskn1,tkn7,checkeryn1,fyn1,wyn1,ikn8,constantkn1,cyn3,seqyn2,oryn5,ftestyn5,wtestkn10,conversionyn2,efyn2,eiyn2,ewyn2,cvyn3,i2fyn3,r32yn3,w2fkn7,memberskn3,recyn3,f2iyn4,zeroyn2,styn3,w2iyn3,fstyn3,i2wyn3,f2wyn3,w2wyn2,ilyn2,isyn3,fldyn4,addskn4,linekn6,columnyn4,fbinyn1,*yn1,+yn1,-yn1,/yn2,fsyn2,flkn2,nfkn2,nikn5,framekn6,labelskn6,localskn2,idkn9,addressedkn6,statickn3,lockn3,idxkn5,localkn5,constkn3,vlakn4,slotkn4,sizekn4,namekn3,memkn3,offkn6,slot-fkn6,slot-ikn7,linkagekn3,objyn2,atkn4,modekn1,akn4,bitskn6,bitoffkn4,unityn3,bldyn2,ldyn3,wldyn3,bstyn4,copyyn3,wstkn2,toys1,c2,idkn5,entrykn4,kindkn1,ekn1,xys11,arbace.core5,derefyn4,agetyn2,->kn6,memberyn12,compound-lityn4,realyn4,imagys1,c4,expryn1,?yn5,commayn4,set!kn5,formsyn1,gkn7,fn-nameyn2,fpyn6,bit-oryn1,%yn2,==yn1,<yn1,>yn7,bit-andyn2,<<yn2,<=yn2,>>yn2,>=yn2,!=yn7,bit-xorkn8,bitfieldyn3,binyn4,wbinyn3,wshyn3,cmpyn3,andyn4,fcmpyn4,lnotyn4,wcmpyn5,pdiffyn3,negyn4,wnegyn4,fseqyn4,wseqyn3,fifyn2,ifyn3,wifyn4,inc!yn8,pre-inc!yn8,pre-dec!kn4,wideyn4,inityn1,xkn4,tempkn4,clityn3,letyn2,doyn2,sxys1,c10,stmt-valueyn3,fsxkn9,constexprkn7,builtinys1,c4,callyn4,dec!yn4,asetyn6,va-argkn7,builderyn4,fnegyn2,fayn5,vaargyn9,imaginaryyn5,elvisyn5,floatyn8,offsetofyn6,sizeofyn7,alignofyn13,classify-typeyn3,notys1,c6,effectyn8,bit-castyn7,generickn6,chosenyn13,convertvectoryn4,addryn14,has-attribute?yn10,label-addryn7,labaddryn4,convyn7,bit-notyn17,types-compatible?yn4,bnotyn4,wnotyn12,alignof-typeyn11,sizeof-typeyn9,stmt-expryn2,afyn2,aiyn2,amyn2,awyn7,vastartyn3,nopyn6,allocakn3,retkn6,paramskn5,protoyn5,fnrefyn5,fcallyn4,callyn5,ecallyn5,wcallkn4,anonys1,c5,embedkn5,embedys1,c12,local-labelsys1,c3,varys1,c13,static-assertys1,c6,structys1,c5,unionys1,c4,enumys1,c7,declareys1,c7,typedefys1,c5,groupys1,c4,defnys1,c9,attr-declys1,c13,declare-specsyn10,vlarestoreyn7,vlallockn3,tagys1,c3,asmyn5,whileyn6,switchyn4,whenyn8,do-whileyn4,condyn3,foryn8,continueyn3,jmpkn5,caseskn7,defaultkn3,preyn1,_yn2,swyn5,goto*yn4,loopyn5,igotoys1,c6,defineys1,c6,pragmays1,c9,directiveyn6,returnyn3,retkn6,fn-retyn5,labelyn4,retfyn4,retiyn4,retmyn4,retwyn3,labyn7,defaultyn7,vlamarkys1,c7,includeyn4,gotoyn5,breakys1,c5,undefyn4,caseyn2,sjyn2,pfyn2,pmyn2,pwyn2,piks1,c2,kryn1,&yn4,voidyn6,nativeyn4,codekn8,variadicyn6,sjbodykn5,unitsks1,c5,attrsks1,c11,after-attrsks1,c10,decl-attrsks1,c9,gnu-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c14,decl-end-attrskn6,externkn10,libc-startkn2,rdkn4,initkn3,defkn5,aliasyn5,startyn5,entrykn4,weakyn7,fnaliasyn5,aliaskn7,no-mainv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.c.buildm2,R6,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR7,v11,arbace.core5,applyv11,arbace.core6,vectorR8,R9,v11,arbace.core8,hash-mapR10,l8,R11,v11,arbace.core7,ex-infov11,arbace.core3,strR12,v14,arbace.c.build3,unqR13,R14,v14,arbace.c.check10,enum-underv14,arbace.c.check7,size-ofv11,arbace.core19,pop-thread-bindingsv14,arbace.c.build6,refuseR15,v14,arbace.c.check4,tstrv11,arbace.core20,push-thread-bindingsv14,arbace.c.check4,*cx*v11,arbace.core5,mergem2,R10,l8,v14,arbace.c.build5,*cfg*v14,arbace.c.check8,align-ofm2,R10,l8,v14,arbace.c.build5,underS2,R16,R17,R18,R19,R20,R21,R22,S6,R23,R24,R25,R26,R27,R28,R29,R30,R31,R24,R32,v14,arbace.c.build5,wide?R33,R34,R35,R25,R36,R27,R28,R37,R38,R26,R39,R23,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R16,R17,S2,R23,R28,v14,arbace.c.build4,f32?S2,R53,R63,S6,s3,u16s1,ps3,u32s2,u8s1,bs3,u64R66,R67,R68,R69,R70,v11,arbace.core4,atoml0,R71,R72,R73,R74,R75,R76,R77,v14,arbace.c.build3,*p*v14,arbace.c.build5,emit!R78,v11,arbace.core5,swap!v11,arbace.core3,incR79,l1,v11,arbace.core7,vector?v11,arbace.core4,lastv11,arbace.core6,formatv14,arbace.c.build6,hex-ofR79,R80,v11,arbace.core7,string?v11,arbace.core3,vecv11,arbace.core3,mapv14,arbace.c.build4,utf8v11,arbace.core4,longv11,arbace.core8,integer?v11,arbace.core4,seq?S2,R81,R82,v11,arbace.core6,mapcatv14,arbace.c.build10,code-unitsv11,arbace.core4,restR83,v11,arbace.core6,pr-strv11,arbace.core5,firstv11,arbace.core11,map-indexedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core10,chunk-restv11,arbace.core4,nextR82,R84,S2,R81,R82,R84,v11,arbace.core6,secondR85,R86,R87,R88,R89,R90,v14,arbace.c.build3,*u*v11,arbace.core7,symbol?R91,v11,arbace.core2,<=l-2147483648,l2147483647,v14,arbace.c.check5,t-intv14,arbace.c.check6,t-longr21,18446744073709551615Nv14,arbace.c.check7,t-ulongm2,R14,R16,v14,arbace.c.check8,t-doublev11,arbace.core6,ratio?v14,arbace.c.check6,t-boolv14,arbace.c.check9,t-nullptrv14,arbace.c.check3,arrv14,arbace.c.check6,t-charv14,arbace.c.build6,ex-resv14,arbace.c.build7,lit-resR92,v14,arbace.c.build4,kindR93,v14,arbace.c.build5,fbitsR94,v14,arbace.c.build3,wtyR95,v14,arbace.c.check4,wrapv14,arbace.c.build9,int-constR96,R93,R95,R94,v11,arbace.core6,bigintv11,arbace.core8,to-arrayv14,arbace.c.build8,complex?R97,v14,arbace.c.build6,cpartsR98,R99,R100,R100,R100,R101,v11,arbace.core5,assocv14,arbace.c.build5,cmakev14,arbace.c.build4,convR93,v11,arbace.core4,not=v14,arbace.c.build8,seq-nodev14,arbace.c.build3,ityV2,R34,R32,V2,R29,R34,V2,R32,R32,v11,arbace.core3,notV2,R29,R29,R102,R98,R99,R100,R100,R103,R104,R104,R105,R106,v14,arbace.c.build5,truthR107,R108,V2,R34,R34,S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64V2,R33,R32,R106,V2,R32,R34,R109,V2,R34,R29,v11,arbace.core6,filterv14,arbace.c.check11,compatible?m2,R10,l8,R110,v11,arbace.core4,intoR111,v14,arbace.c.build10,frame-tempR112,V2,R33,R34,R98,R104,R113,v14,arbace.c.build7,size-ofR104,R114,V2,R32,R29,m2,R10,l8,R115,V2,R34,R33,R98,R104,R113,R103,R116,v14,arbace.c.build3,ftyV2,R32,R33,R117,V2,R33,R33,R118,R119,v14,arbace.c.build6,temp-iR120,R104,R121,R122,R122,R123,ML2,R95,l1,m4,R124,i316,R125,i57,R98,R103,R116,R103,R116,R123,ML2,R95,l1,m4,R124,i327,R125,i85,v14,arbace.c.build9,new-slot!R126,R127,R128,R129,R130,R103,R131,R103,R131,R103,R131,R103,R131,R132,R132,R132,R132,R103,R104,R104,R105,v14,arbace.c.build3,*f*R133,R134,v11,arbace.core6,updateR135,R136,v11,arbace.core8,assoc-inR137,R138,v11,arbace.core9,contains?R139,S2,R33,R29,R140,R141,R142,v14,arbace.c.build10,static-idxR143,v14,arbace.c.build8,align-ofv14,arbace.c.check5,qualsR144,R145,R146,R147,v14,arbace.c.build10,addressed?R148,R149,R150,v14,arbace.c.build12,frame-alloc!R151,R152,R153,v14,arbace.c.build5,fn-idv14,arbace.c.build10,global-keyR154,R155,R156,R157,R158,R159,R160,R132,R161,v14,arbace.c.build12,unsigned-ty?R122,R162,R104,R163,R120,R131,R164,R116,R114,R165,R166,R121,R95,R167,v14,arbace.c.check5,decayS2,R46,R30,v14,arbace.c.build6,res-ofv14,arbace.c.build4,ptr?v14,arbace.c.build2,exR123,R168,R169,v11,arbace.core4,nameR170,R171,v14,arbace.c.build8,local-ofS2,R172,R34,R173,v14,arbace.c.build5,ex-asR174,v14,arbace.c.build10,aget-placeR175,v14,arbace.c.build11,arrow-placev13,arbace.string12,starts-with?v14,arbace.c.build5,placeR176,v14,arbace.c.build12,member-placeR177,S2,R178,R179,v14,arbace.c.build12,string-form?R180,R181,R182,R183,R184,R185,R186,v14,arbace.c.build13,string-staticR120,R185,R187,R185,v14,arbace.c.build14,global-obj-idxR123,ML2,R95,l1,m4,R124,i536,R125,i32,v14,arbace.c.check6,memberv11,arbace.core6,reducev14,arbace.c.check4,qualv14,arbace.c.build10,place-loadm2,R10,l8,R188,R189,R190,R127,R128,R129,R130,R191,R192,R193,R194,R195,R196,R197,R198,R199,v14,arbace.c.check7,promoteS4,R55,R54,R64,R58,S2,R54,R64,R200,m2,R10,l8,v14,arbace.c.build6,carithv14,arbace.c.build6,op-symS4,s3,subs3,muls3,divs3,addR126,R201,R202,R201,R203,v14,arbace.c.check5,usualv14,arbace.c.build8,promotedR204,m2,R10,l8,R205,R206,R206,R98,R207,R206,R204,R208,S6,R191,R195,R192,R197,R198,R190,v14,arbace.c.build13,compare-nodesS2,R196,R194,v14,arbace.c.build5,shiftR128,R128,R129,R129,v14,arbace.c.build5,arithm2,R10,l8,R123,v14,arbace.c.build15,ptr-target-sizeR123,R209,R123,v14,arbace.c.build6,ex-negR210,R211,v11,arbace.core6,empty?R212,R98,R104,R98,ML2,R95,l0,m4,R124,i657,R125,i71,R213,R214,R215,R104,R215,R98,ML2,R95,l0,m4,R124,i664,R125,i66,R98,ML2,R95,l0,m4,R124,i664,R125,i94,R216,R175,v14,arbace.c.build11,place-storeS2,R129,R128,S2,R196,R194,m2,R10,l8,R132,R103,R131,R120,R104,R121,R120,R104,R121,R123,R129,R175,S2,R217,R218,ML2,R95,l1,m4,R124,i709,R125,i73,R128,R95,S2,R219,R218,R220,ML2,R95,l1,m4,R124,i721,R125,i78,R128,R132,R120,R95,v14,arbace.c.build6,effectR132,R120,R120,R104,R121,R123,R95,R207,R103,R131,R104,R121,R123,R120,R95,R207,R120,m4,R134,l0,R133,l0,R221,R222,R104,R98,ML2,R95,l0,m4,R124,i733,R125,i79,v14,arbace.c.build13,*static-init*R187,R185,R223,v14,arbace.c.build17,build-init-storesR221,R185,R224,v14,arbace.c.build8,init-cmdv14,arbace.c.build12,string-unitsR185,v14,arbace.c.build12,units->bytesv11,arbace.core4,peekR225,R225,v11,arbace.core3,popR225,v11,arbace.core4,dropl2,v14,arbace.c.build10,build-stmtR226,R104,R227,R226,ML2,R95,l0,m4,R124,i767,R125,i79,R228,R229,R132,R227,R120,R168,v11,arbace.core5,some?R230,v14,arbace.c.build10,const-nodev14,arbace.c.check3,ptrR231,S8,R219,R217,R232,R233,R182,R218,R183,R234,S3,R33,R32,R34,S2,R99,R205,v14,arbace.c.build9,call-nodeR235,R236,R189,R128,R129,R237,R237,v14,arbace.c.build6,binaryR179,R127,v14,arbace.c.build11,string-nodev11,arbace.core7,number?v11,arbace.core5,char?ML2,R95,l0,m4,R124,i941,R125,i42,R238,v14,arbace.c.build6,fn-refR239,R237,R128,R129,R130,R191,R192,R181,v14,arbace.c.build7,if-nodeR240,R84,ML2,R93,l0,m4,R124,i923,R125,i61,R93,R241,R198,S1,R242,v14,arbace.c.check7,t-floatR199,R243,R244,R174,R120,R188,R183,v14,arbace.c.build6,assignR245,R84,R240,ML2,R93,l0,m4,R124,i903,R125,i57,R93,R246,R233,v14,arbace.c.build6,incdecR244,R82,R247,R205,R205,R106,R207,R248,v14,arbace.c.check6,t-voidR249,R217,R250,v11,arbace.core4,someR251,R252,R253,R168,R173,R175,R177,v14,arbace.c.build12,compound-litR238,R254,R182,v11,arbace.core4,mapvR232,R234,R255,R193,R256,v14,arbace.c.build11,label-code!R194,R180,R195,R257,R258,R237,R259,R260,R261,R175,R190,R262,R219,R196,R197,R178,R263,R221,R218,R99,R99,R106,R264,v14,arbace.c.build9,stmt-exprR173,R95,R95,m2,R10,l8,R265,R266,R267,R268,ML2,R95,l0,m4,R124,i1017,R125,i54,m2,R10,l8,R206,R206,R206,R206,R99,R206,R206,R93,R93,m2,R10,l8,v14,arbace.c.build12,seq-node-effR269,R93,R270,m2,R10,l8,R95,S2,l0,l1,l-1,R93,R271,ML2,R95,l0,m4,R124,i1022,R125,i50,ML2,R187,l0,m4,R124,i1021,R125,i57,ML2,R95,l0,m4,R124,i1021,R125,i65,R104,R114,R95,l4,l18,l10,l12,l9,l5,l13,m2,R10,l8,ML2,R95,l-1,m4,R124,i1019,R125,i55,m2,R10,l8,R104,R98,ML2,R95,l0,m4,R124,i1040,R125,i86,v13,arbace.string9,includes?m2,R14,R16,R202,R98,R105,R166,R104,R121,R104,R114,R120,R115,R163,R208,R117,R162,R120,R163,R168,v14,arbace.c.build12,builtin-callv14,arbace.c.build17,overflow-builtinsv14,arbace.c.build13,overflow-callv11,arbace.core4,subsv14,arbace.c.build15,builtin-aliasesv14,arbace.c.build15,builtin-nativesv14,arbace.c.build11,callee-typeR272,R273,R274,v14,arbace.c.build8,arg-nodeR275,R275,R104,R276,R277,R277,R278,R279,v11,arbace.core6,removev11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core7,keywordv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consR123,ML2,R95,l1,m4,R124,i1131,R125,i62,S10,R55,R57,R62,R56,R65,R64,R61,R52,R50,R49,v11,arbace.core4,takeV1,l0,R104,R165,R185,v11,arbace.core8,keyword?R155,R155,v14,arbace.c.build4,fillv14,arbace.c.build5,addr+v14,arbace.c.build10,subobjectsR155,R280,v14,arbace.c.build12,anon-membersv11,arbace.core12,keep-indexedv14,arbace.c.build9,fill-listR221,v14,arbace.c.build6,int-ofv11,arbace.core5,rangev14,arbace.c.build15,fill-designatedv11,arbace.core5,nnextv14,arbace.c.build10,elem-storeS2,R44,R47,R221,v14,arbace.c.build11,char-array?R221,R281,R282,S2,R44,R47,v14,arbace.c.build13,string-storesm2,R10,l8,R104,R165,R221,R221,R221,R104,R113,S12,R283,R284,R285,R286,R287,R288,R289,R290,R291,R292,R293,R294,v14,arbace.c.build11,*vla-stack*R226,R222,R104,R295,v14,arbace.c.build11,*vla-block*v11,arbace.core6,reset!R121,R201,v14,arbace.c.build13,vla-elem-sizeR222,R104,R121,R296,R222,R104,R121,R271,R291,v14,arbace.c.build10,local-declR284,S2,R172,R34,v14,arbace.c.build11,bind-local!R221,R292,R185,v14,arbace.c.build9,vla-allocR297,R222,R104,R98,R187,ML2,R95,l0,m4,R124,i1351,R125,i114,R222,v11,arbace.core7,re-findp73,^\\s*(__asm__|__asm|asm)\\s*(__volatile__|volatile|__volatile)?\\s*\\(\\s*\\\"\\\"p3,\\\"=R298,v14,arbace.c.build10,empty-asm?R226,v14,arbace.c.build5,stmtsv14,arbace.c.build12,setjmp-namesS2,R225,R226,S5,R299,R300,R301,R215,R302,R303,v11,arbace.core8,take-nthR304,R303,v11,arbace.core9,partitionv14,arbace.c.build7,do-nodeR301,v11,arbace.core7,reverseR305,v14,arbace.c.build9,vla-leavev14,arbace.c.build10,*vla-cont*ML2,R306,l3,m4,R124,i1457,R125,i41,R293,ML2,R226,V0,m4,R124,i1469,R125,i87,R300,R307,R308,v14,arbace.c.build10,decl-head?R304,R309,v14,arbace.c.build5,stmt*R225,R310,R310,v14,arbace.c.build8,*switch*v14,arbace.c.build9,*vla-brk*R311,R312,R222,R226,R313,R228,R314,R315,ML2,R226,V0,m4,R124,i1469,R125,i87,R222,R103,R131,R104,R121,R316,ML2,R226,V0,m4,R124,i1469,R125,i87,R317,ML2,R226,V0,m4,R124,i1469,R125,i87,R318,ML1,R319,m4,R124,i1459,R125,i19,R320,R321,R319,R322,R319,R323,R319,R324,R226,ML1,R319,m4,R124,i1463,R125,i58,R222,R319,R325,R215,R326,R327,v14,arbace.c.build11,fresh-code!R301,R225,v11,arbace.core9,with-metaR284,R326,R302,R226,R222,R104,R328,R222,R104,R295,R226,R298,ML2,R226,V0,m4,R124,i1468,R125,i35,R313,R329,ML2,R226,V0,m4,R124,i1469,R125,i87,R226,R330,R299,R306,R248,R313,R331,ML2,R306,l2,m4,R124,i1456,R125,i37,R222,R301,R283,ML2,R226,V0,m4,R124,i1469,R125,i87,R301,R332,ML2,R226,V0,m4,R124,i1469,R125,i87,R333,R326,R226,R222,R222,v14,arbace.c.build13,calls-setjmp?v14,arbace.c.build11,has-setjmp?R334,v11,arbace.core3,setR253,R253,R253,R168,R235,p21,^__builtin_(c23_)?va_R174,R335,R336,R336,R337,R336,R338,R339,v14,arbace.c.build9,asm-body?v14,arbace.c.build11,asm-nativesS2,R340,R341,v14,arbace.c.build10,param-specS2,R340,R341,S3,s1,ps3,i64s3,u64R222,R104,R121,R106,R120,S3,s1,ps3,i64s3,u64ML2,R319,ML2,R323,ML2,R95,l0,m4,R124,i1565,R125,i60,m4,R124,i1565,R125,i54,m4,R124,i1565,R125,i49,R342,v14,arbace.c.build15,addressed-namesR343,R344,R338,R226,R345,v11,arbace.core7,ex-dataR346,R329,v11,arbace.core10,drop-whileR291,v11,arbace.core4,keepR284,R284,v13,arbace.string7,replacep7,^__|__$S2,s5,aliass9,__alias__V7,R347,R348,R349,R350,R351,R352,R353,S2,R172,R34,R354,R221,v11,arbace.core8,not-any?R155,v14,arbace.c.check10,init-countR221,R221,m2,R10,l8,R355,v14,arbace.c.build10,unit-formsR356,v14,arbace.c.build8,new-progR357,R358,R359,R360,R361,R291,S3,R284,R289,R292,S3,R284,R289,R292,v11,arbace.core4,map?R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,v14,arbace.c.build12,file-objectsS2,R172,R34,v14,arbace.c.build10,decl-attrsv14,arbace.c.build17,tentative-or-def?S2,R172,R34,S2,R172,R34,S2,R172,R34,v14,arbace.c.build10,flex-extraR185,R291,S3,R284,R289,R292,S3,R284,R289,R292,R292,R362,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,S3,R284,R289,R292,v14,arbace.c.build11,ex-res-namev14,arbace.c.build8,build-fnR363,R364,R365,v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*")

var Lit_1 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk__558000656")

var Lit_2 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk_base__558000669")

var Lit_3 *jrt.String = jrt.Intern(".-")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.build$align_of$fn__558000024")

var Lit_5 *jrt.String = jrt.Intern("arbace.c.build$anon_members$fn__558000554")

var Lit_6 *jrt.String = jrt.Intern("")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.build$arg_node$fn__558000334")

var Lit_8 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_9 *jrt.String = jrt.Intern("the operator ")

var Lit_10 *jrt.String = jrt.Intern(" on floating operands")

var Lit_11 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000171")

var Lit_12 *jrt.String = jrt.Intern("no member ")

var Lit_13 *jrt.String = jrt.Intern(" in ")

var Lit_14 *jrt.String = jrt.Intern(" of ")

var Lit_15 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_$walk__558000593")

var Lit_16 *jrt.String = jrt.Intern("arbace.c.build$assign$fn__558000214")

var Lit_17 *jrt.String = jrt.Intern("arbace.c.build$binary$fn__558000194")

var Lit_18 *jrt.String = jrt.Intern("no entry for the function ")

var Lit_19 *jrt.String = jrt.Intern(": inline assembly (SPEC §14)")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000678__558000682")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000688__558000692")

var Lit_22 *jrt.String = jrt.Intern("main")

var Lit_23 *jrt.String = jrt.Intern(": ")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000678__558000682$fn__558000683")

var Lit_25 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000678__558000682$fn__558000683$fn__558000684")

var Lit_26 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000688__558000692$fn__558000693")

var Lit_27 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000688__558000692$fn__558000693$fn__558000694")

var Lit_28 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000763")

var Lit_29 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000793")

var Lit_30 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000795")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000797")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000799")

var Lit_33 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000801")

var Lit_34 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000803")

var Lit_35 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000805")

var Lit_36 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000807")

var Lit_37 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000813")

var Lit_38 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000825")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000846")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000853")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000864")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000873")

var Lit_43 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000905")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000910")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000915")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000920")

var Lit_47 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000925")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000930")

var Lit_49 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000935")

var Lit_50 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000940")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000954")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000961")

var Lit_53 *jrt.String = jrt.Intern("no main")

var Lit_54 *jrt.String = jrt.Intern("__libc_start_main")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000864$fn__558000865")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.build$build_program$fn__558000873$fn__558000874")

var Lit_57 *jrt.String = jrt.Intern("__builtin_constant_p")

var Lit_58 *jrt.String = jrt.Intern("__builtin_va_end")

var Lit_59 *jrt.String = jrt.Intern("__builtin_isgreaterequal")

var Lit_60 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000345")

var Lit_61 *jrt.String = jrt.Intern("__builtin_isgreater")

var Lit_62 *jrt.String = jrt.Intern("gt")

var Lit_63 *jrt.String = jrt.Intern("__builtin_islessequal")

var Lit_64 *jrt.String = jrt.Intern("le")

var Lit_65 *jrt.String = jrt.Intern("__builtin_isless")

var Lit_66 *jrt.String = jrt.Intern("lt")

var Lit_67 *jrt.String = jrt.Intern("ge")

var Lit_68 *jrt.String = jrt.Intern("__builtin_nanf")

var Lit_69 *jrt.String = jrt.Intern("__builtin_nanl")

var Lit_70 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000351")

var Lit_72 *jrt.String = jrt.Intern("__builtin_expect_with_probability")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000354")

var Lit_74 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_75 *jrt.String = jrt.Intern("__builtin_va_start")

var Lit_76 *jrt.String = jrt.Intern("va_start of a register place")

var Lit_77 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000356")

var Lit_78 *jrt.String = jrt.Intern("__builtin_prefetch")

var Lit_79 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000358")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000363")

var Lit_81 *jrt.String = jrt.Intern("__builtin_object_size")

var Lit_82 *jrt.String = jrt.Intern("__builtin_nan")

var Lit_83 *jrt.String = jrt.Intern("__builtin_inff")

var Lit_84 *jrt.String = jrt.Intern("__builtin_infl")

var Lit_85 *jrt.String = jrt.Intern("__builtin_alloca")

var Lit_86 *jrt.String = jrt.Intern("__builtin_assume_aligned")

var Lit_87 *jrt.String = jrt.Intern("__builtin_return_address")

var Lit_88 *jrt.String = jrt.Intern("__builtin_alloca_with_align")

var Lit_89 *jrt.String = jrt.Intern("alloca")

var Lit_90 *jrt.String = jrt.Intern("__builtin_expect")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000367")

var Lit_92 *jrt.String = jrt.Intern("__builtin_huge_val")

var Lit_93 *jrt.String = jrt.Intern("__builtin_frame_address")

var Lit_94 *jrt.String = jrt.Intern("__builtin_c23_va_start")

var Lit_95 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000369")

var Lit_96 *jrt.String = jrt.Intern("__builtin_va_copy")

var Lit_97 *jrt.String = jrt.Intern("u64")

var Lit_98 *jrt.String = jrt.Intern("__builtin_classify_type")

var Lit_99 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000375")

var Lit_100 *jrt.String = jrt.Intern("__builtin_huge_valf")

var Lit_101 *jrt.String = jrt.Intern("__builtin_huge_vall")

var Lit_102 *jrt.String = jrt.Intern("__builtin_nansf")

var Lit_103 *jrt.String = jrt.Intern("__builtin_nansl")

var Lit_104 *jrt.String = jrt.Intern("__builtin_islessgreater")

var Lit_105 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000381")

var Lit_106 *jrt.String = jrt.Intern("__builtin_dynamic_object_size")

var Lit_107 *jrt.String = jrt.Intern("__builtin_")

var Lit_108 *jrt.String = jrt.Intern("arbace.c.build$call_node$fn__558000390")

var Lit_109 *jrt.String = jrt.Intern("arbace.c.build$carith$s__558000115")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.build$carith$fb__558000117")

var Lit_111 *jrt.String = jrt.Intern("sub")

var Lit_112 *jrt.String = jrt.Intern("mul")

var Lit_113 *jrt.String = jrt.Intern("add")

var Lit_114 *jrt.String = jrt.Intern("div")

var Lit_115 *jrt.String = jrt.Intern(" on complex operands")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000048")

var Lit_117 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000050")

var Lit_118 *jrt.String = jrt.Intern("a string literal part ")

var Lit_119 *jrt.String = jrt.Intern("p")

var Lit_120 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes$fn__558000184")

var Lit_121 *jrt.String = jrt.Intern("eq")

var Lit_122 *jrt.String = jrt.Intern("a constant of type ")

var Lit_123 *jrt.String = jrt.Intern("b")

var Lit_124 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000095")

var Lit_125 *jrt.String = jrt.Intern("a cast to a union without a member of type ")

var Lit_126 *jrt.String = jrt.Intern("a conversion from ")

var Lit_127 *jrt.String = jrt.Intern(" to ")

var Lit_128 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000097")

var Lit_129 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs$walk__558000734")

var Lit_130 *jrt.String = jrt.Intern("weak")

var Lit_131 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_132 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_133 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_134 *jrt.String = jrt.Intern("the builtin ")

var Lit_135 *jrt.String = jrt.Intern(" as a value")

var Lit_136 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000245")

var Lit_137 *jrt.String = jrt.Intern("va_arg of a register place")

var Lit_138 *jrt.String = jrt.Intern("unary ")

var Lit_139 *jrt.String = jrt.Intern("__real__ and __imag__ (SPEC §14)")

var Lit_140 *jrt.String = jrt.Intern("GNU ?: of a non-integer")

var Lit_141 *jrt.String = jrt.Intern("sizeof of a VLA")

var Lit_142 *jrt.String = jrt.Intern("sizeof of a variably modified type")

var Lit_143 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000298")

var Lit_144 *jrt.String = jrt.Intern("__builtin_bit_cast")

var Lit_145 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000303")

var Lit_146 *jrt.String = jrt.Intern("_Generic without a chosen association")

var Lit_147 *jrt.String = jrt.Intern("GNU vector types (SPEC §14)")

var Lit_148 *jrt.String = jrt.Intern("the address of a register place ")

var Lit_149 *jrt.String = jrt.Intern("an initializer list as an expression")

var Lit_150 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000330")

var Lit_151 *jrt.String = jrt.Intern("an expression ")

var Lit_152 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558000728")

var Lit_153 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558000728$fn__558000730")

var Lit_154 *jrt.String = jrt.Intern("#embed in an initializer (CS75)")

var Lit_155 *jrt.String = jrt.Intern("arbace.c.build$fill$fn__558000574")

var Lit_156 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000562")

var Lit_157 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000564")

var Lit_158 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000571")

var Lit_159 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000564$fn__558000565")

var Lit_160 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000481")

var Lit_161 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000483")

var Lit_162 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000485")

var Lit_163 *jrt.String = jrt.Intern(" to designate")

var Lit_164 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000527")

var Lit_165 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000529")

var Lit_166 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000531")

var Lit_167 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000485$fn__558000486")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000531$fn__558000532")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558000755")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558000757")

var Lit_171 *jrt.String = jrt.Intern("f32")

var Lit_172 *jrt.String = jrt.Intern("f64")

var Lit_173 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx$fn__558000137")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_$in_expr__558000600")

var Lit_175 *jrt.String = jrt.Intern("%02x")

var Lit_176 *jrt.String = jrt.Intern("++ of a wide integer")

var Lit_177 *jrt.String = jrt.Intern("a designator that is not constant")

var Lit_178 *jrt.String = jrt.Intern("i8")

var Lit_179 *jrt.String = jrt.Intern("u8")

var Lit_180 *jrt.String = jrt.Intern("i64")

var Lit_181 *jrt.String = jrt.Intern("i32")

var Lit_182 *jrt.String = jrt.Intern("i16")

var Lit_183 *jrt.String = jrt.Intern("u16")

var Lit_184 *jrt.String = jrt.Intern("u32")

var Lit_185 *jrt.String = jrt.Intern("u")

var Lit_186 *jrt.String = jrt.Intern("s")

var Lit_187 *jrt.String = jrt.Intern("the type ")

var Lit_188 *jrt.String = jrt.Intern(" (SPEC §14)")

var Lit_189 *jrt.String = jrt.Intern("GNU's complex integer types (deferred)")

var Lit_190 *jrt.String = jrt.Intern("UTF-8")

var Lit_191 *jrt.String = jrt.Intern("no entry for ")

var Lit_192 *jrt.String = jrt.Intern("arbace.c.build$local_decl$fn__558000588")

var Lit_193 *jrt.String = jrt.Intern("GNU nested functions (SPEC §14)")

var Lit_194 *jrt.String = jrt.Intern("or")

var Lit_195 *jrt.String = jrt.Intern("rem")

var Lit_196 *jrt.String = jrt.Intern("and")

var Lit_197 *jrt.String = jrt.Intern("shl")

var Lit_198 *jrt.String = jrt.Intern("shr")

var Lit_199 *jrt.String = jrt.Intern("ne")

var Lit_200 *jrt.String = jrt.Intern("xor")

var Lit_201 *jrt.String = jrt.Intern("s128")

var Lit_202 *jrt.String = jrt.Intern("__builtin_*_overflow on wide integers")

var Lit_203 *jrt.String = jrt.Intern("a parameter's place")

var Lit_204 *jrt.String = jrt.Intern("__func__")

var Lit_205 *jrt.String = jrt.Intern("no declaration of ")

var Lit_206 *jrt.String = jrt.Intern("a local outside its function: ")

var Lit_207 *jrt.String = jrt.Intern("not a place: ")

var Lit_208 *jrt.String = jrt.Intern("arbace.c.build$program_text$fn__558000976")

var Lit_209 *jrt.String = jrt.Intern("\n")

var Lit_210 *jrt.String = jrt.Intern("arbace.c.build$promoted$fn__558000177")

var Lit_211 *jrt.String = jrt.Intern("no result for ")

var Lit_212 *jrt.String = jrt.Intern("arbace.c.build$size_of$fn__558000021")

var Lit_213 *jrt.String = jrt.Intern("size of an incomplete type ")

var Lit_214 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000611")

var Lit_215 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000619")

var Lit_216 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000624")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000637")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000642")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000644")

var Lit_220 *jrt.String = jrt.Intern("inline assembly (SPEC §14)")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000646")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$v__558000651")

var Lit_223 *jrt.String = jrt.Intern("case outside a switch")

var Lit_224 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$fn__558000235")

var Lit_225 *jrt.String = jrt.Intern("a wide statement expression")

var Lit_226 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$wv__558000237")

var Lit_227 *jrt.String = jrt.Intern("arbace.c.build$stmts$fn__558000596")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000397")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000399__558000403")

var Lit_230 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000409")

var Lit_231 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000411__558000415")

var Lit_232 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000399__558000403$fn__558000404")

var Lit_233 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000399__558000403$fn__558000404$fn__558000405")

var Lit_234 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000411__558000415$fn__558000416")

var Lit_235 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000411__558000415$fn__558000416$fn__558000417")

var Lit_236 *jrt.String = jrt.Intern("a condition of type ")

var Lit_237 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000700__558000704")

var Lit_238 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000716")

var Lit_239 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000700__558000704$fn__558000705")

var Lit_240 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000700__558000704$fn__558000705$fn__558000706")

var Lit_241 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000716$fn__558000721")

var Lit_242 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000716$fn__558000723")

var Lit_243 *jrt.String = jrt.Intern("a variably modified element type")

var Lit_244 *jrt.String = jrt.Intern("u128")

var Lit_245 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn12,ldouble-sizekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,&yn4,bodykn8,declaredyn3,clsyn3,msgyn1,tkn3,tagyn4,longyn6,Stringyn3,cmdyn3,keyyn4,sizeyn5,alignyn2,royn5,bytesyn16,java.lang.Stringyn1,xyn5,unitsyn1,fyn1,vkn4,keysyn1,kyn1,nyn2,reyn2,imyn3,preyn2,opyn1,ayn1,byn2,otyn2,kwyn1,eyn4,modeyn4,bitsyn6,bitoffyn4,unityn1,iyn2,bpyn2,mmyn1,hyn1,rv11,arbace.core5,in-nsMyn14,arbace.c.buildm2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.m2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.c.build5,*cfg*m2,R2,l8,m8,R3,TR4,i24,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,with-typesm10,R7,TR8,L1,V2,R9,R10,R4,i26,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,cpartsm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,cmakem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,complex?m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,seq-nodem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,temp-im8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,frame-tempm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,new-slot!m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,refusem10,R7,TR8,L1,V3,R12,R9,R13,R4,i31,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,unqv14,arbace.c.check3,unqm6,R4,i37,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,underm12,R7,TR8,L1,V1,R14,R0,s81,A type with its enumeration replaced by its compatible integer type, unqualified.R4,i39,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,size-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i44,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,align-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i48,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,wide?m10,R7,TR8,L1,V1,R14,R4,i50,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,kindm10,R8,L1,V1,R14,R0,s139,A type's node kind: :i (integers of at most 64 bits, pointers, bool), :f, :w (wider integers), :m (an\n  aggregate: its address), :v (void).R4,i54,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,itym10,R8,L1,V1,R14,R0,s109,An integer type's machine name: i8 u8 i16 u16 i32 u32 i64 u64 b p, sN/uN for a _BitInt(N) of at most 64 bits.R4,i70,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,wtym8,R8,L1,V1,R14,R4,i88,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,f32?m10,R7,TR8,L1,V1,R14,R4,i94,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,ftym10,R7,TR8,L1,V1,R14,R4,i95,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,ptr?m10,R7,TR8,L1,V1,R14,R4,i97,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,unsigned-ty?m10,R7,TR8,L1,V1,Myn1,sm2,R15,R17,R4,i98,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,new-progm10,R7,TR8,L1,V0,R4,i103,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*p*m8,R3,TR4,i117,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*u*m8,R3,TR4,i118,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*f*m8,R3,TR4,i119,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,emit!m10,R7,TR8,L1,V1,R18,R4,i121,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fn-idm10,R8,L1,V2,R19,Myn2,nmm2,R15,R17,R0,s93,The function of the key (a name, or [unit name] for a static one): its id, declared when new.R4,i123,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,static-idxm12,R7,TR8,L1,V4,R19,R20,R21,R22,R0,s60,A static object's index, allocated (SIZE ALIGN RO) when new.R4,i134,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,hex-ofm10,R7,TR8,L1,MV1,Myn1,bm2,R15,R23,m2,R15,R24,R4,i144,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,string-staticm12,R7,TR8,L1,V2,Myn2,bsm2,R15,R23,Myn5,esizem2,R15,R16,R0,s102,A string literal's array (its code units of `esize` bytes and the NUL) in read-only memory: its index.R4,i149,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,utf8m10,R7,TR8,L1,MV1,Myn1,sm2,R15,R17,m2,R15,R23,R4,i166,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,code-unitsm12,R7,TR8,L1,V2,R25,Myn5,esizem2,R15,R16,R0,s76,The code units of a string-ish literal part for an element of `esize` bytes.R4,i168,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,units->bytesm10,R7,TR8,L1,MV2,R26,Myn5,esizem2,R15,R16,m2,R15,R23,R4,i180,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-form?m10,R7,TR8,L1,V1,R25,R4,i186,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-unitsm12,R7,TR8,L1,V1,R25,R0,s30,A string form's [units esize].R4,i192,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-resm10,R7,TR8,L1,V1,R27,R4,i203,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,lit-resm12,R7,TR8,L1,V1,R25,R0,s58,A bare literal's type and value (the checker's rules, §8).R4,i205,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,res-ofm10,R7,TR8,L1,V1,R27,R4,i220,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fbitsm10,R7,TR8,L1,V1,R28,R4,i222,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,int-constm12,R7,TR8,L1,V2,R28,R14,R0,s45,The node of the integer constant v at type t.R4,i224,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,const-nodem12,R7,TR8,L1,V2,R28,R14,R0,s51,A constant value v of type t as a node of t's kind.R4,i232,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,truthm12,R7,TR8,L1,V1,m2,R29,V3,R30,R31,R14,R0,s52,A node as a condition: an I node, nonzero when true.R4,i245,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i256,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,convm10,R8,L1,V2,R25,R14,R0,s31,The node x converted to type t.R4,i258,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R14,R4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i306,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i306,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i306,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V1,R25,R0,s68,A complex node's parts: [effects re im], its address evaluated once.R4,i308,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V4,R14,R32,R33,R34,R0,s84,A complex value of type t from its parts (effects pre first): a temporary's address.R4,i318,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,carithm12,R7,TR8,L1,V4,R35,R36,R37,R38,R0,s189,A complex operator at the complex type ot (gcc -O0's formulas; its __muldc3 and __divdc3 handle\n  infinities and NaNs more carefully: SPEC §13's class complex-edge when a program shows it).R4,i330,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,effectm12,R7,TR8,L1,V1,m2,R29,V2,R30,R31,R0,s20,A node as an effect.R4,i354,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fstatem10,R7,TR8,L1,V0,R4,i362,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R30,R4,i364,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,frame-alloc!m12,R7,TR8,L1,MV2,Myn4,sizem2,R15,R16,Myn5,alignm2,R15,R16,m2,R15,R16,R0,s54,size bytes of the frame's memory, aligned: the offset.R4,i370,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,label-code!m10,R7,TR8,L1,V1,R39,R4,i378,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,fresh-code!m10,R7,TR8,L1,V0,R4,i383,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,local-ofm10,R7,TR8,L1,V1,R40,R4,i388,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,addressed?m12,R7,TR8,L1,V2,Myn1,nm2,R15,R17,R14,R0,s142,Whether the local `n` is in memory: its address is taken (by name, anywhere in the function), or its\n  type is an aggregate or a wide integer.R4,i390,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,bind-local!m12,R7,TR8,L1,V2,R40,R14,R0,s65,A local object's place (6.2.4: automatic storage), or a static's.R4,i396,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,global-keym10,R7,TR8,L1,V1,R40,R4,i413,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fn-refm10,R7,TR8,L1,V1,R40,R4,i416,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build14,global-obj-idxm12,R7,TR8,L1,V1,R40,R0,s157,A file-scope object's (or a block-scope extern's) static index: allocated by the program's linking\n  (arbace.c.build/link), else here with its declared type.R4,i419,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build2,exm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,ex-asm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,build-stmtm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build17,build-init-storesm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,call-nodem8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,member-placem8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,arrow-placem8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-negm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,seq-node-effm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build15,fill-designatedm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,anon-membersm8,R11,TR4,i434,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,place-loadm10,R7,TR8,L1,V1,m2,R29,V7,R41,R30,R36,R14,R42,R43,R44,R4,i436,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,place-storem12,R7,TR8,L1,V2,m2,R29,V7,R41,R30,R36,R14,R42,R43,R44,R28,R0,s97,A store of the node v (of the place's type) into the place: the node, its value the value stored.R4,i449,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,vla-elem-sizem12,R7,TR8,L1,V1,R14,R0,s76,The size of an element of a VLA type form `(array n T)` at run time: a node.R4,i463,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build15,ptr-target-sizem12,R7,TR8,L1,MV1,R14,m2,R15,R16,R0,s76,The size of what a pointer type points to (1 for void and functions, GNU's).R4,i471,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,aget-placem12,R7,TR8,L1,V3,R36,R45,R14,R0,s44,The place a[i] of element type t (i[a] too).R4,i477,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,placem12,R7,TR8,L1,V1,R27,R0,s27,A form's place (an lvalue).R4,i486,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V3,R46,R47,R14,R0,s43,The member mm of the aggregate at place bp.R4,i533,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V1,R27,R0,s49,(-> p a b): p->a->b, each step through a pointer.R4,i550,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V0,R4,i571,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,op-symm10,R7,TR8,L1,V1,R48,R4,i573,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,promotedm12,R7,TR8,L1,V1,R49,R0,s151,An operand's promoted type; a bit-field wider than int of a 64-bit type is gcc's N-bit type (its\n  arithmetic wraps at its width: pr32244-1, bitfld-3).R4,i577,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,arithm12,R7,TR8,L1,V4,R35,R36,R37,R38,R0,s125,The operator op over the nodes a and b at the operation type ot (the usual arithmetic conversions'),\n  the result of type rt.R4,i587,R5,i1,R6,s17,arbace/c/build.ae")

var Lit_246 *jrt.String = jrt.Intern("arbace.c.build$eval558000004$loading__1927001464__auto____558000005")

var Lit_247 *jrt.String = jrt.Intern("arbace.c.build$eval558000008$fn__558000009")

var Lit_248 *jrt.String = jrt.Intern("arbace.c.build$with_types")

var Lit_249 *jrt.String = jrt.Intern("arbace.c.build$refuse")

var Lit_250 *jrt.String = jrt.Intern("arbace.c.build$under")

var Lit_251 *jrt.String = jrt.Intern("arbace.c.build$size_of")

var Lit_252 *jrt.String = jrt.Intern("arbace.c.build$align_of")

var Lit_253 *jrt.String = jrt.Intern("arbace.c.build$wide_QMARK_")

var Lit_254 *jrt.String = jrt.Intern("arbace.c.build$kind")

var Lit_255 *jrt.String = jrt.Intern("arbace.c.build$ity")

var Lit_256 *jrt.String = jrt.Intern("arbace.c.build$wty")

var Lit_257 *jrt.String = jrt.Intern("arbace.c.build$f32_QMARK_")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.build$fty")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.build$ptr_QMARK_")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.build$unsigned_ty_QMARK_")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.build$new_prog")

var Lit_262 *jrt.String = jrt.Intern("arbace.c.build$emit_BANG_")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.build$fn_id")

var Lit_264 *jrt.String = jrt.Intern("arbace.c.build$static_idx")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.build$hex_of")

var Lit_266 *jrt.String = jrt.Intern("arbace.c.build$string_static")

var Lit_267 *jrt.String = jrt.Intern("arbace.c.build$utf8")

var Lit_268 *jrt.String = jrt.Intern("arbace.c.build$code_units")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.build$units__GT_bytes")

var Lit_270 *jrt.String = jrt.Intern("arbace.c.build$string_form_QMARK_")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.build$string_units")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.build$ex_res")

var Lit_273 *jrt.String = jrt.Intern("arbace.c.build$lit_res")

var Lit_274 *jrt.String = jrt.Intern("arbace.c.build$res_of")

var Lit_275 *jrt.String = jrt.Intern("arbace.c.build$fbits")

var Lit_276 *jrt.String = jrt.Intern("arbace.c.build$int_const")

var Lit_277 *jrt.String = jrt.Intern("arbace.c.build$const_node")

var Lit_278 *jrt.String = jrt.Intern("arbace.c.build$truth")

var Lit_279 *jrt.String = jrt.Intern("arbace.c.build$conv")

var Lit_280 *jrt.String = jrt.Intern("arbace.c.build$complex_QMARK_")

var Lit_281 *jrt.String = jrt.Intern("arbace.c.build$cparts")

var Lit_282 *jrt.String = jrt.Intern("arbace.c.build$cmake")

var Lit_283 *jrt.String = jrt.Intern("arbace.c.build$carith")

var Lit_284 *jrt.String = jrt.Intern("arbace.c.build$effect")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.build$fstate")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.build$new_slot_BANG_")

var Lit_287 *jrt.String = jrt.Intern("arbace.c.build$frame_alloc_BANG_")

var Lit_288 *jrt.String = jrt.Intern("arbace.c.build$label_code_BANG_")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.build$fresh_code_BANG_")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.build$local_of")

var Lit_291 *jrt.String = jrt.Intern("arbace.c.build$addressed_QMARK_")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.build$bind_local_BANG_")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.build$global_key")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.build$fn_ref")

var Lit_295 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx")

var Lit_296 *jrt.String = jrt.Intern("arbace.c.build$place_load")

var Lit_297 *jrt.String = jrt.Intern("arbace.c.build$place_store")

var Lit_298 *jrt.String = jrt.Intern("arbace.c.build$vla_elem_size")

var Lit_299 *jrt.String = jrt.Intern("arbace.c.build$ptr_target_size")

var Lit_300 *jrt.String = jrt.Intern("arbace.c.build$aget_place")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.build$place")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.build$member_place")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.build$arrow_place")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.build$temp_i")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.build$op_sym")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.build$promoted")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.build$arith")

var Lit_308 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn2,opyn1,ayn1,bkn4,linekn6,columnkn4,fileyn2,rayn2,rbyn1,hyn1,xyn1,yyn2,rxyn2,ryyn2,rtyn1,fyn1,kkn3,docyn2,esyn1,cyn1,tkn7,dynamicyn2,fsyn6,storesyn1,ryn2,ptkn3,tagyn6,Stringyn4,argsyn1,eyn2,mmyn3,offkn8,declaredyn3,elsyn6,bracedyn2,dsyn1,vyn4,inityn4,zeroyn5,depthyn3,jmpyn7,tf-formyn3,locyn1,dyn4,bodyyn5,itemsyn1,syn2,rdyn5,formsyn1,myn1,uyn4,longyn5,unitsyn1,&kn4,keysyn10,libc-startyn4,cmdsyn16,java.lang.Stringv14,arbace.c.build5,shiftm10,R0,TR1,L1,V3,R2,R3,R4,R5,i601,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,compare-nodesm10,R0,TR1,L1,V5,R2,R3,R4,R8,R9,R5,i607,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build6,binarym10,R0,TR1,L1,V6,R10,R11,R12,R13,R14,R15,R5,i624,R6,i1,R7,s17,arbace/c/build.aem10,R0,TR1,L1,V1,R12,R5,i637,R6,i1,R7,s17,arbace/c/build.aem10,R1,L1,V2,R16,R17,R18,s63,A form's node converted to the node kind k (for addresses: :i).R5,i642,R6,i1,R7,s17,arbace/c/build.aem12,R0,TR1,L1,V2,R19,R11,R18,s28,Effects es then the value x.R5,i648,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build7,if-nodem10,R0,TR1,L1,V4,R20,R3,R4,R21,R5,i659,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build6,assignm10,R0,TR1,L1,V1,R16,R5,i666,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build6,incdecm10,R0,TR1,L1,V1,R16,R5,i697,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,*static-init*m8,R22,TR5,i727,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build8,init-cmdm12,R0,TR1,L1,V2,R23,R24,R18,s105,A static initializer's command: (init NI NF STMT), run before the program starts in a frame of its slots.R5,i729,R6,i1,R7,s17,arbace/c/build.aem12,R0,TR1,L1,V1,R21,R18,s63,A temporary aggregate of type t in the frame: its address node.R5,i735,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build12,compound-litm10,R0,TR1,L1,V1,R16,R5,i742,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,string-nodem10,R0,TR1,L1,V2,R16,R21,R5,i756,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,stmt-exprm10,R0,TR1,L1,V1,R16,R5,i760,R6,i1,R7,s17,arbace/c/build.aem10,R1,L1,V1,R16,R18,s26,A form's node: {:k :n :t}.R5,i782,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build15,builtin-aliasesS144,s5,floors5,log1ps6,mallocs4,ceils6,strcmps3,fmas4,frees4,coshs6,strdups6,printfs6,strcpys14,fputs_unlockeds4,nanls6,strspns6,strchrs7,isalphas4,labss6,lrounds7,isalnums6,memchrs5,sqrtls5,indexs6,strlens7,strrchrs5,fputcs5,llabss5,_exits5,ffslls5,fputss8,copysigns7,sprintfs16,putchar_unlockeds5,atan2s7,isdigits5,frexps6,scalbns8,vsprintfs4,fdims7,mempcpys15,printf_unlockeds4,cbrts6,stpcpys6,truncfs8,snprintfs5,lrints13,aligned_allocs4,bcmps7,strcspns4,powfs5,sqrtfs6,memsets7,strncats6,memcpys3,pows5,fabsfs7,strncmps4,putss9,vsnprintfs7,putchars8,vfprintfs4,fmods4,atans3,nans7,fprintfs7,isspaces3,logs7,toasciis4,logbs6,llrints3,sins4,fabss5,hypots5,creals4,fmins7,memrchrs4,atois16,fprintf_unlockeds9,remainders3,exps6,callocs9,nearbyints7,imaxabss6,roundfs5,ceilfs7,tolowers5,log10s7,isasciis4,fmaxs6,strtols6,strstrs4,sqrts6,rindexs3,tans3,coss5,truncs9,copysignls9,copysignfs7,isuppers5,fmaxfs7,llrounds4,ffsls6,memcmps5,fminfs3,ffss3,abss4,cabss4,conjs5,expm1s7,strpbrks7,strncpys14,posix_memaligns4,exits4,exp2s5,ldexps4,nanfs7,strndups5,aborts7,touppers5,ilogbs7,strnlens7,reallocs11,strncasecmps5,cimags7,isprints4,sinhs7,vprintfs4,atols6,fwrites5,rounds8,isxdigits5,bcopys4,asins6,floorfs7,memmoves4,tanhs5,bzeros4,log2s5,fabsls4,rints4,modfs10,strcasecmps6,strcats7,islowers4,acosm8,R0,TR5,i947,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build15,builtin-nativesS33,s18,__builtin_isnormals17,__builtin_bswap16s17,__builtin_bswap32s21,__builtin_unreachables18,__builtin_paritylls14,__builtin_ffsls15,__builtin_isnans13,__builtin_ctzs18,__builtin_popcounts14,__builtin_traps21,__builtin_isunordereds18,__builtin_signbitfs15,__builtin_ctzlls16,__builtin_paritys17,__builtin_parityls17,__builtin_signbits13,__builtin_ffss20,__builtin_popcountlls14,__builtin_ctzls19,__builtin_popcountls15,__builtin_clzlls17,__builtin_clrsblls13,__builtin_clzs15,__builtin_clrsbs15,__builtin_isinfs14,__builtin_clzls17,__builtin_bswap64s15,__builtin_ffslls20,__builtin_isinf_signs18,__builtin_signbitls18,__builtin_isfinites20,__builtin_fpclassifys16,__builtin_clrsblm8,R0,TR5,i962,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,callee-typem10,R0,TR1,L1,V1,R25,R5,i972,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build8,arg-nodem12,R0,TR1,L1,V2,R3,R26,R18,s77,An argument converted to the parameter type pt, or default-promoted (pt nil).R5,i976,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build12,builtin-callm12,R0,TR1,L1,V3,Myn2,nmm2,R27,R28,R29,R25,R18,s64,A call of a builtin by name, or nil when it is an ordinary call.R5,i993,R6,i1,R7,s17,arbace/c/build.aem10,R0,TR1,L1,V2,R19,R30,R5,i1040,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build17,overflow-builtinsS21,s23,__builtin_sadd_overflows24,__builtin_uaddl_overflows25,__builtin_usubll_overflows23,__builtin_uadd_overflows23,__builtin_usub_overflows23,__builtin_umul_overflows23,__builtin_smul_overflows25,__builtin_ssubll_overflows24,__builtin_usubl_overflows25,__builtin_smulll_overflows22,__builtin_sub_overflows24,__builtin_ssubl_overflows24,__builtin_saddl_overflows22,__builtin_add_overflows24,__builtin_umull_overflows24,__builtin_smull_overflows22,__builtin_mul_overflows25,__builtin_uaddll_overflows25,__builtin_umulll_overflows23,__builtin_ssub_overflows25,__builtin_saddll_overflowm8,R0,TR5,i1042,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,overflow-callm12,R0,TR1,L1,V2,Myn2,nmm2,R27,R28,R29,R18,s99,__builtin_OP_overflow(a, b, res): the exact result's wrap into *res's type, 1 when it does not fit.R5,i1051,R6,i1,R7,s17,arbace/c/build.aem8,R1,L1,V4,R16,R10,R29,R25,R5,i1072,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build6,int-ofm10,R0,TR1,L1,V1,R11,R5,i1109,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,subobjectsm12,R0,TR1,L1,V1,R21,R18,s94,An aggregate's subobjects: [[key type offset member] ...] (an array's by index: lazily, by n).R5,i1113,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,elem-storem12,R0,TR1,L1,V4,R21,R3,R11,R31,R18,s84,The stores of a scalar or aggregate value x (a form) into the object of type t at a.R5,i1123,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build5,addr+m10,R0,TR1,L1,V2,R3,R32,R5,i1131,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build4,fillm8,R33,TR5,i1133,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,char-array?m10,R0,TR1,L1,V1,R21,R5,i1135,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,string-storesm10,R0,TR1,L1,V3,R21,R3,R11,R5,i1138,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,fill-listm12,R0,TR1,L1,V4,R21,R3,R34,R35,R18,s187,The stores of a braced list els into the object of type t at a: [stores rest]. braced: the list is\n  this object's own braces (designators apply here); else elided (a designator ends it).R5,i1146,R6,i1,R7,s17,arbace/c/build.aem12,R0,TR1,L1,V1,R21,R18,s70,A record type's members, an anonymous member's own members among them.R5,i1226,R6,i1,R7,s17,arbace/c/build.aem12,R0,TR1,L1,V4,R21,R3,R36,R37,R18,s90,A designator path's rest `ds` into the object of type t at a, given the value v: [stores].R5,i1233,R6,i1,R7,s17,arbace/c/build.aem12,R0,TR1,L1,V4,R21,R3,R34,R35,R18,s146,The stores of the initializer elements els (their first, or for an aggregate as many as it takes)\n  into the object of type t at a: [stores rest].R5,i1252,R6,i1,R7,s17,arbace/c/build.aem10,R1,L1,V4,R21,R3,R38,R39,R18,s186,The effects that initialize the object of type t at the address node a from the initializer form\n  init; zero: the object zeroed first (an automatic one; static storage is zero already).R5,i1277,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build8,*switch*m8,R22,TR5,i1296,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,decl-head?m10,R0,TR1,L1,V1,R11,R5,i1298,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,*vla-block*m8,R22,TR5,i1300,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,*vla-stack*m8,R22,TR5,i1301,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,*vla-brk*l0,m8,R22,TR5,i1302,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,*vla-cont*m8,R22,TR5,i1303,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,vla-leavem12,R0,TR1,L1,V2,R40,R41,R18,s93,A break or continue: the stack pointer restored to the outermost VLA block it leaves (CS106).R5,i1305,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,vla-allocm10,R0,TR1,L1,V3,R30,R42,R43,R5,i1312,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,local-declm12,R0,TR1,L1,V1,R44,R18,s46,A block's declaration: the statements it runs.R5,i1325,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,empty-asm?m12,R0,TR1,L1,V1,R16,R18,s98,An asm statement whose template is empty (a compiler barrier: __asm__(\"\" : \"+r\"(x) : : \"memory\")).R5,i1359,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build9,asm-body?m12,R0,TR1,L1,V1,R45,R18,s95,A function body that is inline assembly (musl's arch/x86_64 inline functions): natives of ci's.R5,i1367,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build5,stmtsm10,R0,TR1,L1,V1,R46,R5,i1375,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build7,do-nodem10,R0,TR1,L1,V1,R46,R5,i1377,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build12,setjmp-namesS5,s7,_setjmps16,__builtin_setjmps11,__sigsetjmps6,setjmps9,sigsetjmpm8,R0,TR5,i1379,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,has-setjmp?m12,R0,TR1,L1,V1,R16,R18,s202,Whether a statement's own expressions call setjmp (a compound statement's body is its statements', so a\n  block or a let is never the guarded statement: re-entering it would run its declarations again).R5,i1381,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build5,stmt*m10,R0,TR1,L1,V1,R47,R5,i1396,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,calls-setjmp?m12,R0,TR1,L1,V1,R16,R18,s75,Whether forms call setjmp anywhere (the function's body is then an SjBody).R5,i1479,R6,i1,R7,s17,arbace/c/build.aem8,R1,L1,V1,R47,R5,i1487,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build15,addressed-namesm12,R0,TR1,L1,V1,R45,R18,s87,The names whose address the body takes: (addr x), and a va_list given to a va_ builtin.R5,i1494,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,param-specm10,R0,TR1,L1,V2,R30,R21,R5,i1517,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,asm-nativesS24,s6,a_spins10,__syscall6s7,a_stores10,__syscall1s8,__get_tps4,a_ors11,a_fetch_adds10,__syscall4s7,a_cas_ps8,a_clz_64s5,a_cass6,a_swaps9,a_barriers7,a_or_64s7,a_crashs10,__syscall5s5,a_incs8,a_and_64s8,a_ctz_64s10,__syscall2s10,__syscall3s10,__syscall0s5,a_ands5,a_decm8,R5,i1529,R6,i1,R7,s17,arbace/c/build.aeR18,s170,The functions whose body is inline assembly that are natives of go/arbace/ci: musl 1.2.6's arch/x86_64\n  inline functions (atomic_arch.h, syscall_arch.h, pthread_arch.h).v14,arbace.c.build8,build-fnm10,R1,L1,V1,R16,R18,s80,A c/defn: its (code ...) command, or (native ...) for a body of inline assembly.R5,i1536,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,unit-formsm12,R0,TR1,L1,V1,R48,R18,s100,A unit's top-level forms with its header units' spliced in where their c/include stands (once each).R5,i1577,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build12,file-objectsm12,R0,TR1,L1,V1,R49,R18,s73,The file-scope object declarations of a unit's forms: [[form entry] ...].R5,i1593,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,decl-attrsm12,R0,TR1,L1,V1,R50,R18,s63,A declaration's weak and alias attributes: [weak alias-target].R5,i1604,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build11,ex-res-namem12,R0,TR1,L1,V2,R51,Myn1,nm2,R27,R28,R18,s59,The file-scope entry named n in unit u (an alias's target).R5,i1620,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build17,tentative-or-def?m10,R0,TR1,L1,V2,R16,R30,R5,i1625,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build10,flex-extram12,R0,TR1,L1,MV2,R21,R38,m2,R27,R52,R18,s151,The bytes a static struct's initialized flexible array member adds (GNU: struct W w = {{...}, {1, 2, 3}};\n  the object is as large as its initializer).R5,i1628,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build13,build-programm10,R1,L1,V3,R53,R54,m2,R55,V1,R56,R18,s291,The node program of checked units [{:rd :results :std :unsigned-char}] (a program's, in link order):\n  the commands, with (entry main) or, when `libc-start` names __libc_start_main, (start ...). Throws\n  ex-info with :ci/refused CLASS for a construct out of eval (SPEC §14) or not built yet.R5,i1647,R6,i1,R7,s17,arbace/c/build.aev14,arbace.c.build12,program-textm10,R1,L1,MV1,R57,m2,R27,R58,R18,s73,A node program as text, a command a line (go/arbace/ci's Parse reads it).R5,i1730,R6,i1,R7,s17,arbace/c/build.ae")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.build$shift")

var Lit_310 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes")

var Lit_311 *jrt.String = jrt.Intern("arbace.c.build$binary")

var Lit_312 *jrt.String = jrt.Intern("arbace.c.build$ex_neg")

var Lit_313 *jrt.String = jrt.Intern("arbace.c.build$ex_as")

var Lit_314 *jrt.String = jrt.Intern("arbace.c.build$seq_node")

var Lit_315 *jrt.String = jrt.Intern("arbace.c.build$if_node")

var Lit_316 *jrt.String = jrt.Intern("arbace.c.build$assign")

var Lit_317 *jrt.String = jrt.Intern("arbace.c.build$incdec")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.build$init_cmd")

var Lit_319 *jrt.String = jrt.Intern("arbace.c.build$frame_temp")

var Lit_320 *jrt.String = jrt.Intern("arbace.c.build$compound_lit")

var Lit_321 *jrt.String = jrt.Intern("arbace.c.build$string_node")

var Lit_322 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr")

var Lit_323 *jrt.String = jrt.Intern("arbace.c.build$ex")

var Lit_324 *jrt.String = jrt.Intern("arbace.c.build$callee_type")

var Lit_325 *jrt.String = jrt.Intern("arbace.c.build$arg_node")

var Lit_326 *jrt.String = jrt.Intern("arbace.c.build$builtin_call")

var Lit_327 *jrt.String = jrt.Intern("arbace.c.build$seq_node_eff")

var Lit_328 *jrt.String = jrt.Intern("arbace.c.build$overflow_call")

var Lit_329 *jrt.String = jrt.Intern("arbace.c.build$call_node")

var Lit_330 *jrt.String = jrt.Intern("arbace.c.build$int_of")

var Lit_331 *jrt.String = jrt.Intern("arbace.c.build$subobjects")

var Lit_332 *jrt.String = jrt.Intern("arbace.c.build$elem_store")

var Lit_333 *jrt.String = jrt.Intern("arbace.c.build$addr_PLUS_")

var Lit_334 *jrt.String = jrt.Intern("arbace.c.build$char_array_QMARK_")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.build$string_stores")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.build$fill_list")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.build$anon_members")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.build$fill_designated")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.build$fill")

var Lit_340 *jrt.String = jrt.Intern("arbace.c.build$build_init_stores")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.build$decl_head_QMARK_")

var Lit_342 *jrt.String = jrt.Intern("arbace.c.build$vla_leave")

var Lit_343 *jrt.String = jrt.Intern("arbace.c.build$vla_alloc")

var Lit_344 *jrt.String = jrt.Intern("arbace.c.build$local_decl")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.build$empty_asm_QMARK_")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.build$stmts")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.build$do_node")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_")

var Lit_351 *jrt.String = jrt.Intern("arbace.c.build$calls_setjmp_QMARK_")

var Lit_352 *jrt.String = jrt.Intern("arbace.c.build$build_stmt")

var Lit_353 *jrt.String = jrt.Intern("arbace.c.build$addressed_names")

var Lit_354 *jrt.String = jrt.Intern("arbace.c.build$param_spec")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.build$build_fn")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.build$unit_forms")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.build$file_objects")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.build$ex_res_name")

var Lit_360 *jrt.String = jrt.Intern("arbace.c.build$tentative_or_def_QMARK_")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.build$flex_extra")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.build$build_program")

var Lit_363 *jrt.String = jrt.Intern("arbace.c.build$program_text")
