//line j2g_strings.ae:1
package aot_arbace_c_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.c.checkkn2,asyn3,chkyn13,arbace.stringyn3,strkn3,docys11,arbace.core7,bindingys14,arbace.c.check4,*cx*ys11,arbace.core5,mergekn12,ldouble-sizeys14,arbace.c.build5,*cfg*ks2,ci7,refusedkn4,enumkn1,kkn10,incompletekn6,int128kn7,uint128kn6,bitintkn1,nkn8,float128kn9,by-designkn7,complexkn2,ofkn7,float32kn8,float32xkn7,float64kn6,doublekn8,float64xkn7,ldoublekn5,floatkn1,mkn7,float16kn9,float128xkn5,dec64kn4,bf16kn5,dec32kn6,dec64xkn6,dec128kn4,elsekn4,voidkn1,vkn1,fkn1,wkn1,ikn5,arraykn6,vectorkn5,unionkn2,fnkn6,structkn5,scharkn4,charkn13,unsigned-charkn4,boolkn7,nullptrkn6,ullongkn4,longkn3,intkn5,shortkn5,llongkn1,ukn5,ucharkn6,ushortkn3,ptrkn5,ulongkn4,uintkn4,fragkn5,fkeyskn3,fnskn5,skeyskn3,stskn7,entrieskn7,ev-listkn4,seenkn3,outkn8,fn-nameskn7,staticskn7,nstatickn7,stringskn5,initskn4,defskn7,aliaseskn9,undefinedkn7,nativesyn2,fnkn3,tlskn1,syn6,statickn3,stryn4,datayn10,code-unitsyn11,byte-stringkn7,literalyn3,lityn4,charyn13,unsigned-charyn5,shortyn11,signed-charyn14,unsigned-shortkn7,resultskn1,tkn7,checkeryn1,fyn1,wyn1,ikn8,constantkn1,cyn3,seqyn2,oryn5,ftestyn5,wtestkn10,conversionyn2,efyn2,eiyn2,ewyn2,cvyn3,i2fyn3,r32yn3,w2fkn7,memberskn3,recyn3,f2iyn4,zeroyn2,styn3,w2iyn3,fstyn3,i2wyn3,f2wyn3,w2wyn3,fldyn2,ldyn4,fnegyn4,fcmpyn3,cmpyn2,ilyn4,addskn4,linekn6,columnyn2,isyn3,binyn1,*yn1,+yn1,-yn1,/yn2,ifyn3,negyn4,fbinyn2,fsyn2,flkn2,nfkn2,nikn5,framekn6,labelskn6,localskn2,idkn9,addressedks1,c14,declared-alignkn6,dalignkn8,align-upyn2,fpkn3,offkn6,statickn3,lockn3,idxkn5,localkn5,constkn12,thread_localkn3,vlakn4,slotkn4,sizekn4,namekn3,memkn6,slot-fkn6,slot-ikn7,linkagekn3,objkn1,oyn2,atkn4,modekn1,akn4,bitskn6,bitoffkn4,unityn4,wbldyn3,bldyn3,wldkn5,vsizeyn4,wbstyn3,bstyn4,copyyn3,wstkn2,toyn8,restrictyn8,volatileyn6,atomicyn5,constyn5,unionyn6,structys1,c6,structys1,c5,unionkn4,kindkn6,vmrecsys1,c13,static-assertys1,c4,bitsys1,c5,groupys1,c4,basekn3,tagkn4,vmemkn4,voffyn2,sxyn2,doyn1,xyn4,loopys1,c2,idkn5,entrykn3,rttyn8,pre-dec!yn4,addryn4,set!yn4,dec!kn2,rtyn2,->yn8,pre-inc!yn4,agetys11,arbace.core5,derefyn4,convkn4,rttsyn9,stmt-expryn1,?yn4,inc!yn5,commakn6,packedkn9,max-alignkn5,alignkn8,var-sizeyn18,typeof-unqual-typeyn8,__seg_fsyn8,__seg_gsyn13,typeof-unqualyn6,typeofyn11,typeof-typeyn5,arrayyn8,_Nonnullkn1,ekn11,param-nameskn1,xkn6,memberyn12,compound-lityn4,realyn4,imagys1,c4,exprkn5,formsyn1,gkn7,fn-nameyn6,bit-oryn1,%yn2,==yn1,<yn1,>yn7,bit-andyn2,<<yn2,<=yn2,>>yn2,>=yn2,!=yn7,bit-xorkn8,bitfieldyn4,wbinyn3,wshyn3,andyn4,lnotyn4,wcmpyn5,pdiffyn4,wnegyn4,fseqyn4,wseqyn3,fifyn3,wifyn4,initkn4,tempkn6,storeskn4,clityn3,letys1,c10,stmt-valueyn3,fsxkn9,constexprkn7,builtinys1,c4,callyn4,asetyn6,va-argkn7,builderyn2,fayn5,vaargyn9,imaginaryyn5,elvisyn5,floatyn8,offsetofkn2,ttyn11,sizeof-typeyn6,sizeofyn7,alignofyn13,classify-typeyn3,notys1,c6,effectyn8,bit-castyn7,generickn6,chosenyn13,convertvectoryn14,has-attribute?yn10,label-addryn7,labaddryn7,bit-notyn17,types-compatible?yn4,bnotyn4,wnotyn12,alignof-typekn2,vmyn2,aiyn2,afyn2,amyn6,allocayn2,awyn7,vastartyn3,nopyn5,fnrefyn4,callyn5,wcallkn3,taskn5,clearkn5,fencekn9,sync-boolkn8,sync-valkn4,xchgkn7,releasekn5,storekn4,loadkn3,caskn5,fetchkn8,op-fetchyn5,vplenkn3,retkn6,paramskn5,protoyn5,apackyn5,fcallyn5,ecallkn4,anonys1,c5,embedkn5,embedys1,c12,local-labelsys1,c3,varys1,c4,enumys1,c7,declareys1,c7,typedefys1,c4,defnys1,c9,attr-declys1,c13,declare-specsyn10,vlarestoreyn7,vlallockn4,autoks1,c9,auto-typeys1,c3,asmyn5,whileyn6,switchyn4,whenyn8,do-whileyn4,condyn3,foryn8,continueyn3,jmpkn5,caseskn7,defaultkn3,preyn1,_yn2,swyn5,goto*yn5,igotoys1,c6,defineys1,c6,pragmays1,c9,directiveyn6,returnyn3,retkn6,fn-retyn5,labelyn4,retfyn4,retiyn4,retmyn4,retwyn3,labyn7,defaultyn7,vlamarkys1,c7,includeyn4,gotoyn5,breakys1,c5,undefyn4,caseyn2,sjyn2,pfyn2,pmyn2,pwyn2,piks1,c2,kryn1,&yn4,voidyn6,nativeyn4,codekn8,variadicyn6,sjbodykn5,unitsks1,c5,attrsks1,c11,after-attrsks1,c10,decl-attrsks1,c9,gnu-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c14,decl-end-attrskn6,externkn7,refusedkn5,errorkn2,evkn4,textkn2,exkn4,selfkn2,rdkn2,rokn4,initkn3,defkn4,itemkn3,errkn4,weakkn5,aliaskn2,tekn4,objskn6,fcandskn10,libc-startkn5,prunekn5,rootskn5,itemskn5,fmapskn5,smapsyn5,startyn5,entrykn1,jyn7,fnaliasyn5,aliaskn7,no-mainv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.c.buildm2,R6,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR7,v11,arbace.core5,applyv11,arbace.core6,vectorR8,R9,v11,arbace.core8,hash-mapR10,l8,R11,v11,arbace.core7,ex-infov11,arbace.core3,strR12,v14,arbace.c.build3,unqR13,R14,v14,arbace.c.check10,enum-underv14,arbace.c.check7,size-ofv11,arbace.core19,pop-thread-bindingsv14,arbace.c.build6,refuseR15,v14,arbace.c.check4,tstrv11,arbace.core20,push-thread-bindingsv14,arbace.c.check4,*cx*v11,arbace.core5,mergem2,R10,l8,v14,arbace.c.build5,*cfg*v14,arbace.c.check8,align-ofm2,R10,l8,v14,arbace.c.build5,underS2,R16,R17,R18,R19,R20,R21,R22,R23,S7,R24,R25,R26,R27,R28,R29,R30,R31,S8,R32,R33,R34,R35,R20,R36,R37,R38,v14,arbace.c.check9,int-type?v11,arbace.core3,notv14,arbace.c.build5,wide?R39,R40,R41,R25,R42,R43,R44,R26,R45,R29,R30,R33,R35,R27,R38,R24,R37,R46,R36,R32,R47,R34,R48,R49,R28,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R16,R17,S2,R24,R30,v14,arbace.c.build4,f32?S2,R54,R63,S6,s3,u16s1,ps3,u32s2,u8s1,bs3,u64R66,R67,R68,R69,R70,R71,v14,arbace.c.build6,*item*v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR72,R73,v14,arbace.c.build3,*p*v11,arbace.core6,symbolR74,R75,R76,R77,v11,arbace.core4,atoml0,R78,R79,R80,R81,R82,R83,v14,arbace.c.build9,item-ref!v14,arbace.c.build5,emit!R84,R85,l2,l1,v14,arbace.c.build12,frag-static!v14,arbace.c.build7,ro-codev11,arbace.core7,vector?v11,arbace.core4,lastv14,arbace.c.build3,sphv11,arbace.core5,swap!v11,arbace.core3,incR86,R87,v11,arbace.core6,formatv14,arbace.c.build6,hex-ofR88,R87,R89,v11,arbace.core7,string?v11,arbace.core3,vecv11,arbace.core3,mapv14,arbace.c.build4,utf8v11,arbace.core4,longv11,arbace.core8,integer?v11,arbace.core4,seq?S2,R90,R91,v11,arbace.core6,mapcatv14,arbace.c.build10,code-unitsv11,arbace.core4,restR92,v11,arbace.core6,pr-strv11,arbace.core11,map-indexedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core10,chunk-restR91,R93,S2,R90,R91,R93,v11,arbace.core6,secondR94,R95,R96,R97,R98,R99,v14,arbace.c.build3,*u*v11,arbace.core7,symbol?R100,v11,arbace.core2,<=l-2147483648,l2147483647,v14,arbace.c.check5,t-intv14,arbace.c.check6,t-longr21,18446744073709551615Nv14,arbace.c.check7,t-ulongm2,R14,R16,v14,arbace.c.check8,t-doublev11,arbace.core6,ratio?v14,arbace.c.check6,t-boolv14,arbace.c.check9,t-nullptrv14,arbace.c.check3,arrv14,arbace.c.check6,t-charv14,arbace.c.build6,ex-resv14,arbace.c.build7,lit-resR101,v14,arbace.c.build4,kindR102,v14,arbace.c.build5,fbitsR103,v14,arbace.c.build3,wtyR104,v14,arbace.c.check4,wrapv14,arbace.c.build9,int-constR105,R102,R104,R103,v11,arbace.core6,bigintv14,arbace.c.build8,complex?R106,v14,arbace.c.build6,cpartsR107,R108,v14,arbace.c.build5,truthR109,R110,v11,arbace.core5,assocv14,arbace.c.build5,cmakev14,arbace.c.build4,convR102,v11,arbace.core4,not=v14,arbace.c.build8,seq-nodev14,arbace.c.build3,ityV2,R44,R42,V2,R31,R44,V2,R42,R42,V2,R31,R31,R111,R107,R108,R112,R113,R113,R114,R115,R116,R117,V2,R44,R44,S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64V2,R43,R42,R115,V2,R42,R44,R118,V2,R44,R31,v11,arbace.core6,filterv14,arbace.c.check11,compatible?m2,R10,l8,R119,v11,arbace.core4,intoR120,v14,arbace.c.build10,frame-tempR121,V2,R43,R44,R107,R113,R122,v14,arbace.c.build7,size-ofR113,R123,V2,R42,R31,m2,R10,l8,R124,V2,R44,R43,R107,R113,R122,R112,R125,v14,arbace.c.build3,ftyV2,R42,R43,R126,V2,R43,R43,R127,R128,R129,R130,R112,R125,R113,R123,v14,arbace.c.build6,ex-negR131,R132,R133,v14,arbace.c.build6,temp-iR134,v14,arbace.c.build9,part-loadR135,ML2,R104,l1,m4,R136,i393,R137,i35,R113,R138,R107,v14,arbace.c.build10,part-storeR135,ML2,R104,l1,m4,R136,i404,R137,i70,R115,R139,R140,R141,R142,R143,v14,arbace.c.build12,unsigned-ty?R139,R144,R133,ML2,R104,l0,m4,R136,i432,R137,i97,R145,R144,R113,R138,R113,R138,R113,R138,R113,R138,R134,R134,R134,R134,R133,R134,R134,R107,R113,R138,R113,R138,v14,arbace.c.build7,icarithv14,arbace.c.build9,new-slot!R146,R140,R141,R142,R143,R112,R147,R112,R147,R112,R147,R112,R147,R148,R148,R148,R148,R112,R113,R113,R114,v14,arbace.c.build3,*f*R149,R150,v11,arbace.core6,updateR151,R152,v11,arbace.core8,assoc-inR153,R154,v11,arbace.core9,contains?R155,S2,R43,R31,v14,arbace.c.build8,align-ofR156,R157,R158,R159,R160,R139,R139,R104,R104,R161,R162,R163,v14,arbace.c.build10,static-idxR164,v14,arbace.c.build9,obj-alignv14,arbace.c.check5,qualsR165,R166,R167,v14,arbace.c.build9,var-size?R168,R169,v14,arbace.c.build10,addressed?R170,R171,v14,arbace.c.build12,frame-alloc!l16,R172,R173,R174,v11,arbace.core5,classv14,arbace.c.build5,fn-idv14,arbace.c.build10,global-keyR175,R176,v14,arbace.c.build8,obj-sizeR177,R178,R179,R180,R181,R182,R148,R183,R184,R129,R130,R113,R185,R134,R186,v14,arbace.c.build8,dyn-copyR147,R187,R188,R125,R123,R189,R190,R138,R191,v14,arbace.c.check5,decayS2,R48,R40,v14,arbace.c.build3,vm?v14,arbace.c.check8,vm-type?v14,arbace.c.check9,var-size?S4,R192,R193,R194,R195,v14,arbace.c.build10,struct-defS4,R196,R197,R198,R199,R200,R201,R202,R203,R204,R205,v11,arbace.core9,with-metav11,arbace.core4,dropS2,R196,R197,R206,R207,R208,v14,arbace.c.build7,vmem-ofR209,R210,R211,R113,R138,R211,R113,R138,R211,R113,R138,R211,R113,R138,ML2,R104,l0,m4,R136,i705,R137,i58,R212,R133,R134,R134,R113,R138,R139,ML2,R104,l1,m4,R136,i707,R137,i91,R134,R210,R211,R113,R123,R135,R134,R134,R130,R135,R134,R134,R134,v14,arbace.c.build7,rt-elemR135,R139,R213,R214,v14,arbace.c.build8,local-ofR215,v14,arbace.c.build4,ptr?v11,arbace.core4,somev14,arbace.c.build6,res-ofR216,R217,v14,arbace.c.build6,rtt-ofR218,R219,v13,arbace.string12,starts-with?v11,arbace.core4,namev11,arbace.core4,subsR220,R221,R222,R223,R224,R141,R142,R225,R226,R227,R228,R229,R230,R211,R213,R211,R113,R138,R134,v11,arbace.core7,number?R104,R139,R139,R104,R104,v14,arbace.c.build10,member-tfsR231,R232,v11,arbace.core6,reducem2,R10,l8,R144,R133,v14,arbace.c.check12,member-alignm2,R10,l8,R139,R233,R234,S2,R47,R49,v14,arbace.c.build7,rec-rttv14,arbace.c.build13,*vm-typedefs*R235,R236,R237,R238,R238,R194,v14,arbace.c.build6,effectv14,arbace.c.build2,exR140,R239,R193,R192,R240,R241,R140,R134,R195,v11,arbace.core5,some?R113,R138,R113,R138,R139,R134,R104,R242,v14,arbace.c.build9,rt-dscalev14,arbace.c.build8,adds-dynR135,R213,R243,R244,v14,arbace.c.build12,mem-loc-addrS2,R245,R44,R224,v14,arbace.c.build5,ex-asR223,v14,arbace.c.build10,aget-placeR221,v14,arbace.c.build11,arrow-placev14,arbace.c.build5,placeR246,v14,arbace.c.build10,dyn-memberv14,arbace.c.build12,member-placeR247,v14,arbace.c.build18,compound-lit-placeS2,R248,R249,v14,arbace.c.build12,string-form?R250,R228,R230,R218,R251,R252,R253,v14,arbace.c.build13,string-staticR134,R252,R252,v14,arbace.c.build14,global-obj-idxR135,ML2,R104,l1,m4,R136,i922,R137,i34,R135,v14,arbace.c.check6,memberv14,arbace.c.check4,qualv14,arbace.c.build10,place-loadm2,R10,l8,R254,R255,R256,R140,R141,R142,R143,R257,R258,R259,R260,R261,R262,R263,R264,R265,v14,arbace.c.check7,promoteS4,R56,R55,R64,R59,S2,R55,R64,R266,S2,R16,R17,m2,R10,l8,v14,arbace.c.build6,carithv14,arbace.c.build6,op-symS4,s3,subs3,muls3,divs3,addR146,R139,R267,R139,R268,v14,arbace.c.check5,usualv14,arbace.c.build8,promotedR133,m2,R10,l8,R269,v14,arbace.c.build7,part-eqR107,R270,R132,R133,R271,S6,R257,R261,R258,R263,R264,R256,v14,arbace.c.build13,compare-nodesS2,R262,R260,v14,arbace.c.build5,shiftR141,R141,R142,R142,v14,arbace.c.build5,arithm2,R10,l8,R135,v14,arbace.c.build15,ptr-target-sizeR135,R139,R272,R272,R135,R145,R273,v11,arbace.core6,empty?R274,R107,R113,R107,ML2,R104,l0,m4,R136,i1061,R137,i71,R275,R276,R144,R113,R144,R107,ML2,R104,l0,m4,R136,i1068,R137,i66,R107,ML2,R104,l0,m4,R136,i1068,R137,i94,R277,R221,v14,arbace.c.build11,place-storeS2,R142,R141,R142,S2,R262,R260,m2,R10,l8,R148,R112,R147,R134,R113,R138,R134,R113,R138,R135,R221,S2,R229,R222,R104,R135,R104,ML2,R104,l1,m4,R136,i1119,R137,i73,R141,R104,S2,R216,R222,ML2,R104,l1,m4,R136,i1133,R137,i78,R141,R104,R134,R113,R138,R270,R148,R185,R134,R112,R147,R114,R190,R113,R138,R134,R270,R134,m4,R150,l0,R149,l0,R278,R211,R113,R107,ML2,R104,l0,m4,R136,i1145,R137,i79,v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v14,arbace.c.build13,*static-init*R159,R252,R279,v14,arbace.c.build17,build-init-storesR278,R280,R252,R281,v14,arbace.c.build9,add-init!v14,arbace.c.build8,init-cmdv14,arbace.c.build19,compound-lit-objectR107,v14,arbace.c.build12,string-unitsR252,v14,arbace.c.build12,units->bytesv11,arbace.core4,peekR282,R282,v11,arbace.core3,popR282,v14,arbace.c.build10,build-stmtR210,R113,R209,R210,ML2,R104,l0,m4,R136,i1204,R137,i79,R283,R284,R148,R275,R113,R209,ML2,R104,l0,m4,R136,i1219,R137,i67,R185,R209,R134,R213,R285,v14,arbace.c.build10,const-nodev14,arbace.c.check3,ptrR286,S8,R216,R229,R287,R219,R230,R222,R218,R288,R225,S3,R43,R42,R44,S2,R108,R269,v14,arbace.c.build9,call-nodeR289,R290,R130,R255,R141,R142,v14,arbace.c.build8,part-negv14,arbace.c.build8,with-rttv14,arbace.c.build6,binaryR249,R140,v14,arbace.c.build11,string-nodev11,arbace.core5,char?ML2,R104,l0,m4,R136,i1416,R137,i42,R291,v14,arbace.c.build6,fn-refR292,R131,R141,R142,R143,R257,R258,R228,v14,arbace.c.build7,if-nodeR293,R93,ML2,R102,l0,m4,R136,i1396,R137,i61,R102,R294,R264,S1,R295,v14,arbace.c.check7,t-floatR265,R296,R296,R297,v14,arbace.c.build4,elabR104,ML2,R104,l0,m4,R136,i1349,R137,i62,v11,arbace.core8,keyword?m2,R10,l8,R139,R139,R139,v11,arbace.core4,mapvR298,R299,R213,R223,R254,R218,v14,arbace.c.build6,assignR300,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R93,R293,ML2,R102,l0,m4,R136,i1374,R137,i57,R102,R301,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R219,v14,arbace.c.build6,incdecR299,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R91,R302,R269,R269,R115,R270,R303,v14,arbace.c.check6,t-voidR304,R229,R305,R306,R307,R217,R213,R224,R221,R247,v14,arbace.c.build12,compound-litR291,R308,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R230,R287,R288,R309,R259,R310,v14,arbace.c.build11,label-code!R260,R250,R261,R225,R311,R312,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R313,R314,R221,R256,R315,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R216,R262,R263,R248,R298,ML2,R104,l0,m4,R136,i1349,R137,i62,m2,R10,l8,R278,R222,R108,R108,R115,R227,v14,arbace.c.build9,stmt-exprR224,R104,R104,R316,m2,R10,l8,R317,R318,R319,R317,R320,R321,v11,arbace.core6,repeatv14,arbace.c.build8,pad-maskv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendl255,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core5,rangev11,arbace.core7,bit-andl255,l255,l255,l255,l255,v11,arbace.core4,pos?v14,arbace.c.build17,clear-padding-maxR135,ML2,R104,l1,m4,R136,i1539,R137,i46,R134,R113,R123,ML2,R104,l0,m4,R136,i1542,R137,i50,R113,R123,R139,R130,R104,ML2,R104,l0,m4,R136,i1542,R137,i50,R113,R107,R113,R138,ML2,R104,l0,m4,R136,i1545,R137,i90,ML2,R104,l0,m4,R136,i1571,R137,i54,v14,arbace.c.build18,clear-padding-callm2,R10,l8,R132,R132,R132,R132,R108,R132,R132,R102,R102,m2,R10,l8,v14,arbace.c.build12,seq-node-effR322,R102,R323,R104,m2,R10,l8,R104,S2,l0,l1,l-1,R102,R320,ML2,R104,l0,m4,R136,i1576,R137,i50,ML2,R159,l0,m4,R136,i1575,R137,i57,ML2,R104,l0,m4,R136,i1575,R137,i65,R113,R123,R104,l4,l18,l10,l12,l9,l5,l13,m2,R10,l8,m2,R10,l8,ML2,R104,l-1,m4,R136,i1573,R137,i55,R113,R107,ML2,R104,l0,m4,R136,i1599,R137,i86,v14,arbace.c.check8,int-bitsm2,R10,l8,v13,arbace.string9,includes?v13,arbace.string10,ends-with?v14,arbace.c.build10,exact-bitsm2,R14,R16,m2,R10,l8,R267,R185,R128,R128,R124,R126,m2,R10,l8,R107,R114,R190,R271,R114,R190,R134,R113,R123,R134,R185,R134,R130,R134,R107,R114,R190,R113,R138,R271,R324,R325,R326,m2,R10,l8,S4,s27,__builtin_stdc_rotate_rights24,__builtin_stdc_bit_floors23,__builtin_stdc_bit_ceils26,__builtin_stdc_rotate_leftv14,arbace.c.check6,t-uintS2,s14,__builtin_ctzgs14,__builtin_clzgV2,ML2,R317,ML2,R104,l0,m4,R136,i1696,R137,i66,m4,R136,i1696,R137,i62,ML2,R317,ML2,R104,l0,m4,R136,i1696,R137,i78,m4,R136,i1696,R137,i74,S2,s27,__builtin_stdc_rotate_rights26,__builtin_stdc_rotate_leftm2,R14,R17,v14,arbace.c.build11,native-callR317,R104,m2,R10,l8,R317,R321,v14,arbace.c.build8,arg-nodeML2,R317,ML2,R104,l1,m4,R136,i1696,R137,i52,m4,R136,i1696,R137,i48,R267,R103,R317,S4,s18,compare_exchange_ns10,exchange_ns6,load_ns7,store_nS4,s16,compare_exchanges4,loads8,exchanges5,storeV2,R327,FV2,R328,FS2,s12,thread_fences12,signal_fenceV2,R329,Fv11,arbace.core10,re-matchesp31,fetch_(add|sub|and|or|xor|nand)p31,(add|sub|and|or|xor|nand)_fetchl7,p35,fetch_and_(add|sub|and|or|xor|nand)p35,(add|sub|and|or|xor|nand)_and_fetchV2,R330,FV2,R331,FV2,R332,FV2,R333,FV2,R329,FR334,R335,R332,R336,R337,l6,R338,v13,arbace.string5,splitp1,_v14,arbace.c.build11,atomic-nameR329,S3,R45,R47,R49,v11,arbace.core1,=m2,R14,R61,m2,R14,R62,S3,R45,R47,R49,R113,R138,R134,R113,R138,R134,R113,R107,ML2,R104,l0,m4,R136,i1773,R137,i78,R142,R141,R254,R259,R265,R259,ML2,R104,l-1,m4,R136,i1778,R137,i83,R265,R333,l3,R107,R144,R133,R107,ML2,R104,l1,m4,R136,i1817,R137,i67,R107,ML2,R104,l0,m4,R136,i1818,R137,i69,R330,ML2,R104,l0,m4,R136,i1834,R137,i56,R133,R113,R144,ML2,R104,l0,m4,R136,i1823,R137,i89,R107,ML2,R104,l0,m4,R136,i1823,R137,i81,R107,R328,R331,ML2,R104,l0,m4,R136,i1834,R137,i56,ML2,R104,l0,m4,R136,i1823,R137,i89,ML2,R104,l0,m4,R136,i1823,R137,i81,R327,ML2,R104,l1,m4,R136,i1829,R137,i61,R107,R133,ML2,R104,l0,m4,R136,i1830,R137,i95,R213,v14,arbace.c.build12,builtin-callML1,R339,m4,R136,i1855,R137,i58,v14,arbace.c.build11,atomic-callv14,arbace.c.build17,overflow-builtinsv14,arbace.c.build13,overflow-callv14,arbace.c.build13,bitg-builtinsv14,arbace.c.build9,bitg-callv14,arbace.c.build15,builtin-aliasesv14,arbace.c.build15,builtin-nativesv14,arbace.c.build11,callee-typeR340,R341,R342,R213,ML1,R343,m4,R136,i1877,R137,i50,S6,s3,u16s3,u32s2,u8s3,i16s2,i8s3,i32R324,R324,R113,R344,R115,R325,R325,R325,R345,R326,v11,arbace.core6,removev11,arbace.core7,keywordR135,ML2,R104,l1,m4,R136,i1921,R137,i62,S10,R56,R58,R62,R57,R65,R64,R61,R53,R51,R50,v11,arbace.core4,takeV1,l0,R113,R189,R252,R177,R177,v14,arbace.c.build4,fillv14,arbace.c.build5,addr+v14,arbace.c.build10,subobjectsR177,R346,v14,arbace.c.build12,anon-membersv11,arbace.core12,keep-indexedv14,arbace.c.build9,fill-listR278,v14,arbace.c.build6,int-ofv14,arbace.c.build15,fill-designatedv11,arbace.core5,nnextv14,arbace.c.build10,elem-storeS2,R47,R49,R278,v14,arbace.c.build11,char-array?R278,R347,R348,S2,R47,R49,v14,arbace.c.build13,string-storesm2,R10,l8,R113,R189,R278,R278,R278,R113,R122,S12,R349,R350,R202,R198,R199,R351,R352,R353,R204,R354,R355,R356,v14,arbace.c.build11,*vla-stack*R210,R211,R113,R357,v14,arbace.c.build11,*vla-block*v11,arbace.core6,reset!R138,R211,R113,R138,R358,R211,R113,R138,R320,R204,v14,arbace.c.build10,local-declR350,S2,R245,R44,v14,arbace.c.build11,bind-local!v14,arbace.c.build8,set-rtt!v14,arbace.c.build9,vla-allocR210,R211,R113,R138,ML2,R104,l0,m4,R136,i2151,R137,i85,R212,R133,R134,R113,R138,R139,ML2,R104,l1,m4,R136,i2153,R137,i118,R134,R210,R211,R113,R123,ML2,R104,l0,m4,R136,i2154,R137,i156,R135,R134,R134,R359,R360,R278,R199,R354,R252,R211,R113,R107,ML2,R104,l0,m4,R136,i2166,R137,i133,R211,R198,R353,R213,v11,arbace.core7,re-findp73,^\\s*(__asm__|__asm|asm)\\s*(__volatile__|volatile|__volatile)?\\s*\\(\\s*\\\"\\\"p3,\\\"=R361,v14,arbace.c.build10,empty-asm?R210,v14,arbace.c.build5,stmtsv14,arbace.c.build12,setjmp-namesS2,R282,R210,S5,R362,R363,R364,R144,R365,R366,v11,arbace.core8,take-nthR367,R366,v11,arbace.core9,partitionv14,arbace.c.build7,do-nodeR364,v11,arbace.core7,reverseR368,v14,arbace.c.build9,vla-leavev14,arbace.c.build10,*vla-cont*ML2,R369,l3,m4,R136,i2305,R137,i41,R355,ML2,R210,V0,m4,R136,i2317,R137,i87,R363,R370,R371,R103,R271,R269,R271,R271,R144,R104,ML2,R104,l0,m4,R136,i2282,R137,i99,v14,arbace.c.build10,decl-head?R367,R372,v14,arbace.c.build5,stmt*R282,R373,R373,v14,arbace.c.build8,*switch*v14,arbace.c.build9,*vla-brk*R185,R374,R107,R114,R190,R374,R375,R211,R210,R212,R283,R376,R377,ML2,R210,V0,m4,R136,i2317,R137,i87,R211,R112,R147,R114,R190,R113,R138,R378,ML2,R210,V0,m4,R136,i2317,R137,i87,R379,ML2,R210,V0,m4,R136,i2317,R137,i87,R380,ML1,R381,m4,R136,i2307,R137,i19,R382,R383,R381,R384,R381,R385,R381,R386,R210,ML1,R381,m4,R136,i2311,R137,i58,R211,R381,R387,R144,R388,R389,v14,arbace.c.build11,fresh-code!R364,R282,R350,R388,R365,R210,R211,R113,R390,R211,R113,R357,R210,R361,ML2,R210,V0,m4,R136,i2316,R137,i35,R212,R391,ML2,R210,V0,m4,R136,i2317,R137,i87,R210,R392,R362,R369,R303,R212,R393,ML2,R369,l2,m4,R136,i2304,R137,i37,R211,R364,R349,ML2,R210,V0,m4,R136,i2317,R137,i87,R364,R394,ML2,R210,V0,m4,R136,i2317,R137,i87,R395,R388,R210,R211,R211,v14,arbace.c.build13,calls-setjmp?v14,arbace.c.build11,has-setjmp?R396,v11,arbace.core3,setR217,R217,R217,R213,R289,p21,^__builtin_(c23_)?va_R223,R397,R398,R398,R399,R398,R400,R401,v14,arbace.c.build9,asm-body?v14,arbace.c.build11,asm-nativesv14,arbace.c.build10,param-specS2,R402,R403,S3,s1,ps3,i64s3,u64R211,R113,R138,R115,R134,S3,s1,ps3,i64s3,u64m2,R14,R40,S2,R402,R403,ML2,R381,ML2,R385,ML2,R104,l0,m4,R136,i2433,R137,i60,m4,R136,i2433,R137,i54,m4,R136,i2433,R137,i49,R404,v14,arbace.c.build15,addressed-namesR405,R406,R400,R210,R407,v11,arbace.core7,ex-dataR408,R391,v11,arbace.core10,drop-whileR204,v11,arbace.core4,keepR350,R350,v13,arbace.string7,replacep7,^__|__$S2,s5,aliass9,__alias__V7,R409,R410,R411,R412,R413,R414,R415,S2,R245,R44,R416,R278,v11,arbace.core8,not-any?R177,v14,arbace.c.check10,init-countR278,R278,m2,R10,l8,R417,R418,R419,R420,R421,v14,arbace.c.build5,ex-ofR422,v14,arbace.c.build10,unit-formsR423,S3,R350,R352,R354,S3,R350,R352,R354,R204,S2,R245,R44,v14,arbace.c.build10,decl-attrsv14,arbace.c.build17,tentative-or-def?v14,arbace.c.build10,flex-extraR424,R425,R426,R427,v14,arbace.c.build9,frag-itemR252,S2,R245,R44,v14,arbace.c.build12,file-objectsR354,v14,arbace.c.build11,ex-res-namev11,arbace.core6,zipmapV3,R169,R233,R428,R429,R430,R431,v14,arbace.c.build8,build-fnV3,R169,R233,R428,R432,R433,v14,arbace.c.build8,new-fragv11,arbace.core4,map?R354,S2,R176,R42,S2,R176,R42,R434,R435,R436,p13,\\?([fs])(\\d+)R177,v14,arbace.c.build8,throw-exR87,R89,R87,v14,arbace.c.build7,reachedv14,arbace.c.build8,new-progv14,arbace.c.build12,*link-trace*R437,R438,R439,R440,R441,R442,R428,R443,R444,R445,v13,arbace.string6,blank?v11,arbace.core11,read-stringv13,arbace.string11,split-linesv14,arbace.c.build12,read-programv14,arbace.c.build9,link-textv14,arbace.c.build13,unit-fragmentR440,R441,R204,S3,R350,R352,R354,S3,R350,R352,R354,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S2,R245,R44,S2,R245,R44,S2,R245,R44,S2,R245,R44,R252,R204,S3,R350,R352,R354,S3,R350,R352,R354,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,S3,R350,R352,R354,R443,R444,")

var Lit_1 *jrt.String = jrt.Intern("arbace.c.build$add_init_BANG_$fn__558000377")

var Lit_2 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk__558001145")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk_base__558001158")

var Lit_4 *jrt.String = jrt.Intern(".-")

var Lit_5 *jrt.String = jrt.Intern("mul")

var Lit_6 *jrt.String = jrt.Intern("i64")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.build$align_of$fn__558000024")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.build$anon_members$fn__558001006")

var Lit_9 *jrt.String = jrt.Intern("")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.build$arg_node$fn__558000651")

var Lit_11 *jrt.String = jrt.Intern("an argument of variable size")

var Lit_12 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_13 *jrt.String = jrt.Intern("the operator ")

var Lit_14 *jrt.String = jrt.Intern(" on floating operands")

var Lit_15 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000310")

var Lit_16 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000312")

var Lit_17 *jrt.String = jrt.Intern("no member ")

var Lit_18 *jrt.String = jrt.Intern(" in ")

var Lit_19 *jrt.String = jrt.Intern(" of ")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000314")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000316")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_$walk__558001066")

var Lit_23 *jrt.String = jrt.Intern("the size of a structure of variable size")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.build$assign$fn__558000359")

var Lit_25 *jrt.String = jrt.Intern(" of a non-pointer")

var Lit_26 *jrt.String = jrt.Intern(" on an object of type ")

var Lit_27 *jrt.String = jrt.Intern(" (")

var Lit_28 *jrt.String = jrt.Intern(" bytes: libatomic's)")

var Lit_29 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$add_BANG___558000808")

var Lit_30 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$addr__558000810")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$orders__558000812")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$val__558000818")

var Lit_33 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$out__558000820")

var Lit_34 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$save__558000822")

var Lit_35 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$fin__558000824")

var Lit_36 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$void__558000826")

var Lit_37 *jrt.String = jrt.Intern("arbace.c.build$atomic_call$rmw__558000828")

var Lit_38 *jrt.String = jrt.Intern("eq")

var Lit_39 *jrt.String = jrt.Intern("ne")

var Lit_40 *jrt.String = jrt.Intern("sub")

var Lit_41 *jrt.String = jrt.Intern("add")

var Lit_42 *jrt.String = jrt.Intern("or")

var Lit_43 *jrt.String = jrt.Intern("and")

var Lit_44 *jrt.String = jrt.Intern("nand")

var Lit_45 *jrt.String = jrt.Intern("xor")

var Lit_46 *jrt.String = jrt.Intern("__atomic_")

var Lit_47 *jrt.String = jrt.Intern("store_n")

var Lit_48 *jrt.String = jrt.Intern("load_n")

var Lit_49 *jrt.String = jrt.Intern("exchange_n")

var Lit_50 *jrt.String = jrt.Intern("store")

var Lit_51 *jrt.String = jrt.Intern("load")

var Lit_52 *jrt.String = jrt.Intern("exchange")

var Lit_53 *jrt.String = jrt.Intern("test_and_set")

var Lit_54 *jrt.String = jrt.Intern("clear")

var Lit_55 *jrt.String = jrt.Intern("__sync_")

var Lit_56 *jrt.String = jrt.Intern("bool_compare_and_swap")

var Lit_57 *jrt.String = jrt.Intern("val_compare_and_swap")

var Lit_58 *jrt.String = jrt.Intern("lock_test_and_set")

var Lit_59 *jrt.String = jrt.Intern("lock_release")

var Lit_60 *jrt.String = jrt.Intern("synchronize")

var Lit_61 *jrt.String = jrt.Intern("div")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.build$binary$fn__558000339")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.build$bitg_call$fn__558000794")

var Lit_64 *jrt.String = jrt.Intern(" of an operand of type ")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.build$bitg_call$fn__558000796")

var Lit_66 *jrt.String = jrt.Intern("__builtin_stdc_has_single_bit")

var Lit_67 *jrt.String = jrt.Intern("__builtin_stdc_")

var Lit_68 *jrt.String = jrt.Intern("rem")

var Lit_69 *jrt.String = jrt.Intern(" of a bit-field")

var Lit_70 *jrt.String = jrt.Intern("no entry for the function ")

var Lit_71 *jrt.String = jrt.Intern(": inline assembly (SPEC §14)")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.build$build_fn$fn__558001167")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001169__558001173")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001179__558001183")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.build$build_fn$fn__558001189")

var Lit_76 *jrt.String = jrt.Intern("main")

var Lit_77 *jrt.String = jrt.Intern(": ")

var Lit_78 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001169__558001173$fn__558001174")

var Lit_79 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001169__558001173$fn__558001174$fn__558001175")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001179__558001183$fn__558001184")

var Lit_81 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558001179__558001183$fn__558001184$fn__558001185")

var Lit_82 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001617")

var Lit_83 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001647")

var Lit_84 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001649")

var Lit_85 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001651")

var Lit_86 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001653")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001655")

var Lit_88 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001657")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001659")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001661")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001667")

var Lit_92 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001679")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001700")

var Lit_94 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001707")

var Lit_95 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001718")

var Lit_96 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001727")

var Lit_97 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001759")

var Lit_98 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001764")

var Lit_99 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001769")

var Lit_100 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001774")

var Lit_101 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001779")

var Lit_102 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001784")

var Lit_103 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001789")

var Lit_104 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001794")

var Lit_105 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001808")

var Lit_106 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001815")

var Lit_107 *jrt.String = jrt.Intern("no main")

var Lit_108 *jrt.String = jrt.Intern("__libc_start_main")

var Lit_109 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001718$fn__558001719")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001727$fn__558001728")

var Lit_111 *jrt.String = jrt.Intern("__builtin_constant_p")

var Lit_112 *jrt.String = jrt.Intern("__builtin_va_end")

var Lit_113 *jrt.String = jrt.Intern("__builtin_isgreaterequal")

var Lit_114 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000723")

var Lit_115 *jrt.String = jrt.Intern("__builtin_isgreater")

var Lit_116 *jrt.String = jrt.Intern("gt")

var Lit_117 *jrt.String = jrt.Intern("__builtin_islessequal")

var Lit_118 *jrt.String = jrt.Intern("le")

var Lit_119 *jrt.String = jrt.Intern("__builtin_isless")

var Lit_120 *jrt.String = jrt.Intern("lt")

var Lit_121 *jrt.String = jrt.Intern("ge")

var Lit_122 *jrt.String = jrt.Intern("__builtin_clear_padding")

var Lit_123 *jrt.String = jrt.Intern("__builtin_nanf")

var Lit_124 *jrt.String = jrt.Intern("__builtin_nanl")

var Lit_125 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_126 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000729")

var Lit_127 *jrt.String = jrt.Intern("__builtin_expect_with_probability")

var Lit_128 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000732")

var Lit_129 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_130 *jrt.String = jrt.Intern("__builtin_va_start")

var Lit_131 *jrt.String = jrt.Intern("va_start of a register place")

var Lit_132 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000734")

var Lit_133 *jrt.String = jrt.Intern("__builtin_prefetch")

var Lit_134 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000736")

var Lit_135 *jrt.String = jrt.Intern("__atomic_always_lock_free")

var Lit_136 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000741")

var Lit_137 *jrt.String = jrt.Intern("__builtin_object_size")

var Lit_138 *jrt.String = jrt.Intern("__builtin_nan")

var Lit_139 *jrt.String = jrt.Intern("__builtin_inff")

var Lit_140 *jrt.String = jrt.Intern("__builtin_infl")

var Lit_141 *jrt.String = jrt.Intern("__builtin_alloca")

var Lit_142 *jrt.String = jrt.Intern("__builtin_assume_aligned")

var Lit_143 *jrt.String = jrt.Intern("__builtin_return_address")

var Lit_144 *jrt.String = jrt.Intern("__builtin_alloca_with_align")

var Lit_145 *jrt.String = jrt.Intern("alloca")

var Lit_146 *jrt.String = jrt.Intern("__builtin_expect")

var Lit_147 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000745")

var Lit_148 *jrt.String = jrt.Intern("__builtin_huge_val")

var Lit_149 *jrt.String = jrt.Intern("__builtin_frame_address")

var Lit_150 *jrt.String = jrt.Intern("__builtin_c23_va_start")

var Lit_151 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000747")

var Lit_152 *jrt.String = jrt.Intern("__builtin_va_copy")

var Lit_153 *jrt.String = jrt.Intern("u64")

var Lit_154 *jrt.String = jrt.Intern("__builtin_classify_type")

var Lit_155 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000753")

var Lit_156 *jrt.String = jrt.Intern("__builtin_huge_valf")

var Lit_157 *jrt.String = jrt.Intern("__builtin_huge_vall")

var Lit_158 *jrt.String = jrt.Intern("__builtin_nansf")

var Lit_159 *jrt.String = jrt.Intern("__builtin_nansl")

var Lit_160 *jrt.String = jrt.Intern("__builtin_islessgreater")

var Lit_161 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000759")

var Lit_162 *jrt.String = jrt.Intern("__builtin_assoc_barrier")

var Lit_163 *jrt.String = jrt.Intern("__builtin_dynamic_object_size")

var Lit_164 *jrt.String = jrt.Intern("__builtin_")

var Lit_165 *jrt.String = jrt.Intern("__builtin_va_arg_pack_len")

var Lit_166 *jrt.String = jrt.Intern("arbace.c.build$call_node$pack_QMARK___558000836")

var Lit_167 *jrt.String = jrt.Intern("arbace.c.build$call_node$fn__558000838")

var Lit_168 *jrt.String = jrt.Intern("__builtin_va_arg_pack")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.build$carith$s__558000162")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.build$carith$fb__558000164")

var Lit_171 *jrt.String = jrt.Intern(" on complex operands")

var Lit_172 *jrt.String = jrt.Intern("__builtin_clear_padding of a type with over ")

var Lit_173 *jrt.String = jrt.Intern(" bytes of padding")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$at__558000697")

var Lit_175 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000699__558000703")

var Lit_176 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000699__558000703$fn__558000704")

var Lit_177 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000699__558000703$fn__558000704$fn__558000705")

var Lit_178 *jrt.String = jrt.Intern("u8")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000065")

var Lit_180 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000067")

var Lit_181 *jrt.String = jrt.Intern("a string literal part ")

var Lit_182 *jrt.String = jrt.Intern("p")

var Lit_183 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes$fn__558000329")

var Lit_184 *jrt.String = jrt.Intern("a constant of type ")

var Lit_185 *jrt.String = jrt.Intern("b")

var Lit_186 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000112")

var Lit_187 *jrt.String = jrt.Intern("a cast to a union without a member of type ")

var Lit_188 *jrt.String = jrt.Intern("a conversion from ")

var Lit_189 *jrt.String = jrt.Intern(" to ")

var Lit_190 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000114")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs$walk__558001230")

var Lit_192 *jrt.String = jrt.Intern("weak")

var Lit_193 *jrt.String = jrt.Intern("the offset of a member after one of variable size")

var Lit_194 *jrt.String = jrt.Intern("arbace.c.build$elab$stmt_BANG___558000245")

var Lit_195 *jrt.String = jrt.Intern("arbace.c.build$elab$tname__558000247")

var Lit_196 *jrt.String = jrt.Intern("arbace.c.build$elab$slot_BANG___558000249")

var Lit_197 *jrt.String = jrt.Intern("arbace.c.build$elab$nd__558000251")

var Lit_198 *jrt.String = jrt.Intern("arbace.c.build$elab$up__558000253")

var Lit_199 *jrt.String = jrt.Intern("arbace.c.build$elab$rec_BANG___558000255")

var Lit_200 *jrt.String = jrt.Intern("arbace.c.build$elab$go__558000277")

var Lit_201 *jrt.String = jrt.Intern("a variably modified structure's members")

var Lit_202 *jrt.String = jrt.Intern("arbace.c.build$elab$rec_BANG___558000255$fn__558000261")

var Lit_203 *jrt.String = jrt.Intern("the size of a member of variable size")

var Lit_204 *jrt.String = jrt.Intern("arbace.c.build$elab$rec_BANG___558000255$fn__558000261$fn__558000268")

var Lit_205 *jrt.String = jrt.Intern("a bit-field after a member of variable size")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.build$elab$rec_BANG___558000255$fn__558000261$fn__558000271")

var Lit_207 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_208 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_209 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_210 *jrt.String = jrt.Intern("the builtin ")

var Lit_211 *jrt.String = jrt.Intern(" as a value")

var Lit_212 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000406")

var Lit_213 *jrt.String = jrt.Intern("va_arg of a register place")

var Lit_214 *jrt.String = jrt.Intern("unary ")

var Lit_215 *jrt.String = jrt.Intern("__real__ and __imag__ (SPEC §14)")

var Lit_216 *jrt.String = jrt.Intern("GNU ?: of a non-integer")

var Lit_217 *jrt.String = jrt.Intern("offsetof of a variably modified type")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000462")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000464")

var Lit_220 *jrt.String = jrt.Intern("sizeof of a variably modified type")

var Lit_221 *jrt.String = jrt.Intern("sizeof of a VLA")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000486")

var Lit_223 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000488")

var Lit_224 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000508")

var Lit_225 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000510")

var Lit_226 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000527")

var Lit_227 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000529")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000536")

var Lit_229 *jrt.String = jrt.Intern("__builtin_bit_cast")

var Lit_230 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000541")

var Lit_231 *jrt.String = jrt.Intern("_Generic without a chosen association")

var Lit_232 *jrt.String = jrt.Intern("GNU vector types (SPEC §14)")

var Lit_233 *jrt.String = jrt.Intern("the address of a register place ")

var Lit_234 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000553")

var Lit_235 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000555")

var Lit_236 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000595")

var Lit_237 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000597")

var Lit_238 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000614")

var Lit_239 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000616")

var Lit_240 *jrt.String = jrt.Intern("arbace.c.build$ex$nd__558000638")

var Lit_241 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000640")

var Lit_242 *jrt.String = jrt.Intern("an initializer list as an expression")

var Lit_243 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000647")

var Lit_244 *jrt.String = jrt.Intern("an expression ")

var Lit_245 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000464$fn__558000465")

var Lit_246 *jrt.String = jrt.Intern("an element of variable size")

var Lit_247 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000488$fn__558000489")

var Lit_248 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000510$fn__558000511")

var Lit_249 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000529$fn__558000530")

var Lit_250 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000555$fn__558000556")

var Lit_251 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000597$fn__558000598")

var Lit_252 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000616$fn__558000617")

var Lit_253 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000640$fn__558000641")

var Lit_254 *jrt.String = jrt.Intern("arbace.c.build$exact_bits$fn__558000767")

var Lit_255 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558001224")

var Lit_256 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558001224$fn__558001226")

var Lit_257 *jrt.String = jrt.Intern("#embed in an initializer (CS75)")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.build$fill$fn__558001026")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558001014")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558001016")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558001023")

var Lit_262 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558001016$fn__558001017")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.build$fill_list$put_BANG___558000879")

var Lit_264 *jrt.String = jrt.Intern("arbace.c.build$fill_list$out__558000881")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000933")

var Lit_266 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000935")

var Lit_267 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000937")

var Lit_268 *jrt.String = jrt.Intern(" to designate")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000979")

var Lit_270 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000981")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000983")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000937$fn__558000938")

var Lit_273 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000983$fn__558000984")

var Lit_274 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558001251")

var Lit_275 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558001253")

var Lit_276 *jrt.String = jrt.Intern("?f")

var Lit_277 *jrt.String = jrt.Intern("arbace.c.build$frag_item$fn__558001262")

var Lit_278 *jrt.String = jrt.Intern("f32")

var Lit_279 *jrt.String = jrt.Intern("f64")

var Lit_280 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx$fn__558000192")

var Lit_281 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx$fn__558000194")

var Lit_282 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_$in_expr__558001073")

var Lit_283 *jrt.String = jrt.Intern("%02x")

var Lit_284 *jrt.String = jrt.Intern("arbace.c.build$icarith$s__558000136")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.build$icarith$w__558000138")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.build$icarith$ib__558000140")

var Lit_287 *jrt.String = jrt.Intern("arbace.c.build$icarith$q__558000143")

var Lit_288 *jrt.String = jrt.Intern("arbace.c.build$icarith$ab__558000145")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.build$icarith$pick__558000147")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.build$incdec$step__558000368")

var Lit_291 *jrt.String = jrt.Intern("a designator that is not constant")

var Lit_292 *jrt.String = jrt.Intern("i8")

var Lit_293 *jrt.String = jrt.Intern("i32")

var Lit_294 *jrt.String = jrt.Intern("i16")

var Lit_295 *jrt.String = jrt.Intern("u16")

var Lit_296 *jrt.String = jrt.Intern("u32")

var Lit_297 *jrt.String = jrt.Intern("u")

var Lit_298 *jrt.String = jrt.Intern("s")

var Lit_299 *jrt.String = jrt.Intern("the type ")

var Lit_300 *jrt.String = jrt.Intern(" (SPEC §14)")

var Lit_301 *jrt.String = jrt.Intern("the complex type ")

var Lit_302 *jrt.String = jrt.Intern(" (deferred)")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.build$link_text$rk__558001424")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001426")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001428")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.build$link_text$subst__558001430")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.build$link_text$undefined_obj__558001438")

var Lit_308 *jrt.String = jrt.Intern("arbace.c.build$link_text$replay__558001440")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.build$link_text$keep_QMARK___558001480")

var Lit_310 *jrt.String = jrt.Intern("arbace.c.build$link_text$ob__558001558")

var Lit_311 *jrt.String = jrt.Intern("arbace.c.build$link_text$ob__558001566")

var Lit_312 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001592")

var Lit_313 *jrt.String = jrt.Intern("\n")

var Lit_314 *jrt.String = jrt.Intern("arbace.c.build$link_text$subst__558001430$fn__558001432")

var Lit_315 *jrt.String = jrt.Intern("f")

var Lit_316 *jrt.String = jrt.Intern("ci link: unresolved ?")

var Lit_317 *jrt.String = jrt.Intern("ci link: ")

var Lit_318 *jrt.String = jrt.Intern("UTF-8")

var Lit_319 *jrt.String = jrt.Intern("no entry for ")

var Lit_320 *jrt.String = jrt.Intern("arbace.c.build$local_decl$fn__558001043")

var Lit_321 *jrt.String = jrt.Intern("a VLA's size")

var Lit_322 *jrt.String = jrt.Intern("GNU nested functions (SPEC §14)")

var Lit_323 *jrt.String = jrt.Intern("arbace.c.build$member_tfs$mt__558000215")

var Lit_324 *jrt.String = jrt.Intern("arbace.c.build$member_tfs$mt__558000215$sub__558000216")

var Lit_325 *jrt.String = jrt.Intern("arbace.c.build$obj_size$fn__558000185")

var Lit_326 *jrt.String = jrt.Intern("shl")

var Lit_327 *jrt.String = jrt.Intern("shr")

var Lit_328 *jrt.String = jrt.Intern("_overflow_p")

var Lit_329 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000776")

var Lit_330 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000778")

var Lit_331 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000780")

var Lit_332 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000782")

var Lit_333 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000784")

var Lit_334 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000786")

var Lit_335 *jrt.String = jrt.Intern(" with a result of type ")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fill__558000655")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000658__558000662")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000668")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674")

var Lit_340 *jrt.String = jrt.Intern("__builtin_clear_padding: a flexible array member does not have well defined padding bits")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000668$fn__558000669")

var Lit_342 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000668$fn__558000671")

var Lit_343 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000675__558000679")

var Lit_344 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000685__558000689")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000675__558000679$fn__558000680")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000675__558000679$fn__558000680$fn__558000681")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000685__558000689$fn__558000690")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000674$iter__558000685__558000689$fn__558000690$fn__558000691")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000658__558000662$fn__558000663")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000658__558000662$fn__558000663$fn__558000664")

var Lit_351 *jrt.String = jrt.Intern("a parameter's place")

var Lit_352 *jrt.String = jrt.Intern("__func__")

var Lit_353 *jrt.String = jrt.Intern("no declaration of ")

var Lit_354 *jrt.String = jrt.Intern("a local outside its function: ")

var Lit_355 *jrt.String = jrt.Intern("not a place: ")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.build$program_text$fn__558001830")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.build$promoted$fn__558000322")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.build$reached$reach_BANG___558001360")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001362")

var Lit_360 *jrt.String = jrt.Intern("arbace.c.build$reached$include_BANG___558001374")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001362$iter__558001363__558001367")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001362$iter__558001363__558001367$fn__558001368")

var Lit_363 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001362$iter__558001363__558001367$fn__558001368$fn__558001369")

var Lit_364 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001599__558001603")

var Lit_365 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001599__558001603$fn__558001604")

var Lit_366 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001599__558001603$fn__558001604$fn__558001605")

var Lit_367 *jrt.String = jrt.Intern("no result for ")

var Lit_368 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$as_ptr__558000231")

var Lit_369 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$ptr_arg__558000233")

var Lit_370 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$ptr_arg__558000233$fn__558000234")

var Lit_371 *jrt.String = jrt.Intern("arbace.c.build$size_of$fn__558000021")

var Lit_372 *jrt.String = jrt.Intern("size of an incomplete type ")

var Lit_373 *jrt.String = jrt.Intern("?s")

var Lit_374 *jrt.String = jrt.Intern("arbace.c.build$static_idx$fn__558000051")

var Lit_375 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001084")

var Lit_376 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001092")

var Lit_377 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$wc__558001094")

var Lit_378 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$test__558001097")

var Lit_379 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001102")

var Lit_380 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001105")

var Lit_381 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001113")

var Lit_382 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001126")

var Lit_383 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001131")

var Lit_384 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001133")

var Lit_385 *jrt.String = jrt.Intern("inline assembly (SPEC §14)")

var Lit_386 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558001135")

var Lit_387 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$v__558001140")

var Lit_388 *jrt.String = jrt.Intern("case outside a switch")

var Lit_389 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$fn__558000395")

var Lit_390 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$wv__558000398")

var Lit_391 *jrt.String = jrt.Intern("arbace.c.build$stmts$fn__558001069")

var Lit_392 *jrt.String = jrt.Intern("arbace.c.build$string_static$fn__558000058")

var Lit_393 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000845")

var Lit_394 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000847__558000851")

var Lit_395 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000857")

var Lit_396 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000859__558000863")

var Lit_397 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000847__558000851$fn__558000852")

var Lit_398 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000847__558000851$fn__558000852$fn__558000853")

var Lit_399 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000859__558000863$fn__558000864")

var Lit_400 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000859__558000863$fn__558000864$fn__558000865")

var Lit_401 *jrt.String = jrt.Intern("a condition of type ")

var Lit_402 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558001196__558001200")

var Lit_403 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558001212")

var Lit_404 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558001196__558001200$fn__558001201")

var Lit_405 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558001196__558001200$fn__558001201$fn__558001202")

var Lit_406 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558001212$fn__558001217")

var Lit_407 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558001212$fn__558001219")

var Lit_408 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265")

var Lit_409 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001283")

var Lit_410 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289")

var Lit_411 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331")

var Lit_412 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265$iter__558001266__558001272")

var Lit_413 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265$iter__558001266__558001272$fn__558001273")

var Lit_414 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265$iter__558001266__558001272$fn__558001273$iter__558001268__558001274")

var Lit_415 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265$iter__558001266__558001272$fn__558001273$iter__558001268__558001274$fn__558001275")

var Lit_416 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001265$iter__558001266__558001272$fn__558001273$iter__558001268__558001274$fn__558001275$fn__558001276")

var Lit_417 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294")

var Lit_418 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295")

var Lit_419 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001296")

var Lit_420 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001316")

var Lit_421 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001319")

var Lit_422 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001296$fn__558001300")

var Lit_423 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001296$fn__558001303")

var Lit_424 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001296$fn__558001303$fn__558001307")

var Lit_425 *jrt.String = jrt.Intern("no definition")

var Lit_426 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001296$fn__558001303$fn__558001309")

var Lit_427 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001319$fn__558001323")

var Lit_428 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001289$iter__558001290__558001294$fn__558001295$fn__558001319$fn__558001325")

var Lit_429 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336")

var Lit_430 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337")

var Lit_431 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337$fn__558001338")

var Lit_432 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337$ent__558001351")

var Lit_433 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337$fn__558001354")

var Lit_434 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337$fn__558001338$ent__558001342")

var Lit_435 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001331$iter__558001332__558001336$fn__558001337$fn__558001338$fn__558001345")

var Lit_436 *jrt.String = jrt.Intern("s128")

var Lit_437 *jrt.String = jrt.Intern("u128")

var Lit_438 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn12,ldouble-sizekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,&yn4,bodykn8,declaredyn3,clsyn3,msgyn1,tkn3,tagyn4,longyn6,Stringyn8,seen-keyyn2,evyn3,keyyn4,specyn1,lyn3,cmdyn2,royn4,sizeyn5,alignyn5,bytesyn16,java.lang.Stringyn1,xyn5,unitsyn1,fyn1,vkn4,keysyn1,kyn1,nyn2,ftyn1,ayn1,yyn2,reyn2,imyn3,preyn2,opyn1,byn2,otyn2,kwyn1,eyn3,locv11,arbace.core5,in-nsMyn14,arbace.c.buildm2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.m2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.c.build5,*cfg*m2,R2,l8,m8,R3,TR4,i24,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,with-typesm10,R7,TR8,L1,V2,R9,R10,R4,i26,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,cpartsm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,cmakem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,complex?m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,seq-nodem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,temp-im8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,frame-tempm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,new-slot!m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,var-size?m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,vmem-ofm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,dyn-memberm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,dyn-copym8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-negm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,refusem10,R7,TR8,L1,V3,R12,R9,R13,R4,i31,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,unqv14,arbace.c.check3,unqm6,R4,i37,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,underm12,R7,TR8,L1,V1,R14,R0,s81,A type with its enumeration replaced by its compatible integer type, unqualified.R4,i39,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,size-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i44,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,align-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i48,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,wide?m10,R7,TR8,L1,V1,R14,R4,i50,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,kindm10,R8,L1,V1,R14,R0,s139,A type's node kind: :i (integers of at most 64 bits, pointers, bool), :f, :w (wider integers), :m (an\n  aggregate: its address), :v (void).R4,i54,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,itym10,R8,L1,V1,R14,R0,s109,An integer type's machine name: i8 u8 i16 u16 i32 u32 i64 u64 b p, sN/uN for a _BitInt(N) of at most 64 bits.R4,i77,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,wtym8,R8,L1,V1,R14,R4,i95,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,f32?m10,R7,TR8,L1,V1,R14,R4,i101,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,ftym10,R7,TR8,L1,V1,R14,R4,i102,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,ptr?m10,R7,TR8,L1,V1,R14,R4,i104,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,unsigned-ty?m10,R7,TR8,L1,V1,Myn1,sm2,R15,R17,R4,i105,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*p*m8,R3,TR4,i110,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,*item*m8,R3,TR4,i111,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,new-fragm10,R7,TR8,L1,V0,R4,i118,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,item-ref!m12,R7,TR8,L1,V2,R18,R19,R0,s60,The current item's reference ev (once: its first), recorded.R4,i126,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,frag-static!m12,R7,TR8,L1,V2,R20,R21,R0,s74,A fragment's static L for key, its spec made by (spec) when new: [L new?].R4,i132,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,sphm10,R7,TR8,L1,V1,R22,R4,i143,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,new-progm10,R7,TR8,L1,V0,R4,i145,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*u*m8,R3,TR4,i159,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*f*m8,R3,TR4,i160,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,emit!m10,R7,TR8,L1,V1,R23,R4,i162,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fn-idm10,R8,L1,V2,R20,Myn2,nmm2,R15,R17,R0,s93,The function of the key (a name, or [unit name] for a static one): its id, declared when new.R4,i164,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,ro-codem12,R7,TR8,L1,V1,R24,R0,s111,A static's RO field: 1 read-only, 2 thread-local (go/arbace/ci's thread.go: each thread its own bytes), 0 else.R4,i180,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,static-idxm12,R7,TR8,L1,V4,R20,R25,R26,R24,R0,s108,A static object's index, allocated (SIZE ALIGN RO) when new; ro true, false or :tls (a thread-local object).R4,i185,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,hex-ofm10,R7,TR8,L1,MV1,Myn1,bm2,R15,R27,m2,R15,R28,R4,i200,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,string-staticm12,R7,TR8,L1,V2,Myn2,bsm2,R15,R27,Myn5,esizem2,R15,R16,R0,s102,A string literal's array (its code units of `esize` bytes and the NUL) in read-only memory: its index.R4,i205,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,utf8m10,R7,TR8,L1,MV1,Myn1,sm2,R15,R17,m2,R15,R27,R4,i226,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,code-unitsm12,R7,TR8,L1,V2,R29,Myn5,esizem2,R15,R16,R0,s76,The code units of a string-ish literal part for an element of `esize` bytes.R4,i228,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,units->bytesm10,R7,TR8,L1,MV2,R30,Myn5,esizem2,R15,R16,m2,R15,R27,R4,i240,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-form?m10,R7,TR8,L1,V1,R29,R4,i246,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-unitsm12,R7,TR8,L1,V1,R29,R0,s30,A string form's [units esize].R4,i252,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-resm10,R7,TR8,L1,V1,R31,R4,i263,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,lit-resm12,R7,TR8,L1,V1,R29,R0,s58,A bare literal's type and value (the checker's rules, §8).R4,i265,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,res-ofm10,R7,TR8,L1,V1,R31,R4,i280,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fbitsm10,R7,TR8,L1,V1,R32,R4,i282,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,int-constm12,R7,TR8,L1,V2,R32,R14,R0,s45,The node of the integer constant v at type t.R4,i284,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,const-nodem12,R7,TR8,L1,V2,R32,R14,R0,s51,A constant value v of type t as a node of t's kind.R4,i292,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,truthm12,R7,TR8,L1,V1,m2,R33,V3,R34,R35,R14,R0,s52,A node as a condition: an I node, nonzero when true.R4,i305,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i316,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,convm10,R8,L1,V2,R29,R14,R0,s31,The node x converted to type t.R4,i318,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R14,R4,i364,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i366,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i366,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i366,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,part-loadm12,R7,TR8,L1,V2,R36,R37,R0,s43,A complex part of type ft at the address a.R4,i368,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,part-storem12,R7,TR8,L1,V3,R36,R37,R29,R0,s70,The store of the part node x (of type ft) at the address a, an effect.R4,i373,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,part-negm10,R7,TR8,L1,V1,R29,R4,i378,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,part-eqm12,R7,TR8,L1,V2,R29,R38,R0,s51,Whether two parts of one type are equal: an I node.R4,i380,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V1,R29,R0,s68,A complex node's parts: [effects re im], its address evaluated once.R4,i385,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V4,R14,R39,R40,R41,R0,s84,A complex value of type t from its parts (effects pre first): a temporary's address.R4,i395,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,icarithm12,R7,TR8,L1,V4,R42,R37,R43,R44,R0,s434,A complex integer operator at the complex type ot (GNU's, CS105): gcc's tree-complex.cc lowering, the parts'\n  arithmetic in the part type (+ and - by parts; * as (ac - bd) + (ad + bc)i; / as ((ac + bd) + (bc - ad)i) / (cc + dd),\n  each intermediate wrapped to the part type: computed in 64 bits and converted back, which gives the part type's low bits\n  for +, - and *, and dividing the wrapped values in the part type's signedness).R4,i407,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,carithm12,R7,TR8,L1,V4,R42,R37,R43,R44,R0,s189,A complex operator at the complex type ot (gcc -O0's formulas; its __muldc3 and __divdc3 handle\n  infinities and NaNs more carefully: SPEC §13's class complex-edge when a program shows it).R4,i444,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,effectm12,R7,TR8,L1,V1,m2,R33,V2,R34,R35,R0,s20,A node as an effect.R4,i470,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fstatem10,R7,TR8,L1,V0,R4,i478,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R34,R4,i480,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,frame-alloc!m12,R7,TR8,L1,MV2,Myn4,sizem2,R15,R16,Myn5,alignm2,R15,R16,m2,R15,R16,R0,s54,size bytes of the frame's memory, aligned: the offset.R4,i486,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,label-code!m10,R7,TR8,L1,V1,R45,R4,i494,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,fresh-code!m10,R7,TR8,L1,V0,R4,i499,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,local-ofm10,R7,TR8,L1,V1,R46,R4,i504,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,addressed?m12,R7,TR8,L1,V2,Myn1,nm2,R15,R17,R14,R0,s142,Whether the local `n` is in memory: its address is taken (by name, anywhere in the function), or its\n  type is an aggregate or a wide integer.R4,i506,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,obj-alignm12,R7,TR8,L1,MV2,R46,R14,m2,R15,R16,R0,s207,An object's alignment: its type's, raised by its alignment specifiers (the checker's :c/declared-align, 6.7.6;\n  queue 173) and its declarations' aligned attributes (the checker's :dalign, gcc's DECL_ALIGN).R4,i512,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,mem-loc-addrm12,R7,TR8,L1,V1,R47,R0,s110,A frame object's address node: its offset's, rounded up to :align-up when the frame's 16 bytes are not enough.R4,i518,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,bind-local!m12,R7,TR8,L1,V2,R46,R14,R0,s65,A local object's place (6.2.4: automatic storage), or a static's.R4,i526,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,global-keym10,R7,TR8,L1,V1,R46,R4,i549,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,obj-sizem12,R7,TR8,L1,V1,R46,R0,s246,An undefined object's size and alignment as global-obj-idx allocates it (the entry e's alignment specifiers too,\n  obj-align): [size align], or [nil nil message] when its alignment throws (only an error when the object is in the end\n  undefined).R4,i552,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fn-refm10,R7,TR8,L1,V1,R46,R4,i561,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build14,global-obj-idxm12,R7,TR8,L1,V1,R46,R0,s157,A file-scope object's (or a block-scope extern's) static index: allocated by the program's linking\n  (arbace.c.build/link), else here with its declared type.R4,i564,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build2,exm8,R11,TR4,i584,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,ex-asm8,R11,TR4,i584,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,build-stmtm8,R11,TR4,i584,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build17,build-init-storesm8,R11,TR4,i584,R5,i1,R6,s17,arbace/c/build.ae")

var Lit_439 *jrt.String = jrt.Intern("arbace.c.build$eval558000004$loading__1927001464__auto____558000005")

var Lit_440 *jrt.String = jrt.Intern("arbace.c.build$eval558000008$fn__558000009")

var Lit_441 *jrt.String = jrt.Intern("arbace.c.build$with_types")

var Lit_442 *jrt.String = jrt.Intern("arbace.c.build$refuse")

var Lit_443 *jrt.String = jrt.Intern("arbace.c.build$under")

var Lit_444 *jrt.String = jrt.Intern("arbace.c.build$size_of")

var Lit_445 *jrt.String = jrt.Intern("arbace.c.build$align_of")

var Lit_446 *jrt.String = jrt.Intern("arbace.c.build$wide_QMARK_")

var Lit_447 *jrt.String = jrt.Intern("arbace.c.build$kind")

var Lit_448 *jrt.String = jrt.Intern("arbace.c.build$ity")

var Lit_449 *jrt.String = jrt.Intern("arbace.c.build$wty")

var Lit_450 *jrt.String = jrt.Intern("arbace.c.build$f32_QMARK_")

var Lit_451 *jrt.String = jrt.Intern("arbace.c.build$fty")

var Lit_452 *jrt.String = jrt.Intern("arbace.c.build$ptr_QMARK_")

var Lit_453 *jrt.String = jrt.Intern("arbace.c.build$unsigned_ty_QMARK_")

var Lit_454 *jrt.String = jrt.Intern("arbace.c.build$new_frag")

var Lit_455 *jrt.String = jrt.Intern("arbace.c.build$item_ref_BANG_")

var Lit_456 *jrt.String = jrt.Intern("arbace.c.build$frag_static_BANG_")

var Lit_457 *jrt.String = jrt.Intern("arbace.c.build$sph")

var Lit_458 *jrt.String = jrt.Intern("arbace.c.build$new_prog")

var Lit_459 *jrt.String = jrt.Intern("arbace.c.build$emit_BANG_")

var Lit_460 *jrt.String = jrt.Intern("arbace.c.build$fn_id")

var Lit_461 *jrt.String = jrt.Intern("arbace.c.build$ro_code")

var Lit_462 *jrt.String = jrt.Intern("arbace.c.build$static_idx")

var Lit_463 *jrt.String = jrt.Intern("arbace.c.build$hex_of")

var Lit_464 *jrt.String = jrt.Intern("arbace.c.build$string_static")

var Lit_465 *jrt.String = jrt.Intern("arbace.c.build$utf8")

var Lit_466 *jrt.String = jrt.Intern("arbace.c.build$code_units")

var Lit_467 *jrt.String = jrt.Intern("arbace.c.build$units__GT_bytes")

var Lit_468 *jrt.String = jrt.Intern("arbace.c.build$string_form_QMARK_")

var Lit_469 *jrt.String = jrt.Intern("arbace.c.build$string_units")

var Lit_470 *jrt.String = jrt.Intern("arbace.c.build$ex_res")

var Lit_471 *jrt.String = jrt.Intern("arbace.c.build$lit_res")

var Lit_472 *jrt.String = jrt.Intern("arbace.c.build$res_of")

var Lit_473 *jrt.String = jrt.Intern("arbace.c.build$fbits")

var Lit_474 *jrt.String = jrt.Intern("arbace.c.build$int_const")

var Lit_475 *jrt.String = jrt.Intern("arbace.c.build$const_node")

var Lit_476 *jrt.String = jrt.Intern("arbace.c.build$truth")

var Lit_477 *jrt.String = jrt.Intern("arbace.c.build$conv")

var Lit_478 *jrt.String = jrt.Intern("arbace.c.build$complex_QMARK_")

var Lit_479 *jrt.String = jrt.Intern("arbace.c.build$part_load")

var Lit_480 *jrt.String = jrt.Intern("arbace.c.build$part_store")

var Lit_481 *jrt.String = jrt.Intern("arbace.c.build$part_neg")

var Lit_482 *jrt.String = jrt.Intern("arbace.c.build$part_eq")

var Lit_483 *jrt.String = jrt.Intern("arbace.c.build$cparts")

var Lit_484 *jrt.String = jrt.Intern("arbace.c.build$cmake")

var Lit_485 *jrt.String = jrt.Intern("arbace.c.build$icarith")

var Lit_486 *jrt.String = jrt.Intern("arbace.c.build$carith")

var Lit_487 *jrt.String = jrt.Intern("arbace.c.build$effect")

var Lit_488 *jrt.String = jrt.Intern("arbace.c.build$fstate")

var Lit_489 *jrt.String = jrt.Intern("arbace.c.build$new_slot_BANG_")

var Lit_490 *jrt.String = jrt.Intern("arbace.c.build$frame_alloc_BANG_")

var Lit_491 *jrt.String = jrt.Intern("arbace.c.build$label_code_BANG_")

var Lit_492 *jrt.String = jrt.Intern("arbace.c.build$fresh_code_BANG_")

var Lit_493 *jrt.String = jrt.Intern("arbace.c.build$local_of")

var Lit_494 *jrt.String = jrt.Intern("arbace.c.build$addressed_QMARK_")

var Lit_495 *jrt.String = jrt.Intern("arbace.c.build$obj_align")

var Lit_496 *jrt.String = jrt.Intern("arbace.c.build$mem_loc_addr")

var Lit_497 *jrt.String = jrt.Intern("arbace.c.build$bind_local_BANG_")

var Lit_498 *jrt.String = jrt.Intern("arbace.c.build$global_key")

var Lit_499 *jrt.String = jrt.Intern("arbace.c.build$obj_size")

var Lit_500 *jrt.String = jrt.Intern("arbace.c.build$fn_ref")

var Lit_501 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx")

var Lit_502 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn4,keysyn4,modeyn1,kyn1,ayn1,tyn4,bitsyn6,bitoffyn4,unityn5,vsizeyn1,vkn3,dockn3,tagyn4,longkn7,dynamicyn2,tfyn4,bodyyn2,rtyn6,Stringyn2,mmyn3,dstyn3,srcyn1,nyn4,baseyn3,idxyn1,dyn1,fyn1,xyn5,paramyn1,eyn1,iyn2,bpyn1,hyn1,ryn2,opyn1,byn2,otyn2,rayn2,rbyn1,yyn2,rxyn2,ryyn2,esyn1,cyn2,fsyn6,storesyn3,cmdyn2,ptyn1,pyn4,argsyn5,argnsyn3,offyn3,elsyn6,bracedyn2,dsyn4,inityn4,zeroyn5,depthyn3,jmpyn3,locyn5,itemsyn1,sv14,arbace.c.build9,call-nodem8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,member-placem8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,arrow-placem8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aem8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,seq-node-effm8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,fill-designatedm8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,anon-membersm8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build18,compound-lit-placem8,R0,TR1,i584,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,place-loadm10,R4,TR5,L1,V1,m2,R6,V7,R7,R8,R9,R10,R11,R12,R13,R1,i586,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,place-storem12,R4,TR5,L1,V2,m2,R6,V8,R7,R8,R9,R10,R11,R12,R13,R14,R15,R16,s97,A store of the node v (of the place's type) into the place: the node, its value the value stored.R1,i602,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,ptr-target-sizem12,R4,TR5,L1,MV1,R10,m2,R17,R18,R16,s76,The size of what a pointer type points to (1 for void and functions, GNU's).R1,i619,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,*vm-typedefs*m8,R19,TR1,i631,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build3,vm?m12,R4,TR5,L1,V1,R10,R16,s162,Whether a type is variably modified through arrays and pointers, or a structure or union with a variably modified\n  member (GNU's; the checker's vm-type?, CS106).R1,i633,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R10,R16,s73,Whether a type's size is the run time's (a VLA, a structure holding one).R1,i644,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,struct-defm12,R4,TR5,L1,V1,R20,R16,s170,The definition of a variably modified structure or union a type form holds at its head (through qualifiers):\n  [kind record body], the checker's record found by its body.R1,i651,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,rec-rttm12,R4,TR5,L1,V1,R10,R16,s74,A variably modified record's rtt, once its definition ran in the function.R1,i664,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,member-tfsm12,R4,TR5,L1,V1,R21,R16,s152,A definition's members' type forms, in the checker's member order (arbace.c.check's member-forms): a group's c/base\n  replaced by the group's base form.R1,i667,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V2,R22,Myn1,nm2,R17,R23,R16,s72,The rtt member entry {:off :rt} of the member named n of a record's rtt.R1,i685,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V2,R24,R22,R16,s125,The checker's member mm of the record whose rtt is rt, its offset the run time's when it follows a member of variable\n  size.R1,i690,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V3,R25,R26,R27,R16,s113,A copy of n bytes (a node) from the address src to dst: a node whose value is dst (a structure of variable size).R1,i698,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,rt-elemm12,R4,TR5,L1,V1,R22,R16,s41,A pointer's or array's rtt's element rtt.R1,i713,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,rt-dscalem12,R4,TR5,L1,V1,R22,R16,s112,The run-time size of the element of a pointer or array of rtt rt when it is variably modified: a node, else nil.R1,i716,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,adds-dynm12,R4,TR5,L1,V3,R28,R29,R30,R16,s52,base + idx elements of the run-time size d (a node).R1,i722,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,rtt-ofm12,R4,TR5,L1,V1,R31,R16,s82,The rtt of the form f when its type is variably modified and known here, else nil.R1,i727,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,with-rttm12,R4,TR5,L1,V2,R31,R32,R16,s55,The node x of the form f with f's rtt, when it has one.R1,i758,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build4,elabm12,R4,TR5,L1,V3,R20,R10,R33,R16,s340,The type form tf of the checker's type t elaborated: [stmts rtt], the statements evaluating its arrays' sizes\n  in order. param: tf is a parameter's declared type, t its adjusted one: the array's own size is evaluated for its\n  effects (gcc evaluates `int b[a++]` at the function's entry) and its element elaborated as the pointer's target.R1,i761,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,set-rtt!m12,R4,TR5,L1,V2,R34,R22,R16,s24,The local entry e's rtt.R1,i848,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,aget-placem12,R4,TR5,L1,V3,R9,R35,R10,R16,s44,The place a[i] of element type t (i[a] too).R1,i853,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,placem12,R4,TR5,L1,V1,R31,R16,s27,A form's place (an lvalue).R1,i866,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V3,R36,R24,R10,R16,s43,The member mm of the aggregate at place bp.R1,i918,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R31,R16,s49,(-> p a b): p->a->b, each step through a pointer.R1,i937,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V0,R1,i961,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,op-symm10,R4,TR5,L1,V1,R37,R1,i963,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,promotedm12,R4,TR5,L1,V1,R38,R16,s323,An operand's promoted type; a bit-field wider than int of a 64-bit or 128-bit type is gcc's N-bit type (its\n  arithmetic wraps at its width: pr32244-1, bitfld-3; the 128-bit types' since queue 164). A _BitInt bit-field is\n  promoted to its declared type, as chk/promote does (gcc's c-typeck.cc perform_integral_promotions).R1,i967,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,arithm12,R4,TR5,L1,V4,R39,R9,R40,R41,R16,s125,The operator op over the nodes a and b at the operation type ot (the usual arithmetic conversions'),\n  the result of type rt.R1,i982,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,shiftm10,R4,TR5,L1,V3,R39,R9,R40,R1,i996,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,compare-nodesm10,R4,TR5,L1,V5,R39,R9,R40,R42,R43,R1,i1002,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,binarym10,R4,TR5,L1,V6,R37,R32,R44,R45,R46,R22,R1,i1019,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V1,R44,R1,i1041,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V2,R31,R8,R16,s63,A form's node converted to the node kind k (for addresses: :i).R1,i1046,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V2,R47,R32,R16,s28,Effects es then the value x.R1,i1052,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,if-nodem10,R4,TR5,L1,V4,R48,R9,R40,R10,R1,i1063,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,assignm10,R4,TR5,L1,V1,R31,R1,i1070,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,incdecm10,R4,TR5,L1,V1,R31,R1,i1105,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,*static-init*m8,R19,TR1,i1139,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,init-cmdm12,R4,TR5,L1,V2,R49,R50,R16,s105,A static initializer's command: (init NI NF STMT), run before the program starts in a frame of its slots.R1,i1141,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,add-init!m12,R4,TR5,L1,V1,R51,R16,s106,A static initializer's command added to the program's (in a fragment, to its item's references, in order).R1,i1147,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R10,R16,s63,A temporary aggregate of type t in the frame: its address node.R1,i1155,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build19,compound-lit-objectm12,R4,TR5,L1,V1,R31,R16,s165,A compound literal's object: {:t :a (its address node) :stores (the initializing stores to run before it, none when\n  static: those are the program's initializers)}.R1,i1162,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,compound-litm10,R4,TR5,L1,V1,R31,R1,i1182,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R31,R16,s188,A compound literal as a place (`&(int){5}`, `(double){2.5} += 1`): its address after its stores (queue 173: the\n  place took the literal's value node, a load for a scalar, as its address).R1,i1186,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,string-nodem10,R4,TR5,L1,V2,R31,R10,R1,i1193,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,stmt-exprm10,R4,TR5,L1,V1,R31,R1,i1197,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V1,R31,R16,s26,A form's node: {:k :n :t}.R1,i1222,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,builtin-aliasesS186,s5,cbrtls5,floors5,log1ps6,mallocs4,ceils5,rintfs6,strcmps3,fmas4,frees4,coshs6,expm1fs5,exp2fs6,strdups5,fmodfs6,printfs6,strcpys14,fputs_unlockeds4,nanls5,fmaxls6,strspns6,strchrs7,isalphas4,labss6,lrounds7,isalnums7,scalbnls10,nearbyintls6,memchrs5,sqrtls5,indexs6,strlens7,strrchrs5,fputcs6,hypotfs5,log2ls5,llabss5,_exits5,ffslls5,fputss8,copysigns7,llrintfs7,sprintfs16,putchar_unlockeds6,ilogbls5,atan2s10,remainderls7,isdigits5,frexps6,log1pfs6,scalbns4,fmafs8,vsprintfs4,fdims7,mempcpys5,fdimls15,printf_unlockeds4,cbrts6,stpcpys6,truncfs8,snprintfs5,lrints13,aligned_allocs5,rintls4,bcmps7,strcspns4,powfs5,sqrtfs5,fminls6,memsets7,strncats6,memcpys10,remainderfs3,pows5,fmodls5,fabsfs7,strncmps6,expm1ls4,putss7,scalbnfs9,vsnprintfs7,putchars5,exp2ls8,vfprintfs4,fmods4,atans3,nans6,hypotls7,fprintfs7,isspaces3,logs7,toasciis4,logbs7,llrintls5,logbfs6,llrints3,sins4,fabss5,hypots5,creals4,fmins7,memrchrs7,lroundfs4,atois16,fprintf_unlockeds9,remainders5,cbrtfs3,exps6,callocs9,nearbyints6,lrintfs7,imaxabss6,roundfs5,ceilfs7,tolowers5,log10s7,isasciis4,fmaxs6,strtols6,strstrs4,sqrts6,rindexs3,tans3,coss5,truncs9,copysignls6,truncls9,copysignfs8,llroundfs7,isuppers5,fmaxfs7,llrounds4,ffsls6,memcmps5,fminfs3,ffss3,abss4,cabss4,conjs5,expm1s4,fmals7,strpbrks7,strncpys14,posix_memaligns4,exits4,exp2s5,ldexps4,nanfs6,lrintls7,strndups5,aborts7,touppers5,ilogbs7,strnlens6,roundls7,reallocs6,log1pls5,fdimfs11,strncasecmps5,logbls5,cimags7,isprints4,sinhs7,vprintfs4,atols5,log2fs6,fwrites8,llroundls5,rounds8,isxdigits5,bcopys4,asins6,floorfs10,nearbyintfs7,memmoves4,tanhs5,bzeros4,log2s5,fabsls6,ilogbfs7,lroundls4,rints4,modfs10,strcasecmps6,strcats7,islowers4,acosm8,R4,TR1,i1422,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,builtin-nativesS40,s18,__builtin_isnormals17,__builtin_finitels17,__builtin_bswap16s17,__builtin_bswap32s21,__builtin_unreachables18,__builtin_paritylls14,__builtin_ffsls15,__builtin_isnans16,__builtin_isnanls13,__builtin_ctzs17,__builtin_finitefs18,__builtin_popcounts14,__builtin_traps21,__builtin_isunordereds18,__builtin_signbitfs15,__builtin_ctzlls16,__builtin_paritys17,__builtin_parityls17,__builtin_signbits13,__builtin_ffss20,__builtin_popcountlls14,__builtin_ctzls19,__builtin_popcountls15,__builtin_clzlls17,__builtin_clrsblls13,__builtin_clzs15,__builtin_clrsbs15,__builtin_isinfs14,__builtin_clzls17,__builtin_bswap64s15,__builtin_ffslls20,__builtin_isinf_signs18,__builtin_signbitls18,__builtin_isfinites16,__builtin_isinffs16,__builtin_isnanfs20,__builtin_fpclassifys16,__builtin_finites16,__builtin_clrsbls16,__builtin_isinflm8,R4,TR1,i1442,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,callee-typem10,R4,TR5,L1,V1,R38,R1,i1455,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,arg-nodem12,R4,TR5,L1,V2,R9,R52,R16,s77,An argument converted to the parameter type pt, or default-promoted (pt nil).R1,i1459,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build17,clear-padding-maxl4096,m10,R4,TR1,i1483,R2,i1,R3,s17,arbace/c/build.aeR16,s101,The most bytes of padding pattern clear-padding-call unrolls into stores (a larger array is refused).v14,arbace.c.build8,pad-maskm12,R4,TR5,L1,V1,R10,R16,s495,The type t's padding as a vector of bytes, each byte's padding bits set: none for the scalar types (long double is\n  double, CS35); a _BitInt's bits above N in its storage; for a structure the bytes no member holds and the bits of a\n  bit-field unit no named bit-field holds (an unnamed bit-field is padding); for a union the bits that are padding in\n  every named member; an array's its element's, repeated. A flexible array member is refused (gcc: \"does not have\n  well defined padding bits\").R1,i1487,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build18,clear-padding-callm12,R4,TR5,L1,V1,R53,R16,s145,__builtin_clear_padding (p): p's value kept in a slot, then a store per byte that holds padding (0, or the byte\n  with its padding bits cleared).R1,i1531,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,builtin-callm12,R4,TR5,L1,V3,Myn2,nmm2,R17,R23,R54,R38,R16,s64,A call of a builtin by name, or nil when it is an ordinary call.R1,i1547,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V2,R47,R34,R1,i1599,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build17,overflow-builtinsS24,s23,__builtin_sadd_overflows24,__builtin_uaddl_overflows25,__builtin_usubll_overflows23,__builtin_uadd_overflows23,__builtin_usub_overflows23,__builtin_umul_overflows23,__builtin_smul_overflows25,__builtin_ssubll_overflows24,__builtin_usubl_overflows25,__builtin_smulll_overflows24,__builtin_sub_overflow_ps22,__builtin_sub_overflows24,__builtin_ssubl_overflows24,__builtin_saddl_overflows24,__builtin_add_overflow_ps22,__builtin_add_overflows24,__builtin_umull_overflows24,__builtin_smull_overflows24,__builtin_mul_overflow_ps22,__builtin_mul_overflows25,__builtin_uaddll_overflows25,__builtin_umulll_overflows23,__builtin_ssub_overflows25,__builtin_saddll_overflowm8,R4,TR1,i1601,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,exact-bitsm12,R4,TR5,L1,MV1,R10,m2,R17,R18,R16,s107,The width of a signed type that holds every value of the integer type t: its width, one more when unsigned.R1,i1612,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,overflow-callm12,R4,TR5,L1,V2,Myn2,nmm2,R17,R23,R54,R16,s369,__builtin_OP_overflow(a, b, res): the exact result's wrap into *res's type, 1 when it does not fit;\n  __builtin_OP_overflow_p(a, b, c): the same against c's type, nothing stored, c evaluated for its effects\n  alone. The exact result is computed in a signed type wide enough for it (__int128 when that is, else a\n  _BitInt: queue 126, for the wide operands and results).R1,i1617,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,bitg-builtinsS22,s27,__builtin_stdc_rotate_rights28,__builtin_stdc_trailing_oness19,__builtin_popcountgs14,__builtin_ctzgs24,__builtin_stdc_bit_floors34,__builtin_stdc_first_trailing_zeros25,__builtin_stdc_count_oness32,__builtin_stdc_first_leading_ones29,__builtin_stdc_has_single_bits14,__builtin_clzgs17,__builtin_paritygs23,__builtin_stdc_bit_ceils24,__builtin_stdc_bit_widths16,__builtin_clrsbgs26,__builtin_stdc_count_zeross33,__builtin_stdc_first_leading_zeros14,__builtin_ffsgs33,__builtin_stdc_first_trailing_ones28,__builtin_stdc_leading_zeross26,__builtin_stdc_rotate_lefts27,__builtin_stdc_leading_oness29,__builtin_stdc_trailing_zerosm8,R4,TR1,i1664,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,native-callm12,R4,TR5,L1,V3,Myn2,nmm2,R17,R23,R55,R10,R16,s76,A call of the native nm with the argument nodes argns, its result of type t.R1,i1672,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,bitg-callm12,R4,TR5,L1,V3,Myn2,nmm2,R17,R23,R54,R38,R16,s109,__builtin_popcountg (x), __builtin_clzg (x [, z]), __builtin_stdc_rotate_left (x, c), ...: the native's call.R1,i1680,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,atomic-namem12,R4,TR5,L1,V1,Myn2,nmm2,R17,R23,R16,s216,The operation of a builtin's name, or nil: [op generic?], op one of :load :store :xchg :cas :tas :clear :fence,\n  [:fetch OP], [:op-fetch OP], :sync-bool, :sync-val, :release (the __sync_ spellings mapped onto them).R1,i1713,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,atomic-callm12,R4,TR5,L1,V3,Myn2,nmm2,R17,R23,R54,R38,R16,s106,A call of an __atomic_* or __sync_* builtin: its nodes, the value it returns of the checker's result type.R1,i1741,R2,i1,R3,s17,arbace/c/build.aem8,R5,L1,V4,R31,R37,R54,R38,R1,i1846,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,int-ofm10,R4,TR5,L1,V1,R32,R1,i1899,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,subobjectsm12,R4,TR5,L1,V1,R10,R16,s94,An aggregate's subobjects: [[key type offset member] ...] (an array's by index: lazily, by n).R1,i1903,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,elem-storem12,R4,TR5,L1,V4,R10,R9,R32,R24,R16,s84,The stores of a scalar or aggregate value x (a form) into the object of type t at a.R1,i1913,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,addr+m10,R4,TR5,L1,V2,R9,R56,R1,i1921,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build4,fillm8,R0,TR1,i1923,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,char-array?m10,R4,TR5,L1,V1,R10,R1,i1925,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,string-storesm10,R4,TR5,L1,V3,R10,R9,R32,R1,i1928,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,fill-listm12,R4,TR5,L1,V4,R10,R9,R57,R58,R16,s187,The stores of a braced list els into the object of type t at a: [stores rest]. braced: the list is\n  this object's own braces (designators apply here); else elided (a designator ends it).R1,i1936,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R10,R16,s70,A record type's members, an anonymous member's own members among them.R1,i2027,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V4,R10,R9,R59,R15,R16,s90,A designator path's rest `ds` into the object of type t at a, given the value v: [stores].R1,i2034,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V4,R10,R9,R57,R58,R16,s146,The stores of the initializer elements els (their first, or for an aggregate as many as it takes)\n  into the object of type t at a: [stores rest].R1,i2053,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V4,R10,R9,R60,R61,R16,s186,The effects that initialize the object of type t at the address node a from the initializer form\n  init; zero: the object zeroed first (an automatic one; static storage is zero already).R1,i2078,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,*switch*m8,R19,TR1,i2097,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,decl-head?m10,R4,TR5,L1,V1,R32,R1,i2099,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,*vla-block*m8,R19,TR1,i2101,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,*vla-stack*m8,R19,TR1,i2102,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,*vla-brk*l0,m8,R19,TR1,i2103,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,*vla-cont*m8,R19,TR1,i2104,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,vla-leavem12,R4,TR5,L1,V2,R62,R63,R16,s93,A break or continue: the stack pointer restored to the outermost VLA block it leaves (CS106).R1,i2106,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,vla-allocm10,R4,TR5,L1,V2,R14,R64,R1,i2113,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,local-declm12,R4,TR5,L1,V1,R30,R16,s46,A block's declaration: the statements it runs.R1,i2123,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,empty-asm?m12,R4,TR5,L1,V1,R31,R16,s98,An asm statement whose template is empty (a compiler barrier: __asm__(\"\" : \"+r\"(x) : : \"memory\")).R1,i2192,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,asm-body?m12,R4,TR5,L1,V1,R21,R16,s95,A function body that is inline assembly (musl's arch/x86_64 inline functions): natives of ci's.R1,i2200,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,stmtsm10,R4,TR5,L1,V1,R65,R1,i2208,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,do-nodem10,R4,TR5,L1,V1,R65,R1,i2210,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,setjmp-namesS5,s7,_setjmps16,__builtin_setjmps11,__sigsetjmps6,setjmps9,sigsetjmpm8,R4,TR1,i2212,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,has-setjmp?m12,R4,TR5,L1,V1,R31,R16,s202,Whether a statement's own expressions call setjmp (a compound statement's body is its statements', so a\n  block or a let is never the guarded statement: re-entering it would run its declarations again).R1,i2214,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,stmt*m10,R4,TR5,L1,V1,R66,R1,i2229,R2,i1,R3,s17,arbace/c/build.ae")

var Lit_503 *jrt.String = jrt.Intern("arbace.c.build$place_load")

var Lit_504 *jrt.String = jrt.Intern("arbace.c.build$place_store")

var Lit_505 *jrt.String = jrt.Intern("arbace.c.build$ptr_target_size")

var Lit_506 *jrt.String = jrt.Intern("arbace.c.build$vm_QMARK_")

var Lit_507 *jrt.String = jrt.Intern("arbace.c.build$var_size_QMARK_")

var Lit_508 *jrt.String = jrt.Intern("arbace.c.build$struct_def")

var Lit_509 *jrt.String = jrt.Intern("arbace.c.build$rec_rtt")

var Lit_510 *jrt.String = jrt.Intern("arbace.c.build$member_tfs")

var Lit_511 *jrt.String = jrt.Intern("arbace.c.build$vmem_of")

var Lit_512 *jrt.String = jrt.Intern("arbace.c.build$dyn_member")

var Lit_513 *jrt.String = jrt.Intern("arbace.c.build$dyn_copy")

var Lit_514 *jrt.String = jrt.Intern("arbace.c.build$rt_elem")

var Lit_515 *jrt.String = jrt.Intern("arbace.c.build$rt_dscale")

var Lit_516 *jrt.String = jrt.Intern("arbace.c.build$adds_dyn")

var Lit_517 *jrt.String = jrt.Intern("arbace.c.build$rtt_of")

var Lit_518 *jrt.String = jrt.Intern("arbace.c.build$with_rtt")

var Lit_519 *jrt.String = jrt.Intern("arbace.c.build$elab")

var Lit_520 *jrt.String = jrt.Intern("arbace.c.build$set_rtt_BANG_")

var Lit_521 *jrt.String = jrt.Intern("arbace.c.build$aget_place")

var Lit_522 *jrt.String = jrt.Intern("arbace.c.build$place")

var Lit_523 *jrt.String = jrt.Intern("arbace.c.build$member_place")

var Lit_524 *jrt.String = jrt.Intern("arbace.c.build$arrow_place")

var Lit_525 *jrt.String = jrt.Intern("arbace.c.build$temp_i")

var Lit_526 *jrt.String = jrt.Intern("arbace.c.build$op_sym")

var Lit_527 *jrt.String = jrt.Intern("arbace.c.build$promoted")

var Lit_528 *jrt.String = jrt.Intern("arbace.c.build$arith")

var Lit_529 *jrt.String = jrt.Intern("arbace.c.build$shift")

var Lit_530 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes")

var Lit_531 *jrt.String = jrt.Intern("arbace.c.build$binary")

var Lit_532 *jrt.String = jrt.Intern("arbace.c.build$ex_neg")

var Lit_533 *jrt.String = jrt.Intern("arbace.c.build$ex_as")

var Lit_534 *jrt.String = jrt.Intern("arbace.c.build$seq_node")

var Lit_535 *jrt.String = jrt.Intern("arbace.c.build$if_node")

var Lit_536 *jrt.String = jrt.Intern("arbace.c.build$assign")

var Lit_537 *jrt.String = jrt.Intern("arbace.c.build$incdec")

var Lit_538 *jrt.String = jrt.Intern("arbace.c.build$init_cmd")

var Lit_539 *jrt.String = jrt.Intern("arbace.c.build$add_init_BANG_")

var Lit_540 *jrt.String = jrt.Intern("arbace.c.build$frame_temp")

var Lit_541 *jrt.String = jrt.Intern("arbace.c.build$compound_lit_object")

var Lit_542 *jrt.String = jrt.Intern("arbace.c.build$compound_lit")

var Lit_543 *jrt.String = jrt.Intern("arbace.c.build$compound_lit_place")

var Lit_544 *jrt.String = jrt.Intern("arbace.c.build$string_node")

var Lit_545 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr")

var Lit_546 *jrt.String = jrt.Intern("arbace.c.build$ex")

var Lit_547 *jrt.String = jrt.Intern("arbace.c.build$callee_type")

var Lit_548 *jrt.String = jrt.Intern("arbace.c.build$arg_node")

var Lit_549 *jrt.String = jrt.Intern("arbace.c.build$pad_mask")

var Lit_550 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call")

var Lit_551 *jrt.String = jrt.Intern("arbace.c.build$builtin_call")

var Lit_552 *jrt.String = jrt.Intern("arbace.c.build$seq_node_eff")

var Lit_553 *jrt.String = jrt.Intern("arbace.c.build$exact_bits")

var Lit_554 *jrt.String = jrt.Intern("arbace.c.build$overflow_call")

var Lit_555 *jrt.String = jrt.Intern("arbace.c.build$native_call")

var Lit_556 *jrt.String = jrt.Intern("arbace.c.build$bitg_call")

var Lit_557 *jrt.String = jrt.Intern("arbace.c.build$atomic_name")

var Lit_558 *jrt.String = jrt.Intern("arbace.c.build$atomic_call")

var Lit_559 *jrt.String = jrt.Intern("arbace.c.build$call_node")

var Lit_560 *jrt.String = jrt.Intern("arbace.c.build$int_of")

var Lit_561 *jrt.String = jrt.Intern("arbace.c.build$subobjects")

var Lit_562 *jrt.String = jrt.Intern("arbace.c.build$elem_store")

var Lit_563 *jrt.String = jrt.Intern("arbace.c.build$addr_PLUS_")

var Lit_564 *jrt.String = jrt.Intern("arbace.c.build$char_array_QMARK_")

var Lit_565 *jrt.String = jrt.Intern("arbace.c.build$string_stores")

var Lit_566 *jrt.String = jrt.Intern("arbace.c.build$fill_list")

var Lit_567 *jrt.String = jrt.Intern("arbace.c.build$anon_members")

var Lit_568 *jrt.String = jrt.Intern("arbace.c.build$fill_designated")

var Lit_569 *jrt.String = jrt.Intern("arbace.c.build$fill")

var Lit_570 *jrt.String = jrt.Intern("arbace.c.build$build_init_stores")

var Lit_571 *jrt.String = jrt.Intern("arbace.c.build$decl_head_QMARK_")

var Lit_572 *jrt.String = jrt.Intern("arbace.c.build$vla_leave")

var Lit_573 *jrt.String = jrt.Intern("arbace.c.build$vla_alloc")

var Lit_574 *jrt.String = jrt.Intern("arbace.c.build$local_decl")

var Lit_575 *jrt.String = jrt.Intern("arbace.c.build$empty_asm_QMARK_")

var Lit_576 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_")

var Lit_577 *jrt.String = jrt.Intern("arbace.c.build$stmts")

var Lit_578 *jrt.String = jrt.Intern("arbace.c.build$do_node")

var Lit_579 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_")

var Lit_580 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_")

var Lit_581 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,fkn3,dockn4,linekn6,columnkn4,fileyn1,syn4,bodyyn1,eyn1,tyn2,rdyn5,formsyn1,myn1,ukn3,tagyn6,Stringyn4,inityn4,longyn9,Throwableyn4,kindyn1,ayn1,byn5,thunkyn5,fragsyn5,pruneyn5,rootsyn2,rkkn7,dynamicyn1,&kn4,keysyn10,libc-startyn16,java.lang.Stringyn5,unitsyn4,cmdsv14,arbace.c.build13,calls-setjmp?m12,R0,TR1,L1,V1,R2,R3,s75,Whether forms call setjmp anywhere (the function's body is then an SjBody).R4,i2327,R5,i1,R6,s17,arbace/c/build.aem8,R1,L1,V1,R7,R4,i2335,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build15,addressed-namesm12,R0,TR1,L1,V1,R8,R3,s87,The names whose address the body takes: (addr x), and a va_list given to a va_ builtin.R4,i2342,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,param-specm10,R0,TR1,L1,V2,R9,R10,R4,i2365,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,asm-nativesS24,s6,a_spins10,__syscall6s7,a_stores10,__syscall1s8,__get_tps4,a_ors11,a_fetch_adds10,__syscall4s7,a_cas_ps8,a_clz_64s5,a_cass6,a_swaps9,a_barriers7,a_or_64s7,a_crashs10,__syscall5s5,a_incs8,a_and_64s8,a_ctz_64s10,__syscall2s10,__syscall3s10,__syscall0s5,a_ands5,a_decm8,R4,i2377,R5,i1,R6,s17,arbace/c/build.aeR3,s170,The functions whose body is inline assembly that are natives of go/arbace/ci: musl 1.2.6's arch/x86_64\n  inline functions (atomic_arch.h, syscall_arch.h, pthread_arch.h).v14,arbace.c.build8,build-fnm10,R1,L1,V1,R2,R3,s80,A c/defn: its (code ...) command, or (native ...) for a body of inline assembly.R4,i2384,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,unit-formsm12,R0,TR1,L1,V1,R11,R3,s100,A unit's top-level forms with its header units' spliced in where their c/include stands (once each).R4,i2445,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,file-objectsm12,R0,TR1,L1,V1,R12,R3,s73,The file-scope object declarations of a unit's forms: [[form entry] ...].R4,i2461,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,decl-attrsm12,R0,TR1,L1,V1,R13,R3,s63,A declaration's weak and alias attributes: [weak alias-target].R4,i2472,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,ex-res-namem12,R0,TR1,L1,V2,R14,Myn1,nm2,R15,R16,R3,s59,The file-scope entry named n in unit u (an alias's target).R4,i2488,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build17,tentative-or-def?m10,R0,TR1,L1,V2,R2,R9,R4,i2493,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,flex-extram12,R0,TR1,L1,MV2,R10,R17,m2,R15,R18,R3,s151,The bytes a static struct's initialized flexible array member adds (GNU: struct W w = {{...}, {1, 2, 3}};\n  the object is as large as its initializer).R4,i2496,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build16,fragment-versionl1,m8,R4,i2526,R5,i1,R6,s17,arbace/c/build.aeR3,s81,The fragments' format: in the prebuilt runtime's key (arbace.c.musl/runtime-key).v14,arbace.c.build5,ex-ofm12,R0,TR1,L1,V1,Myn1,xm2,R15,R19,R3,s111,An exception as a fragment records it: [:refused CLASS MESSAGE] for a builder's refusal, else [:error MESSAGE].R4,i2530,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,throw-exm10,R0,TR1,L1,V1,V3,R20,R21,R22,R4,i2537,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,frag-itemm12,R0,TR1,L1,V1,R23,R3,s107,An item built by (thunk), its command: {:ev [reference ...] :text TEXT}, or {:ex EX} when the build throws.R4,i2542,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,unit-fragmentm10,R1,L1,V1,R14,R3,s301,A checked unit {:rd :results :std :unsigned-char} built alone: {:fns [[KEY NAME] ...] :sts [SPEC ...] :objs [CANDIDATE ...]\n  :fcands [CANDIDATE ...]}, plain data (printed and read back by arbace.c.musl's cache). A key of internal linkage is\n  [:self NAME] until link-text puts the unit's index in it.R4,i2553,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,reachedm12,R0,TR1,L1,V4,R24,R25,R26,R27,R3,s387,The keys a program reaches (a linker's --gc-sections at link-text's level): from the names `roots` and every candidate of\n  the fragments not in `prune` (a set of indices), each included candidate's references (its item's, an alias's target),\n  a pruned fragment's candidate included when its key is reached. A HashSet of keys (an object's key as a function's: a\n  name, or [unit name]).R4,i2609,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,*link-trace*m8,R28,TR4,i2646,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,link-textm10,R1,L1,MV3,R24,R29,m2,R30,V3,R31,R25,R26,m2,R15,R32,R3,s426,The node program's text (program-text's) of fragments (unit-fragment's, in link order), linked as build-program links\n  units: with (entry main) or, when `libc-start`, (start ...). Throws build-program's refusals. `prune` (a set of the\n  fragments' indices) with `roots` (names): those fragments' candidates kept only when the program reaches them (reached;\n  arbace.cpp.run's lowered C++ runtime, as its prune cut the forms).R4,i2648,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,read-programm10,R1,L1,V1,Myn4,textm2,R15,R16,R3,s70,A node program's commands from its text (program-text's, link-text's).R4,i2764,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,build-programm10,R1,L1,V3,R33,R29,m2,R30,V1,R31,R3,s334,The node program of checked units [{:rd :results :std :unsigned-char}] (a program's, in link order):\n  the commands, with (entry main) or, when `libc-start` names __libc_start_main, (start ...). Throws\n  ex-info with :ci/refused CLASS for a construct out of eval (SPEC §14) or not built yet. The units' fragments\n  linked (link-text).R4,i2769,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build20,build-program-directm10,R1,L1,V3,R33,R29,m2,R30,V1,R31,R3,s291,The node program of checked units [{:rd :results :std :unsigned-char}] (a program's, in link order):\n  the commands, with (entry main) or, when `libc-start` names __libc_start_main, (start ...). Throws\n  ex-info with :ci/refused CLASS for a construct out of eval (SPEC §14) or not built yet.R4,i2777,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,program-textm10,R1,L1,MV1,R34,m2,R15,R32,R3,s73,A node program as text, a command a line (go/arbace/ci's Parse reads it).R4,i2861,R5,i1,R6,s17,arbace/c/build.ae")

var Lit_582 *jrt.String = jrt.Intern("arbace.c.build$calls_setjmp_QMARK_")

var Lit_583 *jrt.String = jrt.Intern("arbace.c.build$build_stmt")

var Lit_584 *jrt.String = jrt.Intern("arbace.c.build$addressed_names")

var Lit_585 *jrt.String = jrt.Intern("arbace.c.build$param_spec")

var Lit_586 *jrt.String = jrt.Intern("arbace.c.build$build_fn")

var Lit_587 *jrt.String = jrt.Intern("arbace.c.build$unit_forms")

var Lit_588 *jrt.String = jrt.Intern("arbace.c.build$file_objects")

var Lit_589 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs")

var Lit_590 *jrt.String = jrt.Intern("arbace.c.build$ex_res_name")

var Lit_591 *jrt.String = jrt.Intern("arbace.c.build$tentative_or_def_QMARK_")

var Lit_592 *jrt.String = jrt.Intern("arbace.c.build$flex_extra")

var Lit_593 *jrt.String = jrt.Intern("arbace.c.build$ex_of")

var Lit_594 *jrt.String = jrt.Intern("arbace.c.build$throw_ex")

var Lit_595 *jrt.String = jrt.Intern("arbace.c.build$frag_item")

var Lit_596 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment")

var Lit_597 *jrt.String = jrt.Intern("arbace.c.build$reached")

var Lit_598 *jrt.String = jrt.Intern("arbace.c.build$link_text")

var Lit_599 *jrt.String = jrt.Intern("arbace.c.build$read_program")

var Lit_600 *jrt.String = jrt.Intern("arbace.c.build$build_program")

var Lit_601 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct")

var Lit_602 *jrt.String = jrt.Intern("arbace.c.build$program_text")
