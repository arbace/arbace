//line j2g_strings.ae:1
package aot_arbace_c_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.c.checkkn2,asyn3,chkyn13,arbace.stringyn3,strkn3,docys11,arbace.core7,bindingys14,arbace.c.check4,*cx*ys11,arbace.core5,mergekn12,ldouble-sizeys14,arbace.c.build5,*cfg*ks2,ci7,refusedkn4,enumkn1,kkn10,incompletekn6,int128kn7,uint128kn6,bitintkn1,nkn8,float128kn9,by-designkn7,complexkn7,float32kn8,float32xkn7,float64kn6,doublekn7,ldoublekn5,floatkn1,mkn4,voidkn1,vkn1,fkn1,wkn1,ikn2,ofkn5,arraykn9,float128xkn4,bf16kn6,dec128kn6,dec64xkn6,vectorkn5,dec32kn7,float16kn5,unionkn5,dec64kn2,fnkn6,structkn8,float64xkn5,scharkn4,charkn13,unsigned-charkn4,boolkn7,nullptrkn6,ullongkn4,longkn3,intkn5,shortkn5,llongkn1,ukn4,elsekn5,ucharkn6,ushortkn3,ptrkn5,ulongkn4,uintkn4,fragkn5,fkeyskn3,fnskn5,skeyskn3,stskn7,entrieskn7,ev-listkn4,seenkn3,outkn8,fn-nameskn7,staticskn7,nstatickn7,stringskn5,initskn4,defskn7,aliaseskn9,undefinedkn7,nativesyn2,fnkn1,syn6,statickn3,stryn4,datayn10,code-unitsyn11,byte-stringkn7,literalyn3,lityn4,charyn13,unsigned-charyn5,shortyn11,signed-charyn14,unsigned-shortkn7,resultskn1,tkn7,checkeryn1,fyn1,wyn1,ikn8,constantkn1,cyn3,seqyn2,oryn5,ftestyn5,wtestkn10,conversionyn2,efyn2,eiyn2,ewyn2,cvyn3,i2fyn3,r32yn3,w2fkn7,memberskn3,recyn3,f2iyn4,zeroyn2,styn3,w2iyn3,fstyn3,i2wyn3,f2wyn3,w2wyn2,ilyn2,isyn3,fldyn4,addskn4,linekn6,columnyn4,fbinyn1,*yn1,+yn1,-yn1,/yn2,fsyn2,flkn2,nfkn2,nikn5,framekn6,labelskn6,localskn2,idkn9,addressedks1,c14,declared-alignkn8,align-upyn2,fpkn3,offyn3,binkn6,statickn3,lockn3,idxkn5,localkn5,constkn3,vlakn4,slotkn4,sizekn4,namekn3,memkn6,slot-fkn6,slot-ikn7,linkagekn3,objkn1,oyn2,atkn4,modekn1,akn4,bitskn6,bitoffkn4,unityn4,wbldyn3,bldyn2,ldyn3,wldyn4,wbstyn3,bstyn4,copyyn3,wstkn2,tokn5,vsizeys1,c2,idkn5,entrykn3,rttyn8,pre-dec!yn4,addryn4,set!yn4,dec!yn8,pre-inc!yn4,agetys11,arbace.core5,derefyn4,convkn4,rttsyn1,?yn4,inc!yn5,commayn1,xyn18,typeof-unqual-typeyn8,__seg_fsyn8,__seg_gsyn13,typeof-unqualyn6,atomicyn6,typeofyn8,volatileyn8,restrictyn11,typeof-typeyn5,arrayyn5,constyn8,_Nonnullkn4,kindkn1,ekn11,param-nameskn1,xyn2,->kn6,memberyn12,compound-lityn4,realyn4,imagys1,c4,exprkn5,formsyn1,gkn7,fn-nameyn6,bit-oryn1,%yn2,==yn1,<yn1,>yn7,bit-andyn2,<<yn2,<=yn2,>>yn2,>=yn2,!=yn7,bit-xorkn8,bitfieldyn4,wbinyn3,wshyn3,cmpyn3,andyn4,fcmpyn4,lnotyn4,wcmpyn5,pdiffyn3,negyn4,wnegyn4,fseqyn4,wseqyn3,fifyn2,ifyn3,wifyn4,initkn4,tempkn6,storeskn4,clityn3,letyn2,doyn2,sxys1,c10,stmt-valueyn3,fsxkn9,constexprkn7,builtinys1,c4,callyn4,asetyn6,va-argkn7,builderyn4,fnegyn2,fayn5,vaargyn9,imaginaryyn5,elvisyn5,floatyn8,offsetofyn11,sizeof-typekn2,ttyn6,sizeofyn7,alignofyn13,classify-typeyn3,notys1,c6,effectyn8,bit-castyn7,generickn6,chosenyn13,convertvectoryn14,has-attribute?yn10,label-addryn7,labaddryn7,bit-notyn17,types-compatible?yn4,bnotyn4,wnotyn12,alignof-typeyn9,stmt-expryn2,afyn2,aiyn2,amyn2,awyn7,vastartyn3,nopyn6,allocayn5,fnrefyn4,callyn5,wcallkn3,retkn6,paramskn5,protoyn5,fcallyn5,ecallkn4,anonys1,c5,embedkn5,embedys1,c12,local-labelsys1,c3,varys1,c13,static-assertys1,c6,structys1,c5,unionys1,c4,enumys1,c7,declareys1,c7,typedefys1,c5,groupys1,c4,defnys1,c9,attr-declys1,c13,declare-specsyn10,vlarestoreyn7,vlallockn3,tagyn4,loopkn4,autoks1,c9,auto-typeys1,c3,asmyn5,whileyn6,switchyn4,whenyn8,do-whileyn4,condyn3,foryn8,continueyn3,jmpkn5,caseskn7,defaultkn3,preyn1,_yn2,swyn5,goto*yn5,igotoys1,c6,defineys1,c6,pragmays1,c9,directiveyn6,returnyn3,retkn6,fn-retyn5,labelyn4,retfyn4,retiyn4,retmyn4,retwyn3,labyn7,defaultyn7,vlamarkys1,c7,includeyn4,gotoyn5,breakys1,c5,undefyn4,caseyn2,sjyn2,pfyn2,pmyn2,pwyn2,piks1,c2,kryn1,&yn4,voidyn6,nativeyn4,codekn8,variadicyn6,sjbodykn5,unitsks1,c5,attrsks1,c11,after-attrsks1,c10,decl-attrsks1,c9,gnu-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c14,decl-end-attrskn6,externkn7,refusedkn5,errorkn2,evkn4,textkn2,exkn4,selfkn2,rdkn5,alignkn2,rokn4,initkn3,defkn4,itemkn3,errkn4,weakkn5,aliaskn2,tekn4,objskn6,fcandskn10,libc-startkn5,prunekn5,rootsyn5,startyn5,entryyn7,fnaliasyn5,aliaskn7,no-mainv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.c.buildm2,R6,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR7,v11,arbace.core5,applyv11,arbace.core6,vectorR8,R9,v11,arbace.core8,hash-mapR10,l8,R11,v11,arbace.core7,ex-infov11,arbace.core3,strR12,v14,arbace.c.build3,unqR13,R14,v14,arbace.c.check10,enum-underv14,arbace.c.check7,size-ofv11,arbace.core19,pop-thread-bindingsv14,arbace.c.build6,refuseR15,v14,arbace.c.check4,tstrv11,arbace.core20,push-thread-bindingsv14,arbace.c.check4,*cx*v11,arbace.core5,mergem2,R10,l8,v14,arbace.c.build5,*cfg*v14,arbace.c.check8,align-ofm2,R10,l8,v14,arbace.c.build5,underS2,R16,R17,R18,R19,R20,R21,R22,S6,R23,R24,R25,R26,R27,R28,R29,R30,R31,R24,R32,v14,arbace.c.build5,wide?R33,R34,R35,R25,R36,R27,R28,R37,R38,R26,R39,R23,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R16,R17,S2,R23,R28,v14,arbace.c.build4,f32?S2,R53,R63,S6,s3,u16s1,ps3,u32s2,u8s1,bs3,u64R66,R67,R68,R69,R70,R71,v14,arbace.c.build6,*item*v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR72,R73,v14,arbace.c.build3,*p*v11,arbace.core6,symbolR74,R75,R76,R77,v11,arbace.core4,atoml0,R78,R79,R80,R81,R82,R83,v14,arbace.c.build9,item-ref!v14,arbace.c.build5,emit!R84,v14,arbace.c.build12,frag-static!l1,v11,arbace.core7,vector?v11,arbace.core4,lastv14,arbace.c.build3,sphv11,arbace.core5,swap!v11,arbace.core3,incR85,R86,v11,arbace.core6,formatv14,arbace.c.build6,hex-ofR87,R86,R88,v11,arbace.core7,string?v11,arbace.core3,vecv11,arbace.core3,mapv14,arbace.c.build4,utf8v11,arbace.core4,longv11,arbace.core8,integer?v11,arbace.core4,seq?S2,R89,R90,v11,arbace.core6,mapcatv14,arbace.c.build10,code-unitsv11,arbace.core4,restR91,v11,arbace.core6,pr-strv11,arbace.core11,map-indexedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core10,chunk-restR90,R92,S2,R89,R90,R92,v11,arbace.core6,secondR93,R94,R95,R96,R97,R98,v14,arbace.c.build3,*u*v11,arbace.core7,symbol?R99,v11,arbace.core2,<=l-2147483648,l2147483647,v14,arbace.c.check5,t-intv14,arbace.c.check6,t-longr21,18446744073709551615Nv14,arbace.c.check7,t-ulongm2,R14,R16,v14,arbace.c.check8,t-doublev11,arbace.core6,ratio?v14,arbace.c.check6,t-boolv14,arbace.c.check9,t-nullptrv14,arbace.c.check3,arrv14,arbace.c.check6,t-charv14,arbace.c.build6,ex-resv14,arbace.c.build7,lit-resR100,v14,arbace.c.build4,kindR101,v14,arbace.c.build5,fbitsR102,v14,arbace.c.build3,wtyR103,v14,arbace.c.check4,wrapv14,arbace.c.build9,int-constR104,R101,R103,R102,v11,arbace.core6,bigintv14,arbace.c.build8,complex?R105,v14,arbace.c.build6,cpartsR106,R107,R108,R108,R108,R109,v11,arbace.core5,assocv14,arbace.c.build5,cmakev14,arbace.c.build4,convR101,v11,arbace.core4,not=v14,arbace.c.build8,seq-nodev14,arbace.c.build3,ityV2,R34,R32,V2,R29,R34,V2,R32,R32,v11,arbace.core3,notV2,R29,R29,R110,R106,R107,R108,R108,R111,R112,R112,R113,R114,v14,arbace.c.build5,truthR115,R116,V2,R34,R34,S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64S3,s1,ps3,i64s3,u64V2,R33,R32,R114,V2,R32,R34,R117,V2,R34,R29,v11,arbace.core6,filterv14,arbace.c.check11,compatible?m2,R10,l8,R118,v11,arbace.core4,intoR119,v14,arbace.c.build10,frame-tempR120,V2,R33,R34,R106,R112,R121,v14,arbace.c.build7,size-ofR112,R122,V2,R32,R29,m2,R10,l8,R123,V2,R34,R33,R106,R112,R121,R111,R124,v14,arbace.c.build3,ftyV2,R32,R33,R125,V2,R33,R33,R126,R127,v14,arbace.c.build6,temp-iR128,R112,R129,R130,R130,R131,ML2,R103,l1,m4,R132,i364,R133,i57,R106,R111,R124,R111,R124,R131,ML2,R103,l1,m4,R132,i375,R133,i85,v14,arbace.c.build9,new-slot!R134,R135,R136,R137,R138,R111,R139,R111,R139,R111,R139,R111,R139,R140,R140,R140,R140,R111,R112,R112,R113,v14,arbace.c.build3,*f*R141,R142,v11,arbace.core6,updateR143,R144,v11,arbace.core8,assoc-inR145,R146,v11,arbace.core9,contains?R147,S2,R33,R29,v14,arbace.c.build8,align-ofR148,R149,R150,R151,R152,R152,R103,R103,R153,R154,R155,v14,arbace.c.build10,static-idxR156,v14,arbace.c.build9,obj-alignv14,arbace.c.check5,qualsR157,R158,R159,R160,v14,arbace.c.build10,addressed?R161,R162,v14,arbace.c.build12,frame-alloc!l16,R163,R164,R165,v11,arbace.core5,classv14,arbace.c.build5,fn-idv14,arbace.c.build10,global-keyR166,R167,v14,arbace.c.build8,obj-sizeR168,R169,R170,R171,R172,R173,R140,R174,R175,v14,arbace.c.build12,unsigned-ty?R130,R176,R112,R177,R128,R139,R178,R179,R124,R122,R180,R181,R129,R182,v14,arbace.c.check5,decayS2,R46,R30,v14,arbace.c.build3,vm?v14,arbace.c.build7,rt-elemR183,R131,R152,R184,R185,v14,arbace.c.build8,local-ofR186,v14,arbace.c.build4,ptr?v11,arbace.core4,somev14,arbace.c.build6,res-ofR187,R188,v14,arbace.c.build6,rtt-ofR189,R190,R191,R192,R193,R136,R137,R194,R195,R196,R197,R198,R199,v11,arbace.core4,nameR184,v14,arbace.c.build13,*vm-typedefs*R200,R201,R202,R203,R203,R204,v14,arbace.c.build6,effectv14,arbace.c.build2,exR135,R205,R206,R207,R208,R209,R135,R128,R210,v11,arbace.core5,some?R112,R129,R112,R129,R152,R128,R103,R211,v14,arbace.c.build9,rt-dscalev14,arbace.c.build8,adds-dynR131,R184,R212,R213,R214,v14,arbace.c.build12,mem-loc-addrS2,R215,R34,R193,v14,arbace.c.build5,ex-asR192,v14,arbace.c.build10,aget-placeR216,v14,arbace.c.build11,arrow-placev13,arbace.string12,starts-with?v14,arbace.c.build5,placeR217,v14,arbace.c.build12,member-placeR218,v14,arbace.c.build18,compound-lit-placeS2,R219,R220,v14,arbace.c.build12,string-form?R221,R196,R198,R189,R222,R223,R224,v14,arbace.c.build13,string-staticR128,R223,R223,v14,arbace.c.build14,global-obj-idxR131,ML2,R103,l1,m4,R132,i725,R133,i32,v14,arbace.c.check6,memberv11,arbace.core6,reducev14,arbace.c.check4,qualv14,arbace.c.build10,place-loadm2,R10,l8,R225,R226,R227,R135,R136,R137,R138,R228,R229,R230,R231,R232,R233,R234,R235,R236,v14,arbace.c.check7,promoteS4,R55,R54,R64,R58,S2,R54,R64,R237,S2,R16,R17,m2,R10,l8,v14,arbace.c.build6,carithv14,arbace.c.build6,op-symS4,s3,subs3,muls3,divs3,addR134,R152,R238,R152,R239,v14,arbace.c.check5,usualv14,arbace.c.build8,promotedR240,m2,R10,l8,R241,R242,R242,R106,R243,R242,R240,R244,S6,R228,R232,R229,R234,R235,R227,v14,arbace.c.build13,compare-nodesS2,R233,R231,v14,arbace.c.build5,shiftR136,R136,R137,R137,v14,arbace.c.build6,ex-negv14,arbace.c.build5,arithm2,R10,l8,R131,v14,arbace.c.build15,ptr-target-sizeR131,R152,R245,R245,R131,R246,R247,v11,arbace.core6,empty?R248,R106,R112,R106,ML2,R103,l0,m4,R132,i860,R133,i71,R249,R250,R251,R112,R251,R106,ML2,R103,l0,m4,R132,i867,R133,i66,R106,ML2,R103,l0,m4,R132,i867,R133,i94,R252,R216,v14,arbace.c.build11,place-storeS2,R137,R136,R137,S2,R233,R231,m2,R10,l8,R140,R111,R139,R128,R112,R129,R128,R112,R129,R131,R216,S2,R197,R191,R103,R131,R103,ML2,R103,l1,m4,R132,i915,R133,i73,R136,R103,S2,R187,R191,ML2,R103,l1,m4,R132,i929,R133,i78,R136,R103,R128,R112,R129,R243,R140,R177,R128,R111,R139,R113,R181,R112,R129,R128,R243,R128,m4,R142,l0,R141,l0,R253,R199,R112,R106,ML2,R103,l0,m4,R132,i941,R133,i79,v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v14,arbace.c.build13,*static-init*R150,R223,R254,v14,arbace.c.build17,build-init-storesR253,R255,R223,R256,v14,arbace.c.build9,add-init!v14,arbace.c.build8,init-cmdv14,arbace.c.build19,compound-lit-objectR106,v14,arbace.c.build12,string-unitsR223,v14,arbace.c.build12,units->bytesv11,arbace.core4,peekR257,R257,v11,arbace.core3,popR257,v11,arbace.core4,dropl2,v14,arbace.c.build10,build-stmtR258,R112,R259,R258,ML2,R103,l0,m4,R132,i997,R133,i79,R260,R261,R140,R249,R112,R259,ML2,R103,l0,m4,R132,i1012,R133,i67,R177,R259,R128,R184,R262,v14,arbace.c.build10,const-nodev14,arbace.c.check3,ptrR263,S8,R187,R197,R264,R190,R198,R191,R189,R265,R194,S3,R33,R32,R34,S2,R107,R241,v14,arbace.c.build9,call-nodeR266,R267,R226,R136,R137,R268,R268,v14,arbace.c.build8,with-rttv14,arbace.c.build6,binaryR220,R135,v14,arbace.c.build11,string-nodev11,arbace.core7,number?v11,arbace.core5,char?ML2,R103,l0,m4,R132,i1186,R133,i42,R269,v14,arbace.c.build6,fn-refR270,R268,R136,R137,R138,R228,R229,R196,v14,arbace.c.build7,if-nodeR271,R92,ML2,R101,l0,m4,R132,i1168,R133,i61,R101,R272,R235,S1,R273,v14,arbace.c.check7,t-floatR236,R274,R275,R276,v14,arbace.c.build4,elabv11,arbace.core4,mapvR277,R184,R192,R225,R189,v14,arbace.c.build6,assignR278,R92,R271,ML2,R101,l0,m4,R132,i1148,R133,i57,R101,R279,R190,v14,arbace.c.build6,incdecR277,R90,R280,R241,R241,R114,R243,R281,v14,arbace.c.check6,t-voidR282,R197,R283,R284,R285,R188,R184,R193,R216,R218,v14,arbace.c.build12,compound-litR269,R286,R198,R264,R265,R287,R230,R288,v14,arbace.c.build11,label-code!R231,R221,R232,R194,R289,R268,R290,R291,R292,R216,R227,R293,R187,R233,R234,R219,R275,R253,R191,R107,R107,R114,R294,v14,arbace.c.build9,stmt-exprR193,R103,R103,m2,R10,l8,R295,R296,R297,R298,v11,arbace.core6,repeatv14,arbace.c.build8,pad-maskv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendl255,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core5,rangev11,arbace.core7,bit-andl255,l255,l255,l255,l255,v11,arbace.core4,pos?v14,arbace.c.build17,clear-padding-maxR131,ML2,R103,l1,m4,R132,i1305,R133,i46,R128,R112,R122,ML2,R103,l0,m4,R132,i1308,R133,i50,R112,R122,R152,R176,R103,ML2,R103,l0,m4,R132,i1308,R133,i50,R112,R106,R112,R129,ML2,R103,l0,m4,R132,i1311,R133,i90,ML2,R103,l0,m4,R132,i1337,R133,i54,v14,arbace.c.build18,clear-padding-callm2,R10,l8,R242,R242,R242,R242,R107,R242,R242,R101,R101,m2,R10,l8,v14,arbace.c.build12,seq-node-effR299,R101,R300,R103,m2,R10,l8,R103,S2,l0,l1,l-1,R101,R301,ML2,R103,l0,m4,R132,i1342,R133,i50,ML2,R150,l0,m4,R132,i1341,R133,i57,ML2,R103,l0,m4,R132,i1341,R133,i65,R112,R122,R103,l4,l18,l10,l12,l9,l5,l13,m2,R10,l8,m2,R10,l8,ML2,R103,l-1,m4,R132,i1339,R133,i55,R112,R106,ML2,R103,l0,m4,R132,i1365,R133,i86,v14,arbace.c.check8,int-bitsm2,R10,l8,v13,arbace.string9,includes?v13,arbace.string10,ends-with?v14,arbace.c.build10,exact-bitsv14,arbace.c.check9,int-type?m2,R14,R16,m2,R10,l8,R238,R177,R127,R127,R123,R125,m2,R10,l8,R106,R113,R181,R244,R113,R181,R128,R112,R122,R128,R177,R128,R176,R128,R106,R113,R181,R112,R129,R244,R302,R303,R304,m2,R10,l8,S4,s27,__builtin_stdc_rotate_rights24,__builtin_stdc_bit_floors23,__builtin_stdc_bit_ceils26,__builtin_stdc_rotate_leftv14,arbace.c.check6,t-uintS2,s14,__builtin_ctzgs14,__builtin_clzgV2,ML2,R296,ML2,R103,l0,m4,R132,i1462,R133,i66,m4,R132,i1462,R133,i62,ML2,R296,ML2,R103,l0,m4,R132,i1462,R133,i78,m4,R132,i1462,R133,i74,S2,s27,__builtin_stdc_rotate_rights26,__builtin_stdc_rotate_leftm2,R14,R17,v14,arbace.c.build11,native-callR296,R103,m2,R10,l8,R296,R298,v14,arbace.c.build8,arg-nodeML2,R296,ML2,R103,l1,m4,R132,i1462,R133,i52,m4,R132,i1462,R133,i48,R238,R102,R296,R184,v14,arbace.c.build12,builtin-callv14,arbace.c.build17,overflow-builtinsv14,arbace.c.build13,overflow-callv14,arbace.c.build13,bitg-builtinsv14,arbace.c.build9,bitg-callv11,arbace.core4,subsv14,arbace.c.build15,builtin-aliasesv14,arbace.c.build15,builtin-nativesv14,arbace.c.build11,callee-typeR305,R306,R307,R302,R302,R112,R308,R303,R303,R309,R304,v11,arbace.core6,removev11,arbace.core7,keywordR131,ML2,R103,l1,m4,R132,i1535,R133,i62,S10,R55,R57,R62,R56,R65,R64,R61,R52,R50,R49,v11,arbace.core4,takeV1,l0,R112,R180,R223,v11,arbace.core8,keyword?R168,R168,v14,arbace.c.build4,fillv14,arbace.c.build5,addr+v14,arbace.c.build10,subobjectsR168,R310,v14,arbace.c.build12,anon-membersv11,arbace.core12,keep-indexedv14,arbace.c.build9,fill-listR253,v14,arbace.c.build6,int-ofv14,arbace.c.build15,fill-designatedv11,arbace.core5,nnextv14,arbace.c.build10,elem-storeS2,R44,R47,R253,v14,arbace.c.build11,char-array?R253,R311,R312,S2,R44,R47,v14,arbace.c.build13,string-storesm2,R10,l8,R112,R180,R253,R253,R253,R112,R121,S12,R313,R314,R315,R316,R317,R318,R319,R320,R321,R322,R323,R324,v14,arbace.c.build11,*vla-stack*R258,R199,R112,R325,v14,arbace.c.build11,*vla-block*v11,arbace.core6,reset!R129,R199,R112,R129,R326,R199,R112,R129,R301,R321,v14,arbace.c.build10,local-declR320,R184,R314,S2,R215,R34,v14,arbace.c.build11,bind-local!R327,v14,arbace.c.build8,set-rtt!v14,arbace.c.build9,vla-allocR258,R199,R112,R129,ML2,R103,l0,m4,R132,i1754,R133,i85,R328,R240,R128,R112,R129,R152,ML2,R103,l1,m4,R132,i1756,R133,i118,R128,R258,R199,R112,R122,ML2,R103,l0,m4,R132,i1757,R133,i156,R131,R128,R128,R329,R330,R253,R322,R223,R199,R112,R106,ML2,R103,l0,m4,R132,i1769,R133,i133,R199,v11,arbace.core7,re-findp73,^\\s*(__asm__|__asm|asm)\\s*(__volatile__|volatile|__volatile)?\\s*\\(\\s*\\\"\\\"p3,\\\"=R331,v14,arbace.c.build10,empty-asm?R258,v14,arbace.c.build5,stmtsv14,arbace.c.build12,setjmp-namesS2,R257,R258,S5,R332,R333,R334,R251,R335,R336,v11,arbace.core8,take-nthR337,R336,v11,arbace.core9,partitionv14,arbace.c.build7,do-nodeR334,v11,arbace.core7,reverseR338,v14,arbace.c.build9,vla-leavev14,arbace.c.build10,*vla-cont*ML2,R339,l3,m4,R132,i1904,R133,i41,R323,ML2,R258,V0,m4,R132,i1916,R133,i87,R333,R340,R341,R102,R244,R241,R244,R244,R251,R103,ML2,R103,l0,m4,R132,i1881,R133,i99,v14,arbace.c.build10,decl-head?R337,R342,v14,arbace.c.build5,stmt*R257,R343,R343,v14,arbace.c.build8,*switch*v14,arbace.c.build9,*vla-brk*R177,R344,R106,R113,R181,R344,R345,R199,R258,R328,R260,R346,R347,ML2,R258,V0,m4,R132,i1916,R133,i87,R199,R111,R139,R113,R181,R112,R129,R348,ML2,R258,V0,m4,R132,i1916,R133,i87,R349,ML2,R258,V0,m4,R132,i1916,R133,i87,R350,ML1,R351,m4,R132,i1906,R133,i19,R352,R353,R351,R354,R351,R355,R351,R356,R258,ML1,R351,m4,R132,i1910,R133,i58,R199,R351,R357,R251,R358,R359,v14,arbace.c.build11,fresh-code!R334,R257,v11,arbace.core9,with-metaR314,R358,R335,R258,R199,R112,R360,R199,R112,R325,R258,R331,ML2,R258,V0,m4,R132,i1915,R133,i35,R328,R361,ML2,R258,V0,m4,R132,i1916,R133,i87,R258,R362,R332,R339,R281,R328,R363,ML2,R339,l2,m4,R132,i1903,R133,i37,R199,R334,R313,ML2,R258,V0,m4,R132,i1916,R133,i87,R334,R364,ML2,R258,V0,m4,R132,i1916,R133,i87,R365,R358,R258,R199,R199,v14,arbace.c.build13,calls-setjmp?v14,arbace.c.build11,has-setjmp?R366,v11,arbace.core3,setR188,R188,R188,R184,R266,p21,^__builtin_(c23_)?va_R192,R367,R368,R368,R369,R368,R370,R371,v14,arbace.c.build9,asm-body?v14,arbace.c.build11,asm-nativesv14,arbace.c.build10,param-specS2,R372,R373,S3,s1,ps3,i64s3,u64R199,R112,R129,R114,R128,S3,s1,ps3,i64s3,u64m2,R14,R30,S2,R372,R373,ML2,R351,ML2,R355,ML2,R103,l0,m4,R132,i2032,R133,i60,m4,R132,i2032,R133,i54,m4,R132,i2032,R133,i49,R374,v14,arbace.c.build15,addressed-namesR375,R376,R370,R258,R377,v11,arbace.core7,ex-dataR378,R361,v11,arbace.core10,drop-whileR321,v11,arbace.core4,keepR314,R314,v13,arbace.string7,replacep7,^__|__$S2,s5,aliass9,__alias__V7,R379,R380,R381,R382,R383,R384,R385,S2,R215,R34,R386,R253,v11,arbace.core8,not-any?R168,v14,arbace.c.check10,init-countR253,R253,m2,R10,l8,R387,R388,R389,R390,R391,v14,arbace.c.build5,ex-ofR392,v14,arbace.c.build10,unit-formsR393,S3,R314,R319,R322,S3,R314,R319,R322,R321,S2,R215,R34,v14,arbace.c.build10,decl-attrsv14,arbace.c.build17,tentative-or-def?v14,arbace.c.build10,flex-extraR394,R395,R396,R397,R398,v14,arbace.c.build9,frag-itemR223,S2,R215,R34,v14,arbace.c.build12,file-objectsR322,v14,arbace.c.build11,ex-res-namev11,arbace.core6,zipmapV3,R160,R394,R399,R400,R401,R402,v14,arbace.c.build8,build-fnV3,R160,R394,R399,R403,R404,v14,arbace.c.build8,new-fragv11,arbace.core4,map?R322,S2,R167,R32,S2,R167,R32,R405,R406,R407,p13,\\?([fs])(\\d+)R168,v14,arbace.c.build8,throw-exR86,R88,R86,v14,arbace.c.build7,reachedv14,arbace.c.build8,new-progR408,R409,R399,R410,R411,R412,v13,arbace.string6,blank?v11,arbace.core11,read-stringv13,arbace.string11,split-linesv14,arbace.c.build12,read-programv14,arbace.c.build9,link-textv14,arbace.c.build13,unit-fragmentR408,R409,R321,S3,R314,R319,R322,S3,R314,R319,R322,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S2,R215,R34,S2,R215,R34,S2,R215,R34,S2,R215,R34,R223,R321,S3,R314,R319,R322,S3,R314,R319,R322,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,S3,R314,R319,R322,R410,R411,")

var Lit_1 *jrt.String = jrt.Intern("arbace.c.build$add_init_BANG_$fn__558000296")

var Lit_2 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk__558000893")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.build$addressed_names$walk_base__558000906")

var Lit_4 *jrt.String = jrt.Intern(".-")

var Lit_5 *jrt.String = jrt.Intern("mul")

var Lit_6 *jrt.String = jrt.Intern("i64")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.build$align_of$fn__558000024")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.build$anon_members$fn__558000763")

var Lit_9 *jrt.String = jrt.Intern("")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.build$arg_node$fn__558000450")

var Lit_11 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_12 *jrt.String = jrt.Intern("the operator ")

var Lit_13 *jrt.String = jrt.Intern(" on floating operands")

var Lit_14 *jrt.String = jrt.Intern("arbace.c.build$arrow_place$fn__558000235")

var Lit_15 *jrt.String = jrt.Intern("no member ")

var Lit_16 *jrt.String = jrt.Intern(" in ")

var Lit_17 *jrt.String = jrt.Intern(" of ")

var Lit_18 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_$walk__558000814")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.build$assign$fn__558000278")

var Lit_20 *jrt.String = jrt.Intern("div")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.build$binary$fn__558000258")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.build$bitg_call$fn__558000593")

var Lit_23 *jrt.String = jrt.Intern(" of an operand of type ")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.build$bitg_call$fn__558000595")

var Lit_25 *jrt.String = jrt.Intern("__builtin_stdc_has_single_bit")

var Lit_26 *jrt.String = jrt.Intern("__builtin_stdc_")

var Lit_27 *jrt.String = jrt.Intern("rem")

var Lit_28 *jrt.String = jrt.Intern(" of a bit-field")

var Lit_29 *jrt.String = jrt.Intern("no entry for the function ")

var Lit_30 *jrt.String = jrt.Intern(": inline assembly (SPEC §14)")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.build$build_fn$fn__558000915")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000917__558000921")

var Lit_33 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000927__558000931")

var Lit_34 *jrt.String = jrt.Intern("arbace.c.build$build_fn$fn__558000937")

var Lit_35 *jrt.String = jrt.Intern("main")

var Lit_36 *jrt.String = jrt.Intern(": ")

var Lit_37 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000917__558000921$fn__558000922")

var Lit_38 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000917__558000921$fn__558000922$fn__558000923")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000927__558000931$fn__558000932")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.build$build_fn$iter__558000927__558000931$fn__558000932$fn__558000933")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001331")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001361")

var Lit_43 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001363")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001365")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001367")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001369")

var Lit_47 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001371")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001373")

var Lit_49 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001375")

var Lit_50 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001381")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001393")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001414")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001421")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001432")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001441")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001473")

var Lit_57 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001478")

var Lit_58 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001483")

var Lit_59 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001488")

var Lit_60 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001493")

var Lit_61 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001498")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001503")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001508")

var Lit_64 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001522")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001529")

var Lit_66 *jrt.String = jrt.Intern("no main")

var Lit_67 *jrt.String = jrt.Intern("__libc_start_main")

var Lit_68 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001432$fn__558001433")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct$fn__558001441$fn__558001442")

var Lit_70 *jrt.String = jrt.Intern("__builtin_constant_p")

var Lit_71 *jrt.String = jrt.Intern("__builtin_va_end")

var Lit_72 *jrt.String = jrt.Intern("__builtin_isgreaterequal")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000522")

var Lit_74 *jrt.String = jrt.Intern("__builtin_isgreater")

var Lit_75 *jrt.String = jrt.Intern("gt")

var Lit_76 *jrt.String = jrt.Intern("__builtin_islessequal")

var Lit_77 *jrt.String = jrt.Intern("le")

var Lit_78 *jrt.String = jrt.Intern("__builtin_isless")

var Lit_79 *jrt.String = jrt.Intern("lt")

var Lit_80 *jrt.String = jrt.Intern("ge")

var Lit_81 *jrt.String = jrt.Intern("__builtin_clear_padding")

var Lit_82 *jrt.String = jrt.Intern("__builtin_nanf")

var Lit_83 *jrt.String = jrt.Intern("__builtin_nanl")

var Lit_84 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_85 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000528")

var Lit_86 *jrt.String = jrt.Intern("__builtin_expect_with_probability")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000531")

var Lit_88 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_89 *jrt.String = jrt.Intern("__builtin_va_start")

var Lit_90 *jrt.String = jrt.Intern("va_start of a register place")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000533")

var Lit_92 *jrt.String = jrt.Intern("__builtin_prefetch")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000535")

var Lit_94 *jrt.String = jrt.Intern("__atomic_always_lock_free")

var Lit_95 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000540")

var Lit_96 *jrt.String = jrt.Intern("__builtin_object_size")

var Lit_97 *jrt.String = jrt.Intern("__builtin_nan")

var Lit_98 *jrt.String = jrt.Intern("__builtin_inff")

var Lit_99 *jrt.String = jrt.Intern("__builtin_infl")

var Lit_100 *jrt.String = jrt.Intern("__builtin_alloca")

var Lit_101 *jrt.String = jrt.Intern("__builtin_assume_aligned")

var Lit_102 *jrt.String = jrt.Intern("__builtin_return_address")

var Lit_103 *jrt.String = jrt.Intern("__builtin_alloca_with_align")

var Lit_104 *jrt.String = jrt.Intern("alloca")

var Lit_105 *jrt.String = jrt.Intern("__builtin_expect")

var Lit_106 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000544")

var Lit_107 *jrt.String = jrt.Intern("__builtin_huge_val")

var Lit_108 *jrt.String = jrt.Intern("__builtin_frame_address")

var Lit_109 *jrt.String = jrt.Intern("__builtin_c23_va_start")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000546")

var Lit_111 *jrt.String = jrt.Intern("__builtin_va_copy")

var Lit_112 *jrt.String = jrt.Intern("u64")

var Lit_113 *jrt.String = jrt.Intern("__builtin_classify_type")

var Lit_114 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000552")

var Lit_115 *jrt.String = jrt.Intern("__builtin_huge_valf")

var Lit_116 *jrt.String = jrt.Intern("__builtin_huge_vall")

var Lit_117 *jrt.String = jrt.Intern("__builtin_nansf")

var Lit_118 *jrt.String = jrt.Intern("__builtin_nansl")

var Lit_119 *jrt.String = jrt.Intern("__builtin_islessgreater")

var Lit_120 *jrt.String = jrt.Intern("arbace.c.build$builtin_call$fn__558000558")

var Lit_121 *jrt.String = jrt.Intern("__builtin_assoc_barrier")

var Lit_122 *jrt.String = jrt.Intern("__builtin_dynamic_object_size")

var Lit_123 *jrt.String = jrt.Intern("__builtin_")

var Lit_124 *jrt.String = jrt.Intern("arbace.c.build$call_node$fn__558000599")

var Lit_125 *jrt.String = jrt.Intern("arbace.c.build$carith$s__558000131")

var Lit_126 *jrt.String = jrt.Intern("arbace.c.build$carith$fb__558000133")

var Lit_127 *jrt.String = jrt.Intern("sub")

var Lit_128 *jrt.String = jrt.Intern("add")

var Lit_129 *jrt.String = jrt.Intern(" on complex operands")

var Lit_130 *jrt.String = jrt.Intern("__builtin_clear_padding of a type with over ")

var Lit_131 *jrt.String = jrt.Intern(" bytes of padding")

var Lit_132 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$at__558000496")

var Lit_133 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000498__558000502")

var Lit_134 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000498__558000502$fn__558000503")

var Lit_135 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call$iter__558000498__558000502$fn__558000503$fn__558000504")

var Lit_136 *jrt.String = jrt.Intern("u8")

var Lit_137 *jrt.String = jrt.Intern("and")

var Lit_138 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000064")

var Lit_139 *jrt.String = jrt.Intern("arbace.c.build$code_units$fn__558000066")

var Lit_140 *jrt.String = jrt.Intern("a string literal part ")

var Lit_141 *jrt.String = jrt.Intern("p")

var Lit_142 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes$fn__558000248")

var Lit_143 *jrt.String = jrt.Intern("eq")

var Lit_144 *jrt.String = jrt.Intern("a constant of type ")

var Lit_145 *jrt.String = jrt.Intern("b")

var Lit_146 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000111")

var Lit_147 *jrt.String = jrt.Intern("a cast to a union without a member of type ")

var Lit_148 *jrt.String = jrt.Intern("a conversion from ")

var Lit_149 *jrt.String = jrt.Intern(" to ")

var Lit_150 *jrt.String = jrt.Intern("arbace.c.build$conv$fn__558000113")

var Lit_151 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs$walk__558000978")

var Lit_152 *jrt.String = jrt.Intern("weak")

var Lit_153 *jrt.String = jrt.Intern("arbace.c.build$elab$stmt_BANG___558000202")

var Lit_154 *jrt.String = jrt.Intern("arbace.c.build$elab$tname__558000204")

var Lit_155 *jrt.String = jrt.Intern("arbace.c.build$elab$go__558000206")

var Lit_156 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_157 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_158 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_159 *jrt.String = jrt.Intern("the builtin ")

var Lit_160 *jrt.String = jrt.Intern(" as a value")

var Lit_161 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000325")

var Lit_162 *jrt.String = jrt.Intern("va_arg of a register place")

var Lit_163 *jrt.String = jrt.Intern("unary ")

var Lit_164 *jrt.String = jrt.Intern("__real__ and __imag__ (SPEC §14)")

var Lit_165 *jrt.String = jrt.Intern("GNU ?: of a non-integer")

var Lit_166 *jrt.String = jrt.Intern("sizeof of a variably modified type")

var Lit_167 *jrt.String = jrt.Intern("sizeof of a VLA")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000395")

var Lit_169 *jrt.String = jrt.Intern("__builtin_bit_cast")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000400")

var Lit_171 *jrt.String = jrt.Intern("_Generic without a chosen association")

var Lit_172 *jrt.String = jrt.Intern("GNU vector types (SPEC §14)")

var Lit_173 *jrt.String = jrt.Intern("the address of a register place ")

var Lit_174 *jrt.String = jrt.Intern("an initializer list as an expression")

var Lit_175 *jrt.String = jrt.Intern("arbace.c.build$ex$fn__558000446")

var Lit_176 *jrt.String = jrt.Intern("an expression ")

var Lit_177 *jrt.String = jrt.Intern("arbace.c.build$exact_bits$fn__558000566")

var Lit_178 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558000972")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.build$file_objects$fn__558000972$fn__558000974")

var Lit_180 *jrt.String = jrt.Intern("#embed in an initializer (CS75)")

var Lit_181 *jrt.String = jrt.Intern("arbace.c.build$fill$fn__558000783")

var Lit_182 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000771")

var Lit_183 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000773")

var Lit_184 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000780")

var Lit_185 *jrt.String = jrt.Intern("arbace.c.build$fill_designated$fn__558000773$fn__558000774")

var Lit_186 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000690")

var Lit_187 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000692")

var Lit_188 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000694")

var Lit_189 *jrt.String = jrt.Intern(" to designate")

var Lit_190 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000736")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000738")

var Lit_192 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000740")

var Lit_193 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000694$fn__558000695")

var Lit_194 *jrt.String = jrt.Intern("arbace.c.build$fill_list$fn__558000740$fn__558000741")

var Lit_195 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558000999")

var Lit_196 *jrt.String = jrt.Intern("arbace.c.build$flex_extra$fn__558001001")

var Lit_197 *jrt.String = jrt.Intern("?f")

var Lit_198 *jrt.String = jrt.Intern("arbace.c.build$frag_item$fn__558001010")

var Lit_199 *jrt.String = jrt.Intern("f32")

var Lit_200 *jrt.String = jrt.Intern("f64")

var Lit_201 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx$fn__558000161")

var Lit_202 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx$fn__558000163")

var Lit_203 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_$in_expr__558000821")

var Lit_204 *jrt.String = jrt.Intern("%02x")

var Lit_205 *jrt.String = jrt.Intern("arbace.c.build$incdec$step__558000287")

var Lit_206 *jrt.String = jrt.Intern("a designator that is not constant")

var Lit_207 *jrt.String = jrt.Intern("i8")

var Lit_208 *jrt.String = jrt.Intern("i32")

var Lit_209 *jrt.String = jrt.Intern("i16")

var Lit_210 *jrt.String = jrt.Intern("u16")

var Lit_211 *jrt.String = jrt.Intern("u32")

var Lit_212 *jrt.String = jrt.Intern("u")

var Lit_213 *jrt.String = jrt.Intern("s")

var Lit_214 *jrt.String = jrt.Intern("the type ")

var Lit_215 *jrt.String = jrt.Intern(" (SPEC §14)")

var Lit_216 *jrt.String = jrt.Intern("GNU's complex integer types (deferred)")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.build$link_text$rk__558001172")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001174")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001176")

var Lit_220 *jrt.String = jrt.Intern("arbace.c.build$link_text$subst__558001178")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.build$link_text$undefined_obj__558001186")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.build$link_text$replay__558001188")

var Lit_223 *jrt.String = jrt.Intern("arbace.c.build$link_text$keep_QMARK___558001228")

var Lit_224 *jrt.String = jrt.Intern("arbace.c.build$link_text$ob__558001282")

var Lit_225 *jrt.String = jrt.Intern("arbace.c.build$link_text$ob__558001290")

var Lit_226 *jrt.String = jrt.Intern("arbace.c.build$link_text$fn__558001306")

var Lit_227 *jrt.String = jrt.Intern("\n")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.build$link_text$subst__558001178$fn__558001180")

var Lit_229 *jrt.String = jrt.Intern("f")

var Lit_230 *jrt.String = jrt.Intern("ci link: unresolved ?")

var Lit_231 *jrt.String = jrt.Intern("ci link: ")

var Lit_232 *jrt.String = jrt.Intern("UTF-8")

var Lit_233 *jrt.String = jrt.Intern("no entry for ")

var Lit_234 *jrt.String = jrt.Intern("arbace.c.build$local_decl$fn__558000803")

var Lit_235 *jrt.String = jrt.Intern("a VLA's size")

var Lit_236 *jrt.String = jrt.Intern("GNU nested functions (SPEC §14)")

var Lit_237 *jrt.String = jrt.Intern("arbace.c.build$obj_size$fn__558000154")

var Lit_238 *jrt.String = jrt.Intern("or")

var Lit_239 *jrt.String = jrt.Intern("shl")

var Lit_240 *jrt.String = jrt.Intern("shr")

var Lit_241 *jrt.String = jrt.Intern("ne")

var Lit_242 *jrt.String = jrt.Intern("xor")

var Lit_243 *jrt.String = jrt.Intern("_overflow_p")

var Lit_244 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000575")

var Lit_245 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000577")

var Lit_246 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000579")

var Lit_247 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000581")

var Lit_248 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000583")

var Lit_249 *jrt.String = jrt.Intern("arbace.c.build$overflow_call$fn__558000585")

var Lit_250 *jrt.String = jrt.Intern(" with a result of type ")

var Lit_251 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fill__558000454")

var Lit_252 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000457__558000461")

var Lit_253 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000467")

var Lit_254 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473")

var Lit_255 *jrt.String = jrt.Intern("__builtin_clear_padding: a flexible array member does not have well defined padding bits")

var Lit_256 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000467$fn__558000468")

var Lit_257 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000467$fn__558000470")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000474__558000478")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000484__558000488")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000474__558000478$fn__558000479")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000474__558000478$fn__558000479$fn__558000480")

var Lit_262 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000484__558000488$fn__558000489")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$fn__558000473$iter__558000484__558000488$fn__558000489$fn__558000490")

var Lit_264 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000457__558000461$fn__558000462")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.build$pad_mask$iter__558000457__558000461$fn__558000462$fn__558000463")

var Lit_266 *jrt.String = jrt.Intern("a parameter's place")

var Lit_267 *jrt.String = jrt.Intern("__func__")

var Lit_268 *jrt.String = jrt.Intern("no declaration of ")

var Lit_269 *jrt.String = jrt.Intern("a local outside its function: ")

var Lit_270 *jrt.String = jrt.Intern("not a place: ")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.build$program_text$fn__558001544")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.build$promoted$fn__558000241")

var Lit_273 *jrt.String = jrt.Intern("arbace.c.build$reached$reach_BANG___558001108")

var Lit_274 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001110")

var Lit_275 *jrt.String = jrt.Intern("arbace.c.build$reached$include_BANG___558001122")

var Lit_276 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001110$iter__558001111__558001115")

var Lit_277 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001110$iter__558001111__558001115$fn__558001116")

var Lit_278 *jrt.String = jrt.Intern("arbace.c.build$reached$refs_of__558001110$iter__558001111__558001115$fn__558001116$fn__558001117")

var Lit_279 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001313__558001317")

var Lit_280 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001313__558001317$fn__558001318")

var Lit_281 *jrt.String = jrt.Intern("arbace.c.build$read_program$iter__558001313__558001317$fn__558001318$fn__558001319")

var Lit_282 *jrt.String = jrt.Intern("no result for ")

var Lit_283 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$as_ptr__558000189")

var Lit_284 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$ptr_arg__558000191")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.build$rtt_of$ptr_arg__558000191$fn__558000192")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.build$size_of$fn__558000021")

var Lit_287 *jrt.String = jrt.Intern("size of an incomplete type ")

var Lit_288 *jrt.String = jrt.Intern("?s")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.build$static_idx$fn__558000050")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000832")

var Lit_291 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000840")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$wc__558000842")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$test__558000845")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000850")

var Lit_295 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000853")

var Lit_296 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000861")

var Lit_297 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000874")

var Lit_298 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000879")

var Lit_299 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000881")

var Lit_300 *jrt.String = jrt.Intern("inline assembly (SPEC §14)")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$fn__558000883")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_$v__558000888")

var Lit_303 *jrt.String = jrt.Intern("case outside a switch")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$fn__558000314")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr$wv__558000317")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.build$stmts$fn__558000817")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.build$string_static$fn__558000057")

var Lit_308 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000606")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000608__558000612")

var Lit_310 *jrt.String = jrt.Intern("arbace.c.build$subobjects$fn__558000618")

var Lit_311 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000620__558000624")

var Lit_312 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000608__558000612$fn__558000613")

var Lit_313 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000608__558000612$fn__558000613$fn__558000614")

var Lit_314 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000620__558000624$fn__558000625")

var Lit_315 *jrt.String = jrt.Intern("arbace.c.build$subobjects$iter__558000620__558000624$fn__558000625$fn__558000626")

var Lit_316 *jrt.String = jrt.Intern("a condition of type ")

var Lit_317 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000944__558000948")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000960")

var Lit_319 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000944__558000948$fn__558000949")

var Lit_320 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$iter__558000944__558000948$fn__558000949$fn__558000950")

var Lit_321 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000960$fn__558000965")

var Lit_322 *jrt.String = jrt.Intern("arbace.c.build$unit_forms$walk__558000960$fn__558000967")

var Lit_323 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013")

var Lit_324 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001031")

var Lit_325 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037")

var Lit_326 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079")

var Lit_327 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013$iter__558001014__558001020")

var Lit_328 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013$iter__558001014__558001020$fn__558001021")

var Lit_329 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013$iter__558001014__558001020$fn__558001021$iter__558001016__558001022")

var Lit_330 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013$iter__558001014__558001020$fn__558001021$iter__558001016__558001022$fn__558001023")

var Lit_331 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$decls__558001013$iter__558001014__558001020$fn__558001021$iter__558001016__558001022$fn__558001023$fn__558001024")

var Lit_332 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042")

var Lit_333 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043")

var Lit_334 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001044")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001064")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001067")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001044$fn__558001048")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001044$fn__558001051")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001044$fn__558001051$fn__558001055")

var Lit_340 *jrt.String = jrt.Intern("no definition")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001044$fn__558001051$fn__558001057")

var Lit_342 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001067$fn__558001071")

var Lit_343 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001037$iter__558001038__558001042$fn__558001043$fn__558001067$fn__558001073")

var Lit_344 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085$fn__558001086")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085$ent__558001099")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085$fn__558001102")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085$fn__558001086$ent__558001090")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment$fn__558001079$iter__558001080__558001084$fn__558001085$fn__558001086$fn__558001093")

var Lit_351 *jrt.String = jrt.Intern("s128")

var Lit_352 *jrt.String = jrt.Intern("u128")

var Lit_353 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn12,ldouble-sizekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,&yn4,bodykn8,declaredyn3,clsyn3,msgyn1,tkn3,tagyn4,longyn6,Stringyn8,seen-keyyn2,evyn3,keyyn4,specyn1,lyn3,cmdyn4,sizeyn5,alignyn2,royn5,bytesyn16,java.lang.Stringyn1,xyn5,unitsyn1,fyn1,vkn4,keysyn1,kyn1,nyn2,reyn2,imyn3,preyn2,opyn1,ayn1,byn2,otyn2,kwyn1,eyn3,locyn4,modeyn4,bitsyn6,bitoffyn4,unitv11,arbace.core5,in-nsMyn14,arbace.c.buildm2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.m2,R0,s1091,ci's builder (doc/C23-SURVEY.md §6.1, \"As built: C5 (write-ahead)\"; doc/c/SPEC.md §7, §12, §13): a\n  program's checked C forms (arbace.c.check's results, CS95 (a)) made into a node program, the data\n  ci's back end (go/arbace/ci's Loader) makes into functions, statics and nodes, as goi's builder makes\n  goi's (doc/go/GOI-SPEC.md §4.1). The builder makes no decision the checker has not made: types,\n  constants, layout, linkage and the chosen _Generic association are the checker's; it decides only the\n  machine's: slots, the frame's memory, label codes, the conversions' nodes, the order of evaluation\n  (CS31 (a): a call's arguments right to left, in the back end).\n\n  A node program is a vector of commands (lists of symbols, longs and strings): (fn ID NAME), (native\n  ID NAME NATIVE), (static IDX SIZE ALIGN RO), (data IDX OFF HEX), (code ID NI NF FRAME VARIADIC RETF32\n  PARAMS BODY), (init STMT), (start LIBC MAIN) or (entry MAIN). Floating constants are their bits as a\n  long. `program-text` prints one for tools/cirun; arbace.c.repl hands the same data to\n  arbace.lang.CInterp.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.c.build5,*cfg*m2,R2,l8,m8,R3,TR4,i24,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,with-typesm10,R7,TR8,L1,V2,R9,R10,R4,i26,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,cpartsm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,cmakem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,complex?m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,seq-nodem8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,temp-im8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,frame-tempm8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,new-slot!m8,R11,TR4,i29,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,refusem10,R7,TR8,L1,V3,R12,R9,R13,R4,i31,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,unqv14,arbace.c.check3,unqm6,R4,i37,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,underm12,R7,TR8,L1,V1,R14,R0,s81,A type with its enumeration replaced by its compatible integer type, unqualified.R4,i39,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,size-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i44,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,align-ofm8,R8,L1,MV1,R14,m2,R15,R16,R4,i48,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,wide?m10,R7,TR8,L1,V1,R14,R4,i50,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,kindm10,R8,L1,V1,R14,R0,s139,A type's node kind: :i (integers of at most 64 bits, pointers, bool), :f, :w (wider integers), :m (an\n  aggregate: its address), :v (void).R4,i54,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,itym10,R8,L1,V1,R14,R0,s109,An integer type's machine name: i8 u8 i16 u16 i32 u32 i64 u64 b p, sN/uN for a _BitInt(N) of at most 64 bits.R4,i70,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,wtym8,R8,L1,V1,R14,R4,i88,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,f32?m10,R7,TR8,L1,V1,R14,R4,i94,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,ftym10,R7,TR8,L1,V1,R14,R4,i95,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,ptr?m10,R7,TR8,L1,V1,R14,R4,i97,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,unsigned-ty?m10,R7,TR8,L1,V1,Myn1,sm2,R15,R17,R4,i98,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*p*m8,R3,TR4,i103,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,*item*m8,R3,TR4,i104,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,new-fragm10,R7,TR8,L1,V0,R4,i111,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,item-ref!m12,R7,TR8,L1,V2,R18,R19,R0,s60,The current item's reference ev (once: its first), recorded.R4,i119,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,frag-static!m12,R7,TR8,L1,V2,R20,R21,R0,s74,A fragment's static L for key, its spec made by (spec) when new: [L new?].R4,i125,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,sphm10,R7,TR8,L1,V1,R22,R4,i136,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,new-progm10,R7,TR8,L1,V0,R4,i138,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*u*m8,R3,TR4,i152,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build3,*f*m8,R3,TR4,i153,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,emit!m10,R7,TR8,L1,V1,R23,R4,i155,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fn-idm10,R8,L1,V2,R20,Myn2,nmm2,R15,R17,R0,s93,The function of the key (a name, or [unit name] for a static one): its id, declared when new.R4,i157,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,static-idxm12,R7,TR8,L1,V4,R20,R24,R25,R26,R0,s60,A static object's index, allocated (SIZE ALIGN RO) when new.R4,i173,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,hex-ofm10,R7,TR8,L1,MV1,Myn1,bm2,R15,R27,m2,R15,R28,R4,i188,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build13,string-staticm12,R7,TR8,L1,V2,Myn2,bsm2,R15,R27,Myn5,esizem2,R15,R16,R0,s102,A string literal's array (its code units of `esize` bytes and the NUL) in read-only memory: its index.R4,i193,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,utf8m10,R7,TR8,L1,MV1,Myn1,sm2,R15,R17,m2,R15,R27,R4,i214,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,code-unitsm12,R7,TR8,L1,V2,R29,Myn5,esizem2,R15,R16,R0,s76,The code units of a string-ish literal part for an element of `esize` bytes.R4,i216,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,units->bytesm10,R7,TR8,L1,MV2,R30,Myn5,esizem2,R15,R16,m2,R15,R27,R4,i228,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-form?m10,R7,TR8,L1,V1,R29,R4,i234,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,string-unitsm12,R7,TR8,L1,V1,R29,R0,s30,A string form's [units esize].R4,i240,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-resm10,R7,TR8,L1,V1,R31,R4,i251,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build7,lit-resm12,R7,TR8,L1,V1,R29,R0,s58,A bare literal's type and value (the checker's rules, §8).R4,i253,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,res-ofm10,R7,TR8,L1,V1,R31,R4,i268,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,fbitsm10,R7,TR8,L1,V1,R32,R4,i270,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,int-constm12,R7,TR8,L1,V2,R32,R14,R0,s45,The node of the integer constant v at type t.R4,i272,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,const-nodem12,R7,TR8,L1,V2,R32,R14,R0,s51,A constant value v of type t as a node of t's kind.R4,i280,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,truthm12,R7,TR8,L1,V1,m2,R33,V3,R34,R35,R14,R0,s52,A node as a condition: an I node, nonzero when true.R4,i293,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i304,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build4,convm10,R8,L1,V2,R29,R14,R0,s31,The node x converted to type t.R4,i306,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R14,R4,i352,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i354,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i354,R5,i1,R6,s17,arbace/c/build.aem8,R11,TR4,i354,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V1,R29,R0,s68,A complex node's parts: [effects re im], its address evaluated once.R4,i356,R5,i1,R6,s17,arbace/c/build.aem12,R7,TR8,L1,V4,R14,R36,R37,R38,R0,s84,A complex value of type t from its parts (effects pre first): a temporary's address.R4,i366,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,carithm12,R7,TR8,L1,V4,R39,R40,R41,R42,R0,s189,A complex operator at the complex type ot (gcc -O0's formulas; its __muldc3 and __divdc3 handle\n  infinities and NaNs more carefully: SPEC §13's class complex-edge when a program shows it).R4,i378,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,effectm12,R7,TR8,L1,V1,m2,R33,V2,R34,R35,R0,s20,A node as an effect.R4,i402,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fstatem10,R7,TR8,L1,V0,R4,i410,R5,i1,R6,s17,arbace/c/build.aem10,R7,TR8,L1,V1,R34,R4,i412,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,frame-alloc!m12,R7,TR8,L1,MV2,Myn4,sizem2,R15,R16,Myn5,alignm2,R15,R16,m2,R15,R16,R0,s54,size bytes of the frame's memory, aligned: the offset.R4,i418,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,label-code!m10,R7,TR8,L1,V1,R43,R4,i426,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,fresh-code!m10,R7,TR8,L1,V0,R4,i431,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,local-ofm10,R7,TR8,L1,V1,R44,R4,i436,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,addressed?m12,R7,TR8,L1,V2,Myn1,nm2,R15,R17,R14,R0,s142,Whether the local `n` is in memory: its address is taken (by name, anywhere in the function), or its\n  type is an aggregate or a wide integer.R4,i438,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,obj-alignm12,R7,TR8,L1,MV2,R44,R14,m2,R15,R16,R0,s124,An object's alignment: its type's, raised by its alignment specifiers (the checker's :c/declared-align, 6.7.6;\n  queue 173).R4,i444,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,mem-loc-addrm12,R7,TR8,L1,V1,R45,R0,s110,A frame object's address node: its offset's, rounded up to :align-up when the frame's 16 bytes are not enough.R4,i450,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,bind-local!m12,R7,TR8,L1,V2,R44,R14,R0,s65,A local object's place (6.2.4: automatic storage), or a static's.R4,i458,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,global-keym10,R7,TR8,L1,V1,R44,R4,i480,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build8,obj-sizem12,R7,TR8,L1,V1,R44,R0,s246,An undefined object's size and alignment as global-obj-idx allocates it (the entry e's alignment specifiers too,\n  obj-align): [size align], or [nil nil message] when its alignment throws (only an error when the object is in the end\n  undefined).R4,i483,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,fn-refm10,R7,TR8,L1,V1,R44,R4,i492,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build14,global-obj-idxm12,R7,TR8,L1,V1,R44,R0,s157,A file-scope object's (or a block-scope extern's) static index: allocated by the program's linking\n  (arbace.c.build/link), else here with its declared type.R4,i495,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build2,exm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build5,ex-asm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,build-stmtm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build17,build-init-storesm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build9,call-nodem8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,member-placem8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,arrow-placem8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build6,ex-negm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,seq-node-effm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build15,fill-designatedm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build12,anon-membersm8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build18,compound-lit-placem8,R11,TR4,i515,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build10,place-loadm10,R7,TR8,L1,V1,m2,R33,V7,R46,R34,R40,R14,R47,R48,R49,R4,i517,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build11,place-storem12,R7,TR8,L1,V2,m2,R33,V7,R46,R34,R40,R14,R47,R48,R49,R32,R0,s97,A store of the node v (of the place's type) into the place: the node, its value the value stored.R4,i533,R5,i1,R6,s17,arbace/c/build.aev14,arbace.c.build15,ptr-target-sizem12,R7,TR8,L1,MV1,R14,m2,R15,R16,R0,s76,The size of what a pointer type points to (1 for void and functions, GNU's).R4,i549,R5,i1,R6,s17,arbace/c/build.ae")

var Lit_354 *jrt.String = jrt.Intern("arbace.c.build$eval558000004$loading__1927001464__auto____558000005")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.build$eval558000008$fn__558000009")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.build$with_types")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.build$refuse")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.build$under")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.build$size_of")

var Lit_360 *jrt.String = jrt.Intern("arbace.c.build$align_of")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.build$wide_QMARK_")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.build$kind")

var Lit_363 *jrt.String = jrt.Intern("arbace.c.build$ity")

var Lit_364 *jrt.String = jrt.Intern("arbace.c.build$wty")

var Lit_365 *jrt.String = jrt.Intern("arbace.c.build$f32_QMARK_")

var Lit_366 *jrt.String = jrt.Intern("arbace.c.build$fty")

var Lit_367 *jrt.String = jrt.Intern("arbace.c.build$ptr_QMARK_")

var Lit_368 *jrt.String = jrt.Intern("arbace.c.build$unsigned_ty_QMARK_")

var Lit_369 *jrt.String = jrt.Intern("arbace.c.build$new_frag")

var Lit_370 *jrt.String = jrt.Intern("arbace.c.build$item_ref_BANG_")

var Lit_371 *jrt.String = jrt.Intern("arbace.c.build$frag_static_BANG_")

var Lit_372 *jrt.String = jrt.Intern("arbace.c.build$sph")

var Lit_373 *jrt.String = jrt.Intern("arbace.c.build$new_prog")

var Lit_374 *jrt.String = jrt.Intern("arbace.c.build$emit_BANG_")

var Lit_375 *jrt.String = jrt.Intern("arbace.c.build$fn_id")

var Lit_376 *jrt.String = jrt.Intern("arbace.c.build$static_idx")

var Lit_377 *jrt.String = jrt.Intern("arbace.c.build$hex_of")

var Lit_378 *jrt.String = jrt.Intern("arbace.c.build$string_static")

var Lit_379 *jrt.String = jrt.Intern("arbace.c.build$utf8")

var Lit_380 *jrt.String = jrt.Intern("arbace.c.build$code_units")

var Lit_381 *jrt.String = jrt.Intern("arbace.c.build$units__GT_bytes")

var Lit_382 *jrt.String = jrt.Intern("arbace.c.build$string_form_QMARK_")

var Lit_383 *jrt.String = jrt.Intern("arbace.c.build$string_units")

var Lit_384 *jrt.String = jrt.Intern("arbace.c.build$ex_res")

var Lit_385 *jrt.String = jrt.Intern("arbace.c.build$lit_res")

var Lit_386 *jrt.String = jrt.Intern("arbace.c.build$res_of")

var Lit_387 *jrt.String = jrt.Intern("arbace.c.build$fbits")

var Lit_388 *jrt.String = jrt.Intern("arbace.c.build$int_const")

var Lit_389 *jrt.String = jrt.Intern("arbace.c.build$const_node")

var Lit_390 *jrt.String = jrt.Intern("arbace.c.build$truth")

var Lit_391 *jrt.String = jrt.Intern("arbace.c.build$conv")

var Lit_392 *jrt.String = jrt.Intern("arbace.c.build$complex_QMARK_")

var Lit_393 *jrt.String = jrt.Intern("arbace.c.build$cparts")

var Lit_394 *jrt.String = jrt.Intern("arbace.c.build$cmake")

var Lit_395 *jrt.String = jrt.Intern("arbace.c.build$carith")

var Lit_396 *jrt.String = jrt.Intern("arbace.c.build$effect")

var Lit_397 *jrt.String = jrt.Intern("arbace.c.build$fstate")

var Lit_398 *jrt.String = jrt.Intern("arbace.c.build$new_slot_BANG_")

var Lit_399 *jrt.String = jrt.Intern("arbace.c.build$frame_alloc_BANG_")

var Lit_400 *jrt.String = jrt.Intern("arbace.c.build$label_code_BANG_")

var Lit_401 *jrt.String = jrt.Intern("arbace.c.build$fresh_code_BANG_")

var Lit_402 *jrt.String = jrt.Intern("arbace.c.build$local_of")

var Lit_403 *jrt.String = jrt.Intern("arbace.c.build$addressed_QMARK_")

var Lit_404 *jrt.String = jrt.Intern("arbace.c.build$obj_align")

var Lit_405 *jrt.String = jrt.Intern("arbace.c.build$mem_loc_addr")

var Lit_406 *jrt.String = jrt.Intern("arbace.c.build$bind_local_BANG_")

var Lit_407 *jrt.String = jrt.Intern("arbace.c.build$global_key")

var Lit_408 *jrt.String = jrt.Intern("arbace.c.build$obj_size")

var Lit_409 *jrt.String = jrt.Intern("arbace.c.build$fn_ref")

var Lit_410 *jrt.String = jrt.Intern("arbace.c.build$global_obj_idx")

var Lit_411 *jrt.String = jrt.Intern("arbace.c.build$place_load")

var Lit_412 *jrt.String = jrt.Intern("arbace.c.build$place_store")

var Lit_413 *jrt.String = jrt.Intern("arbace.c.build$ptr_target_size")

var Lit_414 *jrt.String = jrt.Intern("kn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,tkn3,docyn2,rtyn4,baseyn3,idxyn1,dyn1,fyn1,xyn2,tfyn5,paramyn1,eyn1,ayn1,iyn2,bpyn2,mmyn1,hyn1,ryn2,opyn1,byn2,otyn2,rayn2,rbyn1,yyn2,rxyn2,ryyn1,kyn2,esyn1,cyn2,fsyn6,storesyn3,cmdyn2,ptyn1,pkn3,tagyn6,Stringyn4,argsyn4,longyn5,argnsyn3,offkn8,declaredyn3,elsyn6,bracedyn2,dsyn1,vyn4,inityn4,zeroyn5,depthyn3,jmpyn5,vsizeyn3,locyn4,bodyyn5,itemsyn1,syn2,rdyn5,formsyn1,myn1,uyn9,Throwableyn4,kindyn5,thunkyn5,fragsyn5,pruneyn5,rootsyn2,rkyn1,&kn4,keysyn10,libc-startyn16,java.lang.Stringv14,arbace.c.build13,*vm-typedefs*m8,R0,TR1,i561,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build3,vm?m12,R4,TR5,L1,V1,R6,R7,s101,Whether a type is variably modified through arrays and pointers (structs holding VLAs: out of scope).R1,i563,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,rt-elemm12,R4,TR5,L1,V1,R8,R7,s41,A pointer's or array's rtt's element rtt.R1,i572,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,rt-dscalem12,R4,TR5,L1,V1,R8,R7,s112,The run-time size of the element of a pointer or array of rtt rt when it is variably modified: a node, else nil.R1,i575,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,adds-dynm12,R4,TR5,L1,V3,R9,R10,R11,R7,s52,base + idx elements of the run-time size d (a node).R1,i581,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,rtt-ofm12,R4,TR5,L1,V1,R12,R7,s82,The rtt of the form f when its type is variably modified and known here, else nil.R1,i586,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,with-rttm12,R4,TR5,L1,V2,R12,R13,R7,s55,The node x of the form f with f's rtt, when it has one.R1,i610,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build4,elabm12,R4,TR5,L1,V3,R14,R6,R15,R7,s340,The type form tf of the checker's type t elaborated: [stmts rtt], the statements evaluating its arrays' sizes\n  in order. param: tf is a parameter's declared type, t its adjusted one: the array's own size is evaluated for its\n  effects (gcc evaluates `int b[a++]` at the function's entry) and its element elaborated as the pointer's target.R1,i613,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,set-rtt!m12,R4,TR5,L1,V2,R16,R8,R7,s24,The local entry e's rtt.R1,i655,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,aget-placem12,R4,TR5,L1,V3,R17,R18,R6,R7,s44,The place a[i] of element type t (i[a] too).R1,i660,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,placem12,R4,TR5,L1,V1,R12,R7,s27,A form's place (an lvalue).R1,i671,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V3,R19,R20,R6,R7,s43,The member mm of the aggregate at place bp.R1,i722,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R12,R7,s49,(-> p a b): p->a->b, each step through a pointer.R1,i739,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V0,R1,i760,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,op-symm10,R4,TR5,L1,V1,R21,R1,i762,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,promotedm12,R4,TR5,L1,V1,R22,R7,s323,An operand's promoted type; a bit-field wider than int of a 64-bit or 128-bit type is gcc's N-bit type (its\n  arithmetic wraps at its width: pr32244-1, bitfld-3; the 128-bit types' since queue 164). A _BitInt bit-field is\n  promoted to its declared type, as chk/promote does (gcc's c-typeck.cc perform_integral_promotions).R1,i766,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,arithm12,R4,TR5,L1,V4,R23,R17,R24,R25,R7,s125,The operator op over the nodes a and b at the operation type ot (the usual arithmetic conversions'),\n  the result of type rt.R1,i781,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,shiftm10,R4,TR5,L1,V3,R23,R17,R24,R1,i795,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,compare-nodesm10,R4,TR5,L1,V5,R23,R17,R24,R26,R27,R1,i801,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,binarym10,R4,TR5,L1,V6,R21,R13,R28,R29,R30,R8,R1,i818,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V1,R28,R1,i840,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V2,R12,R31,R7,s63,A form's node converted to the node kind k (for addresses: :i).R1,i845,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V2,R32,R13,R7,s28,Effects es then the value x.R1,i851,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,if-nodem10,R4,TR5,L1,V4,R33,R17,R24,R6,R1,i862,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,assignm10,R4,TR5,L1,V1,R12,R1,i869,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,incdecm10,R4,TR5,L1,V1,R12,R1,i901,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,*static-init*m8,R0,TR1,i935,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,init-cmdm12,R4,TR5,L1,V2,R34,R35,R7,s105,A static initializer's command: (init NI NF STMT), run before the program starts in a frame of its slots.R1,i937,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,add-init!m12,R4,TR5,L1,V1,R36,R7,s106,A static initializer's command added to the program's (in a fragment, to its item's references, in order).R1,i943,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R6,R7,s63,A temporary aggregate of type t in the frame: its address node.R1,i951,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build19,compound-lit-objectm12,R4,TR5,L1,V1,R12,R7,s165,A compound literal's object: {:t :a (its address node) :stores (the initializing stores to run before it, none when\n  static: those are the program's initializers)}.R1,i958,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,compound-litm10,R4,TR5,L1,V1,R12,R1,i975,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R12,R7,s188,A compound literal as a place (`&(int){5}`, `(double){2.5} += 1`): its address after its stores (queue 173: the\n  place took the literal's value node, a load for a scalar, as its address).R1,i979,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,string-nodem10,R4,TR5,L1,V2,R12,R6,R1,i986,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,stmt-exprm10,R4,TR5,L1,V1,R12,R1,i990,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V1,R12,R7,s26,A form's node: {:k :n :t}.R1,i1015,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,builtin-aliasesS184,s5,cbrtls5,floors5,log1ps6,mallocs4,ceils5,rintfs6,strcmps3,fmas4,frees4,coshs6,expm1fs5,exp2fs6,strdups6,printfs6,strcpys14,fputs_unlockeds4,nanls5,fmaxls6,strspns6,strchrs7,isalphas4,labss6,lrounds7,isalnums7,scalbnls10,nearbyintls6,memchrs5,sqrtls5,indexs6,strlens7,strrchrs5,fputcs6,hypotfs5,log2ls5,llabss5,_exits5,ffslls5,fputss8,copysigns7,llrintfs7,sprintfs16,putchar_unlockeds6,ilogbls5,atan2s10,remainderls7,isdigits5,frexps6,log1pfs6,scalbns4,fmafs8,vsprintfs4,fdims7,mempcpys5,fdimls15,printf_unlockeds4,cbrts6,stpcpys6,truncfs8,snprintfs5,lrints13,aligned_allocs5,rintls4,bcmps7,strcspns4,powfs5,sqrtfs5,fminls6,memsets7,strncats6,memcpys10,remainderfs3,pows5,fabsfs7,strncmps6,expm1ls4,putss7,scalbnfs9,vsnprintfs7,putchars5,exp2ls8,vfprintfs4,fmods4,atans3,nans6,hypotls7,fprintfs7,isspaces3,logs7,toasciis4,logbs7,llrintls5,logbfs6,llrints3,sins4,fabss5,hypots5,creals4,fmins7,memrchrs7,lroundfs4,atois16,fprintf_unlockeds9,remainders5,cbrtfs3,exps6,callocs9,nearbyints6,lrintfs7,imaxabss6,roundfs5,ceilfs7,tolowers5,log10s7,isasciis4,fmaxs6,strtols6,strstrs4,sqrts6,rindexs3,tans3,coss5,truncs9,copysignls6,truncls9,copysignfs8,llroundfs7,isuppers5,fmaxfs7,llrounds4,ffsls6,memcmps5,fminfs3,ffss3,abss4,cabss4,conjs5,expm1s4,fmals7,strpbrks7,strncpys14,posix_memaligns4,exits4,exp2s5,ldexps4,nanfs6,lrintls7,strndups5,aborts7,touppers5,ilogbs7,strnlens6,roundls7,reallocs6,log1pls5,fdimfs11,strncasecmps5,logbls5,cimags7,isprints4,sinhs7,vprintfs4,atols5,log2fs6,fwrites8,llroundls5,rounds8,isxdigits5,bcopys4,asins6,floorfs10,nearbyintfs7,memmoves4,tanhs5,bzeros4,log2s5,fabsls6,ilogbfs7,lroundls4,rints4,modfs10,strcasecmps6,strcats7,islowers4,acosm8,R4,TR1,i1192,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,builtin-nativesS40,s18,__builtin_isnormals17,__builtin_finitels17,__builtin_bswap16s17,__builtin_bswap32s21,__builtin_unreachables18,__builtin_paritylls14,__builtin_ffsls15,__builtin_isnans16,__builtin_isnanls13,__builtin_ctzs17,__builtin_finitefs18,__builtin_popcounts14,__builtin_traps21,__builtin_isunordereds18,__builtin_signbitfs15,__builtin_ctzlls16,__builtin_paritys17,__builtin_parityls17,__builtin_signbits13,__builtin_ffss20,__builtin_popcountlls14,__builtin_ctzls19,__builtin_popcountls15,__builtin_clzlls17,__builtin_clrsblls13,__builtin_clzs15,__builtin_clrsbs15,__builtin_isinfs14,__builtin_clzls17,__builtin_bswap64s15,__builtin_ffslls20,__builtin_isinf_signs18,__builtin_signbitls18,__builtin_isfinites16,__builtin_isinffs16,__builtin_isnanfs20,__builtin_fpclassifys16,__builtin_finites16,__builtin_clrsbls16,__builtin_isinflm8,R4,TR1,i1212,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,callee-typem10,R4,TR5,L1,V1,R22,R1,i1225,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,arg-nodem12,R4,TR5,L1,V2,R17,R37,R7,s77,An argument converted to the parameter type pt, or default-promoted (pt nil).R1,i1229,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build17,clear-padding-maxl4096,m10,R4,TR1,i1249,R2,i1,R3,s17,arbace/c/build.aeR7,s101,The most bytes of padding pattern clear-padding-call unrolls into stores (a larger array is refused).v14,arbace.c.build8,pad-maskm12,R4,TR5,L1,V1,R6,R7,s495,The type t's padding as a vector of bytes, each byte's padding bits set: none for the scalar types (long double is\n  double, CS35); a _BitInt's bits above N in its storage; for a structure the bytes no member holds and the bits of a\n  bit-field unit no named bit-field holds (an unnamed bit-field is padding); for a union the bits that are padding in\n  every named member; an array's its element's, repeated. A flexible array member is refused (gcc: \"does not have\n  well defined padding bits\").R1,i1253,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build18,clear-padding-callm12,R4,TR5,L1,V1,R38,R7,s145,__builtin_clear_padding (p): p's value kept in a slot, then a store per byte that holds padding (0, or the byte\n  with its padding bits cleared).R1,i1297,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,builtin-callm12,R4,TR5,L1,V3,Myn2,nmm2,R39,R40,R41,R22,R7,s64,A call of a builtin by name, or nil when it is an ordinary call.R1,i1313,R2,i1,R3,s17,arbace/c/build.aem10,R4,TR5,L1,V2,R32,R16,R1,i1365,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build17,overflow-builtinsS24,s23,__builtin_sadd_overflows24,__builtin_uaddl_overflows25,__builtin_usubll_overflows23,__builtin_uadd_overflows23,__builtin_usub_overflows23,__builtin_umul_overflows23,__builtin_smul_overflows25,__builtin_ssubll_overflows24,__builtin_usubl_overflows25,__builtin_smulll_overflows24,__builtin_sub_overflow_ps22,__builtin_sub_overflows24,__builtin_ssubl_overflows24,__builtin_saddl_overflows24,__builtin_add_overflow_ps22,__builtin_add_overflows24,__builtin_umull_overflows24,__builtin_smull_overflows24,__builtin_mul_overflow_ps22,__builtin_mul_overflows25,__builtin_uaddll_overflows25,__builtin_umulll_overflows23,__builtin_ssub_overflows25,__builtin_saddll_overflowm8,R4,TR1,i1367,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,exact-bitsm12,R4,TR5,L1,MV1,R6,m2,R39,R42,R7,s107,The width of a signed type that holds every value of the integer type t: its width, one more when unsigned.R1,i1378,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,overflow-callm12,R4,TR5,L1,V2,Myn2,nmm2,R39,R40,R41,R7,s369,__builtin_OP_overflow(a, b, res): the exact result's wrap into *res's type, 1 when it does not fit;\n  __builtin_OP_overflow_p(a, b, c): the same against c's type, nothing stored, c evaluated for its effects\n  alone. The exact result is computed in a signed type wide enough for it (__int128 when that is, else a\n  _BitInt: queue 126, for the wide operands and results).R1,i1383,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,bitg-builtinsS22,s27,__builtin_stdc_rotate_rights28,__builtin_stdc_trailing_oness19,__builtin_popcountgs14,__builtin_ctzgs24,__builtin_stdc_bit_floors34,__builtin_stdc_first_trailing_zeros25,__builtin_stdc_count_oness32,__builtin_stdc_first_leading_ones29,__builtin_stdc_has_single_bits14,__builtin_clzgs17,__builtin_paritygs23,__builtin_stdc_bit_ceils24,__builtin_stdc_bit_widths16,__builtin_clrsbgs26,__builtin_stdc_count_zeross33,__builtin_stdc_first_leading_zeros14,__builtin_ffsgs33,__builtin_stdc_first_trailing_ones28,__builtin_stdc_leading_zeross26,__builtin_stdc_rotate_lefts27,__builtin_stdc_leading_oness29,__builtin_stdc_trailing_zerosm8,R4,TR1,i1430,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,native-callm12,R4,TR5,L1,V3,Myn2,nmm2,R39,R40,R43,R6,R7,s76,A call of the native nm with the argument nodes argns, its result of type t.R1,i1438,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,bitg-callm12,R4,TR5,L1,V3,Myn2,nmm2,R39,R40,R41,R22,R7,s109,__builtin_popcountg (x), __builtin_clzg (x [, z]), __builtin_stdc_rotate_left (x, c), ...: the native's call.R1,i1446,R2,i1,R3,s17,arbace/c/build.aem8,R5,L1,V4,R12,R21,R41,R22,R1,i1475,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build6,int-ofm10,R4,TR5,L1,V1,R13,R1,i1513,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,subobjectsm12,R4,TR5,L1,V1,R6,R7,s94,An aggregate's subobjects: [[key type offset member] ...] (an array's by index: lazily, by n).R1,i1517,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,elem-storem12,R4,TR5,L1,V4,R6,R17,R13,R20,R7,s84,The stores of a scalar or aggregate value x (a form) into the object of type t at a.R1,i1527,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,addr+m10,R4,TR5,L1,V2,R17,R44,R1,i1535,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build4,fillm8,R45,TR1,i1537,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,char-array?m10,R4,TR5,L1,V1,R6,R1,i1539,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,string-storesm10,R4,TR5,L1,V3,R6,R17,R13,R1,i1542,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,fill-listm12,R4,TR5,L1,V4,R6,R17,R46,R47,R7,s187,The stores of a braced list els into the object of type t at a: [stores rest]. braced: the list is\n  this object's own braces (designators apply here); else elided (a designator ends it).R1,i1550,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V1,R6,R7,s70,A record type's members, an anonymous member's own members among them.R1,i1630,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V4,R6,R17,R48,R49,R7,s90,A designator path's rest `ds` into the object of type t at a, given the value v: [stores].R1,i1637,R2,i1,R3,s17,arbace/c/build.aem12,R4,TR5,L1,V4,R6,R17,R46,R47,R7,s146,The stores of the initializer elements els (their first, or for an aggregate as many as it takes)\n  into the object of type t at a: [stores rest].R1,i1656,R2,i1,R3,s17,arbace/c/build.aem10,R5,L1,V4,R6,R17,R50,R51,R7,s186,The effects that initialize the object of type t at the address node a from the initializer form\n  init; zero: the object zeroed first (an automatic one; static storage is zero already).R1,i1681,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,*switch*m8,R0,TR1,i1700,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,decl-head?m10,R4,TR5,L1,V1,R13,R1,i1702,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,*vla-block*m8,R0,TR1,i1704,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,*vla-stack*m8,R0,TR1,i1705,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,*vla-brk*l0,m8,R0,TR1,i1706,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,*vla-cont*m8,R0,TR1,i1707,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,vla-leavem12,R4,TR5,L1,V2,R52,R53,R7,s93,A break or continue: the stack pointer restored to the outermost VLA block it leaves (CS106).R1,i1709,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,vla-allocm10,R4,TR5,L1,V2,R54,R55,R1,i1716,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,local-declm12,R4,TR5,L1,V1,R11,R7,s46,A block's declaration: the statements it runs.R1,i1726,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,empty-asm?m12,R4,TR5,L1,V1,R12,R7,s98,An asm statement whose template is empty (a compiler barrier: __asm__(\"\" : \"+r\"(x) : : \"memory\")).R1,i1791,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,asm-body?m12,R4,TR5,L1,V1,R56,R7,s95,A function body that is inline assembly (musl's arch/x86_64 inline functions): natives of ci's.R1,i1799,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,stmtsm10,R4,TR5,L1,V1,R57,R1,i1807,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,do-nodem10,R4,TR5,L1,V1,R57,R1,i1809,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,setjmp-namesS5,s7,_setjmps16,__builtin_setjmps11,__sigsetjmps6,setjmps9,sigsetjmpm8,R4,TR1,i1811,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,has-setjmp?m12,R4,TR5,L1,V1,R12,R7,s202,Whether a statement's own expressions call setjmp (a compound statement's body is its statements', so a\n  block or a let is never the guarded statement: re-entering it would run its declarations again).R1,i1813,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build5,stmt*m10,R4,TR5,L1,V1,R58,R1,i1828,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,calls-setjmp?m12,R4,TR5,L1,V1,R12,R7,s75,Whether forms call setjmp anywhere (the function's body is then an SjBody).R1,i1926,R2,i1,R3,s17,arbace/c/build.aem8,R5,L1,V1,R58,R1,i1934,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build15,addressed-namesm12,R4,TR5,L1,V1,R56,R7,s87,The names whose address the body takes: (addr x), and a va_list given to a va_ builtin.R1,i1941,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,param-specm10,R4,TR5,L1,V2,R16,R6,R1,i1964,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,asm-nativesS24,s6,a_spins10,__syscall6s7,a_stores10,__syscall1s8,__get_tps4,a_ors11,a_fetch_adds10,__syscall4s7,a_cas_ps8,a_clz_64s5,a_cass6,a_swaps9,a_barriers7,a_or_64s7,a_crashs10,__syscall5s5,a_incs8,a_and_64s8,a_ctz_64s10,__syscall2s10,__syscall3s10,__syscall0s5,a_ands5,a_decm8,R1,i1976,R2,i1,R3,s17,arbace/c/build.aeR7,s170,The functions whose body is inline assembly that are natives of go/arbace/ci: musl 1.2.6's arch/x86_64\n  inline functions (atomic_arch.h, syscall_arch.h, pthread_arch.h).v14,arbace.c.build8,build-fnm10,R5,L1,V1,R12,R7,s80,A c/defn: its (code ...) command, or (native ...) for a body of inline assembly.R1,i1983,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,unit-formsm12,R4,TR5,L1,V1,R59,R7,s100,A unit's top-level forms with its header units' spliced in where their c/include stands (once each).R1,i2044,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,file-objectsm12,R4,TR5,L1,V1,R60,R7,s73,The file-scope object declarations of a unit's forms: [[form entry] ...].R1,i2060,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,decl-attrsm12,R4,TR5,L1,V1,R61,R7,s63,A declaration's weak and alias attributes: [weak alias-target].R1,i2071,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build11,ex-res-namem12,R4,TR5,L1,V2,R62,Myn1,nm2,R39,R40,R7,s59,The file-scope entry named n in unit u (an alias's target).R1,i2087,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build17,tentative-or-def?m10,R4,TR5,L1,V2,R12,R16,R1,i2092,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build10,flex-extram12,R4,TR5,L1,MV2,R6,R50,m2,R39,R42,R7,s151,The bytes a static struct's initialized flexible array member adds (GNU: struct W w = {{...}, {1, 2, 3}};\n  the object is as large as its initializer).R1,i2095,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build16,fragment-versionl1,m8,R1,i2125,R2,i1,R3,s17,arbace/c/build.aeR7,s81,The fragments' format: in the prebuilt runtime's key (arbace.c.musl/runtime-key).v14,arbace.c.build5,ex-ofm12,R4,TR5,L1,V1,Myn1,xm2,R39,R63,R7,s111,An exception as a fragment records it: [:refused CLASS MESSAGE] for a builder's refusal, else [:error MESSAGE].R1,i2129,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build8,throw-exm10,R4,TR5,L1,V1,V3,R64,R17,R24,R1,i2136,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,frag-itemm12,R4,TR5,L1,V1,R65,R7,s107,An item built by (thunk), its command: {:ev [reference ...] :text TEXT}, or {:ex EX} when the build throws.R1,i2141,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build13,unit-fragmentm10,R5,L1,V1,R62,R7,s301,A checked unit {:rd :results :std :unsigned-char} built alone: {:fns [[KEY NAME] ...] :sts [SPEC ...] :objs [CANDIDATE ...]\n  :fcands [CANDIDATE ...]}, plain data (printed and read back by arbace.c.musl's cache). A key of internal linkage is\n  [:self NAME] until link-text puts the unit's index in it.R1,i2152,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build7,reachedm12,R4,TR5,L1,V4,R66,R67,R68,R69,R7,s387,The keys a program reaches (a linker's --gc-sections at link-text's level): from the names `roots` and every candidate of\n  the fragments not in `prune` (a set of indices), each included candidate's references (its item's, an alias's target),\n  a pruned fragment's candidate included when its key is reached. A HashSet of keys (an object's key as a function's: a\n  name, or [unit name]).R1,i2207,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build9,link-textm10,R5,L1,MV3,R66,R70,m2,R71,V3,R72,R67,R68,m2,R39,R73,R7,s426,The node program's text (program-text's) of fragments (unit-fragment's, in link order), linked as build-program links\n  units: with (entry main) or, when `libc-start`, (start ...). Throws build-program's refusals. `prune` (a set of the\n  fragments' indices) with `roots` (names): those fragments' candidates kept only when the program reaches them (reached;\n  arbace.cpp.run's lowered C++ runtime, as its prune cut the forms).R1,i2239,R2,i1,R3,s17,arbace/c/build.aev14,arbace.c.build12,read-programm10,R5,L1,V1,Myn4,textm2,R39,R40,R7,s70,A node program's commands from its text (program-text's, link-text's).R1,i2343,R2,i1,R3,s17,arbace/c/build.ae")

var Lit_415 *jrt.String = jrt.Intern("arbace.c.build$vm_QMARK_")

var Lit_416 *jrt.String = jrt.Intern("arbace.c.build$rt_elem")

var Lit_417 *jrt.String = jrt.Intern("arbace.c.build$rt_dscale")

var Lit_418 *jrt.String = jrt.Intern("arbace.c.build$adds_dyn")

var Lit_419 *jrt.String = jrt.Intern("arbace.c.build$rtt_of")

var Lit_420 *jrt.String = jrt.Intern("arbace.c.build$with_rtt")

var Lit_421 *jrt.String = jrt.Intern("arbace.c.build$elab")

var Lit_422 *jrt.String = jrt.Intern("arbace.c.build$set_rtt_BANG_")

var Lit_423 *jrt.String = jrt.Intern("arbace.c.build$aget_place")

var Lit_424 *jrt.String = jrt.Intern("arbace.c.build$place")

var Lit_425 *jrt.String = jrt.Intern("arbace.c.build$member_place")

var Lit_426 *jrt.String = jrt.Intern("arbace.c.build$arrow_place")

var Lit_427 *jrt.String = jrt.Intern("arbace.c.build$temp_i")

var Lit_428 *jrt.String = jrt.Intern("arbace.c.build$op_sym")

var Lit_429 *jrt.String = jrt.Intern("arbace.c.build$promoted")

var Lit_430 *jrt.String = jrt.Intern("arbace.c.build$arith")

var Lit_431 *jrt.String = jrt.Intern("arbace.c.build$shift")

var Lit_432 *jrt.String = jrt.Intern("arbace.c.build$compare_nodes")

var Lit_433 *jrt.String = jrt.Intern("arbace.c.build$binary")

var Lit_434 *jrt.String = jrt.Intern("arbace.c.build$ex_neg")

var Lit_435 *jrt.String = jrt.Intern("arbace.c.build$ex_as")

var Lit_436 *jrt.String = jrt.Intern("arbace.c.build$seq_node")

var Lit_437 *jrt.String = jrt.Intern("arbace.c.build$if_node")

var Lit_438 *jrt.String = jrt.Intern("arbace.c.build$assign")

var Lit_439 *jrt.String = jrt.Intern("arbace.c.build$incdec")

var Lit_440 *jrt.String = jrt.Intern("arbace.c.build$init_cmd")

var Lit_441 *jrt.String = jrt.Intern("arbace.c.build$add_init_BANG_")

var Lit_442 *jrt.String = jrt.Intern("arbace.c.build$frame_temp")

var Lit_443 *jrt.String = jrt.Intern("arbace.c.build$compound_lit_object")

var Lit_444 *jrt.String = jrt.Intern("arbace.c.build$compound_lit")

var Lit_445 *jrt.String = jrt.Intern("arbace.c.build$compound_lit_place")

var Lit_446 *jrt.String = jrt.Intern("arbace.c.build$string_node")

var Lit_447 *jrt.String = jrt.Intern("arbace.c.build$stmt_expr")

var Lit_448 *jrt.String = jrt.Intern("arbace.c.build$ex")

var Lit_449 *jrt.String = jrt.Intern("arbace.c.build$callee_type")

var Lit_450 *jrt.String = jrt.Intern("arbace.c.build$arg_node")

var Lit_451 *jrt.String = jrt.Intern("arbace.c.build$pad_mask")

var Lit_452 *jrt.String = jrt.Intern("arbace.c.build$clear_padding_call")

var Lit_453 *jrt.String = jrt.Intern("arbace.c.build$builtin_call")

var Lit_454 *jrt.String = jrt.Intern("arbace.c.build$seq_node_eff")

var Lit_455 *jrt.String = jrt.Intern("arbace.c.build$exact_bits")

var Lit_456 *jrt.String = jrt.Intern("arbace.c.build$overflow_call")

var Lit_457 *jrt.String = jrt.Intern("arbace.c.build$native_call")

var Lit_458 *jrt.String = jrt.Intern("arbace.c.build$bitg_call")

var Lit_459 *jrt.String = jrt.Intern("arbace.c.build$call_node")

var Lit_460 *jrt.String = jrt.Intern("arbace.c.build$int_of")

var Lit_461 *jrt.String = jrt.Intern("arbace.c.build$subobjects")

var Lit_462 *jrt.String = jrt.Intern("arbace.c.build$elem_store")

var Lit_463 *jrt.String = jrt.Intern("arbace.c.build$addr_PLUS_")

var Lit_464 *jrt.String = jrt.Intern("arbace.c.build$char_array_QMARK_")

var Lit_465 *jrt.String = jrt.Intern("arbace.c.build$string_stores")

var Lit_466 *jrt.String = jrt.Intern("arbace.c.build$fill_list")

var Lit_467 *jrt.String = jrt.Intern("arbace.c.build$anon_members")

var Lit_468 *jrt.String = jrt.Intern("arbace.c.build$fill_designated")

var Lit_469 *jrt.String = jrt.Intern("arbace.c.build$fill")

var Lit_470 *jrt.String = jrt.Intern("arbace.c.build$build_init_stores")

var Lit_471 *jrt.String = jrt.Intern("arbace.c.build$decl_head_QMARK_")

var Lit_472 *jrt.String = jrt.Intern("arbace.c.build$vla_leave")

var Lit_473 *jrt.String = jrt.Intern("arbace.c.build$vla_alloc")

var Lit_474 *jrt.String = jrt.Intern("arbace.c.build$local_decl")

var Lit_475 *jrt.String = jrt.Intern("arbace.c.build$empty_asm_QMARK_")

var Lit_476 *jrt.String = jrt.Intern("arbace.c.build$asm_body_QMARK_")

var Lit_477 *jrt.String = jrt.Intern("arbace.c.build$stmts")

var Lit_478 *jrt.String = jrt.Intern("arbace.c.build$do_node")

var Lit_479 *jrt.String = jrt.Intern("arbace.c.build$has_setjmp_QMARK_")

var Lit_480 *jrt.String = jrt.Intern("arbace.c.build$stmt_STAR_")

var Lit_481 *jrt.String = jrt.Intern("arbace.c.build$calls_setjmp_QMARK_")

var Lit_482 *jrt.String = jrt.Intern("arbace.c.build$build_stmt")

var Lit_483 *jrt.String = jrt.Intern("arbace.c.build$addressed_names")

var Lit_484 *jrt.String = jrt.Intern("arbace.c.build$param_spec")

var Lit_485 *jrt.String = jrt.Intern("arbace.c.build$build_fn")

var Lit_486 *jrt.String = jrt.Intern("arbace.c.build$unit_forms")

var Lit_487 *jrt.String = jrt.Intern("arbace.c.build$file_objects")

var Lit_488 *jrt.String = jrt.Intern("arbace.c.build$decl_attrs")

var Lit_489 *jrt.String = jrt.Intern("arbace.c.build$ex_res_name")

var Lit_490 *jrt.String = jrt.Intern("arbace.c.build$tentative_or_def_QMARK_")

var Lit_491 *jrt.String = jrt.Intern("arbace.c.build$flex_extra")

var Lit_492 *jrt.String = jrt.Intern("arbace.c.build$ex_of")

var Lit_493 *jrt.String = jrt.Intern("arbace.c.build$throw_ex")

var Lit_494 *jrt.String = jrt.Intern("arbace.c.build$frag_item")

var Lit_495 *jrt.String = jrt.Intern("arbace.c.build$unit_fragment")

var Lit_496 *jrt.String = jrt.Intern("arbace.c.build$reached")

var Lit_497 *jrt.String = jrt.Intern("arbace.c.build$link_text")

var Lit_498 *jrt.String = jrt.Intern("arbace.c.build$read_program")

var Lit_499 *jrt.String = jrt.Intern("kn8,arglistsyn5,unitsyn1,&kn4,keysyn10,libc-startkn3,dockn4,linekn6,columnkn4,fileyn4,cmdskn3,tagyn16,java.lang.Stringv14,arbace.c.build13,build-programm10,R0,L1,V3,R1,R2,m2,R3,V1,R4,R5,s334,The node program of checked units [{:rd :results :std :unsigned-char}] (a program's, in link order):\n  the commands, with (entry main) or, when `libc-start` names __libc_start_main, (start ...). Throws\n  ex-info with :ci/refused CLASS for a construct out of eval (SPEC §14) or not built yet. The units' fragments\n  linked (link-text).R6,i2348,R7,i1,R8,s17,arbace/c/build.aev14,arbace.c.build20,build-program-directm10,R0,L1,V3,R1,R2,m2,R3,V1,R4,R5,s291,The node program of checked units [{:rd :results :std :unsigned-char}] (a program's, in link order):\n  the commands, with (entry main) or, when `libc-start` names __libc_start_main, (start ...). Throws\n  ex-info with :ci/refused CLASS for a construct out of eval (SPEC §14) or not built yet.R6,i2356,R7,i1,R8,s17,arbace/c/build.aev14,arbace.c.build12,program-textm10,R0,L1,MV1,R9,m2,R10,R11,R5,s73,A node program as text, a command a line (go/arbace/ci's Parse reads it).R6,i2439,R7,i1,R8,s17,arbace/c/build.ae")

var Lit_500 *jrt.String = jrt.Intern("arbace.c.build$build_program")

var Lit_501 *jrt.String = jrt.Intern("arbace.c.build$build_program_direct")

var Lit_502 *jrt.String = jrt.Intern("arbace.c.build$program_text")
