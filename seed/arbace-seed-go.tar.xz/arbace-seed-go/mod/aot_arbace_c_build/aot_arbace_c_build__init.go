//line aot_arbace_c_build__init.ae:1
package aot_arbace_c_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_build__init_part0_A_Unit0__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c_build__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_build__init_part0_A_const_1) }
//line :1:1
func A_arbace_c_build__init_part0_A_Unit1__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c_build__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_2)) }
//line :1:1
func A_arbace_c_build__init_part0_A_Unit2__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_build_eval558000004_loading__1927001464__auto____558000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_build_eval558000004_loading__1927001464__auto____558000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_246, false, nil); A_arbace_c_build_eval558000004_loading__1927001464__auto____558000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c_build__init_part0_A_Unit3__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c_build__init_part0_A_const_1)).Equals_O__Z(A_arbace_c_build__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_build_eval558000008_fn__558000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_build_eval558000008_fn__558000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_247, false, nil); A_arbace_c_build_eval558000008_fn__558000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_c_build__init_part0_A_Init__O() any { A_arbace_c_build__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_c_build__init_part0_A_Load__O() any { A_arbace_c_build__init_part0_A_Init(); A_arbace_c_build__init_part0_A_Unit0__O(); A_arbace_c_build__init_part0_A_Unit1__O(); A_arbace_c_build__init_part0_A_Unit2__O(); A_arbace_c_build__init_part0_A_Unit3__O(); A_arbace_c_build__init_part0_A_Unit4__O(); A_arbace_c_build__init_part0_A_Unit5__O(); A_arbace_c_build__init_part0_A_Unit6__O(); A_arbace_c_build__init_part0_A_Unit7__O(); A_arbace_c_build__init_part0_A_Unit8__O(); A_arbace_c_build__init_part0_A_Unit9__O(); A_arbace_c_build__init_part0_A_Unit10__O(); A_arbace_c_build__init_part0_A_Unit11__O(); A_arbace_c_build__init_part0_A_Unit12__O(); A_arbace_c_build__init_part0_A_Unit13__O(); A_arbace_c_build__init_part0_A_Unit14__O(); A_arbace_c_build__init_part0_A_Unit15__O(); A_arbace_c_build__init_part0_A_Unit16__O(); A_arbace_c_build__init_part0_A_Unit17__O(); A_arbace_c_build__init_part0_A_Unit18__O(); A_arbace_c_build__init_part0_A_Unit19__O(); A_arbace_c_build__init_part0_A_Unit20__O(); A_arbace_c_build__init_part0_A_Unit21__O(); A_arbace_c_build__init_part0_A_Unit22__O(); A_arbace_c_build__init_part0_A_Unit23__O(); A_arbace_c_build__init_part0_A_Unit24__O(); A_arbace_c_build__init_part0_A_Unit25__O(); A_arbace_c_build__init_part0_A_Unit26__O(); A_arbace_c_build__init_part0_A_Unit27__O(); A_arbace_c_build__init_part0_A_Unit28__O(); A_arbace_c_build__init_part0_A_Unit29__O(); A_arbace_c_build__init_part0_A_Unit30__O(); A_arbace_c_build__init_part0_A_Unit31__O(); A_arbace_c_build__init_part0_A_Unit32__O(); A_arbace_c_build__init_part0_A_Unit33__O(); A_arbace_c_build__init_part0_A_Unit34__O(); A_arbace_c_build__init_part0_A_Unit35__O(); A_arbace_c_build__init_part0_A_Unit36__O(); A_arbace_c_build__init_part0_A_Unit37__O(); A_arbace_c_build__init_part0_A_Unit38__O(); A_arbace_c_build__init_part0_A_Unit39__O(); A_arbace_c_build__init_part0_A_Unit40__O(); A_arbace_c_build__init_part0_A_Unit41__O(); A_arbace_c_build__init_part0_A_Unit42__O(); A_arbace_c_build__init_part0_A_Unit43__O(); A_arbace_c_build__init_part0_A_Unit44__O(); A_arbace_c_build__init_part0_A_Unit45__O(); A_arbace_c_build__init_part0_A_Unit46__O(); A_arbace_c_build__init_part0_A_Unit47__O(); A_arbace_c_build__init_part0_A_Unit48__O(); A_arbace_c_build__init_part0_A_Unit49__O(); A_arbace_c_build__init_part0_A_Unit50__O(); A_arbace_c_build__init_part0_A_Unit51__O(); A_arbace_c_build__init_part0_A_Unit52__O(); A_arbace_c_build__init_part0_A_Unit53__O(); A_arbace_c_build__init_part0_A_Unit54__O(); A_arbace_c_build__init_part0_A_Unit55__O(); A_arbace_c_build__init_part0_A_Unit56__O(); A_arbace_c_build__init_part0_A_Unit57__O(); A_arbace_c_build__init_part0_A_Unit58__O(); A_arbace_c_build__init_part0_A_Unit59__O(); A_arbace_c_build__init_part0_A_Unit60__O(); A_arbace_c_build__init_part0_A_Unit61__O(); A_arbace_c_build__init_part0_A_Unit62__O(); A_arbace_c_build__init_part0_A_Unit63__O(); A_arbace_c_build__init_part0_A_Unit64__O(); A_arbace_c_build__init_part0_A_Unit65__O(); A_arbace_c_build__init_part0_A_Unit66__O(); A_arbace_c_build__init_part0_A_Unit67__O(); A_arbace_c_build__init_part0_A_Unit68__O(); A_arbace_c_build__init_part0_A_Unit69__O(); A_arbace_c_build__init_part0_A_Unit70__O(); A_arbace_c_build__init_part0_A_Unit71__O(); A_arbace_c_build__init_part0_A_Unit72__O(); A_arbace_c_build__init_part0_A_Unit73__O(); A_arbace_c_build__init_part0_A_Unit74__O(); A_arbace_c_build__init_part0_A_Unit75__O(); A_arbace_c_build__init_part0_A_Unit76__O(); A_arbace_c_build__init_part0_A_Unit77__O(); A_arbace_c_build__init_part0_A_Unit78__O(); A_arbace_c_build__init_part0_A_Unit79__O(); A_arbace_c_build__init_part0_A_Unit80__O(); A_arbace_c_build__init_part0_A_Unit81__O(); A_arbace_c_build__init_part0_A_Unit82__O(); A_arbace_c_build__init_part0_A_Unit83__O(); A_arbace_c_build__init_part0_A_Unit84__O(); A_arbace_c_build__init_part0_A_Unit85__O(); A_arbace_c_build__init_part0_A_Unit86__O(); A_arbace_c_build__init_part0_A_Unit87__O(); A_arbace_c_build__init_part0_A_Unit88__O(); A_arbace_c_build__init_part0_A_Unit89__O(); A_arbace_c_build__init_part0_A_Unit90__O(); A_arbace_c_build__init_part0_A_Unit91__O(); A_arbace_c_build__init_part0_A_Unit92__O(); A_arbace_c_build__init_part0_A_Unit93__O(); A_arbace_c_build__init_part0_A_Unit94__O(); A_arbace_c_build__init_part0_A_Unit95__O(); A_arbace_c_build__init_part0_A_Unit96__O(); A_arbace_c_build__init_part0_A_Unit97__O(); A_arbace_c_build__init_part0_A_Unit98__O(); A_arbace_c_build__init_part0_A_Unit99__O(); return nil }



func A_arbace_c_build__init_A_Load__O() any { jrt.StartCheck(); A_arbace_c_build__init_part0_A_Init__O(); A_arbace_c_build__init_part1_A_Init__O(); A_arbace_c_build__init_part0_A_Load__O(); A_arbace_c_build__init_part1_A_Load__O(); return nil }













func A_arbace_c_build__init_part0_A_Unit4__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return A_arbace_c_build__init_part0_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }




func A_arbace_c_build__init_part0_A_Unit5__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_c_build__init_part0_A_const_5.BindRoot_O__V(A_arbace_c_build__init_part0_A_const_6); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_7)); return A_arbace_c_build__init_part0_A_const_5.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_build__init_part0_A_Unit6__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = A_arbace_c_build_with_types_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_build_with_types_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_248, true, nil); A_arbace_c_build_with_types_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_9)); return A_arbace_c_build__init_part0_A_const_8 }
//line :26:1
func A_arbace_c_build__init_part0_A_Unit7__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_c_build__init_part0_A_const_8.SetMacro__V(); return nil }
//line :26:1
func A_arbace_c_build__init_part0_A_Unit8__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return A_arbace_c_build__init_part0_A_const_8 }


func A_arbace_c_build__init_part0_A_Unit9__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_11)); return A_arbace_c_build__init_part0_A_const_10 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit10__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_13)); return A_arbace_c_build__init_part0_A_const_12 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit11__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_15)); return A_arbace_c_build__init_part0_A_const_14 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit12__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_17)); return A_arbace_c_build__init_part0_A_const_16 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit13__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_19)); return A_arbace_c_build__init_part0_A_const_18 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit14__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_21)); return A_arbace_c_build__init_part0_A_const_20 }
//line :29:1
func A_arbace_c_build__init_part0_A_Unit15__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_23)); return A_arbace_c_build__init_part0_A_const_22 }

func A_arbace_c_build__init_part0_A_Unit16__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = A_arbace_c_build_refuse_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_build_refuse_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_249, true, nil); A_arbace_c_build_refuse_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_25)); return A_arbace_c_build__init_part0_A_const_24 }





func A_arbace_c_build__init_part0_A_Unit17__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_26; tmp1.BindRoot_O__V(A_arbace_c_build__init_part0_A_const_27.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_c_build__init_part0_A_const_26; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_28)); return A_arbace_c_build__init_part0_A_const_26 }

func A_arbace_c_build__init_part0_A_Unit18__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_build_under_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_build_under_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_250, false, nil); A_arbace_c_build_under_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_30)); return A_arbace_c_build__init_part0_A_const_29 }




func A_arbace_c_build__init_part0_A_Unit19__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_build_size_of_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_build_size_of_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_251, false, nil); A_arbace_c_build_size_of_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_32)); return A_arbace_c_build__init_part0_A_const_31 }



func A_arbace_c_build__init_part0_A_Unit20__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_build_align_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_build_align_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_252, false, nil); A_arbace_c_build_align_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_34)); return A_arbace_c_build__init_part0_A_const_33 }

func A_arbace_c_build__init_part0_A_Unit21__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_build_wide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_build_wide_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_253, false, nil); A_arbace_c_build_wide_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_36)); return A_arbace_c_build__init_part0_A_const_35 }



func A_arbace_c_build__init_part0_A_Unit22__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_build_kind_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_build_kind_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_254, false, nil); A_arbace_c_build_kind_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_38)); return A_arbace_c_build__init_part0_A_const_37 }















func A_arbace_c_build__init_part0_A_Unit23__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_build_ity_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_build_ity_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_255, false, nil); A_arbace_c_build_ity_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_40)); return A_arbace_c_build__init_part0_A_const_39 }

















func A_arbace_c_build__init_part0_A_Unit24__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_build_wty_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_build_wty_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_256, false, nil); A_arbace_c_build_wty_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_42)); return A_arbace_c_build__init_part0_A_const_41 }





func A_arbace_c_build__init_part0_A_Unit25__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_build_f32_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_build_f32_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_257, false, nil); A_arbace_c_build_f32_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_44)); return A_arbace_c_build__init_part0_A_const_43 }
func A_arbace_c_build__init_part0_A_Unit26__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_build_fty_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_build_fty_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_258, false, nil); A_arbace_c_build_fty_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_46)); return A_arbace_c_build__init_part0_A_const_45 }

func A_arbace_c_build__init_part0_A_Unit27__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_build_ptr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_build_ptr_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_259, false, nil); A_arbace_c_build_ptr_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_48)); return A_arbace_c_build__init_part0_A_const_47 }
func A_arbace_c_build__init_part0_A_Unit28__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_build_unsigned_ty_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_build_unsigned_ty_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_260, false, nil); A_arbace_c_build_unsigned_ty_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_50)); return A_arbace_c_build__init_part0_A_const_49 }




func A_arbace_c_build__init_part0_A_Unit29__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_build_new_prog_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_build_new_prog_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_261, false, nil); A_arbace_c_build_new_prog_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_52)); return A_arbace_c_build__init_part0_A_const_51 }













func A_arbace_c_build__init_part0_A_Unit30__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); A_arbace_c_build__init_part0_A_const_53.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_54)); return A_arbace_c_build__init_part0_A_const_53.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_build__init_part0_A_Unit31__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); A_arbace_c_build__init_part0_A_const_55.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_56)); return A_arbace_c_build__init_part0_A_const_55.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_build__init_part0_A_Unit32__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); A_arbace_c_build__init_part0_A_const_57.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_58)); return A_arbace_c_build__init_part0_A_const_57.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_build__init_part0_A_Unit33__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_build_emit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_build_emit_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_262, false, nil); A_arbace_c_build_emit_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_60)); return A_arbace_c_build__init_part0_A_const_59 }

func A_arbace_c_build__init_part0_A_Unit34__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_build_fn_id_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_build_fn_id_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_263, false, nil); A_arbace_c_build_fn_id_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_62)); return A_arbace_c_build__init_part0_A_const_61 }










func A_arbace_c_build__init_part0_A_Unit35__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_build_static_idx_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_build_static_idx_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_264, false, nil); A_arbace_c_build_static_idx_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_64)); return A_arbace_c_build__init_part0_A_const_63 }









func A_arbace_c_build__init_part0_A_Unit36__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_build_hex_of_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_build_hex_of_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_265, false, nil); A_arbace_c_build_hex_of_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_66)); return A_arbace_c_build__init_part0_A_const_65 }




func A_arbace_c_build__init_part0_A_Unit37__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_build_string_static_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_build_string_static_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_266, false, nil); A_arbace_c_build_string_static_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_68)); return A_arbace_c_build__init_part0_A_const_67 }
















func A_arbace_c_build__init_part0_A_Unit38__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_build_utf8_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_build_utf8_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_267, false, nil); A_arbace_c_build_utf8_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_70)); return A_arbace_c_build__init_part0_A_const_69 }

func A_arbace_c_build__init_part0_A_Unit39__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_build_code_units_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_build_code_units_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_268, false, nil); A_arbace_c_build_code_units_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_72)); return A_arbace_c_build__init_part0_A_const_71 }











func A_arbace_c_build__init_part0_A_Unit40__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_build_units__GT_bytes_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_build_units__GT_bytes_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_269, false, nil); A_arbace_c_build_units__GT_bytes_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_74)); return A_arbace_c_build__init_part0_A_const_73 }





func A_arbace_c_build__init_part0_A_Unit41__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_build_string_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_build_string_form_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_270, false, nil); A_arbace_c_build_string_form_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_76)); return A_arbace_c_build__init_part0_A_const_75 }





func A_arbace_c_build__init_part0_A_Unit42__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_build_string_units_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_build_string_units_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_271, false, nil); A_arbace_c_build_string_units_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_78)); return A_arbace_c_build__init_part0_A_const_77 }










func A_arbace_c_build__init_part0_A_Unit43__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_build_ex_res_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_build_ex_res_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_272, false, nil); A_arbace_c_build_ex_res_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_80)); return A_arbace_c_build__init_part0_A_const_79 }

func A_arbace_c_build__init_part0_A_Unit44__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_build_lit_res_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_build_lit_res_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_273, false, nil); A_arbace_c_build_lit_res_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_82)); return A_arbace_c_build__init_part0_A_const_81 }














func A_arbace_c_build__init_part0_A_Unit45__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_build_res_of_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_build_res_of_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_274, false, nil); A_arbace_c_build_res_of_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_84)); return A_arbace_c_build__init_part0_A_const_83 }

func A_arbace_c_build__init_part0_A_Unit46__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_build_fbits_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_build_fbits_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_275, false, nil); A_arbace_c_build_fbits_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_86)); return A_arbace_c_build__init_part0_A_const_85 }

func A_arbace_c_build__init_part0_A_Unit47__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_build_int_const_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_build_int_const_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_276, false, nil); A_arbace_c_build_int_const_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_88)); return A_arbace_c_build__init_part0_A_const_87 }







func A_arbace_c_build__init_part0_A_Unit48__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_build_const_node_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_build_const_node_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_277, false, nil); A_arbace_c_build_const_node_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_90)); return A_arbace_c_build__init_part0_A_const_89 }












func A_arbace_c_build__init_part0_A_Unit49__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_build_truth_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_build_truth_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_278, false, nil); A_arbace_c_build_truth_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_92)); return A_arbace_c_build__init_part0_A_const_91 }










func A_arbace_c_build__init_part0_A_Unit50__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_93)); return A_arbace_c_build__init_part0_A_const_10 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit51__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_94)); return A_arbace_c_build__init_part0_A_const_12 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit52__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_95)); return A_arbace_c_build__init_part0_A_const_14 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit53__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_96)); return A_arbace_c_build__init_part0_A_const_16 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit54__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_97)); return A_arbace_c_build__init_part0_A_const_18 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit55__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_98)); return A_arbace_c_build__init_part0_A_const_20 }
//line :256:1
func A_arbace_c_build__init_part0_A_Unit56__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_99)); return A_arbace_c_build__init_part0_A_const_22 }

func A_arbace_c_build__init_part0_A_Unit57__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_build_conv_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_build_conv_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_279, false, nil); A_arbace_c_build_conv_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_101)); return A_arbace_c_build__init_part0_A_const_100 }













































func A_arbace_c_build__init_part0_A_Unit58__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_build_complex_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_build_complex_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_280, false, nil); A_arbace_c_build_complex_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_102)); return A_arbace_c_build__init_part0_A_const_14 }

func A_arbace_c_build__init_part0_A_Unit59__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_103)); return A_arbace_c_build__init_part0_A_const_18 }
//line :306:1
func A_arbace_c_build__init_part0_A_Unit60__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_104)); return A_arbace_c_build__init_part0_A_const_20 }
//line :306:1
func A_arbace_c_build__init_part0_A_Unit61__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_105)); return A_arbace_c_build__init_part0_A_const_16 }

func A_arbace_c_build__init_part0_A_Unit62__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_build_cparts_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_build_cparts_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_281, false, nil); A_arbace_c_build_cparts_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_106)); return A_arbace_c_build__init_part0_A_const_10 }









func A_arbace_c_build__init_part0_A_Unit63__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(318, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_build_cmake_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_build_cmake_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_282, false, nil); A_arbace_c_build_cmake_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_107)); return A_arbace_c_build__init_part0_A_const_12 }











func A_arbace_c_build__init_part0_A_Unit64__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_build_carith_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_build_carith_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_283, false, nil); A_arbace_c_build_carith_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_109)); return A_arbace_c_build__init_part0_A_const_108 }























func A_arbace_c_build__init_part0_A_Unit65__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_build_effect_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_build_effect_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_284, false, nil); A_arbace_c_build_effect_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_111)); return A_arbace_c_build__init_part0_A_const_110 }







func A_arbace_c_build__init_part0_A_Unit66__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_build_fstate_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_build_fstate_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_285, false, nil); A_arbace_c_build_fstate_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_113)); return A_arbace_c_build__init_part0_A_const_112 }

func A_arbace_c_build__init_part0_A_Unit67__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_build_new_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_build_new_slot_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_286, false, nil); A_arbace_c_build_new_slot_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_114)); return A_arbace_c_build__init_part0_A_const_22 }





func A_arbace_c_build__init_part0_A_Unit68__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_build_frame_alloc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_build_frame_alloc_BANG__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_287, false, nil); A_arbace_c_build_frame_alloc_BANG__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_116)); return A_arbace_c_build__init_part0_A_const_115 }







func A_arbace_c_build__init_part0_A_Unit69__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_build_label_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_build_label_code_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_288, false, nil); A_arbace_c_build_label_code_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_118)); return A_arbace_c_build__init_part0_A_const_117 }




func A_arbace_c_build__init_part0_A_Unit70__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(383, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_build_fresh_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_build_fresh_code_BANG__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_289, false, nil); A_arbace_c_build_fresh_code_BANG__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_120)); return A_arbace_c_build__init_part0_A_const_119 }




func A_arbace_c_build__init_part0_A_Unit71__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_build_local_of_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_build_local_of_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_290, false, nil); A_arbace_c_build_local_of_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_122)); return A_arbace_c_build__init_part0_A_const_121 }

func A_arbace_c_build__init_part0_A_Unit72__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_build_addressed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_build_addressed_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_291, false, nil); A_arbace_c_build_addressed_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_124)); return A_arbace_c_build__init_part0_A_const_123 }





func A_arbace_c_build__init_part0_A_Unit73__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c_build_bind_local_BANG__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_build_bind_local_BANG__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_292, false, nil); A_arbace_c_build_bind_local_BANG__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_126)); return A_arbace_c_build__init_part0_A_const_125 }
















func A_arbace_c_build__init_part0_A_Unit74__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c_build_global_key_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c_build_global_key_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_293, false, nil); A_arbace_c_build_global_key_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_128)); return A_arbace_c_build__init_part0_A_const_127 }


func A_arbace_c_build__init_part0_A_Unit75__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(416, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c_build_fn_ref_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c_build_fn_ref_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_294, false, nil); A_arbace_c_build_fn_ref_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_130)); return A_arbace_c_build__init_part0_A_const_129 }


func A_arbace_c_build__init_part0_A_Unit76__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(419, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c_build_global_obj_idx_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c_build_global_obj_idx_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_295, false, nil); A_arbace_c_build_global_obj_idx_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_132)); return A_arbace_c_build__init_part0_A_const_131 }














func A_arbace_c_build__init_part0_A_Unit77__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_133; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_134)); return A_arbace_c_build__init_part0_A_const_133 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit78__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_136)); return A_arbace_c_build__init_part0_A_const_135 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit79__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_137; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_138)); return A_arbace_c_build__init_part0_A_const_137 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit80__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_139; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_140)); return A_arbace_c_build__init_part0_A_const_139 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit81__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_141; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_142)); return A_arbace_c_build__init_part0_A_const_141 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit82__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_143; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_144)); return A_arbace_c_build__init_part0_A_const_143 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit83__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_145; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_146)); return A_arbace_c_build__init_part0_A_const_145 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit84__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_148)); return A_arbace_c_build__init_part0_A_const_147 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit85__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_149; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_150)); return A_arbace_c_build__init_part0_A_const_149 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit86__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_152)); return A_arbace_c_build__init_part0_A_const_151 }
//line :434:1
func A_arbace_c_build__init_part0_A_Unit87__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_154)); return A_arbace_c_build__init_part0_A_const_153 }

func A_arbace_c_build__init_part0_A_Unit88__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c_build_place_load_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c_build_place_load_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_296, false, nil); A_arbace_c_build_place_load_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_156)); return A_arbace_c_build__init_part0_A_const_155 }












func A_arbace_c_build__init_part0_A_Unit89__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(449, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c_build_place_store_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c_build_place_store_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_297, false, nil); A_arbace_c_build_place_store_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_158)); return A_arbace_c_build__init_part0_A_const_157 }













func A_arbace_c_build__init_part0_A_Unit90__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c_build_vla_elem_size_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c_build_vla_elem_size_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_298, false, nil); A_arbace_c_build_vla_elem_size_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_160)); return A_arbace_c_build__init_part0_A_const_159 }







func A_arbace_c_build__init_part0_A_Unit91__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c_build_ptr_target_size_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c_build_ptr_target_size_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_299, false, nil); A_arbace_c_build_ptr_target_size_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_162)); return A_arbace_c_build__init_part0_A_const_161 }





func A_arbace_c_build__init_part0_A_Unit92__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(477, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c_build_aget_place_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c_build_aget_place_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_300, false, nil); A_arbace_c_build_aget_place_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_164)); return A_arbace_c_build__init_part0_A_const_163 }








func A_arbace_c_build__init_part0_A_Unit93__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(486, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c_build_place_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c_build_place_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_301, false, nil); A_arbace_c_build_place_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_166)); return A_arbace_c_build__init_part0_A_const_165 }














































func A_arbace_c_build__init_part0_A_Unit94__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c_build_member_place_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c_build_member_place_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_302, false, nil); A_arbace_c_build_member_place_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_167)); return A_arbace_c_build__init_part0_A_const_143 }
















func A_arbace_c_build__init_part0_A_Unit95__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c_build_arrow_place_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c_build_arrow_place_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_303, false, nil); A_arbace_c_build_arrow_place_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_168)); return A_arbace_c_build__init_part0_A_const_145 }




















func A_arbace_c_build__init_part0_A_Unit96__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(571, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c_build_temp_i_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c_build_temp_i_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_304, false, nil); A_arbace_c_build_temp_i_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_169)); return A_arbace_c_build__init_part0_A_const_18 }

func A_arbace_c_build__init_part0_A_Unit97__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c_build_op_sym_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c_build_op_sym_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_305, false, nil); A_arbace_c_build_op_sym_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_171)); return A_arbace_c_build__init_part0_A_const_170 }



func A_arbace_c_build__init_part0_A_Unit98__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(577, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c_build_promoted_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c_build_promoted_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_306, false, nil); A_arbace_c_build_promoted_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_173)); return A_arbace_c_build__init_part0_A_const_172 }









func A_arbace_c_build__init_part0_A_Unit99__O() any { A_arbace_c_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part0_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_c_build_arith_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c_build_arith_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_307, false, nil); A_arbace_c_build_arith_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part0_A_const_175)); return A_arbace_c_build__init_part0_A_const_174 }













func A_arbace_c_build__init_part1_A_Unit100__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_build_shift_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_build_shift_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_c_build_shift_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_1)); return A_arbace_c_build__init_part1_A_const_0 }
//line :601:1
func A_arbace_c_build__init_part1_A_Init__O() any { A_arbace_c_build__init_part1_A_Init(); return nil }
//line :601:1
func A_arbace_c_build__init_part1_A_Load__O() any { A_arbace_c_build__init_part1_A_Init(); A_arbace_c_build__init_part1_A_Unit100__O(); A_arbace_c_build__init_part1_A_Unit101__O(); A_arbace_c_build__init_part1_A_Unit102__O(); A_arbace_c_build__init_part1_A_Unit103__O(); A_arbace_c_build__init_part1_A_Unit104__O(); A_arbace_c_build__init_part1_A_Unit105__O(); A_arbace_c_build__init_part1_A_Unit106__O(); A_arbace_c_build__init_part1_A_Unit107__O(); A_arbace_c_build__init_part1_A_Unit108__O(); A_arbace_c_build__init_part1_A_Unit109__O(); A_arbace_c_build__init_part1_A_Unit110__O(); A_arbace_c_build__init_part1_A_Unit111__O(); A_arbace_c_build__init_part1_A_Unit112__O(); A_arbace_c_build__init_part1_A_Unit113__O(); A_arbace_c_build__init_part1_A_Unit114__O(); A_arbace_c_build__init_part1_A_Unit115__O(); A_arbace_c_build__init_part1_A_Unit116__O(); A_arbace_c_build__init_part1_A_Unit117__O(); A_arbace_c_build__init_part1_A_Unit118__O(); A_arbace_c_build__init_part1_A_Unit119__O(); A_arbace_c_build__init_part1_A_Unit120__O(); A_arbace_c_build__init_part1_A_Unit121__O(); A_arbace_c_build__init_part1_A_Unit122__O(); A_arbace_c_build__init_part1_A_Unit123__O(); A_arbace_c_build__init_part1_A_Unit124__O(); A_arbace_c_build__init_part1_A_Unit125__O(); A_arbace_c_build__init_part1_A_Unit126__O(); A_arbace_c_build__init_part1_A_Unit127__O(); A_arbace_c_build__init_part1_A_Unit128__O(); A_arbace_c_build__init_part1_A_Unit129__O(); A_arbace_c_build__init_part1_A_Unit130__O(); A_arbace_c_build__init_part1_A_Unit131__O(); A_arbace_c_build__init_part1_A_Unit132__O(); A_arbace_c_build__init_part1_A_Unit133__O(); A_arbace_c_build__init_part1_A_Unit134__O(); A_arbace_c_build__init_part1_A_Unit135__O(); A_arbace_c_build__init_part1_A_Unit136__O(); A_arbace_c_build__init_part1_A_Unit137__O(); A_arbace_c_build__init_part1_A_Unit138__O(); A_arbace_c_build__init_part1_A_Unit139__O(); A_arbace_c_build__init_part1_A_Unit140__O(); A_arbace_c_build__init_part1_A_Unit141__O(); A_arbace_c_build__init_part1_A_Unit142__O(); A_arbace_c_build__init_part1_A_Unit143__O(); A_arbace_c_build__init_part1_A_Unit144__O(); A_arbace_c_build__init_part1_A_Unit145__O(); A_arbace_c_build__init_part1_A_Unit146__O(); A_arbace_c_build__init_part1_A_Unit147__O(); A_arbace_c_build__init_part1_A_Unit148__O(); A_arbace_c_build__init_part1_A_Unit149__O(); A_arbace_c_build__init_part1_A_Unit150__O(); A_arbace_c_build__init_part1_A_Unit151__O(); A_arbace_c_build__init_part1_A_Unit152__O(); A_arbace_c_build__init_part1_A_Unit153__O(); A_arbace_c_build__init_part1_A_Unit154__O(); A_arbace_c_build__init_part1_A_Unit155__O(); A_arbace_c_build__init_part1_A_Unit156__O(); A_arbace_c_build__init_part1_A_Unit157__O(); A_arbace_c_build__init_part1_A_Unit158__O(); A_arbace_c_build__init_part1_A_Unit159__O(); A_arbace_c_build__init_part1_A_Unit160__O(); A_arbace_c_build__init_part1_A_Unit161__O(); A_arbace_c_build__init_part1_A_Unit162__O(); A_arbace_c_build__init_part1_A_Unit163__O(); A_arbace_c_build__init_part1_A_Unit164__O(); A_arbace_c_build__init_part1_A_Unit165__O(); A_arbace_c_build__init_part1_A_Unit166__O(); return nil }





func A_arbace_c_build__init_part1_A_Unit101__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(607, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_build_compare_nodes_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_build_compare_nodes_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_c_build_compare_nodes_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_3)); return A_arbace_c_build__init_part1_A_const_2 }
















func A_arbace_c_build__init_part1_A_Unit102__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_build_binary_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_build_binary_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_c_build_binary_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_5)); return A_arbace_c_build__init_part1_A_const_4 }












func A_arbace_c_build__init_part1_A_Unit103__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(637, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_build_ex_neg_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_build_ex_neg_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_c_build_ex_neg_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_7)); return A_arbace_c_build__init_part1_A_const_6 }




func A_arbace_c_build__init_part1_A_Unit104__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(642, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_build_ex_as_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_build_ex_as_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_c_build_ex_as_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_9)); return A_arbace_c_build__init_part1_A_const_8 }





func A_arbace_c_build__init_part1_A_Unit105__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(648, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_build_seq_node_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_build_seq_node_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_c_build_seq_node_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_11)); return A_arbace_c_build__init_part1_A_const_10 }










func A_arbace_c_build__init_part1_A_Unit106__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(659, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_build_if_node_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_build_if_node_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_c_build_if_node_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_13)); return A_arbace_c_build__init_part1_A_const_12 }






func A_arbace_c_build__init_part1_A_Unit107__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_build_assign_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_build_assign_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_c_build_assign_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_15)); return A_arbace_c_build__init_part1_A_const_14 }






























func A_arbace_c_build__init_part1_A_Unit108__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(697, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_build_incdec_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_build_incdec_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_c_build_incdec_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_17)); return A_arbace_c_build__init_part1_A_const_16 }





























func A_arbace_c_build__init_part1_A_Unit109__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(727, 1); A_arbace_c_build__init_part1_A_const_18.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_19)); return A_arbace_c_build__init_part1_A_const_18.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_build__init_part1_A_Unit110__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(729, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_build_init_cmd_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_build_init_cmd_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_c_build_init_cmd_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_21)); return A_arbace_c_build__init_part1_A_const_20 }





func A_arbace_c_build__init_part1_A_Unit111__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(735, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_build_frame_temp_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_build_frame_temp_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, false, nil); A_arbace_c_build_frame_temp_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_23)); return A_arbace_c_build__init_part1_A_const_22 }






func A_arbace_c_build__init_part1_A_Unit112__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(742, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_build_compound_lit_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_build_compound_lit_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, false, nil); A_arbace_c_build_compound_lit_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_25)); return A_arbace_c_build__init_part1_A_const_24 }













func A_arbace_c_build__init_part1_A_Unit113__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_build_string_node_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_build_string_node_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_321, false, nil); A_arbace_c_build_string_node_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_27)); return A_arbace_c_build__init_part1_A_const_26 }



func A_arbace_c_build__init_part1_A_Unit114__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(760, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_build_stmt_expr_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_build_stmt_expr_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_322, false, nil); A_arbace_c_build_stmt_expr_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_29)); return A_arbace_c_build__init_part1_A_const_28 }





















func A_arbace_c_build__init_part1_A_Unit115__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(782, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_build_ex_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_build_ex_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_c_build_ex_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_31)); return A_arbace_c_build__init_part1_A_const_30 }




































































































































































func A_arbace_c_build__init_part1_A_Unit116__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(947, 1); A_arbace_c_build__init_part1_A_const_32.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_33); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_34)); return A_arbace_c_build__init_part1_A_const_32 }














func A_arbace_c_build__init_part1_A_Unit117__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(962, 1); A_arbace_c_build__init_part1_A_const_35.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_36); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_37)); return A_arbace_c_build__init_part1_A_const_35 }









func A_arbace_c_build__init_part1_A_Unit118__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(972, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_build_callee_type_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_build_callee_type_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_c_build_callee_type_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_39)); return A_arbace_c_build__init_part1_A_const_38 }



func A_arbace_c_build__init_part1_A_Unit119__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(976, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_build_arg_node_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_build_arg_node_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_c_build_arg_node_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_41)); return A_arbace_c_build__init_part1_A_const_40 }
















func A_arbace_c_build__init_part1_A_Unit120__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(993, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_build_builtin_call_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_build_builtin_call_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_c_build_builtin_call_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_43)); return A_arbace_c_build__init_part1_A_const_42 }














































func A_arbace_c_build__init_part1_A_Unit121__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1040, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_build_seq_node_eff_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_build_seq_node_eff_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_c_build_seq_node_eff_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_45)); return A_arbace_c_build__init_part1_A_const_44 }

func A_arbace_c_build__init_part1_A_Unit122__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1042, 1); A_arbace_c_build__init_part1_A_const_46.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_47); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_48)); return A_arbace_c_build__init_part1_A_const_46 }








func A_arbace_c_build__init_part1_A_Unit123__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1051, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_build_overflow_call_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_build_overflow_call_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_c_build_overflow_call_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_50)); return A_arbace_c_build__init_part1_A_const_49 }




















func A_arbace_c_build__init_part1_A_Unit124__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1072, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_build_call_node_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_build_call_node_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_c_build_call_node_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_52)); return A_arbace_c_build__init_part1_A_const_51 }




































func A_arbace_c_build__init_part1_A_Unit125__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1109, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_build_int_of_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_build_int_of_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_c_build_int_of_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_54)); return A_arbace_c_build__init_part1_A_const_53 }



func A_arbace_c_build__init_part1_A_Unit126__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1113, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_build_subobjects_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_build_subobjects_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_c_build_subobjects_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_56)); return A_arbace_c_build__init_part1_A_const_55 }









func A_arbace_c_build__init_part1_A_Unit127__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1123, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_build_elem_store_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_build_elem_store_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_c_build_elem_store_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_58)); return A_arbace_c_build__init_part1_A_const_57 }







func A_arbace_c_build__init_part1_A_Unit128__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1131, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_build_addr_PLUS__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_build_addr_PLUS__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_c_build_addr_PLUS__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_60)); return A_arbace_c_build__init_part1_A_const_59 }

func A_arbace_c_build__init_part1_A_Unit129__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1133, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_62)); return A_arbace_c_build__init_part1_A_const_61 }

func A_arbace_c_build__init_part1_A_Unit130__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1135, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_build_char_array_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_build_char_array_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_c_build_char_array_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_64)); return A_arbace_c_build__init_part1_A_const_63 }


func A_arbace_c_build__init_part1_A_Unit131__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1138, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_build_string_stores_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_build_string_stores_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_c_build_string_stores_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_66)); return A_arbace_c_build__init_part1_A_const_65 }







func A_arbace_c_build__init_part1_A_Unit132__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1146, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_build_fill_list_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_build_fill_list_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_c_build_fill_list_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_68)); return A_arbace_c_build__init_part1_A_const_67 }















































































func A_arbace_c_build__init_part1_A_Unit133__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1226, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_build_anon_members_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_build_anon_members_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, false, nil); A_arbace_c_build_anon_members_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_70)); return A_arbace_c_build__init_part1_A_const_69 }






func A_arbace_c_build__init_part1_A_Unit134__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1233, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_build_fill_designated_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_build_fill_designated_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_c_build_fill_designated_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_72)); return A_arbace_c_build__init_part1_A_const_71 }


















func A_arbace_c_build__init_part1_A_Unit135__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1252, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_build_fill_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_build_fill_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_c_build_fill_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_73)); return A_arbace_c_build__init_part1_A_const_61 }
























func A_arbace_c_build__init_part1_A_Unit136__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1277, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_build_build_init_stores_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_build_build_init_stores_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_c_build_build_init_stores_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_75)); return A_arbace_c_build__init_part1_A_const_74 }


















func A_arbace_c_build__init_part1_A_Unit137__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1296, 1); A_arbace_c_build__init_part1_A_const_76.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_77)); return A_arbace_c_build__init_part1_A_const_76.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_build__init_part1_A_Unit138__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1298, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_build_decl_head_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_build_decl_head_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_c_build_decl_head_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_79)); return A_arbace_c_build__init_part1_A_const_78 }

func A_arbace_c_build__init_part1_A_Unit139__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1300, 1); A_arbace_c_build__init_part1_A_const_80.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_81)); return A_arbace_c_build__init_part1_A_const_80.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_build__init_part1_A_Unit140__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1301, 1); A_arbace_c_build__init_part1_A_const_82.BindRoot_O__V(lang.PersistentVector_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_83)); return A_arbace_c_build__init_part1_A_const_82.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_build__init_part1_A_Unit141__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1302, 1); A_arbace_c_build__init_part1_A_const_84.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_85); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_86)); return A_arbace_c_build__init_part1_A_const_84.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_build__init_part1_A_Unit142__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1303, 1); A_arbace_c_build__init_part1_A_const_87.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_85); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_88)); return A_arbace_c_build__init_part1_A_const_87.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_build__init_part1_A_Unit143__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1305, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_build_vla_leave_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_build_vla_leave_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_c_build_vla_leave_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_90)); return A_arbace_c_build__init_part1_A_const_89 }






func A_arbace_c_build__init_part1_A_Unit144__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1312, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_build_vla_alloc_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_build_vla_alloc_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_c_build_vla_alloc_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_92)); return A_arbace_c_build__init_part1_A_const_91 }












func A_arbace_c_build__init_part1_A_Unit145__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1325, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_build_local_decl_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_build_local_decl_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_344, false, nil); A_arbace_c_build_local_decl_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_94)); return A_arbace_c_build__init_part1_A_const_93 }

































func A_arbace_c_build__init_part1_A_Unit146__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1359, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_build_empty_asm_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_build_empty_asm_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_c_build_empty_asm_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_96)); return A_arbace_c_build__init_part1_A_const_95 }







func A_arbace_c_build__init_part1_A_Unit147__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1367, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_build_asm_body_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_build_asm_body_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_c_build_asm_body_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_98)); return A_arbace_c_build__init_part1_A_const_97 }







func A_arbace_c_build__init_part1_A_Unit148__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1375, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_build_stmts_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_build_stmts_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_c_build_stmts_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_100)); return A_arbace_c_build__init_part1_A_const_99 }

func A_arbace_c_build__init_part1_A_Unit149__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1377, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_build_do_node_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_build_do_node_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_c_build_do_node_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_102)); return A_arbace_c_build__init_part1_A_const_101 }

func A_arbace_c_build__init_part1_A_Unit150__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1379, 1); A_arbace_c_build__init_part1_A_const_103.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_104); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_103; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_105)); return A_arbace_c_build__init_part1_A_const_103 }

func A_arbace_c_build__init_part1_A_Unit151__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1381, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_build_has_setjmp_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_build_has_setjmp_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_c_build_has_setjmp_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_107)); return A_arbace_c_build__init_part1_A_const_106 }














func A_arbace_c_build__init_part1_A_Unit152__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1396, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_build_stmt_STAR__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_build_stmt_STAR__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_c_build_stmt_STAR__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_109)); return A_arbace_c_build__init_part1_A_const_108 }


















































































func A_arbace_c_build__init_part1_A_Unit153__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1479, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_build_calls_setjmp_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_build_calls_setjmp_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_c_build_calls_setjmp_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_111)); return A_arbace_c_build__init_part1_A_const_110 }







func A_arbace_c_build__init_part1_A_Unit154__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1487, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_build_build_stmt_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_build_build_stmt_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, false, nil); A_arbace_c_build_build_stmt_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_113)); return A_arbace_c_build__init_part1_A_const_112 }






func A_arbace_c_build__init_part1_A_Unit155__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1494, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_build_addressed_names_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_build_addressed_names_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_353, false, nil); A_arbace_c_build_addressed_names_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_115)); return A_arbace_c_build__init_part1_A_const_114 }






















func A_arbace_c_build__init_part1_A_Unit156__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1517, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_build_param_spec_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_build_param_spec_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_354, false, nil); A_arbace_c_build_param_spec_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_117)); return A_arbace_c_build__init_part1_A_const_116 }











func A_arbace_c_build__init_part1_A_Unit157__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1529, 1); A_arbace_c_build__init_part1_A_const_118.BindRoot_O__V(A_arbace_c_build__init_part1_A_const_119); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_120)); return A_arbace_c_build__init_part1_A_const_118 }






func A_arbace_c_build__init_part1_A_Unit158__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1536, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c_build_build_fn_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_build_build_fn_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_355, false, nil); A_arbace_c_build_build_fn_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_122)); return A_arbace_c_build__init_part1_A_const_121 }








































func A_arbace_c_build__init_part1_A_Unit159__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1577, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c_build_unit_forms_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c_build_unit_forms_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_c_build_unit_forms_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_124)); return A_arbace_c_build__init_part1_A_const_123 }















func A_arbace_c_build__init_part1_A_Unit160__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1593, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c_build_file_objects_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c_build_file_objects_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_357, false, nil); A_arbace_c_build_file_objects_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_126)); return A_arbace_c_build__init_part1_A_const_125 }










func A_arbace_c_build__init_part1_A_Unit161__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1604, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c_build_decl_attrs_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c_build_decl_attrs_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_358, false, nil); A_arbace_c_build_decl_attrs_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_128)); return A_arbace_c_build__init_part1_A_const_127 }















func A_arbace_c_build__init_part1_A_Unit162__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1620, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c_build_ex_res_name_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c_build_ex_res_name_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_359, false, nil); A_arbace_c_build_ex_res_name_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_130)); return A_arbace_c_build__init_part1_A_const_129 }




func A_arbace_c_build__init_part1_A_Unit163__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1625, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c_build_tentative_or_def_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c_build_tentative_or_def_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_360, false, nil); A_arbace_c_build_tentative_or_def_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_132)); return A_arbace_c_build__init_part1_A_const_131 }


func A_arbace_c_build__init_part1_A_Unit164__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1628, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c_build_flex_extra_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c_build_flex_extra_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_361, false, nil); A_arbace_c_build_flex_extra_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_134)); return A_arbace_c_build__init_part1_A_const_133 }


















func A_arbace_c_build__init_part1_A_Unit165__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1647, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__108 any = A_arbace_c_build_build_program_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c_build_build_program_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_362, true, nil); A_arbace_c_build_build_program_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__108, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_136)); return A_arbace_c_build__init_part1_A_const_135 }


















































































func A_arbace_c_build__init_part1_A_Unit166__O() any { A_arbace_c_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1730, 1); var tmp1 *lang.Var = A_arbace_c_build__init_part1_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c_build_program_text_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c_build_program_text_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_363, false, nil); A_arbace_c_build_program_text_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_build__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_build__init_part1_A_const_138)); return A_arbace_c_build__init_part1_A_const_137 }



type A_arbace_c_build__init_A struct{ jrt.Object }

func A_arbace_c_build__init_A_New() *A_arbace_c_build__init_A { t := &A_arbace_c_build__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c_build__init_A) Ctor() {}

func (t *A_arbace_c_build__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_build__init_A) GetClass__Class() *jrt.Class { return A_arbace_c_build__init_A_class }

func (t *A_arbace_c_build__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_build__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_build__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_build__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_build__init_A); return ok }

func A_arbace_c_build__init_A_Cast(x any) *A_arbace_c_build__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_build__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_build__init_A_class)) }; return v }



type A_arbace_c_build__init_part0_A struct{ jrt.Object }

var A_arbace_c_build__init_part0_A_const_pool *jrt.RefArray

var A_arbace_c_build__init_part0_A_const_0 *lang.Var

var A_arbace_c_build__init_part0_A_const_1 any

var A_arbace_c_build__init_part0_A_const_2 any

var A_arbace_c_build__init_part0_A_const_3 any

var A_arbace_c_build__init_part0_A_const_4 *lang.Var

var A_arbace_c_build__init_part0_A_const_5 *lang.Var

var A_arbace_c_build__init_part0_A_const_6 any

var A_arbace_c_build__init_part0_A_const_7 any

var A_arbace_c_build__init_part0_A_const_8 *lang.Var

var A_arbace_c_build__init_part0_A_const_9 any

var A_arbace_c_build__init_part0_A_const_10 *lang.Var

var A_arbace_c_build__init_part0_A_const_11 any

var A_arbace_c_build__init_part0_A_const_12 *lang.Var

var A_arbace_c_build__init_part0_A_const_13 any

var A_arbace_c_build__init_part0_A_const_14 *lang.Var

var A_arbace_c_build__init_part0_A_const_15 any

var A_arbace_c_build__init_part0_A_const_16 *lang.Var

var A_arbace_c_build__init_part0_A_const_17 any

var A_arbace_c_build__init_part0_A_const_18 *lang.Var

var A_arbace_c_build__init_part0_A_const_19 any

var A_arbace_c_build__init_part0_A_const_20 *lang.Var

var A_arbace_c_build__init_part0_A_const_21 any

var A_arbace_c_build__init_part0_A_const_22 *lang.Var

var A_arbace_c_build__init_part0_A_const_23 any

var A_arbace_c_build__init_part0_A_const_24 *lang.Var

var A_arbace_c_build__init_part0_A_const_25 any

var A_arbace_c_build__init_part0_A_const_26 *lang.Var

var A_arbace_c_build__init_part0_A_const_27 *lang.Var

var A_arbace_c_build__init_part0_A_const_28 any

var A_arbace_c_build__init_part0_A_const_29 *lang.Var

var A_arbace_c_build__init_part0_A_const_30 any

var A_arbace_c_build__init_part0_A_const_31 *lang.Var

var A_arbace_c_build__init_part0_A_const_32 any

var A_arbace_c_build__init_part0_A_const_33 *lang.Var

var A_arbace_c_build__init_part0_A_const_34 any

var A_arbace_c_build__init_part0_A_const_35 *lang.Var

var A_arbace_c_build__init_part0_A_const_36 any

var A_arbace_c_build__init_part0_A_const_37 *lang.Var

var A_arbace_c_build__init_part0_A_const_38 any

var A_arbace_c_build__init_part0_A_const_39 *lang.Var

var A_arbace_c_build__init_part0_A_const_40 any

var A_arbace_c_build__init_part0_A_const_41 *lang.Var

var A_arbace_c_build__init_part0_A_const_42 any

var A_arbace_c_build__init_part0_A_const_43 *lang.Var

var A_arbace_c_build__init_part0_A_const_44 any

var A_arbace_c_build__init_part0_A_const_45 *lang.Var

var A_arbace_c_build__init_part0_A_const_46 any

var A_arbace_c_build__init_part0_A_const_47 *lang.Var

var A_arbace_c_build__init_part0_A_const_48 any

var A_arbace_c_build__init_part0_A_const_49 *lang.Var

var A_arbace_c_build__init_part0_A_const_50 any

var A_arbace_c_build__init_part0_A_const_51 *lang.Var

var A_arbace_c_build__init_part0_A_const_52 any

var A_arbace_c_build__init_part0_A_const_53 *lang.Var

var A_arbace_c_build__init_part0_A_const_54 any

var A_arbace_c_build__init_part0_A_const_55 *lang.Var

var A_arbace_c_build__init_part0_A_const_56 any

var A_arbace_c_build__init_part0_A_const_57 *lang.Var

var A_arbace_c_build__init_part0_A_const_58 any

var A_arbace_c_build__init_part0_A_const_59 *lang.Var

var A_arbace_c_build__init_part0_A_const_60 any

var A_arbace_c_build__init_part0_A_const_61 *lang.Var

var A_arbace_c_build__init_part0_A_const_62 any

var A_arbace_c_build__init_part0_A_const_63 *lang.Var

var A_arbace_c_build__init_part0_A_const_64 any

var A_arbace_c_build__init_part0_A_const_65 *lang.Var

var A_arbace_c_build__init_part0_A_const_66 any

var A_arbace_c_build__init_part0_A_const_67 *lang.Var

var A_arbace_c_build__init_part0_A_const_68 any

var A_arbace_c_build__init_part0_A_const_69 *lang.Var

var A_arbace_c_build__init_part0_A_const_70 any

var A_arbace_c_build__init_part0_A_const_71 *lang.Var

var A_arbace_c_build__init_part0_A_const_72 any

var A_arbace_c_build__init_part0_A_const_73 *lang.Var

var A_arbace_c_build__init_part0_A_const_74 any

var A_arbace_c_build__init_part0_A_const_75 *lang.Var

var A_arbace_c_build__init_part0_A_const_76 any

var A_arbace_c_build__init_part0_A_const_77 *lang.Var

var A_arbace_c_build__init_part0_A_const_78 any

var A_arbace_c_build__init_part0_A_const_79 *lang.Var

var A_arbace_c_build__init_part0_A_const_80 any

var A_arbace_c_build__init_part0_A_const_81 *lang.Var

var A_arbace_c_build__init_part0_A_const_82 any

var A_arbace_c_build__init_part0_A_const_83 *lang.Var

var A_arbace_c_build__init_part0_A_const_84 any

var A_arbace_c_build__init_part0_A_const_85 *lang.Var

var A_arbace_c_build__init_part0_A_const_86 any

var A_arbace_c_build__init_part0_A_const_87 *lang.Var

var A_arbace_c_build__init_part0_A_const_88 any

var A_arbace_c_build__init_part0_A_const_89 *lang.Var

var A_arbace_c_build__init_part0_A_const_90 any

var A_arbace_c_build__init_part0_A_const_91 *lang.Var

var A_arbace_c_build__init_part0_A_const_92 any

var A_arbace_c_build__init_part0_A_const_93 any

var A_arbace_c_build__init_part0_A_const_94 any

var A_arbace_c_build__init_part0_A_const_95 any

var A_arbace_c_build__init_part0_A_const_96 any

var A_arbace_c_build__init_part0_A_const_97 any

var A_arbace_c_build__init_part0_A_const_98 any

var A_arbace_c_build__init_part0_A_const_99 any

var A_arbace_c_build__init_part0_A_const_100 *lang.Var

var A_arbace_c_build__init_part0_A_const_101 any

var A_arbace_c_build__init_part0_A_const_102 any

var A_arbace_c_build__init_part0_A_const_103 any

var A_arbace_c_build__init_part0_A_const_104 any

var A_arbace_c_build__init_part0_A_const_105 any

var A_arbace_c_build__init_part0_A_const_106 any

var A_arbace_c_build__init_part0_A_const_107 any

var A_arbace_c_build__init_part0_A_const_108 *lang.Var

var A_arbace_c_build__init_part0_A_const_109 any

var A_arbace_c_build__init_part0_A_const_110 *lang.Var

var A_arbace_c_build__init_part0_A_const_111 any

var A_arbace_c_build__init_part0_A_const_112 *lang.Var

var A_arbace_c_build__init_part0_A_const_113 any

var A_arbace_c_build__init_part0_A_const_114 any

var A_arbace_c_build__init_part0_A_const_115 *lang.Var

var A_arbace_c_build__init_part0_A_const_116 any

var A_arbace_c_build__init_part0_A_const_117 *lang.Var

var A_arbace_c_build__init_part0_A_const_118 any

var A_arbace_c_build__init_part0_A_const_119 *lang.Var

var A_arbace_c_build__init_part0_A_const_120 any

var A_arbace_c_build__init_part0_A_const_121 *lang.Var

var A_arbace_c_build__init_part0_A_const_122 any

var A_arbace_c_build__init_part0_A_const_123 *lang.Var

var A_arbace_c_build__init_part0_A_const_124 any

var A_arbace_c_build__init_part0_A_const_125 *lang.Var

var A_arbace_c_build__init_part0_A_const_126 any

var A_arbace_c_build__init_part0_A_const_127 *lang.Var

var A_arbace_c_build__init_part0_A_const_128 any

var A_arbace_c_build__init_part0_A_const_129 *lang.Var

var A_arbace_c_build__init_part0_A_const_130 any

var A_arbace_c_build__init_part0_A_const_131 *lang.Var

var A_arbace_c_build__init_part0_A_const_132 any

var A_arbace_c_build__init_part0_A_const_133 *lang.Var

var A_arbace_c_build__init_part0_A_const_134 any

var A_arbace_c_build__init_part0_A_const_135 *lang.Var

var A_arbace_c_build__init_part0_A_const_136 any

var A_arbace_c_build__init_part0_A_const_137 *lang.Var

var A_arbace_c_build__init_part0_A_const_138 any

var A_arbace_c_build__init_part0_A_const_139 *lang.Var

var A_arbace_c_build__init_part0_A_const_140 any

var A_arbace_c_build__init_part0_A_const_141 *lang.Var

var A_arbace_c_build__init_part0_A_const_142 any

var A_arbace_c_build__init_part0_A_const_143 *lang.Var

var A_arbace_c_build__init_part0_A_const_144 any

var A_arbace_c_build__init_part0_A_const_145 *lang.Var

var A_arbace_c_build__init_part0_A_const_146 any

var A_arbace_c_build__init_part0_A_const_147 *lang.Var

var A_arbace_c_build__init_part0_A_const_148 any

var A_arbace_c_build__init_part0_A_const_149 *lang.Var

var A_arbace_c_build__init_part0_A_const_150 any

var A_arbace_c_build__init_part0_A_const_151 *lang.Var

var A_arbace_c_build__init_part0_A_const_152 any

var A_arbace_c_build__init_part0_A_const_153 *lang.Var

var A_arbace_c_build__init_part0_A_const_154 any

var A_arbace_c_build__init_part0_A_const_155 *lang.Var

var A_arbace_c_build__init_part0_A_const_156 any

var A_arbace_c_build__init_part0_A_const_157 *lang.Var

var A_arbace_c_build__init_part0_A_const_158 any

var A_arbace_c_build__init_part0_A_const_159 *lang.Var

var A_arbace_c_build__init_part0_A_const_160 any

var A_arbace_c_build__init_part0_A_const_161 *lang.Var

var A_arbace_c_build__init_part0_A_const_162 any

var A_arbace_c_build__init_part0_A_const_163 *lang.Var

var A_arbace_c_build__init_part0_A_const_164 any

var A_arbace_c_build__init_part0_A_const_165 *lang.Var

var A_arbace_c_build__init_part0_A_const_166 any

var A_arbace_c_build__init_part0_A_const_167 any

var A_arbace_c_build__init_part0_A_const_168 any

var A_arbace_c_build__init_part0_A_const_169 any

var A_arbace_c_build__init_part0_A_const_170 *lang.Var

var A_arbace_c_build__init_part0_A_const_171 any

var A_arbace_c_build__init_part0_A_const_172 *lang.Var

var A_arbace_c_build__init_part0_A_const_173 any

var A_arbace_c_build__init_part0_A_const_174 *lang.Var

var A_arbace_c_build__init_part0_A_const_175 any

var A_arbace_c_build__init_part0_A_init jrt.ClassInit

func A_arbace_c_build__init_part0_A_Init() { if !A_arbace_c_build__init_part0_A_init.Done() { A_arbace_c_build__init_part0_A_init.Run(A_arbace_c_build__init_part0_A_clinit) } }

func A_arbace_c_build__init_part0_A_clinit() { A_arbace_c_build__init_part0_A_clinit_p0(); A_arbace_c_build__init_part0_A_clinit_p1(); A_arbace_c_build__init_part0_A_clinit_p2(); A_arbace_c_build__init_part0_A_clinit_p3(); A_arbace_c_build__init_part0_A_clinit_p4(); A_arbace_c_build__init_part0_A_clinit_p5(); A_arbace_c_build__init_part0_A_clinit_p6(); A_arbace_c_build__init_part0_A_clinit_p7(); A_arbace_c_build__init_part0_A_clinit_p8(); A_arbace_c_build__init_part0_A_clinit_p9(); A_arbace_c_build__init_part0_A_clinit_p10(); A_arbace_c_build__init_part0_A_clinit_p11(); A_arbace_c_build__init_part0_A_clinit_p12(); A_arbace_c_build__init_part0_A_clinit_p13() }

func A_arbace_c_build__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_build__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_245, 226); A_arbace_c_build__init_part0_A_const_0 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[50]); A_arbace_c_build__init_part0_A_const_1 = A_arbace_c_build__init_part0_A_const_pool.A[51]; A_arbace_c_build__init_part0_A_const_2 = A_arbace_c_build__init_part0_A_const_pool.A[52]; A_arbace_c_build__init_part0_A_const_3 = A_arbace_c_build__init_part0_A_const_pool.A[53]; A_arbace_c_build__init_part0_A_const_4 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[54]); A_arbace_c_build__init_part0_A_const_5 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[55]); A_arbace_c_build__init_part0_A_const_6 = A_arbace_c_build__init_part0_A_const_pool.A[56]; A_arbace_c_build__init_part0_A_const_7 = A_arbace_c_build__init_part0_A_const_pool.A[57]; A_arbace_c_build__init_part0_A_const_8 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[58]); A_arbace_c_build__init_part0_A_const_9 = A_arbace_c_build__init_part0_A_const_pool.A[59]; A_arbace_c_build__init_part0_A_const_10 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[60]); A_arbace_c_build__init_part0_A_const_11 = A_arbace_c_build__init_part0_A_const_pool.A[61]; A_arbace_c_build__init_part0_A_const_12 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[62]) }

func A_arbace_c_build__init_part0_A_clinit_p1() { A_arbace_c_build__init_part0_A_const_13 = A_arbace_c_build__init_part0_A_const_pool.A[63]; A_arbace_c_build__init_part0_A_const_14 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[64]); A_arbace_c_build__init_part0_A_const_15 = A_arbace_c_build__init_part0_A_const_pool.A[65]; A_arbace_c_build__init_part0_A_const_16 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[66]); A_arbace_c_build__init_part0_A_const_17 = A_arbace_c_build__init_part0_A_const_pool.A[67]; A_arbace_c_build__init_part0_A_const_18 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[68]); A_arbace_c_build__init_part0_A_const_19 = A_arbace_c_build__init_part0_A_const_pool.A[69]; A_arbace_c_build__init_part0_A_const_20 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[70]); A_arbace_c_build__init_part0_A_const_21 = A_arbace_c_build__init_part0_A_const_pool.A[71]; A_arbace_c_build__init_part0_A_const_22 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[72]); A_arbace_c_build__init_part0_A_const_23 = A_arbace_c_build__init_part0_A_const_pool.A[73]; A_arbace_c_build__init_part0_A_const_24 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[74]); A_arbace_c_build__init_part0_A_const_25 = A_arbace_c_build__init_part0_A_const_pool.A[75] }

func A_arbace_c_build__init_part0_A_clinit_p2() { A_arbace_c_build__init_part0_A_const_26 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[76]); A_arbace_c_build__init_part0_A_const_27 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[77]); A_arbace_c_build__init_part0_A_const_28 = A_arbace_c_build__init_part0_A_const_pool.A[78]; A_arbace_c_build__init_part0_A_const_29 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[79]); A_arbace_c_build__init_part0_A_const_30 = A_arbace_c_build__init_part0_A_const_pool.A[80]; A_arbace_c_build__init_part0_A_const_31 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[81]); A_arbace_c_build__init_part0_A_const_32 = A_arbace_c_build__init_part0_A_const_pool.A[82]; A_arbace_c_build__init_part0_A_const_33 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[83]); A_arbace_c_build__init_part0_A_const_34 = A_arbace_c_build__init_part0_A_const_pool.A[84]; A_arbace_c_build__init_part0_A_const_35 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[85]); A_arbace_c_build__init_part0_A_const_36 = A_arbace_c_build__init_part0_A_const_pool.A[86]; A_arbace_c_build__init_part0_A_const_37 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[87]); A_arbace_c_build__init_part0_A_const_38 = A_arbace_c_build__init_part0_A_const_pool.A[88] }

func A_arbace_c_build__init_part0_A_clinit_p3() { A_arbace_c_build__init_part0_A_const_39 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[89]); A_arbace_c_build__init_part0_A_const_40 = A_arbace_c_build__init_part0_A_const_pool.A[90]; A_arbace_c_build__init_part0_A_const_41 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[91]); A_arbace_c_build__init_part0_A_const_42 = A_arbace_c_build__init_part0_A_const_pool.A[92]; A_arbace_c_build__init_part0_A_const_43 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[93]); A_arbace_c_build__init_part0_A_const_44 = A_arbace_c_build__init_part0_A_const_pool.A[94]; A_arbace_c_build__init_part0_A_const_45 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[95]); A_arbace_c_build__init_part0_A_const_46 = A_arbace_c_build__init_part0_A_const_pool.A[96]; A_arbace_c_build__init_part0_A_const_47 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[97]); A_arbace_c_build__init_part0_A_const_48 = A_arbace_c_build__init_part0_A_const_pool.A[98]; A_arbace_c_build__init_part0_A_const_49 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[99]); A_arbace_c_build__init_part0_A_const_50 = A_arbace_c_build__init_part0_A_const_pool.A[100]; A_arbace_c_build__init_part0_A_const_51 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[101]) }

func A_arbace_c_build__init_part0_A_clinit_p4() { A_arbace_c_build__init_part0_A_const_52 = A_arbace_c_build__init_part0_A_const_pool.A[102]; A_arbace_c_build__init_part0_A_const_53 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[103]); A_arbace_c_build__init_part0_A_const_54 = A_arbace_c_build__init_part0_A_const_pool.A[104]; A_arbace_c_build__init_part0_A_const_55 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[105]); A_arbace_c_build__init_part0_A_const_56 = A_arbace_c_build__init_part0_A_const_pool.A[106]; A_arbace_c_build__init_part0_A_const_57 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[107]); A_arbace_c_build__init_part0_A_const_58 = A_arbace_c_build__init_part0_A_const_pool.A[108]; A_arbace_c_build__init_part0_A_const_59 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[109]); A_arbace_c_build__init_part0_A_const_60 = A_arbace_c_build__init_part0_A_const_pool.A[110]; A_arbace_c_build__init_part0_A_const_61 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[111]); A_arbace_c_build__init_part0_A_const_62 = A_arbace_c_build__init_part0_A_const_pool.A[112]; A_arbace_c_build__init_part0_A_const_63 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[113]); A_arbace_c_build__init_part0_A_const_64 = A_arbace_c_build__init_part0_A_const_pool.A[114] }

func A_arbace_c_build__init_part0_A_clinit_p5() { A_arbace_c_build__init_part0_A_const_65 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[115]); A_arbace_c_build__init_part0_A_const_66 = A_arbace_c_build__init_part0_A_const_pool.A[116]; A_arbace_c_build__init_part0_A_const_67 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[117]); A_arbace_c_build__init_part0_A_const_68 = A_arbace_c_build__init_part0_A_const_pool.A[118]; A_arbace_c_build__init_part0_A_const_69 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[119]); A_arbace_c_build__init_part0_A_const_70 = A_arbace_c_build__init_part0_A_const_pool.A[120]; A_arbace_c_build__init_part0_A_const_71 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[121]); A_arbace_c_build__init_part0_A_const_72 = A_arbace_c_build__init_part0_A_const_pool.A[122]; A_arbace_c_build__init_part0_A_const_73 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[123]); A_arbace_c_build__init_part0_A_const_74 = A_arbace_c_build__init_part0_A_const_pool.A[124]; A_arbace_c_build__init_part0_A_const_75 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[125]); A_arbace_c_build__init_part0_A_const_76 = A_arbace_c_build__init_part0_A_const_pool.A[126]; A_arbace_c_build__init_part0_A_const_77 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[127]) }

func A_arbace_c_build__init_part0_A_clinit_p6() { A_arbace_c_build__init_part0_A_const_78 = A_arbace_c_build__init_part0_A_const_pool.A[128]; A_arbace_c_build__init_part0_A_const_79 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[129]); A_arbace_c_build__init_part0_A_const_80 = A_arbace_c_build__init_part0_A_const_pool.A[130]; A_arbace_c_build__init_part0_A_const_81 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[131]); A_arbace_c_build__init_part0_A_const_82 = A_arbace_c_build__init_part0_A_const_pool.A[132]; A_arbace_c_build__init_part0_A_const_83 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[133]); A_arbace_c_build__init_part0_A_const_84 = A_arbace_c_build__init_part0_A_const_pool.A[134]; A_arbace_c_build__init_part0_A_const_85 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[135]); A_arbace_c_build__init_part0_A_const_86 = A_arbace_c_build__init_part0_A_const_pool.A[136]; A_arbace_c_build__init_part0_A_const_87 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[137]); A_arbace_c_build__init_part0_A_const_88 = A_arbace_c_build__init_part0_A_const_pool.A[138]; A_arbace_c_build__init_part0_A_const_89 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[139]); A_arbace_c_build__init_part0_A_const_90 = A_arbace_c_build__init_part0_A_const_pool.A[140] }

func A_arbace_c_build__init_part0_A_clinit_p7() { A_arbace_c_build__init_part0_A_const_91 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[141]); A_arbace_c_build__init_part0_A_const_92 = A_arbace_c_build__init_part0_A_const_pool.A[142]; A_arbace_c_build__init_part0_A_const_93 = A_arbace_c_build__init_part0_A_const_pool.A[143]; A_arbace_c_build__init_part0_A_const_94 = A_arbace_c_build__init_part0_A_const_pool.A[144]; A_arbace_c_build__init_part0_A_const_95 = A_arbace_c_build__init_part0_A_const_pool.A[145]; A_arbace_c_build__init_part0_A_const_96 = A_arbace_c_build__init_part0_A_const_pool.A[146]; A_arbace_c_build__init_part0_A_const_97 = A_arbace_c_build__init_part0_A_const_pool.A[147]; A_arbace_c_build__init_part0_A_const_98 = A_arbace_c_build__init_part0_A_const_pool.A[148]; A_arbace_c_build__init_part0_A_const_99 = A_arbace_c_build__init_part0_A_const_pool.A[149]; A_arbace_c_build__init_part0_A_const_100 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[150]); A_arbace_c_build__init_part0_A_const_101 = A_arbace_c_build__init_part0_A_const_pool.A[151]; A_arbace_c_build__init_part0_A_const_102 = A_arbace_c_build__init_part0_A_const_pool.A[152]; A_arbace_c_build__init_part0_A_const_103 = A_arbace_c_build__init_part0_A_const_pool.A[153]; A_arbace_c_build__init_part0_A_const_104 = A_arbace_c_build__init_part0_A_const_pool.A[154]; A_arbace_c_build__init_part0_A_const_105 = A_arbace_c_build__init_part0_A_const_pool.A[155] }

func A_arbace_c_build__init_part0_A_clinit_p8() { A_arbace_c_build__init_part0_A_const_106 = A_arbace_c_build__init_part0_A_const_pool.A[156]; A_arbace_c_build__init_part0_A_const_107 = A_arbace_c_build__init_part0_A_const_pool.A[157]; A_arbace_c_build__init_part0_A_const_108 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[158]); A_arbace_c_build__init_part0_A_const_109 = A_arbace_c_build__init_part0_A_const_pool.A[159]; A_arbace_c_build__init_part0_A_const_110 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[160]); A_arbace_c_build__init_part0_A_const_111 = A_arbace_c_build__init_part0_A_const_pool.A[161]; A_arbace_c_build__init_part0_A_const_112 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[162]); A_arbace_c_build__init_part0_A_const_113 = A_arbace_c_build__init_part0_A_const_pool.A[163]; A_arbace_c_build__init_part0_A_const_114 = A_arbace_c_build__init_part0_A_const_pool.A[164]; A_arbace_c_build__init_part0_A_const_115 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[165]); A_arbace_c_build__init_part0_A_const_116 = A_arbace_c_build__init_part0_A_const_pool.A[166]; A_arbace_c_build__init_part0_A_const_117 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[167]); A_arbace_c_build__init_part0_A_const_118 = A_arbace_c_build__init_part0_A_const_pool.A[168]; A_arbace_c_build__init_part0_A_const_119 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[169]) }

func A_arbace_c_build__init_part0_A_clinit_p9() { A_arbace_c_build__init_part0_A_const_120 = A_arbace_c_build__init_part0_A_const_pool.A[170]; A_arbace_c_build__init_part0_A_const_121 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[171]); A_arbace_c_build__init_part0_A_const_122 = A_arbace_c_build__init_part0_A_const_pool.A[172]; A_arbace_c_build__init_part0_A_const_123 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[173]); A_arbace_c_build__init_part0_A_const_124 = A_arbace_c_build__init_part0_A_const_pool.A[174]; A_arbace_c_build__init_part0_A_const_125 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[175]); A_arbace_c_build__init_part0_A_const_126 = A_arbace_c_build__init_part0_A_const_pool.A[176]; A_arbace_c_build__init_part0_A_const_127 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[177]); A_arbace_c_build__init_part0_A_const_128 = A_arbace_c_build__init_part0_A_const_pool.A[178]; A_arbace_c_build__init_part0_A_const_129 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[179]); A_arbace_c_build__init_part0_A_const_130 = A_arbace_c_build__init_part0_A_const_pool.A[180]; A_arbace_c_build__init_part0_A_const_131 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[181]); A_arbace_c_build__init_part0_A_const_132 = A_arbace_c_build__init_part0_A_const_pool.A[182] }

func A_arbace_c_build__init_part0_A_clinit_p10() { A_arbace_c_build__init_part0_A_const_133 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[183]); A_arbace_c_build__init_part0_A_const_134 = A_arbace_c_build__init_part0_A_const_pool.A[184]; A_arbace_c_build__init_part0_A_const_135 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[185]); A_arbace_c_build__init_part0_A_const_136 = A_arbace_c_build__init_part0_A_const_pool.A[186]; A_arbace_c_build__init_part0_A_const_137 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[187]); A_arbace_c_build__init_part0_A_const_138 = A_arbace_c_build__init_part0_A_const_pool.A[188]; A_arbace_c_build__init_part0_A_const_139 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[189]); A_arbace_c_build__init_part0_A_const_140 = A_arbace_c_build__init_part0_A_const_pool.A[190]; A_arbace_c_build__init_part0_A_const_141 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[191]); A_arbace_c_build__init_part0_A_const_142 = A_arbace_c_build__init_part0_A_const_pool.A[192]; A_arbace_c_build__init_part0_A_const_143 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[193]); A_arbace_c_build__init_part0_A_const_144 = A_arbace_c_build__init_part0_A_const_pool.A[194]; A_arbace_c_build__init_part0_A_const_145 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[195]) }

func A_arbace_c_build__init_part0_A_clinit_p11() { A_arbace_c_build__init_part0_A_const_146 = A_arbace_c_build__init_part0_A_const_pool.A[196]; A_arbace_c_build__init_part0_A_const_147 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[197]); A_arbace_c_build__init_part0_A_const_148 = A_arbace_c_build__init_part0_A_const_pool.A[198]; A_arbace_c_build__init_part0_A_const_149 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[199]); A_arbace_c_build__init_part0_A_const_150 = A_arbace_c_build__init_part0_A_const_pool.A[200]; A_arbace_c_build__init_part0_A_const_151 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[201]); A_arbace_c_build__init_part0_A_const_152 = A_arbace_c_build__init_part0_A_const_pool.A[202]; A_arbace_c_build__init_part0_A_const_153 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[203]); A_arbace_c_build__init_part0_A_const_154 = A_arbace_c_build__init_part0_A_const_pool.A[204]; A_arbace_c_build__init_part0_A_const_155 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[205]); A_arbace_c_build__init_part0_A_const_156 = A_arbace_c_build__init_part0_A_const_pool.A[206]; A_arbace_c_build__init_part0_A_const_157 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[207]); A_arbace_c_build__init_part0_A_const_158 = A_arbace_c_build__init_part0_A_const_pool.A[208] }

func A_arbace_c_build__init_part0_A_clinit_p12() { A_arbace_c_build__init_part0_A_const_159 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[209]); A_arbace_c_build__init_part0_A_const_160 = A_arbace_c_build__init_part0_A_const_pool.A[210]; A_arbace_c_build__init_part0_A_const_161 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[211]); A_arbace_c_build__init_part0_A_const_162 = A_arbace_c_build__init_part0_A_const_pool.A[212]; A_arbace_c_build__init_part0_A_const_163 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[213]); A_arbace_c_build__init_part0_A_const_164 = A_arbace_c_build__init_part0_A_const_pool.A[214]; A_arbace_c_build__init_part0_A_const_165 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[215]); A_arbace_c_build__init_part0_A_const_166 = A_arbace_c_build__init_part0_A_const_pool.A[216]; A_arbace_c_build__init_part0_A_const_167 = A_arbace_c_build__init_part0_A_const_pool.A[217]; A_arbace_c_build__init_part0_A_const_168 = A_arbace_c_build__init_part0_A_const_pool.A[218]; A_arbace_c_build__init_part0_A_const_169 = A_arbace_c_build__init_part0_A_const_pool.A[219]; A_arbace_c_build__init_part0_A_const_170 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[220]); A_arbace_c_build__init_part0_A_const_171 = A_arbace_c_build__init_part0_A_const_pool.A[221]; A_arbace_c_build__init_part0_A_const_172 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[222]) }

func A_arbace_c_build__init_part0_A_clinit_p13() { A_arbace_c_build__init_part0_A_const_173 = A_arbace_c_build__init_part0_A_const_pool.A[223]; A_arbace_c_build__init_part0_A_const_174 = lang.Var_Cast(A_arbace_c_build__init_part0_A_const_pool.A[224]); A_arbace_c_build__init_part0_A_const_175 = A_arbace_c_build__init_part0_A_const_pool.A[225] }

func A_arbace_c_build__init_part0_A_New() *A_arbace_c_build__init_part0_A { A_arbace_c_build__init_part0_A_Init(); t := &A_arbace_c_build__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_c_build__init_part0_A) Ctor() {}

func (t *A_arbace_c_build__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_build__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_c_build__init_part0_A_class }

func (t *A_arbace_c_build__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_build__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_build__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_build__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_build__init_part0_A); return ok }

func A_arbace_c_build__init_part0_A_Cast(x any) *A_arbace_c_build__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_build__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_build__init_part0_A_class)) }; return v }



type A_arbace_c_build__init_part1_A struct{ jrt.Object }

var A_arbace_c_build__init_part1_A_const_pool *jrt.RefArray

var A_arbace_c_build__init_part1_A_const_0 *lang.Var

var A_arbace_c_build__init_part1_A_const_1 any

var A_arbace_c_build__init_part1_A_const_2 *lang.Var

var A_arbace_c_build__init_part1_A_const_3 any

var A_arbace_c_build__init_part1_A_const_4 *lang.Var

var A_arbace_c_build__init_part1_A_const_5 any

var A_arbace_c_build__init_part1_A_const_6 *lang.Var

var A_arbace_c_build__init_part1_A_const_7 any

var A_arbace_c_build__init_part1_A_const_8 *lang.Var

var A_arbace_c_build__init_part1_A_const_9 any

var A_arbace_c_build__init_part1_A_const_10 *lang.Var

var A_arbace_c_build__init_part1_A_const_11 any

var A_arbace_c_build__init_part1_A_const_12 *lang.Var

var A_arbace_c_build__init_part1_A_const_13 any

var A_arbace_c_build__init_part1_A_const_14 *lang.Var

var A_arbace_c_build__init_part1_A_const_15 any

var A_arbace_c_build__init_part1_A_const_16 *lang.Var

var A_arbace_c_build__init_part1_A_const_17 any

var A_arbace_c_build__init_part1_A_const_18 *lang.Var

var A_arbace_c_build__init_part1_A_const_19 any

var A_arbace_c_build__init_part1_A_const_20 *lang.Var

var A_arbace_c_build__init_part1_A_const_21 any

var A_arbace_c_build__init_part1_A_const_22 *lang.Var

var A_arbace_c_build__init_part1_A_const_23 any

var A_arbace_c_build__init_part1_A_const_24 *lang.Var

var A_arbace_c_build__init_part1_A_const_25 any

var A_arbace_c_build__init_part1_A_const_26 *lang.Var

var A_arbace_c_build__init_part1_A_const_27 any

var A_arbace_c_build__init_part1_A_const_28 *lang.Var

var A_arbace_c_build__init_part1_A_const_29 any

var A_arbace_c_build__init_part1_A_const_30 *lang.Var

var A_arbace_c_build__init_part1_A_const_31 any

var A_arbace_c_build__init_part1_A_const_32 *lang.Var

var A_arbace_c_build__init_part1_A_const_33 any

var A_arbace_c_build__init_part1_A_const_34 any

var A_arbace_c_build__init_part1_A_const_35 *lang.Var

var A_arbace_c_build__init_part1_A_const_36 any

var A_arbace_c_build__init_part1_A_const_37 any

var A_arbace_c_build__init_part1_A_const_38 *lang.Var

var A_arbace_c_build__init_part1_A_const_39 any

var A_arbace_c_build__init_part1_A_const_40 *lang.Var

var A_arbace_c_build__init_part1_A_const_41 any

var A_arbace_c_build__init_part1_A_const_42 *lang.Var

var A_arbace_c_build__init_part1_A_const_43 any

var A_arbace_c_build__init_part1_A_const_44 *lang.Var

var A_arbace_c_build__init_part1_A_const_45 any

var A_arbace_c_build__init_part1_A_const_46 *lang.Var

var A_arbace_c_build__init_part1_A_const_47 any

var A_arbace_c_build__init_part1_A_const_48 any

var A_arbace_c_build__init_part1_A_const_49 *lang.Var

var A_arbace_c_build__init_part1_A_const_50 any

var A_arbace_c_build__init_part1_A_const_51 *lang.Var

var A_arbace_c_build__init_part1_A_const_52 any

var A_arbace_c_build__init_part1_A_const_53 *lang.Var

var A_arbace_c_build__init_part1_A_const_54 any

var A_arbace_c_build__init_part1_A_const_55 *lang.Var

var A_arbace_c_build__init_part1_A_const_56 any

var A_arbace_c_build__init_part1_A_const_57 *lang.Var

var A_arbace_c_build__init_part1_A_const_58 any

var A_arbace_c_build__init_part1_A_const_59 *lang.Var

var A_arbace_c_build__init_part1_A_const_60 any

var A_arbace_c_build__init_part1_A_const_61 *lang.Var

var A_arbace_c_build__init_part1_A_const_62 any

var A_arbace_c_build__init_part1_A_const_63 *lang.Var

var A_arbace_c_build__init_part1_A_const_64 any

var A_arbace_c_build__init_part1_A_const_65 *lang.Var

var A_arbace_c_build__init_part1_A_const_66 any

var A_arbace_c_build__init_part1_A_const_67 *lang.Var

var A_arbace_c_build__init_part1_A_const_68 any

var A_arbace_c_build__init_part1_A_const_69 *lang.Var

var A_arbace_c_build__init_part1_A_const_70 any

var A_arbace_c_build__init_part1_A_const_71 *lang.Var

var A_arbace_c_build__init_part1_A_const_72 any

var A_arbace_c_build__init_part1_A_const_73 any

var A_arbace_c_build__init_part1_A_const_74 *lang.Var

var A_arbace_c_build__init_part1_A_const_75 any

var A_arbace_c_build__init_part1_A_const_76 *lang.Var

var A_arbace_c_build__init_part1_A_const_77 any

var A_arbace_c_build__init_part1_A_const_78 *lang.Var

var A_arbace_c_build__init_part1_A_const_79 any

var A_arbace_c_build__init_part1_A_const_80 *lang.Var

var A_arbace_c_build__init_part1_A_const_81 any

var A_arbace_c_build__init_part1_A_const_82 *lang.Var

var A_arbace_c_build__init_part1_A_const_83 any

var A_arbace_c_build__init_part1_A_const_84 *lang.Var

var A_arbace_c_build__init_part1_A_const_85 any

var A_arbace_c_build__init_part1_A_const_86 any

var A_arbace_c_build__init_part1_A_const_87 *lang.Var

var A_arbace_c_build__init_part1_A_const_88 any

var A_arbace_c_build__init_part1_A_const_89 *lang.Var

var A_arbace_c_build__init_part1_A_const_90 any

var A_arbace_c_build__init_part1_A_const_91 *lang.Var

var A_arbace_c_build__init_part1_A_const_92 any

var A_arbace_c_build__init_part1_A_const_93 *lang.Var

var A_arbace_c_build__init_part1_A_const_94 any

var A_arbace_c_build__init_part1_A_const_95 *lang.Var

var A_arbace_c_build__init_part1_A_const_96 any

var A_arbace_c_build__init_part1_A_const_97 *lang.Var

var A_arbace_c_build__init_part1_A_const_98 any

var A_arbace_c_build__init_part1_A_const_99 *lang.Var

var A_arbace_c_build__init_part1_A_const_100 any

var A_arbace_c_build__init_part1_A_const_101 *lang.Var

var A_arbace_c_build__init_part1_A_const_102 any

var A_arbace_c_build__init_part1_A_const_103 *lang.Var

var A_arbace_c_build__init_part1_A_const_104 any

var A_arbace_c_build__init_part1_A_const_105 any

var A_arbace_c_build__init_part1_A_const_106 *lang.Var

var A_arbace_c_build__init_part1_A_const_107 any

var A_arbace_c_build__init_part1_A_const_108 *lang.Var

var A_arbace_c_build__init_part1_A_const_109 any

var A_arbace_c_build__init_part1_A_const_110 *lang.Var

var A_arbace_c_build__init_part1_A_const_111 any

var A_arbace_c_build__init_part1_A_const_112 *lang.Var

var A_arbace_c_build__init_part1_A_const_113 any

var A_arbace_c_build__init_part1_A_const_114 *lang.Var

var A_arbace_c_build__init_part1_A_const_115 any

var A_arbace_c_build__init_part1_A_const_116 *lang.Var

var A_arbace_c_build__init_part1_A_const_117 any

var A_arbace_c_build__init_part1_A_const_118 *lang.Var

var A_arbace_c_build__init_part1_A_const_119 any

var A_arbace_c_build__init_part1_A_const_120 any

var A_arbace_c_build__init_part1_A_const_121 *lang.Var

var A_arbace_c_build__init_part1_A_const_122 any

var A_arbace_c_build__init_part1_A_const_123 *lang.Var

var A_arbace_c_build__init_part1_A_const_124 any

var A_arbace_c_build__init_part1_A_const_125 *lang.Var

var A_arbace_c_build__init_part1_A_const_126 any

var A_arbace_c_build__init_part1_A_const_127 *lang.Var

var A_arbace_c_build__init_part1_A_const_128 any

var A_arbace_c_build__init_part1_A_const_129 *lang.Var

var A_arbace_c_build__init_part1_A_const_130 any

var A_arbace_c_build__init_part1_A_const_131 *lang.Var

var A_arbace_c_build__init_part1_A_const_132 any

var A_arbace_c_build__init_part1_A_const_133 *lang.Var

var A_arbace_c_build__init_part1_A_const_134 any

var A_arbace_c_build__init_part1_A_const_135 *lang.Var

var A_arbace_c_build__init_part1_A_const_136 any

var A_arbace_c_build__init_part1_A_const_137 *lang.Var

var A_arbace_c_build__init_part1_A_const_138 any

var A_arbace_c_build__init_part1_A_init jrt.ClassInit

func A_arbace_c_build__init_part1_A_Init() { if !A_arbace_c_build__init_part1_A_init.Done() { A_arbace_c_build__init_part1_A_init.Run(A_arbace_c_build__init_part1_A_clinit) } }

func A_arbace_c_build__init_part1_A_clinit() { A_arbace_c_build__init_part1_A_clinit_p0(); A_arbace_c_build__init_part1_A_clinit_p1() }

func A_arbace_c_build__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_build__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_308, 187); A_arbace_c_build__init_part1_A_const_0 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[59]); A_arbace_c_build__init_part1_A_const_1 = A_arbace_c_build__init_part1_A_const_pool.A[60]; A_arbace_c_build__init_part1_A_const_2 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[61]); A_arbace_c_build__init_part1_A_const_3 = A_arbace_c_build__init_part1_A_const_pool.A[62]; A_arbace_c_build__init_part1_A_const_4 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[63]); A_arbace_c_build__init_part1_A_const_5 = A_arbace_c_build__init_part1_A_const_pool.A[64] }

func A_arbace_c_build__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp1 = A_arbace_c_build__init_part0_A_const_147; A_arbace_c_build__init_part1_A_const_6 = tmp1; A_arbace_c_build__init_part1_A_const_7 = A_arbace_c_build__init_part1_A_const_pool.A[65]; var tmp2 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp2 = A_arbace_c_build__init_part0_A_const_135; A_arbace_c_build__init_part1_A_const_8 = tmp2; A_arbace_c_build__init_part1_A_const_9 = A_arbace_c_build__init_part1_A_const_pool.A[66]; var tmp3 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp3 = A_arbace_c_build__init_part0_A_const_16; A_arbace_c_build__init_part1_A_const_10 = tmp3; A_arbace_c_build__init_part1_A_const_11 = A_arbace_c_build__init_part1_A_const_pool.A[67]; A_arbace_c_build__init_part1_A_const_12 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[68]); A_arbace_c_build__init_part1_A_const_13 = A_arbace_c_build__init_part1_A_const_pool.A[69]; A_arbace_c_build__init_part1_A_const_14 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[70]); A_arbace_c_build__init_part1_A_const_15 = A_arbace_c_build__init_part1_A_const_pool.A[71]; A_arbace_c_build__init_part1_A_const_16 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[72]); A_arbace_c_build__init_part1_A_const_17 = A_arbace_c_build__init_part1_A_const_pool.A[73]; A_arbace_c_build__init_part1_A_const_18 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[74]); A_arbace_c_build__init_part1_A_const_19 = A_arbace_c_build__init_part1_A_const_pool.A[75]; A_arbace_c_build__init_part1_A_const_20 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[76]); A_arbace_c_build__init_part1_A_const_21 = A_arbace_c_build__init_part1_A_const_pool.A[77]; var tmp4 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp4 = A_arbace_c_build__init_part0_A_const_20; A_arbace_c_build__init_part1_A_const_22 = tmp4; A_arbace_c_build__init_part1_A_const_23 = A_arbace_c_build__init_part1_A_const_pool.A[78]; A_arbace_c_build__init_part1_A_const_24 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[79]); A_arbace_c_build__init_part1_A_const_25 = A_arbace_c_build__init_part1_A_const_pool.A[80]; A_arbace_c_build__init_part1_A_const_26 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[81]); A_arbace_c_build__init_part1_A_const_27 = A_arbace_c_build__init_part1_A_const_pool.A[82]; A_arbace_c_build__init_part1_A_const_28 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[83]); A_arbace_c_build__init_part1_A_const_29 = A_arbace_c_build__init_part1_A_const_pool.A[84]; var tmp5 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp5 = A_arbace_c_build__init_part0_A_const_133; A_arbace_c_build__init_part1_A_const_30 = tmp5; A_arbace_c_build__init_part1_A_const_31 = A_arbace_c_build__init_part1_A_const_pool.A[85]; A_arbace_c_build__init_part1_A_const_32 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[86]); A_arbace_c_build__init_part1_A_const_33 = A_arbace_c_build__init_part1_A_const_pool.A[87]; A_arbace_c_build__init_part1_A_const_34 = A_arbace_c_build__init_part1_A_const_pool.A[88]; A_arbace_c_build__init_part1_A_const_35 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[89]); A_arbace_c_build__init_part1_A_const_36 = A_arbace_c_build__init_part1_A_const_pool.A[90]; A_arbace_c_build__init_part1_A_const_37 = A_arbace_c_build__init_part1_A_const_pool.A[91]; A_arbace_c_build__init_part1_A_const_38 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[92]); A_arbace_c_build__init_part1_A_const_39 = A_arbace_c_build__init_part1_A_const_pool.A[93]; A_arbace_c_build__init_part1_A_const_40 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[94]); A_arbace_c_build__init_part1_A_const_41 = A_arbace_c_build__init_part1_A_const_pool.A[95]; A_arbace_c_build__init_part1_A_const_42 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[96]); A_arbace_c_build__init_part1_A_const_43 = A_arbace_c_build__init_part1_A_const_pool.A[97]; var tmp6 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp6 = A_arbace_c_build__init_part0_A_const_149; A_arbace_c_build__init_part1_A_const_44 = tmp6; A_arbace_c_build__init_part1_A_const_45 = A_arbace_c_build__init_part1_A_const_pool.A[98]; A_arbace_c_build__init_part1_A_const_46 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[99]); A_arbace_c_build__init_part1_A_const_47 = A_arbace_c_build__init_part1_A_const_pool.A[100]; A_arbace_c_build__init_part1_A_const_48 = A_arbace_c_build__init_part1_A_const_pool.A[101]; A_arbace_c_build__init_part1_A_const_49 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[102]); A_arbace_c_build__init_part1_A_const_50 = A_arbace_c_build__init_part1_A_const_pool.A[103]; var tmp7 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp7 = A_arbace_c_build__init_part0_A_const_141; A_arbace_c_build__init_part1_A_const_51 = tmp7; A_arbace_c_build__init_part1_A_const_52 = A_arbace_c_build__init_part1_A_const_pool.A[104]; A_arbace_c_build__init_part1_A_const_53 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[105]); A_arbace_c_build__init_part1_A_const_54 = A_arbace_c_build__init_part1_A_const_pool.A[106]; A_arbace_c_build__init_part1_A_const_55 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[107]); A_arbace_c_build__init_part1_A_const_56 = A_arbace_c_build__init_part1_A_const_pool.A[108]; A_arbace_c_build__init_part1_A_const_57 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[109]); A_arbace_c_build__init_part1_A_const_58 = A_arbace_c_build__init_part1_A_const_pool.A[110]; A_arbace_c_build__init_part1_A_const_59 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[111]); A_arbace_c_build__init_part1_A_const_60 = A_arbace_c_build__init_part1_A_const_pool.A[112]; A_arbace_c_build__init_part1_A_const_61 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[113]); A_arbace_c_build__init_part1_A_const_62 = A_arbace_c_build__init_part1_A_const_pool.A[114]; A_arbace_c_build__init_part1_A_const_63 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[115]); A_arbace_c_build__init_part1_A_const_64 = A_arbace_c_build__init_part1_A_const_pool.A[116]; A_arbace_c_build__init_part1_A_const_65 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[117]); A_arbace_c_build__init_part1_A_const_66 = A_arbace_c_build__init_part1_A_const_pool.A[118]; A_arbace_c_build__init_part1_A_const_67 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[119]); A_arbace_c_build__init_part1_A_const_68 = A_arbace_c_build__init_part1_A_const_pool.A[120]; var tmp8 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp8 = A_arbace_c_build__init_part0_A_const_153; A_arbace_c_build__init_part1_A_const_69 = tmp8; A_arbace_c_build__init_part1_A_const_70 = A_arbace_c_build__init_part1_A_const_pool.A[121]; var tmp9 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp9 = A_arbace_c_build__init_part0_A_const_151; A_arbace_c_build__init_part1_A_const_71 = tmp9; A_arbace_c_build__init_part1_A_const_72 = A_arbace_c_build__init_part1_A_const_pool.A[122]; A_arbace_c_build__init_part1_A_const_73 = A_arbace_c_build__init_part1_A_const_pool.A[123]; var tmp10 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp10 = A_arbace_c_build__init_part0_A_const_139; A_arbace_c_build__init_part1_A_const_74 = tmp10; A_arbace_c_build__init_part1_A_const_75 = A_arbace_c_build__init_part1_A_const_pool.A[124]; A_arbace_c_build__init_part1_A_const_76 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[125]); A_arbace_c_build__init_part1_A_const_77 = A_arbace_c_build__init_part1_A_const_pool.A[126]; A_arbace_c_build__init_part1_A_const_78 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[127]); A_arbace_c_build__init_part1_A_const_79 = A_arbace_c_build__init_part1_A_const_pool.A[128]; A_arbace_c_build__init_part1_A_const_80 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[129]); A_arbace_c_build__init_part1_A_const_81 = A_arbace_c_build__init_part1_A_const_pool.A[130]; A_arbace_c_build__init_part1_A_const_82 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[131]); A_arbace_c_build__init_part1_A_const_83 = A_arbace_c_build__init_part1_A_const_pool.A[132]; A_arbace_c_build__init_part1_A_const_84 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[133]); A_arbace_c_build__init_part1_A_const_85 = A_arbace_c_build__init_part1_A_const_pool.A[134]; A_arbace_c_build__init_part1_A_const_86 = A_arbace_c_build__init_part1_A_const_pool.A[135]; A_arbace_c_build__init_part1_A_const_87 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[136]); A_arbace_c_build__init_part1_A_const_88 = A_arbace_c_build__init_part1_A_const_pool.A[137]; A_arbace_c_build__init_part1_A_const_89 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[138]); A_arbace_c_build__init_part1_A_const_90 = A_arbace_c_build__init_part1_A_const_pool.A[139]; A_arbace_c_build__init_part1_A_const_91 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[140]); A_arbace_c_build__init_part1_A_const_92 = A_arbace_c_build__init_part1_A_const_pool.A[141]; A_arbace_c_build__init_part1_A_const_93 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[142]); A_arbace_c_build__init_part1_A_const_94 = A_arbace_c_build__init_part1_A_const_pool.A[143]; A_arbace_c_build__init_part1_A_const_95 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[144]); A_arbace_c_build__init_part1_A_const_96 = A_arbace_c_build__init_part1_A_const_pool.A[145]; A_arbace_c_build__init_part1_A_const_97 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[146]); A_arbace_c_build__init_part1_A_const_98 = A_arbace_c_build__init_part1_A_const_pool.A[147]; A_arbace_c_build__init_part1_A_const_99 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[148]); A_arbace_c_build__init_part1_A_const_100 = A_arbace_c_build__init_part1_A_const_pool.A[149]; A_arbace_c_build__init_part1_A_const_101 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[150]); A_arbace_c_build__init_part1_A_const_102 = A_arbace_c_build__init_part1_A_const_pool.A[151]; A_arbace_c_build__init_part1_A_const_103 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[152]); A_arbace_c_build__init_part1_A_const_104 = A_arbace_c_build__init_part1_A_const_pool.A[153]; A_arbace_c_build__init_part1_A_const_105 = A_arbace_c_build__init_part1_A_const_pool.A[154]; A_arbace_c_build__init_part1_A_const_106 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[155]); A_arbace_c_build__init_part1_A_const_107 = A_arbace_c_build__init_part1_A_const_pool.A[156]; A_arbace_c_build__init_part1_A_const_108 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[157]); A_arbace_c_build__init_part1_A_const_109 = A_arbace_c_build__init_part1_A_const_pool.A[158]; A_arbace_c_build__init_part1_A_const_110 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[159]); A_arbace_c_build__init_part1_A_const_111 = A_arbace_c_build__init_part1_A_const_pool.A[160]; var tmp11 *lang.Var; A_arbace_c_build__init_part0_A_Init(); tmp11 = A_arbace_c_build__init_part0_A_const_137; A_arbace_c_build__init_part1_A_const_112 = tmp11; A_arbace_c_build__init_part1_A_const_113 = A_arbace_c_build__init_part1_A_const_pool.A[161]; A_arbace_c_build__init_part1_A_const_114 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[162]); A_arbace_c_build__init_part1_A_const_115 = A_arbace_c_build__init_part1_A_const_pool.A[163]; A_arbace_c_build__init_part1_A_const_116 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[164]); A_arbace_c_build__init_part1_A_const_117 = A_arbace_c_build__init_part1_A_const_pool.A[165]; A_arbace_c_build__init_part1_A_const_118 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[166]); A_arbace_c_build__init_part1_A_const_119 = A_arbace_c_build__init_part1_A_const_pool.A[167]; A_arbace_c_build__init_part1_A_const_120 = A_arbace_c_build__init_part1_A_const_pool.A[168]; A_arbace_c_build__init_part1_A_const_121 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[169]); A_arbace_c_build__init_part1_A_const_122 = A_arbace_c_build__init_part1_A_const_pool.A[170]; A_arbace_c_build__init_part1_A_const_123 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[171]); A_arbace_c_build__init_part1_A_const_124 = A_arbace_c_build__init_part1_A_const_pool.A[172]; A_arbace_c_build__init_part1_A_const_125 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[173]); A_arbace_c_build__init_part1_A_const_126 = A_arbace_c_build__init_part1_A_const_pool.A[174]; A_arbace_c_build__init_part1_A_const_127 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[175]); A_arbace_c_build__init_part1_A_const_128 = A_arbace_c_build__init_part1_A_const_pool.A[176]; A_arbace_c_build__init_part1_A_const_129 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[177]); A_arbace_c_build__init_part1_A_const_130 = A_arbace_c_build__init_part1_A_const_pool.A[178]; A_arbace_c_build__init_part1_A_const_131 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[179]); A_arbace_c_build__init_part1_A_const_132 = A_arbace_c_build__init_part1_A_const_pool.A[180]; A_arbace_c_build__init_part1_A_const_133 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[181]); A_arbace_c_build__init_part1_A_const_134 = A_arbace_c_build__init_part1_A_const_pool.A[182]; A_arbace_c_build__init_part1_A_const_135 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[183]); A_arbace_c_build__init_part1_A_const_136 = A_arbace_c_build__init_part1_A_const_pool.A[184]; A_arbace_c_build__init_part1_A_const_137 = lang.Var_Cast(A_arbace_c_build__init_part1_A_const_pool.A[185]); A_arbace_c_build__init_part1_A_const_138 = A_arbace_c_build__init_part1_A_const_pool.A[186] }

func A_arbace_c_build__init_part1_A_New() *A_arbace_c_build__init_part1_A { A_arbace_c_build__init_part1_A_Init(); t := &A_arbace_c_build__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_c_build__init_part1_A) Ctor() {}

func (t *A_arbace_c_build__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_build__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_c_build__init_part1_A_class }

func (t *A_arbace_c_build__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_build__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_build__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_build__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_build__init_part1_A); return ok }

func A_arbace_c_build__init_part1_A_Cast(x any) *A_arbace_c_build__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_build__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_build__init_part1_A_class)) }; return v }
