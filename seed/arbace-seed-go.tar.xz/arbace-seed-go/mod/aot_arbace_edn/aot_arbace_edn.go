//line aot_arbace_edn.ae:1
package aot_arbace_edn

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_New() *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A { A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_Init(); t := &A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_edn_A_Init(); tmp4 = A_arbace_edn_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_edn_A_Init(); tmp6 = A_arbace_edn_A_const_1; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_edn_A_Init(); tmp8 = A_arbace_edn_A_const_2; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_edn_A_Init(); tmp10 = A_arbace_edn_A_const_3; tmp3 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp11 != nil { panic(tmp11) }; return tmp3 }
//line :9:1
func A_arbace_edn_eval1345000008_fn__1345000009_A_New() *A_arbace_edn_eval1345000008_fn__1345000009_A { A_arbace_edn_eval1345000008_fn__1345000009_A_Init(); t := &A_arbace_edn_eval1345000008_fn__1345000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_edn_A_Init(); tmp1 = A_arbace_edn_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_edn_A_Init(); tmp3 = A_arbace_edn_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_edn_A_Init(); tmp5 = A_arbace_edn_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_edn_A_Init(); tmp7 = A_arbace_edn_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_edn_A_Init(); tmp9 = A_arbace_edn_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




func A_arbace_edn_read_A_New() *A_arbace_edn_read_A { A_arbace_edn_read_A_Init(); t := &A_arbace_edn_read_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_edn_read_A) Ctor() {}
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O_O__O(self, opts__0, stream__1 any) any {




















	return lang.EdnReader_Read_PushbackReader_IPersistentMap__O(jrt.PushbackReader_Cast(stream__1), lang.IPersistentMap_Cast(opts__0)) }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O__O(self, stream__0 any) any {


















	var tmp1 *lang.Var; A_arbace_edn_A_Init(); tmp1 = A_arbace_edn_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O__O(tmp3.Ref(), stream__0) }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O__O(self any) any {
















	var tmp1 *lang.Var; A_arbace_edn_A_Init(); tmp1 = A_arbace_edn_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_edn_A_Init(); tmp3 = A_arbace_edn_A_const_10; return tmp2.Invoke_O__O(jrt.NN(tmp3).Get__O())
}




func A_arbace_edn_read_string_A_New() *A_arbace_edn_read_string_A { A_arbace_edn_read_string_A_Init(); t := &A_arbace_edn_read_string_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_edn_read_string_A) Ctor() {}
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O_O__O(self, opts__0, s__1 any) any {








	if jrt.A2g_Truth(s__1) { return lang.EdnReader_ReadString_String_IPersistentMap__O(jrt.String_Cast(s__1), lang.IPersistentMap_Cast(opts__0)) } else { return nil } }
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O__O(self, s__0 any) any {







	var tmp1 *lang.Var; A_arbace_edn_A_Init(); tmp1 = A_arbace_edn_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_edn_A_Init(); tmp3 = A_arbace_edn_A_const_12; return tmp2.Invoke_O_O__O(tmp3, s__0)
}
type A_arbace_edn_A struct{ jrt.Object }

var A_arbace_edn_A_const_0 *lang.Var

var A_arbace_edn_A_const_1 any

var A_arbace_edn_A_const_2 *lang.Keyword

var A_arbace_edn_A_const_3 any

var A_arbace_edn_A_const_4 *lang.Var

var A_arbace_edn_A_const_5 *lang.Var

var A_arbace_edn_A_const_6 *lang.Var

var A_arbace_edn_A_const_7 any

var A_arbace_edn_A_const_8 *lang.Var

var A_arbace_edn_A_const_9 *lang.Var

var A_arbace_edn_A_const_10 *lang.Var

var A_arbace_edn_A_const_11 *lang.Var

var A_arbace_edn_A_const_12 any

var A_arbace_edn_A_init jrt.ClassInit

func A_arbace_edn_A_Init() { if !A_arbace_edn_A_init.Done() { A_arbace_edn_A_init.Run(A_arbace_edn_A_clinit) } }

func A_arbace_edn_A_clinit() { A_arbace_edn_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_edn_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_edn_A_const_2 = lang.RT_Keyword_String_String__Keyword(nil, Lit_2); A_arbace_edn_A_const_3 = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref()); A_arbace_edn_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_edn_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_edn_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_edn_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12))); A_arbace_edn_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_edn_A_const_9 = lang.RT_Var_String_String__Var(Lit_8, Lit_3); A_arbace_edn_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_edn_A_const_11 = lang.RT_Var_String_String__Var(Lit_8, Lit_4); A_arbace_edn_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), nil)) }

func A_arbace_edn_A_New() *A_arbace_edn_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_A) Ctor() {}

func (t *A_arbace_edn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_A) GetClass__Class() *jrt.Class { return A_arbace_edn_A_class }

func (t *A_arbace_edn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_A); return ok }

func A_arbace_edn_A_Cast(x any) *A_arbace_edn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_A_class)) }; return v }



type A_arbace_edn_eval1345000004_A struct{ jrt.Object }

func A_arbace_edn_eval1345000004_A_New() *A_arbace_edn_eval1345000004_A { t := &A_arbace_edn_eval1345000004_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000004_A) Ctor() {}

func (t *A_arbace_edn_eval1345000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000004_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000004_A_class }

func (t *A_arbace_edn_eval1345000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000004_A); return ok }

func A_arbace_edn_eval1345000004_A_Cast(x any) *A_arbace_edn_eval1345000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000004_A_class)) }; return v }



type A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A struct{ jrt.Object }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Is_Compiler_AOTF0() {}

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_fn_class *jrt.Class

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_init jrt.ClassInit

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_Init() { if !A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_init.Done() { A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_init.Run(A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_clinit) } }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_clinit() { A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_16, lang.Compiler_AOTFn_class) }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A); return ok }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_Cast(x any) *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class)) }; return v }



type A_arbace_edn_eval1345000008_A struct{ jrt.Object }

func A_arbace_edn_eval1345000008_A_New() *A_arbace_edn_eval1345000008_A { t := &A_arbace_edn_eval1345000008_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000008_A) Ctor() {}

func (t *A_arbace_edn_eval1345000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000008_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000008_A_class }

func (t *A_arbace_edn_eval1345000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000008_A); return ok }

func A_arbace_edn_eval1345000008_A_Cast(x any) *A_arbace_edn_eval1345000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000008_A_class)) }; return v }



type A_arbace_edn_eval1345000008_fn__1345000009_A struct{ jrt.Object }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Is_Compiler_AOTF0() {}

var A_arbace_edn_eval1345000008_fn__1345000009_A_fn_class *jrt.Class

var A_arbace_edn_eval1345000008_fn__1345000009_A_init jrt.ClassInit

func A_arbace_edn_eval1345000008_fn__1345000009_A_Init() { if !A_arbace_edn_eval1345000008_fn__1345000009_A_init.Done() { A_arbace_edn_eval1345000008_fn__1345000009_A_init.Run(A_arbace_edn_eval1345000008_fn__1345000009_A_clinit) } }

func A_arbace_edn_eval1345000008_fn__1345000009_A_clinit() { A_arbace_edn_eval1345000008_fn__1345000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_17, lang.Compiler_AOTFn_class) }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000008_fn__1345000009_A_class }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000008_fn__1345000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000008_fn__1345000009_A); return ok }

func A_arbace_edn_eval1345000008_fn__1345000009_A_Cast(x any) *A_arbace_edn_eval1345000008_fn__1345000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000008_fn__1345000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000008_fn__1345000009_A_class)) }; return v }



type A_arbace_edn_read_A struct{ jrt.Object }

func (t *A_arbace_edn_read_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_edn_read_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_edn_read_A) Is_Compiler_AOTF0() {}

var A_arbace_edn_read_A_fn_class *jrt.Class

var A_arbace_edn_read_A_init jrt.ClassInit

func A_arbace_edn_read_A_Init() { if !A_arbace_edn_read_A_init.Done() { A_arbace_edn_read_A_init.Run(A_arbace_edn_read_A_clinit) } }

func A_arbace_edn_read_A_clinit() { A_arbace_edn_read_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_18, lang.Compiler_AOTFn_class) }

func (t *A_arbace_edn_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_read_A) GetClass__Class() *jrt.Class { return A_arbace_edn_read_A_class }

func (t *A_arbace_edn_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_read_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_read_A); return ok }

func A_arbace_edn_read_A_Cast(x any) *A_arbace_edn_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_read_A_class)) }; return v }



type A_arbace_edn_read_string_A struct{ jrt.Object }

func (t *A_arbace_edn_read_string_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_edn_read_string_A) Is_Compiler_AOTF1() {}

var A_arbace_edn_read_string_A_fn_class *jrt.Class

var A_arbace_edn_read_string_A_init jrt.ClassInit

func A_arbace_edn_read_string_A_Init() { if !A_arbace_edn_read_string_A_init.Done() { A_arbace_edn_read_string_A_init.Run(A_arbace_edn_read_string_A_clinit) } }

func A_arbace_edn_read_string_A_clinit() { A_arbace_edn_read_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_19, lang.Compiler_AOTFn_class) }

func (t *A_arbace_edn_read_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_read_string_A) GetClass__Class() *jrt.Class { return A_arbace_edn_read_string_A_class }

func (t *A_arbace_edn_read_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_read_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_read_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_read_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_read_string_A); return ok }

func A_arbace_edn_read_string_A_Cast(x any) *A_arbace_edn_read_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_read_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_read_string_A_class)) }; return v }
