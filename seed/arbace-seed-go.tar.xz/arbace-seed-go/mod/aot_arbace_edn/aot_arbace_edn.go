//line aot_arbace_edn.ae:1
package aot_arbace_edn

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_New() *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_edn_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_edn_A_const_1, A_arbace_edn_A_const_2, A_arbace_edn_A_const_3); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :9:1
func A_arbace_edn_eval1345000008_fn__1345000009_A_New() *A_arbace_edn_eval1345000008_fn__1345000009_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_eval1345000008_fn__1345000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_edn_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_edn_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_edn_A_const_8), A_arbace_edn_A_const_6.GetRawRoot__O(), A_arbace_edn_A_const_7) }




func A_arbace_edn_read_A_New() *A_arbace_edn_read_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_read_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_edn_read_A) Ctor() {}
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O_O__O(self, opts__0, stream__1 any) any {




















	return lang.EdnReader_Read_PushbackReader_IPersistentMap__O(jrt.PushbackReader_Cast(stream__1), lang.IPersistentMap_Cast(opts__0)) }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O__O(self, stream__0 any) any {


















	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_edn_A_const_9.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O__O(tmp2.Ref(), stream__0) }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O__O(self any) any {
















	return lang.IFn_Cast(A_arbace_edn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_edn_A_const_10.Get__O())
}




func A_arbace_edn_read_string_A_New() *A_arbace_edn_read_string_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_read_string_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_edn_read_string_A) Ctor() {}
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O_O__O(self, opts__0, s__1 any) any {








	if jrt.A2g_Truth(s__1) { return lang.EdnReader_ReadString_String_IPersistentMap__O(jrt.String_Cast(s__1), lang.IPersistentMap_Cast(opts__0)) } else { return nil } }
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O__O(self, s__0 any) any {







	return lang.IFn_Cast(A_arbace_edn_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_edn_A_const_12, s__0)
}
type A_arbace_edn_A struct{ jrt.Object }

var A_arbace_edn_A_const_pool *jrt.RefArray

var A_arbace_edn_A_const_0 *lang.Var

var A_arbace_edn_A_const_1 any

var A_arbace_edn_A_const_2 *lang.Keyword

var A_arbace_edn_A_const_3 any

var A_arbace_edn_A_const_4 *lang.Var

var A_arbace_edn_A_const_5 *lang.Var

var A_arbace_edn_A_const_6 *lang.Var

var A_arbace_edn_A_const_7 any

var A_arbace_edn_A_const_8 *lang.Var

var A_arbace_edn_A_const_9 *lang.Var

var A_arbace_edn_A_const_10 *lang.Var

var A_arbace_edn_A_const_11 *lang.Var

var A_arbace_edn_A_const_12 any

var A_arbace_edn_A_init jrt.ClassInit

func A_arbace_edn_A_Init() { if !A_arbace_edn_A_init.Done() { A_arbace_edn_A_init.Run(A_arbace_edn_A_clinit) } }

func A_arbace_edn_A_clinit() { A_arbace_edn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 20); A_arbace_edn_A_const_0 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[7]); A_arbace_edn_A_const_1 = A_arbace_edn_A_const_pool.A[8]; A_arbace_edn_A_const_2 = lang.Keyword_Cast(A_arbace_edn_A_const_pool.A[9]); A_arbace_edn_A_const_3 = A_arbace_edn_A_const_pool.A[10]; A_arbace_edn_A_const_4 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[11]); A_arbace_edn_A_const_5 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[12]); A_arbace_edn_A_const_6 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[13]); A_arbace_edn_A_const_7 = A_arbace_edn_A_const_pool.A[14]; A_arbace_edn_A_const_8 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[15]); A_arbace_edn_A_const_9 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[16]); A_arbace_edn_A_const_10 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[17]); A_arbace_edn_A_const_11 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[18]); A_arbace_edn_A_const_12 = A_arbace_edn_A_const_pool.A[19] }

func A_arbace_edn_A_New() *A_arbace_edn_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_A) Ctor() {}

func (t *A_arbace_edn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_A) GetClass__Class() *jrt.Class { return A_arbace_edn_A_class }

func (t *A_arbace_edn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_A); return ok }

func A_arbace_edn_A_Cast(x any) *A_arbace_edn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_A_class)) }; return v }



type A_arbace_edn_eval1345000004_A struct{ jrt.Object }

func A_arbace_edn_eval1345000004_A_New() *A_arbace_edn_eval1345000004_A { t := &A_arbace_edn_eval1345000004_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000004_A) Ctor() {}

func (t *A_arbace_edn_eval1345000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000004_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000004_A_class }

func (t *A_arbace_edn_eval1345000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000004_A); return ok }

func A_arbace_edn_eval1345000004_A_Cast(x any) *A_arbace_edn_eval1345000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000004_A_class)) }; return v }



type A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A struct{ a2g_header uint64 }

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_fn_class *jrt.Class



type A_arbace_edn_eval1345000008_A struct{ jrt.Object }

func A_arbace_edn_eval1345000008_A_New() *A_arbace_edn_eval1345000008_A { t := &A_arbace_edn_eval1345000008_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000008_A) Ctor() {}

func (t *A_arbace_edn_eval1345000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000008_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000008_A_class }

func (t *A_arbace_edn_eval1345000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000008_A); return ok }

func A_arbace_edn_eval1345000008_A_Cast(x any) *A_arbace_edn_eval1345000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000008_A_class)) }; return v }



type A_arbace_edn_eval1345000008_fn__1345000009_A struct{ a2g_header uint64 }

var A_arbace_edn_eval1345000008_fn__1345000009_A_fn_class *jrt.Class



type A_arbace_edn_read_A struct{ a2g_header uint64 }

var A_arbace_edn_read_A_fn_class *jrt.Class



type A_arbace_edn_read_string_A struct{ a2g_header uint64 }

var A_arbace_edn_read_string_A_fn_class *jrt.Class
