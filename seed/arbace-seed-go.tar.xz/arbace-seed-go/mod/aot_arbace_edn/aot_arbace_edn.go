//line aot_arbace_edn.ae:1
package aot_arbace_edn

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_New() *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_edn_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_edn_A_const_1, A_arbace_edn_A_const_2, A_arbace_edn_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_edn_eval1345000008_fn__1345000009_A_New() *A_arbace_edn_eval1345000008_fn__1345000009_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_eval1345000008_fn__1345000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_edn_eval1345000008_fn__1345000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_edn_A_const_4.GetRawRoot__O()); var tmp2 any; var root_7 any = A_arbace_edn_A_const_5.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_edn_A_const_6; if linked_8 == nil { tmp2 = ifn_9.Invoke_O__O(arg_10) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_7, arg_10) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_edn_A_const_7.GetRawRoot__O(), A_arbace_edn_A_const_8) }




func A_arbace_edn_read_A_New() *A_arbace_edn_read_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_read_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_edn_read_A) Ctor() {}
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O_O__O(self, opts__0, stream__1 any) any {




















	return lang.EdnReader_Read_PushbackReader_IPersistentMap__O(jrt.PushbackReader_Cast(stream__1), lang.IPersistentMap_Cast(opts__0)) }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O_O__O(self, stream__0 any) any {


















	var root_17 any = A_arbace_edn_A_const_9.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, A_arbace_edn_read_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_21 any = stream__0; if linked_18 == nil { return ifn_19.Invoke_O_O__O(arg_20, arg_21) } else { return linked_18.(*A_arbace_edn_read_A).Invoke_O_O_O__O(root_17, arg_20, arg_21) } }
//line :14:1
func (t *A_arbace_edn_read_A) Invoke_O__O(self any) any {
















	var root_22 any = A_arbace_edn_A_const_9.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, A_arbace_edn_read_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_edn_A_const_10.Get__O(); if linked_23 == nil { return ifn_24.Invoke_O__O(arg_25) } else { return linked_23.(*A_arbace_edn_read_A).Invoke_O_O__O(root_22, arg_25)
	}
}



func A_arbace_edn_read_string_A_New() *A_arbace_edn_read_string_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_read_string_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_edn_read_string_A) Ctor() {}
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O_O__O(self, opts__0, s__1 any) any {








	if jrt.J2g_Truth(s__1) { return lang.EdnReader_ReadString_String_IPersistentMap__O(jrt.String_Cast(s__1), lang.IPersistentMap_Cast(opts__0)) } else { return nil } }
//line :37:1
func (t *A_arbace_edn_read_string_A) Invoke_O_O__O(self, s__0 any) any {







	var root_26 any = A_arbace_edn_A_const_11.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, A_arbace_edn_read_string_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_edn_A_const_12; var arg_30 any = s__0; if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*A_arbace_edn_read_string_A).Invoke_O_O_O__O(root_26, arg_29, arg_30)
	} }
type A_arbace_edn_A struct{ jrt.Object }

var A_arbace_edn_A_const_pool *jrt.RefArray

var A_arbace_edn_A_const_0 *lang.Var

var A_arbace_edn_A_const_1 any

var A_arbace_edn_A_const_2 *lang.Keyword

var A_arbace_edn_A_const_3 any

var A_arbace_edn_A_const_4 *lang.Var

var A_arbace_edn_A_const_5 *lang.Var

var A_arbace_edn_A_const_6 *lang.Var

var A_arbace_edn_A_const_7 *lang.Var

var A_arbace_edn_A_const_8 any

var A_arbace_edn_A_const_9 *lang.Var

var A_arbace_edn_A_const_10 *lang.Var

var A_arbace_edn_A_const_11 *lang.Var

var A_arbace_edn_A_const_12 any

var A_arbace_edn_A_init jrt.ClassInit

func A_arbace_edn_A_Init() { if !A_arbace_edn_A_init.Done() { A_arbace_edn_A_init.Run(A_arbace_edn_A_clinit) } }

func A_arbace_edn_A_clinit() { jrt.StartCheck(); A_arbace_edn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 20); A_arbace_edn_A_const_0 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[7]); A_arbace_edn_A_const_1 = A_arbace_edn_A_const_pool.A[8]; A_arbace_edn_A_const_2 = lang.Keyword_Cast(A_arbace_edn_A_const_pool.A[9]); A_arbace_edn_A_const_3 = A_arbace_edn_A_const_pool.A[10]; A_arbace_edn_A_const_4 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[11]); A_arbace_edn_A_const_5 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[12]); A_arbace_edn_A_const_6 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[13]); A_arbace_edn_A_const_7 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[14]); A_arbace_edn_A_const_8 = A_arbace_edn_A_const_pool.A[15]; A_arbace_edn_A_const_9 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[16]); A_arbace_edn_A_const_10 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[17]); A_arbace_edn_A_const_11 = lang.Var_Cast(A_arbace_edn_A_const_pool.A[18]); A_arbace_edn_A_const_12 = A_arbace_edn_A_const_pool.A[19] }

func A_arbace_edn_A_New() *A_arbace_edn_A { A_arbace_edn_A_Init(); t := &A_arbace_edn_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_A) Ctor() {}

func (t *A_arbace_edn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_A) GetClass__Class() *jrt.Class { return A_arbace_edn_A_class }

func (t *A_arbace_edn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_edn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_A); return ok }

func A_arbace_edn_A_Cast(x any) *A_arbace_edn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_A_class)) }; return v }



type A_arbace_edn_eval1345000004_A struct{ jrt.Object }

func A_arbace_edn_eval1345000004_A_New() *A_arbace_edn_eval1345000004_A { t := &A_arbace_edn_eval1345000004_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000004_A) Ctor() {}

func (t *A_arbace_edn_eval1345000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000004_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000004_A_class }

func (t *A_arbace_edn_eval1345000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000004_A); return ok }

func A_arbace_edn_eval1345000004_A_Cast(x any) *A_arbace_edn_eval1345000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000004_A_class)) }; return v }



type A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A struct{ j2g_header uint64 }

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_fn_class *jrt.Class



type A_arbace_edn_eval1345000008_A struct{ jrt.Object }

func A_arbace_edn_eval1345000008_A_New() *A_arbace_edn_eval1345000008_A { t := &A_arbace_edn_eval1345000008_A{}; t.Ctor(); return t }

func (t *A_arbace_edn_eval1345000008_A) Ctor() {}

func (t *A_arbace_edn_eval1345000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_edn_eval1345000008_A) GetClass__Class() *jrt.Class { return A_arbace_edn_eval1345000008_A_class }

func (t *A_arbace_edn_eval1345000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_edn_eval1345000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_edn_eval1345000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_edn_eval1345000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_edn_eval1345000008_A); return ok }

func A_arbace_edn_eval1345000008_A_Cast(x any) *A_arbace_edn_eval1345000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_edn_eval1345000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_edn_eval1345000008_A_class)) }; return v }



type A_arbace_edn_eval1345000008_fn__1345000009_A struct{ j2g_header uint64 }

var A_arbace_edn_eval1345000008_fn__1345000009_A_fn_class *jrt.Class



type A_arbace_edn_read_A struct{ j2g_header uint64 }

var A_arbace_edn_read_A_fn_class *jrt.Class



type A_arbace_edn_read_string_A struct{ j2g_header uint64 }

var A_arbace_edn_read_string_A_fn_class *jrt.Class
