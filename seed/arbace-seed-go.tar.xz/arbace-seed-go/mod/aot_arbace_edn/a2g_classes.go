//line a2g_classes.ae:1
package aot_arbace_edn

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class, Name: "arbace.edn$eval1345000004$loading__1927001464__auto____1345000005", Modifiers: 25, Simple: "loading__1927001464__auto____1345000005", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A", Source: "edn.ae", Declaring: &A_arbace_edn_eval1345000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_edn_eval1345000008_fn__1345000009_A_class, Name: "arbace.edn$eval1345000008$fn__1345000009", Modifiers: 25, Simple: "fn__1345000009", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000008_fn__1345000009_A", Source: "edn.ae", Declaring: &A_arbace_edn_eval1345000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_edn_read_A_class, Name: "arbace.edn$read", Modifiers: 25, Simple: "read", Go: "arbace/aot_arbace_edn.A_arbace_edn_read_A", Source: "edn.ae", Declaring: &A_arbace_edn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_edn_read_string_A_class, Name: "arbace.edn$read_string", Modifiers: 25, Simple: "read_string", Go: "arbace/aot_arbace_edn.A_arbace_edn_read_string_A", Source: "edn.ae", Declaring: &A_arbace_edn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_edn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_A_New()}; return nil }

var A_arbace_edn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_A_new}

var A_arbace_edn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_edn.A_arbace_edn_A"})

func init() { i := A_arbace_edn_A_class.Info(); i.IsInstance = A_arbace_edn_A_InstanceOf; i.Init = A_arbace_edn_A_Init; i.Table = A_arbace_edn_A_members }

func A_arbace_edn_eval1345000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000004_A_New()}; return nil }

var A_arbace_edn_eval1345000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_eval1345000004_A_new}

var A_arbace_edn_eval1345000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_edn_A_class, Simple: "eval1345000004", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000004_A"})

func init() { i := A_arbace_edn_eval1345000004_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000004_A_InstanceOf; i.Table = A_arbace_edn_eval1345000004_A_members }

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class *jrt.Class

func A_arbace_edn_eval1345000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000008_A_New()}; return nil }

var A_arbace_edn_eval1345000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_eval1345000008_A_new}

var A_arbace_edn_eval1345000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_edn_A_class, Simple: "eval1345000008", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000008_A"})

func init() { i := A_arbace_edn_eval1345000008_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000008_A_InstanceOf; i.Table = A_arbace_edn_eval1345000008_A_members }

var A_arbace_edn_eval1345000008_fn__1345000009_A_class *jrt.Class

var A_arbace_edn_read_A_class *jrt.Class

var A_arbace_edn_read_string_A_class *jrt.Class

func A_arbace_edn__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_edn__init_A_Load__O()}; return nil }

func A_arbace_edn__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn__init_A_New()}; return nil }

var A_arbace_edn__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_edn__init_A_invoke, New: A_arbace_edn__init_A_new}

var A_arbace_edn__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_edn.A_arbace_edn__init_A", Source: "edn.ae"})

func init() { i := A_arbace_edn__init_A_class.Info(); i.IsInstance = A_arbace_edn__init_A_InstanceOf; i.Init = A_arbace_edn__init_A_Init; i.Table = A_arbace_edn__init_A_members }
