//line a2g_classes.ae:1
package aot_arbace_edn

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_edn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_A_New()}; return nil }

var A_arbace_edn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_A_new}

var A_arbace_edn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_edn.A_arbace_edn_A"})

func init() { i := A_arbace_edn_A_class.Info(); i.IsInstance = A_arbace_edn_A_InstanceOf; i.Init = A_arbace_edn_A_Init; i.Table = A_arbace_edn_A_members; jrt.RegisterGoType(A_arbace_edn_A_class, reflect.TypeFor[A_arbace_edn_A]()) }

func A_arbace_edn_eval1345000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000004_A_New()}; return nil }

var A_arbace_edn_eval1345000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_eval1345000004_A_new}

var A_arbace_edn_eval1345000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_edn_A_class, Simple: "eval1345000004", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000004_A"})

func init() { i := A_arbace_edn_eval1345000004_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000004_A_InstanceOf; i.Table = A_arbace_edn_eval1345000004_A_members; jrt.RegisterGoType(A_arbace_edn_eval1345000004_A_class, reflect.TypeFor[A_arbace_edn_eval1345000004_A]()) }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_New()}; return nil }

func A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_fn_class)}; return nil }

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_invoke, New: A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_new, Get: A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_get}

var A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000004$loading__1927001464__auto____1345000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_edn_eval1345000004_A_class, Simple: "loading__1927001464__auto____1345000005", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A", Source: "edn.ae"})

func init() { i := A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_InstanceOf; i.Init = A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_Init; i.Table = A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_members; jrt.RegisterGoType(A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A_class, reflect.TypeFor[A_arbace_edn_eval1345000004_loading__1927001464__auto____1345000005_A]()) }

func A_arbace_edn_eval1345000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000008_A_New()}; return nil }

var A_arbace_edn_eval1345000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_edn_eval1345000008_A_new}

var A_arbace_edn_eval1345000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_edn_A_class, Simple: "eval1345000008", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000008_A"})

func init() { i := A_arbace_edn_eval1345000008_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000008_A_InstanceOf; i.Table = A_arbace_edn_eval1345000008_A_members; jrt.RegisterGoType(A_arbace_edn_eval1345000008_A_class, reflect.TypeFor[A_arbace_edn_eval1345000008_A]()) }

func A_arbace_edn_eval1345000008_fn__1345000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_edn_eval1345000008_fn__1345000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_edn_eval1345000008_fn__1345000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_eval1345000008_fn__1345000009_A_New()}; return nil }

func A_arbace_edn_eval1345000008_fn__1345000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_edn_eval1345000008_fn__1345000009_A_fn_class)}; return nil }

var A_arbace_edn_eval1345000008_fn__1345000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_edn_eval1345000008_fn__1345000009_A_invoke, New: A_arbace_edn_eval1345000008_fn__1345000009_A_new, Get: A_arbace_edn_eval1345000008_fn__1345000009_A_get}

var A_arbace_edn_eval1345000008_fn__1345000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$eval1345000008$fn__1345000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_edn_eval1345000008_A_class, Simple: "fn__1345000009", Go: "arbace/aot_arbace_edn.A_arbace_edn_eval1345000008_fn__1345000009_A", Source: "edn.ae"})

func init() { i := A_arbace_edn_eval1345000008_fn__1345000009_A_class.Info(); i.IsInstance = A_arbace_edn_eval1345000008_fn__1345000009_A_InstanceOf; i.Init = A_arbace_edn_eval1345000008_fn__1345000009_A_Init; i.Table = A_arbace_edn_eval1345000008_fn__1345000009_A_members; jrt.RegisterGoType(A_arbace_edn_eval1345000008_fn__1345000009_A_class, reflect.TypeFor[A_arbace_edn_eval1345000008_fn__1345000009_A]()) }

func A_arbace_edn_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_edn_read_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_edn_read_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_edn_read_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_edn_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_read_A_New()}; return nil }

func A_arbace_edn_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_edn_read_A_fn_class)}; return nil }

var A_arbace_edn_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_edn_read_A_invoke, New: A_arbace_edn_read_A_new, Get: A_arbace_edn_read_A_get}

var A_arbace_edn_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_edn_A_class, Simple: "read", Go: "arbace/aot_arbace_edn.A_arbace_edn_read_A", Source: "edn.ae"})

func init() { i := A_arbace_edn_read_A_class.Info(); i.IsInstance = A_arbace_edn_read_A_InstanceOf; i.Init = A_arbace_edn_read_A_Init; i.Table = A_arbace_edn_read_A_members; jrt.RegisterGoType(A_arbace_edn_read_A_class, reflect.TypeFor[A_arbace_edn_read_A]()) }

func A_arbace_edn_read_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_edn_read_string_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_edn_read_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_edn_read_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn_read_string_A_New()}; return nil }

func A_arbace_edn_read_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_edn_read_string_A_fn_class)}; return nil }

var A_arbace_edn_read_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_edn_read_string_A_invoke, New: A_arbace_edn_read_string_A_new, Get: A_arbace_edn_read_string_A_get}

var A_arbace_edn_read_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn$read_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_edn_A_class, Simple: "read_string", Go: "arbace/aot_arbace_edn.A_arbace_edn_read_string_A", Source: "edn.ae"})

func init() { i := A_arbace_edn_read_string_A_class.Info(); i.IsInstance = A_arbace_edn_read_string_A_InstanceOf; i.Init = A_arbace_edn_read_string_A_Init; i.Table = A_arbace_edn_read_string_A_members; jrt.RegisterGoType(A_arbace_edn_read_string_A_class, reflect.TypeFor[A_arbace_edn_read_string_A]()) }

func A_arbace_edn__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_edn__init_A_Load__O(); case 1: return A_arbace_edn__init_A_Unit0__O(); case 2: return A_arbace_edn__init_A_Unit1__O(); case 3: return A_arbace_edn__init_A_Unit2__O(); case 4: return A_arbace_edn__init_A_Unit3__O(); case 5: return A_arbace_edn__init_A_Unit4__O(); case 6: return A_arbace_edn__init_A_Unit5__O()}; return nil }

func A_arbace_edn__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_edn__init_A_New()}; return nil }

var A_arbace_edn__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_edn__init_A_invoke, New: A_arbace_edn__init_A_new}

var A_arbace_edn__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.edn__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_edn.A_arbace_edn__init_A", Source: "edn.ae"})

func init() { i := A_arbace_edn__init_A_class.Info(); i.IsInstance = A_arbace_edn__init_A_InstanceOf; i.Init = A_arbace_edn__init_A_Init; i.Table = A_arbace_edn__init_A_members; jrt.RegisterGoType(A_arbace_edn__init_A_class, reflect.TypeFor[A_arbace_edn__init_A]()) }
