//line j2g_strings.ae:1
package aot_arbace_edn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn4,readyn11,read-stringkn3,dockn6,authorkn3,eofv11,arbace.core5,referR0,R1,V2,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn10,arbace.ednm4,R4,s12,edn reading.R5,s11,Rich Hickeyv10,arbace.edn4,readv11,arbace.core4,*in*v10,arbace.edn11,read-stringm2,R6,n")

var Lit_1 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistsyn6,streamyn4,optskn5,addedkn4,linekn6,columnkn4,fileyn1,sv11,arbace.core5,in-nsMyn10,arbace.ednm4,R0,s12,edn reading.R1,s11,Rich Hickeym4,R0,s12,edn reading.R1,s11,Rich HickeyR2,v10,arbace.edn4,readm12,R3,L3,V0,V1,R4,V2,R5,R4,R0,s702,Reads the next object from stream, which must be an instance of\n  java.io.PushbackReader or some derivee.  stream defaults to the\n  current value of *in*.\n\n  Reads data in the edn format (subset of Clojure data):\n  http://edn-format.org\n\n  opts is a map that can include the following keys:\n  :eof - value to return on end-of-file. When not supplied, eof throws an exception.\n  :readers  - a map of tag symbols to data-reader functions to be considered before default-data-readers.\n              When not supplied, only the default-data-readers will be used.\n  :default - A function of two args, that will, if present and no reader is found for a tag,\n             be called with the tag and the value.R6,s3,1.5R7,i14,R8,i1,R9,s13,arbace/edn.aev10,arbace.edn11,read-stringm12,R3,L2,V1,R10,V2,R5,R10,R0,s193,Reads one object from the string s. Returns nil when s is nil or empty.\n\n  Reads data in the edn format (subset of Clojure data):\n  http://edn-format.org\n\n  opts is a map as per arbace.edn/readR6,s3,1.5R7,i37,R8,i1,R9,s13,arbace/edn.ae")

var Lit_2 *jrt.String = jrt.Intern("arbace.edn$eval1345000004$loading__1927001464__auto____1345000005")

var Lit_3 *jrt.String = jrt.Intern("arbace.edn$eval1345000008$fn__1345000009")

var Lit_4 *jrt.String = jrt.Intern("arbace.edn$read")

var Lit_5 *jrt.String = jrt.Intern("arbace.edn$read_string")
