//line a2g_strings.ae:1
package aot_arbace_edn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("exclude")

var Lit_3 *jrt.String = jrt.Intern("read")

var Lit_4 *jrt.String = jrt.Intern("read-string")

var Lit_5 *jrt.String = jrt.Intern("commute")

var Lit_6 *jrt.String = jrt.Intern("deref")

var Lit_7 *jrt.String = jrt.Intern("conj")

var Lit_8 *jrt.String = jrt.Intern("arbace.edn")

var Lit_9 *jrt.String = jrt.Intern("doc")

var Lit_10 *jrt.String = jrt.Intern("edn reading.")

var Lit_11 *jrt.String = jrt.Intern("author")

var Lit_12 *jrt.String = jrt.Intern("Rich Hickey")

var Lit_13 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_14 *jrt.String = jrt.Intern("*in*")

var Lit_15 *jrt.String = jrt.Intern("eof")

var Lit_16 *jrt.String = jrt.Intern("arbace.edn$eval1345000004$loading__1927001464__auto____1345000005")

var Lit_17 *jrt.String = jrt.Intern("arbace.edn$eval1345000008$fn__1345000009")

var Lit_18 *jrt.String = jrt.Intern("arbace.edn$read")

var Lit_19 *jrt.String = jrt.Intern("arbace.edn$read_string")

var Lit_20 *jrt.String = jrt.Intern("in-ns")

var Lit_21 *jrt.String = jrt.Intern("arglists")

var Lit_22 *jrt.String = jrt.Intern("stream")

var Lit_23 *jrt.String = jrt.Intern("opts")

var Lit_24 *jrt.String = jrt.Intern("Reads the next object from stream, which must be an instance of\n  java.io.PushbackReader or some derivee.  stream defaults to the\n  current value of *in*.\n\n  Reads data in the edn format (subset of Clojure data):\n  http://edn-format.org\n\n  opts is a map that can include the following keys:\n  :eof - value to return on end-of-file. When not supplied, eof throws an exception.\n  :readers  - a map of tag symbols to data-reader functions to be considered before default-data-readers.\n              When not supplied, only the default-data-readers will be used.\n  :default - A function of two args, that will, if present and no reader is found for a tag,\n             be called with the tag and the value.")

var Lit_25 *jrt.String = jrt.Intern("added")

var Lit_26 *jrt.String = jrt.Intern("1.5")

var Lit_27 *jrt.String = jrt.Intern("line")

var Lit_28 *jrt.String = jrt.Intern("column")

var Lit_29 *jrt.String = jrt.Intern("file")

var Lit_30 *jrt.String = jrt.Intern("arbace/edn.ae")

var Lit_31 *jrt.String = jrt.Intern("s")

var Lit_32 *jrt.String = jrt.Intern("Reads one object from the string s. Returns nil when s is nil or empty.\n\n  Reads data in the edn format (subset of Clojure data):\n  http://edn-format.org\n\n  opts is a map as per arbace.edn/read")
