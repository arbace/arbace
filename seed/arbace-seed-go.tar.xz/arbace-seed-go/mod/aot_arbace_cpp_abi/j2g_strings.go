//line j2g_strings.ae:1
package aot_arbace_cpp_abi

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.corekn7,excludeyn6,class?yn3,fn?kn3,docks7,codegen7,refusedkn1,kkn1,bkn1,nkn3,ptrkn2,tokn3,refkn4,rrefkn3,arrkn2,ofkn1,ckn1,vkn4,voidkn5,classkn4,enumkn2,fnkn7,float16kn6,doublekn7,ldoublekn5,floatkn8,float128kn4,mptrkn7,nullptrkn2,idkn5,underkn7,complexkn4,typekn4,sizekn5,alignkn5,baseskn7,virtualkn3,clskn8,virtualskn6,nvsizekn7,primarykn3,nuakn2,tykn6,fieldskn9,user-ctorkn9,user-dtorkn16,user-copy-assignkn6,publickn6,accesskn4,elsekn6,vbaseskn4,bitskn6,layoutkn4,namekn7,nvalignkn3,podkn5,unionkn10,align-attrkn5,dsizekn7,bitoffskn4,vptrkn7,partialkn8,finishedkn5,scopeyn3,ptryn6,structyn3,i64kn4,linekn6,columnkn5,scharyn2,i8yn6,doublekn4,charkn4,boolyn2,i1kn4,i128yn4,i128yn5,floatkn6,ullongyn4,halfkn4,longkn3,intyn3,i32yn8,x86_fp80kn5,wcharkn5,shortyn3,i16kn5,llongkn5,char8kn4,u128kn5,ucharkn6,ushortkn6,char32yn5,fp128yn4,voidkn5,ulongkn6,char16kn4,uintyn5,arraykn5,nameskn10,dollar-keykn6,countskn5,mnamekn2,nskn4,anonkn4,tmplkn4,pathkn5,targskn6,prefixkn5,localkn3,ttpkn1,tkn1,ikn4,argskn8,tparam-vkn5,texprkn1,okn2,srkn4,basekn5,tspeckn7,writtenkn4,packkn4,qualkn6,tparamkn6,manglekn2,vtkn7,conceptkn5,mcallkn5,wbasekn2,qtkn1,qkn1,xkn3,tpvkn4,castkn4,codekn2,szkn2,fpkn3,litkn3,rawkn1,skn4,callkn1,fkn4,failkn4,whatkn4,tyopkn9,constructkn4,listkn2,opkn3,memkn8,implicitkn5,arrowkn4,tdepkn2,dtkn4,declkn4,nullkn7,mangledkn5,ttdepkn3,valkn4,autokn8,decltypekn8,pack-expkn6,qparamkn3,retkn2,pskn2,vakn2,cqkn8,abi-tagskn4,kindkn4,ctorkn8,inh-namekn8,inh-basekn4,convkn10,mangle-retkn4,dtorkn6,statickn5,innerkn8,qualTypekn6,opcodekn5,valuekn14,referencedDeclkn20,explicitTemplateArgskn9,qualifierkn6,paramskn15,globalQualifierkn9,initStylekn8,isGlobalkn7,isArraykn7,linkagekn5,tinstkn2,tnkn2,tkkn4,nodekn4,pidxkn5,depthkn3,tidkn10,internal-lkn4,xobjkn4,refqkn4,tsigkn4,nonekn6,memorykn7,integerkn3,x87kn3,ssekn6,ignorev11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,R4,V2,R5,R6,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.cpp.abim2,R7,s688,The C++ code generator's types and the Itanium C++ ABI's parts it needs (doc/cpp/CODEGEN.md §3, §4): the semantic\n  types of arbace.cpp.sema (maps with :k), the program's classes and enumerations (a registry by id), sizes and\n  alignments on x86-64 (LP64), the class layout of the Itanium ABI (§2.4: the vptr, the primary base, empty bases at\n  offset 0, a non-POD base's tail padding reused) and the Itanium mangling of names (§5.1: nested names, the\n  substitutions S_ S0_ ..., the special members' C1 C2 D0 D1 D2, operators, local statics). Written from the ABI's text\n  (itanium-cxx-abi.github.io/cxx-abi/abi.html) and checked against clang 23's output on the samples; no code ported.v11,arbace.core7,ex-infov11,arbace.core5,applyv11,arbace.core3,strR8,v13,arbace.string9,includes?R9,R10,R11,R12,R13,R14,R15,R16,R17,v11,arbace.core6,dissocR18,R19,v11,arbace.core5,assocR20,v14,arbace.cpp.abi2,bnS2,R14,R15,v14,arbace.cpp.abi4,ref?R21,R22,R23,v11,arbace.core9,contains?v14,arbace.cpp.abi9,int-ranksv14,arbace.cpp.abi5,enum?S5,R24,R25,R26,R27,R28,v14,arbace.cpp.abi9,floating?R29,v14,arbace.cpp.abi5,mptr?v14,arbace.cpp.abi6,arith?v14,arbace.cpp.abi4,ptr?R30,v14,arbace.cpp.abi3,unqv14,arbace.cpp.abi9,*classes*v14,arbace.cpp.abi3,clsR31,v11,arbace.core5,swap!v11,arbace.core6,updatev14,arbace.cpp.abi7,*enums*R32,v14,arbace.cpp.abi3,enmv14,arbace.cpp.abi4,int*V2,l8,l8,R33,v14,arbace.cpp.abi10,size-alignv14,arbace.cpp.abi6,layoutV2,l16,l8,V2,l8,l8,v14,arbace.cpp.abi4,failR34,v11,arbace.core6,pr-strR35,R36,V2,l8,l8,l0,V2,l8,l8,V2,l1,l1,v14,arbace.cpp.abi11,scalar-sizev14,arbace.cpp.abi10,underlyingv11,arbace.core5,firstv11,arbace.core6,secondv11,arbace.core3,vecv11,arbace.core3,seqR37,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstR38,R39,v11,arbace.core10,chunk-restv11,arbace.core4,nextR40,v11,arbace.core4,somev14,arbace.cpp.abi8,dynamic?R41,R42,v11,arbace.core6,filterv11,arbace.core3,notv14,arbace.cpp.abi18,indirect-primariesv11,arbace.core4,atomv14,arbace.cpp.abi13,nearly-empty?v14,arbace.cpp.abi6,vbasesv11,arbace.core6,reset!R43,v14,arbace.cpp.abi6,class?R44,v14,arbace.cpp.abi12,empty-class?v11,arbace.core6,every?v14,arbace.cpp.abi13,empty-member?R45,v11,arbace.core6,empty?R46,R47,R48,R49,R50,v14,arbace.cpp.abi4,arr?v14,arbace.cpp.abi15,pod-for-layout?v11,arbace.core4,intov11,arbace.core6,mapcatv14,arbace.cpp.abi21,nonvirtual-subobjectsv11,arbace.core11,map-indexedv11,arbace.core6,vectorv14,arbace.cpp.abi13,class-emptiesv11,arbace.core5,rangeR51,R52,R53,v14,arbace.cpp.abi13,field-emptiesv11,arbace.core6,concatv11,arbace.core8,not-any?v11,arbace.core4,fnilR54,v14,arbace.cpp.abi7,layout*R55,v14,arbace.cpp.abi12,primary-basev11,arbace.core12,keep-indexedv11,arbace.core4,consv11,arbace.core6,removev11,arbace.core6,reduceR56,R57,v14,arbace.cpp.abi10,can-place?v14,arbace.cpp.abi8,align-upv14,arbace.cpp.abi6,place!v11,arbace.core3,maxv11,arbace.core4,mapvR58,v11,arbace.core4,not=R59,l1,R60,R61,R62,v14,arbace.cpp.abi11,update-cls!R63,R64,R65,v11,arbace.core3,mapv11,arbace.core4,keepv14,arbace.cpp.abi9,base-pathv11,arbace.core5,some?R66,R66,v11,arbace.core4,listML3,R67,R68,R68,m4,R69,i395,R70,i40,R68,R71,R72,R25,R73,R74,R75,R76,R72,v14,arbace.cpp.abi9,llvm-typeR66,R77,R78,R27,R79,R80,R68,R24,R81,R82,R83,R84,R26,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R28,R95,R96,R97,R98,R99,R100,v14,arbace.cpp.abi7,size-ofR72,v14,arbace.cpp.abi11,unsigned-nsv14,arbace.cpp.abi6,*subs*v14,arbace.cpp.abi6,seq-idv14,arbace.cpp.abi9,*dollars*v11,arbace.core6,get-inR101,R102,R103,v14,arbace.cpp.abi11,source-namev11,arbace.core8,assoc-inR104,v14,arbace.cpp.abi12,dollar-name!R105,R106,R107,m4,R9,R10,R11,R74,V1,V2,R105,s3,stdR108,R109,V1,V2,R105,s3,stdl2,R110,v11,arbace.core6,subvecV2,R105,s3,stdv14,arbace.cpp.abi16,std-abbreviationv14,arbace.cpp.abi10,part-targsv14,arbace.cpp.abi15,template-prefixv14,arbace.cpp.abi13,template-argsv14,arbace.cpp.abi9,part-namev11,arbace.core7,string?v14,arbace.cpp.abi14,local-encodingv14,arbace.cpp.abi12,path-of-typeR111,v11,arbace.core6,ffirstv11,arbace.core4,restv14,arbace.cpp.abi9,local-encv14,arbace.cpp.abi13,mangle-prefixV2,R105,s3,stdR112,v14,arbace.cpp.abi6,sub-orR113,v14,arbace.cpp.abi14,template-paramR114,R115,v11,arbace.core7,number?R116,R117,R118,R119,R120,R121,R122,v11,arbace.core4,takev11,arbace.core4,map?R123,R124,V1,V2,R105,s3,stdR125,v14,arbace.cpp.abi12,mangle-type*R126,R127,v14,arbace.cpp.abi13,expr-op-codesv14,arbace.cpp.abi11,mangle-exprR128,R129,R130,R131,R132,v14,arbace.cpp.abi12,template-argR133,R134,R135,R136,v14,arbace.cpp.abi14,mangle-dt-exprR137,R138,R139,R140,R141,R142,R143,R144,R145,R146,R147,R148,R149,R150,R151,R152,v14,arbace.cpp.abi13,dt-unresolvedR153,V2,R120,R55,V2,R120,R114,R154,R155,R156,R157,R158,R159,v11,arbace.core6,false?v14,arbace.cpp.abi4,skeyv11,arbace.core7,vector?v14,arbace.cpp.abi3,cvqR160,R161,v14,arbace.cpp.abi12,mangle-namedR162,R163,R164,R165,R166,v14,arbace.cpp.abi11,dt-standin?v11,arbace.core8,tree-seqv11,arbace.core5,coll?v11,arbace.core4,valsv14,arbace.cpp.abi15,tspec-unwrappedV1,V2,R105,s3,stdR167,v14,arbace.cpp.abi13,builtin-codesv14,arbace.cpp.abi11,bare-paramsv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv14,arbace.cpp.abi17,unqualified-name*R168,R169,R170,R171,R172,R173,R174,R175,S4,s1,*s1,-s1,&s1,+R176,v14,arbace.cpp.abi14,unary-op-codesv14,arbace.cpp.abi8,op-codesv11,arbace.core10,re-matchesp31,\\\"\\\"\\s*([A-Za-z_][A-Za-z0-9_]*)v13,arbace.string4,trimv14,arbace.cpp.abi7,q-paramv13,arbace.string10,ends-with?v11,arbace.core4,subsv13,arbace.string12,starts-with?l6,m18,s5,floatR27,s3,intR83,s4,voidR20,s12,unsigned intR99,s4,longR82,s4,boolR75,s4,charR74,s6,doubleR25,s13,unsigned longR97,m18,s5,floatR27,s3,intR83,s4,voidR20,s12,unsigned intR99,s4,longR82,s4,boolR75,s4,charR74,s6,doubleR25,s13,unsigned longR97,R177,V2,R34,R178,R179,R180,V2,R181,R55,R182,R183,R184,R185,v11,arbace.core7,re-findp1,<V2,R181,R55,R186,V2,R34,R178,R187,V2,R34,R178,R188,R189,v14,arbace.cpp.abi9,encoding*v14,arbace.cpp.abi9,mangle-fnR190,S3,R170,R173,R175,v14,arbace.cpp.abi16,unqualified-nameR191,R192,V1,V2,R105,s3,stdv14,arbace.cpp.abi17,mangle-constraintR193,R194,R195,R196,R197,V1,V2,R105,s3,stdR198,R199,R200,S3,R170,R173,R175,V1,V2,R105,s3,stdS2,R170,R175,R201,R202,R203,R204,R205,v14,arbace.cpp.abi11,merge-classv14,arbace.cpp.abi14,classify-into!v14,arbace.cpp.abi5,mark!v14,arbace.cpp.abi12,scalar-classl8,R206,V4,R201,R201,l0,l0,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunk")

var Lit_1 *jrt.String = jrt.Intern("v")

var Lit_2 *jrt.String = jrt.Intern("z")

var Lit_3 *jrt.String = jrt.Intern("arbace.cpp.abi$base_path$fn__677000211")

var Lit_4 *jrt.String = jrt.Intern("arbace.cpp.abi$can_place_QMARK_$fn__677000128")

var Lit_5 *jrt.String = jrt.Intern("arbace.cpp.abi$class_empties$fn__677000116")

var Lit_6 *jrt.String = jrt.Intern("arbace.cpp.abi$class_empties$fn__677000119")

var Lit_7 *jrt.String = jrt.Intern("arbace.cpp.abi$class_empties$fn__677000124")

var Lit_8 *jrt.String = jrt.Intern("arbace.cpp.abi$classify_class$iter__677000413__677000417")

var Lit_9 *jrt.String = jrt.Intern("arbace.cpp.abi$classify_class$iter__677000413__677000417$fn__677000418")

var Lit_10 *jrt.String = jrt.Intern("arbace.cpp.abi$classify_class$iter__677000413__677000417$fn__677000418$fn__677000419")

var Lit_11 *jrt.String = jrt.Intern("V")

var Lit_12 *jrt.String = jrt.Intern("K")

var Lit_13 *jrt.String = jrt.Intern("$_")

var Lit_14 *jrt.String = jrt.Intern("arbace.cpp.abi$dollar_name_BANG_$fn__677000231")

var Lit_15 *jrt.String = jrt.Intern("decltype")

var Lit_16 *jrt.String = jrt.Intern("sr")

var Lit_17 *jrt.String = jrt.Intern("E")

var Lit_18 *jrt.String = jrt.Intern("I")

var Lit_19 *jrt.String = jrt.Intern("arbace.cpp.abi$dynamic_QMARK_$fn__677000070")

var Lit_20 *jrt.String = jrt.Intern("arbace.cpp.abi$empty_class_QMARK_$fn__677000091")

var Lit_21 *jrt.String = jrt.Intern("Z")

var Lit_22 *jrt.String = jrt.Intern("arbace.cpp.abi$encoding_STAR_$uname__677000356")

var Lit_23 *jrt.String = jrt.Intern("L")

var Lit_24 *jrt.String = jrt.Intern("")

var Lit_25 *jrt.String = jrt.Intern("St")

var Lit_26 *jrt.String = jrt.Intern("N")

var Lit_27 *jrt.String = jrt.Intern("H")

var Lit_28 *jrt.String = jrt.Intern("&")

var Lit_29 *jrt.String = jrt.Intern("R")

var Lit_30 *jrt.String = jrt.Intern("&&")

var Lit_31 *jrt.String = jrt.Intern("O")

var Lit_32 *jrt.String = jrt.Intern("arbace.cpp.abi$encoding_STAR_$uname__677000356$fn__677000357")

var Lit_33 *jrt.String = jrt.Intern("arbace.cpp.abi$encoding_STAR_$uname__677000356$fn__677000359")

var Lit_34 *jrt.String = jrt.Intern("Tp")

var Lit_35 *jrt.String = jrt.Intern("Tk")

var Lit_36 *jrt.String = jrt.Intern("Tn")

var Lit_37 *jrt.String = jrt.Intern("Q")

var Lit_38 *jrt.String = jrt.Intern("CPP_FAIL_STACK")

var Lit_39 *jrt.String = jrt.Intern("codegen: ")

var Lit_40 *jrt.String = jrt.Intern("arbace.cpp.abi$field_empties$fn__677000109")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.abi$field_empties$fn__677000111")

var Lit_42 *jrt.String = jrt.Intern("arbace.cpp.abi$field_empties$fn__677000113")

var Lit_43 *jrt.String = jrt.Intern("arbace.cpp.abi$indirect_primaries$walk__677000074")

var Lit_44 *jrt.String = jrt.Intern("the class ")

var Lit_45 *jrt.String = jrt.Intern(" is too large for its layout")

var Lit_46 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000157")

var Lit_47 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000159")

var Lit_48 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000162")

var Lit_49 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000169")

var Lit_50 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000172")

var Lit_51 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$mark_BANG___677000182")

var Lit_52 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000195")

var Lit_53 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000202")

var Lit_54 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000204")

var Lit_55 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000162$fn__677000166")

var Lit_56 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000172$fn__677000179")

var Lit_57 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000195$fn__677000199")

var Lit_58 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_$fn__677000204$fn__677000205")

var Lit_59 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_60 *jrt.String = jrt.Intern("main")

var Lit_61 *jrt.String = jrt.Intern("4main")

var Lit_62 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ty__677000330")

var Lit_63 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$tt__677000332")

var Lit_64 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$arg__677000334")

var Lit_65 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$req__677000336")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ex__677000339")

var Lit_67 *jrt.String = jrt.Intern("BinaryOperator")

var Lit_68 *jrt.String = jrt.Intern("operator ")

var Lit_69 *jrt.String = jrt.Intern("IntegerLiteral")

var Lit_70 *jrt.String = jrt.Intern("Li")

var Lit_71 *jrt.String = jrt.Intern("UnresolvedLookupExpr")

var Lit_72 *jrt.String = jrt.Intern("a ::-qualified name in a constraint")

var Lit_73 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000341")

var Lit_74 *jrt.String = jrt.Intern("a template in a constraint's qualifier")

var Lit_75 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000343")

var Lit_76 *jrt.String = jrt.Intern("RequiresExpr")

var Lit_77 *jrt.String = jrt.Intern("a requires-expression's parameters")

var Lit_78 *jrt.String = jrt.Intern("rq")

var Lit_79 *jrt.String = jrt.Intern("UnaryOperator")

var Lit_80 *jrt.String = jrt.Intern("!")

var Lit_81 *jrt.String = jrt.Intern("nt")

var Lit_82 *jrt.String = jrt.Intern("-")

var Lit_83 *jrt.String = jrt.Intern("ng")

var Lit_84 *jrt.String = jrt.Intern("~")

var Lit_85 *jrt.String = jrt.Intern("co")

var Lit_86 *jrt.String = jrt.Intern("DeclRefExpr")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000346")

var Lit_88 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000348")

var Lit_89 *jrt.String = jrt.Intern("PackExpansionExpr")

var Lit_90 *jrt.String = jrt.Intern("sp")

var Lit_91 *jrt.String = jrt.Intern("CXXBoolLiteralExpr")

var Lit_92 *jrt.String = jrt.Intern("Lb1E")

var Lit_93 *jrt.String = jrt.Intern("Lb0E")

var Lit_94 *jrt.String = jrt.Intern("CStyleCastExpr")

var Lit_95 *jrt.String = jrt.Intern("cv")

var Lit_96 *jrt.String = jrt.Intern("CXXNewExpr")

var Lit_97 *jrt.String = jrt.Intern("*")

var Lit_98 *jrt.String = jrt.Intern("an array new in a constraint")

var Lit_99 *jrt.String = jrt.Intern("nw")

var Lit_100 *jrt.String = jrt.Intern("_")

var Lit_101 *jrt.String = jrt.Intern("gs")

var Lit_102 *jrt.String = jrt.Intern("pi")

var Lit_103 *jrt.String = jrt.Intern("ParenListExpr")

var Lit_104 *jrt.String = jrt.Intern("ParenExpr")

var Lit_105 *jrt.String = jrt.Intern("CallExpr")

var Lit_106 *jrt.String = jrt.Intern("cl")

var Lit_107 *jrt.String = jrt.Intern("a constraint's ")

var Lit_108 *jrt.String = jrt.Intern("SimpleRequirement")

var Lit_109 *jrt.String = jrt.Intern("X")

var Lit_110 *jrt.String = jrt.Intern("TypeRequirement")

var Lit_111 *jrt.String = jrt.Intern("T")

var Lit_112 *jrt.String = jrt.Intern("NestedRequirement")

var Lit_113 *jrt.String = jrt.Intern("a requirement ")

var Lit_114 *jrt.String = jrt.Intern("const ")

var Lit_115 *jrt.String = jrt.Intern(" const")

var Lit_116 *jrt.String = jrt.Intern("a member template's parameter type")

var Lit_117 *jrt.String = jrt.Intern("a constraint's type ")

var Lit_118 *jrt.String = jrt.Intern("_ZTC")

var Lit_119 *jrt.String = jrt.Intern("sZ")

var Lit_120 *jrt.String = jrt.Intern("fp")

var Lit_121 *jrt.String = jrt.Intern("a dependent decltype's ")

var Lit_122 *jrt.String = jrt.Intern("tl")

var Lit_123 *jrt.String = jrt.Intern("dtdefpT")

var Lit_124 *jrt.String = jrt.Intern("pt")

var Lit_125 *jrt.String = jrt.Intern("dt")

var Lit_126 *jrt.String = jrt.Intern("n")

var Lit_127 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_expr$fn__677000260")

var Lit_128 *jrt.String = jrt.Intern("a member of ")

var Lit_129 *jrt.String = jrt.Intern("sizeof...")

var Lit_130 *jrt.String = jrt.Intern("sizeof... of ")

var Lit_131 *jrt.String = jrt.Intern("sizeof")

var Lit_132 *jrt.String = jrt.Intern("st")

var Lit_133 *jrt.String = jrt.Intern("clsr")

var Lit_134 *jrt.String = jrt.Intern("a member call of ")

var Lit_135 *jrt.String = jrt.Intern("expression ")

var Lit_136 *jrt.String = jrt.Intern("_Z")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_local_static$fn__677000366")

var Lit_138 *jrt.String = jrt.Intern("_ZZ")

var Lit_139 *jrt.String = jrt.Intern("__")

var Lit_140 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_prefix$idx__677000244")

var Lit_141 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_prefix$fn__677000246")

var Lit_142 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280")

var Lit_143 *jrt.String = jrt.Intern("Dc")

var Lit_144 *jrt.String = jrt.Intern("Da")

var Lit_145 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000282")

var Lit_146 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000284")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000286")

var Lit_148 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000288")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000290")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000292")

var Lit_151 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000294")

var Lit_152 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000296")

var Lit_153 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298")

var Lit_154 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000308")

var Lit_155 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000310")

var Lit_156 *jrt.String = jrt.Intern("C")

var Lit_157 *jrt.String = jrt.Intern("A")

var Lit_158 *jrt.String = jrt.Intern("Dp")

var Lit_159 *jrt.String = jrt.Intern("P")

var Lit_160 *jrt.String = jrt.Intern("F")

var Lit_161 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000299")

var Lit_162 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000301")

var Lit_163 *jrt.String = jrt.Intern("DT")

var Lit_164 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000303")

var Lit_165 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000305")

var Lit_166 *jrt.String = jrt.Intern("M")

var Lit_167 *jrt.String = jrt.Intern("_ZN")

var Lit_168 *jrt.String = jrt.Intern("_ZL")

var Lit_169 *jrt.String = jrt.Intern("_ZSt")

var Lit_170 *jrt.String = jrt.Intern("arbace.cpp.abi$mark_BANG_$fn__677000374")

var Lit_171 *jrt.String = jrt.Intern("arbace.cpp.abi$nonvirtual_subobjects$fn__677000103")

var Lit_172 *jrt.String = jrt.Intern("12_GLOBAL__N_1")

var Lit_173 *jrt.String = jrt.Intern("arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000095")

var Lit_174 *jrt.String = jrt.Intern("arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000097")

var Lit_175 *jrt.String = jrt.Intern("arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000097$fn__677000098")

var Lit_176 *jrt.String = jrt.Intern("arbace.cpp.abi$primary_base$fn__677000082")

var Lit_177 *jrt.String = jrt.Intern("arbace.cpp.abi$primary_base$sel__677000084")

var Lit_178 *jrt.String = jrt.Intern("arbace.cpp.abi$primary_base$sel__677000084$fn__677000085")

var Lit_179 *jrt.String = jrt.Intern("arbace.cpp.abi$q_param$fn__677000325")

var Lit_180 *jrt.String = jrt.Intern("S_")

var Lit_181 *jrt.String = jrt.Intern("S")

var Lit_182 *jrt.String = jrt.Intern("no size for ")

var Lit_183 *jrt.String = jrt.Intern("arbace.cpp.abi$skey$fn__677000274")

var Lit_184 *jrt.String = jrt.Intern("arbace.cpp.abi$std_abbreviation$traits_QMARK___677000238")

var Lit_185 *jrt.String = jrt.Intern("arbace.cpp.abi$std_abbreviation$alloc_QMARK___677000240")

var Lit_186 *jrt.String = jrt.Intern("basic_string")

var Lit_187 *jrt.String = jrt.Intern("Ss")

var Lit_188 *jrt.String = jrt.Intern("basic_iostream")

var Lit_189 *jrt.String = jrt.Intern("Sd")

var Lit_190 *jrt.String = jrt.Intern("basic_istream")

var Lit_191 *jrt.String = jrt.Intern("Si")

var Lit_192 *jrt.String = jrt.Intern("basic_ostream")

var Lit_193 *jrt.String = jrt.Intern("So")

var Lit_194 *jrt.String = jrt.Intern("allocator")

var Lit_195 *jrt.String = jrt.Intern("char_traits")

var Lit_196 *jrt.String = jrt.Intern("J")

var Lit_197 *jrt.String = jrt.Intern("0E")

var Lit_198 *jrt.String = jrt.Intern("XadL")

var Lit_199 *jrt.String = jrt.Intern("EE")

var Lit_200 *jrt.String = jrt.Intern("arbace.cpp.abi$template_arg$fn__677000267")

var Lit_201 *jrt.String = jrt.Intern("a dependent template name ")

var Lit_202 *jrt.String = jrt.Intern("1")

var Lit_203 *jrt.String = jrt.Intern("0")

var Lit_204 *jrt.String = jrt.Intern("template argument ")

var Lit_205 *jrt.String = jrt.Intern("T_")

var Lit_206 *jrt.String = jrt.Intern("Sa")

var Lit_207 *jrt.String = jrt.Intern("Sb")

var Lit_208 *jrt.String = jrt.Intern("arbace.cpp.abi$tspec_unwrapped$fn__677000254")

var Lit_209 *jrt.String = jrt.Intern("arbace.cpp.abi$unqualified_name$fn__677000317")

var Lit_210 *jrt.String = jrt.Intern("B")

var Lit_211 *jrt.String = jrt.Intern("CI")

var Lit_212 *jrt.String = jrt.Intern("D")

var Lit_213 *jrt.String = jrt.Intern("li")

var Lit_214 *jrt.String = jrt.Intern("arbace.cpp.abi$vbases$walk__677000055")

var Lit_215 *jrt.String = jrt.Intern("arbace.cpp.abi$vbases_init$walk__677000062")

var Lit_216 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn3,clsyn1,&yn3,msgkn4,linekn6,columnkn4,fileyn1,nkn4,voidkn4,boolkn4,charkn3,intkn4,uintkn4,longkn5,ulongkn6,doublekn5,floatkn7,nullptryn1,tkn5,scharkn5,ucharkn5,char8kn5,shortkn6,ushortkn6,char16kn6,char32kn5,wcharkn5,llongkn6,ullongkn4,i128kn4,u128yn1,ayn1,bkn7,dynamicyn2,idyn1,fyn4,argskn7,ldoublekn7,float16kn8,float128kn7,privatekn8,declaredkn3,tagyn4,longyn1,xyn3,topyn2,emyn3,lstyn4,fromyn2,toyn1,dyn3,bseyn6,value?yn16,java.lang.Stringyn6,Stringyn1,kyn1,cyn1,pyn3,tidyn5,partsv11,arbace.core5,in-nsMyn14,arbace.cpp.abim2,R0,s688,The C++ code generator's types and the Itanium C++ ABI's parts it needs (doc/cpp/CODEGEN.md §3, §4): the semantic\n  types of arbace.cpp.sema (maps with :k), the program's classes and enumerations (a registry by id), sizes and\n  alignments on x86-64 (LP64), the class layout of the Itanium ABI (§2.4: the vptr, the primary base, empty bases at\n  offset 0, a non-POD base's tail padding reused) and the Itanium mangling of names (§5.1: nested names, the\n  substitutions S_ S0_ ..., the special members' C1 C2 D0 D1 D2, operators, local statics). Written from the ABI's text\n  (itanium-cxx-abi.github.io/cxx-abi/abi.html) and checked against clang 23's output on the samples; no code ported.m2,R0,s688,The C++ code generator's types and the Itanium C++ ABI's parts it needs (doc/cpp/CODEGEN.md §3, §4): the semantic\n  types of arbace.cpp.sema (maps with :k), the program's classes and enumerations (a registry by id), sizes and\n  alignments on x86-64 (LP64), the class layout of the Itanium ABI (§2.4: the vptr, the primary base, empty bases at\n  offset 0, a non-POD base's tail padding reused) and the Itanium mangling of names (§5.1: nested names, the\n  substitutions S_ S0_ ..., the special members' C1 C2 D0 D1 D2, operators, local statics). Written from the ABI's text\n  (itanium-cxx-abi.github.io/cxx-abi/abi.html) and checked against clang 23's output on the samples; no code ported.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.cpp.abi4,failm8,R2,L1,V3,R3,R4,R5,R6,i13,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi1,bm8,R2,L1,V1,R9,R6,i19,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,voidR10,m6,R6,i20,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,bool*R11,m6,R6,i20,R7,i22,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,char*R12,m6,R6,i20,R7,i44,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,int*R13,m6,R6,i20,R7,i66,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,uint*R14,m6,R6,i20,R7,i86,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,long*R15,m6,R6,i21,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,ulong*R16,m6,R6,i21,R7,i23,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,double*R17,m6,R6,i21,R7,i47,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,float*R18,m6,R6,i21,R7,i73,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,nullptr-tR19,m6,R6,i21,R7,i97,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,ptrm8,R2,L1,V1,R20,R6,i22,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,lrefm8,R2,L1,V1,R20,R6,i23,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,rrefm8,R2,L1,V1,R20,R6,i24,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,arrm8,R2,L1,V2,R9,R20,R6,i25,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,unqm8,R2,L1,V1,R20,R6,i26,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,constqm8,R2,L1,V1,R20,R6,i27,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,kindm8,R2,L1,V1,R20,R6,i28,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi2,bnm8,R2,L1,V1,R20,R6,i29,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,void?m8,R2,L1,V1,R20,R6,i30,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,ref?m8,R2,L1,V1,R20,R6,i31,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,non-refm8,R2,L1,V1,R20,R6,i32,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,ptr?m8,R2,L1,V1,R20,R6,i33,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,class?m8,R2,L1,V1,R20,R6,i34,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,enum?m8,R2,L1,V1,R20,R6,i35,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,arr?m8,R2,L1,V1,R20,R6,i36,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,fn?m8,R2,L1,V1,R20,R6,i37,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,int-ranksm36,R11,l0,R12,l1,R21,l1,R22,l1,R23,l1,R24,l2,R25,l2,R26,l2,R13,l3,R14,l3,R27,l3,R28,l3,R15,l4,R16,l4,R29,l5,R30,l5,R31,l6,R32,l6,m6,R6,i38,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,unsigned-nsS10,R32,R30,R25,R14,R16,R23,R22,R11,R27,R26,m6,R6,i40,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,integral?m8,R2,L1,V1,R20,R6,i41,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,floating?m8,R2,L1,V1,R20,R6,i44,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,arith?m8,R2,L1,V1,R20,R6,i45,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,mptr?m8,R2,L1,V1,R20,R6,i46,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi8,mfn-ptr?m8,R2,L1,V1,R20,R6,i47,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,scalar?m8,R2,L1,V1,R20,R6,i48,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,same-type?m8,R2,L1,V2,R33,R34,R6,i49,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,*classes*m8,R35,TR6,i54,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,*enums*m8,R35,TR6,i55,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,clsm8,R2,L1,V1,R36,R6,i57,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,cls-ofm8,R2,L1,V1,R20,R6,i58,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,update-cls!m8,R2,L1,V4,R36,R37,R4,R38,R6,i59,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,enmm8,R2,L1,V1,R36,R6,i60,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,underlyingm8,R2,L1,V1,R20,R6,i62,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,scalar-sizem48,R11,l1,R12,l1,R21,l1,R22,l1,R23,l1,R24,l2,R25,l2,R26,l2,R13,l4,R14,l4,R27,l4,R28,l4,R15,l8,R16,l8,R29,l8,R30,l8,R31,l16,R32,l16,R18,l4,R17,l8,R39,l16,R40,l2,R41,l16,R19,l8,m8,R42,TR6,i67,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,layoutm8,R43,TR6,i70,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,size-alignm10,R2,L1,V1,R20,R0,s39,[size align] of a complete object type.R6,i72,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,size-ofm8,R2,L1,MV1,R20,m2,R44,R45,R6,i87,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi8,align-ofm8,R2,L1,MV1,R20,m2,R44,R45,R6,i88,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi8,align-upm8,R2,L1,MV2,Myn1,nm2,R44,R45,Myn1,am2,R44,R45,m2,R44,R45,R6,i89,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,vbasesm10,R2,L1,V1,R36,R0,s158,The class's virtual bases, direct and indirect, in inheritance graph order (Itanium §2.4 II.4: a pre-order of the\n  bases, each virtual base where first met).R6,i94,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,vbases-initm10,R2,L1,V1,R36,R0,s164,The virtual bases in the order the complete object's constructor initializes them ([class.base.init]/13.1, as\n  clang's vbases(): a base's virtual bases before it).R6,i102,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi8,dynamic?m10,R2,L1,V1,R36,R0,s92,Whether the class has a vptr (virtual functions of its own, a dynamic base, a virtual base).R6,i110,R7,i1,R8,s17,arbace/cpp/abi.aem8,R43,TR6,i113,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,nearly-empty?m10,R2,L1,V1,R36,R0,s54,A dynamic class with no data but its vptr (§2.4 II.3).R6,i115,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi18,indirect-primariesm12,R42,TR2,L1,V1,R36,R0,s98,The virtual bases that are the primary base of a base class of `id` (its hierarchy's, `id` aside).R6,i118,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,primary-basem10,R2,L1,V1,R36,R0,s275,The primary base (Itanium §2.4 II.3): the first non-virtual dynamic base, else the first nearly empty virtual base\n  (in the inheritance graph's pre-order) that is not an indirect primary base, else the first nearly empty one: the\n  base's entry ({:cls :virtual ...}) or nil.R6,i128,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,empty-class?m8,R43,TR6,i149,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,empty-member?m10,R2,L1,V1,R37,R0,s153,Whether field `f` is an empty data member (Itanium §1.1: a potentially-overlapping member, [[no_unique_address]], of an\n  empty class type; cpp-gatefix).R6,i151,R7,i1,R8,s17,arbace/cpp/abi.aem10,R2,L1,V1,R36,R0,s173,Itanium's empty class (§1.1): no non-static data members other than empty data members, no virtual functions or bases,\n  no non-empty bases (clang's CXXRecordDecl::isEmpty).R6,i157,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi15,pod-for-layout?m10,R2,L1,V1,R36,R0,s103,POD as C++03 defined it, which Itanium's layout uses to decide whether a base's tail padding is reused.R6,i163,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi21,nonvirtual-subobjectsm12,R42,TR2,L1,V2,R46,Myn3,offm2,R44,R45,R0,s88,[[class-id offset] ...] of the non-virtual subtree of class `x` at `off` (itself first).R6,i173,R7,i1,R8,s17,arbace/cpp/abi.aem8,R43,TR6,i180,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,class-emptiesm8,R43,TR6,i180,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,field-emptiesm12,R42,TR2,L1,V2,R20,Myn3,offm2,R44,R45,R0,s232,[[class-id offset] ...] of the empty-class subobjects of a field of type `t` at `off`, as clang's EmptySubobjectMap\n  (RecordLayoutBuilder.cpp) tracks them: a class-typed member as a most-derived object, an array element by element.R6,i182,R7,i1,R8,s17,arbace/cpp/abi.aem12,R42,TR2,L1,V3,R36,Myn3,offm2,R44,R45,R47,R0,s180,The empty subobjects of class `id` at `off`: `top` true for a member's class (virtual bases too), false for a base\n  subobject (its non-virtual bases and its primary virtual base).R6,i200,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,can-place?m10,R42,TR2,L1,V2,R48,R49,R6,i213,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,place!m10,R42,TR2,L1,V2,R48,R49,R6,i214,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,layout*m8,R43,TR6,i216,R7,i1,R8,s17,arbace/cpp/abi.aem10,R2,L1,V1,R36,R0,s372,The class's layout (Itanium §2.4), cached: {:size :align (the complete object's) :nvsize :nvalign :dsize (the\n  non-virtual part's, what a derived class lays out) :fields [offsets] :bitoffs [bit offsets of bit-fields] :bases\n  [offsets of the non-virtual bases, nil for virtual ones] :vbases {class-id offset} (in a complete object) :vptr bool\n  :primary {:cls :virtual}}.R6,i218,R7,i1,R8,s17,arbace/cpp/abi.aem10,R42,TR2,L1,V1,R36,R6,i230,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,field-offsetm8,R2,L1,MV2,R36,Myn1,im2,R44,R45,m2,R44,R45,R6,i354,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,base-pathm10,R2,L1,V2,R50,R51,R0,s264,The way from class `from` to its base `to`: [steps offset vbase] -- the [class-id base-index] steps, and the offset of\n  `to` from `from` when no step is virtual (vbase nil), else from the last virtual base on the way (vbase its id); nil\n  when `to` is not a base.R6,i356,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,derived-from?m8,R2,L1,V2,R52,R53,R6,i370,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,has-vbases?m8,R2,L1,V1,R36,R6,i371,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,llvm-typem10,R2,L2,V1,R20,V2,R20,R54,R0,s101,The LLVM type of a scalar value of type `t` in memory (bool i8) or as an operand (`:value`: bool i1).R6,i376,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,signed?m8,R2,L1,V1,R20,R6,i398,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi8,op-codesm86,s2,>>s2,rss2,&&s2,aas2,!=s2,nes1,=s2,aSs1,!s2,nts1,*s2,mls1,%s2,rms2,<=s2,les2,-=s2,mIs2,++s2,pps1,|s2,ors6,deletes2,dls1,~s2,cos1,/s2,dvs1,-s2,mis2,/=s2,dVs2,%=s2,rMs2,*=s2,mLs3,news2,nws2,|=s2,oRs3,<<=s2,lSs3,<=>s2,sss3,>>=s2,rSs2,[]s2,ixs2,>=s2,ges2,^=s2,eOs1,&s2,ans2,--s2,mms2,->s2,pts1,<s2,lts2,<<s2,lss1,,s2,cms8,delete[]s2,das2,&=s2,aNs2,+=s2,pLs5,new[]s2,nas2,||s2,oos2,()s2,cls2,==s2,eqs1,^s2,eos3,->*s2,pms1,+s2,pls1,>s2,gtm6,R6,i413,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi14,unary-op-codesm8,s1,+s2,pss1,-s2,ngs1,&s2,ads1,*s2,dem6,R6,i418,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,builtin-codesm50,R10,s1,vR11,s1,bR12,s1,cR21,s1,aR22,s1,hR24,s1,sR25,s1,tR13,s1,iR14,s1,jR15,s1,lR16,s1,mR29,s1,xR30,s1,yR31,s1,nR32,s1,oR18,s1,fR17,s1,dR39,s1,eR40,s5,DF16_R41,s1,gR19,s2,DnR28,s1,wR23,s2,DuR26,s2,DsR27,s2,Dim8,R42,TR6,i420,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,seq-idm10,R42,TR2,L1,MV1,Myn1,nm2,R44,R45,m2,R44,R55,R6,i424,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,source-namem8,R2,L1,MV1,Myn1,sm2,R44,R56,m2,R44,R55,R6,i428,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,*subs*m10,R42,TR35,TR6,i430,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,sub!m10,R42,TR2,L1,V2,R57,Myn1,sm2,R44,R56,R6,i432,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi6,sub-orm10,R42,TR2,L1,V2,R57,R37,R6,i436,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,*dollars*m8,R35,TR6,i440,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,dollar-name!m12,R42,TR2,L1,MV1,R58,m2,R44,R55,R0,s195,A closure's name in a function that is not inline: $_N, N counted per enclosing function in the order the closures\n  are first mangled (clang numbers them as its code generator first names them).R6,i442,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,part-namem10,R42,TR2,L1,MV1,R59,m2,R44,R55,R6,i453,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,mangle-type*m8,R43,TR6,i460,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,template-argsm8,R43,TR6,i460,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,part-targsm12,R42,TR2,L1,V1,R59,R0,s107,A class part's template arguments when the class is a template's specialization (CODEGEN.md §G3), else nil.R6,i462,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi15,template-prefixm12,R42,TR2,L1,MV3,Myn3,outm2,R44,R56,R60,Myn2,nmm2,R44,R56,m2,R44,R55,R0,s230,<template-prefix> ::= <prefix> <template unqualified-name>: `out` (the prefix as written so far) and the template's\n  name, or the template's substitution when it was seen (it stands for the prefix too); a new candidate otherwise.R6,i467,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi16,std-abbreviationm12,R42,TR2,L1,V1,R58,R0,s254,The Itanium ABI's abbreviation (§5.1.8) of a ::std class specialization `c`: Ss std::basic_string<char,\n  std::char_traits<char>, std::allocator<char>>, Si basic_istream<char, char_traits<char>>, So basic_ostream<...>,\n  Sd basic_iostream<...>; else nil.R6,i480,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,mangle-prefixm12,R42,TR2,L1,MV1,R61,m2,R44,R55,R0,s259,The prefix of the parts as written inside N ... E: the longest prefix already substituted as its S_, then each\n  further part, every prefix a new substitution candidate (a template specialization's part: its template-prefix a\n  candidate, then its arguments).R6,i497,R7,i1,R8,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,path-of-typem10,R2,L1,V1,R20,R0,s81,The scope path naming a class or enumeration type: its enclosing path and itself.R6,i521,R7,i1,R8,s17,arbace/cpp/abi.ae")

var Lit_217 *jrt.String = jrt.Intern("arbace.cpp.abi$eval677000004$loading__1927001464__auto____677000005")

var Lit_218 *jrt.String = jrt.Intern("arbace.cpp.abi$eval677000008$fn__677000009")

var Lit_219 *jrt.String = jrt.Intern("arbace.cpp.abi$fail")

var Lit_220 *jrt.String = jrt.Intern("arbace.cpp.abi$b")

var Lit_221 *jrt.String = jrt.Intern("arbace.cpp.abi$ptr")

var Lit_222 *jrt.String = jrt.Intern("arbace.cpp.abi$lref")

var Lit_223 *jrt.String = jrt.Intern("arbace.cpp.abi$rref")

var Lit_224 *jrt.String = jrt.Intern("arbace.cpp.abi$arr")

var Lit_225 *jrt.String = jrt.Intern("arbace.cpp.abi$unq")

var Lit_226 *jrt.String = jrt.Intern("arbace.cpp.abi$constq")

var Lit_227 *jrt.String = jrt.Intern("arbace.cpp.abi$kind")

var Lit_228 *jrt.String = jrt.Intern("arbace.cpp.abi$bn")

var Lit_229 *jrt.String = jrt.Intern("arbace.cpp.abi$void_QMARK_")

var Lit_230 *jrt.String = jrt.Intern("arbace.cpp.abi$ref_QMARK_")

var Lit_231 *jrt.String = jrt.Intern("arbace.cpp.abi$non_ref")

var Lit_232 *jrt.String = jrt.Intern("arbace.cpp.abi$ptr_QMARK_")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.abi$class_QMARK_")

var Lit_234 *jrt.String = jrt.Intern("arbace.cpp.abi$enum_QMARK_")

var Lit_235 *jrt.String = jrt.Intern("arbace.cpp.abi$arr_QMARK_")

var Lit_236 *jrt.String = jrt.Intern("arbace.cpp.abi$fn_QMARK_")

var Lit_237 *jrt.String = jrt.Intern("arbace.cpp.abi$integral_QMARK_")

var Lit_238 *jrt.String = jrt.Intern("arbace.cpp.abi$floating_QMARK_")

var Lit_239 *jrt.String = jrt.Intern("arbace.cpp.abi$arith_QMARK_")

var Lit_240 *jrt.String = jrt.Intern("arbace.cpp.abi$mptr_QMARK_")

var Lit_241 *jrt.String = jrt.Intern("arbace.cpp.abi$mfn_ptr_QMARK_")

var Lit_242 *jrt.String = jrt.Intern("arbace.cpp.abi$scalar_QMARK_")

var Lit_243 *jrt.String = jrt.Intern("arbace.cpp.abi$same_type_QMARK_")

var Lit_244 *jrt.String = jrt.Intern("arbace.cpp.abi$cls")

var Lit_245 *jrt.String = jrt.Intern("arbace.cpp.abi$cls_of")

var Lit_246 *jrt.String = jrt.Intern("arbace.cpp.abi$update_cls_BANG_")

var Lit_247 *jrt.String = jrt.Intern("arbace.cpp.abi$enm")

var Lit_248 *jrt.String = jrt.Intern("arbace.cpp.abi$underlying")

var Lit_249 *jrt.String = jrt.Intern("arbace.cpp.abi$size_align")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.abi$size_of")

var Lit_251 *jrt.String = jrt.Intern("arbace.cpp.abi$align_of")

var Lit_252 *jrt.String = jrt.Intern("arbace.cpp.abi$align_up")

var Lit_253 *jrt.String = jrt.Intern("arbace.cpp.abi$vbases")

var Lit_254 *jrt.String = jrt.Intern("arbace.cpp.abi$vbases_init")

var Lit_255 *jrt.String = jrt.Intern("arbace.cpp.abi$dynamic_QMARK_")

var Lit_256 *jrt.String = jrt.Intern("arbace.cpp.abi$nearly_empty_QMARK_")

var Lit_257 *jrt.String = jrt.Intern("arbace.cpp.abi$indirect_primaries")

var Lit_258 *jrt.String = jrt.Intern("arbace.cpp.abi$primary_base")

var Lit_259 *jrt.String = jrt.Intern("arbace.cpp.abi$empty_member_QMARK_")

var Lit_260 *jrt.String = jrt.Intern("arbace.cpp.abi$empty_class_QMARK_")

var Lit_261 *jrt.String = jrt.Intern("arbace.cpp.abi$pod_for_layout_QMARK_")

var Lit_262 *jrt.String = jrt.Intern("arbace.cpp.abi$nonvirtual_subobjects")

var Lit_263 *jrt.String = jrt.Intern("arbace.cpp.abi$field_empties")

var Lit_264 *jrt.String = jrt.Intern("arbace.cpp.abi$class_empties")

var Lit_265 *jrt.String = jrt.Intern("arbace.cpp.abi$can_place_QMARK_")

var Lit_266 *jrt.String = jrt.Intern("arbace.cpp.abi$place_BANG_")

var Lit_267 *jrt.String = jrt.Intern("arbace.cpp.abi$layout")

var Lit_268 *jrt.String = jrt.Intern("arbace.cpp.abi$layout_STAR_")

var Lit_269 *jrt.String = jrt.Intern("arbace.cpp.abi$field_offset")

var Lit_270 *jrt.String = jrt.Intern("arbace.cpp.abi$base_path")

var Lit_271 *jrt.String = jrt.Intern("arbace.cpp.abi$derived_from_QMARK_")

var Lit_272 *jrt.String = jrt.Intern("arbace.cpp.abi$has_vbases_QMARK_")

var Lit_273 *jrt.String = jrt.Intern("arbace.cpp.abi$llvm_type")

var Lit_274 *jrt.String = jrt.Intern("arbace.cpp.abi$signed_QMARK_")

var Lit_275 *jrt.String = jrt.Intern("arbace.cpp.abi$seq_id")

var Lit_276 *jrt.String = jrt.Intern("arbace.cpp.abi$source_name")

var Lit_277 *jrt.String = jrt.Intern("arbace.cpp.abi$sub_BANG_")

var Lit_278 *jrt.String = jrt.Intern("arbace.cpp.abi$sub_or")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.abi$dollar_name_BANG_")

var Lit_280 *jrt.String = jrt.Intern("arbace.cpp.abi$part_name")

var Lit_281 *jrt.String = jrt.Intern("arbace.cpp.abi$part_targs")

var Lit_282 *jrt.String = jrt.Intern("arbace.cpp.abi$template_prefix")

var Lit_283 *jrt.String = jrt.Intern("arbace.cpp.abi$std_abbreviation")

var Lit_284 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_prefix")

var Lit_285 *jrt.String = jrt.Intern("arbace.cpp.abi$path_of_type")

var Lit_286 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,xkn3,tagyn16,java.lang.Stringyn1,tkn3,docyn4,longyn1,ayn4,argsyn2,psyn2,vayn1,fyn7,variantyn1,nyn4,pidxyn1,vyn6,Stringyn7,derivedyn4,baseyn1,byn3,accyn3,clsyn2,idv14,arbace.cpp.abi14,local-encodingm8,R0,TR1,i528,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,local-encm10,R4,TR5,L1,MV1,R6,m2,R7,R8,R1,i529,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,mangle-namedm12,R4,TR5,L1,MV1,R9,m2,R7,R8,R10,s113,A class or enumeration type's name: a source name at the global scope, else N prefix E; a substitution candidate.R1,i531,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi14,template-paramm12,R4,TR5,L1,MV1,Myn1,im2,R7,R11,m2,R7,R8,R10,s91,<template-param>: T_ for the first, T<n-2>_ after (a parameter of depth 0: CODEGEN.md §G3).R1,i548,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi15,tspec-unwrappedm12,R4,TR5,L1,MV1,R9,m2,R7,R8,R10,s108,A dependent template-id's <prefix> <template-name> <template-args>, without the N ... E around a nested one.R1,i553,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,expr-op-codesm44,s2,>>s2,rss2,&&s2,aas2,!=s2,nes1,!s2,nts1,*s2,mls1,%s2,rms2,<=s2,les1,|s2,ors1,~s2,cos1,/s2,dvs1,-s2,mis1,?s2,qus3,negs2,ngs2,>=s2,ges1,&s2,ans1,<s2,lts2,<<s2,lss2,||s2,oos2,==s2,eqs1,^s2,eos1,+s2,pls1,>s2,gtm8,R4,TR1,i561,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,mangle-exprm12,R4,TR5,L1,MV1,R6,m2,R7,R8,R10,s300,<expression> of a dependent template argument (5.1.6): an int literal L i n E, a non-type parameter T_, an\n  operator's code and operands, sizeof's st <type>, a member of a dependent class sr <type> <name> (a template-id's\n  levels then E, its names no substitution candidates, as clang writes them).R1,i565,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,template-argm8,R0,TR1,i616,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,dt-unresolvedm12,R4,TR5,L1,MV1,R6,m2,R7,R8,R10,s194,<unresolved-name> of a dependent decltype's operand (clang's mangleUnresolvedName): [sr <namespace levels> E | sr\n  <unresolved-type>] <simple-id>, the simple-id's template arguments as written.R1,i618,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi14,mangle-dt-exprm12,R4,TR5,L1,MV1,R6,m2,R7,R8,R10,s351,The <expression> of a dependent decltype (sema's dt-ir data; Itanium 5.1.6, as clang's mangleExpression writes it):\n  calls cl ... E, function parameters fp_ (fpK_, fp0_ ...), this fpT, members dt/pt (an implicit this dtdefpT, as gcc\n  and clang), unresolved names, operators, literals, sizeof and alignof, casts and constructions (cv <type> _ ... E).R1,i627,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,dt-standin?m10,R4,TR5,L1,V1,R9,R1,i651,R2,i1,R3,s17,arbace/cpp/abi.aem12,R4,TR5,L1,MV1,R12,m2,R7,R8,R10,s109,<template-arg>: a type, or an integral value as <expr-primary> L <type> <number> E (n for a minus, bool 0/1).R1,i653,R2,i1,R3,s17,arbace/cpp/abi.aem8,R5,L1,MV1,R13,m2,R7,R8,R1,i684,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi3,cvqm10,R4,TR5,L1,MV1,R9,m2,R7,R8,R1,i686,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi4,skeym12,R4,TR5,L1,V1,R9,R10,s130,A type as a substitution key: a template parameter by its index alone (the signature's T_ and a constraint's are\n  one candidate).R1,i688,R2,i1,R3,s17,arbace/cpp/abi.aem10,R4,TR5,L1,MV1,R9,m2,R7,R8,R1,i698,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,bare-paramsm10,R4,TR5,L1,MV2,R14,R15,m2,R7,R8,R1,i742,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi13,mangle-paramsm10,R5,L1,MV1,R14,m2,R7,R8,R10,s66,A parameter list's mangling (v when empty), its own substitutions.R1,i745,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi17,unqualified-name*m8,R0,TR1,i748,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi16,unqualified-namem12,R4,TR5,L1,MV2,R16,R17,m2,R7,R8,R10,s206,A function's unqualified name: its source name, an operator's code, C1/C2/D0/D1/D2 for the special members; its ABI\n  tags after it (Itanium 5.1.2: <abi-tags> ::= B <source-name>..., GNU's abi_tag; cpp-s3).R1,i750,R2,i1,R3,s17,arbace/cpp/abi.aem10,R4,TR5,L1,MV2,R16,R17,m2,R7,R8,R1,i756,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi7,q-paramm12,R4,TR5,L1,MV2,Myn5,depthm2,R7,R11,Myn1,im2,R7,R11,m2,R7,R8,R10,s182,A template parameter of depth `depth` in a constraint ([temp.param]; ItaniumMangle.cpp's mangleTemplateParameter:\n  T_, T<n-1>_, TL<d-1>__, TL<d-1>_<n-1>_), a substitution candidate.R1,i776,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi17,mangle-constraintm12,R4,TR5,L1,MV3,R18,R19,Myn5,depthm2,R7,R11,m2,R7,R8,R10,s399,A requires-clause's expression (the native parser's node) as clang 23 mangles it after a function template's\n  arguments (Q <expression>; ItaniumMangle.cpp's mangleRequiresClause, mangleExpression): operators, calls, names as\n  written (an unresolved simple name with its explicit arguments), the template's own parameters by depth and index;\n  `pidx` {name index} of the template's parameters (G4).R1,i782,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,encoding*m8,R0,TR1,i849,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi9,mangle-fnm10,R5,L2,MV1,R16,m2,R7,R8,MV2,R16,R17,m2,R7,R8,R10,s324,A function's mangled name (variant: 1 or 2 for a constructor's C1/C2, 0/1/2 for a destructor's D0/D1/D2). A\n  function template's specialization (:tinst) writes its template arguments after its name, then its template's\n  signature with the return type (§5.1.3: the parameters as the template declares them, T_ for its own).R1,i851,R2,i1,R3,s17,arbace/cpp/abi.aem12,R4,TR5,L1,MV2,R16,R17,m2,R7,R8,R10,s219,A function's <encoding> (its mangled name without _Z) in the current substitution table: a local entity's\n  Z <encoding> E <entity> shares it with the enclosing function's encoding (ItaniumMangle.cpp's mangleLocalName).R1,i862,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi10,mangle-varm10,R5,L1,MV1,R20,m2,R7,R8,R10,s115,A variable's mangled name at namespace or class scope (a global in the global namespace keeps its name; static: L).R1,i909,R2,i1,R3,s17,arbace/cpp/abi.aem10,R5,L1,MV1,R16,m2,R7,R8,R10,s147,A function's encoding as a local name's prefix: its mangled name without _Z (main's: 4main), in the current\n  substitution table when one is bound.R1,i929,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi19,mangle-local-staticm10,R5,L1,MV3,R16,Myn2,nmm2,R7,R21,Myn4,discm2,R7,R11,m2,R7,R8,R10,s114,A static local's name in the function f (Itanium §5.1.6: Z encoding E name, the discriminator _N from the second).R1,i940,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi16,mangle-type-namem10,R5,L1,MV1,R9,m2,R7,R8,R10,s58,The mangling of a class type alone (for _ZTV, _ZTI, _ZTS).R1,i946,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi23,mangle-ctor-vtable-namem10,R5,L1,MV3,R22,Myn3,offm2,R7,R11,R23,m2,R7,R8,R10,s165,A construction vtable's name, _ZTC <derived> <offset> _ <base>: one name, its substitutions shared by the two types\n  (ECPublicKeyIS0_E after 12ECPrivateKeyI4EC2NE).R1,i951,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi11,merge-classm10,R4,TR5,L1,V2,R12,R24,R1,i962,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi12,scalar-classm10,R4,TR5,L1,V1,R9,R1,i966,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi5,mark!m10,R4,TR5,L1,V4,R25,Myn1,em2,R7,R11,R26,Myn3,endm2,R7,R11,R1,i972,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi14,classify-into!m12,R4,TR5,L1,V3,R25,R9,Myn3,offm2,R7,R11,R10,s123,Merges the classes of the object of type `t` at byte `off` into the eightbytes (`acc`, an atom of [lo hi lo-end\n  hi-end]).R1,i975,R2,i1,R3,s17,arbace/cpp/abi.aev14,arbace.cpp.abi14,classify-classm10,R5,L1,V1,R27,R10,s140,How a class of trivially copyable type passes by value: :ignore (an empty class), :memory, or the eightbytes'\n  [[:integer|:sse bytes] ...].R1,i1005,R2,i1,R3,s17,arbace/cpp/abi.ae")

var Lit_287 *jrt.String = jrt.Intern("arbace.cpp.abi$local_enc")

var Lit_288 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_named")

var Lit_289 *jrt.String = jrt.Intern("arbace.cpp.abi$template_param")

var Lit_290 *jrt.String = jrt.Intern("arbace.cpp.abi$tspec_unwrapped")

var Lit_291 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_expr")

var Lit_292 *jrt.String = jrt.Intern("arbace.cpp.abi$dt_unresolved")

var Lit_293 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_dt_expr")

var Lit_294 *jrt.String = jrt.Intern("arbace.cpp.abi$dt_standin_QMARK_")

var Lit_295 *jrt.String = jrt.Intern("arbace.cpp.abi$template_arg")

var Lit_296 *jrt.String = jrt.Intern("arbace.cpp.abi$template_args")

var Lit_297 *jrt.String = jrt.Intern("arbace.cpp.abi$cvq")

var Lit_298 *jrt.String = jrt.Intern("arbace.cpp.abi$skey")

var Lit_299 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_STAR_")

var Lit_300 *jrt.String = jrt.Intern("arbace.cpp.abi$bare_params")

var Lit_301 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_params")

var Lit_302 *jrt.String = jrt.Intern("arbace.cpp.abi$unqualified_name")

var Lit_303 *jrt.String = jrt.Intern("arbace.cpp.abi$unqualified_name_STAR_")

var Lit_304 *jrt.String = jrt.Intern("arbace.cpp.abi$q_param")

var Lit_305 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_constraint")

var Lit_306 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_fn")

var Lit_307 *jrt.String = jrt.Intern("arbace.cpp.abi$encoding_STAR_")

var Lit_308 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_var")

var Lit_309 *jrt.String = jrt.Intern("arbace.cpp.abi$local_encoding")

var Lit_310 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_local_static")

var Lit_311 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_type_name")

var Lit_312 *jrt.String = jrt.Intern("arbace.cpp.abi$mangle_ctor_vtable_name")

var Lit_313 *jrt.String = jrt.Intern("arbace.cpp.abi$merge_class")

var Lit_314 *jrt.String = jrt.Intern("arbace.cpp.abi$scalar_class")

var Lit_315 *jrt.String = jrt.Intern("arbace.cpp.abi$mark_BANG_")

var Lit_316 *jrt.String = jrt.Intern("arbace.cpp.abi$classify_into_BANG_")

var Lit_317 *jrt.String = jrt.Intern("arbace.cpp.abi$classify_class")
