//line aot_arbace_cpp_abi.ae:1
package aot_arbace_cpp_abi

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A_New() *A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_cpp_abi_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_cpp_abi_A_const_3, A_arbace_cpp_abi_A_const_4, A_arbace_cpp_abi_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_cpp_abi_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_abi_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_cpp_abi_eval677000008_fn__677000009_A_New() *A_arbace_cpp_abi_eval677000008_fn__677000009_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_eval677000008_fn__677000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_cpp_abi_eval677000008_fn__677000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_cpp_abi_eval677000008_fn__677000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_cpp_abi_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_cpp_abi_A_const_9.GetRawRoot__O(), A_arbace_cpp_abi_A_const_10) }











func A_arbace_cpp_abi_fail_A_New() *A_arbace_cpp_abi_fail_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_fail_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_cpp_abi_fail_A) Ctor() {}
//line :13:1
func (t *A_arbace_cpp_abi_fail_A) DoInvoke_O_O_O__O(self, cls__0, msg__1 any) any { var temp__1927000414__auto____3 any = jrt.System_Getenv_String__String(Lit_38).Ref(); if jrt.J2g_Truth(temp__1927000414__auto____3) { var s__4 any = temp__1927000414__auto____3; var tmp1 any; var root_31 any = A_arbace_cpp_abi_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var root_36 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_40 any = msg__1; if linked_37 == nil { arg_34 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }; var arg_35 any = s__4; if linked_32 == nil { tmp1 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { tmp1 = linked_32.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_41 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_45 any = msg__1; if linked_42 == nil { tmp2 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp2 = linked_42.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; jrt.Exception_New_String(jrt.String_Cast(tmp2)).PrintStackTrace__V() } }; var tmp3 any; var root_21 any = A_arbace_cpp_abi_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_39, nil); var tmp5 any; var root_26 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_30 any = msg__1; if linked_27 == nil { tmp5 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { tmp5 = linked_27.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; arg_24 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref(); var arg_25 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_14, cls__0)); if linked_22 == nil { tmp3 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp3 = linked_22.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) }





func A_arbace_cpp_abi_b_A_New() *A_arbace_cpp_abi_b_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_b_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_cpp_abi_b_A) Ctor() {}
//line :19:1
func (t *A_arbace_cpp_abi_b_A) Invoke_O_O__O(self, n__0 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_17, A_arbace_cpp_abi_A_const_18, n__0)) }


func A_arbace_cpp_abi_ptr_A_New() *A_arbace_cpp_abi_ptr_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_ptr_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_cpp_abi_ptr_A) Ctor() {}
//line :22:1
func (t *A_arbace_cpp_abi_ptr_A) Invoke_O_O__O(self, t__0 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_19, A_arbace_cpp_abi_A_const_20, t__0)) }
func A_arbace_cpp_abi_lref_A_New() *A_arbace_cpp_abi_lref_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_lref_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_cpp_abi_lref_A) Ctor() {}
//line :23:1
func (t *A_arbace_cpp_abi_lref_A) Invoke_O_O__O(self, t__0 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_21, A_arbace_cpp_abi_A_const_20, t__0)) }
func A_arbace_cpp_abi_rref_A_New() *A_arbace_cpp_abi_rref_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_rref_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_cpp_abi_rref_A) Ctor() {}
//line :24:1
func (t *A_arbace_cpp_abi_rref_A) Invoke_O_O__O(self, t__0 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_22, A_arbace_cpp_abi_A_const_20, t__0)) }
func A_arbace_cpp_abi_arr_A_New() *A_arbace_cpp_abi_arr_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_arr_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_cpp_abi_arr_A) Ctor() {}
//line :25:1
func (t *A_arbace_cpp_abi_arr_A) Invoke_O_O_O__O(self, n__0, t__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_23, A_arbace_cpp_abi_A_const_18, n__0, A_arbace_cpp_abi_A_const_24, t__1)) }
func A_arbace_cpp_abi_unq_A_New() *A_arbace_cpp_abi_unq_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_unq_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_cpp_abi_unq_A) Ctor() {}
//line :26:1
func (t *A_arbace_cpp_abi_unq_A) Invoke_O_O__O(self, t__0 any) any { return lang.IFn_Cast(A_arbace_cpp_abi_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(t__0, A_arbace_cpp_abi_A_const_26, A_arbace_cpp_abi_A_const_27) }
func A_arbace_cpp_abi_constq_A_New() *A_arbace_cpp_abi_constq_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_constq_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_cpp_abi_constq_A) Ctor() {}
//line :27:1
func (t *A_arbace_cpp_abi_constq_A) Invoke_O_O__O(self, t__0 any) any { var root_52 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = t__0; var arg_56 any = A_arbace_cpp_abi_A_const_26; var arg_57 any = jrt.Boolean_TRUE.Ref(); if linked_53 == nil { return ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { return linked_53.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
func A_arbace_cpp_abi_kind_A_New() *A_arbace_cpp_abi_kind_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_kind_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_cpp_abi_kind_A) Ctor() {}
//line :28:1
func (t *A_arbace_cpp_abi_kind_A) Invoke_O_O__O(self, t__0 any) any { return A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0) }
func A_arbace_cpp_abi_bn_A_New() *A_arbace_cpp_abi_bn_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_bn_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_cpp_abi_bn_A) Ctor() {}
//line :29:1
func (t *A_arbace_cpp_abi_bn_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_17; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0)) { return A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__0) } else { return nil } }
func A_arbace_cpp_abi_void_QMARK__A_New() *A_arbace_cpp_abi_void_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_void_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_cpp_abi_void_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_cpp_abi_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_29; var tmp2 any; var root_58 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_cpp_abi_bn_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = t__0; if linked_59 == nil { tmp2 = ifn_60.Invoke_O__O(arg_61) } else { tmp2 = linked_59.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_58, arg_61) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_cpp_abi_ref_QMARK__A_New() *A_arbace_cpp_abi_ref_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_ref_QMARK__A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_cpp_abi_ref_QMARK__A) Ctor() {}
//line :31:1
func (t *A_arbace_cpp_abi_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_31); return tmp1.Invoke_O__O(A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0)) }
func A_arbace_cpp_abi_non_ref_A_New() *A_arbace_cpp_abi_non_ref_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_non_ref_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_cpp_abi_non_ref_A) Ctor() {}
//line :32:1
func (t *A_arbace_cpp_abi_non_ref_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var root_62 any = A_arbace_cpp_abi_A_const_32.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, A_arbace_cpp_abi_ref_QMARK__A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = t__0; if linked_63 == nil { tmp1 = ifn_64.Invoke_O__O(arg_65) } else { tmp1 = linked_63.(*A_arbace_cpp_abi_ref_QMARK__A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(tmp1) { return A_arbace_cpp_abi_A_const_20.Invoke_O__O(t__0) } else { return t__0 } }
func A_arbace_cpp_abi_ptr_QMARK__A_New() *A_arbace_cpp_abi_ptr_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_ptr_QMARK__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_cpp_abi_ptr_QMARK__A) Ctor() {}
//line :33:1
func (t *A_arbace_cpp_abi_ptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_19; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }
func A_arbace_cpp_abi_class_QMARK__A_New() *A_arbace_cpp_abi_class_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_class_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_cpp_abi_class_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_cpp_abi_class_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_33; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }
func A_arbace_cpp_abi_enum_QMARK__A_New() *A_arbace_cpp_abi_enum_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_enum_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_cpp_abi_enum_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_cpp_abi_enum_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_34; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }
func A_arbace_cpp_abi_arr_QMARK__A_New() *A_arbace_cpp_abi_arr_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_arr_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_cpp_abi_arr_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_cpp_abi_arr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_23; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }
func A_arbace_cpp_abi_fn_QMARK__A_New() *A_arbace_cpp_abi_fn_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_fn_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_cpp_abi_fn_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_cpp_abi_fn_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }



func A_arbace_cpp_abi_integral_QMARK__A_New() *A_arbace_cpp_abi_integral_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_integral_QMARK__A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_cpp_abi_integral_QMARK__A) Ctor() {}
//line :41:1
func (t *A_arbace_cpp_abi_integral_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_66 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_cpp_abi_A_const_37.GetRawRoot__O(); var arg_70 any; var root_71 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_cpp_abi_bn_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = t__0; if linked_72 == nil { arg_70 = ifn_73.Invoke_O__O(arg_74) } else { arg_70 = linked_72.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_71, arg_74) }; if linked_67 == nil { or__1927000174__auto____2 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { or__1927000174__auto____2 = linked_67.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_75 any = A_arbace_cpp_abi_A_const_38.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_cpp_abi_enum_QMARK__A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = t__0; if linked_76 == nil { return ifn_77.Invoke_O__O(arg_78) } else { return linked_76.(*A_arbace_cpp_abi_enum_QMARK__A).Invoke_O_O__O(root_75, arg_78) } } }


func A_arbace_cpp_abi_floating_QMARK__A_New() *A_arbace_cpp_abi_floating_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_floating_QMARK__A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_cpp_abi_floating_QMARK__A) Ctor() {}
//line :44:1
func (t *A_arbace_cpp_abi_floating_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_39); var tmp2 any; var root_79 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, A_arbace_cpp_abi_bn_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = t__0; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_79, arg_82) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_cpp_abi_arith_QMARK__A_New() *A_arbace_cpp_abi_arith_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_arith_QMARK__A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_cpp_abi_arith_QMARK__A) Ctor() {}
//line :45:1
func (t *A_arbace_cpp_abi_arith_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_83 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = A_arbace_cpp_abi_A_const_37.GetRawRoot__O(); var arg_87 any; var root_88 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, A_arbace_cpp_abi_bn_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = t__0; if linked_89 == nil { arg_87 = ifn_90.Invoke_O__O(arg_91) } else { arg_87 = linked_89.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_88, arg_91) }; if linked_84 == nil { or__1927000174__auto____2 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { or__1927000174__auto____2 = linked_84.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_92 any = A_arbace_cpp_abi_A_const_40.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_cpp_abi_floating_QMARK__A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t__0; if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*A_arbace_cpp_abi_floating_QMARK__A).Invoke_O_O__O(root_92, arg_95) } } }
func A_arbace_cpp_abi_mptr_QMARK__A_New() *A_arbace_cpp_abi_mptr_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mptr_QMARK__A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_cpp_abi_mptr_QMARK__A) Ctor() {}
//line :46:1
func (t *A_arbace_cpp_abi_mptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_41; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() }
func A_arbace_cpp_abi_mfn_ptr_QMARK__A_New() *A_arbace_cpp_abi_mfn_ptr_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mfn_ptr_QMARK__A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_cpp_abi_mfn_ptr_QMARK__A) Ctor() {}
//line :47:1
func (t *A_arbace_cpp_abi_mfn_ptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_96 any = A_arbace_cpp_abi_A_const_42.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_cpp_abi_mptr_QMARK__A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = t__0; if linked_97 == nil { and__1927000168__auto____2 = ifn_98.Invoke_O__O(arg_99) } else { and__1927000168__auto____2 = linked_97.(*A_arbace_cpp_abi_mptr_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_cpp_abi_A_const_35; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_cpp_abi_A_const_20.Invoke_O__O(t__0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_cpp_abi_scalar_QMARK__A_New() *A_arbace_cpp_abi_scalar_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_scalar_QMARK__A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_cpp_abi_scalar_QMARK__A) Ctor() {}
//line :48:1
func (t *A_arbace_cpp_abi_scalar_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_100 any = A_arbace_cpp_abi_A_const_43.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_cpp_abi_arith_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = t__0; if linked_101 == nil { or__1927000174__auto____2 = ifn_102.Invoke_O__O(arg_103) } else { or__1927000174__auto____2 = linked_101.(*A_arbace_cpp_abi_arith_QMARK__A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_104 any = A_arbace_cpp_abi_A_const_38.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, A_arbace_cpp_abi_enum_QMARK__A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = t__0; if linked_105 == nil { or__1927000174__auto____3 = ifn_106.Invoke_O__O(arg_107) } else { or__1927000174__auto____3 = linked_105.(*A_arbace_cpp_abi_enum_QMARK__A).Invoke_O_O__O(root_104, arg_107) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_108 any = A_arbace_cpp_abi_A_const_44.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_cpp_abi_ptr_QMARK__A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = t__0; if linked_109 == nil { or__1927000174__auto____4 = ifn_110.Invoke_O__O(arg_111) } else { or__1927000174__auto____4 = linked_109.(*A_arbace_cpp_abi_ptr_QMARK__A).Invoke_O_O__O(root_108, arg_111) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var or__1927000174__auto____5 bool; var tmp1 any = A_arbace_cpp_abi_A_const_45; var tmp2 any; var root_112 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_cpp_abi_bn_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = t__0; if linked_113 == nil { tmp2 = ifn_114.Invoke_O__O(arg_115) } else { tmp2 = linked_113.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_112, arg_115) }; or__1927000174__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_116 any = A_arbace_cpp_abi_A_const_42.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, A_arbace_cpp_abi_mptr_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = t__0; if linked_117 == nil { return ifn_118.Invoke_O__O(arg_119) } else { return linked_117.(*A_arbace_cpp_abi_mptr_QMARK__A).Invoke_O_O__O(root_116, arg_119) } } } } } }
func A_arbace_cpp_abi_same_type_QMARK__A_New() *A_arbace_cpp_abi_same_type_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_same_type_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_cpp_abi_same_type_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_cpp_abi_same_type_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var tmp1 any; var root_120 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, A_arbace_cpp_abi_unq_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = a__0; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_120, arg_123) }; var tmp2 any = tmp1; var tmp3 any; var root_124 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, A_arbace_cpp_abi_unq_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = b__1; if linked_125 == nil { tmp3 = ifn_126.Invoke_O__O(arg_127) } else { tmp3 = linked_125.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_124, arg_127) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }







func A_arbace_cpp_abi_cls_A_New() *A_arbace_cpp_abi_cls_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_cls_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_cpp_abi_cls_A) Ctor() {}
//line :57:1
func (t *A_arbace_cpp_abi_cls_A) Invoke_O_O__O(self, id__0 any) any { var tmp1 any; var root_128 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = A_arbace_cpp_abi_A_const_47.Get__O(); if linked_129 == nil { tmp1 = ifn_130.Invoke_O__O(arg_131) } else { tmp1 = linked_129.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_128, arg_131) }; return lang.RT_Get_O_O__O_NoInit(tmp1, id__0) }
func A_arbace_cpp_abi_cls_of_A_New() *A_arbace_cpp_abi_cls_of_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_cls_of_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_cpp_abi_cls_of_A) Ctor() {}
//line :58:1
func (t *A_arbace_cpp_abi_cls_of_A) Invoke_O_O__O(self, t__0 any) any { var root_132 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_cpp_abi_cls_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_49; var tmp2 any; var root_136 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_cpp_abi_unq_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t__0; if linked_137 == nil { tmp2 = ifn_138.Invoke_O__O(arg_139) } else { tmp2 = linked_137.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_136, arg_139) }; arg_135 = tmp1.Invoke_O__O(tmp2); if linked_133 == nil { return ifn_134.Invoke_O__O(arg_135) } else { return linked_133.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_132, arg_135) } }
func A_arbace_cpp_abi_update_cls_BANG__A_New() *A_arbace_cpp_abi_update_cls_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_update_cls_BANG__A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_cpp_abi_update_cls_BANG__A) Ctor() {}
//line :59:1
func (t *A_arbace_cpp_abi_update_cls_BANG__A) DoInvoke_O_O_O_O__O(self, id__0, f__1, args__2 any) any { return lang.IFn_Cast(A_arbace_cpp_abi_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_cpp_abi_A_const_50.GetRawRoot__O(), A_arbace_cpp_abi_A_const_47.Get__O(), A_arbace_cpp_abi_A_const_51.GetRawRoot__O(), id__0, f__1, args__2) }
func A_arbace_cpp_abi_enm_A_New() *A_arbace_cpp_abi_enm_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_enm_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_cpp_abi_enm_A) Ctor() {}
//line :60:1
func (t *A_arbace_cpp_abi_enm_A) Invoke_O_O__O(self, id__0 any) any { var tmp1 any; var root_149 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = A_arbace_cpp_abi_A_const_52.Get__O(); if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_149, arg_152) }; return lang.RT_Get_O_O__O_NoInit(tmp1, id__0) }

func A_arbace_cpp_abi_underlying_A_New() *A_arbace_cpp_abi_underlying_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_underlying_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_cpp_abi_underlying_A) Ctor() {}
//line :62:1
func (t *A_arbace_cpp_abi_underlying_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var root_153 any = A_arbace_cpp_abi_A_const_38.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_cpp_abi_enum_QMARK__A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = t__0; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*A_arbace_cpp_abi_enum_QMARK__A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_53; var tmp3 any; var root_157 any = A_arbace_cpp_abi_A_const_54.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_cpp_abi_enm_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0); if linked_158 == nil { tmp3 = ifn_159.Invoke_O__O(arg_160) } else { tmp3 = linked_158.(*A_arbace_cpp_abi_enm_A).Invoke_O_O__O(root_157, arg_160) }; or__1927000174__auto____2 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_cpp_abi_A_const_55.GetRawRoot__O() } } else { return t__0 } }









func A_arbace_cpp_abi_size_align_A_New() *A_arbace_cpp_abi_size_align_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_size_align_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_cpp_abi_size_align_A) Ctor() {}
//line :72:1
func (t *A_arbace_cpp_abi_size_align_A) Invoke_O_O__O(self, t__0 any) any { var G__677000044__2_ any = A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0); switch


	lang.Util_Hash_O__I_NoInit(G__677000044__2_) >> 2 & 63 { case 2: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_22) { return A_arbace_cpp_abi_A_const_56 }; case 3: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_57) { var vec__677000045__3 any; var root_162 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_164 lang.IFn








		if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t__0); if linked_163 == nil { vec__677000045__3 = ifn_164.Invoke_O__O(arg_165) } else { vec__677000045__3 = linked_163.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_162, arg_165) }
//line :75:1
		var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000045__3, lang.RT_IntCast_J__I_NoInit(0), nil); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000045__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, lang.RT_LongCast_O__J_NoInit(s__4))).Ref(), a__5) }; case 10: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_33) { var l__3 any; var root_166 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_cpp_abi_layout_A_fn_class); var ifn_168 lang.IFn




			if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0); if linked_167 == nil { l__3 = ifn_168.Invoke_O__O(arg_169) } else { l__3 = linked_167.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_166, arg_169) }
//line :75:1
			return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_65.Invoke_O__O(l__3), A_arbace_cpp_abi_A_const_66.Invoke_O__O(l__3)) }; case 26: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_41) {






				var tmp1 any = A_arbace_cpp_abi_A_const_35; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_16; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_cpp_abi_A_const_20.Invoke_O__O(t__0))) { return A_arbace_cpp_abi_A_const_60 } else { return A_arbace_cpp_abi_A_const_61 } }
//line :75:1
	case 42: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_23) { var vec__677000048__3 any; var root_180 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_182 lang.IFn



		if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t__0); if linked_181 == nil { vec__677000048__3 = ifn_182.Invoke_O__O(arg_183) } else { vec__677000048__3 = linked_181.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_180, arg_183) }
//line :75:1
		var s__4_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var a__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 int64 = lang.RT_LongCast_O__J_NoInit(s__4_2); var tmp4 any; var or__1927000174__auto____6 any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__0)



		if jrt.J2g_Truth(or__1927000174__auto____6) { tmp4 = or__1927000174__auto____6 } else { tmp4 = A_arbace_cpp_abi_A_const_68 }
//line :75:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(tmp3, lang.RT_LongCast_O__J_NoInit(tmp4))).Ref(), a__5_2) }; case 49: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_21) { return A_arbace_cpp_abi_A_const_67 }; case 52: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_19) { return A_arbace_cpp_abi_A_const_69 }; case 55: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_35) { return A_arbace_cpp_abi_A_const_70 }; case 59: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_17) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_71.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__0))
			if jrt.J2g_Truth(temp__1927000408__auto____3) { var s__4_3 any = temp__1927000408__auto____3; return lang.Tuple_Create_O_O__IPersistentVector(s__4_3, s__4_3) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_cpp_abi_A_const_63; return tmp5.Invoke_O_O_O__O(tmp6, Lit_182, A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__0)) } }
//line :75:1
	case 60: if any(G__677000044__2_) == any(A_arbace_cpp_abi_A_const_34) {


		var root_190 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_194 any = A_arbace_cpp_abi_A_const_72.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_cpp_abi_underlying_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = t__0; if linked_195 == nil { arg_193 = ifn_196.Invoke_O__O(arg_197) } else { arg_193 = linked_195.(*A_arbace_cpp_abi_underlying_A).Invoke_O_O__O(root_194, arg_197) }; if linked_191 == nil { return ifn_192.Invoke_O__O(arg_193) } else { return linked_191.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_190, arg_193) } }
//line :75:1
	default:}; var tmp7 lang.IFn =









	lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_cpp_abi_A_const_63; return tmp7.Invoke_O_O_O__O(tmp8, Lit_182, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(t__0)) }

func A_arbace_cpp_abi_size_of_A_New() *A_arbace_cpp_abi_size_of_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_size_of_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_cpp_abi_size_of_A) Ctor() {}
//line :87:1
func (t *A_arbace_cpp_abi_size_of_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var root_198 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any; var root_202 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = t__0; if linked_203 == nil { arg_201 = ifn_204.Invoke_O__O(arg_205) } else { arg_201 = linked_203.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_202, arg_205) }; if linked_199 == nil { tmp1 = ifn_200.Invoke_O__O(arg_201) } else { tmp1 = linked_199.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_198, arg_201) }; return lang.RT_LongCast_O__J_NoInit(tmp1) }
//line :87:1
func (t *A_arbace_cpp_abi_size_of_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }
func A_arbace_cpp_abi_align_of_A_New() *A_arbace_cpp_abi_align_of_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_align_of_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_cpp_abi_align_of_A) Ctor() {}
//line :88:1
func (t *A_arbace_cpp_abi_align_of_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var root_206 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var root_210 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = t__0; if linked_211 == nil { arg_209 = ifn_212.Invoke_O__O(arg_213) } else { arg_209 = linked_211.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_210, arg_213) }; if linked_207 == nil { tmp1 = ifn_208.Invoke_O__O(arg_209) } else { tmp1 = linked_207.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_206, arg_209) }; return lang.RT_LongCast_O__J_NoInit(tmp1) }
//line :88:1
func (t *A_arbace_cpp_abi_align_of_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }
func A_arbace_cpp_abi_align_up_A_New() *A_arbace_cpp_abi_align_up_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_align_up_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_cpp_abi_align_up_A) Ctor() {}
//line :89:1
func (t *A_arbace_cpp_abi_align_up_A) InvokePrim_O_J_J__J(self any, n__0, a__1 int64) int64 { return lang.Numbers_Multiply_J_J__J_NoInit(a__1, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(n__0, lang.Numbers_Dec_J__J_NoInit(a__1)), a__1)) }
//line :89:1
func (t *A_arbace_cpp_abi_align_up_A) Invoke_O_O_O__O(self, p_n__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_n__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }




func A_arbace_cpp_abi_vbases_A_New() *A_arbace_cpp_abi_vbases_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_vbases_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_cpp_abi_vbases_A) Ctor() {}
//line :94:1
func (t *A_arbace_cpp_abi_vbases_A) Invoke_O_O__O(self, id__0 any) any { var seen__2 any = jrt.LinkedHashSet_New(); var tmp1 *lang.Compiler_AOTFn; var fnbody__251 any = A_arbace_cpp_abi_vbases_walk__677000055_A_New_O(seen__2); var tmp2 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_cpp_abi_vbases_walk__677000055_A_fn_class; if




	fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_214, false, fnbody__251); A_arbace_cpp_abi_vbases_walk__677000055_A_fn_class = fncls__250d; tmp2 = fncls__250d } else { tmp2 = fncls__250 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__251, tmp2, nil); Up_Compiler_AOTFn_IFn(tmp1).Invoke_O__O(id__0); var root_214 any =
	A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = seen__2; if linked_215 == nil { return ifn_216.Invoke_O__O(arg_217) } else { return linked_215.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_214, arg_217) } }
//line :99:1
func A_arbace_cpp_abi_vbases_walk__677000055_A_New_O(p0 any) *A_arbace_cpp_abi_vbases_walk__677000055_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_vbases_walk__677000055_A{}; t.Ctor_O(p0); return t }
//line :99:1
func (t *A_arbace_cpp_abi_vbases_walk__677000055_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :99:1
func (t *A_arbace_cpp_abi_vbases_walk__677000055_A) Invoke_O_O__O(self, x__1 any) any { { var seq_677000056__2 any; var root_218 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp2 any; var root_222 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, A_arbace_cpp_abi_cls_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = x__1; if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_222, arg_225) }; arg_221 = tmp1.Invoke_O__O(tmp2); if linked_219 == nil { seq_677000056__2 = ifn_220.Invoke_O__O(arg_221) } else { seq_677000056__2 = linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) }; var chunk_677000057__3 any; var count_677000058__4 int64 = 0; var i_677000059__5 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_677000059__5, count_677000058__4) { var b__6 any = lang.Indexed_Cast(chunk_677000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000059__5)); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__6)) { var tmp3 jrt.HashSet_I = jrt.HashSet_Cast(t.F_seen); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6))) }; lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6)); seq_677000056__2, chunk_677000057__3, count_677000058__4, i_677000059__5 = seq_677000056__2, chunk_677000057__3, count_677000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000059__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_226 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = seq_677000056__2; if linked_227 == nil { temp__1927000414__auto____6 = ifn_228.Invoke_O__O(arg_229) } else { temp__1927000414__auto____6 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_677000056__7 any = temp__1927000414__auto____6; var tmp4 any; var root_230 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = seq_677000056__7; if linked_231 == nil { tmp4 = ifn_232.Invoke_O__O(arg_233) } else { tmp4 = linked_231.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_230, arg_233) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____8 any; var root_234 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_677000056__7; if linked_235 == nil { c__1927000678__auto____8 = ifn_236.Invoke_O__O(arg_237) } else { c__1927000678__auto____8 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_234, arg_237) }; var tmp5 any; var root_242 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_677000056__7; if linked_243 == nil { tmp5 = ifn_244.Invoke_O__O(arg_245) } else { tmp5 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_242, arg_245) }; seq_677000056__2, chunk_677000057__3, count_677000058__4, i_677000059__5 = tmp5, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__8 any; var root_238 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_677000056__7; if linked_239 == nil { b__8 = ifn_240.Invoke_O__O(arg_241) } else { b__8 = linked_239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__8)) { var tmp6 jrt.HashSet_I = jrt.HashSet_Cast(t.F_seen); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8))) }; lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8)); var tmp7 any; var root_246 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_677000056__7; if linked_247 == nil { tmp7 = ifn_248.Invoke_O__O(arg_249) } else { tmp7 = linked_247.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_246, arg_249) }; seq_677000056__2, chunk_677000057__3, count_677000058__4, i_677000059__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_cpp_abi_vbases_init_A_New() *A_arbace_cpp_abi_vbases_init_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_vbases_init_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_cpp_abi_vbases_init_A) Ctor() {}
//line :102:1
func (t *A_arbace_cpp_abi_vbases_init_A) Invoke_O_O__O(self, id__0 any) any { var seen__2 any = jrt.LinkedHashSet_New(); var tmp1 *lang.Compiler_AOTFn; var fnbody__289 any = A_arbace_cpp_abi_vbases_init_walk__677000062_A_New_O(seen__2); var tmp2 *jrt.Class; var fncls__288 *jrt.Class = A_arbace_cpp_abi_vbases_init_walk__677000062_A_fn_class; if




	fncls__288 == nil { var fncls__288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_215, false, fnbody__289); A_arbace_cpp_abi_vbases_init_walk__677000062_A_fn_class = fncls__288d; tmp2 = fncls__288d } else { tmp2 = fncls__288 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__289, tmp2, nil); Up_Compiler_AOTFn_IFn(tmp1).Invoke_O__O(id__0); var root_252 any =
	A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = seen__2; if linked_253 == nil { return ifn_254.Invoke_O__O(arg_255) } else { return linked_253.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_252, arg_255) } }
//line :107:1
func A_arbace_cpp_abi_vbases_init_walk__677000062_A_New_O(p0 any) *A_arbace_cpp_abi_vbases_init_walk__677000062_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_vbases_init_walk__677000062_A{}; t.Ctor_O(p0); return t }
//line :107:1
func (t *A_arbace_cpp_abi_vbases_init_walk__677000062_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :107:1
func (t *A_arbace_cpp_abi_vbases_init_walk__677000062_A) Invoke_O_O__O(self, x__1 any) any { { var seq_677000063__2 any; var root_256 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp2 any; var root_260 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, A_arbace_cpp_abi_cls_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = x__1; if linked_261 == nil { tmp2 = ifn_262.Invoke_O__O(arg_263) } else { tmp2 = linked_261.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_260, arg_263) }; arg_259 = tmp1.Invoke_O__O(tmp2); if linked_257 == nil { seq_677000063__2 = ifn_258.Invoke_O__O(arg_259) } else { seq_677000063__2 = linked_257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_256, arg_259) }; var chunk_677000064__3 any; var count_677000065__4 int64 = 0; var i_677000066__5 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_677000066__5, count_677000065__4) { var b__6 any = lang.Indexed_Cast(chunk_677000064__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000066__5)); lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6)); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__6)) { var tmp3 jrt.HashSet_I = jrt.HashSet_Cast(t.F_seen); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6))) }; seq_677000063__2, chunk_677000064__3, count_677000065__4, i_677000066__5 = seq_677000063__2, chunk_677000064__3, count_677000065__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000066__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_264 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq_677000063__2; if linked_265 == nil { temp__1927000414__auto____6 = ifn_266.Invoke_O__O(arg_267) } else { temp__1927000414__auto____6 = linked_265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_264, arg_267) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_677000063__7 any = temp__1927000414__auto____6; var tmp4 any; var root_268 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq_677000063__7; if linked_269 == nil { tmp4 = ifn_270.Invoke_O__O(arg_271) } else { tmp4 = linked_269.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_268, arg_271) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____8 any; var root_272 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = seq_677000063__7; if linked_273 == nil { c__1927000678__auto____8 = ifn_274.Invoke_O__O(arg_275) } else { c__1927000678__auto____8 = linked_273.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_272, arg_275) }; var tmp5 any; var root_280 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = seq_677000063__7; if linked_281 == nil { tmp5 = ifn_282.Invoke_O__O(arg_283) } else { tmp5 = linked_281.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_280, arg_283) }; seq_677000063__2, chunk_677000064__3, count_677000065__4, i_677000066__5 = tmp5, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__8 any; var root_276 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = seq_677000063__7; if linked_277 == nil { b__8 = ifn_278.Invoke_O__O(arg_279) } else { b__8 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) }; lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8)); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__8)) { var tmp6 jrt.HashSet_I = jrt.HashSet_Cast(t.F_seen); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8))) }; var tmp7 any; var root_284 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = seq_677000063__7; if linked_285 == nil { tmp7 = ifn_286.Invoke_O__O(arg_287) } else { tmp7 = linked_285.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_284, arg_287) }; seq_677000063__2, chunk_677000064__3, count_677000065__4, i_677000066__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_cpp_abi_dynamic_QMARK__A_New() *A_arbace_cpp_abi_dynamic_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dynamic_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_cpp_abi_dynamic_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_cpp_abi_dynamic_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var c__2 any; var root_290 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_cpp_abi_cls_A_fn_class); var ifn_292 lang.IFn; if
										linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = id__0; if linked_291 == nil { c__2 = ifn_292.Invoke_O__O(arg_293) } else { c__2 = linked_291.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_290, arg_293) }; var tmp1 any; var or__1927000174__auto____3 any; var root_294 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = A_arbace_cpp_abi_A_const_84.Invoke_O__O(c__2); if linked_295 == nil { or__1927000174__auto____3 = ifn_296.Invoke_O__O(arg_297) } else { or__1927000174__auto____3 = linked_295.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_294, arg_297) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_298 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = A_arbace_cpp_abi_A_const_80; var arg_302 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_299 == nil { or__1927000174__auto____4 = ifn_300.Invoke_O_O__O(arg_301, arg_302) } else { or__1927000174__auto____4 = linked_299.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_298, arg_301, arg_302) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_303 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var fnbody__313 any = A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_New(); var tmp2 *jrt.Class; var fncls__312 *jrt.Class = A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_fn_class; if fncls__312 == nil { var fncls__312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_fn_class = fncls__312d; tmp2 = fncls__312d } else { tmp2 = fncls__312 }; arg_306 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__313, tmp2, nil); var arg_307 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_304 == nil { tmp1 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { tmp1 = linked_304.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :111:1
func A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_New() *A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A) Ctor() {}
//line :111:1
func (t *A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A) Invoke_O_O__O(self, p1__677000069_SHARP___1 any) any { var root_308 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(p1__677000069_SHARP___1); if linked_309 == nil { return ifn_310.Invoke_O__O(arg_311) } else { return linked_309.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_308, arg_311) } }



func A_arbace_cpp_abi_nearly_empty_QMARK__A_New() *A_arbace_cpp_abi_nearly_empty_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_nearly_empty_QMARK__A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_cpp_abi_nearly_empty_QMARK__A) Ctor() {}
//line :115:1
func (t *A_arbace_cpp_abi_nearly_empty_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var and__1927000168__auto____2 any; var root_314 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_316 lang.IFn; if
											linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = id__0; if linked_315 == nil { and__1927000168__auto____2 = ifn_316.Invoke_O__O(arg_317) } else { and__1927000168__auto____2 = linked_315.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_314, arg_317) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_87; var tmp2 any; var root_318 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, A_arbace_cpp_abi_layout_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = id__0; if linked_319 == nil { tmp2 = ifn_320.Invoke_O__O(arg_321) } else { tmp2 = linked_319.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_318, arg_321) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(8, lang.RT_LongCast_O__J_NoInit(tmp1.Invoke_O__O(tmp2)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_cpp_abi_indirect_primaries_A_New() *A_arbace_cpp_abi_indirect_primaries_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_indirect_primaries_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_cpp_abi_indirect_primaries_A) Ctor() {}
//line :118:1
func (t *A_arbace_cpp_abi_indirect_primaries_A) Invoke_O_O__O(self, id__0 any) any { var out__2 any = jrt.HashSet_New(); var tmp1 *lang.Compiler_AOTFn; var fnbody__363 any = A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_New_O(out__2); var tmp2 *jrt.Class; var fncls__362 *jrt.Class = A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_fn_class; if



	fncls__362 == nil { var fncls__362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__363); A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_fn_class = fncls__362d; tmp2 = fncls__362d } else { tmp2 = fncls__362 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__363, tmp2, nil); Up_Compiler_AOTFn_IFn(tmp1).Invoke_O__O(id__0); return out__2 }
//line :122:1
func A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_New_O(p0 any) *A_arbace_cpp_abi_indirect_primaries_walk__677000074_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_indirect_primaries_walk__677000074_A{}; t.Ctor_O(p0); return t }
//line :122:1
func (t *A_arbace_cpp_abi_indirect_primaries_walk__677000074_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :122:1
func (t *A_arbace_cpp_abi_indirect_primaries_walk__677000074_A) Invoke_O_O__O(self, x__1 any) any { { var seq_677000075__2 any; var root_322 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp2 any; var root_326 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_cpp_abi_cls_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = x__1; if linked_327 == nil { tmp2 = ifn_328.Invoke_O__O(arg_329) } else { tmp2 = linked_327.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_326, arg_329) }; arg_325 = tmp1.Invoke_O__O(tmp2); if linked_323 == nil { seq_677000075__2 = ifn_324.Invoke_O__O(arg_325) } else { seq_677000075__2 = linked_323.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_322, arg_325) }; var chunk_677000076__3 any; var count_677000077__4 int64 = 0; var i_677000078__5 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_677000078__5, count_677000077__4) { var b__6 any = lang.Indexed_Cast(chunk_677000076__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000078__5)); var pb__7 any; var tmp3 *lang.Keyword = A_arbace_cpp_abi_A_const_88; var tmp4 any; var root_346 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_cpp_abi_layout_A_fn_class); var ifn_348 lang.IFn
													if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6); if linked_347 == nil { tmp4 = ifn_348.Invoke_O__O(arg_349) } else { tmp4 = linked_347.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_346, arg_349) }; pb__7 = tmp3.Invoke_O__O(tmp4); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(pb__7)) { var tmp5 jrt.HashSet_I = jrt.HashSet_Cast(t.F_out); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(pb__7))) }
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__6))
//line :122:1
	seq_677000075__2, chunk_677000076__3, count_677000077__4, i_677000078__5 = seq_677000075__2, chunk_677000076__3, count_677000077__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000078__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_330 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = seq_677000075__2; if linked_331 == nil { temp__1927000414__auto____6 = ifn_332.Invoke_O__O(arg_333) } else { temp__1927000414__auto____6 = linked_331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_330, arg_333) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_677000075__7 any = temp__1927000414__auto____6; var tmp6 any; var root_334 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seq_677000075__7; if linked_335 == nil { tmp6 = ifn_336.Invoke_O__O(arg_337) } else { tmp6 = linked_335.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____8 any; var root_338 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_677000075__7; if linked_339 == nil { c__1927000678__auto____8 = ifn_340.Invoke_O__O(arg_341) } else { c__1927000678__auto____8 = linked_339.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_338, arg_341) }; var tmp7 any; var root_350 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = seq_677000075__7; if linked_351 == nil { tmp7 = ifn_352.Invoke_O__O(arg_353) } else { tmp7 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_350, arg_353) }; seq_677000075__2, chunk_677000076__3, count_677000077__4, i_677000078__5 = tmp7, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__8 any; var root_342 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_677000075__7; if linked_343 == nil { b__8 = ifn_344.Invoke_O__O(arg_345) } else { b__8 = linked_343.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_342, arg_345) }; var pb__9 any; var tmp8 *lang.Keyword = A_arbace_cpp_abi_A_const_88; var tmp9 any; var root_354 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_cpp_abi_layout_A_fn_class); var ifn_356 lang.IFn
		if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8); if linked_355 == nil { tmp9 = ifn_356.Invoke_O__O(arg_357) } else { tmp9 = linked_355.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_354, arg_357) }; pb__9 = tmp8.Invoke_O__O(tmp9); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(pb__9)) { var tmp10 jrt.HashSet_I = jrt.HashSet_Cast(t.F_out); jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp10.Add_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(pb__9))) }
		lang.IFn_Cast(self).Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8))
//line :122:1
		var tmp11 any; var root_358 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = seq_677000075__7; if linked_359 == nil { tmp11 = ifn_360.Invoke_O__O(arg_361) } else { tmp11 = linked_359.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_358, arg_361) }; seq_677000075__2, chunk_677000076__3, count_677000077__4, i_677000078__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }





func A_arbace_cpp_abi_primary_base_A_New() *A_arbace_cpp_abi_primary_base_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_primary_base_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_cpp_abi_primary_base_A) Ctor() {}
//line :128:1
func (t *A_arbace_cpp_abi_primary_base_A) Invoke_O_O__O(self, id__0 any) any { var c__2 any; var root_364 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_cpp_abi_cls_A_fn_class); var ifn_366 lang.IFn; if




	linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = id__0; if linked_365 == nil { c__2 = ifn_366.Invoke_O__O(arg_367) } else { c__2 = linked_365.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_364, arg_367) }; var or__1927000174__auto____3 any; var root_368 any = /*line :128:1*/A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_370 lang.IFn; if





	linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var root_372 any = A_arbace_cpp_abi_A_const_89.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var fnbody__386 any = A_arbace_cpp_abi_primary_base_fn__677000082_A_New(); var tmp1 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_cpp_abi_primary_base_fn__677000082_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_cpp_abi_primary_base_fn__677000082_A_fn_class = fncls__385d; tmp1 = fncls__385d } else { tmp1 = fncls__385 }; arg_375 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__386, tmp1, nil); var arg_376 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_373 == nil { arg_371 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { arg_371 = linked_373.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }; if linked_369 == nil { or__1927000174__auto____3 = ifn_370.Invoke_O__O(arg_371) } else { or__1927000174__auto____3 = linked_369.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {
		var tmp2 any; var root_387 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = id__0; if linked_388 == nil { tmp2 = ifn_389.Invoke_O__O(arg_390) } else { tmp2 = linked_388.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(tmp2) { var ip__4 any; var root_391 any = A_arbace_cpp_abi_A_const_91.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, A_arbace_cpp_abi_indirect_primaries_A_fn_class); var ifn_393 lang.IFn
			if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = id__0; if linked_392 == nil { ip__4 = ifn_393.Invoke_O__O(arg_394) } else { ip__4 = linked_392.(*A_arbace_cpp_abi_indirect_primaries_A).Invoke_O_O__O(root_391, arg_394) }
//line :135:1
			var first_ne__5 any; var root_395 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_397 lang.IFn

			if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; if linked_396 == nil { first_ne__5 = ifn_397.Invoke_O__O(arg_398) } else { first_ne__5 = linked_396.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_395, arg_398) }
//line :135:1
			var found__6 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__432 any = A_arbace_cpp_abi_primary_base_sel__677000084_A_New_O_O(first_ne__5, ip__4); var tmp4 *jrt.Class
			var fncls__431 /*line :135:1*/*jrt.Class = A_arbace_cpp_abi_primary_base_sel__677000084_A_fn_class


			if fncls__431 == nil { var fncls__431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, fnbody__432); A_arbace_cpp_abi_primary_base_sel__677000084_A_fn_class = fncls__431d; tmp4 = fncls__431d } else { tmp4 = fncls__431 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__432, tmp4, nil); found__6 = Up_Compiler_AOTFn_IFn(tmp3).Invoke_O__O(id__0)
//line :135:1
			var temp__1927000414__auto____7 any
			var or__1927000174__auto____7 any = found__6










			if jrt.J2g_Truth(or__1927000174__auto____7) { temp__1927000414__auto____7 = or__1927000174__auto____7 } else { var root_433 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = first_ne__5; if linked_434 == nil { temp__1927000414__auto____7 = ifn_435.Invoke_O__O(arg_436) } else { temp__1927000414__auto____7 = linked_434.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_433, arg_436) } }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var b__8 any = temp__1927000414__auto____7; var tmp5 any = A_arbace_cpp_abi_A_const_81; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__8), A_arbace_cpp_abi_A_const_80, jrt.Boolean_TRUE.Ref())) } else { return nil } } else {
//line :135:1
				return nil } } }
//line :134:1
func A_arbace_cpp_abi_primary_base_fn__677000082_A_New() *A_arbace_cpp_abi_primary_base_fn__677000082_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_primary_base_fn__677000082_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_cpp_abi_primary_base_fn__677000082_A) Ctor() {}
//line :134:1
func (t *A_arbace_cpp_abi_primary_base_fn__677000082_A) Invoke_O_O__O(self, p1__677000081_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_377 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(p1__677000081_SHARP___1); if linked_378 == nil { and__1927000168__auto____2 = ifn_379.Invoke_O__O(arg_380) } else { and__1927000168__auto____2 = linked_378.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_377, arg_380) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_381 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(p1__677000081_SHARP___1); if linked_382 == nil { return ifn_383.Invoke_O__O(arg_384) } else { return linked_382.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_381, arg_384) } } else { return and__1927000168__auto____2 } }



func A_arbace_cpp_abi_primary_base_sel__677000084_A_New_O_O(p0, p1 any) *A_arbace_cpp_abi_primary_base_sel__677000084_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_primary_base_sel__677000084_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_cpp_abi_primary_base_sel__677000084_A) Ctor_O_O(c__first_ne, c__ip any) { t.F_first_ne = c__first_ne; t.F_ip = c__ip }
//line :138:1
func (t *A_arbace_cpp_abi_primary_base_sel__677000084_A) Invoke_O_O__O(self, x__1 any) any {
	var root_399 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any; var fnbody__426 any = A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_New_O_O_O(t.F_first_ne, t.F_ip, self); var tmp1 *jrt.Class; var fncls__425 *jrt.Class = A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_fn_class; if fncls__425 == nil { var fncls__425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, fnbody__426); A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_fn_class = fncls__425d; tmp1 = fncls__425d } else { tmp1 = fncls__425 }; arg_402 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__426, tmp1, nil); var arg_403 any; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp3 any; var root_427 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, A_arbace_cpp_abi_cls_A_fn_class); var ifn_429 lang.IFn





	if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = x__1; if linked_428 == nil { tmp3 = ifn_429.Invoke_O__O(arg_430) } else { tmp3 = linked_428.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_427, arg_430) }; arg_403 = tmp2.Invoke_O__O(tmp3)
//line :139:1
	if linked_400 == nil { return ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { return linked_400.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) } }
//line :139:1
func A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :139:1
func (t *A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A) Ctor_O_O_O(c__first_ne, c__ip, c__sel any) { t.F_first_ne = c__first_ne; t.F_ip = c__ip; t.F_sel = c__sel }
//line :139:1
func (t *A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A) Invoke_O_O__O(self, b__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var and__1927000168__auto____2 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__1); if
														jrt.J2g_Truth(and__1927000168__auto____2) { var root_404 any = A_arbace_cpp_abi_A_const_93.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_cpp_abi_nearly_empty_QMARK__A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__1); if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*A_arbace_cpp_abi_nearly_empty_QMARK__A).Invoke_O_O__O(root_404, arg_407) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
															var tmp2 jrt.HashSet_I = jrt.HashSet_Cast(t.F_ip); if tmp2.Contains_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__1)) {
																var tmp3 any; var root_416 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = t.F_first_ne; if linked_417 == nil { tmp3 = ifn_418.Invoke_O__O(arg_419) } else { tmp3 = linked_417.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(tmp3) { } else { var root_420 any = A_arbace_cpp_abi_A_const_95.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = t.F_first_ne; var arg_424 any = b__1; if linked_421 == nil { ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { linked_421.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_420, arg_423, arg_424) } }
//line :141:1
			or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = b__1 } } else {
//line :140:1
				or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {



					var tmp4 any; var root_408 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_412 any = A_arbace_cpp_abi_A_const_94.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, A_arbace_cpp_abi_vbases_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__1); if linked_413 == nil { arg_411 = ifn_414.Invoke_O__O(arg_415) } else { arg_411 = linked_413.(*A_arbace_cpp_abi_vbases_A).Invoke_O_O__O(root_412, arg_415) }; if linked_409 == nil { tmp4 = ifn_410.Invoke_O__O(arg_411) } else { tmp4 = linked_409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_sel); return tmp5.Invoke_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__1)) } else { return nil } } }






func A_arbace_cpp_abi_empty_member_QMARK__A_New() *A_arbace_cpp_abi_empty_member_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_empty_member_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_cpp_abi_empty_member_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_cpp_abi_empty_member_QMARK__A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_cpp_abi_A_const_96.Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_437 any = A_arbace_cpp_abi_A_const_97.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_cpp_abi_class_QMARK__A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var root_441 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_cpp_abi_unq_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__0); if linked_442 == nil { arg_440 = ifn_443.Invoke_O__O(arg_444) } else { arg_440 = linked_442.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_441, arg_444) }; if linked_438 == nil { and__1927000168__auto____3 = ifn_439.Invoke_O__O(arg_440) } else { and__1927000168__auto____3 = linked_438.(*A_arbace_cpp_abi_class_QMARK__A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_445 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_49; var tmp3 any; var root_449 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, A_arbace_cpp_abi_unq_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__0); if linked_450 == nil { tmp3 = ifn_451.Invoke_O__O(arg_452) } else { tmp3 = linked_450.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_449, arg_452) }; arg_448 = tmp2.Invoke_O__O(tmp3); if linked_446 == nil { tmp1 = ifn_447.Invoke_O__O(arg_448) } else { tmp1 = linked_446.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_445, arg_448) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_cpp_abi_empty_class_QMARK__A_New() *A_arbace_cpp_abi_empty_class_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_empty_class_QMARK__A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_cpp_abi_empty_class_QMARK__A) Ctor() {}
//line :157:1
func (t *A_arbace_cpp_abi_empty_class_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var c__2 any; var root_453 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_cpp_abi_cls_A_fn_class); var ifn_455 lang.IFn; if



	linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = id__0; if linked_454 == nil { c__2 = ifn_455.Invoke_O__O(arg_456) } else { c__2 = linked_454.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_453, arg_456) }; var and__1927000168__auto____3 any; var root_457 any = /*line :157:1*/A_arbace_cpp_abi_A_const_100.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_459 lang.IFn; if



	linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = A_arbace_cpp_abi_A_const_101.GetRawRoot__O(); var arg_461 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__2); if linked_458 == nil { and__1927000168__auto____3 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { and__1927000168__auto____3 = linked_458.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_462 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_466 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = id__0; if linked_467 == nil { arg_465 = ifn_468.Invoke_O__O(arg_469) } else { arg_465 = linked_467.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_466, arg_469) }; if linked_463 == nil { and__1927000168__auto____4 = ifn_464.Invoke_O__O(arg_465) } else { and__1927000168__auto____4 = linked_463.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_470 any = A_arbace_cpp_abi_A_const_100.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var fnbody__480 any = A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_New(); var tmp1 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_fn_class = fncls__479d; tmp1 = fncls__479d } else { tmp1 = fncls__479 }; arg_473 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__480, tmp1, nil); var arg_474 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_471 == nil { return ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { return linked_471.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_470, arg_473, arg_474) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }
//line :161:1
func A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_New() *A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A) Ctor() {}
//line :161:1
func (t *A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A) Invoke_O_O__O(self, p1__677000090_SHARP___1 any) any { var root_475 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(p1__677000090_SHARP___1); if linked_476 == nil { return ifn_477.Invoke_O__O(arg_478) } else { return linked_476.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_475, arg_478) } }

func A_arbace_cpp_abi_pod_for_layout_QMARK__A_New() *A_arbace_cpp_abi_pod_for_layout_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_pod_for_layout_QMARK__A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__A) Ctor() {}
//line :163:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var c__2 any; var root_481 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_cpp_abi_cls_A_fn_class); var ifn_483 lang.IFn; if


	linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = id__0; if linked_482 == nil { c__2 = ifn_483.Invoke_O__O(arg_484) } else { c__2 = linked_482.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_481, arg_484) }; var and__1927000168__auto____3 any; var root_485 any = /*line :163:1*/A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_487 lang.IFn; if



	linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_486 == nil { and__1927000168__auto____3 = ifn_487.Invoke_O__O(arg_488) } else { and__1927000168__auto____3 = linked_486.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_485, arg_488) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_489 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_493 any = A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = id__0; if linked_494 == nil { arg_492 = ifn_495.Invoke_O__O(arg_496) } else { arg_492 = linked_494.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_493, arg_496) }; if linked_490 == nil { and__1927000168__auto____4 = ifn_491.Invoke_O__O(arg_492) } else { and__1927000168__auto____4 = linked_490.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_497 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_cpp_abi_A_const_104.Invoke_O__O(c__2); if linked_498 == nil { and__1927000168__auto____5 = ifn_499.Invoke_O__O(arg_500) } else { and__1927000168__auto____5 = linked_498.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_497, arg_500) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_501 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = A_arbace_cpp_abi_A_const_105.Invoke_O__O(c__2); if linked_502 == nil { and__1927000168__auto____6 = ifn_503.Invoke_O__O(arg_504) } else { and__1927000168__auto____6 = linked_502.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_501, arg_504) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_505 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = A_arbace_cpp_abi_A_const_106.Invoke_O__O(c__2); if linked_506 == nil { and__1927000168__auto____7 = ifn_507.Invoke_O__O(arg_508) } else { and__1927000168__auto____7 = linked_506.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_505, arg_508) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_509 any = A_arbace_cpp_abi_A_const_100.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_511 lang.IFn
		if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any; var fnbody__515 any = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_New(); var tmp1 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_fn_class = fncls__514d; tmp1 = fncls__514d } else { tmp1 = fncls__514 }; arg_512 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__515, tmp1, nil); var arg_513 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__2); if linked_510 == nil { and__1927000168__auto____8 = ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { and__1927000168__auto____8 = linked_510.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_509, arg_512, arg_513) }
//line :167:1
		if jrt.J2g_Truth(and__1927000168__auto____8) {

			var root_516 any = A_arbace_cpp_abi_A_const_100.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var fnbody__548 any = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_New(); var tmp2 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_fn_class = fncls__547d; tmp2 = fncls__547d } else { tmp2 = fncls__547 }; arg_519 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__548, tmp2, nil); var arg_520 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__2); if linked_517 == nil { return ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { return linked_517.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_516, arg_519, arg_520) } } else {
//line :167:1
				return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }
func A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_New() *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A) Ctor() {}
//line :168:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A) Invoke_O_O__O(self, p1__677000094_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_107; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_108.Invoke_O__O(p1__677000094_SHARP___1))).Ref() }
func A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_New() *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A) Ctor() {}
//line :169:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A) Invoke_O_O__O(self, f__1 any) any { var t__2 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__526 any = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__525 *jrt.Class = A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_fn_class; if fncls__525 == nil { var fncls__525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, fnbody__526); A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_fn_class = fncls__525d; tmp2 = fncls__525d } else { tmp2 = fncls__525 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__526, tmp2, nil); t__2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var and__1927000168__auto____3 any; var root_527 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_529 lang.IFn; if
													linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var root_531 any = A_arbace_cpp_abi_A_const_32.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, A_arbace_cpp_abi_ref_QMARK__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = t__2; if linked_532 == nil { arg_530 = ifn_533.Invoke_O__O(arg_534) } else { arg_530 = linked_532.(*A_arbace_cpp_abi_ref_QMARK__A).Invoke_O_O__O(root_531, arg_534) }; if linked_528 == nil { and__1927000168__auto____3 = ifn_529.Invoke_O__O(arg_530) } else { and__1927000168__auto____3 = linked_528.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_527, arg_530) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_535 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var root_539 any = A_arbace_cpp_abi_A_const_97.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_cpp_abi_class_QMARK__A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = t__2; if linked_540 == nil { arg_538 = ifn_541.Invoke_O__O(arg_542) } else { arg_538 = linked_540.(*A_arbace_cpp_abi_class_QMARK__A).Invoke_O_O__O(root_539, arg_542) }; if linked_536 == nil { or__1927000174__auto____4 = ifn_537.Invoke_O__O(arg_538) } else { or__1927000174__auto____4 = linked_536.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_535, arg_538) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_543 any = A_arbace_cpp_abi_A_const_110.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_cpp_abi_pod_for_layout_QMARK__A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__2); if linked_544 == nil { return ifn_545.Invoke_O__O(arg_546) } else { return linked_544.(*A_arbace_cpp_abi_pod_for_layout_QMARK__A).Invoke_O_O__O(root_543, arg_546) } } } else { return and__1927000168__auto____3 } }
//line :169:1
func A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_New_O(p0 any) *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A{}; t.Ctor_O(p0); return t }
//line :169:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :169:1
func (t *A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A) Invoke_O__O(self any) any { { var t__1 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_98; var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; t__1 = tmp1.Invoke_O__O(tmp2); L1: for { var tmp3 any; var root_521 any = A_arbace_cpp_abi_A_const_109.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, A_arbace_cpp_abi_arr_QMARK__A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = t__1; if linked_522 == nil { tmp3 = ifn_523.Invoke_O__O(arg_524) } else { tmp3 = linked_522.(*A_arbace_cpp_abi_arr_QMARK__A).Invoke_O_O__O(root_521, arg_524) }; if jrt.J2g_Truth(tmp3) { t__1 = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t__1); continue L1 } else { return t__1 } } }; panic("j2g: unreachable") }



func A_arbace_cpp_abi_nonvirtual_subobjects_A_New() *A_arbace_cpp_abi_nonvirtual_subobjects_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_nonvirtual_subobjects_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_cpp_abi_nonvirtual_subobjects_A) Ctor() {}
//line :173:1
func (t *A_arbace_cpp_abi_nonvirtual_subobjects_A) InvokePrim_O_O_J__O(self, x__0 any, off__1 int64) any { var c__3 any; var root_549 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, A_arbace_cpp_abi_cls_A_fn_class); var ifn_551 lang.IFn; if


	linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = x__0; if linked_550 == nil { c__3 = ifn_551.Invoke_O__O(arg_552) } else { c__3 = linked_550.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_549, arg_552) }; var l__4 any; var root_553 any = /*line :173:1*/A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_cpp_abi_layout_A_fn_class); var ifn_555 lang.IFn; if


	linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = x__0; if linked_554 == nil { l__4 = ifn_555.Invoke_O__O(arg_556) } else { l__4 = linked_554.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_553, arg_556) }; var root_557 any =
	A_arbace_cpp_abi_A_const_111.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(x__0, jrt.Long_ValueOf_J__Long_NoInit(off__1).Ref())); var arg_561 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__573 any = A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_New_O_J(l__4, off__1); var tmp3 *jrt.Class; var fncls__572 *jrt.Class = A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_fn_class; if fncls__572 == nil { var fncls__572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, fnbody__573); A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_fn_class = fncls__572d; tmp3 = fncls__572d } else { tmp3 = fncls__572 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__573, tmp3, nil); var tmp4 any = tmp2.Ref(); var tmp5 any; var root_574 any = A_arbace_cpp_abi_A_const_114.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_576 lang.IFn; if
	linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = A_arbace_cpp_abi_A_const_115.GetRawRoot__O(); var arg_578 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__3); if linked_575 == nil { tmp5 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { tmp5 = linked_575.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; arg_561 = /*line :177:1*/tmp1.Invoke_O_O__O(tmp4, tmp5); if linked_558 == nil { return ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { return linked_558.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) } }
//line :173:1
func (t *A_arbace_cpp_abi_nonvirtual_subobjects_A) Invoke_O_O_O__O(self, x__0, p_off__1 any) any { return t.InvokePrim_O_O_J__O(self, x__0, lang.RT_LongCast_O__J_NoInit(p_off__1)) }



func A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_New_O_J(p0 any, p1 int64) *A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A{}; t.Ctor_O_J(p0, p1); return t }
//line :177:1
func (t *A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A) Ctor_O_J(c__l any, c__off int64) { t.F_l = c__l; t.F_off = c__off }
//line :177:1
func (t *A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A) Invoke_O_O__O(self, p__677000102__1 any) any { var vec__677000104__2 any = p__677000102__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000104__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000104__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__4)) { return nil } else { var root_567 any = A_arbace_cpp_abi_A_const_113.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_567, A_arbace_cpp_abi_nonvirtual_subobjects_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__4); var tmp1 int64 = t.F_off; var arg_571 int64 = lang.Numbers_Add_J_J__J_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_77.Invoke_O__O(t.F_l), lang.RT_IntCast_O__I_NoInit(i__3)))); if linked_568 == nil { return ifn_569.Invoke_O_O__O(arg_570, jrt.Long_ValueOf_J__Long_NoInit(arg_571).Ref()) } else { return linked_568.(*A_arbace_cpp_abi_nonvirtual_subobjects_A).InvokePrim_O_O_J__O(root_567, arg_570, arg_571) } } }




func A_arbace_cpp_abi_field_empties_A_New() *A_arbace_cpp_abi_field_empties_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_field_empties_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_cpp_abi_field_empties_A) Ctor() {}
//line :182:1
func (t *A_arbace_cpp_abi_field_empties_A) InvokePrim_O_O_J__O(self, t__0 any, off__1 int64) any { var t__3 any; var root_579 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_cpp_abi_unq_A_fn_class); var ifn_581 lang.IFn; if



	linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = t__0; if linked_580 == nil { t__3 = ifn_581.Invoke_O__O(arg_582) } else { t__3 = linked_580.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_579, arg_582) }; var tmp1 any; var root_583 any =
	A_arbace_cpp_abi_A_const_97.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_cpp_abi_class_QMARK__A_fn_class); var ifn_585 lang.IFn; if
	linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = t__3; if linked_584 == nil { tmp1 = ifn_585.Invoke_O__O(arg_586) } else { tmp1 = linked_584.(*A_arbace_cpp_abi_class_QMARK__A).Invoke_O_O__O(root_583, arg_586) }; if /*line :187:1*/ jrt.J2g_Truth(tmp1) {
		var root_587 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_587, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__3); var arg_591 int64 = off__1; var arg_592 any = jrt.Boolean_TRUE.Ref(); if linked_588 == nil { return ifn_589.Invoke_O_O_O__O(arg_590, jrt.Long_ValueOf_J__Long_NoInit(arg_591).Ref(), arg_592) } else { return linked_588.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_587, arg_590, arg_591, arg_592) } } else {
//line :187:1
			var tmp2 any; var root_593 any = A_arbace_cpp_abi_A_const_109.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_cpp_abi_arr_QMARK__A_fn_class); var ifn_595 lang.IFn

			if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = t__3; if linked_594 == nil { tmp2 = ifn_595.Invoke_O__O(arg_596) } else { tmp2 = linked_594.(*A_arbace_cpp_abi_arr_QMARK__A).Invoke_O_O__O(root_593, arg_596) }
//line :187:1
			if jrt.J2g_Truth(tmp2) { var et__4 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__610 any = A_arbace_cpp_abi_field_empties_fn__677000109_A_New_O(t__3); var tmp4 *jrt.Class
				var fncls__609 /*line :187:1*/*jrt.Class = A_arbace_cpp_abi_field_empties_fn__677000109_A_fn_class

				if fncls__609 == nil { var fncls__609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__610); A_arbace_cpp_abi_field_empties_fn__677000109_A_fn_class = fncls__609d; tmp4 = fncls__609d } else { tmp4 = fncls__609 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__610, tmp4, nil); et__4 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :187:1
				var n__5 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__620 any = A_arbace_cpp_abi_field_empties_fn__677000111_A_New_O(t__3); var tmp6 *jrt.Class
				var fncls__619 /*line :187:1*/*jrt.Class = A_arbace_cpp_abi_field_empties_fn__677000111_A_fn_class


				if fncls__619 == nil { var fncls__619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__620); A_arbace_cpp_abi_field_empties_fn__677000111_A_fn_class = fncls__619d; tmp6 = fncls__619d } else { tmp6 = fncls__619 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__620, tmp6, nil); n__5 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
				var tmp7 any; var root_621 any = A_arbace_cpp_abi_A_const_97.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, A_arbace_cpp_abi_class_QMARK__A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = et__4; if linked_622 == nil { tmp7 = ifn_623.Invoke_O__O(arg_624) } else { tmp7 = linked_622.(*A_arbace_cpp_abi_class_QMARK__A).Invoke_O_O__O(root_621, arg_624) }; if jrt.J2g_Truth(tmp7) { var e0__6 any; var root_625 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_625, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_627 lang.IFn
					if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(et__4); var arg_630 any = jrt.Boolean_TRUE.Ref(); if linked_626 == nil { e0__6 = ifn_627.Invoke_O_O_O__O(arg_628, A_arbace_cpp_abi_A_const_68, arg_630) } else { e0__6 = linked_626.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_625, arg_628, 0, arg_630) }
					var tmp8 any; var root_631 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = e0__6; if linked_632 == nil { tmp8 = ifn_633.Invoke_O__O(arg_634) } else { tmp8 = linked_632.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(tmp8) { return lang.PersistentVector_EMPTY.Ref() } else { var sz__7 int64; var tmp9 any; var root_635 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_637 lang.IFn

						if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var root_639 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = et__4; if linked_640 == nil { arg_638 = ifn_641.Invoke_O__O(arg_642) } else { arg_638 = linked_640.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_639, arg_642) }; if linked_636 == nil { tmp9 = ifn_637.Invoke_O__O(arg_638) } else { tmp9 = linked_636.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_635, arg_638) }; sz__7 = lang.RT_LongCast_O__J_NoInit(tmp9)
						var root_643 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp11 *lang.Compiler_AOTFn; var fnbody__669 any = A_arbace_cpp_abi_field_empties_fn__677000113_A_New_J_O_J(sz__7, et__4, off__1); var tmp12 *jrt.Class; var fncls__668 *jrt.Class = A_arbace_cpp_abi_field_empties_fn__677000113_A_fn_class; if fncls__668 == nil { var fncls__668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__669); A_arbace_cpp_abi_field_empties_fn__677000113_A_fn_class = fncls__668d; tmp12 = fncls__668d } else { tmp12 = fncls__668 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__669, tmp12, nil); var tmp13 any = tmp11.Ref(); var tmp14 any; var root_670 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = lang.Numbers_Min_O_J__O_NoInit(n__5, 1024); if linked_671 == nil { tmp14 = ifn_672.Invoke_O__O(arg_673) } else { tmp14 = linked_671.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_670, arg_673) }; arg_646 = tmp10.Invoke_O_O__O(tmp13, tmp14); if linked_644 == nil { return ifn_645.Invoke_O__O(arg_646) } else { return linked_644.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_643, arg_646) } } } else {
//line :191:1
							return lang.PersistentVector_EMPTY.Ref() } } else {
//line :187:1
								if A_arbace_cpp_abi_A_const_118 != nil { return lang.PersistentVector_EMPTY.Ref() } else { return nil } } } }
//line :182:1
func (t *A_arbace_cpp_abi_field_empties_A) Invoke_O_O_O__O(self, t__0, p_off__1 any) any { return t.InvokePrim_O_O_J__O(self, t__0, lang.RT_LongCast_O__J_NoInit(p_off__1)) }






func A_arbace_cpp_abi_field_empties_fn__677000109_A_New_O(p0 any) *A_arbace_cpp_abi_field_empties_fn__677000109_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_field_empties_fn__677000109_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000109_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :189:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000109_A) Invoke_O__O(self any) any { { var x__1 any; var root_597 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_cpp_abi_unq_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_24; var tmp2 any; var t_ any = t.F_t; t.F_t = nil; tmp2 = t_; arg_600 = tmp1.Invoke_O__O(tmp2); if linked_598 == nil { x__1 = ifn_599.Invoke_O__O(arg_600) } else { x__1 = linked_598.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_597, arg_600) }; L1: for { var tmp3 any; var root_601 any = A_arbace_cpp_abi_A_const_109.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, A_arbace_cpp_abi_arr_QMARK__A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = x__1; if linked_602 == nil { tmp3 = ifn_603.Invoke_O__O(arg_604) } else { tmp3 = linked_602.(*A_arbace_cpp_abi_arr_QMARK__A).Invoke_O_O__O(root_601, arg_604) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_605 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, A_arbace_cpp_abi_unq_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(x__1); if linked_606 == nil { tmp4 = ifn_607.Invoke_O__O(arg_608) } else { tmp4 = linked_606.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_605, arg_608) }; x__1 = tmp4; continue L1 } else { return x__1 } } }; panic("j2g: unreachable") }
func A_arbace_cpp_abi_field_empties_fn__677000111_A_New_O(p0 any) *A_arbace_cpp_abi_field_empties_fn__677000111_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_field_empties_fn__677000111_A{}; t.Ctor_O(p0); return t }
//line :190:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000111_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :190:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000111_A) Invoke_O__O(self any) any { { var x__1 any; var t_ any = t.F_t; t.F_t = nil; x__1 = t_; var n__2 int64 = 1; L1: for { var tmp1 any; var root_611 any = A_arbace_cpp_abi_A_const_109.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_cpp_abi_arr_QMARK__A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = x__1; if linked_612 == nil { tmp1 = ifn_613.Invoke_O__O(arg_614) } else { tmp1 = linked_612.(*A_arbace_cpp_abi_arr_QMARK__A).Invoke_O_O__O(root_611, arg_614) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_615 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_cpp_abi_unq_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(x__1); if linked_616 == nil { tmp2 = ifn_617.Invoke_O__O(arg_618) } else { tmp2 = linked_616.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_615, arg_618) }; var tmp3 any = tmp2; var tmp4 any; var or__1927000174__auto____3 any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { tmp4 = A_arbace_cpp_abi_A_const_68 }; x__1, n__2 = tmp3, lang.Numbers_Multiply_J_J__J_NoInit(n__2, lang.RT_LongCast_O__J_NoInit(tmp4)); continue L1 } else { return jrt.Long_ValueOf_J__Long_NoInit(n__2).Ref() } } }; panic("j2g: unreachable") }





func A_arbace_cpp_abi_field_empties_fn__677000113_A_New_J_O_J(p0 int64, p1 any, p2 int64) *A_arbace_cpp_abi_field_empties_fn__677000113_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_field_empties_fn__677000113_A{}; t.Ctor_J_O_J(p0, p1, p2); return t }
//line :196:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000113_A) Ctor_J_O_J(c__sz int64, c__et any, c__off int64) { t.F_sz = c__sz; t.F_et = c__et; t.F_off = c__off }
//line :196:1
func (t *A_arbace_cpp_abi_field_empties_fn__677000113_A) Invoke_O_O__O(self, i__1 any) any { var root_652 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_652, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t.F_et); var arg_656 any; var na_658 int64 = t.F_off; var na_659 any; var na_660 any = i__1; var na_661 int64 = t.F_sz; if jrt.Long_InstanceOf(na_660) { var n0_662 int64 = jrt.NN(jrt.Long_Cast(na_660)).LongValue__J(); var n1_663 int64 = na_661; var nr_664 int64 = n0_662 * n1_663; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = n0_662 == -9223372036854775808; if tmp4 { tmp4 = n1_663 < 0 }; tmp3 = tmp4; tmp2 = !tmp3; if tmp2 { var tmp5 bool; tmp5 = n1_663 == 0; if !tmp5 { tmp5 = nr_664/n1_663 == n0_662 }; tmp2 = tmp5 }; tmp1 = tmp2; if tmp1 { na_659 = jrt.Long_ValueOf_J__Long_NoInit(nr_664).Ref() } else { na_659 = lang.Numbers_Multiply_O_J__Number_NoInit(na_660, na_661) } } else { na_659 = lang.Numbers_Multiply_O_J__Number_NoInit(na_660, na_661) }; if jrt.Long_InstanceOf(na_659) { var n0_665 int64 = na_658; var n1_666 int64 = jrt.NN(jrt.Long_Cast(na_659)).LongValue__J(); var nr_667 int64 = n0_665 + n1_666; if (n0_665^nr_667)&(n1_666^nr_667) >= 0 { arg_656 = jrt.Long_ValueOf_J__Long_NoInit(nr_667).Ref() } else { arg_656 = lang.Numbers_Add_J_O__Number_NoInit(na_658, na_659) } } else { arg_656 = lang.Numbers_Add_J_O__Number_NoInit(na_658, na_659) }; var arg_657 any = jrt.Boolean_TRUE.Ref(); if linked_653 == nil { return ifn_654.Invoke_O_O_O__O(arg_655, arg_656, arg_657) } else { return linked_653.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_652, arg_655, lang.RT_LongCast_O__J_NoInit(arg_656), arg_657) } }



func A_arbace_cpp_abi_class_empties_A_New() *A_arbace_cpp_abi_class_empties_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_class_empties_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_cpp_abi_class_empties_A) Ctor() {}
//line :200:1
func (t *A_arbace_cpp_abi_class_empties_A) InvokePrim_O_O_J_O__O(self, id__0 any, off__1 int64, top__2 any) any { var c__4 any; var root_674 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_cpp_abi_cls_A_fn_class); var ifn_676 lang.IFn; if



	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = id__0; if linked_675 == nil { c__4 = ifn_676.Invoke_O__O(arg_677) } else { c__4 = linked_675.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_674, arg_677) }; var l__5 any; var root_678 any = /*line :200:1*/A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_cpp_abi_layout_A_fn_class); var ifn_680 lang.IFn; if



	linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = id__0; if linked_679 == nil { l__5 = ifn_680.Invoke_O__O(arg_681) } else { l__5 = linked_679.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_678, arg_681) }; var own__6 any; var tmp1 any; var root_682 any = /*line :200:1*/A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_684 lang.IFn; if




	linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = id__0; if linked_683 == nil { tmp1 = ifn_684.Invoke_O__O(arg_685) } else { tmp1 = linked_683.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp1) { own__6 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(id__0, jrt.Long_ValueOf_J__Long_NoInit(off__1).Ref())) } else { own__6 = nil }; var bs__7 any; var tmp2 lang.IFn = /*line :200:1*/lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp3 *lang.Compiler_AOTFn; var fnbody__699 any = A_arbace_cpp_abi_class_empties_fn__677000116_A_New_O_J(l__5, off__1); var tmp4 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_cpp_abi_class_empties_fn__677000116_A_fn_class; if





	fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__699); A_arbace_cpp_abi_class_empties_fn__677000116_A_fn_class = fncls__698d; tmp4 = fncls__698d } else { tmp4 = fncls__698 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__699, tmp4, nil); var tmp5 any = tmp3.Ref(); var tmp6 any; var root_700 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_702 lang.IFn; if
	linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; if linked_701 == nil { tmp6 = ifn_702.Invoke__O() } else { tmp6 = linked_701.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O__O(root_700) }; bs__7 = /*line :206:1*/tmp2.Invoke_O_O_O__O(tmp5, tmp6, A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__4)); var pv__8 any; var p__8 any = /*line :200:1*/A_arbace_cpp_abi_A_const_88.Invoke_O__O(l__5); var tmp7 any; var and__1927000168__auto____9 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(p__8); if







	jrt.J2g_Truth(and__1927000168__auto____9) { var root_703 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = top__2; if linked_704 == nil { tmp7 = ifn_705.Invoke_O__O(arg_706) } else { tmp7 = linked_704.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_703, arg_706) } } else { tmp7 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp7) { var root_707 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_707, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(p__8); var arg_711 int64 = off__1; var arg_712 any = jrt.Boolean_FALSE.Ref(); if linked_708 == nil { pv__8 = ifn_709.Invoke_O_O_O__O(arg_710, jrt.Long_ValueOf_J__Long_NoInit(arg_711).Ref(), arg_712) } else { pv__8 = linked_708.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_707, arg_710, arg_711, arg_712) } } else { pv__8 = nil }; var vb__9 any; if
	jrt.J2g_Truth(top__2) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp9 *lang.Compiler_AOTFn; var fnbody__725 any = A_arbace_cpp_abi_class_empties_fn__677000119_A_New_J(off__1); var tmp10 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_cpp_abi_class_empties_fn__677000119_A_fn_class; if fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__725); A_arbace_cpp_abi_class_empties_fn__677000119_A_fn_class = fncls__724d; tmp10 = fncls__724d } else { tmp10 = fncls__724 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__725, tmp10, nil); vb__9 = tmp8.Invoke_O_O__O(tmp9.Ref(), A_arbace_cpp_abi_A_const_119.Invoke_O__O(l__5)) } else { vb__9 = nil }; var fs__10 any; var tmp11 lang.IFn = /*line :200:1*/lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp12 *lang.Compiler_AOTFn; var fnbody__738 any = A_arbace_cpp_abi_class_empties_fn__677000124_A_New_J(off__1); var tmp13 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_cpp_abi_class_empties_fn__677000124_A_fn_class; if









	fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__738); A_arbace_cpp_abi_class_empties_fn__677000124_A_fn_class = fncls__737d; tmp13 = fncls__737d } else { tmp13 = fncls__737 }; tmp12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__738, tmp13, nil); fs__10 = tmp11.Invoke_O_O_O__O(tmp12.Ref(), A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__4), A_arbace_cpp_abi_A_const_102.Invoke_O__O(l__5)); var root_739 any =
	A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_122.GetRawRoot__O()).Invoke_O_O_O_O_O__O(own__6, bs__7, pv__8, vb__9, fs__10); if linked_740 == nil { return ifn_741.Invoke_O__O(arg_742) } else { return linked_740.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_739, arg_742) } }
//line :200:1
func (t *A_arbace_cpp_abi_class_empties_A) Invoke_O_O_O_O__O(self, id__0, p_off__1, top__2 any) any { return t.InvokePrim_O_O_J_O__O(self, id__0, lang.RT_LongCast_O__J_NoInit(p_off__1), top__2) }





func A_arbace_cpp_abi_class_empties_fn__677000116_A_New_O_J(p0 any, p1 int64) *A_arbace_cpp_abi_class_empties_fn__677000116_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_class_empties_fn__677000116_A{}; t.Ctor_O_J(p0, p1); return t }
//line :206:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000116_A) Ctor_O_J(c__l any, c__off int64) { t.F_l = c__l; t.F_off = c__off }
//line :206:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000116_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__2)) { return nil } else { var root_692 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_692, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__2); var tmp1 int64 = t.F_off; var arg_696 int64 = lang.Numbers_Add_J_J__J_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_77.Invoke_O__O(t.F_l), lang.RT_IntCast_O__I_NoInit(i__1)))); var arg_697 any = jrt.Boolean_FALSE.Ref(); if linked_693 == nil { return ifn_694.Invoke_O_O_O__O(arg_695, jrt.Long_ValueOf_J__Long_NoInit(arg_696).Ref(), arg_697) } else { return linked_693.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_692, arg_695, arg_696, arg_697) } } }


func A_arbace_cpp_abi_class_empties_fn__677000119_A_New_J(p0 int64) *A_arbace_cpp_abi_class_empties_fn__677000119_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_class_empties_fn__677000119_A{}; t.Ctor_J(p0); return t }
//line :209:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000119_A) Ctor_J(c__off int64) { t.F_off = c__off }
//line :209:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000119_A) Invoke_O_O__O(self, p__677000118__1 any) any { var vec__677000120__2 any = p__677000118__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000120__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vo__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000120__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_718 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_718, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = v__3; var tmp1 int64 = t.F_off; var arg_722 int64 = lang.Numbers_Add_J_J__J_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(vo__4)); var arg_723 any = jrt.Boolean_FALSE.Ref(); if linked_719 == nil { return ifn_720.Invoke_O_O_O__O(arg_721, jrt.Long_ValueOf_J__Long_NoInit(arg_722).Ref(), arg_723) } else { return linked_719.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_718, arg_721, arg_722, arg_723) } }
func A_arbace_cpp_abi_class_empties_fn__677000124_A_New_J(p0 int64) *A_arbace_cpp_abi_class_empties_fn__677000124_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_class_empties_fn__677000124_A{}; t.Ctor_J(p0); return t }
//line :210:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000124_A) Ctor_J(c__off int64) { t.F_off = c__off }
//line :210:1
func (t *A_arbace_cpp_abi_class_empties_fn__677000124_A) Invoke_O_O_O__O(self, f__1, o__2 any) any { if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__1)) { return nil } else { var root_732 any = A_arbace_cpp_abi_A_const_121.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_732, A_arbace_cpp_abi_field_empties_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__1); var tmp1 int64 = t.F_off; var arg_736 int64 = lang.Numbers_Add_J_J__J_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(o__2)); if linked_733 == nil { return ifn_734.Invoke_O_O__O(arg_735, jrt.Long_ValueOf_J__Long_NoInit(arg_736).Ref()) } else { return linked_733.(*A_arbace_cpp_abi_field_empties_A).InvokePrim_O_O_J__O(root_732, arg_735, arg_736) } } }


func A_arbace_cpp_abi_can_place_QMARK__A_New() *A_arbace_cpp_abi_can_place_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_can_place_QMARK__A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_cpp_abi_can_place_QMARK__A) Ctor() {}
//line :213:1
func (t *A_arbace_cpp_abi_can_place_QMARK__A) Invoke_O_O_O__O(self, em__0, lst__1 any) any { var root_751 any = A_arbace_cpp_abi_A_const_123.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_comp_fn__1927000519_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any; var fnbody__766 any = A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_New_O(em__0); var tmp1 *jrt.Class; var fncls__765 *jrt.Class = A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_fn_class; if fncls__765 == nil { var fncls__765d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__766); A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_fn_class = fncls__765d; tmp1 = fncls__765d } else { tmp1 = fncls__765 }; arg_754 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__766, tmp1, nil); var arg_755 any = lst__1; if linked_752 == nil { return ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { return linked_752.(*aot_arbace_core.A_arbace_core_comp_fn__1927000519_A).Invoke_O_O_O__O(root_751, arg_754, arg_755) } }
//line :213:1
func A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_New_O(p0 any) *A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A{}; t.Ctor_O(p0); return t }
//line :213:1
func (t *A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A) Ctor_O(c__em any) { t.F_em = c__em }
//line :213:1
func (t *A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A) Invoke_O_O__O(self, p__677000127__1 any) any { var vec__677000129__2 any = p__677000127__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000129__2, lang.RT_IntCast_J__I_NoInit(0), nil); var o__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000129__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_756 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp1 any; var root_761 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = t.F_em; if linked_762 == nil { tmp1 = ifn_763.Invoke_O__O(arg_764) } else { tmp1 = linked_762.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_761, arg_764) }; arg_759 = lang.RT_Get_O_O_O__O_NoInit(tmp1, o__4, lang.PersistentHashSet_EMPTY.Ref()); var arg_760 any = c__3; if linked_757 == nil { return ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { return linked_757.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_756, arg_759, arg_760) } }
func A_arbace_cpp_abi_place_BANG__A_New() *A_arbace_cpp_abi_place_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_place_BANG__A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_cpp_abi_place_BANG__A) Ctor() {}
//line :214:1
func (t *A_arbace_cpp_abi_place_BANG__A) Invoke_O_O_O__O(self, em__0, lst__1 any) any { { var seq_677000134__3 any; var root_767 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = lst__1; if linked_768 == nil { seq_677000134__3 = ifn_769.Invoke_O__O(arg_770) } else { seq_677000134__3 = linked_768.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_767, arg_770) }; var chunk_677000135__4 any; var count_677000136__5 int64 = 0; var i_677000137__6 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_677000137__6, count_677000136__5) { var vec__677000138__7 any = lang.Indexed_Cast(chunk_677000135__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000137__6)); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var o__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_51.GetRawRoot__O(); var tmp3 any; var root_795 any = A_arbace_cpp_abi_A_const_124.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_799 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_796 == nil { tmp3 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp3 = linked_796.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; tmp1.Invoke_O_O_O_O_O__O(em__0, tmp2, o__9, tmp3, c__8); seq_677000134__3, chunk_677000135__4, count_677000136__5, i_677000137__6 = seq_677000134__3, chunk_677000135__4, count_677000136__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000137__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_771 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = seq_677000134__3; if linked_772 == nil { temp__1927000414__auto____7 = ifn_773.Invoke_O__O(arg_774) } else { temp__1927000414__auto____7 = linked_772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_771, arg_774) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_677000134__8 any = temp__1927000414__auto____7; var tmp4 any; var root_775 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = seq_677000134__8; if linked_776 == nil { tmp4 = ifn_777.Invoke_O__O(arg_778) } else { tmp4 = linked_776.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_775, arg_778) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____9 any; var root_779 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = seq_677000134__8; if linked_780 == nil { c__1927000678__auto____9 = ifn_781.Invoke_O__O(arg_782) } else { c__1927000678__auto____9 = linked_780.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_779, arg_782) }; var tmp5 any; var root_800 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = seq_677000134__8; if linked_801 == nil { tmp5 = ifn_802.Invoke_O__O(arg_803) } else { tmp5 = linked_801.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_800, arg_803) }; seq_677000134__3, chunk_677000135__4, count_677000136__5, i_677000137__6 = tmp5, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__677000141__9 any; var root_783 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = seq_677000134__8; if linked_784 == nil { vec__677000141__9 = ifn_785.Invoke_O__O(arg_786) } else { vec__677000141__9 = linked_784.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_783, arg_786) }; var c__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000141__9, lang.RT_IntCast_J__I_NoInit(0), nil); var o__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000141__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_50.GetRawRoot__O()); var tmp7 any = A_arbace_cpp_abi_A_const_51.GetRawRoot__O(); var tmp8 any; var root_812 any = A_arbace_cpp_abi_A_const_124.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_816 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_813 == nil { tmp8 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { tmp8 = linked_813.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }; tmp6.Invoke_O_O_O_O_O__O(em__0, tmp7, o__11, tmp8, c__10); var tmp9 any; var root_817 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = seq_677000134__8; if linked_818 == nil { tmp9 = ifn_819.Invoke_O__O(arg_820) } else { tmp9 = linked_818.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_817, arg_820) }; seq_677000134__3, chunk_677000135__4, count_677000136__5, i_677000137__6 = tmp9, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }



func A_arbace_cpp_abi_layout_A_New() *A_arbace_cpp_abi_layout_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_cpp_abi_layout_A) Ctor() {}
//line :218:1
func (t *A_arbace_cpp_abi_layout_A) Invoke_O_O__O(self, id__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_125; var tmp2 any; var root_821 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_cpp_abi_cls_A_fn_class); var ifn_823 lang.IFn; if





	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = id__0; if linked_822 == nil { tmp2 = ifn_823.Invoke_O__O(arg_824) } else { tmp2 = linked_822.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_821, arg_824) }; or__1927000174__auto____2 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var root_825 any = A_arbace_cpp_abi_A_const_126.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_cpp_abi_layout_STAR__A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = id__0; if linked_826 == nil { tmp3 = ifn_827.Invoke_O__O(arg_828) } else { tmp3 = linked_826.(*A_arbace_cpp_abi_layout_STAR__A).Invoke_O_O__O(root_825, arg_828) } }
//line :224:1
		return nil }(); if tmp4 != nil { if jrt.ArithmeticException_InstanceOf(tmp4) { var ___5 *jrt.ArithmeticException = jrt.ArithmeticException_Cast(tmp4); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_cpp_abi_A_const_63; var tmp7 *lang.Keyword = A_arbace_cpp_abi_A_const_127; var tmp8 any; var root_836 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_cpp_abi_cls_A_fn_class); var ifn_838 lang.IFn; _ = ___5



			if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = id__0; if linked_837 == nil { tmp8 = ifn_838.Invoke_O__O(arg_839) } else { tmp8 = linked_837.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_836, arg_839) }; tmp3 = tmp5.Invoke_O_O_O_O__O(tmp6, Lit_44, tmp7.Invoke_O__O(tmp8), Lit_45) } else {
//line :224:1
				panic(tmp4) } }; return tmp3 } }





func A_arbace_cpp_abi_layout_STAR__A_New() *A_arbace_cpp_abi_layout_STAR__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_cpp_abi_layout_STAR__A) Ctor() {}
//line :230:1
func (t *A_arbace_cpp_abi_layout_STAR__A) Invoke_O_O__O(self, id__0 any) any { var c__2 any; var root_840 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_cpp_abi_cls_A_fn_class); var ifn_842 lang.IFn; if


	linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = id__0; if linked_841 == nil { c__2 = ifn_842.Invoke_O__O(arg_843) } else { c__2 = linked_841.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_840, arg_843) }; var dyn__3 any; var root_844 any = /*line :230:1*/A_arbace_cpp_abi_A_const_86.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_cpp_abi_dynamic_QMARK__A_fn_class); var ifn_846 lang.IFn; if



	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = id__0; if linked_845 == nil { dyn__3 = ifn_846.Invoke_O__O(arg_847) } else { dyn__3 = linked_845.(*A_arbace_cpp_abi_dynamic_QMARK__A).Invoke_O_O__O(root_844, arg_847) }; var pb__4 any; var root_848 any = /*line :230:1*/A_arbace_cpp_abi_A_const_128.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, A_arbace_cpp_abi_primary_base_A_fn_class); var ifn_850 lang.IFn; if





	linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = id__0; if linked_849 == nil { pb__4 = ifn_850.Invoke_O__O(arg_851) } else { pb__4 = linked_849.(*A_arbace_cpp_abi_primary_base_A).Invoke_O_O__O(root_848, arg_851) }; var pbv__5 any = /*line :230:1*/A_arbace_cpp_abi_A_const_80.Invoke_O__O(pb__4); var start__6 int64; var tmp1 any; var and__1927000168__auto____6 any = dyn__3; if








	jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(pb__4, nil); if or__1927000174__auto____7 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { tmp1 = pbv__5 } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { start__6 = 8 } else { start__6 = 0 }; var init_align__7 int64; if
	jrt.J2g_Truth(dyn__3) { init_align__7 = 8 } else { init_align__7 = 1 }; var bases__8 any; var root_852 any = /*line :230:1*/A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_854 lang.IFn; if










	linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_853 == nil { bases__8 = ifn_854.Invoke_O__O(arg_855) } else { bases__8 = linked_853.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_852, arg_855) }; var pbi__9 any; var tmp2 any; var and__1927000168__auto____9 any = pb__4; if
	jrt.J2g_Truth(and__1927000168__auto____9) { var root_856 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = pbv__5; if linked_857 == nil { tmp2 = ifn_858.Invoke_O__O(arg_859) } else { tmp2 = linked_857.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_856, arg_859) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) { var root_860 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_864 any = A_arbace_cpp_abi_A_const_129.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var fnbody__874 any = A_arbace_cpp_abi_layout_STAR__fn__677000157_A_New_O(pb__4); var tmp3 *jrt.Class; var fncls__873 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000157_A_fn_class; if fncls__873 == nil { var fncls__873d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__874); A_arbace_cpp_abi_layout_STAR__fn__677000157_A_fn_class = fncls__873d; tmp3 = fncls__873d } else { tmp3 = fncls__873 }; arg_867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__874, tmp3, nil); var arg_868 any = bases__8; if linked_865 == nil { arg_863 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { arg_863 = linked_865.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }; if linked_861 == nil { pbi__9 = ifn_862.Invoke_O__O(arg_863) } else { pbi__9 = linked_861.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_860, arg_863) } } else { pbi__9 = nil }; var em__10 any; var root_875 any = /*line :230:1*/A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_877 lang.IFn; if












	linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_876 == nil { em__10 = ifn_877.Invoke_O__O(arg_878) } else { em__10 = linked_876.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_875, arg_878) }; var floor__11 any; var root_879 any = /*line :230:1*/A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_881 lang.IFn; if
















	linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = A_arbace_cpp_abi_A_const_68; if linked_880 == nil { floor__11 = ifn_881.Invoke_O__O(arg_882) } else { floor__11 = linked_880.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_879, arg_882) }; var order__12 any; if
	jrt.J2g_Truth(pbi__9) { var root_883 any = A_arbace_cpp_abi_A_const_130.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = pbi__9; var arg_887 any; var root_888 any = A_arbace_cpp_abi_A_const_131.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var fnbody__894 any = A_arbace_cpp_abi_layout_STAR__fn__677000159_A_New_O(pbi__9); var tmp4 *jrt.Class; var fncls__893 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000159_A_fn_class; if fncls__893 == nil { var fncls__893d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__894); A_arbace_cpp_abi_layout_STAR__fn__677000159_A_fn_class = fncls__893d; tmp4 = fncls__893d } else { tmp4 = fncls__893 }; arg_891 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__894, tmp4, nil); var arg_892 any; var root_895 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(bases__8)).Ref(); if linked_896 == nil { arg_892 = ifn_897.Invoke_O__O(arg_898) } else { arg_892 = linked_896.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_895, arg_898) }; if linked_889 == nil { arg_887 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { arg_887 = linked_889.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }; if linked_884 == nil { order__12 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { order__12 = linked_884.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) } } else { var root_899 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(bases__8)).Ref(); if linked_900 == nil { order__12 = ifn_901.Invoke_O__O(arg_902) } else { order__12 = linked_900.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_899, arg_902) } }; var vec__677000148__13 any; var root_903 any = /*line :230:1*/A_arbace_cpp_abi_A_const_132.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_905 lang.IFn; if



















	linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any; var fnbody__1028 any = A_arbace_cpp_abi_layout_STAR__fn__677000162_A_New_O_O_O_O(floor__11, pbi__9, bases__8, em__10); var tmp5 *jrt.Class; var fncls__1027 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000162_A_fn_class; if fncls__1027 == nil { var fncls__1027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1028); A_arbace_cpp_abi_layout_STAR__fn__677000162_A_fn_class = fncls__1027d; tmp5 = fncls__1027d } else { tmp5 = fncls__1027 }; arg_906 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1028, tmp5, nil); var arg_907 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(start__6)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(init_align__7)).Ref(), lang.PersistentArrayMap_EMPTY.Ref()); var arg_908 any = order__12; if linked_904 == nil { vec__677000148__13 = ifn_905.Invoke_O_O_O__O(arg_906, arg_907, arg_908) } else { vec__677000148__13 = linked_904.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_903, arg_906, arg_907, arg_908) }; var off__14 any = /*line :230:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__677000148__13, lang.RT_IntCast_J__I_NoInit(0), nil); var align__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000148__13, lang.RT_IntCast_J__I_NoInit(1), nil); var boffm__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000148__13, lang.RT_IntCast_J__I_NoInit(2), nil); var boffs__17 any; var root_1029 any = A_arbace_cpp_abi_A_const_139.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1031 lang.IFn; if





































	linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var fnbody__1035 any = A_arbace_cpp_abi_layout_STAR__fn__677000169_A_New_O(boffm__16); var tmp6 *jrt.Class; var fncls__1034 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000169_A_fn_class; if fncls__1034 == nil { var fncls__1034d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1035); A_arbace_cpp_abi_layout_STAR__fn__677000169_A_fn_class = fncls__1034d; tmp6 = fncls__1034d } else { tmp6 = fncls__1034 }; arg_1032 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1035, tmp6, nil); var arg_1033 any; var root_1036 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(bases__8)).Ref(); if linked_1037 == nil { arg_1033 = ifn_1038.Invoke_O__O(arg_1039) } else { arg_1033 = linked_1037.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1036, arg_1039) }; if linked_1030 == nil { boffs__17 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { boffs__17 = linked_1030.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }; var uni__18 any = /*line :230:1*/A_arbace_cpp_abi_A_const_140.Invoke_O__O(c__2); var vec__677000151__19 any; var root_1040 any = A_arbace_cpp_abi_A_const_132.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1042 lang.IFn; if











































	linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var fnbody__1194 any = A_arbace_cpp_abi_layout_STAR__fn__677000172_A_New_O_O_O(floor__11, em__10, uni__18); var tmp7 *jrt.Class; var fncls__1193 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000172_A_fn_class; if fncls__1193 == nil { var fncls__1193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1194); A_arbace_cpp_abi_layout_STAR__fn__677000172_A_fn_class = fncls__1193d; tmp7 = fncls__1193d } else { tmp7 = fncls__1193 }; arg_1043 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1194, tmp7, nil); var arg_1044 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(8, lang.RT_LongCast_O__J_NoInit(off__14))).Ref(), align__15, lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref()); var arg_1045 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__2); if linked_1041 == nil { vec__677000151__19 = ifn_1042.Invoke_O_O_O__O(arg_1043, arg_1044, arg_1045) } else { vec__677000151__19 = linked_1041.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1040, arg_1043, arg_1044, arg_1045) }; var offb__20 any = /*line :230:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__677000151__19, lang.RT_IntCast_J__I_NoInit(0), nil); var align__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000151__19, lang.RT_IntCast_J__I_NoInit(1), nil); var foffs__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000151__19, lang.RT_IntCast_J__I_NoInit(2), nil); var bitoffs__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000151__19, lang.RT_IntCast_J__I_NoInit(3), nil); var dsize0__24 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(offb__20), 7), 8); var nvsize__25 int64; var tmp8 any; var root_1195 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1197 lang.IFn; if













































































	linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = floor__11; if linked_1196 == nil { tmp8 = ifn_1197.Invoke_O__O(arg_1198) } else { tmp8 = linked_1196.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1195, arg_1198) }; nvsize__25 = lang.Numbers_Max_J_J__J_NoInit(dsize0__24, lang.RT_LongCast_O__J_NoInit(tmp8)); var nvalign__26 int64; var tmp9 int64 = /*line :230:1*/lang.RT_LongCast_O__J_NoInit(align__21); var tmp10 any; var or__1927000174__auto____26 any = A_arbace_cpp_abi_A_const_142.Invoke_O__O(c__2); if















































































	jrt.J2g_Truth(or__1927000174__auto____26) { tmp10 = or__1927000174__auto____26 } else { tmp10 = A_arbace_cpp_abi_A_const_143 }; nvalign__26 = lang.Numbers_Max_J_J__J_NoInit(tmp9, lang.RT_LongCast_O__J_NoInit(tmp10)); var pre__27 any; var tmp11 any = A_arbace_cpp_abi_A_const_87; var tmp12 any = /*line :230:1*/jrt.Long_ValueOf_J__Long_NoInit(nvsize__25).Ref(); var tmp13 any = A_arbace_cpp_abi_A_const_133; var tmp14 any = jrt.Long_ValueOf_J__Long_NoInit(nvalign__26).Ref(); var tmp15 any = A_arbace_cpp_abi_A_const_144; var tmp16 any = jrt.Long_ValueOf_J__Long_NoInit(dsize0__24).Ref(); var tmp17 any = A_arbace_cpp_abi_A_const_102; var tmp18 any = A_arbace_cpp_abi_A_const_145; var tmp19 any = A_arbace_cpp_abi_A_const_77; var tmp20 any = A_arbace_cpp_abi_A_const_146; var tmp21 any = A_arbace_cpp_abi_A_const_134; var tmp22 any; var root_1199 any = A_arbace_cpp_abi_A_const_110.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_cpp_abi_pod_for_layout_QMARK__A_fn_class); var ifn_1201 lang.IFn; if

















































































	linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = id__0; if linked_1200 == nil { tmp22 = ifn_1201.Invoke_O__O(arg_1202) } else { tmp22 = linked_1200.(*A_arbace_cpp_abi_pod_for_layout_QMARK__A).Invoke_O_O__O(root_1199, arg_1202) }; pre__27 = /*line :230:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, foffs__22, tmp18, bitoffs__23, tmp19, boffs__17, tmp20, dyn__3, tmp21, tmp22, A_arbace_cpp_abi_A_const_88, pb__4)); var ___28 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_147.GetRawRoot__O()); var tmp24 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var tmp25 any = A_arbace_cpp_abi_A_const_125; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_28.GetRawRoot__O()); var tmp27 any = A_arbace_cpp_abi_A_const_65; var tmp28 int64; var root_1222 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1222, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1224 lang.IFn; _ = ___28; if


















































































	linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 int64 = nvsize__25; var arg_1226 int64 = nvalign__26; if linked_1223 == nil { tmp28 = lang.RT_LongCast_O__J_NoInit(ifn_1224.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1225).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_1226).Ref())) } else { tmp28 = linked_1223.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1222, arg_1225, arg_1226) }; var tmp29 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(1, lang.RT_LongCast_J__J_NoInit(tmp28))).Ref(); var tmp30 any = A_arbace_cpp_abi_A_const_66; ___28 = tmp23.Invoke_O_O_O_O__O(id__0, tmp24, tmp25, tmp26.Invoke_O_O_O_O_O_O_O_O_O__O(pre__27, tmp27, tmp29, tmp30, jrt.Long_ValueOf_J__Long_NoInit(nvalign__26).Ref(), A_arbace_cpp_abi_A_const_119, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_cpp_abi_A_const_148, jrt.Boolean_TRUE.Ref())); var ip__29 any; var root_1227 any = /*line :230:1*/A_arbace_cpp_abi_A_const_91.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, A_arbace_cpp_abi_indirect_primaries_A_fn_class); var ifn_1229 lang.IFn; if





















































































	linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = id__0; if linked_1228 == nil { ip__29 = ifn_1229.Invoke_O__O(arg_1230) } else { ip__29 = linked_1228.(*A_arbace_cpp_abi_indirect_primaries_A).Invoke_O_O__O(root_1227, arg_1230) }; var vbo__30 any = /*line :230:1*/jrt.LinkedHashMap_New(); var mark_BANG___31 any; var fnbody__1281 any = A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_New_O(vbo__30); var tmp31 *jrt.Class; var fncls__1280 *jrt.Class = A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_fn_class; if























































































	fncls__1280 == nil { var fncls__1280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__1281); A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_fn_class = fncls__1280d; tmp31 = fncls__1280d } else { tmp31 = fncls__1280 }; mark_BANG___31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1281, tmp31, nil); var ___32 any; _ = ___32; if



	jrt.J2g_Truth(pbv__5) { ___32 = jrt.HashMap_Cast(vbo__30).Put_O_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(pb__4), A_arbace_cpp_abi_A_const_68) } else { ___32 = nil }; var ___33 any = /*line :230:1*/lang.IFn_Cast(mark_BANG___31).Invoke_O_O__O(id__0, A_arbace_cpp_abi_A_const_68); var vec__677000154__34 any; var root_1282 any = A_arbace_cpp_abi_A_const_132.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1284 lang.IFn; _ = ___33; if






























































































	linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var fnbody__1356 any = A_arbace_cpp_abi_layout_STAR__fn__677000195_A_New_O_O_O_O_O(floor__11, vbo__30, ip__29, mark_BANG___31, em__10); var tmp32 *jrt.Class; var fncls__1355 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000195_A_fn_class; if fncls__1355 == nil { var fncls__1355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__1356); A_arbace_cpp_abi_layout_STAR__fn__677000195_A_fn_class = fncls__1355d; tmp32 = fncls__1355d } else { tmp32 = fncls__1355 }; arg_1285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1356, tmp32, nil); var arg_1286 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(dsize0__24).Ref(), jrt.Long_ValueOf_J__Long_NoInit(nvalign__26).Ref()); var arg_1287 any; var root_1357 any = A_arbace_cpp_abi_A_const_94.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, A_arbace_cpp_abi_vbases_A_fn_class); var ifn_1359 lang.IFn; if














	linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = id__0; if linked_1358 == nil { arg_1287 = ifn_1359.Invoke_O__O(arg_1360) } else { arg_1287 = linked_1358.(*A_arbace_cpp_abi_vbases_A).Invoke_O_O__O(root_1357, arg_1360) }; if /*line :325:1*/ linked_1283 == nil { vec__677000154__34 = ifn_1284.Invoke_O_O_O__O(arg_1285, arg_1286, arg_1287) } else { vec__677000154__34 = linked_1283.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1282, arg_1285, arg_1286, arg_1287) }; var dsize__35 any = /*line :230:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__677000154__34, lang.RT_IntCast_J__I_NoInit(0), nil); var align__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000154__34, lang.RT_IntCast_J__I_NoInit(1), nil); var size__37 int64; var tmp33 int64; var root_1361 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1361, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1363 lang.IFn; if














































































































	linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 int64; var tmp34 int64 = lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(dsize__35), nvsize__25); var tmp35 any; var root_1366 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = floor__11; if linked_1367 == nil { tmp35 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp35 = linked_1367.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1366, arg_1369) }; arg_1364 = lang.Numbers_Max_J_J__J_NoInit(tmp34, lang.RT_LongCast_O__J_NoInit(tmp35)); var arg_1365 any = align__36; if linked_1362 == nil { tmp33 = lang.RT_LongCast_O__J_NoInit(ifn_1363.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1364).Ref(), arg_1365)) } else { tmp33 = linked_1362.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1361, arg_1364, lang.RT_LongCast_O__J_NoInit(arg_1365)) }; size__37 = lang.Numbers_Max_J_J__J_NoInit(1, lang.RT_LongCast_J__J_NoInit(tmp33)); var l__38 any; var tmp36 lang.IFn = /*line :230:1*/lang.IFn_Cast(A_arbace_cpp_abi_A_const_28.GetRawRoot__O()); var tmp37 any = A_arbace_cpp_abi_A_const_65; var tmp38 any = jrt.Long_ValueOf_J__Long_NoInit(size__37).Ref(); var tmp39 any = A_arbace_cpp_abi_A_const_66; var tmp40 any = A_arbace_cpp_abi_A_const_119; var tmp41 any; var root_1380 any = A_arbace_cpp_abi_A_const_111.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1382 lang.IFn; if















































































































	linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1384 any = vbo__30; if linked_1381 == nil { tmp41 = ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { tmp41 = linked_1381.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) }; l__38 = tmp36.Invoke_O_O_O_O_O_O_O__O(pre__27, tmp37, tmp38, tmp39, align__36, tmp40, tmp41); var tmp42 any; var and__1927000168__auto____39 any; var or__1927000174__auto____39 any =



	A_arbace_cpp_abi_A_const_149.Invoke_O__O(c__2); if jrt.J2g_Truth(or__1927000174__auto____39) { and__1927000168__auto____39 = or__1927000174__auto____39 } else { var root_1385 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = A_arbace_cpp_abi_A_const_150.Invoke_O__O(c__2); if linked_1386 == nil { and__1927000168__auto____39 = ifn_1387.Invoke_O__O(arg_1388) } else { and__1927000168__auto____39 = linked_1386.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1385, arg_1388) } }; if jrt.J2g_Truth(and__1927000168__auto____39) {
		var root_1389 any = A_arbace_cpp_abi_A_const_100.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any; var fnbody__1403 any = A_arbace_cpp_abi_layout_STAR__fn__677000202_A_New(); var tmp43 *jrt.Class; var fncls__1402 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000202_A_fn_class; if fncls__1402 == nil { var fncls__1402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_cpp_abi_layout_STAR__fn__677000202_A_fn_class = fncls__1402d; tmp43 = fncls__1402d } else { tmp43 = fncls__1402 }; arg_1392 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1403, tmp43, nil); var arg_1393 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_122.GetRawRoot__O()); var tmp45 any; var root_1410 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1412 lang.IFn
		if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = A_arbace_cpp_abi_A_const_81; var arg_1414 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__2); if linked_1411 == nil { tmp45 = ifn_1412.Invoke_O_O__O(arg_1413, arg_1414) } else { tmp45 = linked_1411.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1410, arg_1413, arg_1414) }; var tmp46 any = tmp45; var tmp47 any; var root_1415 any = A_arbace_cpp_abi_A_const_94.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, A_arbace_cpp_abi_vbases_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = id__0; if linked_1416 == nil { tmp47 = ifn_1417.Invoke_O__O(arg_1418) } else { tmp47 = linked_1416.(*A_arbace_cpp_abi_vbases_A).Invoke_O_O__O(root_1415, arg_1418) }; var tmp48 any = tmp47; var tmp49 any; var root_1419 any = A_arbace_cpp_abi_A_const_152.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1421 lang.IFn
		if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any; var fnbody__1439 any = A_arbace_cpp_abi_layout_STAR__fn__677000204_A_New(); var tmp50 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000204_A_fn_class; if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_cpp_abi_layout_STAR__fn__677000204_A_fn_class = fncls__1438d; tmp50 = fncls__1438d } else { tmp50 = fncls__1438 }; arg_1422 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1439, tmp50, nil); var arg_1423 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__2); if linked_1420 == nil { tmp49 = ifn_1421.Invoke_O_O__O(arg_1422, arg_1423) } else { tmp49 = linked_1420.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1419, arg_1422, arg_1423) }
//line :348:1
		arg_1393 = tmp44.Invoke_O_O_O__O(tmp46, tmp48, tmp49)
//line :347:1
		if linked_1390 == nil { tmp42 = ifn_1391.Invoke_O_O__O(arg_1392, arg_1393) } else { tmp42 = linked_1390.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1389, arg_1392, arg_1393) } } else {
//line :346:1
			tmp42 = and__1927000168__auto____39 }; if jrt.J2g_Truth(tmp42) {



				lang.IFn_Cast(A_arbace_cpp_abi_A_const_147.GetRawRoot__O()).Invoke_O_O_O_O__O(id__0, A_arbace_cpp_abi_A_const_28.GetRawRoot__O(), A_arbace_cpp_abi_A_const_125, l__38) } else {
					lang.IFn_Cast(A_arbace_cpp_abi_A_const_147.GetRawRoot__O()).Invoke_O_O_O__O(id__0, A_arbace_cpp_abi_A_const_25.GetRawRoot__O(), A_arbace_cpp_abi_A_const_125) }; return l__38 }
//line :242:1
func A_arbace_cpp_abi_layout_STAR__fn__677000157_A_New_O(p0 any) *A_arbace_cpp_abi_layout_STAR__fn__677000157_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000157_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000157_A) Ctor_O(c__pb any) { t.F_pb = c__pb }
//line :242:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000157_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__2), A_arbace_cpp_abi_A_const_81.Invoke_O__O(t.F_pb)); if and__1927000168__auto____3 { var root_869 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__2); if linked_870 == nil { tmp1 = ifn_871.Invoke_O__O(arg_872) } else { tmp1 = linked_870.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_869, arg_872) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return i__1 } else { return nil } }





func A_arbace_cpp_abi_layout_STAR__fn__677000159_A_New_O(p0 any) *A_arbace_cpp_abi_layout_STAR__fn__677000159_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000159_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000159_A) Ctor_O(c__pbi any) { t.F_pbi = c__pbi }
//line :248:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000159_A) Invoke_O_O__O(self, p1__677000146_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__677000146_SHARP___1, t.F_pbi)).Ref() }

func A_arbace_cpp_abi_layout_STAR__fn__677000162_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_abi_layout_STAR__fn__677000162_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000162_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000162_A) Ctor_O_O_O_O(c__floor, c__pbi, c__bases, c__em any) { t.F_floor = c__floor; t.F_pbi = c__pbi; t.F_bases = c__bases; t.F_em = c__em }
//line :250:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000162_A) Invoke_O_O_O__O(self, p__677000161__1, i__2 any) any { var vec__677000163__3 any = p__677000161__1; var off__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000163__3, lang.RT_IntCast_J__I_NoInit(0), nil); var align__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000163__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000163__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any = t.F_bases; var b__7 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__2)); var bid__8 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__7); var bl__9 any; var root_909 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_cpp_abi_layout_A_fn_class); var ifn_911 lang.IFn; if


	linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = bid__8; if linked_910 == nil { bl__9 = ifn_911.Invoke_O__O(arg_912) } else { bl__9 = linked_910.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_909, arg_912) }; var ba__10 int64 = /*line :250:1*/lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_133.Invoke_O__O(bl__9)); var bsz__11 int64; var tmp2 any; if




	jrt.J2g_Truth(A_arbace_cpp_abi_A_const_134.Invoke_O__O(bl__9)) { tmp2 = A_arbace_cpp_abi_A_const_65.Invoke_O__O(bl__9) } else { tmp2 = A_arbace_cpp_abi_A_const_87.Invoke_O__O(bl__9) }; bsz__11 = lang.RT_LongCast_O__J_NoInit(tmp2); if
	jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(b__7)) { return lang.Tuple_Create_O_O_O__IPersistentVector(off__4, align__5, m__6) } else { if lang.Util_Equiv_O_O__Z_NoInit(i__2, t.F_pbi) {

		var root_946 any = A_arbace_cpp_abi_A_const_137.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_cpp_abi_place_BANG__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = t.F_em; var arg_950 any; var root_951 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_951, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = bid__8; var arg_956 any = jrt.Boolean_FALSE.Ref(); if linked_952 == nil { arg_950 = ifn_953.Invoke_O_O_O__O(arg_954, A_arbace_cpp_abi_A_const_68, arg_956) } else { arg_950 = linked_952.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_951, arg_954, 0, arg_956) }; if linked_947 == nil { ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { linked_947.(*A_arbace_cpp_abi_place_BANG__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }
//line :256:1
		var tmp3 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(off__4), bsz__11)).Ref(); var tmp4 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(align__5), ba__10)).Ref(); var tmp5 any; var root_957 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_959 lang.IFn

		if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = m__6; var arg_961 any = i__2; var arg_962 any = A_arbace_cpp_abi_A_const_68; if linked_958 == nil { tmp5 = ifn_959.Invoke_O_O_O__O(arg_960, arg_961, arg_962) } else { tmp5 = linked_958.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_957, arg_960, arg_961, arg_962) }
//line :256:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp4, tmp5) } else { var tmp6 any; var and__1927000168__auto____12 any; var root_913 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_915 lang.IFn


			if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = bid__8; if linked_914 == nil { and__1927000168__auto____12 = ifn_915.Invoke_O__O(arg_916) } else { and__1927000168__auto____12 = linked_914.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_913, arg_916) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var root_917 any = A_arbace_cpp_abi_A_const_135.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_cpp_abi_can_place_QMARK__A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = t.F_em; var arg_921 any; var root_922 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_922, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = bid__8; var arg_927 any = jrt.Boolean_FALSE.Ref(); if linked_923 == nil { arg_921 = ifn_924.Invoke_O_O_O__O(arg_925, A_arbace_cpp_abi_A_const_68, arg_927) } else { arg_921 = linked_923.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_922, arg_925, 0, arg_927) }; if linked_918 == nil { tmp6 = ifn_919.Invoke_O_O__O(arg_920, arg_921) } else { tmp6 = linked_918.(*A_arbace_cpp_abi_can_place_QMARK__A).Invoke_O_O_O__O(root_917, arg_920, arg_921) } } else { tmp6 = and__1927000168__auto____12 }
//line :256:1
			if jrt.J2g_Truth(tmp6) {



				var root_963 any = A_arbace_cpp_abi_A_const_137.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, A_arbace_cpp_abi_place_BANG__A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = t.F_em; var arg_967 any; var root_968 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_968, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = bid__8; var arg_973 any = jrt.Boolean_FALSE.Ref(); if linked_969 == nil { arg_967 = ifn_970.Invoke_O_O_O__O(arg_971, A_arbace_cpp_abi_A_const_68, arg_973) } else { arg_967 = linked_969.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_968, arg_971, 0, arg_973) }; if linked_964 == nil { ifn_965.Invoke_O_O__O(arg_966, arg_967) } else { linked_964.(*A_arbace_cpp_abi_place_BANG__A).Invoke_O_O_O__O(root_963, arg_966, arg_967) }; var root_974 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = t.F_floor; var arg_978 any = A_arbace_cpp_abi_A_const_138.GetRawRoot__O(); var arg_979 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_65.Invoke_O__O(bl__9))).Ref(); if linked_975 == nil { ifn_976.Invoke_O_O_O__O(arg_977, arg_978, arg_979) } else { linked_975.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_974, arg_977, arg_978, arg_979) }
//line :256:1
				var tmp7 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(align__5), ba__10)).Ref(); var tmp8 any; var root_980 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_982 lang.IFn



				if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = m__6; var arg_984 any = i__2; var arg_985 any = A_arbace_cpp_abi_A_const_68; if linked_981 == nil { tmp8 = ifn_982.Invoke_O_O_O__O(arg_983, arg_984, arg_985) } else { tmp8 = linked_981.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_980, arg_983, arg_984, arg_985) }
//line :256:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(off__4, tmp7, tmp8) } else { if A_arbace_cpp_abi_A_const_118 != nil { var o__12 any; var tmp9 *lang.Compiler_AOTFn; var fnbody__945 any = A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_New_O_J_O_O(off__4, ba__10, bid__8, t.F_em); var tmp10 *jrt.Class
					var fncls__944 /*line :256:1*/*jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_fn_class




					if fncls__944 == nil { var fncls__944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__945); A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_fn_class = fncls__944d; tmp10 = fncls__944d } else { tmp10 = fncls__944 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__945, tmp10, nil); o__12 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O()

					var root_986 any = A_arbace_cpp_abi_A_const_137.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_cpp_abi_place_BANG__A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = t.F_em; var arg_990 any; var root_991 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_991, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = bid__8; var arg_995 any = o__12; var arg_996 any = jrt.Boolean_FALSE.Ref(); if linked_992 == nil { arg_990 = ifn_993.Invoke_O_O_O__O(arg_994, arg_995, arg_996) } else { arg_990 = linked_992.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_991, arg_994, lang.RT_LongCast_O__J_NoInit(arg_995), arg_996) }; if linked_987 == nil { ifn_988.Invoke_O_O__O(arg_989, arg_990) } else { linked_987.(*A_arbace_cpp_abi_place_BANG__A).Invoke_O_O_O__O(root_986, arg_989, arg_990) }
					var tmp11 any; var root_997 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = bid__8; if linked_998 == nil { tmp11 = ifn_999.Invoke_O__O(arg_1000) } else { tmp11 = linked_998.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_997, arg_1000) }; if jrt.J2g_Truth(tmp11) { var root_1001 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = t.F_floor; var arg_1005 any = A_arbace_cpp_abi_A_const_138.GetRawRoot__O(); var arg_1006 any; var na_1007 any = o__12; var na_1008 int64 = lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_65.Invoke_O__O(bl__9)); if jrt.Long_InstanceOf(na_1007) { var n0_1009 int64 = jrt.NN(jrt.Long_Cast(na_1007)).LongValue__J(); var n1_1010 int64 = na_1008; var nr_1011 int64 = n0_1009 + n1_1010; if (n0_1009^nr_1011)&(n1_1010^nr_1011) >= 0 { arg_1006 = jrt.Long_ValueOf_J__Long_NoInit(nr_1011).Ref() } else { arg_1006 = lang.Numbers_Add_O_J__Number_NoInit(na_1007, na_1008) } } else { arg_1006 = lang.Numbers_Add_O_J__Number_NoInit(na_1007, na_1008) }; if linked_1002 == nil { ifn_1003.Invoke_O_O_O__O(arg_1004, arg_1005, arg_1006) } else { linked_1002.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006) } }
//line :256:1
					var tmp12 any; var tmp13 any; var root_1012 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_1014 lang.IFn








					if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = bid__8; if linked_1013 == nil { tmp13 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp13 = linked_1013.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }; if jrt.J2g_Truth(tmp13) { tmp12 = off__4 } else { var na_1016 any = o__12; var na_1017 int64 = bsz__11; if jrt.Long_InstanceOf(na_1016) { var n0_1018 int64 = jrt.NN(jrt.Long_Cast(na_1016)).LongValue__J(); var n1_1019 int64 = na_1017; var nr_1020 int64 = n0_1018 + n1_1019; if (n0_1018^nr_1020)&(n1_1019^nr_1020) >= 0 { tmp12 = jrt.Long_ValueOf_J__Long_NoInit(nr_1020).Ref() } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_1016, na_1017) } } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_1016, na_1017) } }
//line :256:1
					var tmp14 any = tmp12; var tmp15 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(align__5), ba__10)).Ref(); var tmp16 any; var root_1021 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1023 lang.IFn








					if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = m__6; var arg_1025 any = i__2; var arg_1026 any = o__12; if linked_1022 == nil { tmp16 = ifn_1023.Invoke_O_O_O__O(arg_1024, arg_1025, arg_1026) } else { tmp16 = linked_1022.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1021, arg_1024, arg_1025, arg_1026) }
//line :256:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp14, tmp15, tmp16) } else { return nil } } } } }




func A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_New_O_J_O_O(p0 any, p1 int64, p2, p3 any) *A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A{}; t.Ctor_O_J_O_O(p0, p1, p2, p3); return t }
//line :261:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A) Ctor_O_J_O_O(c__off any, c__ba int64, c__bid, c__em any) { t.F_off = c__off; t.F_ba = c__ba; t.F_bid = c__bid; t.F_em = c__em }
//line :261:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A) Invoke_O__O(self any) any { { var o__1 int64; var tmp1 int64; var root_928 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_928, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any; var t_ any = t.F_off; t.F_off = nil; arg_931 = t_; var arg_932 int64 = t.F_ba; if linked_929 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_930.Invoke_O_O__O(arg_931, jrt.Long_ValueOf_J__Long_NoInit(arg_932).Ref())) } else { tmp1 = linked_929.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_928, lang.RT_LongCast_O__J_NoInit(arg_931), arg_932) }; o__1 = lang.RT_LongCast_J__J_NoInit(tmp1); L1: for {
												var tmp2 any; var root_933 any = A_arbace_cpp_abi_A_const_135.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_cpp_abi_can_place_QMARK__A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = t.F_em; var arg_937 any; var root_938 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_938, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = t.F_bid; var arg_942 int64 = o__1; var arg_943 any = jrt.Boolean_FALSE.Ref(); if linked_939 == nil { arg_937 = ifn_940.Invoke_O_O_O__O(arg_941, jrt.Long_ValueOf_J__Long_NoInit(arg_942).Ref(), arg_943) } else { arg_937 = linked_939.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_938, arg_941, arg_942, arg_943) }; if linked_934 == nil { tmp2 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { tmp2 = linked_934.(*A_arbace_cpp_abi_can_place_QMARK__A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }; if jrt.J2g_Truth(tmp2) { return jrt.Long_ValueOf_J__Long_NoInit(o__1).Ref() } else { o__1 = lang.Numbers_Add_J_J__J_NoInit(o__1, t.F_ba); continue L1 } } }; /*line :261:1*/panic("j2g: unreachable") }






func A_arbace_cpp_abi_layout_STAR__fn__677000169_A_New_O(p0 any) *A_arbace_cpp_abi_layout_STAR__fn__677000169_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000169_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000169_A) Ctor_O(c__boffm any) { t.F_boffm = c__boffm }
//line :268:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000169_A) Invoke_O_O__O(self, p1__677000147_SHARP___1 any) any { return lang.RT_Get_O_O__O_NoInit(t.F_boffm, p1__677000147_SHARP___1) }





func A_arbace_cpp_abi_layout_STAR__fn__677000172_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_abi_layout_STAR__fn__677000172_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000172_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :274:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000172_A) Ctor_O_O_O(c__floor, c__em, c__uni any) { t.F_floor = c__floor; t.F_em = c__em; t.F_uni = c__uni }
//line :274:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000172_A) Invoke_O_O_O__O(self, p__677000171__1, f__2 any) any { var vec__677000173__3 any = p__677000171__1; var offb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000173__3, lang.RT_IntCast_J__I_NoInit(0), nil); var align__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000173__3, lang.RT_IntCast_J__I_NoInit(1), nil); var foffs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000173__3, lang.RT_IntCast_J__I_NoInit(2), nil); var bitoffs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000173__3, lang.RT_IntCast_J__I_NoInit(3), nil); var vec__677000176__8 any; var root_1046 any = A_arbace_cpp_abi_A_const_58.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, A_arbace_cpp_abi_size_align_A_fn_class); var ifn_1048 lang.IFn; if
														linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__2); if linked_1047 == nil { vec__677000176__8 = ifn_1048.Invoke_O__O(arg_1049) } else { vec__677000176__8 = linked_1047.(*A_arbace_cpp_abi_size_align_A).Invoke_O_O__O(root_1046, arg_1049) }; var s__9 any = /*line :274:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__677000176__8, lang.RT_IntCast_J__I_NoInit(0), nil); var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000176__8, lang.RT_IntCast_J__I_NoInit(1), nil); var s__11 int64 = lang.RT_LongCast_O__J_NoInit(s__9); var a__12 int64 = lang.RT_LongCast_O__J_NoInit(a__10); var offb__13 int64 = lang.RT_LongCast_O__J_NoInit(offb__4); var start__14 int64; if


	jrt.J2g_Truth(t.F_uni) { start__14 = 0 } else { start__14 = offb__13 }; var temp__1927000408__auto____15 any = /*line :274:1*/A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__2); if



	jrt.J2g_Truth(temp__1927000408__auto____15) { var w__16 any = temp__1927000408__auto____15; var w__17 int64 = lang.RT_LongCast_O__J_NoInit(w__16); var ua__18 int64 = lang.Numbers_Multiply_J_J__J_NoInit(8, a__12); var b__19 any

		if lang.Numbers_IsZero_J__Z_NoInit(w__17) { var tmp1 int64; var root_1050 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1050, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 int64 = start__14; var arg_1054 int64 = ua__18; if linked_1051 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1052.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1053).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_1054).Ref())) } else { tmp1 = linked_1051.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1050, arg_1053, arg_1054) }; b__19 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(tmp1)).Ref() } else { var tmp2 any; var root_1055 any = A_arbace_cpp_abi_A_const_141.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1057 lang.IFn
			if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(start__14, ua__18)).Ref(); var arg_1059 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(start__14, w__17), -1), ua__18)).Ref(); if linked_1056 == nil { tmp2 = ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { tmp2 = linked_1056.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) }
//line :280:1
			if jrt.J2g_Truth(tmp2) {
				var tmp3 int64; var root_1060 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1060, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 int64 = start__14; var arg_1064 int64 = ua__18; if linked_1061 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_1062.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1063).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_1064).Ref())) } else { tmp3 = linked_1061.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1060, arg_1063, arg_1064) }; b__19 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(tmp3)).Ref() } else {
//line :280:1
					if A_arbace_cpp_abi_A_const_118 != nil { b__19 = jrt.Long_ValueOf_J__Long_NoInit(start__14).Ref() } else { b__19 = nil } } }
//line :278:1
		var tmp4 any




		if jrt.J2g_Truth(t.F_uni) { var tmp5 jrt.Number_I; var na_1133 any = b__19; var na_1134 int64 = w__17; if jrt.Long_InstanceOf(na_1133) { var n0_1135 int64 = jrt.NN(jrt.Long_Cast(na_1133)).LongValue__J(); var n1_1136 int64 = na_1134; var nr_1137 int64 = n0_1135 + n1_1136; if (n0_1135^nr_1137)&(n1_1136^nr_1137) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1137)) } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_1133, na_1134) } } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_1133, na_1134) }; tmp4 = lang.Numbers_Max_J_O__O_NoInit(offb__13, tmp5) } else { var na_1138 any = b__19; var na_1139 int64 = w__17; if jrt.Long_InstanceOf(na_1138) { var n0_1140 int64 = jrt.NN(jrt.Long_Cast(na_1138)).LongValue__J(); var n1_1141 int64 = na_1139; var nr_1142 int64 = n0_1140 + n1_1141; if (n0_1140^nr_1142)&(n1_1141^nr_1142) >= 0 { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(nr_1142).Ref() } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_1138, na_1139) } } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_1138, na_1139) } }
//line :278:1
		var tmp6 any = tmp4; var tmp7 any




		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__2)) { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(align__5), a__12)).Ref() } else { tmp7 = align__5 }
//line :278:1
		var tmp8 any = tmp7; var tmp9 any; var root_1143 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1145 lang.IFn




		if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = foffs__6; var arg_1147 any; var na_1148 int64 = a__12; var na_1149 any; var na_1150 any = b__19; var na_1151 int64 = ua__18; if jrt.Long_InstanceOf(na_1150) { var n0_1152 int64 = jrt.NN(jrt.Long_Cast(na_1150)).LongValue__J(); var n1_1153 int64 = na_1151; if n1_1153 == 0 { na_1149 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1150, na_1151) } else { na_1149 = jrt.Long_ValueOf_J__Long_NoInit(n0_1152 / n1_1153).Ref() } } else { na_1149 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1150, na_1151) }; if jrt.Long_InstanceOf(na_1149) { var n0_1155 int64 = na_1148; var n1_1156 int64 = jrt.NN(jrt.Long_Cast(na_1149)).LongValue__J(); var nr_1157 int64 = n0_1155 * n1_1156; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = n0_1155 == -9223372036854775808; if tmp13 { tmp13 = n1_1156 < 0 }; tmp12 = tmp13; tmp11 = !tmp12; if tmp11 { var tmp14 bool; tmp14 = n1_1156 == 0; if !tmp14 { tmp14 = nr_1157/n1_1156 == n0_1155 }; tmp11 = tmp14 }; tmp10 = tmp11; if tmp10 { arg_1147 = jrt.Long_ValueOf_J__Long_NoInit(nr_1157).Ref() } else { arg_1147 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1148, na_1149) } } else { arg_1147 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1148, na_1149) }; if linked_1144 == nil { tmp9 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { tmp9 = linked_1144.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }
//line :278:1
		var tmp15 any = tmp9; var tmp16 any; var root_1158 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1160 lang.IFn




		if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = bitoffs__7; var arg_1162 any = b__19; if linked_1159 == nil { tmp16 = ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { tmp16 = linked_1159.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) }
//line :278:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp15, tmp16) } else { var ovl__16 any = A_arbace_cpp_abi_A_const_96.Invoke_O__O(f__2); var emp__17 any
			var and__1927000168__auto____17 any = ovl__16









			if jrt.J2g_Truth(and__1927000168__auto____17) { var root_1065 any = A_arbace_cpp_abi_A_const_101.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, A_arbace_cpp_abi_empty_member_QMARK__A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = f__2; if linked_1066 == nil { emp__17 = ifn_1067.Invoke_O__O(arg_1068) } else { emp__17 = linked_1066.(*A_arbace_cpp_abi_empty_member_QMARK__A).Invoke_O_O__O(root_1065, arg_1068) } } else { emp__17 = and__1927000168__auto____17 }
//line :278:1
			var o__18 int64











			if jrt.J2g_Truth(emp__17) { o__18 = 0 } else { var tmp17 int64; var root_1069 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1069, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(start__14, 7), 8); var arg_1073 int64 = a__12; if linked_1070 == nil { tmp17 = lang.RT_LongCast_O__J_NoInit(ifn_1071.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1072).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_1073).Ref())) } else { tmp17 = linked_1070.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1069, arg_1072, arg_1073) }; o__18 = lang.RT_LongCast_J__J_NoInit(tmp17) }
//line :278:1
			var dsz__19 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(offb__13, 7), 8); var o__20 any; var tmp18 any; var or__1927000174__auto____20 any = t.F_uni













			if jrt.J2g_Truth(or__1927000174__auto____20) { tmp18 = or__1927000174__auto____20 } else { var root_1074 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any; var root_1078 any = A_arbace_cpp_abi_A_const_121.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1078, A_arbace_cpp_abi_field_empties_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__2); if linked_1079 == nil { arg_1077 = ifn_1080.Invoke_O_O__O(arg_1081, A_arbace_cpp_abi_A_const_68) } else { arg_1077 = linked_1079.(*A_arbace_cpp_abi_field_empties_A).InvokePrim_O_O_J__O(root_1078, arg_1081, 0) }; if linked_1075 == nil { tmp18 = ifn_1076.Invoke_O__O(arg_1077) } else { tmp18 = linked_1075.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1074, arg_1077) } }; if jrt.J2g_Truth(tmp18) { o__20 = jrt.Long_ValueOf_J__Long_NoInit(o__18).Ref() } else {

				var tmp19 *lang.Compiler_AOTFn; var fnbody__1103 any = A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_New_O_J_J_J_O(f__2, a__12, dsz__19, o__18, t.F_em); var tmp20 *jrt.Class; var fncls__1102 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_fn_class; if fncls__1102 == nil { var fncls__1102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1103); A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_fn_class = fncls__1102d; tmp20 = fncls__1102d } else { tmp20 = fncls__1102 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1103, tmp20, nil); o__20 = Up_Compiler_AOTFn_IFn(tmp19).Invoke__O() }
//line :278:1
			var ___21 any; _ = ___21



















			if jrt.J2g_Truth(t.F_uni) { ___21 = nil } else { var root_1104 any = A_arbace_cpp_abi_A_const_137.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_cpp_abi_place_BANG__A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = t.F_em; var arg_1108 any; var root_1109 any = A_arbace_cpp_abi_A_const_121.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1109, A_arbace_cpp_abi_field_empties_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__2); var arg_1113 any = o__20; if linked_1110 == nil { arg_1108 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { arg_1108 = linked_1110.(*A_arbace_cpp_abi_field_empties_A).InvokePrim_O_O_J__O(root_1109, arg_1112, lang.RT_LongCast_O__J_NoInit(arg_1113)) }; if linked_1105 == nil { ___21 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { ___21 = linked_1105.(*A_arbace_cpp_abi_place_BANG__A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) } }
//line :278:1
			var ___22 any; _ = ___22




















			if jrt.J2g_Truth(emp__17) { var root_1114 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = t.F_floor; var arg_1118 any = A_arbace_cpp_abi_A_const_138.GetRawRoot__O(); var arg_1119 any; var na_1120 any = o__20; var na_1121 int64 = s__11; if jrt.Long_InstanceOf(na_1120) { var n0_1122 int64 = jrt.NN(jrt.Long_Cast(na_1120)).LongValue__J(); var n1_1123 int64 = na_1121; var nr_1124 int64 = n0_1122 + n1_1123; if (n0_1122^nr_1124)&(n1_1123^nr_1124) >= 0 { arg_1119 = jrt.Long_ValueOf_J__Long_NoInit(nr_1124).Ref() } else { arg_1119 = lang.Numbers_Add_O_J__Number_NoInit(na_1120, na_1121) } } else { arg_1119 = lang.Numbers_Add_O_J__Number_NoInit(na_1120, na_1121) }; if linked_1115 == nil { ___22 = ifn_1116.Invoke_O_O_O__O(arg_1117, arg_1118, arg_1119) } else { ___22 = linked_1115.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1114, arg_1117, arg_1118, arg_1119) } } else { ___22 = nil }
//line :278:1
			var es__23 any





















			if jrt.J2g_Truth(emp__17) { es__23 = nil } else { if jrt.J2g_Truth(ovl__16) { var fl__23 any; var root_1125 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1127 lang.IFn
				if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var tmp21 *lang.Keyword = A_arbace_cpp_abi_A_const_49; var tmp22 any; var root_1129 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__2); if linked_1130 == nil { tmp22 = ifn_1131.Invoke_O__O(arg_1132) } else { tmp22 = linked_1130.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1129, arg_1132) }; arg_1128 = tmp21.Invoke_O__O(tmp22); if linked_1126 == nil { fl__23 = ifn_1127.Invoke_O__O(arg_1128) } else { fl__23 = linked_1126.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp23 any; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_134.Invoke_O__O(fl__23)) { tmp23 = A_arbace_cpp_abi_A_const_65.Invoke_O__O(fl__23) } else { tmp23 = A_arbace_cpp_abi_A_const_87.Invoke_O__O(fl__23) }; es__23 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp23)).Ref() } else {
//line :300:1
					if A_arbace_cpp_abi_A_const_118 != nil { es__23 = jrt.Long_ValueOf_J__Long_NoInit(s__11).Ref() } else { es__23 = nil } } }
//line :278:1
			var tmp24 any
























			if lang.Util_Identical_O_O__Z_NoInit(es__23, nil) { tmp24 = jrt.Long_ValueOf_J__Long_NoInit(offb__13).Ref() } else { if jrt.J2g_Truth(t.F_uni) { var tmp25 jrt.Number_I; var na_1163 int64 = 8; var na_1164 any; var na_1165 any = o__20; var na_1166 int64 = lang.RT_LongCast_O__J_NoInit(es__23); if jrt.Long_InstanceOf(na_1165) { var n0_1167 int64 = jrt.NN(jrt.Long_Cast(na_1165)).LongValue__J(); var n1_1168 int64 = na_1166; var nr_1169 int64 = n0_1167 + n1_1168; if (n0_1167^nr_1169)&(n1_1168^nr_1169) >= 0 { na_1164 = jrt.Long_ValueOf_J__Long_NoInit(nr_1169).Ref() } else { na_1164 = lang.Numbers_Add_O_J__Number_NoInit(na_1165, na_1166) } } else { na_1164 = lang.Numbers_Add_O_J__Number_NoInit(na_1165, na_1166) }; if jrt.Long_InstanceOf(na_1164) { var n0_1170 int64 = na_1163; var n1_1171 int64 = jrt.NN(jrt.Long_Cast(na_1164)).LongValue__J(); var nr_1172 int64 = n0_1170 * n1_1171; var tmp26 bool; var tmp27 bool; var tmp28 bool; var tmp29 bool; tmp29 = n0_1170 == -9223372036854775808; if tmp29 { tmp29 = n1_1171 < 0 }; tmp28 = tmp29; tmp27 = !tmp28; if tmp27 { var tmp30 bool; tmp30 = n1_1171 == 0; if !tmp30 { tmp30 = nr_1172/n1_1171 == n0_1170 }; tmp27 = tmp30 }; tmp26 = tmp27; if tmp26 { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1172)) } else { tmp25 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1163, na_1164) } } else { tmp25 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1163, na_1164) }; tmp24 = lang.Numbers_Max_J_O__O_NoInit(offb__13, tmp25) } else { if A_arbace_cpp_abi_A_const_118 != nil { var na_1173 int64 = 8; var na_1174 any; var na_1175 any = o__20; var na_1176 int64 = lang.RT_LongCast_O__J_NoInit(es__23); if jrt.Long_InstanceOf(na_1175) { var n0_1177 int64 = jrt.NN(jrt.Long_Cast(na_1175)).LongValue__J(); var n1_1178 int64 = na_1176; var nr_1179 int64 = n0_1177 + n1_1178; if (n0_1177^nr_1179)&(n1_1178^nr_1179) >= 0 { na_1174 = jrt.Long_ValueOf_J__Long_NoInit(nr_1179).Ref() } else { na_1174 = lang.Numbers_Add_O_J__Number_NoInit(na_1175, na_1176) } } else { na_1174 = lang.Numbers_Add_O_J__Number_NoInit(na_1175, na_1176) }; if jrt.Long_InstanceOf(na_1174) { var n0_1180 int64 = na_1173; var n1_1181 int64 = jrt.NN(jrt.Long_Cast(na_1174)).LongValue__J(); var nr_1182 int64 = n0_1180 * n1_1181; var tmp31 bool; var tmp32 bool; var tmp33 bool; var tmp34 bool; tmp34 = n0_1180 == -9223372036854775808; if tmp34 { tmp34 = n1_1181 < 0 }; tmp33 = tmp34; tmp32 = !tmp33; if tmp32 { var tmp35 bool; tmp35 = n1_1181 == 0; if !tmp35 { tmp35 = nr_1182/n1_1181 == n0_1180 }; tmp32 = tmp35 }; tmp31 = tmp32; if tmp31 { tmp24 = jrt.Long_ValueOf_J__Long_NoInit(nr_1182).Ref() } else { tmp24 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1173, na_1174) } } else { tmp24 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1173, na_1174) } } else { tmp24 = nil } } }
//line :278:1
			var tmp36 any = tmp24; var tmp37 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(align__5), a__12)).Ref(); var tmp38 any; var root_1183 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1185 lang.IFn

























			if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = foffs__6; var arg_1187 any = o__20; if linked_1184 == nil { tmp38 = ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { tmp38 = linked_1184.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) }
//line :278:1
			var tmp39 any = tmp38; var tmp40 any; var root_1188 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1190 lang.IFn

























			if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = bitoffs__7; var arg_1192 any; if linked_1189 == nil { tmp40 = ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { tmp40 = linked_1189.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) }
//line :278:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp36, tmp37, tmp39, tmp40) } }















func A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_New_O_J_J_J_O(p0 any, p1, p2, p3 int64, p4 any) *A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A{}; t.Ctor_O_J_J_J_O(p0, p1, p2, p3, p4); return t }
//line :294:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A) Ctor_O_J_J_J_O(c__f any, c__a, c__dsz, c__o int64, c__em any) { t.F_f = c__f; t.F_a = c__a; t.F_dsz = c__dsz; t.F_o = c__o; t.F_em = c__em }
//line :294:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A) Invoke_O__O(self any) any { { var o__1 int64 = t.F_o; L1: for {
												var tmp1 any; var root_1083 any = A_arbace_cpp_abi_A_const_135.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, A_arbace_cpp_abi_can_place_QMARK__A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = t.F_em; var arg_1087 any; var root_1088 any = A_arbace_cpp_abi_A_const_121.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1088, A_arbace_cpp_abi_field_empties_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(t.F_f); var arg_1092 int64 = o__1; if linked_1089 == nil { arg_1087 = ifn_1090.Invoke_O_O__O(arg_1091, jrt.Long_ValueOf_J__Long_NoInit(arg_1092).Ref()) } else { arg_1087 = linked_1089.(*A_arbace_cpp_abi_field_empties_A).InvokePrim_O_O_J__O(root_1088, arg_1091, arg_1092) }; if linked_1084 == nil { tmp1 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { tmp1 = linked_1084.(*A_arbace_cpp_abi_can_place_QMARK__A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) }; if jrt.J2g_Truth(tmp1) { return jrt.Long_ValueOf_J__Long_NoInit(o__1).Ref() } else {

		var tmp2 int64; var tmp3 any; var and__1927000168__auto____2 bool = lang.Numbers_IsZero_J__Z_NoInit(o__1); if and__1927000168__auto____2 { var root_1093 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_dsz)).Ref(); if linked_1094 == nil { tmp3 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp3 = linked_1094.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1093, arg_1096) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp3) { var tmp4 int64; var root_1097 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1097, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 int64 = t.F_dsz; var arg_1101 int64 = t.F_a; if linked_1098 == nil { tmp4 = lang.RT_LongCast_O__J_NoInit(ifn_1099.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_1100).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_1101).Ref())) } else { tmp4 = linked_1098.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1097, arg_1100, arg_1101) }; tmp2 = lang.RT_LongCast_J__J_NoInit(tmp4) } else { tmp2 = lang.Numbers_Add_J_J__J_NoInit(o__1, t.F_a) }; o__1 = tmp2; continue L1 } } }; /*line :294:1*/panic("j2g: unreachable") }























func A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_New_O(p0 any) *A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A{}; t.Ctor_O(p0); return t }
//line :318:1
func (t *A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A) Ctor_O(c__vbo any) { t.F_vbo = c__vbo }
//line :318:1
func (t *A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A) InvokePrim_O_O_J__O(self, x__1 any, xoff__2 int64) any { { var seq_677000183__3 any; var root_1231 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1233 lang.IFn
															if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any; var root_1235 any = A_arbace_cpp_abi_A_const_113.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1235, A_arbace_cpp_abi_nonvirtual_subobjects_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = x__1; var arg_1239 int64 = xoff__2; if linked_1236 == nil { arg_1234 = ifn_1237.Invoke_O_O__O(arg_1238, jrt.Long_ValueOf_J__Long_NoInit(arg_1239).Ref()) } else { arg_1234 = linked_1236.(*A_arbace_cpp_abi_nonvirtual_subobjects_A).InvokePrim_O_O_J__O(root_1235, arg_1238, arg_1239) }; if linked_1232 == nil { seq_677000183__3 = ifn_1233.Invoke_O__O(arg_1234) } else { seq_677000183__3 = linked_1232.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1231, arg_1234) }
//line :318:1
	var chunk_677000184__4 any; var count_677000185__5 int64 = 0; var i_677000186__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_677000186__6, count_677000185__5) { var vec__677000187__7 any = lang.Indexed_Cast(chunk_677000184__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000186__6)); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000187__7, lang.RT_IntCast_J__I_NoInit(0), nil); var yoff__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000187__7, lang.RT_IntCast_J__I_NoInit(1), nil); var p__10 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_88; var tmp2 any; var root_1256 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1258 lang.IFn
			if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = y__8; if linked_1257 == nil { tmp2 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp2 = linked_1257.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1256, arg_1259) }; p__10 = tmp1.Invoke_O__O(tmp2)
			var tmp3 any; var and__1927000168__auto____11 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(p__10); if jrt.J2g_Truth(and__1927000168__auto____11) { var root_1260 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(t.F_vbo); var arg_1263 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp4.ContainsKey_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(p__10))).Ref(); if linked_1261 == nil { tmp3 = ifn_1262.Invoke_O__O(arg_1263) } else { tmp3 = linked_1261.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1260, arg_1263) } } else { tmp3 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp3) { var tmp5 jrt.HashMap_I = jrt.HashMap_Cast(t.F_vbo); tmp5.Put_O_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(p__10), yoff__9) }
//line :319:1
			seq_677000183__3, chunk_677000184__4, count_677000185__5, i_677000186__6 = seq_677000183__3, chunk_677000184__4, count_677000185__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000186__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_1240 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = seq_677000183__3; if linked_1241 == nil { temp__1927000414__auto____7 = ifn_1242.Invoke_O__O(arg_1243) } else { temp__1927000414__auto____7 = linked_1241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1240, arg_1243) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_677000183__8 any = temp__1927000414__auto____7; var tmp6 any; var root_1244 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = seq_677000183__8; if linked_1245 == nil { tmp6 = ifn_1246.Invoke_O__O(arg_1247) } else { tmp6 = linked_1245.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1244, arg_1247) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____9 any; var root_1248 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq_677000183__8; if linked_1249 == nil { c__1927000678__auto____9 = ifn_1250.Invoke_O__O(arg_1251) } else { c__1927000678__auto____9 = linked_1249.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1248, arg_1251) }; var tmp7 any; var root_1264 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = seq_677000183__8; if linked_1265 == nil { tmp7 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp7 = linked_1265.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1264, arg_1267) }; seq_677000183__3, chunk_677000184__4, count_677000185__5, i_677000186__6 = tmp7, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__677000190__9 any; var root_1252 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = seq_677000183__8; if linked_1253 == nil { vec__677000190__9 = ifn_1254.Invoke_O__O(arg_1255) } else { vec__677000190__9 = linked_1253.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1252, arg_1255) }; var y__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000190__9, lang.RT_IntCast_J__I_NoInit(0), nil); var yoff__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000190__9, lang.RT_IntCast_J__I_NoInit(1), nil); var p__12 any; var tmp8 *lang.Keyword = A_arbace_cpp_abi_A_const_88; var tmp9 any; var root_1268 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1270 lang.IFn
				if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = y__10; if linked_1269 == nil { tmp9 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp9 = linked_1269.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1268, arg_1271) }; p__12 = tmp8.Invoke_O__O(tmp9)
				var tmp10 any; var and__1927000168__auto____13 any = A_arbace_cpp_abi_A_const_80.Invoke_O__O(p__12); if jrt.J2g_Truth(and__1927000168__auto____13) { var root_1272 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var tmp11 jrt.HashMap_I = jrt.HashMap_Cast(t.F_vbo); var arg_1275 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp11.ContainsKey_O__Z(A_arbace_cpp_abi_A_const_81.Invoke_O__O(p__12))).Ref(); if linked_1273 == nil { tmp10 = ifn_1274.Invoke_O__O(arg_1275) } else { tmp10 = linked_1273.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1272, arg_1275) } } else { tmp10 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp10) { var tmp12 jrt.HashMap_I = jrt.HashMap_Cast(t.F_vbo); tmp12.Put_O_O__O(A_arbace_cpp_abi_A_const_81.Invoke_O__O(p__12), yoff__11) }
//line :319:1
				var tmp13 any; var root_1276 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = seq_677000183__8; if linked_1277 == nil { tmp13 = ifn_1278.Invoke_O__O(arg_1279) } else { tmp13 = linked_1277.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1276, arg_1279) }; seq_677000183__3, chunk_677000184__4, count_677000185__5, i_677000186__6 = tmp13, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :318:1*/panic("j2g: unreachable") }
//line :318:1
func (t *A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A) Invoke_O_O_O__O(self, x__1, p_xoff__2 any) any { return t.InvokePrim_O_O_J__O(self, x__1, lang.RT_LongCast_O__J_NoInit(p_xoff__2)) }






func A_arbace_cpp_abi_layout_STAR__fn__677000195_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_abi_layout_STAR__fn__677000195_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000195_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :325:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000195_A) Ctor_O_O_O_O_O(c__floor, c__vbo, c__ip, c__mark_BANG_, c__em any) { t.F_floor = c__floor; t.F_vbo = c__vbo; t.F_ip = c__ip; t.F_mark_BANG_ = c__mark_BANG_; t.F_em = c__em }
//line :325:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000195_A) Invoke_O_O_O__O(self, p__677000194__1, v__2 any) any { var vec__677000196__3 any = p__677000194__1; var ds__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000196__3, lang.RT_IntCast_J__I_NoInit(0), nil); var al__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000196__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var or__1927000174__auto____6 bool = jrt.HashMap_Cast(t.F_vbo).ContainsKey_O__Z(v__2); if or__1927000174__auto____6 {
														tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.HashSet_Cast(t.F_ip).Contains_O__Z(v__2) }; if tmp1 { return lang.Tuple_Create_O_O__IPersistentVector(ds__4, al__5) } else { var vl__6 any; var root_1288 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1290 lang.IFn

		if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = v__2; if linked_1289 == nil { vl__6 = ifn_1290.Invoke_O__O(arg_1291) } else { vl__6 = linked_1289.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1288, arg_1291) }
//line :326:1
		var va__7 int64 = lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_133.Invoke_O__O(vl__6)); var o__8 any; var tmp2 any; var and__1927000168__auto____8 any; var root_1292 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_1294 lang.IFn



		if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = v__2; if linked_1293 == nil { and__1927000168__auto____8 = ifn_1294.Invoke_O__O(arg_1295) } else { and__1927000168__auto____8 = linked_1293.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_1292, arg_1295) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1296 any = A_arbace_cpp_abi_A_const_135.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, A_arbace_cpp_abi_can_place_QMARK__A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = t.F_em; var arg_1300 any; var root_1301 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1301, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = v__2; var arg_1306 any = jrt.Boolean_FALSE.Ref(); if linked_1302 == nil { arg_1300 = ifn_1303.Invoke_O_O_O__O(arg_1304, A_arbace_cpp_abi_A_const_68, arg_1306) } else { arg_1300 = linked_1302.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_1301, arg_1304, 0, arg_1306) }; if linked_1297 == nil { tmp2 = ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { tmp2 = linked_1297.(*A_arbace_cpp_abi_can_place_QMARK__A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) } } else { tmp2 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp2) { o__8 = A_arbace_cpp_abi_A_const_68 } else {

			var tmp3 *lang.Compiler_AOTFn; var fnbody__1324 any = A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_New_J_O_O_O(va__7, ds__4, v__2, t.F_em); var tmp4 *jrt.Class; var fncls__1323 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_fn_class; if fncls__1323 == nil { var fncls__1323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__1324); A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_fn_class = fncls__1323d; tmp4 = fncls__1323d } else { tmp4 = fncls__1323 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1324, tmp4, nil); o__8 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O() }
//line :326:1
		var ___9 any; var root_1325 any = A_arbace_cpp_abi_A_const_137.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, A_arbace_cpp_abi_place_BANG__A_fn_class); var ifn_1327 lang.IFn; _ = ___9






		if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = t.F_em; var arg_1329 any; var root_1330 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1330, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = v__2; var arg_1334 any = o__8; var arg_1335 any = jrt.Boolean_FALSE.Ref(); if linked_1331 == nil { arg_1329 = ifn_1332.Invoke_O_O_O__O(arg_1333, arg_1334, arg_1335) } else { arg_1329 = linked_1331.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_1330, arg_1333, lang.RT_LongCast_O__J_NoInit(arg_1334), arg_1335) }; if linked_1326 == nil { ___9 = ifn_1327.Invoke_O_O__O(arg_1328, arg_1329) } else { ___9 = linked_1326.(*A_arbace_cpp_abi_place_BANG__A).Invoke_O_O_O__O(root_1325, arg_1328, arg_1329) }
//line :326:1
		var ___10 any; var tmp5 any; var root_1336 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_1338 lang.IFn; _ = ___10








		if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = v__2; if linked_1337 == nil { tmp5 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp5 = linked_1337.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_1336, arg_1339) }; if jrt.J2g_Truth(tmp5) { var root_1340 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = t.F_floor; var arg_1344 any = A_arbace_cpp_abi_A_const_138.GetRawRoot__O(); var arg_1345 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(o__8), lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_65.Invoke_O__O(vl__6)))).Ref(); if linked_1341 == nil { ___10 = ifn_1342.Invoke_O_O_O__O(arg_1343, arg_1344, arg_1345) } else { ___10 = linked_1341.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1340, arg_1343, arg_1344, arg_1345) } } else { ___10 = nil }
		jrt.HashMap_Cast(t.F_vbo).Put_O_O__O(v__2, o__8)
		lang.IFn_Cast(t.F_mark_BANG_).Invoke_O_O__O(v__2, o__8)
//line :326:1
		var tmp6 any; var tmp7 any; var root_1346 any = A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_1348 lang.IFn











		if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = v__2; if linked_1347 == nil { tmp7 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp7 = linked_1347.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_1346, arg_1349) }; if jrt.J2g_Truth(tmp7) { tmp6 = ds__4 } else { var na_1350 any = o__8; var na_1351 int64 = lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_87.Invoke_O__O(vl__6)); if jrt.Long_InstanceOf(na_1350) { var n0_1352 int64 = jrt.NN(jrt.Long_Cast(na_1350)).LongValue__J(); var n1_1353 int64 = na_1351; var nr_1354 int64 = n0_1352 + n1_1353; if (n0_1352^nr_1354)&(n1_1353^nr_1354) >= 0 { tmp6 = jrt.Long_ValueOf_J__Long_NoInit(nr_1354).Ref() } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_1350, na_1351) } } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_1350, na_1351) } }
//line :326:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(al__5), lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_133.Invoke_O__O(vl__6)))).Ref()) } }





func A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_New_J_O_O_O(p0 int64, p1, p2, p3 any) *A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A{}; t.Ctor_J_O_O_O(p0, p1, p2, p3); return t }
//line :332:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A) Ctor_J_O_O_O(c__va int64, c__ds, c__v, c__em any) { t.F_va = c__va; t.F_ds = c__ds; t.F_v = c__v; t.F_em = c__em }
//line :332:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A) Invoke_O__O(self any) any { { var o__1 int64; var tmp1 int64; var root_1307 any = A_arbace_cpp_abi_A_const_136.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1307, A_arbace_cpp_abi_align_up_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var t_ any = t.F_ds; t.F_ds = nil; arg_1310 = t_; var arg_1311 int64 = t.F_va; if linked_1308 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1309.Invoke_O_O__O(arg_1310, jrt.Long_ValueOf_J__Long_NoInit(arg_1311).Ref())) } else { tmp1 = linked_1308.(*A_arbace_cpp_abi_align_up_A).InvokePrim_O_J_J__J(root_1307, lang.RT_LongCast_O__J_NoInit(arg_1310), arg_1311) }; o__1 = lang.RT_LongCast_J__J_NoInit(tmp1); L1: for { var tmp2 any; var root_1312 any = A_arbace_cpp_abi_A_const_135.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, A_arbace_cpp_abi_can_place_QMARK__A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = t.F_em; var arg_1316 any; var root_1317 any = A_arbace_cpp_abi_A_const_116.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1317, A_arbace_cpp_abi_class_empties_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = t.F_v; var arg_1321 int64 = o__1; var arg_1322 any = jrt.Boolean_FALSE.Ref(); if linked_1318 == nil { arg_1316 = ifn_1319.Invoke_O_O_O__O(arg_1320, jrt.Long_ValueOf_J__Long_NoInit(arg_1321).Ref(), arg_1322) } else { arg_1316 = linked_1318.(*A_arbace_cpp_abi_class_empties_A).InvokePrim_O_O_J_O__O(root_1317, arg_1320, arg_1321, arg_1322) }; if linked_1313 == nil { tmp2 = ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { tmp2 = linked_1313.(*A_arbace_cpp_abi_can_place_QMARK__A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) }; if jrt.J2g_Truth(tmp2) { return jrt.Long_ValueOf_J__Long_NoInit(o__1).Ref() } else { o__1 = lang.Numbers_Add_J_J__J_NoInit(o__1, t.F_va); continue L1 } } }; panic("j2g: unreachable") }














func A_arbace_cpp_abi_layout_STAR__fn__677000202_A_New() *A_arbace_cpp_abi_layout_STAR__fn__677000202_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000202_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000202_A) Ctor() {}
//line :347:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000202_A) Invoke_O_O__O(self, x__1 any) any { var k__2 any; var root_1394 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = x__1; if linked_1395 == nil { k__2 = ifn_1396.Invoke_O__O(arg_1397) } else { k__2 = linked_1395.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1394, arg_1397) }; var or__1927000174__auto____3 any = A_arbace_cpp_abi_A_const_149.Invoke_O__O(k__2); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_1398 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = A_arbace_cpp_abi_A_const_150.Invoke_O__O(k__2); if linked_1399 == nil { return ifn_1400.Invoke_O__O(arg_1401) } else { return linked_1399.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1398, arg_1401) } } }

func A_arbace_cpp_abi_layout_STAR__fn__677000204_A_New() *A_arbace_cpp_abi_layout_STAR__fn__677000204_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000204_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000204_A) Ctor() {}
//line :349:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000204_A) Invoke_O_O__O(self, f__1 any) any { var t__2 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__1437 any = A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1436 *jrt.Class = A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_fn_class; if fncls__1436 == nil { var fncls__1436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__1437); A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_fn_class = fncls__1436d; tmp2 = fncls__1436d } else { tmp2 = fncls__1436 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1437, tmp2, nil); t__2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var tmp3 any = A_arbace_cpp_abi_A_const_33; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__2)) { return A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__2) } else { return nil } }
//line :349:1
func A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_New_O(p0 any) *A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :349:1
func (t *A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A) Invoke_O__O(self any) any { { var t__1 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_98; var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; t__1 = tmp1.Invoke_O__O(tmp2); L1: for { var tmp3 any = A_arbace_cpp_abi_A_const_23; var tmp4 *lang.Keyword = A_arbace_cpp_abi_A_const_16; var tmp5 any; var root_1424 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = t__1; if linked_1425 == nil { tmp5 = ifn_1426.Invoke_O__O(arg_1427) } else { tmp5 = linked_1425.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1424, arg_1427) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4.Invoke_O__O(tmp5)) { var tmp6 *lang.Keyword = A_arbace_cpp_abi_A_const_24; var tmp7 any; var root_1432 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = t__1; if linked_1433 == nil { tmp7 = ifn_1434.Invoke_O__O(arg_1435) } else { tmp7 = linked_1433.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1432, arg_1435) }; t__1 = tmp6.Invoke_O__O(tmp7); continue L1 } else { var root_1428 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = t__1; if linked_1429 == nil { return ifn_1430.Invoke_O__O(arg_1431) } else { return linked_1429.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1428, arg_1431) } } } }; panic("j2g: unreachable") }




func A_arbace_cpp_abi_field_offset_A_New() *A_arbace_cpp_abi_field_offset_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_field_offset_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_cpp_abi_field_offset_A) Ctor() {}
//line :354:1
func (t *A_arbace_cpp_abi_field_offset_A) InvokePrim_O_O_J__J(self, id__0 any, i__1 int64) int64 { var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_102; var tmp2 any; var root_1453 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = id__0; if linked_1454 == nil { tmp2 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp2 = linked_1454.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1453, arg_1456) }; return lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.RT_IntCast_J__I_NoInit(i__1))) }
//line :354:1
func (t *A_arbace_cpp_abi_field_offset_A) Invoke_O_O_O__O(self, id__0, p_i__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J__J(self, id__0, lang.RT_LongCast_O__J_NoInit(p_i__1))).Ref() }

func A_arbace_cpp_abi_base_path_A_New() *A_arbace_cpp_abi_base_path_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_base_path_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_cpp_abi_base_path_A) Ctor() {}
//line :356:1
func (t *A_arbace_cpp_abi_base_path_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return lang.Tuple_Create_O_O_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref(), A_arbace_cpp_abi_A_const_68, nil) } else {

		var root_1457 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var fnbody__1477 any = A_arbace_cpp_abi_base_path_fn__677000211_A_New_O_O(from__0, to__1); var tmp1 *jrt.Class; var fncls__1476 *jrt.Class = A_arbace_cpp_abi_base_path_fn__677000211_A_fn_class; if fncls__1476 == nil { var fncls__1476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__1477); A_arbace_cpp_abi_base_path_fn__677000211_A_fn_class = fncls__1476d; tmp1 = fncls__1476d } else { tmp1 = fncls__1476 }; arg_1460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1477, tmp1, nil); var arg_1461 any; var root_1478 any = A_arbace_cpp_abi_A_const_114.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1480 lang.IFn




		if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = A_arbace_cpp_abi_A_const_115.GetRawRoot__O(); var arg_1482 any; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp3 any; var root_1483 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = from__0; if linked_1484 == nil { tmp3 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp3 = linked_1484.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1483, arg_1486) }; arg_1482 = tmp2.Invoke_O__O(tmp3); if linked_1479 == nil { arg_1461 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { arg_1461 = linked_1479.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }
//line :363:1
		if linked_1458 == nil { return ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { return linked_1458.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) } } }
//line :363:1
func A_arbace_cpp_abi_base_path_fn__677000211_A_New_O_O(p0, p1 any) *A_arbace_cpp_abi_base_path_fn__677000211_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_base_path_fn__677000211_A{}; t.Ctor_O_O(p0, p1); return t }
//line :363:1
func (t *A_arbace_cpp_abi_base_path_fn__677000211_A) Ctor_O_O(c__from, c__to any) { t.F_from = c__from; t.F_to = c__to }
//line :363:1
func (t *A_arbace_cpp_abi_base_path_fn__677000211_A) Invoke_O_O__O(self, p__677000210__1 any) any { var vec__677000212__2 any = p__677000210__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000212__2, lang.RT_IntCast_J__I_NoInit(0), nil); var bs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000212__2, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____5 any; var root_1462 any = A_arbace_cpp_abi_A_const_153.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, A_arbace_cpp_abi_base_path_A_fn_class); var ifn_1464 lang.IFn; if
													linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(bs__4); var arg_1466 any = t.F_to; if linked_1463 == nil { temp__1927000414__auto____5 = ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { temp__1927000414__auto____5 = linked_1463.(*A_arbace_cpp_abi_base_path_A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var vec__677000215__6 any = temp__1927000414__auto____5; var steps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000215__6, lang.RT_IntCast_J__I_NoInit(0), nil); var off__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000215__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vb__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000215__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any; var root_1467 any = A_arbace_cpp_abi_A_const_111.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1469 lang.IFn
														if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t.F_from, i__3)); var arg_1471 any = steps__7; if linked_1468 == nil { tmp1 = ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { tmp1 = linked_1468.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) }
//line :364:1
		var tmp2 any = tmp1; var tmp3 any

		if jrt.J2g_Truth(vb__9) { tmp3 = off__8 } else { if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(bs__4)) { tmp3 = off__8 } else { if A_arbace_cpp_abi_A_const_118 != nil { var tmp4 *lang.Keyword = A_arbace_cpp_abi_A_const_77; var tmp5 any; var root_1472 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, A_arbace_cpp_abi_layout_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = t.F_from; if linked_1473 == nil { tmp5 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp5 = linked_1473.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_1472, arg_1475) }; tmp3 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp4.Invoke_O__O(tmp5), lang.RT_IntCast_O__I_NoInit(i__3))), lang.RT_LongCast_O__J_NoInit(off__8))).Ref() } else { tmp3 = nil } } }
//line :364:1
		var tmp6 any = tmp3; var tmp7 any
		var or__1927000174__auto____10 any = vb__9

		if jrt.J2g_Truth(or__1927000174__auto____10) { tmp7 = or__1927000174__auto____10 } else { if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_80.Invoke_O__O(bs__4)) { tmp7 = A_arbace_cpp_abi_A_const_81.Invoke_O__O(bs__4) } else { tmp7 = nil } }
//line :364:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp6, tmp7) } else { return nil } }





func A_arbace_cpp_abi_derived_from_QMARK__A_New() *A_arbace_cpp_abi_derived_from_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_derived_from_QMARK__A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_cpp_abi_derived_from_QMARK__A) Ctor() {}
//line :370:1
func (t *A_arbace_cpp_abi_derived_from_QMARK__A) Invoke_O_O_O__O(self, d__0, bse__1 any) any { var and__1927000168__auto____3 any; var root_1487 any = A_arbace_cpp_abi_A_const_141.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = d__0; var arg_1491 any = bse__1; if linked_1488 == nil { and__1927000168__auto____3 = ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { and__1927000168__auto____3 = linked_1488.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1492 any = A_arbace_cpp_abi_A_const_154.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var root_1496 any = A_arbace_cpp_abi_A_const_153.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, A_arbace_cpp_abi_base_path_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = d__0; var arg_1500 any = bse__1; if linked_1497 == nil { arg_1495 = ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { arg_1495 = linked_1497.(*A_arbace_cpp_abi_base_path_A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) }; if linked_1493 == nil { return ifn_1494.Invoke_O__O(arg_1495) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1492, arg_1495) } } else { return and__1927000168__auto____3 } }
func A_arbace_cpp_abi_has_vbases_QMARK__A_New() *A_arbace_cpp_abi_has_vbases_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_has_vbases_QMARK__A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_cpp_abi_has_vbases_QMARK__A) Ctor() {}
//line :371:1
func (t *A_arbace_cpp_abi_has_vbases_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var tmp1 any; var root_1501 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any; var root_1505 any = A_arbace_cpp_abi_A_const_94.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, A_arbace_cpp_abi_vbases_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = id__0; if linked_1506 == nil { arg_1504 = ifn_1507.Invoke_O__O(arg_1508) } else { arg_1504 = linked_1506.(*A_arbace_cpp_abi_vbases_A).Invoke_O_O__O(root_1505, arg_1508) }; if linked_1502 == nil { tmp1 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp1 = linked_1502.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1501, arg_1504) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }




func A_arbace_cpp_abi_llvm_type_A_New() *A_arbace_cpp_abi_llvm_type_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_llvm_type_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_cpp_abi_llvm_type_A) Ctor() {}
//line :376:1
func (t *A_arbace_cpp_abi_llvm_type_A) Invoke_O_O_O__O(self, t__0, value_QMARK___1 any) any { var t__3 any; var root_1509 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1511 lang.IFn; if



	linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = t__0; if linked_1510 == nil { t__3 = ifn_1511.Invoke_O__O(arg_1512) } else { t__3 = linked_1510.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1509, arg_1512) }; var G__677000222__4_ any = /*line :376:1*/A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__3); switch




	lang.Util_Hash_O__I_NoInit(G__677000222__4_) >> 2 & 15 { case 1: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_21) { return A_arbace_cpp_abi_A_const_155 }; case 2: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_22) { return A_arbace_cpp_abi_A_const_155 }; case 4: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_19) { return A_arbace_cpp_abi_A_const_155 }; case 7: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_35) { return A_arbace_cpp_abi_A_const_156 }; case 10: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_41) {













		var tmp1 any = A_arbace_cpp_abi_A_const_35; var tmp2 *lang.Keyword = A_arbace_cpp_abi_A_const_16; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_cpp_abi_A_const_20.Invoke_O__O(t__3))) { return A_arbace_cpp_abi_A_const_158 } else { return A_arbace_cpp_abi_A_const_159 } }
//line :381:1
	case 11: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_17) { var G__677000223__5_ any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__3)
		switch lang.Util_Hash_O__I_NoInit(G__677000223__5_) >> 6 & 63 { case 1: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_160) { return A_arbace_cpp_abi_A_const_161 }; case 3: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_162) { return A_arbace_cpp_abi_A_const_163 }; case 4: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_164) { return A_arbace_cpp_abi_A_const_161 }; case 7: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_165) {

			if jrt.J2g_Truth(value_QMARK___1) { return A_arbace_cpp_abi_A_const_166 } else { return A_arbace_cpp_abi_A_const_167 } }
//line :382:1
		case 16: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_45) { return A_arbace_cpp_abi_A_const_169 }; case 17: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_170) { return A_arbace_cpp_abi_A_const_171 }; case 19: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_172) { return A_arbace_cpp_abi_A_const_173 }; case 20: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_174) { return A_arbace_cpp_abi_A_const_175 }; case 22: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_176) { return A_arbace_cpp_abi_A_const_177 }; case 23: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_178) { return A_arbace_cpp_abi_A_const_175 }; case 25: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_179) { return A_arbace_cpp_abi_A_const_180 }; case 26: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_181) { return A_arbace_cpp_abi_A_const_182 }; case 27: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_183) { return A_arbace_cpp_abi_A_const_180 }; case 29: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_184) { return A_arbace_cpp_abi_A_const_185 }; case 35: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_186) { return A_arbace_cpp_abi_A_const_175 }; case 36: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_187) { return A_arbace_cpp_abi_A_const_161 }; case 38: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_188) { return A_arbace_cpp_abi_A_const_171 }; case 44: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_189) { return A_arbace_cpp_abi_A_const_161 }; case 46: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_190) { return A_arbace_cpp_abi_A_const_185 }; case 47: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_191) { return A_arbace_cpp_abi_A_const_180 }; case 48: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_192) { return A_arbace_cpp_abi_A_const_193 }; case 49: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_29) { return A_arbace_cpp_abi_A_const_194 }; case 52: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_195) { return A_arbace_cpp_abi_A_const_175 }; case 57: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_196) { return A_arbace_cpp_abi_A_const_185 }; case 60: if any(G__677000223__5_) == any(A_arbace_cpp_abi_A_const_197) { return A_arbace_cpp_abi_A_const_180 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__677000223__5_))))) }
//line :381:1
	case 12: if any(G__677000222__4_) == any(A_arbace_cpp_abi_A_const_34) {











		var root_1515 any = A_arbace_cpp_abi_A_const_168.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, A_arbace_cpp_abi_llvm_type_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any; var root_1520 any = A_arbace_cpp_abi_A_const_72.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, A_arbace_cpp_abi_underlying_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = t__3; if linked_1521 == nil { arg_1518 = ifn_1522.Invoke_O__O(arg_1523) } else { arg_1518 = linked_1521.(*A_arbace_cpp_abi_underlying_A).Invoke_O_O__O(root_1520, arg_1523) }; var arg_1519 any = value_QMARK___1; if linked_1516 == nil { return ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { return linked_1516.(*A_arbace_cpp_abi_llvm_type_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) } }
//line :381:1
	default:}; var tmp3 lang.IFn =














	lang.IFn_Cast(A_arbace_cpp_abi_A_const_157.GetRawRoot__O()); var tmp4 any = A_arbace_cpp_abi_A_const_198; var tmp5 int64; var root_1524 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1524, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = t__3; if linked_1525 == nil { tmp5 = lang.RT_LongCast_O__J_NoInit(ifn_1526.Invoke_O__O(arg_1527)) } else { tmp5 = linked_1525.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_1524, arg_1527) }; return tmp3.Invoke_O_O_O__O(tmp4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(tmp5)).Ref(), A_arbace_cpp_abi_A_const_200) }
//line :376:1
func (t *A_arbace_cpp_abi_llvm_type_A) Invoke_O_O__O(self, t__0 any) any {

	var root_1528 any = A_arbace_cpp_abi_A_const_168.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, A_arbace_cpp_abi_llvm_type_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = t__0; var arg_1532 any = jrt.Boolean_FALSE.Ref(); if linked_1529 == nil { return ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { return linked_1529.(*A_arbace_cpp_abi_llvm_type_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532)
	}
}

















func A_arbace_cpp_abi_signed_QMARK__A_New() *A_arbace_cpp_abi_signed_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_signed_QMARK__A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_cpp_abi_signed_QMARK__A) Ctor() {}
//line :398:1
func (t *A_arbace_cpp_abi_signed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var n__2 any; var root_1533 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, A_arbace_cpp_abi_bn_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any; var root_1537 any = A_arbace_cpp_abi_A_const_72.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, A_arbace_cpp_abi_underlying_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any; var root_1541 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = t__0; if linked_1542 == nil { arg_1540 = ifn_1543.Invoke_O__O(arg_1544) } else { arg_1540 = linked_1542.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1541, arg_1544) }; if linked_1538 == nil { arg_1536 = ifn_1539.Invoke_O__O(arg_1540) } else { arg_1536 = linked_1538.(*A_arbace_cpp_abi_underlying_A).Invoke_O_O__O(root_1537, arg_1540) }; if linked_1534 == nil { n__2 = ifn_1535.Invoke_O__O(arg_1536) } else { n__2 = linked_1534.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_1533, arg_1536) }; var and__1927000168__auto____3 any; var root_1545 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = A_arbace_cpp_abi_A_const_37.GetRawRoot__O(); var arg_1549 any = n__2; if linked_1546 == nil { and__1927000168__auto____3 = ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { and__1927000168__auto____3 = linked_1546.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1550 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_201.GetRawRoot__O()).Invoke_O__O(n__2); if linked_1551 == nil { return ifn_1552.Invoke_O__O(arg_1553) } else { return linked_1551.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1550, arg_1553) } } else { return and__1927000168__auto____3 } }

























func A_arbace_cpp_abi_seq_id_A_New() *A_arbace_cpp_abi_seq_id_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_seq_id_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_cpp_abi_seq_id_A) Ctor() {}
//line :424:1
func (t *A_arbace_cpp_abi_seq_id_A) InvokePrim_O_J__O(self any, n__0 int64) any {
	if lang.Numbers_IsZero_J__Z_NoInit(n__0) { return Lit_180 } else {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_181, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Long_ToString_J_I__String_NoInit(lang.Numbers_Dec_J__J_NoInit(n__0), lang.RT_IntCast_J__I_NoInit(36))).ToUpperCase__String().Ref(), nil)).Ref() } }
//line :424:1
func (t *A_arbace_cpp_abi_seq_id_A) Invoke_O_O__O(self, p_n__0 any) any { return t.InvokePrim_O_J__O(self, lang.RT_LongCast_O__J_NoInit(p_n__0)) }



func A_arbace_cpp_abi_source_name_A_New() *A_arbace_cpp_abi_source_name_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_source_name_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_cpp_abi_source_name_A) Ctor() {}
//line :428:1
func (t *A_arbace_cpp_abi_source_name_A) Invoke_O_O__O(self, s__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__0)).Ref(), s__0)).Ref() }



func A_arbace_cpp_abi_sub_BANG__A_New() *A_arbace_cpp_abi_sub_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_sub_BANG__A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_cpp_abi_sub_BANG__A) Ctor() {}
//line :432:1
func (t *A_arbace_cpp_abi_sub_BANG__A) Invoke_O_O_O__O(self, k__0, s__1 any) any { var v__3 any; var root_1554 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1556 lang.IFn; if
											linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_1555 == nil { v__3 = ifn_1556.Invoke_O__O(arg_1557) } else { v__3 = linked_1555.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1554, arg_1557) }; var i__4 int32 = /*line :432:1*/jrt.List_Cast(v__3).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__4)) { var root_1562 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_1566 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_1567 any = k__0; if linked_1563 == nil { ifn_1564.Invoke_O_O_O__O(arg_1565, arg_1566, arg_1567) } else { linked_1563.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1562, arg_1565, arg_1566, arg_1567) }; return s__1 } else { var root_1558 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1558, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__4).Ref(); if linked_1559 == nil { return ifn_1560.Invoke_O__O(arg_1561) } else { return linked_1559.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_1558, lang.RT_LongCast_O__J_NoInit(arg_1561)) } } }

func A_arbace_cpp_abi_sub_or_A_New() *A_arbace_cpp_abi_sub_or_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_sub_or_A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_cpp_abi_sub_or_A) Ctor() {}
//line :436:1
func (t *A_arbace_cpp_abi_sub_or_A) Invoke_O_O_O__O(self, k__0, f__1 any) any { var i__3 int32; var tmp1 any; var root_1568 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1570 lang.IFn; if
										linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_1569 == nil { tmp1 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp1 = linked_1569.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1568, arg_1571) }; i__3 = jrt.List_Cast(tmp1).IndexOf_O__I(k__0); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__3)) { var s__4 any = lang.IFn_Cast(f__1).Invoke__O(); var root_1576 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_1580 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_1581 any = k__0; if linked_1577 == nil { ifn_1578.Invoke_O_O_O__O(arg_1579, arg_1580, arg_1581) } else { linked_1577.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1576, arg_1579, arg_1580, arg_1581) }; return s__4 } else { var root_1572 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1572, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__3).Ref(); if linked_1573 == nil { return ifn_1574.Invoke_O__O(arg_1575) } else { return linked_1573.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_1572, lang.RT_LongCast_O__J_NoInit(arg_1575)) } } }



func A_arbace_cpp_abi_dollar_name_BANG__A_New() *A_arbace_cpp_abi_dollar_name_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dollar_name_BANG__A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_cpp_abi_dollar_name_BANG__A) Ctor() {}
//line :442:1
func (t *A_arbace_cpp_abi_dollar_name_BANG__A) Invoke_O_O__O(self, c__0 any) any { var a__2 any; var or__1927000174__auto____2 any = A_arbace_cpp_abi_A_const_204.Get__O(); if



	jrt.J2g_Truth(or__1927000174__auto____2) { a__2 = or__1927000174__auto____2 } else { var root_1582 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1583 == nil { a__2 = ifn_1584.Invoke_O__O(arg_1585) } else { a__2 = linked_1583.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1582, arg_1585) } }; var or__1927000174__auto____3 any; var root_1586 any = /*line :442:1*/A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1588 lang.IFn; if




	linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any; var root_1591 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = a__2; if linked_1592 == nil { arg_1589 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1589 = linked_1592.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1591, arg_1594) }; var tmp1 any = A_arbace_cpp_abi_A_const_206; var arg_1590 any = lang.Tuple_Create_O_O__IPersistentVector(tmp1, A_arbace_cpp_abi_A_const_49.Invoke_O__O(c__0)); if linked_1587 == nil { or__1927000174__auto____3 = ifn_1588.Invoke_O_O__O(arg_1589, arg_1590) } else { or__1927000174__auto____3 = linked_1587.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1586, arg_1589, arg_1590) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var k__4 any = A_arbace_cpp_abi_A_const_207.Invoke_O__O(c__0); var n__5 int64; var tmp2 any; var root_1595 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1597 lang.IFn
		if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any; var root_1601 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = a__2; if linked_1602 == nil { arg_1598 = ifn_1603.Invoke_O__O(arg_1604) } else { arg_1598 = linked_1602.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1601, arg_1604) }; var arg_1599 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_208, k__4); var arg_1600 any = A_arbace_cpp_abi_A_const_68; if linked_1596 == nil { tmp2 = ifn_1597.Invoke_O_O_O__O(arg_1598, arg_1599, arg_1600) } else { tmp2 = linked_1596.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_1595, arg_1598, arg_1599, arg_1600) }; n__5 = lang.RT_LongCast_O__J_NoInit(tmp2)
//line :447:1
		var nm__6 any; var root_1605 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_1607 lang.IFn

		if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(n__5).Ref())).Ref(); if linked_1606 == nil { nm__6 = ifn_1607.Invoke_O__O(arg_1608) } else { nm__6 = linked_1606.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_1605, arg_1608) }
		var root_1609 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = a__2; var arg_1613 any; var fnbody__1627 any = A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_New_O_O_J_O(c__0, k__4, n__5, nm__6); var tmp3 *jrt.Class; var fncls__1626 *jrt.Class = A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_fn_class; if fncls__1626 == nil { var fncls__1626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__1627); A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_fn_class = fncls__1626d; tmp3 = fncls__1626d } else { tmp3 = fncls__1626 }; arg_1613 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1627, tmp3, nil); if linked_1610 == nil { ifn_1611.Invoke_O_O__O(arg_1612, arg_1613) } else { linked_1610.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1609, arg_1612, arg_1613) }
//line :447:1
		return nm__6 } }


func A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_New_O_O_J_O(p0, p1 any, p2 int64, p3 any) *A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A{}; t.Ctor_O_O_J_O(p0, p1, p2, p3); return t }
//line :450:1
func (t *A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A) Ctor_O_O_J_O(c__c, c__k any, c__n int64, c__nm any) { t.F_c = c__c; t.F_k = c__k; t.F_n = c__n; t.F_nm = c__nm }
//line :450:1
func (t *A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A) Invoke_O_O__O(self, p1__677000230_SHARP___1 any) any { var root_1614 any = A_arbace_cpp_abi_A_const_210.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any; var root_1620 any = A_arbace_cpp_abi_A_const_210.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = p1__677000230_SHARP___1; var tmp1 any = A_arbace_cpp_abi_A_const_206; var arg_1624 any = lang.Tuple_Create_O_O__IPersistentVector(tmp1, A_arbace_cpp_abi_A_const_49.Invoke_O__O(t.F_c)); var arg_1625 any = t.F_nm; if linked_1621 == nil { arg_1617 = ifn_1622.Invoke_O_O_O__O(arg_1623, arg_1624, arg_1625) } else { arg_1617 = linked_1621.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1620, arg_1623, arg_1624, arg_1625) }; var arg_1618 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_208, t.F_k); var arg_1619 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(t.F_n)).Ref(); if linked_1615 == nil { return ifn_1616.Invoke_O_O_O__O(arg_1617, arg_1618, arg_1619) } else { return linked_1615.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1614, arg_1617, arg_1618, arg_1619) } }


func A_arbace_cpp_abi_part_name_A_New() *A_arbace_cpp_abi_part_name_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_part_name_A{}; t.Ctor(); return t }
//line :453:1
func (t *A_arbace_cpp_abi_part_name_A) Ctor() {}
//line :453:1
func (t *A_arbace_cpp_abi_part_name_A) Invoke_O_O__O(self, p__0 any) any { var G__677000234__2_ any; var root_1628 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1630 lang.IFn; if
										linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = p__0; if linked_1629 == nil { G__677000234__2_ = ifn_1630.Invoke_O__O(arg_1631) } else { G__677000234__2_ = linked_1629.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1628, arg_1631) }; switch lang.Util_Hash_O__I_NoInit(G__677000234__2_) >> 3 & 3 { case 0: if any(G__677000234__2_) == any(A_arbace_cpp_abi_A_const_81) { var c__3 any; var root_1633 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1635 lang.IFn


		if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any; var root_1637 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = p__0; if linked_1638 == nil { arg_1636 = ifn_1639.Invoke_O__O(arg_1640) } else { arg_1636 = linked_1638.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1637, arg_1640) }; if linked_1634 == nil { c__3 = ifn_1635.Invoke_O__O(arg_1636) } else { c__3 = linked_1634.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1633, arg_1636) }
//line :454:1
		var or__1927000174__auto____4 any = A_arbace_cpp_abi_A_const_211.Invoke_O__O(c__3)


		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_207.Invoke_O__O(c__3)) { var root_1641 any = A_arbace_cpp_abi_A_const_212.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, A_arbace_cpp_abi_dollar_name_BANG__A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = c__3; if linked_1642 == nil { or__1927000174__auto____5 = ifn_1643.Invoke_O__O(arg_1644) } else { or__1927000174__auto____5 = linked_1642.(*A_arbace_cpp_abi_dollar_name_BANG__A).Invoke_O_O__O(root_1641, arg_1644) } } else { or__1927000174__auto____5 = nil }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var root_1645 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(c__3); if linked_1646 == nil { return ifn_1647.Invoke_O__O(arg_1648) } else { return linked_1646.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_1645, arg_1648) } } } }
//line :454:1
	case 1: if any(G__677000234__2_) == any(A_arbace_cpp_abi_A_const_213) {
		var root_1649 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any; var root_1653 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = p__0; if linked_1654 == nil { arg_1652 = ifn_1655.Invoke_O__O(arg_1656) } else { arg_1652 = linked_1654.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1653, arg_1656) }; if linked_1650 == nil { return ifn_1651.Invoke_O__O(arg_1652) } else { return linked_1650.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_1649, arg_1652) } }
//line :454:1
	case 2: if any(G__677000234__2_) == any(A_arbace_cpp_abi_A_const_34) {



		var root_1657 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_127; var tmp2 any; var root_1661 any = A_arbace_cpp_abi_A_const_54.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, A_arbace_cpp_abi_enm_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any; var root_1665 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = p__0; if linked_1666 == nil { arg_1664 = ifn_1667.Invoke_O__O(arg_1668) } else { arg_1664 = linked_1666.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1665, arg_1668) }; if linked_1662 == nil { tmp2 = ifn_1663.Invoke_O__O(arg_1664) } else { tmp2 = linked_1662.(*A_arbace_cpp_abi_enm_A).Invoke_O_O__O(root_1661, arg_1664) }; arg_1660 = tmp1.Invoke_O__O(tmp2); if linked_1658 == nil { return ifn_1659.Invoke_O__O(arg_1660) } else { return linked_1658.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_1657, arg_1660) } }
//line :454:1
	case 3: if any(G__677000234__2_) == any(A_arbace_cpp_abi_A_const_214) { return Lit_172 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__677000234__2_))))) }







func A_arbace_cpp_abi_part_targs_A_New() *A_arbace_cpp_abi_part_targs_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_part_targs_A{}; t.Ctor(); return t }
//line :462:1
func (t *A_arbace_cpp_abi_part_targs_A) Ctor() {}
//line :462:1
func (t *A_arbace_cpp_abi_part_targs_A) Invoke_O_O__O(self, p__0 any) any {


	var tmp1 any = A_arbace_cpp_abi_A_const_81; var tmp2 any; var root_1669 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = p__0; if linked_1670 == nil { tmp2 = ifn_1671.Invoke_O__O(arg_1672) } else { tmp2 = linked_1670.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1669, arg_1672) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var c__2 any; var root_1673 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any; var root_1677 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = p__0; if linked_1678 == nil { arg_1676 = ifn_1679.Invoke_O__O(arg_1680) } else { arg_1676 = linked_1678.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1677, arg_1680) }; if linked_1674 == nil { c__2 = ifn_1675.Invoke_O__O(arg_1676) } else { c__2 = linked_1674.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1673, arg_1676) }; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_215.Invoke_O__O(c__2)) { return c__2 } else { return nil } } else { return nil
	} }
func A_arbace_cpp_abi_template_prefix_A_New() *A_arbace_cpp_abi_template_prefix_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_template_prefix_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_cpp_abi_template_prefix_A) Ctor() {}
//line :467:1
func (t *A_arbace_cpp_abi_template_prefix_A) Invoke_O_O_O_O__O(self, out__0, tid__1, nm__2 any) any { var i__4 int32; var tmp1 any; var root_1681 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1683 lang.IFn; if



	linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_1682 == nil { tmp1 = ifn_1683.Invoke_O__O(arg_1684) } else { tmp1 = linked_1682.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1681, arg_1684) }; i__4 = jrt.List_Cast(tmp1).IndexOf_O__I(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_215, tid__1)); var tmp2 bool; var and__1927000168__auto____5 bool =
	lang.Util_Equiv_O_O__Z_NoInit(out__0, Lit_25); if and__1927000168__auto____5 {

		tmp2 = lang.Util_Equiv_O_O__Z_NoInit(nm__2, Lit_194) } else { tmp2 = and__1927000168__auto____5 }; if tmp2 {
//line :472:1
			return Lit_206 } else { var tmp3 bool; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(out__0, Lit_25)


				if and__1927000168__auto____5_2 { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(nm__2, Lit_186) } else { tmp3 = and__1927000168__auto____5_2 }
//line :472:1
				if tmp3 { return Lit_207 } else { if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__4)) { var s__5 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 any; var root_1685 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_1687 lang.IFn




					if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = nm__2; if linked_1686 == nil { tmp5 = ifn_1687.Invoke_O__O(arg_1688) } else { tmp5 = linked_1686.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_1685, arg_1688) }; s__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, out__0, tmp5)).Ref(); var root_1693 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_1697 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_1698 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_215, tid__1); if linked_1694 == nil { ifn_1695.Invoke_O_O_O__O(arg_1696, arg_1697, arg_1698) } else { linked_1694.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1693, arg_1696, arg_1697, arg_1698) }
//line :472:1
					return s__5 } else { if A_arbace_cpp_abi_A_const_118 != nil {





						var root_1689 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1689, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__4).Ref(); if linked_1690 == nil { return ifn_1691.Invoke_O__O(arg_1692) } else { return linked_1690.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_1689, lang.RT_LongCast_O__J_NoInit(arg_1692)) } } else {
//line :472:1
							return nil } } } } }







func A_arbace_cpp_abi_std_abbreviation_A_New() *A_arbace_cpp_abi_std_abbreviation_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_std_abbreviation_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_cpp_abi_std_abbreviation_A) Ctor() {}
//line :480:1
func (t *A_arbace_cpp_abi_std_abbreviation_A) Invoke_O_O__O(self, c__0 any) any {




	if jrt.J2g_Truth(c__0) { var ch__2 any = A_arbace_cpp_abi_A_const_216; var traits_QMARK___3 any; var fnbody__1713 any = A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_New_O(ch__2); var tmp1 *jrt.Class
		var fncls__1712 /*line :485:1*/*jrt.Class = A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_fn_class

		if fncls__1712 == nil { var fncls__1712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, fnbody__1713); A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_fn_class = fncls__1712d; tmp1 = fncls__1712d } else { tmp1 = fncls__1712 }; traits_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1713, tmp1, nil)
//line :485:1
		var alloc_QMARK___4 any; var fnbody__1728 any = A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_New_O(ch__2); var tmp2 *jrt.Class
		var fncls__1727 /*line :485:1*/*jrt.Class = A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_fn_class


		if fncls__1727 == nil { var fncls__1727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, fnbody__1728); A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_fn_class = fncls__1727d; tmp2 = fncls__1727d } else { tmp2 = fncls__1727 }; alloc_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1728, tmp2, nil)
//line :485:1
		var as__5 any; var root_1729 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1731 lang.IFn



		if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(c__0); if linked_1730 == nil { as__5 = ifn_1731.Invoke_O__O(arg_1732) } else { as__5 = linked_1730.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1729, arg_1732) }
//line :485:1
		var G__677000242__6_ any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(c__0)




		switch lang.Util_Hash_O__I_NoInit(G__677000242__6_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__677000242__6_, Lit_186) {



			var tmp3 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(as__5))); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp4 any; var root_1734 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_68); if linked_1735 == nil { tmp4 = ifn_1736.Invoke_O__O(arg_1737) } else { tmp4 = linked_1735.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1734, arg_1737) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(ch__2, tmp4); if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(traits_QMARK___3).Invoke_O__O(lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_143)); if jrt.J2g_Truth(and__1927000168__auto____9) { tmp3 = lang.IFn_Cast(alloc_QMARK___4).Invoke_O__O(lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_221)) } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp3) { return Lit_187 } else { return nil } }
//line :490:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__677000242__6_, Lit_188) {


			var tmp5 any; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(as__5))); if and__1927000168__auto____7_2 { var and__1927000168__auto____8_2 bool; var tmp6 any; var root_1738 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_68); if linked_1739 == nil { tmp6 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp6 = linked_1739.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1738, arg_1741) }; and__1927000168__auto____8_2 = lang.Util_Equiv_O_O__Z_NoInit(ch__2, tmp6); if and__1927000168__auto____8_2 { tmp5 = lang.IFn_Cast(traits_QMARK___3).Invoke_O__O(lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_143)) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_2).Ref() } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7_2).Ref() }; if jrt.J2g_Truth(tmp5) { return Lit_189 } else { return nil } }
//line :490:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__677000242__6_, Lit_190) {
			var tmp7 any; var and__1927000168__auto____7_3 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(as__5))); if and__1927000168__auto____7_3 { var and__1927000168__auto____8_3 bool; var tmp8 any; var root_1742 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_68); if linked_1743 == nil { tmp8 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp8 = linked_1743.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1742, arg_1745) }; and__1927000168__auto____8_3 = lang.Util_Equiv_O_O__Z_NoInit(ch__2, tmp8); if and__1927000168__auto____8_3 { tmp7 = lang.IFn_Cast(traits_QMARK___3).Invoke_O__O(lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_143)) } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7_3).Ref() }; if jrt.J2g_Truth(tmp7) { return Lit_191 } else { return nil } }
//line :490:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__677000242__6_, Lit_192) {

			var tmp9 any; var and__1927000168__auto____7_4 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(as__5))); if and__1927000168__auto____7_4 { var and__1927000168__auto____8_4 bool; var tmp10 any; var root_1746 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_68); if linked_1747 == nil { tmp10 = ifn_1748.Invoke_O__O(arg_1749) } else { tmp10 = linked_1747.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1746, arg_1749) }; and__1927000168__auto____8_4 = lang.Util_Equiv_O_O__Z_NoInit(ch__2, tmp10); if and__1927000168__auto____8_4 { tmp9 = lang.IFn_Cast(traits_QMARK___3).Invoke_O__O(lang.IFn_Cast(as__5).Invoke_O__O(A_arbace_cpp_abi_A_const_143)) } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_4).Ref() } } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7_4).Ref() }; if jrt.J2g_Truth(tmp9) { return Lit_193 } else { return nil } }
//line :490:1
		default:}; return nil } else {
//line :485:1
			return nil
		} }
func A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_New_O(p0 any) *A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A{}; t.Ctor_O(p0); return t }
//line :487:1
func (t *A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A) Ctor_O(c__ch any) { t.F_ch = c__ch }
//line :487:1
func (t *A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_33; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__1)); if and__1927000168__auto____2 { var k__3 any; var root_1699 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(a__1); if linked_1700 == nil { k__3 = ifn_1701.Invoke_O__O(arg_1702) } else { k__3 = linked_1700.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1699, arg_1702) }; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_195, A_arbace_cpp_abi_A_const_127.Invoke_O__O(k__3)); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp2 any = A_arbace_cpp_abi_A_const_217; var tmp3 any; var root_1703 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(k__3); if linked_1704 == nil { tmp3 = ifn_1705.Invoke_O__O(arg_1706) } else { tmp3 = linked_1704.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1703, arg_1706) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____5 { var tmp4 any = lang.Tuple_Create_O__IPersistentVector(t.F_ch); var tmp5 any; var root_1707 any = A_arbace_cpp_abi_A_const_139.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var arg_1711 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(k__3); if linked_1708 == nil { tmp5 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { tmp5 = linked_1708.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_New_O(p0 any) *A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A{}; t.Ctor_O(p0); return t }
//line :488:1
func (t *A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A) Ctor_O(c__ch any) { t.F_ch = c__ch }
//line :488:1
func (t *A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_33; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__1)); if and__1927000168__auto____2 { var k__3 any; var root_1714 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(a__1); if linked_1715 == nil { k__3 = ifn_1716.Invoke_O__O(arg_1717) } else { k__3 = linked_1715.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1714, arg_1717) }; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_194, A_arbace_cpp_abi_A_const_127.Invoke_O__O(k__3)); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool; var tmp2 any = A_arbace_cpp_abi_A_const_220; var tmp3 any; var root_1718 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(k__3); if linked_1719 == nil { tmp3 = ifn_1720.Invoke_O__O(arg_1721) } else { tmp3 = linked_1719.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1718, arg_1721) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____5 { var tmp4 any = lang.Tuple_Create_O__IPersistentVector(t.F_ch); var tmp5 any; var root_1722 any = A_arbace_cpp_abi_A_const_139.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var arg_1726 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(k__3); if linked_1723 == nil { tmp5 = ifn_1724.Invoke_O_O__O(arg_1725, arg_1726) } else { tmp5 = linked_1723.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1722, arg_1725, arg_1726) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }








func A_arbace_cpp_abi_mangle_prefix_A_New() *A_arbace_cpp_abi_mangle_prefix_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_prefix_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_cpp_abi_mangle_prefix_A) Ctor() {}
//line :497:1
func (t *A_arbace_cpp_abi_mangle_prefix_A) Invoke_O_O__O(self, parts__0 any) any { { var parts__2 any; var root_1750 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1752 lang.IFn




	if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = parts__0; if linked_1751 == nil { parts__2 = ifn_1752.Invoke_O__O(arg_1753) } else { parts__2 = linked_1751.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1750, arg_1753) }
//line :497:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(parts__2); var idx__4 any; var fnbody__1765 any = A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_New_O(parts__2); var tmp1 *jrt.Class
	var fncls__1764 /*line :497:1*/*jrt.Class = A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_fn_class






	if fncls__1764 == nil { var fncls__1764d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, fnbody__1765); A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_fn_class = fncls__1764d; tmp1 = fncls__1764d } else { tmp1 = fncls__1764 }; idx__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1765, tmp1, nil)
//line :497:1
	var best__5 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__1767 any = A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_New_I_O(n__3, idx__4); var tmp3 *jrt.Class
	var fncls__1766 /*line :497:1*/*jrt.Class = A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_fn_class







	if fncls__1766 == nil { var fncls__1766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__1767); A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_fn_class = fncls__1766d; tmp3 = fncls__1766d } else { tmp3 = fncls__1766 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1767, tmp3, nil); best__5 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :497:1
	var start__6 any
	var or__1927000174__auto____6 any = best__5







	if jrt.J2g_Truth(or__1927000174__auto____6) { start__6 = or__1927000174__auto____6 } else { start__6 = A_arbace_cpp_abi_A_const_68 }
//line :497:1
	var i__7 any
	var na_1768 any = start__6








	if jrt.Long_InstanceOf(na_1768) { var n0_1769 int64 = jrt.NN(jrt.Long_Cast(na_1768)).LongValue__J(); if n0_1769 == 9223372036854775807 { i__7 = lang.Numbers_Inc_O__Number_NoInit(na_1768) } else { i__7 = jrt.Long_ValueOf_J__Long_NoInit(n0_1769 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1768) { var n0_1769_2 float64 = jrt.NN(jrt.Double_Cast(na_1768)).DoubleValue__D(); i__7 = jrt.Double_ValueOf_D__Double_NoInit(n0_1769_2 + 1.0).Ref() } else { i__7 = lang.Numbers_Inc_O__Number_NoInit(na_1768) } }
//line :497:1
	var out__8 any









	if jrt.J2g_Truth(best__5) { var root_1770 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1770, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = lang.IFn_Cast(idx__4).Invoke_O__O(best__5); if linked_1771 == nil { out__8 = ifn_1772.Invoke_O__O(arg_1773) } else { out__8 = linked_1771.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_1770, lang.RT_LongCast_O__J_NoInit(arg_1773)) } } else { out__8 = Lit_24 }
//line :497:1
L1: for {










	var tmp4 bool; var na_1774 any = i__7; var na_1775 int64 = int64(n__3); if jrt.Long_InstanceOf(na_1774) { var n0_1776 int64 = jrt.NN(jrt.Long_Cast(na_1774)).LongValue__J(); var n1_1777 int64 = na_1775; tmp4 = n0_1776 > n1_1777 } else { tmp4 = lang.Numbers_Gt_O_J__Z_NoInit(na_1774, na_1775) }; if tmp4 { return out__8 } else {

		var tmp5 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_J__Z_NoInit(i__7, 1); if and__1927000168__auto____9 { var tmp6 any = A_arbace_cpp_abi_A_const_224; var tmp7 any; var root_1779 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = parts__2; if linked_1780 == nil { tmp7 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp7 = linked_1780.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1779, arg_1782) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____9 }; if tmp5 {
			var tmp8 jrt.Number_I; var na_1811 any = i__7; if jrt.Long_InstanceOf(na_1811) { var n0_1812 int64 = jrt.NN(jrt.Long_Cast(na_1811)).LongValue__J(); if n0_1812 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_1811) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1812 + 1)) } } else { if jrt.Double_InstanceOf(na_1811) { var n0_1812_2 float64 = jrt.NN(jrt.Double_Cast(na_1811)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1812_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_1811) } }; i__7, out__8 = tmp8, Lit_25; continue L1 } else {
//line :510:1
				var p__9 any; var tmp9 jrt.Number_I
				var na_1783 any = i__7
				if jrt.Long_InstanceOf(na_1783) { var n0_1784 int64 = jrt.NN(jrt.Long_Cast(na_1783)).LongValue__J(); if n0_1784 == -9223372036854775808 { tmp9 = lang.Numbers_Dec_O__Number_NoInit(na_1783) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1784 - 1)) } } else { if jrt.Double_InstanceOf(na_1783) { var n0_1784_2 float64 = jrt.NN(jrt.Double_Cast(na_1783)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1784_2 - 1.0)) } else { tmp9 = lang.Numbers_Dec_O__Number_NoInit(na_1783) } }; p__9 = lang.RT_Nth_O_I__O_NoInit(parts__2, lang.RT_IntCast_O__I_NoInit(tmp9))
//line :510:1
				var ab__10 any


				if lang.Util_Equiv_O_O__Z_NoInit(out__8, Lit_25) { var root_1785 any = A_arbace_cpp_abi_A_const_225.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, A_arbace_cpp_abi_std_abbreviation_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any; var root_1789 any = A_arbace_cpp_abi_A_const_226.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, A_arbace_cpp_abi_part_targs_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = p__9; if linked_1790 == nil { arg_1788 = ifn_1791.Invoke_O__O(arg_1792) } else { arg_1788 = linked_1790.(*A_arbace_cpp_abi_part_targs_A).Invoke_O_O__O(root_1789, arg_1792) }; if linked_1786 == nil { ab__10 = ifn_1787.Invoke_O__O(arg_1788) } else { ab__10 = linked_1786.(*A_arbace_cpp_abi_std_abbreviation_A).Invoke_O_O__O(root_1785, arg_1788) } } else { ab__10 = nil }
//line :510:1
				var s__11 any; var temp__1927000408__auto____11 any



				if jrt.J2g_Truth(ab__10) { temp__1927000408__auto____11 = nil } else { var root_1793 any = A_arbace_cpp_abi_A_const_226.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, A_arbace_cpp_abi_part_targs_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = p__9; if linked_1794 == nil { temp__1927000408__auto____11 = ifn_1795.Invoke_O__O(arg_1796) } else { temp__1927000408__auto____11 = linked_1794.(*A_arbace_cpp_abi_part_targs_A).Invoke_O_O__O(root_1793, arg_1796) } }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var c__12 any = temp__1927000408__auto____11; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 any; var root_1797 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_1799 lang.IFn
					if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = out__8; var arg_1801 any = A_arbace_cpp_abi_A_const_215.Invoke_O__O(c__12); var arg_1802 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(c__12); if linked_1798 == nil { tmp11 = ifn_1799.Invoke_O_O_O__O(arg_1800, arg_1801, arg_1802) } else { tmp11 = linked_1798.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_1797, arg_1800, arg_1801, arg_1802) }; var tmp12 any = tmp11; var tmp13 any; var root_1803 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(c__12); if linked_1804 == nil { tmp13 = ifn_1805.Invoke_O__O(arg_1806) } else { tmp13 = linked_1804.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_1803, arg_1806) }; s__11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)).Ref() } else {
//line :514:1
						var or__1927000174__auto____12 any = ab__10

						if jrt.J2g_Truth(or__1927000174__auto____12) { s__11 = or__1927000174__auto____12 } else { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp15 any; var root_1807 any = A_arbace_cpp_abi_A_const_229.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, A_arbace_cpp_abi_part_name_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = p__9; if linked_1808 == nil { tmp15 = ifn_1809.Invoke_O__O(arg_1810) } else { tmp15 = linked_1808.(*A_arbace_cpp_abi_part_name_A).Invoke_O_O__O(root_1807, arg_1810) }; s__11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, out__8, tmp15)).Ref()
						} }
				if jrt.J2g_Truth(ab__10) { } else { var root_1813 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_1817 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_1818 any; var tmp16 any = A_arbace_cpp_abi_A_const_222; var tmp17 any; var root_1819 any = A_arbace_cpp_abi_A_const_223.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = parts__2; var arg_1823 any = A_arbace_cpp_abi_A_const_68; var arg_1824 any = i__7; if linked_1820 == nil { tmp17 = ifn_1821.Invoke_O_O_O__O(arg_1822, arg_1823, arg_1824) } else { tmp17 = linked_1820.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1819, arg_1822, arg_1823, arg_1824) }; arg_1818 = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17); if linked_1814 == nil { ifn_1815.Invoke_O_O_O__O(arg_1816, arg_1817, arg_1818) } else { linked_1814.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1813, arg_1816, arg_1817, arg_1818) } }
				var tmp18 jrt.Number_I; var na_1825 any = i__7; if jrt.Long_InstanceOf(na_1825) { var n0_1826 int64 = jrt.NN(jrt.Long_Cast(na_1825)).LongValue__J(); if n0_1826 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_1825) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1826 + 1)) } } else { if jrt.Double_InstanceOf(na_1825) { var n0_1826_2 float64 = jrt.NN(jrt.Double_Cast(na_1825)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1826_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_1825) } }; i__7, out__8 = tmp18, s__11; continue L1 } } } }; /*line :497:1*/panic("j2g: unreachable") }






func A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_prefix_idx__677000244_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_prefix_idx__677000244_A{}; t.Ctor_O(p0); return t }
//line :504:1
func (t *A_arbace_cpp_abi_mangle_prefix_idx__677000244_A) Ctor_O(c__parts any) { t.F_parts = c__parts }
//line :504:1
func (t *A_arbace_cpp_abi_mangle_prefix_idx__677000244_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any; var root_1754 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_1755 == nil { tmp1 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp1 = linked_1755.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp2 jrt.List = jrt.List_Cast(tmp1); var tmp3 any = A_arbace_cpp_abi_A_const_222; var tmp4 any; var root_1758 any = A_arbace_cpp_abi_A_const_223.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = t.F_parts; var arg_1762 any = A_arbace_cpp_abi_A_const_68; var arg_1763 any = m__1; if linked_1759 == nil { tmp4 = ifn_1760.Invoke_O_O_O__O(arg_1761, arg_1762, arg_1763) } else { tmp4 = linked_1759.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1758, arg_1761, arg_1762, arg_1763) }; return jrt.Integer_ValueOf_I__Integer_NoInit(tmp2.IndexOf_O__I(lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4))).Ref() }
func A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_New_I_O(p0 int32, p1 any) *A_arbace_cpp_abi_mangle_prefix_fn__677000246_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_prefix_fn__677000246_A{}; t.Ctor_I_O(p0, p1); return t }
//line :505:1
func (t *A_arbace_cpp_abi_mangle_prefix_fn__677000246_A) Ctor_I_O(c__n int32, c__idx any) { t.F_n = c__n; t.F_idx = c__idx }
//line :505:1
func (t *A_arbace_cpp_abi_mangle_prefix_fn__677000246_A) Invoke_O__O(self any) any { { var m__1 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); L1: for { if lang.Numbers_IsPos_J__Z_NoInit(m__1) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp1.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(m__1).Ref()))) { m__1 = lang.Numbers_Dec_J__J_NoInit(m__1); continue L1 } else { return jrt.Long_ValueOf_J__Long_NoInit(m__1).Ref() } } else { return nil } } }; panic("j2g: unreachable") }















func A_arbace_cpp_abi_path_of_type_A_New() *A_arbace_cpp_abi_path_of_type_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_path_of_type_A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_cpp_abi_path_of_type_A) Ctor() {}
//line :521:1
func (t *A_arbace_cpp_abi_path_of_type_A) Invoke_O_O__O(self, t__0 any) any { var G__677000249__2_ any = A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0); switch


	lang.Util_Hash_O__I_NoInit(G__677000249__2_) >> 0 & 1 { case 0: if any(G__677000249__2_) == any(A_arbace_cpp_abi_A_const_33) {
		var root_1828 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any; var root_1833 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any; var tmp1 *lang.Keyword = A_arbace_cpp_abi_A_const_218; var tmp2 any; var root_1837 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, A_arbace_cpp_abi_cls_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0); if linked_1838 == nil { tmp2 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp2 = linked_1838.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_1837, arg_1840) }; arg_1836 = tmp1.Invoke_O__O(tmp2); if linked_1834 == nil { arg_1831 = ifn_1835.Invoke_O__O(arg_1836) } else { arg_1831 = linked_1834.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1833, arg_1836) }; var tmp3 any = A_arbace_cpp_abi_A_const_81; var arg_1832 any = lang.Tuple_Create_O_O__IPersistentVector(tmp3, A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0)); if linked_1829 == nil { return ifn_1830.Invoke_O_O__O(arg_1831, arg_1832) } else { return linked_1829.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1828, arg_1831, arg_1832) } }
//line :524:1
	case 1: if any(G__677000249__2_) == any(A_arbace_cpp_abi_A_const_34) {

		var root_1841 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any; var root_1846 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any; var tmp4 *lang.Keyword = A_arbace_cpp_abi_A_const_218; var tmp5 any; var root_1850 any = A_arbace_cpp_abi_A_const_54.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, A_arbace_cpp_abi_enm_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0); if linked_1851 == nil { tmp5 = ifn_1852.Invoke_O__O(arg_1853) } else { tmp5 = linked_1851.(*A_arbace_cpp_abi_enm_A).Invoke_O_O__O(root_1850, arg_1853) }; arg_1849 = tmp4.Invoke_O__O(tmp5); if linked_1847 == nil { arg_1844 = ifn_1848.Invoke_O__O(arg_1849) } else { arg_1844 = linked_1847.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1846, arg_1849) }; var tmp6 any = A_arbace_cpp_abi_A_const_34; var arg_1845 any = lang.Tuple_Create_O_O__IPersistentVector(tmp6, A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__0)); if linked_1842 == nil { return ifn_1843.Invoke_O_O__O(arg_1844, arg_1845) } else { return linked_1842.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1841, arg_1844, arg_1845) } }
//line :524:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__677000249__2_))))) }




func A_arbace_cpp_abi_local_enc_A_New() *A_arbace_cpp_abi_local_enc_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_local_enc_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_cpp_abi_local_enc_A) Ctor() {}
//line :529:1
func (t *A_arbace_cpp_abi_local_enc_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1854 any = A_arbace_cpp_abi_A_const_230.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = x__0; if linked_1855 == nil { tmp1 = ifn_1856.Invoke_O__O(arg_1857) } else { tmp1 = linked_1855.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1854, arg_1857) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var root_1858 any = A_arbace_cpp_abi_A_const_231.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, A_arbace_cpp_abi_local_encoding_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = x__0; if linked_1859 == nil { return ifn_1860.Invoke_O__O(arg_1861) } else { return linked_1859.(*A_arbace_cpp_abi_local_encoding_A).Invoke_O_O__O(root_1858, arg_1861) } } }

func A_arbace_cpp_abi_mangle_named_A_New() *A_arbace_cpp_abi_mangle_named_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_named_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_cpp_abi_mangle_named_A) Ctor() {}
//line :531:1
func (t *A_arbace_cpp_abi_mangle_named_A) Invoke_O_O__O(self, t__0 any) any { var parts__2 any; var root_1862 any = A_arbace_cpp_abi_A_const_232.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, A_arbace_cpp_abi_path_of_type_A_fn_class); var ifn_1864 lang.IFn; if


	linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = t__0; if linked_1863 == nil { parts__2 = ifn_1864.Invoke_O__O(arg_1865) } else { parts__2 = linked_1863.(*A_arbace_cpp_abi_path_of_type_A).Invoke_O_O__O(root_1862, arg_1865) }; var k__3 any = /*line :531:1*/lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_222, parts__2); var i__4 int32; var tmp1 any; var root_1866 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1868 lang.IFn; if




	linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_1867 == nil { tmp1 = ifn_1868.Invoke_O__O(arg_1869) } else { tmp1 = linked_1867.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1866, arg_1869) }; i__4 = jrt.List_Cast(tmp1).IndexOf_O__I(k__3); var tmp2 any; var root_1870 any =
	A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1872 lang.IFn; if
	linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(i__4))).Ref(); if linked_1871 == nil { tmp2 = ifn_1872.Invoke_O__O(arg_1873) } else { tmp2 = linked_1871.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1870, arg_1873) }; if /*line :537:1*/ jrt.J2g_Truth(tmp2) {
		var root_1874 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1874, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__4).Ref(); if linked_1875 == nil { return ifn_1876.Invoke_O__O(arg_1877) } else { return linked_1875.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_1874, lang.RT_LongCast_O__J_NoInit(arg_1877)) } } else {
//line :537:1
			var tmp3 any = A_arbace_cpp_abi_A_const_233; var tmp4 any; var root_1878 any = A_arbace_cpp_abi_A_const_234.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_ffirst__1927000018_A_fn_class); var ifn_1880 lang.IFn


			if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = parts__2; if linked_1879 == nil { tmp4 = ifn_1880.Invoke_O__O(arg_1881) } else { tmp4 = linked_1879.(*aot_arbace_core.A_arbace_core_ffirst__1927000018_A).Invoke_O_O__O(root_1878, arg_1881) }
//line :537:1
			if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var r__5 any; var root_1882 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1884 lang.IFn


				if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any; var root_1886 any = A_arbace_cpp_abi_A_const_235.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = parts__2; if linked_1887 == nil { arg_1885 = ifn_1888.Invoke_O__O(arg_1889) } else { arg_1885 = linked_1887.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1886, arg_1889) }; if linked_1883 == nil { r__5 = ifn_1884.Invoke_O__O(arg_1885) } else { r__5 = linked_1883.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1882, arg_1885) }
//line :537:1
				var s__6 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_17, nil); var tmp6 any; var root_1890 any = A_arbace_cpp_abi_A_const_236.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, A_arbace_cpp_abi_local_enc_A_fn_class); var ifn_1892 lang.IFn



				if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any; var root_1894 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any; var root_1898 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = parts__2; if linked_1899 == nil { arg_1897 = ifn_1900.Invoke_O__O(arg_1901) } else { arg_1897 = linked_1899.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1898, arg_1901) }; if linked_1895 == nil { arg_1893 = ifn_1896.Invoke_O__O(arg_1897) } else { arg_1893 = linked_1895.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1894, arg_1897) }; if linked_1891 == nil { tmp6 = ifn_1892.Invoke_O__O(arg_1893) } else { tmp6 = linked_1891.(*A_arbace_cpp_abi_local_enc_A).Invoke_O_O__O(root_1890, arg_1893) }; var tmp7 any = tmp6; var tmp8 any; if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(r__5))) { var root_1902 any = A_arbace_cpp_abi_A_const_229.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, A_arbace_cpp_abi_part_name_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any; var root_1906 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = r__5; if linked_1907 == nil { arg_1905 = ifn_1908.Invoke_O__O(arg_1909) } else { arg_1905 = linked_1907.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1906, arg_1909) }; if linked_1903 == nil { tmp8 = ifn_1904.Invoke_O__O(arg_1905) } else { tmp8 = linked_1903.(*A_arbace_cpp_abi_part_name_A).Invoke_O_O__O(root_1902, arg_1905) } } else { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_17); var tmp10 any; var root_1910 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = r__5; if linked_1911 == nil { tmp10 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp10 = linked_1911.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_1910, arg_1913) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil)).Ref() }; s__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8)).Ref()
				var root_1930 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_1934 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_1935 any = k__3; if linked_1931 == nil { ifn_1932.Invoke_O_O_O__O(arg_1933, arg_1934, arg_1935) } else { linked_1931.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1930, arg_1933, arg_1934, arg_1935) }
//line :537:1
				return s__6 } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(parts__2))) {






					var root_1914 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = parts__2; if linked_1915 == nil { return ifn_1916.Invoke_O__O(arg_1917) } else { return linked_1915.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_1914, arg_1917) } } else {
//line :537:1
						var tmp11 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(parts__2)))







						if and__1927000168__auto____5 { var tmp12 any = A_arbace_cpp_abi_A_const_238; var tmp13 any; var root_1918 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = parts__2; if linked_1919 == nil { tmp13 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp13 = linked_1919.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1918, arg_1921) }; tmp11 = lang.Util_Equiv_O_O__Z_NoInit(tmp12, tmp13) } else { tmp11 = and__1927000168__auto____5 }
//line :537:1
						if tmp11 {







							var root_1922 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = parts__2; if linked_1923 == nil { return ifn_1924.Invoke_O__O(arg_1925) } else { return linked_1923.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_1922, arg_1925) } } else {
//line :537:1
								if A_arbace_cpp_abi_A_const_118 != nil {








									var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_17); var tmp15 any; var root_1926 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = parts__2; if linked_1927 == nil { tmp15 = ifn_1928.Invoke_O__O(arg_1929) } else { tmp15 = linked_1927.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_1926, arg_1929) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, nil)).Ref() } else {
//line :537:1
										return nil } } } } } }










func A_arbace_cpp_abi_template_param_A_New() *A_arbace_cpp_abi_template_param_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_template_param_A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_cpp_abi_template_param_A) Ctor() {}
//line :548:1
func (t *A_arbace_cpp_abi_template_param_A) InvokePrim_O_J__O(self any, i__0 int64) any {


	if lang.Numbers_IsZero_J__Z_NoInit(i__0) { return Lit_205 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(i__0)).Ref(), nil)).Ref() } }
//line :548:1
func (t *A_arbace_cpp_abi_template_param_A) Invoke_O_O__O(self, p_i__0 any) any { return t.InvokePrim_O_J__O(self, lang.RT_LongCast_O__J_NoInit(p_i__0)) }




func A_arbace_cpp_abi_tspec_unwrapped_A_New() *A_arbace_cpp_abi_tspec_unwrapped_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_tspec_unwrapped_A{}; t.Ctor(); return t }
//line :553:1
func (t *A_arbace_cpp_abi_tspec_unwrapped_A) Ctor() {}
//line :553:1
func (t *A_arbace_cpp_abi_tspec_unwrapped_A) Invoke_O_O__O(self, t__0 any) any { var temp__1927000408__auto____2 any = A_arbace_cpp_abi_A_const_239.Invoke_O__O(t__0); if


	jrt.J2g_Truth(temp__1927000408__auto____2) { var tt__3 any = temp__1927000408__auto____2; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1936 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_1938 lang.IFn

		if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, tt__3); var arg_1940 any; var fnbody__1946 any = A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_New_O(tt__3); var tmp3 *jrt.Class; var fncls__1945 *jrt.Class = A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_fn_class; if fncls__1945 == nil { var fncls__1945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_208, false, fnbody__1946); A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_fn_class = fncls__1945d; tmp3 = fncls__1945d } else { tmp3 = fncls__1945 }; arg_1940 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1946, tmp3, nil); if linked_1937 == nil { tmp2 = ifn_1938.Invoke_O_O__O(arg_1939, arg_1940) } else { tmp2 = linked_1937.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_1936, arg_1939, arg_1940) }; var tmp4 any = tmp2; var tmp5 any; var root_1947 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(t__0); if linked_1948 == nil { tmp5 = ifn_1949.Invoke_O__O(arg_1950) } else { tmp5 = linked_1948.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_1947, arg_1950) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any; var root_1951 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any; var tmp8 any; var root_1957 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(t__0); if linked_1958 == nil { tmp8 = ifn_1959.Invoke_O__O(arg_1960) } else { tmp8 = linked_1958.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1957, arg_1960) }; if jrt.J2g_Truth(tmp8) { arg_1954 = Lit_24 } else { var root_1961 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_1962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1961, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_1963 lang.IFn; if linked_1962 == nil { ifn_1963 = lang.IFn_Cast(root_1961) } else { ifn_1963 = nil }; var arg_1964 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(t__0); if linked_1962 == nil { arg_1954 = ifn_1963.Invoke_O__O(arg_1964) } else { arg_1954 = linked_1962.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_1961, arg_1964) } }; var arg_1955 any = A_arbace_cpp_abi_A_const_215.Invoke_O__O(t__0); var arg_1956 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(t__0); if linked_1952 == nil { tmp7 = ifn_1953.Invoke_O_O_O__O(arg_1954, arg_1955, arg_1956) } else { tmp7 = linked_1952.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_1951, arg_1954, arg_1955, arg_1956) }; var tmp9 any = tmp7; var tmp10 any; var root_1965 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(t__0); if linked_1966 == nil { tmp10 = ifn_1967.Invoke_O__O(arg_1968) } else { tmp10 = linked_1966.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_1965, arg_1968) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10)).Ref() } }
//line :558:1
func A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_New_O(p0 any) *A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A{}; t.Ctor_O(p0); return t }
//line :558:1
func (t *A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A) Ctor_O(c__tt any) { t.F_tt = c__tt }
//line :558:1
func (t *A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A) Invoke_O__O(self any) any { var root_1941 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1941, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(t.F_tt); if linked_1942 == nil { return ifn_1943.Invoke_O__O(arg_1944) } else { return linked_1942.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_1941, lang.RT_LongCast_O__J_NoInit(arg_1944)) } }






func A_arbace_cpp_abi_mangle_expr_A_New() *A_arbace_cpp_abi_mangle_expr_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_expr_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_cpp_abi_mangle_expr_A) Ctor() {}
//line :565:1
func (t *A_arbace_cpp_abi_mangle_expr_A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 any; var root_1969 any = A_arbace_cpp_abi_A_const_245.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1971 lang.IFn
	if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = x__0; if linked_1970 == nil { tmp1 = ifn_1971.Invoke_O__O(arg_1972) } else { tmp1 = linked_1970.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1969, arg_1972) }
//line :570:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_17); var tmp3 any; if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(x__0)) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(x__0))).Ref())).Ref() } else { tmp3 = x__0 }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :570:1
			var tmp4 any = A_arbace_cpp_abi_A_const_246; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_cpp_abi_A_const_16.Invoke_O__O(x__0)) {

				var root_1973 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1973, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_1975 lang.IFn; if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0); if linked_1974 == nil { return ifn_1975.Invoke_O__O(arg_1976) } else { return linked_1974.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_1973, lang.RT_LongCast_O__J_NoInit(arg_1976)) } } else {
//line :570:1
					var tmp5 any = A_arbace_cpp_abi_A_const_247; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_cpp_abi_A_const_16.Invoke_O__O(x__0)) { var G__677000258__2_ any = A_arbace_cpp_abi_A_const_248.Invoke_O__O(x__0)



						switch lang.Util_Hash_O__I_NoInit(G__677000258__2_) >> 2 & 15 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, A_arbace_cpp_abi_A_const_249) { var b__3 any; var root_1978 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, A_arbace_cpp_abi_unq_A_fn_class); var ifn_1980 lang.IFn
							if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = A_arbace_cpp_abi_A_const_250.Invoke_O__O(x__0); if linked_1979 == nil { b__3 = ifn_1980.Invoke_O__O(arg_1981) } else { b__3 = linked_1979.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_1978, arg_1981) }
//line :574:1
							var G__677000259__4_ any = A_arbace_cpp_abi_A_const_16.Invoke_O__O(b__3)

							switch lang.Util_Hash_O__I_NoInit(G__677000259__4_) >> 0 & 1 { case 0: if any(G__677000259__4_) == any(A_arbace_cpp_abi_A_const_251) { var w__5 any = A_arbace_cpp_abi_A_const_252.Invoke_O__O(b__3); var args__6 any




								if jrt.J2g_Truth(w__5) { var root_1983 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any; var root_1987 any = A_arbace_cpp_abi_A_const_253.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = w__5; var arg_1991 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(b__3); if linked_1988 == nil { arg_1986 = ifn_1989.Invoke_O_O__O(arg_1990, arg_1991) } else { arg_1986 = linked_1988.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1987, arg_1990, arg_1991) }; if linked_1984 == nil { args__6 = ifn_1985.Invoke_O__O(arg_1986) } else { args__6 = linked_1984.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1983, arg_1986) } } else { args__6 = A_arbace_cpp_abi_A_const_244.Invoke_O__O(b__3) }
//line :576:1
								var targs__7 any; var root_1992 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_1994 lang.IFn





								if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any; var root_1996 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_112.GetRawRoot__O()); var tmp7 *lang.Compiler_AOTFn; var fnbody__2015 any = A_arbace_cpp_abi_mangle_expr_fn__677000260_A_New(); var tmp8 *jrt.Class; var fncls__2014 *jrt.Class = A_arbace_cpp_abi_mangle_expr_fn__677000260_A_fn_class; if fncls__2014 == nil { var fncls__2014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_cpp_abi_mangle_expr_fn__677000260_A_fn_class = fncls__2014d; tmp8 = fncls__2014d } else { tmp8 = fncls__2014 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2015, tmp8, nil); arg_1999 = tmp6.Invoke_O_O__O(tmp7.Ref(), args__6); if linked_1997 == nil { arg_1995 = ifn_1998.Invoke_O__O(arg_1999) } else { arg_1995 = linked_1997.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1996, arg_1999) }; if linked_1993 == nil { targs__7 = ifn_1994.Invoke_O__O(arg_1995) } else { targs__7 = linked_1993.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_1992, arg_1995) }
//line :576:1
								var temp__1927000408__auto____8 any; var root_2016 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2018 lang.IFn






								if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = A_arbace_cpp_abi_A_const_256.Invoke_O__O(b__3); if linked_2017 == nil { temp__1927000408__auto____8 = ifn_2018.Invoke_O__O(arg_2019) } else { temp__1927000408__auto____8 = linked_2017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2016, arg_2019) }; if jrt.J2g_Truth(temp__1927000408__auto____8) { var q__9 any = temp__1927000408__auto____8; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, nil, nil, Lit_17, nil); var tmp10 any; var root_2020 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2022 lang.IFn

									if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2024 any; var root_2025 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var arg_2029 any = q__9; if linked_2026 == nil { arg_2024 = ifn_2027.Invoke_O_O__O(arg_2028, arg_2029) } else { arg_2024 = linked_2026.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2025, arg_2028, arg_2029) }; if linked_2021 == nil { tmp10 = ifn_2022.Invoke_O_O__O(arg_2023, arg_2024) } else { tmp10 = linked_2021.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2020, arg_2023, arg_2024) }; var tmp11 any = tmp10; var tmp12 any; var root_2030 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2030, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2032 lang.IFn; if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(b__3); if linked_2031 == nil { tmp12 = ifn_2032.Invoke_O__O(arg_2033) } else { tmp12 = linked_2031.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2030, arg_2033) }; var tmp13 any = tmp12; var tmp14 any; var root_2034 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2034, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2036 lang.IFn; if linked_2035 == nil { ifn_2036 = lang.IFn_Cast(root_2034) } else { ifn_2036 = nil }; var arg_2037 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2035 == nil { tmp14 = ifn_2036.Invoke_O__O(arg_2037) } else { tmp14 = linked_2035.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2034, arg_2037) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, tmp13, targs__7, nil, tmp14)).Ref() } else {
										var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, nil, nil, Lit_17, nil); var tmp16 any; var tmp17 any = A_arbace_cpp_abi_A_const_257; var tmp18 any; var root_2038 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(b__3); if linked_2039 == nil { tmp18 = ifn_2040.Invoke_O__O(arg_2041) } else { tmp18 = linked_2039.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2038, arg_2041) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp17, tmp18) { tmp16 = nil } else { var root_2042 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2046 any; var root_2047 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = A_arbace_cpp_abi_A_const_229.GetRawRoot__O(); var arg_2051 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(b__3); if linked_2048 == nil { arg_2046 = ifn_2049.Invoke_O_O__O(arg_2050, arg_2051) } else { arg_2046 = linked_2048.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2047, arg_2050, arg_2051) }; if linked_2043 == nil { tmp16 = ifn_2044.Invoke_O_O__O(arg_2045, arg_2046) } else { tmp16 = linked_2043.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2042, arg_2045, arg_2046) } }; var tmp19 any = tmp16; var tmp20 any; var root_2052 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2054 lang.IFn
										if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(b__3); if linked_2053 == nil { tmp20 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp20 = linked_2053.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2052, arg_2055) }
//line :586:1
										var tmp21 any = tmp20; var tmp22 any; var root_2056 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2058 lang.IFn
										if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2057 == nil { tmp22 = ifn_2058.Invoke_O__O(arg_2059) } else { tmp22 = linked_2057.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2056, arg_2059) }
//line :586:1
										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, tmp21, targs__7, nil, tmp22)).Ref() } }
//line :576:1
							case 1: if any(G__677000259__4_) == any(A_arbace_cpp_abi_A_const_258) {
								var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, nil); var tmp24 any; var root_2060 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = b__3; if linked_2061 == nil { tmp24 = ifn_2062.Invoke_O__O(arg_2063) } else { tmp24 = linked_2061.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2060, arg_2063) }; var tmp25 any = tmp24; var tmp26 any; var root_2064 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2065 == nil { tmp26 = ifn_2066.Invoke_O__O(arg_2067) } else { tmp26 = linked_2065.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2064, arg_2067) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, tmp26)).Ref() }
//line :576:1
							default:
							}










							var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp28 any = A_arbace_cpp_abi_A_const_260; return tmp27.Invoke_O_O_O__O(tmp28, Lit_128, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(b__3)) }
//line :574:1
						case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, A_arbace_cpp_abi_A_const_261) {






























							var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp30 any; var root_2078 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2079 == nil { tmp30 = ifn_2080.Invoke_O__O(arg_2081) } else { tmp30 = linked_2079.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2078, arg_2081) }; var tmp31 any = tmp30; var tmp32 any; var root_2082 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2083 == nil { tmp32 = ifn_2084.Invoke_O__O(arg_2085) } else { tmp32 = linked_2083.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2082, arg_2085) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32)).Ref() }
//line :574:1
						case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, Lit_129) { var temp__1927000408__auto____3 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0)





































							if jrt.J2g_Truth(temp__1927000408__auto____3) { var i__4 any = temp__1927000408__auto____3; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_119, nil); var tmp34 any; var root_2086 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2086, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 int64 = lang.RT_LongCast_O__J_NoInit(i__4); if linked_2087 == nil { tmp34 = ifn_2088.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_2089).Ref()) } else { tmp34 = linked_2087.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2086, arg_2089) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref() } else { var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp36 any = A_arbace_cpp_abi_A_const_260; return tmp35.Invoke_O_O_O__O(tmp36, Lit_130, A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0)) } }
//line :574:1
						case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, Lit_131) {


































							var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_132, nil); var tmp38 any; var root_2096 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = A_arbace_cpp_abi_A_const_63.Invoke_O__O(x__0); if linked_2097 == nil { tmp38 = ifn_2098.Invoke_O__O(arg_2099) } else { tmp38 = linked_2097.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2096, arg_2099) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref() }
//line :574:1
						case 13: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, A_arbace_cpp_abi_A_const_264) {

































							var tmp39 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp40 any; var root_2126 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2127 == nil { tmp40 = ifn_2128.Invoke_O__O(arg_2129) } else { tmp40 = linked_2127.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2126, arg_2129) }; var tmp41 any = tmp40; var tmp42 any; var root_2130 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2131 == nil { tmp42 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp42 = linked_2131.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2130, arg_2133) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp39, jrt.RefArrayOf(jrt.Object_class, tmp41, tmp42)).Ref() }
//line :574:1
						case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__677000258__2_, A_arbace_cpp_abi_A_const_265) { var temp__1927000408__auto____3_2 any = A_arbace_cpp_abi_A_const_266.Invoke_O__O(x__0)




















							if jrt.J2g_Truth(temp__1927000408__auto____3_2) { var w__4 any = temp__1927000408__auto____3_2; var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_133, nil, nil, Lit_17, nil, nil, Lit_17); var tmp44 any; var root_2134 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2136 lang.IFn
								if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(w__4); if linked_2135 == nil { tmp44 = ifn_2136.Invoke_O__O(arg_2137) } else { tmp44 = linked_2135.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2134, arg_2137) }; var tmp45 any = tmp44; var tmp46 any; var tmp47 any; var root_2138 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(w__4); if linked_2139 == nil { tmp47 = ifn_2140.Invoke_O__O(arg_2141) } else { tmp47 = linked_2139.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2138, arg_2141) }; if jrt.J2g_Truth(tmp47) { var root_2142 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(w__4); if linked_2143 == nil { tmp46 = ifn_2144.Invoke_O__O(arg_2145) } else { tmp46 = linked_2143.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2142, arg_2145) } } else { tmp46 = nil }; var tmp48 any = tmp46; var tmp49 any; var root_2146 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2148 lang.IFn
								if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2147 == nil { tmp49 = ifn_2148.Invoke_O__O(arg_2149) } else { tmp49 = linked_2147.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2146, arg_2149) }
//line :596:1
								var tmp50 any = tmp49; var tmp51 any; var tmp52 any; var root_2150 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2152 lang.IFn
								if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0); if linked_2151 == nil { tmp52 = ifn_2152.Invoke_O__O(arg_2153) } else { tmp52 = linked_2151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2150, arg_2153) }; if jrt.J2g_Truth(tmp52) { var root_2154 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0); if linked_2155 == nil { tmp51 = ifn_2156.Invoke_O__O(arg_2157) } else { tmp51 = linked_2155.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2154, arg_2157) } } else { tmp51 = nil }
//line :596:1
								return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp43, jrt.RefArrayOf(jrt.Object_class, nil, tmp45, tmp48, nil, tmp50, tmp51, nil)).Ref() } else {
//line :595:1
									var b__4 any; var root_2158 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, A_arbace_cpp_abi_unq_A_fn_class); var ifn_2160 lang.IFn


									if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = A_arbace_cpp_abi_A_const_250.Invoke_O__O(x__0); if linked_2159 == nil { b__4 = ifn_2160.Invoke_O__O(arg_2161) } else { b__4 = linked_2159.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_2158, arg_2161) }
//line :595:1
									var ___5 any; var tmp53 any; var and__1927000168__auto____5 any = b__4; _ = ___5



									if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp54 any = A_arbace_cpp_abi_A_const_33; tmp53 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp54, A_arbace_cpp_abi_A_const_16.Invoke_O__O(b__4))).Ref() } else { tmp53 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp53) { ___5 = nil } else { var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp56 any = A_arbace_cpp_abi_A_const_260; ___5 = tmp55.Invoke_O_O_O__O(tmp56, Lit_134, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(b__4)) }
//line :595:1
									var c__6 any; var root_2172 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, A_arbace_cpp_abi_cls_A_fn_class); var ifn_2174 lang.IFn




									if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(b__4); if linked_2173 == nil { c__6 = ifn_2174.Invoke_O__O(arg_2175) } else { c__6 = linked_2173.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_2172, arg_2175) }
									var tmp57 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_133, nil, nil, nil, Lit_17, nil, nil, Lit_17); var tmp58 any; var root_2176 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2178 lang.IFn; if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2180 any; var root_2181 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = A_arbace_cpp_abi_A_const_229.GetRawRoot__O(); var arg_2185 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(c__6); if linked_2182 == nil { arg_2180 = ifn_2183.Invoke_O_O__O(arg_2184, arg_2185) } else { arg_2180 = linked_2182.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2181, arg_2184, arg_2185) }; if linked_2177 == nil { tmp58 = ifn_2178.Invoke_O_O__O(arg_2179, arg_2180) } else { tmp58 = linked_2177.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2176, arg_2179, arg_2180) }; var tmp59 any = tmp58; var tmp60 any; var root_2186 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(c__6); if linked_2187 == nil { tmp60 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp60 = linked_2187.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2186, arg_2189) }; var tmp61 any = tmp60; var tmp62 any; var tmp63 any; var root_2190 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(c__6); if linked_2191 == nil { tmp63 = ifn_2192.Invoke_O__O(arg_2193) } else { tmp63 = linked_2191.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2190, arg_2193) }; if jrt.J2g_Truth(tmp63) { var root_2194 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(c__6); if linked_2195 == nil { tmp62 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp62 = linked_2195.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2194, arg_2197) } } else { tmp62 = nil }; var tmp64 any = tmp62; var tmp65 any; var root_2198 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2200 lang.IFn
									if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__0); if linked_2199 == nil { tmp65 = ifn_2200.Invoke_O__O(arg_2201) } else { tmp65 = linked_2199.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2198, arg_2201) }
//line :601:1
									var tmp66 any = tmp65; var tmp67 any; var tmp68 any; var root_2202 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2204 lang.IFn
									if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0); if linked_2203 == nil { tmp68 = ifn_2204.Invoke_O__O(arg_2205) } else { tmp68 = linked_2203.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2202, arg_2205) }; if jrt.J2g_Truth(tmp68) { var root_2206 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0); if linked_2207 == nil { tmp67 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp67 = linked_2207.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2206, arg_2209) } } else { tmp67 = nil }
//line :601:1
									return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp57, jrt.RefArrayOf(jrt.Object_class, nil, tmp59, tmp61, tmp64, nil, tmp66, tmp67, nil)).Ref() } }
//line :574:1
						default:
						}





































						var tmp69 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp70 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_262.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_abi_A_const_248.Invoke_O__O(x__0)); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp70 = or__1927000174__auto____5 } else { var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp72 any = A_arbace_cpp_abi_A_const_260; tmp70 = tmp71.Invoke_O_O_O__O(tmp72, Lit_68, A_arbace_cpp_abi_A_const_248.Invoke_O__O(x__0)) }; var tmp73 any = tmp70; var tmp74 any; var root_2106 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2110 any; var root_2111 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = A_arbace_cpp_abi_A_const_263.GetRawRoot__O(); var arg_2115 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2112 == nil { arg_2110 = ifn_2113.Invoke_O_O__O(arg_2114, arg_2115) } else { arg_2110 = linked_2112.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2111, arg_2114, arg_2115) }; if linked_2107 == nil { tmp74 = ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { tmp74 = linked_2107.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp69, jrt.RefArrayOf(jrt.Object_class, tmp73, tmp74)).Ref() } else {
//line :570:1
							if A_arbace_cpp_abi_A_const_118 != nil {











































								var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp76 any = A_arbace_cpp_abi_A_const_260; return tmp75.Invoke_O_O_O__O(tmp76, Lit_135, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(x__0)) } else {
//line :570:1
									return nil
								}
						}
				}
		}
}






func A_arbace_cpp_abi_mangle_expr_fn__677000260_A_New() *A_arbace_cpp_abi_mangle_expr_fn__677000260_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_expr_fn__677000260_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_cpp_abi_mangle_expr_fn__677000260_A) Ctor() {}
//line :582:1
func (t *A_arbace_cpp_abi_mangle_expr_fn__677000260_A) Invoke_O_O__O(self, p1__677000257_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_2005 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = p1__677000257_SHARP___1; if linked_2006 == nil { and__1927000168__auto____2 = ifn_2007.Invoke_O__O(arg_2008) } else { and__1927000168__auto____2 = linked_2006.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2005, arg_2008) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_2009 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = p1__677000257_SHARP___1; var arg_2013 any = A_arbace_cpp_abi_A_const_255; if linked_2010 == nil { and__1927000168__auto____3 = ifn_2011.Invoke_O_O__O(arg_2012, arg_2013) } else { and__1927000168__auto____3 = linked_2010.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2009, arg_2012, arg_2013) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_cpp_abi_A_const_16.Invoke_O__O(p1__677000257_SHARP___1), nil)).Ref() } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return A_arbace_cpp_abi_A_const_255.Invoke_O__O(p1__677000257_SHARP___1) } else { return lang.Tuple_Create_O__IPersistentVector(p1__677000257_SHARP___1) } }



































func A_arbace_cpp_abi_dt_unresolved_A_New() *A_arbace_cpp_abi_dt_unresolved_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dt_unresolved_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_cpp_abi_dt_unresolved_A) Ctor() {}
//line :618:1
func (t *A_arbace_cpp_abi_dt_unresolved_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_267.Invoke_O__O(x__0)) { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp4 any; var root_2210 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = A_arbace_cpp_abi_A_const_267.Invoke_O__O(x__0); if linked_2211 == nil { tmp4 = ifn_2212.Invoke_O__O(arg_2213) } else { tmp4 = linked_2211.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2210, arg_2213) }; tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)) } else { var tmp5 any; var root_2214 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2216 lang.IFn
		if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = A_arbace_cpp_abi_A_const_268.Invoke_O__O(x__0); if linked_2215 == nil { tmp5 = ifn_2216.Invoke_O__O(arg_2217) } else { tmp5 = linked_2215.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2214, arg_2217) }
//line :622:1
		if jrt.J2g_Truth(tmp5) {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, Lit_17); var tmp7 any; var root_2218 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2218, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2222 any; var root_2223 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var arg_2227 any = A_arbace_cpp_abi_A_const_268.Invoke_O__O(x__0); if linked_2224 == nil { arg_2222 = ifn_2225.Invoke_O_O__O(arg_2226, arg_2227) } else { arg_2222 = linked_2224.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2223, arg_2226, arg_2227) }; if linked_2219 == nil { tmp7 = ifn_2220.Invoke_O_O__O(arg_2221, arg_2222) } else { tmp7 = linked_2219.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2218, arg_2221, arg_2222) }; tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)) } else {
//line :622:1
				tmp2 = nil } }; var tmp8 any = tmp2.Ref(); var tmp9 any; var root_2228 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2230 lang.IFn

	if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(x__0); if linked_2229 == nil { tmp9 = ifn_2230.Invoke_O__O(arg_2231) } else { tmp9 = linked_2229.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2228, arg_2231) }
//line :622:1
	var tmp10 any = tmp9; var tmp11 *jrt.String


	if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0)) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_17); var tmp13 any; var root_2232 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2236 any; var root_2237 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = A_arbace_cpp_abi_A_const_269.GetRawRoot__O(); var arg_2241 any = A_arbace_cpp_abi_A_const_219.Invoke_O__O(x__0); if linked_2238 == nil { arg_2236 = ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { arg_2236 = linked_2238.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) }; if linked_2233 == nil { tmp13 = ifn_2234.Invoke_O_O__O(arg_2235, arg_2236) } else { tmp13 = linked_2233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2232, arg_2235, arg_2236) }; tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil)) } else { tmp11 = nil }
//line :622:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11.Ref())).Ref()
}



func A_arbace_cpp_abi_mangle_dt_expr_A_New() *A_arbace_cpp_abi_mangle_dt_expr_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_dt_expr_A{}; t.Ctor(); return t }
//line :627:1
func (t *A_arbace_cpp_abi_mangle_dt_expr_A) Ctor() {}
//line :627:1
func (t *A_arbace_cpp_abi_mangle_dt_expr_A) Invoke_O_O__O(self, x__0 any) any { var G__677000264__2_ any = A_arbace_cpp_abi_A_const_270.Invoke_O__O(x__0); switch




	lang.Util_Hash_O__I_NoInit(G__677000264__2_) >> 10 & 31 { case 0: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_271) {


		var root_2243 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2243, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0); if linked_2244 == nil { return ifn_2245.Invoke_O__O(arg_2246) } else { return linked_2244.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2243, lang.RT_LongCast_O__J_NoInit(arg_2246)) } }
//line :632:1
	case 3: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_272) {











		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any = A_arbace_cpp_abi_A_const_273.Invoke_O__O(x__0); var tmp3 any; var root_2247 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = A_arbace_cpp_abi_A_const_241.Invoke_O__O(x__0); if linked_2248 == nil { tmp3 = ifn_2249.Invoke_O__O(arg_2250) } else { tmp3 = linked_2248.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2247, arg_2250) }; var tmp4 any = tmp3; var tmp5 any; var root_2251 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2251, A_arbace_cpp_abi_mangle_dt_expr_A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any; var root_2255 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_2256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2255, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2257 lang.IFn; if linked_2256 == nil { ifn_2257 = lang.IFn_Cast(root_2255) } else { ifn_2257 = nil }; var arg_2258 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2256 == nil { arg_2254 = ifn_2257.Invoke_O__O(arg_2258) } else { arg_2254 = linked_2256.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2255, arg_2258) }; if linked_2252 == nil { tmp5 = ifn_2253.Invoke_O__O(arg_2254) } else { tmp5 = linked_2252.(*A_arbace_cpp_abi_mangle_dt_expr_A).Invoke_O_O__O(root_2251, arg_2254) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5)).Ref() }
//line :632:1
	case 4: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_275) {



		var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_119, nil); var tmp7 any; var root_2259 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2260 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2259, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2261 lang.IFn; if linked_2260 == nil { ifn_2261 = lang.IFn_Cast(root_2259) } else { ifn_2261 = nil }; var arg_2262 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0); if linked_2260 == nil { tmp7 = ifn_2261.Invoke_O__O(arg_2262) } else { tmp7 = linked_2260.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2259, lang.RT_LongCast_O__J_NoInit(arg_2262)) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() }
//line :632:1
	case 7: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_276) {

		var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_120, nil, nil, nil, Lit_100); var tmp9 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_27.Invoke_O__O(x__0)) { tmp9 = Lit_11 } else { tmp9 = nil }; var tmp10 any = tmp9.Ref(); var tmp11 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_26.Invoke_O__O(x__0)) { tmp11 = Lit_12 } else { tmp11 = nil }; var tmp12 any = tmp11.Ref(); var tmp13 *jrt.Long; if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0))) { tmp13 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_243.Invoke_O__O(x__0)))) } else { tmp13 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, tmp12, tmp13.Ref(), nil)).Ref() }
//line :632:1
	case 9: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_277) {









		var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil, nil, Lit_17); var tmp15 any; var root_2273 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = A_arbace_cpp_abi_A_const_241.Invoke_O__O(x__0); if linked_2274 == nil { tmp15 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp15 = linked_2274.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2273, arg_2276) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, A_arbace_cpp_abi_A_const_27.Invoke_O__O(x__0), nil)).Ref() }
//line :632:1
	case 16: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_278) {




		return A_arbace_cpp_abi_A_const_279.Invoke_O__O(x__0) }
//line :632:1
	case 19: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_280) {






		var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_106, nil, nil, Lit_17); var tmp17 any; var root_2277 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, A_arbace_cpp_abi_mangle_dt_expr_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = A_arbace_cpp_abi_A_const_281.Invoke_O__O(x__0); if linked_2278 == nil { tmp17 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp17 = linked_2278.(*A_arbace_cpp_abi_mangle_dt_expr_A).Invoke_O_O__O(root_2277, arg_2280) }; var tmp18 any = tmp17; var tmp19 any; var root_2281 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2285 any; var root_2286 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var arg_2290 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2287 == nil { arg_2285 = ifn_2288.Invoke_O_O__O(arg_2289, arg_2290) } else { arg_2285 = linked_2287.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2286, arg_2289, arg_2290) }; if linked_2282 == nil { tmp19 = ifn_2283.Invoke_O_O__O(arg_2284, arg_2285) } else { tmp19 = linked_2282.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2281, arg_2284, arg_2285) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp18, tmp19, nil)).Ref() }
//line :632:1
	case 22: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_282) {
		var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp21 any = A_arbace_cpp_abi_A_const_260; return tmp20.Invoke_O_O_O__O(tmp21, Lit_121, A_arbace_cpp_abi_A_const_283.Invoke_O__O(x__0)) }
//line :632:1
	case 24: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_284) {










		var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp23 any = A_arbace_cpp_abi_A_const_273.Invoke_O__O(x__0); var tmp24 any; var root_2297 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = A_arbace_cpp_abi_A_const_241.Invoke_O__O(x__0); if linked_2298 == nil { tmp24 = ifn_2299.Invoke_O__O(arg_2300) } else { tmp24 = linked_2298.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2297, arg_2300) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24)).Ref() }
//line :632:1
	case 25: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_285) { var n__3 int32 = lang.RT_Count_O__I_NoInit(A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0))













		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_286.Invoke_O__O(x__0)) {
			var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_122, nil, nil, Lit_17); var tmp26 any; var root_2301 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = A_arbace_cpp_abi_A_const_241.Invoke_O__O(x__0); if linked_2302 == nil { tmp26 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp26 = linked_2302.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2301, arg_2304) }; var tmp27 any = tmp26; var tmp28 any; var root_2305 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2305, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2309 any; var root_2310 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var arg_2314 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2311 == nil { arg_2309 = ifn_2312.Invoke_O_O__O(arg_2313, arg_2314) } else { arg_2309 = linked_2311.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2310, arg_2313, arg_2314) }; if linked_2306 == nil { tmp28 = ifn_2307.Invoke_O_O__O(arg_2308, arg_2309) } else { tmp28 = linked_2306.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2305, arg_2308, arg_2309) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp27, tmp28, nil)).Ref() } else {
				var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil, nil, nil, nil); var tmp30 any; var root_2315 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = A_arbace_cpp_abi_A_const_241.Invoke_O__O(x__0); if linked_2316 == nil { tmp30 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp30 = linked_2316.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2315, arg_2318) }; var tmp31 any = tmp30; var tmp32 *jrt.String; var tmp33 any; var root_2319 any = A_arbace_cpp_abi_A_const_141.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = A_arbace_cpp_abi_A_const_143; var arg_2323 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_2320 == nil { tmp33 = ifn_2321.Invoke_O_O__O(arg_2322, arg_2323) } else { tmp33 = linked_2320.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2319, arg_2322, arg_2323) }; if jrt.J2g_Truth(tmp33) { tmp32 = Lit_100 } else { tmp32 = nil }; var tmp34 any = tmp32.Ref(); var tmp35 any; var root_2324 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2324, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2328 any; var root_2329 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var arg_2333 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2330 == nil { arg_2328 = ifn_2331.Invoke_O_O__O(arg_2332, arg_2333) } else { arg_2328 = linked_2330.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2329, arg_2332, arg_2333) }; if linked_2325 == nil { tmp35 = ifn_2326.Invoke_O_O__O(arg_2327, arg_2328) } else { tmp35 = linked_2325.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2324, arg_2327, arg_2328) }; var tmp36 any = tmp35; var tmp37 *jrt.String; var tmp38 any; var root_2334 any = A_arbace_cpp_abi_A_const_141.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = A_arbace_cpp_abi_A_const_143; var arg_2338 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_2335 == nil { tmp38 = ifn_2336.Invoke_O_O__O(arg_2337, arg_2338) } else { tmp38 = linked_2335.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2334, arg_2337, arg_2338) }; if jrt.J2g_Truth(tmp38) { tmp37 = Lit_17 } else { tmp37 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, nil, tmp31, tmp34, tmp36, tmp37.Ref())).Ref() } }
//line :632:1
	case 28: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_287) {








		var tmp39 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp40 any = A_arbace_cpp_abi_A_const_273.Invoke_O__O(x__0); var tmp41 any; var root_2339 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2343 any; var root_2344 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var arg_2348 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__0); if linked_2345 == nil { arg_2343 = ifn_2346.Invoke_O_O__O(arg_2347, arg_2348) } else { arg_2343 = linked_2345.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2344, arg_2347, arg_2348) }; if linked_2340 == nil { tmp41 = ifn_2341.Invoke_O_O__O(arg_2342, arg_2343) } else { tmp41 = linked_2340.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2339, arg_2342, arg_2343) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp39, jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41)).Ref() }
//line :632:1
	case 29: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_288) {







		var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp43 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_289.Invoke_O__O(x__0)) { tmp43 = Lit_123 } else { var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp45 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_290.Invoke_O__O(x__0)) { tmp45 = Lit_124 } else { tmp45 = Lit_125 }; var tmp46 any = tmp45.Ref(); var tmp47 any; var root_2349 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, A_arbace_cpp_abi_mangle_dt_expr_A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = A_arbace_cpp_abi_A_const_250.Invoke_O__O(x__0); if linked_2350 == nil { tmp47 = ifn_2351.Invoke_O__O(arg_2352) } else { tmp47 = linked_2350.(*A_arbace_cpp_abi_mangle_dt_expr_A).Invoke_O_O__O(root_2349, arg_2352) }; tmp43 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp44, jrt.RefArrayOf(jrt.Object_class, tmp46, tmp47)) }; var tmp48 any = tmp43.Ref(); var tmp49 any; var root_2353 any = A_arbace_cpp_abi_A_const_291.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, A_arbace_cpp_abi_dt_unresolved_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = x__0; if linked_2354 == nil { tmp49 = ifn_2355.Invoke_O__O(arg_2356) } else { tmp49 = linked_2354.(*A_arbace_cpp_abi_dt_unresolved_A).Invoke_O_O__O(root_2353, arg_2356) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp42, jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49)).Ref() }
//line :632:1
	case 30: if any(G__677000264__2_) == any(A_arbace_cpp_abi_A_const_127) {





		var root_2357 any = A_arbace_cpp_abi_A_const_291.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, A_arbace_cpp_abi_dt_unresolved_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = x__0; if linked_2358 == nil { return ifn_2359.Invoke_O__O(arg_2360) } else { return linked_2358.(*A_arbace_cpp_abi_dt_unresolved_A).Invoke_O_O__O(root_2357, arg_2360) } }
//line :632:1
	default:}; var tmp50 lang.IFn =
















	lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp51 any = A_arbace_cpp_abi_A_const_260; return tmp50.Invoke_O_O_O__O(tmp51, Lit_121, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(x__0)) }

func A_arbace_cpp_abi_dt_standin_QMARK__A_New() *A_arbace_cpp_abi_dt_standin_QMARK__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_dt_standin_QMARK__A{}; t.Ctor(); return t }
//line :651:1
func (t *A_arbace_cpp_abi_dt_standin_QMARK__A) Ctor() {}
//line :651:1
func (t *A_arbace_cpp_abi_dt_standin_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_cpp_abi_A_const_292; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0)); if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var tmp2 any; var root_2361 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = t__0; var arg_2365 any = A_arbace_cpp_abi_A_const_293; if linked_2362 == nil { tmp2 = ifn_2363.Invoke_O_O__O(arg_2364, arg_2365) } else { tmp2 = linked_2362.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2361, arg_2364, arg_2365) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_15, tmp2); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp3 any; var root_2366 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2368 lang.IFn; if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = t__0; var arg_2370 any = A_arbace_cpp_abi_A_const_294; if linked_2367 == nil { tmp3 = ifn_2368.Invoke_O_O__O(arg_2369, arg_2370) } else { tmp3 = linked_2367.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2366, arg_2369, arg_2370) }; and__1927000168__auto____4 = lang.Util_Equiv_J_O__Z_NoInit(-1, tmp3); if and__1927000168__auto____4 { var root_2371 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2371, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2373 lang.IFn; if linked_2372 == nil { ifn_2373 = lang.IFn_Cast(root_2371) } else { ifn_2373 = nil }; var arg_2374 any = t__0; var arg_2375 any = A_arbace_cpp_abi_A_const_295; if linked_2372 == nil { return ifn_2373.Invoke_O_O__O(arg_2374, arg_2375) } else { return linked_2372.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2371, arg_2374, arg_2375) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_cpp_abi_template_arg_A_New() *A_arbace_cpp_abi_template_arg_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_template_arg_A{}; t.Ctor(); return t }
//line :653:1
func (t *A_arbace_cpp_abi_template_arg_A) Ctor() {}
//line :653:1
func (t *A_arbace_cpp_abi_template_arg_A) Invoke_O_O__O(self, a__0 any) any {


	var tmp1 any = A_arbace_cpp_abi_A_const_246; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0)) {

		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil, Lit_17); var tmp3 any; var root_2376 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2376, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(a__0); if linked_2377 == nil { tmp3 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp3 = linked_2377.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2376, lang.RT_LongCast_O__J_NoInit(arg_2379)) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :656:1
			var tmp4 any = A_arbace_cpp_abi_A_const_247; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0)) {


				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil, Lit_17); var tmp6 any; var root_2380 any = A_arbace_cpp_abi_A_const_263.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, A_arbace_cpp_abi_mangle_expr_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = a__0; if linked_2381 == nil { tmp6 = ifn_2382.Invoke_O__O(arg_2383) } else { tmp6 = linked_2381.(*A_arbace_cpp_abi_mangle_expr_A).Invoke_O_O__O(root_2380, arg_2383) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil)).Ref() } else {
//line :656:1
					var tmp7 any; var and__1927000168__auto____2 any; var root_2384 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2386 lang.IFn



					if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = a__0; var arg_2388 any = A_arbace_cpp_abi_A_const_255; if linked_2385 == nil { and__1927000168__auto____2 = ifn_2386.Invoke_O_O__O(arg_2387, arg_2388) } else { and__1927000168__auto____2 = linked_2385.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2384, arg_2387, arg_2388) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_2389 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0); if linked_2390 == nil { tmp7 = ifn_2391.Invoke_O__O(arg_2392) } else { tmp7 = linked_2390.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2389, arg_2392) } } else { tmp7 = and__1927000168__auto____2 }
//line :656:1
					if jrt.J2g_Truth(tmp7) {



						var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_196, nil, Lit_17); var tmp9 any; var root_2393 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2397 any; var root_2398 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = A_arbace_cpp_abi_A_const_269.GetRawRoot__O(); var arg_2402 any = A_arbace_cpp_abi_A_const_255.Invoke_O__O(a__0); if linked_2399 == nil { arg_2397 = ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { arg_2397 = linked_2399.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) }; if linked_2394 == nil { tmp9 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { tmp9 = linked_2394.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :656:1
							var tmp10 any; var root_2403 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2405 lang.IFn





							if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = a__0; var arg_2407 any = A_arbace_cpp_abi_A_const_296; if linked_2404 == nil { tmp10 = ifn_2405.Invoke_O_O__O(arg_2406, arg_2407) } else { tmp10 = linked_2404.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2403, arg_2406, arg_2407) }
//line :656:1
							if jrt.J2g_Truth(tmp10) {





								if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_297.Invoke_O__O(a__0)) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil, Lit_197); var tmp12 any; var root_2408 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(a__0); if linked_2409 == nil { tmp12 = ifn_2410.Invoke_O__O(arg_2411) } else { tmp12 = linked_2409.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2408, arg_2411) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } else { if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_21.Invoke_O__O(a__0)) {
									return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_cpp_abi_A_const_298.Invoke_O__O(a__0), nil)).Ref() } else {
//line :662:1
										if A_arbace_cpp_abi_A_const_118 != nil {

											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_198, nil, Lit_199), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_cpp_abi_A_const_298.Invoke_O__O(a__0), nil)).Ref() } else {
//line :662:1
												return nil } } } } else {
//line :656:1
													var tmp13 any; var and__1927000168__auto____2_2 any; var root_2412 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2414 lang.IFn









													if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = a__0; var arg_2416 any = A_arbace_cpp_abi_A_const_215; if linked_2413 == nil { and__1927000168__auto____2_2 = ifn_2414.Invoke_O_O__O(arg_2415, arg_2416) } else { and__1927000168__auto____2_2 = linked_2413.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2412, arg_2415, arg_2416) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0), nil)).Ref() } else { tmp13 = and__1927000168__auto____2_2 }
//line :656:1
													if jrt.J2g_Truth(tmp13) {









														var tmp14 any; var root_2417 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(a__0); if linked_2418 == nil { tmp14 = ifn_2419.Invoke_O__O(arg_2420) } else { tmp14 = linked_2418.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2417, arg_2420) }; if jrt.J2g_Truth(tmp14) {
															var root_2421 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = Lit_24; var arg_2425 any = A_arbace_cpp_abi_A_const_215.Invoke_O__O(a__0); var arg_2426 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(a__0); if linked_2422 == nil { return ifn_2423.Invoke_O_O_O__O(arg_2424, arg_2425, arg_2426) } else { return linked_2422.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_2421, arg_2424, arg_2425, arg_2426) } } else {
																var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_17); var tmp16 any; var root_2427 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any; var root_2433 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(a__0); if linked_2434 == nil { arg_2430 = ifn_2435.Invoke_O__O(arg_2436) } else { arg_2430 = linked_2434.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_2433, arg_2436) }; var arg_2431 any = A_arbace_cpp_abi_A_const_215.Invoke_O__O(a__0); var arg_2432 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(a__0); if linked_2428 == nil { tmp16 = ifn_2429.Invoke_O_O_O__O(arg_2430, arg_2431, arg_2432) } else { tmp16 = linked_2428.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_2427, arg_2430, arg_2431, arg_2432) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil)).Ref() } } else {
//line :656:1
																	var tmp17 any = A_arbace_cpp_abi_A_const_239; if lang.Util_Equiv_O_O__Z_NoInit(tmp17, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0)) {












																		var root_2437 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2439 lang.IFn; if linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, a__0); var arg_2441 any; var fnbody__2447 any = A_arbace_cpp_abi_template_arg_fn__677000267_A_New_O(a__0); var tmp18 *jrt.Class; var fncls__2446 *jrt.Class = A_arbace_cpp_abi_template_arg_fn__677000267_A_fn_class; if fncls__2446 == nil { var fncls__2446d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_200, false, fnbody__2447); A_arbace_cpp_abi_template_arg_fn__677000267_A_fn_class = fncls__2446d; tmp18 = fncls__2446d } else { tmp18 = fncls__2446 }; arg_2441 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2447, tmp18, nil); if linked_2438 == nil { return ifn_2439.Invoke_O_O__O(arg_2440, arg_2441) } else { return linked_2438.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2437, arg_2440, arg_2441) } } else {
//line :656:1
																			var tmp19 any = A_arbace_cpp_abi_A_const_299; if lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_cpp_abi_A_const_16.Invoke_O__O(a__0)) {














																				var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp21 any = A_arbace_cpp_abi_A_const_260; return tmp20.Invoke_O_O_O__O(tmp21, Lit_201, A_arbace_cpp_abi_A_const_127.Invoke_O__O(a__0)) } else {
//line :656:1
																					var tmp22 any; var root_2454 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2456 lang.IFn















																					if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = a__0; var arg_2458 any = A_arbace_cpp_abi_A_const_300; if linked_2455 == nil { tmp22 = ifn_2456.Invoke_O_O__O(arg_2457, arg_2458) } else { tmp22 = linked_2455.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2454, arg_2457, arg_2458) }
//line :656:1
																					if jrt.J2g_Truth(tmp22) { var v__2 any = A_arbace_cpp_abi_A_const_300.Invoke_O__O(a__0); var t__3 any; var root_2459 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, A_arbace_cpp_abi_unq_A_fn_class); var ifn_2461 lang.IFn















																						if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(a__0); if linked_2460 == nil { t__3 = ifn_2461.Invoke_O__O(arg_2462) } else { t__3 = linked_2460.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_2459, arg_2462) }
																						var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil, nil, Lit_17); var tmp24 any; var root_2463 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = t__3; if linked_2464 == nil { tmp24 = ifn_2465.Invoke_O__O(arg_2466) } else { tmp24 = linked_2464.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2463, arg_2466) }; var tmp25 any = tmp24; var tmp26 any; var tmp27 any = A_arbace_cpp_abi_A_const_165; var tmp28 any; var root_2467 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, A_arbace_cpp_abi_bn_A_fn_class); var ifn_2469 lang.IFn
																						if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = t__3; if linked_2468 == nil { tmp28 = ifn_2469.Invoke_O__O(arg_2470) } else { tmp28 = linked_2468.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_2467, arg_2470) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp27, tmp28) { var tmp29 any; var and__1927000168__auto____8 any = v__2; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2471 any = A_arbace_cpp_abi_A_const_141.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2471, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = A_arbace_cpp_abi_A_const_68; var arg_2475 any = v__2; if linked_2472 == nil { and__1927000168__auto____9 = ifn_2473.Invoke_O_O__O(arg_2474, arg_2475) } else { and__1927000168__auto____9 = linked_2472.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2471, arg_2474, arg_2475) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_2476 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any; var root_2480 any = A_arbace_cpp_abi_A_const_301.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = v__2; if linked_2481 == nil { arg_2479 = ifn_2482.Invoke_O__O(arg_2483) } else { arg_2479 = linked_2481.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_2480, arg_2483) }; if linked_2477 == nil { tmp29 = ifn_2478.Invoke_O__O(arg_2479) } else { tmp29 = linked_2477.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2476, arg_2479) } } else { tmp29 = and__1927000168__auto____9 } } else { tmp29 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp29) { tmp26 = Lit_202 } else { tmp26 = Lit_203 } } else { var tmp30 any; var and__1927000168__auto____8_2 bool = lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__2))


																							if and__1927000168__auto____8_2 { var root_2484 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = A_arbace_cpp_abi_A_const_201.GetRawRoot__O(); var arg_2488 any; var root_2489 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, A_arbace_cpp_abi_bn_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any; var root_2493 any = A_arbace_cpp_abi_A_const_72.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, A_arbace_cpp_abi_underlying_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = t__3; if linked_2494 == nil { arg_2492 = ifn_2495.Invoke_O__O(arg_2496) } else { arg_2492 = linked_2494.(*A_arbace_cpp_abi_underlying_A).Invoke_O_O__O(root_2493, arg_2496) }; if linked_2490 == nil { arg_2488 = ifn_2491.Invoke_O__O(arg_2492) } else { arg_2488 = linked_2490.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_2489, arg_2492) }; if linked_2485 == nil { tmp30 = ifn_2486.Invoke_O_O__O(arg_2487, arg_2488) } else { tmp30 = linked_2485.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2484, arg_2487, arg_2488) } } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_2).Ref() }
//line :674:1
																							if jrt.J2g_Truth(tmp30) {


																								tmp26 = jrt.Long_ToUnsignedString_J__String_NoInit(lang.RT_LongCast_O__J_NoInit(v__2)).Ref() } else {
//line :674:1
																									if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__2)) {



																										tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(v__2))).Ref())).Ref() } else {
//line :674:1
																											if A_arbace_cpp_abi_A_const_118 != nil { tmp26 = v__2 } else { tmp26 = nil } } } }
//line :673:1
																						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, tmp26, nil)).Ref() } else {
//line :656:1
																							var tmp31 any; var root_2497 any = A_arbace_cpp_abi_A_const_36.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2499 lang.IFn
























																							if linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any = a__0; var arg_2501 any = A_arbace_cpp_abi_A_const_16; if linked_2498 == nil { tmp31 = ifn_2499.Invoke_O_O__O(arg_2500, arg_2501) } else { tmp31 = linked_2498.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2497, arg_2500, arg_2501) }
//line :656:1
																							if jrt.J2g_Truth(tmp31) {
























																								var root_2502 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = a__0; if linked_2503 == nil { return ifn_2504.Invoke_O__O(arg_2505) } else { return linked_2503.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2502, arg_2505) } } else {
//line :656:1
																									if A_arbace_cpp_abi_A_const_118 != nil {

























																										var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp33 any = A_arbace_cpp_abi_A_const_260; return tmp32.Invoke_O_O_O__O(tmp33, Lit_204, lang.IFn_Cast(A_arbace_cpp_abi_A_const_64.GetRawRoot__O()).Invoke_O__O(a__0)) } else {
//line :656:1
																											return nil
																										}
																								}
																						}
																				}
																		}
																}
												}
						}
				}
		}
}

func A_arbace_cpp_abi_template_arg_fn__677000267_A_New_O(p0 any) *A_arbace_cpp_abi_template_arg_fn__677000267_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_template_arg_fn__677000267_A{}; t.Ctor_O(p0); return t }
//line :669:1
func (t *A_arbace_cpp_abi_template_arg_fn__677000267_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :669:1
func (t *A_arbace_cpp_abi_template_arg_fn__677000267_A) Invoke_O__O(self any) any { var root_2442 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2442, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2444 lang.IFn; if linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(t.F_a); if linked_2443 == nil { return ifn_2444.Invoke_O__O(arg_2445) } else { return linked_2443.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2442, lang.RT_LongCast_O__J_NoInit(arg_2445)) } }














func A_arbace_cpp_abi_template_args_A_New() *A_arbace_cpp_abi_template_args_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_template_args_A{}; t.Ctor(); return t }
//line :684:1
func (t *A_arbace_cpp_abi_template_args_A) Ctor() {}
//line :684:1
func (t *A_arbace_cpp_abi_template_args_A) Invoke_O_O__O(self, args__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_17); var tmp2 any; var root_2516 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2520 any; var root_2521 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = A_arbace_cpp_abi_A_const_269.GetRawRoot__O(); var arg_2525 any = args__0; if linked_2522 == nil { arg_2520 = ifn_2523.Invoke_O_O__O(arg_2524, arg_2525) } else { arg_2520 = linked_2522.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2521, arg_2524, arg_2525) }; if linked_2517 == nil { tmp2 = ifn_2518.Invoke_O_O__O(arg_2519, arg_2520) } else { tmp2 = linked_2517.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2516, arg_2519, arg_2520) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }

func A_arbace_cpp_abi_cvq_A_New() *A_arbace_cpp_abi_cvq_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_cvq_A{}; t.Ctor(); return t }
//line :686:1
func (t *A_arbace_cpp_abi_cvq_A) Ctor() {}
//line :686:1
func (t *A_arbace_cpp_abi_cvq_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_27.Invoke_O__O(t__0)) { tmp2 = Lit_11 } else { tmp2 = nil }; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_26.Invoke_O__O(t__0)) { tmp4 = Lit_12 } else { tmp4 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }

func A_arbace_cpp_abi_skey_A_New() *A_arbace_cpp_abi_skey_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_skey_A{}; t.Ctor(); return t }
//line :688:1
func (t *A_arbace_cpp_abi_skey_A) Ctor() {}
//line :688:1
func (t *A_arbace_cpp_abi_skey_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_2526 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2528 lang.IFn
	if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = t__0; if linked_2527 == nil { and__1927000168__auto____2 = ifn_2528.Invoke_O__O(arg_2529) } else { and__1927000168__auto____2 = linked_2527.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2526, arg_2529) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_abi_A_const_258; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__0))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :692:1
	if jrt.J2g_Truth(tmp1) { var tmp3 any = A_arbace_cpp_abi_A_const_16; var tmp4 any = A_arbace_cpp_abi_A_const_258; var tmp5 any = A_arbace_cpp_abi_A_const_243; var G__677000272__2_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, A_arbace_cpp_abi_A_const_243.Invoke_O__O(t__0))); var G__677000272__3_ any
		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_26.Invoke_O__O(t__0)) { var root_2530 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = G__677000272__2_; var arg_2534 any = A_arbace_cpp_abi_A_const_26; var arg_2535 any = jrt.Boolean_TRUE.Ref(); if linked_2531 == nil { G__677000272__3_ = ifn_2532.Invoke_O_O_O__O(arg_2533, arg_2534, arg_2535) } else { G__677000272__3_ = linked_2531.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2530, arg_2533, arg_2534, arg_2535) } } else { G__677000272__3_ = G__677000272__2_ }; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_27.Invoke_O__O(t__0)) { var root_2536 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = G__677000272__3_; var arg_2540 any = A_arbace_cpp_abi_A_const_27; var arg_2541 any = jrt.Boolean_TRUE.Ref(); if linked_2537 == nil { return ifn_2538.Invoke_O_O_O__O(arg_2539, arg_2540, arg_2541) } else { return linked_2537.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2536, arg_2539, arg_2540, arg_2541) } } else { return G__677000272__3_ } } else {
//line :692:1
			var tmp6 any; var root_2542 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2544 lang.IFn

			if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = t__0; if linked_2543 == nil { tmp6 = ifn_2544.Invoke_O__O(arg_2545) } else { tmp6 = linked_2543.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2542, arg_2545) }
//line :692:1
			if jrt.J2g_Truth(tmp6) {

				var root_2546 any = A_arbace_cpp_abi_A_const_111.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2550 any; var root_2551 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any; var fnbody__2561 any = A_arbace_cpp_abi_skey_fn__677000274_A_New(); var tmp7 *jrt.Class; var fncls__2560 *jrt.Class = A_arbace_cpp_abi_skey_fn__677000274_A_fn_class; if fncls__2560 == nil { var fncls__2560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_cpp_abi_skey_fn__677000274_A_fn_class = fncls__2560d; tmp7 = fncls__2560d } else { tmp7 = fncls__2560 }; arg_2554 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2561, tmp7, nil); var arg_2555 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(t__0, A_arbace_cpp_abi_A_const_252, A_arbace_cpp_abi_A_const_256); if linked_2552 == nil { arg_2550 = ifn_2553.Invoke_O_O__O(arg_2554, arg_2555) } else { arg_2550 = linked_2552.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2551, arg_2554, arg_2555) }; if linked_2547 == nil { return ifn_2548.Invoke_O_O__O(arg_2549, arg_2550) } else { return linked_2547.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2546, arg_2549, arg_2550) } } else {
//line :692:1
					var tmp8 any; var root_2568 any = A_arbace_cpp_abi_A_const_303.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2570 lang.IFn


					if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = t__0; if linked_2569 == nil { tmp8 = ifn_2570.Invoke_O__O(arg_2571) } else { tmp8 = linked_2569.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2568, arg_2571) }
//line :692:1
					if jrt.J2g_Truth(tmp8) {


						var root_2572 any = A_arbace_cpp_abi_A_const_139.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = A_arbace_cpp_abi_A_const_302.GetRawRoot__O(); var arg_2576 any = t__0; if linked_2573 == nil { return ifn_2574.Invoke_O_O__O(arg_2575, arg_2576) } else { return linked_2573.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2572, arg_2575, arg_2576) } } else {
//line :692:1
							if A_arbace_cpp_abi_A_const_118 != nil { return t__0 } else { return nil
							} } } } }
func A_arbace_cpp_abi_skey_fn__677000274_A_New() *A_arbace_cpp_abi_skey_fn__677000274_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_skey_fn__677000274_A{}; t.Ctor(); return t }
//line :694:1
func (t *A_arbace_cpp_abi_skey_fn__677000274_A) Ctor() {}
//line :694:1
func (t *A_arbace_cpp_abi_skey_fn__677000274_A) Invoke_O_O__O(self, p__677000273__1 any) any { var vec__677000275__2 any = p__677000273__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_2556 any = A_arbace_cpp_abi_A_const_302.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, A_arbace_cpp_abi_skey_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = v__4; if linked_2557 == nil { tmp1 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp1 = linked_2557.(*A_arbace_cpp_abi_skey_A).Invoke_O_O__O(root_2556, arg_2559) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_cpp_abi_mangle_type_STAR__A_New() *A_arbace_cpp_abi_mangle_type_STAR__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__A{}; t.Ctor(); return t }
//line :698:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__A) Ctor() {}
//line :698:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__A) Invoke_O_O__O(self, t__0 any) any { var q__2 any; var root_2577 any = A_arbace_cpp_abi_A_const_304.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, A_arbace_cpp_abi_cvq_A_fn_class); var ifn_2579 lang.IFn; if
											linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = t__0; if linked_2578 == nil { q__2 = ifn_2579.Invoke_O__O(arg_2580) } else { q__2 = linked_2578.(*A_arbace_cpp_abi_cvq_A).Invoke_O_O__O(root_2577, arg_2580) }; var bare__3 any; var root_2581 any = /*line :698:1*/A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, A_arbace_cpp_abi_unq_A_fn_class); var ifn_2583 lang.IFn; if

	linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = t__0; if linked_2582 == nil { bare__3 = ifn_2583.Invoke_O__O(arg_2584) } else { bare__3 = linked_2582.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_2581, arg_2584) }; var sk__4 any; var root_2585 any = /*line :698:1*/A_arbace_cpp_abi_A_const_302.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, A_arbace_cpp_abi_skey_A_fn_class); var ifn_2587 lang.IFn; if


	linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = bare__3; if linked_2586 == nil { sk__4 = ifn_2587.Invoke_O__O(arg_2588) } else { sk__4 = linked_2586.(*A_arbace_cpp_abi_skey_A).Invoke_O_O__O(root_2585, arg_2588) }; var inner__5 any; var fnbody__2863 any = /*line :698:1*/A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_New_O_O(bare__3, sk__4); var tmp1 *jrt.Class; var fncls__2862 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_fn_class; if



	fncls__2862 == nil { var fncls__2862d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__2863); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_fn_class = fncls__2862d; tmp1 = fncls__2862d } else { tmp1 = fncls__2862 }; inner__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2863, tmp1, nil); if
































	lang.Util_Equiv_O_O__Z_NoInit(Lit_24, q__2) {
		return lang.IFn_Cast(inner__5).Invoke__O() } else {
//line :735:1
			var k__6 any; var tmp2 any = A_arbace_cpp_abi_A_const_241; var tmp3 any; var root_2872 any = A_arbace_cpp_abi_A_const_302.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, A_arbace_cpp_abi_skey_A_fn_class); var ifn_2874 lang.IFn

			if linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any = t__0; if linked_2873 == nil { tmp3 = ifn_2874.Invoke_O__O(arg_2875) } else { tmp3 = linked_2873.(*A_arbace_cpp_abi_skey_A).Invoke_O_O__O(root_2872, arg_2875) }
//line :735:1
			k__6 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var i__7 int32; var tmp4 any; var root_2864 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_2865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2864, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2866 lang.IFn

			if linked_2865 == nil { ifn_2866 = lang.IFn_Cast(root_2864) } else { ifn_2866 = nil }; var arg_2867 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_2865 == nil { tmp4 = ifn_2866.Invoke_O__O(arg_2867) } else { tmp4 = linked_2865.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2864, arg_2867) }; i__7 = jrt.List_Cast(tmp4).IndexOf_O__I(k__6)
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__7)) { var s__8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, q__2, lang.IFn_Cast(inner__5).Invoke__O())).Ref(); var root_2876 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2878 lang.IFn
				if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_2880 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var arg_2881 any = k__6; if linked_2877 == nil { ifn_2878.Invoke_O_O_O__O(arg_2879, arg_2880, arg_2881) } else { linked_2877.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2876, arg_2879, arg_2880, arg_2881) }
//line :738:1
				return s__8 } else {

					var root_2868 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_2869 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2868, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_2870 lang.IFn; if linked_2869 == nil { ifn_2870 = lang.IFn_Cast(root_2868) } else { ifn_2870 = nil }; var arg_2871 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__7).Ref(); if linked_2869 == nil { return ifn_2870.Invoke_O__O(arg_2871) } else { return linked_2869.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_2868, lang.RT_LongCast_O__J_NoInit(arg_2871)) } } } }
//line :702:1
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_New_O_O(p0, p1 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A{}; t.Ctor_O_O(p0, p1); return t }
//line :702:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A) Ctor_O_O(c__bare, c__sk any) { t.F_bare = c__bare; t.F_sk = c__sk }
//line :702:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A) Invoke_O__O(self any) any { var G__677000281__1_ any = A_arbace_cpp_abi_A_const_16.Invoke_O__O(t.F_bare); switch
												lang.Util_Hash_O__I_NoInit(G__677000281__1_) >> 0 & 127 { case 4: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_305) {


		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_306.Invoke_O__O(t.F_bare)) { return Lit_143 } else { return Lit_144 } }
//line :703:1
	case 9: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_22) {









		var root_2590 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2594 any; var fnbody__2600 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_New_O(t.F_bare); var tmp1 *jrt.Class; var fncls__2599 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_fn_class; if fncls__2599 == nil { var fncls__2599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, fnbody__2600); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_fn_class = fncls__2599d; tmp1 = fncls__2599d } else { tmp1 = fncls__2599 }; arg_2594 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2600, tmp1, nil); if linked_2591 == nil { return ifn_2592.Invoke_O_O__O(arg_2593, arg_2594) } else { return linked_2591.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2590, arg_2593, arg_2594) } }
//line :703:1
	case 14: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_57) {




		var root_2601 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2601, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2603 lang.IFn; if linked_2602 == nil { ifn_2603 = lang.IFn_Cast(root_2601) } else { ifn_2603 = nil }; var arg_2604 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2605 any; var fnbody__2611 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_New_O(t.F_bare); var tmp2 *jrt.Class; var fncls__2610 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_fn_class; if fncls__2610 == nil { var fncls__2610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__2611); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_fn_class = fncls__2610d; tmp2 = fncls__2610d } else { tmp2 = fncls__2610 }; arg_2605 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2611, tmp2, nil); if linked_2602 == nil { return ifn_2603.Invoke_O_O__O(arg_2604, arg_2605) } else { return linked_2602.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2601, arg_2604, arg_2605) } }
//line :703:1
	case 40: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_33) {





		var root_2612 any = A_arbace_cpp_abi_A_const_307.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, A_arbace_cpp_abi_mangle_named_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = t.F_bare; if linked_2613 == nil { return ifn_2614.Invoke_O__O(arg_2615) } else { return linked_2613.(*A_arbace_cpp_abi_mangle_named_A).Invoke_O_O__O(root_2612, arg_2615) } }
//line :703:1
	case 41: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_23) {










		var root_2616 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2620 any; var fnbody__2634 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_New_O(t.F_bare); var tmp3 *jrt.Class; var fncls__2633 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_fn_class; if fncls__2633 == nil { var fncls__2633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__2634); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_fn_class = fncls__2633d; tmp3 = fncls__2633d } else { tmp3 = fncls__2633 }; arg_2620 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2634, tmp3, nil); if linked_2617 == nil { return ifn_2618.Invoke_O_O__O(arg_2619, arg_2620) } else { return linked_2617.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2616, arg_2619, arg_2620) } }
//line :703:1
	case 51: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_308) {


















		var root_2635 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2639 any; var fnbody__2645 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_New_O(t.F_bare); var tmp4 *jrt.Class; var fncls__2644 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_fn_class; if fncls__2644 == nil { var fncls__2644d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__2645); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_fn_class = fncls__2644d; tmp4 = fncls__2644d } else { tmp4 = fncls__2644 }; arg_2639 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2645, tmp4, nil); if linked_2636 == nil { return ifn_2637.Invoke_O_O__O(arg_2638, arg_2639) } else { return linked_2636.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2635, arg_2638, arg_2639) } }
//line :703:1
	case 63: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_258) {

















		var root_2646 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var tmp5 any = A_arbace_cpp_abi_A_const_309; var tmp6 any = A_arbace_cpp_abi_A_const_68; var arg_2649 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, A_arbace_cpp_abi_A_const_243.Invoke_O__O(t.F_bare)); var arg_2650 any; var fnbody__2656 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_New_O(t.F_bare); var tmp7 *jrt.Class; var fncls__2655 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_fn_class; if fncls__2655 == nil { var fncls__2655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__2656); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_fn_class = fncls__2655d; tmp7 = fncls__2655d } else { tmp7 = fncls__2655 }; arg_2650 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2656, tmp7, nil); if linked_2647 == nil { return ifn_2648.Invoke_O_O__O(arg_2649, arg_2650) } else { return linked_2647.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2646, arg_2649, arg_2650) } }
//line :703:1
	case 71: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_21) {








		var root_2657 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2661 any; var fnbody__2667 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_New_O(t.F_bare); var tmp8 *jrt.Class; var fncls__2666 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_fn_class; if fncls__2666 == nil { var fncls__2666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__2667); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_fn_class = fncls__2666d; tmp8 = fncls__2666d } else { tmp8 = fncls__2666 }; arg_2661 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2667, tmp8, nil); if linked_2658 == nil { return ifn_2659.Invoke_O_O__O(arg_2660, arg_2661) } else { return linked_2658.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2657, arg_2660, arg_2661) } }
//line :703:1
	case 83: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_19) {







		var root_2668 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2672 any; var fnbody__2678 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_New_O(t.F_bare); var tmp9 *jrt.Class; var fncls__2677 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_fn_class; if fncls__2677 == nil { var fncls__2677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__2678); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_fn_class = fncls__2677d; tmp9 = fncls__2677d } else { tmp9 = fncls__2677 }; arg_2672 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2678, tmp9, nil); if linked_2669 == nil { return ifn_2670.Invoke_O_O__O(arg_2671, arg_2672) } else { return linked_2669.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2668, arg_2671, arg_2672) } }
//line :703:1
	case 92: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_35) {













		var root_2679 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2683 any; var fnbody__2707 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_New_O(t.F_bare); var tmp10 *jrt.Class; var fncls__2706 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_fn_class; if fncls__2706 == nil { var fncls__2706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, fnbody__2707); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_fn_class = fncls__2706d; tmp10 = fncls__2706d } else { tmp10 = fncls__2706 }; arg_2683 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2707, tmp10, nil); if linked_2680 == nil { return ifn_2681.Invoke_O_O__O(arg_2682, arg_2683) } else { return linked_2680.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2679, arg_2682, arg_2683) } }
//line :703:1
	case 93: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_292) {





















		var root_2708 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2712 any; var fnbody__2810 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_New_O(t.F_bare); var tmp11 *jrt.Class; var fncls__2809 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_fn_class; if fncls__2809 == nil { var fncls__2809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, fnbody__2810); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_fn_class = fncls__2809d; tmp11 = fncls__2809d } else { tmp11 = fncls__2809 }; arg_2712 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2810, tmp11, nil); if linked_2709 == nil { return ifn_2710.Invoke_O_O__O(arg_2711, arg_2712) } else { return linked_2709.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2708, arg_2711, arg_2712) } }
//line :703:1
	case 100: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_251) {





























		var root_2811 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2815 any; var fnbody__2833 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_New_O(t.F_bare); var tmp12 *jrt.Class; var fncls__2832 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_fn_class; if fncls__2832 == nil { var fncls__2832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__2833); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_fn_class = fncls__2832d; tmp12 = fncls__2832d } else { tmp12 = fncls__2832 }; arg_2815 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2833, tmp12, nil); if linked_2812 == nil { return ifn_2813.Invoke_O_O__O(arg_2814, arg_2815) } else { return linked_2812.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2811, arg_2814, arg_2815) } }
//line :703:1
	case 105: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_41) {











		var root_2834 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, t.F_sk); var arg_2838 any; var fnbody__2857 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_New_O(t.F_bare); var tmp13 *jrt.Class; var fncls__2856 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_fn_class; if fncls__2856 == nil { var fncls__2856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, fnbody__2857); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_fn_class = fncls__2856d; tmp13 = fncls__2856d } else { tmp13 = fncls__2856 }; arg_2838 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2857, tmp13, nil); if linked_2835 == nil { return ifn_2836.Invoke_O_O__O(arg_2837, arg_2838) } else { return linked_2835.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2834, arg_2837, arg_2838) } }
//line :703:1
	case 108: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_17) {
		return lang.IFn_Cast(A_arbace_cpp_abi_A_const_320.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_abi_A_const_18.Invoke_O__O(t.F_bare)) }
//line :703:1
	case 113: if any(G__677000281__1_) == any(A_arbace_cpp_abi_A_const_34) {






		var root_2858 any = A_arbace_cpp_abi_A_const_307.GetRawRoot__O(); var linked_2859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2858, A_arbace_cpp_abi_mangle_named_A_fn_class); var ifn_2860 lang.IFn; if linked_2859 == nil { ifn_2860 = lang.IFn_Cast(root_2858) } else { ifn_2860 = nil }; var arg_2861 any = t.F_bare; if linked_2859 == nil { return ifn_2860.Invoke_O__O(arg_2861) } else { return linked_2859.(*A_arbace_cpp_abi_mangle_named_A).Invoke_O_O__O(root_2858, arg_2861) } }
//line :703:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__677000281__1_))))) }




func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A{}; t.Ctor_O(p0); return t }
//line :708:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :708:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_156, nil); var tmp2 any; var root_2606 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2608 lang.IFn; if linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; var arg_2609 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t.F_bare); if linked_2607 == nil { tmp2 = ifn_2608.Invoke_O__O(arg_2609) } else { tmp2 = linked_2607.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2606, arg_2609) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }


func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A{}; t.Ctor_O(p0); return t }
//line :711:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :711:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_159, nil); var tmp2 any; var root_2673 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any = A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare); if linked_2674 == nil { tmp2 = ifn_2675.Invoke_O__O(arg_2676) } else { tmp2 = linked_2674.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2673, arg_2676) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A{}; t.Ctor_O(p0); return t }
//line :712:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :712:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil); var tmp2 any; var root_2662 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare); if linked_2663 == nil { tmp2 = ifn_2664.Invoke_O__O(arg_2665) } else { tmp2 = linked_2663.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2662, arg_2665) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :713:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp2 any; var root_2595 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare); if linked_2596 == nil { tmp2 = ifn_2597.Invoke_O__O(arg_2598) } else { tmp2 = linked_2596.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2595, arg_2598) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A{}; t.Ctor_O(p0); return t }
//line :714:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :714:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_157, nil, Lit_100, nil); var tmp2 any; var n__5 any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(t.F_bare); var tmp3 any; var root_2621 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = n__5; if linked_2622 == nil { tmp3 = ifn_2623.Invoke_O__O(arg_2624) } else { tmp3 = linked_2622.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2621, arg_2624) }; if jrt.J2g_Truth(tmp3) { var root_2625 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2625, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(n__5); if linked_2626 == nil { tmp2 = ifn_2627.Invoke_O__O(arg_2628) } else { tmp2 = linked_2626.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2625, lang.RT_LongCast_O__J_NoInit(arg_2628)) } } else { tmp2 = n__5 }; var tmp4 any = tmp2; var tmp5 any; var root_2629 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t.F_bare); if linked_2630 == nil { tmp5 = ifn_2631.Invoke_O__O(arg_2632) } else { tmp5 = linked_2630.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2629, arg_2632) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5)).Ref() }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A{}; t.Ctor_O(p0); return t }
//line :715:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :715:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_166, nil, nil); var tmp2 any; var root_2839 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2839, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var tmp3 any = A_arbace_cpp_abi_A_const_16; var tmp4 any = A_arbace_cpp_abi_A_const_33; var tmp5 any = A_arbace_cpp_abi_A_const_49; var arg_2842 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, A_arbace_cpp_abi_A_const_81.Invoke_O__O(t.F_bare))); if linked_2840 == nil { tmp2 = ifn_2841.Invoke_O__O(arg_2842) } else { tmp2 = linked_2840.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2839, arg_2842) }; var tmp6 any = tmp2; var tmp7 any; var tmp8 any = A_arbace_cpp_abi_A_const_35; var tmp9 *lang.Keyword = A_arbace_cpp_abi_A_const_16; if
													lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9.Invoke_O__O(A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare))) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 *jrt.String; var tmp12 *lang.Keyword = A_arbace_cpp_abi_A_const_319; if jrt.J2g_Truth(tmp12.Invoke_O__O(A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare))) { tmp11 = Lit_12 } else { tmp11 = nil }; var tmp13 any = tmp11.Ref(); var tmp14 any; var root_2843 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any; var root_2847 any = A_arbace_cpp_abi_A_const_25.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare); var arg_2851 any = A_arbace_cpp_abi_A_const_319; if linked_2848 == nil { arg_2846 = ifn_2849.Invoke_O_O__O(arg_2850, arg_2851) } else { arg_2846 = linked_2848.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_2847, arg_2850, arg_2851) }; if linked_2844 == nil { tmp14 = ifn_2845.Invoke_O__O(arg_2846) } else { tmp14 = linked_2844.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2843, arg_2846) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)).Ref() } else { var root_2852 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2852, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2854 lang.IFn; if linked_2853 == nil { ifn_2854 = lang.IFn_Cast(root_2852) } else { ifn_2854 = nil }; var arg_2855 any = A_arbace_cpp_abi_A_const_20.Invoke_O__O(t.F_bare); if linked_2853 == nil { tmp7 = ifn_2854.Invoke_O__O(arg_2855) } else { tmp7 = linked_2853.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2852, arg_2855) } }; return /*line :715:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, tmp7)).Ref() }

func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A{}; t.Ctor_O(p0); return t }
//line :717:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :717:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_160, nil, nil, nil, Lit_17); var tmp2 any; var root_2684 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = A_arbace_cpp_abi_A_const_310.Invoke_O__O(t.F_bare); if linked_2685 == nil { tmp2 = ifn_2686.Invoke_O__O(arg_2687) } else { tmp2 = linked_2685.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2684, arg_2687) }; var tmp3 any = tmp2; var tmp4 any; var tmp5 any; var and__1927000168__auto____6 any; var root_2688 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2690 lang.IFn; if
													linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = A_arbace_cpp_abi_A_const_311.Invoke_O__O(t.F_bare); if linked_2689 == nil { and__1927000168__auto____6 = ifn_2690.Invoke_O__O(arg_2691) } else { and__1927000168__auto____6 = linked_2689.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2688, arg_2691) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2692 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = A_arbace_cpp_abi_A_const_312.Invoke_O__O(t.F_bare); if linked_2693 == nil { tmp5 = ifn_2694.Invoke_O__O(arg_2695) } else { tmp5 = linked_2693.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2692, arg_2695) } } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { tmp4 = Lit_1 } else { var root_2696 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2700 any; var root_2701 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var arg_2705 any = A_arbace_cpp_abi_A_const_311.Invoke_O__O(t.F_bare); if linked_2702 == nil { arg_2700 = ifn_2703.Invoke_O_O__O(arg_2704, arg_2705) } else { arg_2700 = linked_2702.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2701, arg_2704, arg_2705) }; if linked_2697 == nil { tmp4 = ifn_2698.Invoke_O_O__O(arg_2699, arg_2700) } else { tmp4 = linked_2697.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2696, arg_2699, arg_2700) } }; var tmp6 any = tmp4; var tmp7 /*line :717:1*/*jrt.String; if

	jrt.J2g_Truth(A_arbace_cpp_abi_A_const_312.Invoke_O__O(t.F_bare)) { tmp7 = Lit_2 } else { tmp7 = nil }; return /*line :717:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, tmp6, tmp7.Ref(), nil)).Ref() }



func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A{}; t.Ctor_O(p0); return t }
//line :721:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :721:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A) Invoke_O__O(self any) any { var root_2651 any = A_arbace_cpp_abi_A_const_242.GetRawRoot__O(); var linked_2652 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2651, A_arbace_cpp_abi_template_param_A_fn_class); var ifn_2653 lang.IFn; if linked_2652 == nil { ifn_2653 = lang.IFn_Cast(root_2651) } else { ifn_2653 = nil }; var arg_2654 any = A_arbace_cpp_abi_A_const_243.Invoke_O__O(t.F_bare); if linked_2652 == nil { return ifn_2653.Invoke_O__O(arg_2654) } else { return linked_2652.(*A_arbace_cpp_abi_template_param_A).InvokePrim_O_J__O(root_2651, lang.RT_LongCast_O__J_NoInit(arg_2654)) } }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A{}; t.Ctor_O(p0); return t }
//line :722:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :722:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_158, nil); var tmp2 any; var root_2640 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t.F_bare); if linked_2641 == nil { tmp2 = ifn_2642.Invoke_O__O(arg_2643) } else { tmp2 = linked_2641.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2640, arg_2643) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }


func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A{}; t.Ctor_O(p0); return t }
//line :725:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :725:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A) Invoke_O__O(self any) any { var base__1 any; var root_2713 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, A_arbace_cpp_abi_unq_A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = A_arbace_cpp_abi_A_const_250.Invoke_O__O(t.F_bare); if linked_2714 == nil { base__1 = ifn_2715.Invoke_O__O(arg_2716) } else { base__1 = linked_2714.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_2713, arg_2716) }; var tmp1 any; var root_2717 any =
													A_arbace_cpp_abi_A_const_313.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, A_arbace_cpp_abi_dt_standin_QMARK__A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = t.F_bare; if linked_2718 == nil { tmp1 = ifn_2719.Invoke_O__O(arg_2720) } else { tmp1 = linked_2718.(*A_arbace_cpp_abi_dt_standin_QMARK__A).Invoke_O_O__O(root_2717, arg_2720) }; if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____2 any; var root_2721 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2723 lang.IFn
														if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any; var root_2725 any = A_arbace_cpp_abi_A_const_89.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2727 lang.IFn; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any; var fnbody__2735 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_New(); var tmp2 *jrt.Class; var fncls__2734 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_fn_class; if fncls__2734 == nil { var fncls__2734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_fn_class = fncls__2734d; tmp2 = fncls__2734d } else { tmp2 = fncls__2734 }; arg_2728 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2735, tmp2, nil); var arg_2729 any; var root_2736 any = A_arbace_cpp_abi_A_const_314.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any = A_arbace_cpp_abi_A_const_315.GetRawRoot__O(); var arg_2740 any; var fnbody__2755 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_New(); var tmp3 *jrt.Class; var fncls__2754 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_fn_class; if fncls__2754 == nil { var fncls__2754d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, nil); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_fn_class = fncls__2754d; tmp3 = fncls__2754d } else { tmp3 = fncls__2754 }; arg_2740 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2755, tmp3, nil); var arg_2741 any = A_arbace_cpp_abi_A_const_295.Invoke_O__O(t.F_bare); if linked_2737 == nil { arg_2729 = ifn_2738.Invoke_O_O_O__O(arg_2739, arg_2740, arg_2741) } else { arg_2729 = linked_2737.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_2736, arg_2739, arg_2740, arg_2741) }; if linked_2726 == nil { arg_2724 = ifn_2727.Invoke_O_O__O(arg_2728, arg_2729) } else { arg_2724 = linked_2726.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2725, arg_2728, arg_2729) }; if linked_2722 == nil { temp__1927000408__auto____2 = ifn_2723.Invoke_O__O(arg_2724) } else { temp__1927000408__auto____2 = linked_2722.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2721, arg_2724) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_cpp_abi_A_const_260
															return tmp4.Invoke_O_O_O__O(tmp5, Lit_121, A_arbace_cpp_abi_A_const_283.Invoke_O__O(f__3)) } else {
																var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_163, nil, Lit_17); var tmp7 any; var root_2762 any = A_arbace_cpp_abi_A_const_274.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, A_arbace_cpp_abi_mangle_dt_expr_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = A_arbace_cpp_abi_A_const_295.Invoke_O__O(t.F_bare); if linked_2763 == nil { tmp7 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp7 = linked_2763.(*A_arbace_cpp_abi_mangle_dt_expr_A).Invoke_O_O__O(root_2762, arg_2765) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)).Ref() } } else {
																	var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, nil, Lit_17); var tmp9 any; var tmp10 any = A_arbace_cpp_abi_A_const_251; if lang.Util_Equiv_O_O__Z_NoInit(tmp10, A_arbace_cpp_abi_A_const_16.Invoke_O__O(base__1)) { var root_2766 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_abi_A_const_241, base__1); var arg_2770 any; var fnbody__2776 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_New_O(base__1); var tmp11 *jrt.Class; var fncls__2775 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_fn_class; if fncls__2775 == nil { var fncls__2775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__2776); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_fn_class = fncls__2775d; tmp11 = fncls__2775d } else { tmp11 = fncls__2775 }; arg_2770 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2776, tmp11, nil); if linked_2767 == nil { tmp9 = ifn_2768.Invoke_O_O__O(arg_2769, arg_2770) } else { tmp9 = linked_2767.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2766, arg_2769, arg_2770) } } else { var root_2777 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any = base__1; if linked_2778 == nil { tmp9 = ifn_2779.Invoke_O__O(arg_2780) } else { tmp9 = linked_2778.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2777, arg_2780) } }; var tmp12 any = tmp9; var tmp13 any; var root_2781 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2783 lang.IFn
																	if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2785 any; var root_2786 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2788 lang.IFn; if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any; var fnbody__2808 any = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_New(); var tmp14 *jrt.Class; var fncls__2807 *jrt.Class = A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_fn_class; if fncls__2807 == nil { var fncls__2807d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_fn_class = fncls__2807d; tmp14 = fncls__2807d } else { tmp14 = fncls__2807 }; arg_2789 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2808, tmp14, nil); var arg_2790 any = A_arbace_cpp_abi_A_const_206.Invoke_O__O(t.F_bare); if linked_2787 == nil { arg_2785 = ifn_2788.Invoke_O_O__O(arg_2789, arg_2790) } else { arg_2785 = linked_2787.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2786, arg_2789, arg_2790) }; if linked_2782 == nil { tmp13 = ifn_2783.Invoke_O_O__O(arg_2784, arg_2785) } else { tmp13 = linked_2782.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2781, arg_2784, arg_2785) }
//line :730:1
					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13, nil)).Ref() } }
//line :727:1
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_New() *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A{}; t.Ctor(); return t }
//line :727:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A) Ctor() {}
//line :727:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A) Invoke_O_O__O(self, m__1 any) any { var and__1927000168__auto____2 any; var root_2730 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = m__1; if linked_2731 == nil { and__1927000168__auto____2 = ifn_2732.Invoke_O__O(arg_2733) } else { and__1927000168__auto____2 = linked_2731.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2730, arg_2733) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_cpp_abi_A_const_282; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_270.Invoke_O__O(m__1))).Ref() } else { return and__1927000168__auto____2 } }
//line :727:1
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_New() *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A{}; t.Ctor(); return t }
//line :727:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A) Ctor() {}
//line :727:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 any; var root_2742 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = c__1; if linked_2743 == nil { tmp1 = ifn_2744.Invoke_O__O(arg_2745) } else { tmp1 = linked_2743.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2742, arg_2745) }; if jrt.J2g_Truth(tmp1) { var root_2746 any = A_arbace_cpp_abi_A_const_316.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2748 lang.IFn; if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = c__1; if linked_2747 == nil { return ifn_2748.Invoke_O__O(arg_2749) } else { return linked_2747.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2746, arg_2749) } } else { var root_2750 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2752 lang.IFn; if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any = c__1; if linked_2751 == nil { return ifn_2752.Invoke_O__O(arg_2753) } else { return linked_2751.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2750, arg_2753) } } }


func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A{}; t.Ctor_O(p0); return t }
//line :730:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :730:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A) Invoke_O__O(self any) any { var root_2771 any = A_arbace_cpp_abi_A_const_317.GetRawRoot__O(); var linked_2772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2771, A_arbace_cpp_abi_tspec_unwrapped_A_fn_class); var ifn_2773 lang.IFn; if linked_2772 == nil { ifn_2773 = lang.IFn_Cast(root_2771) } else { ifn_2773 = nil }; var arg_2774 any = t.F_base; if linked_2772 == nil { return ifn_2773.Invoke_O__O(arg_2774) } else { return linked_2772.(*A_arbace_cpp_abi_tspec_unwrapped_A).Invoke_O_O__O(root_2771, arg_2774) } }
func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_New() *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A{}; t.Ctor(); return t }
//line :731:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A) Ctor() {}
//line :731:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_2791 any = A_arbace_cpp_abi_A_const_254.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any = x__1; if linked_2792 == nil { tmp1 = ifn_2793.Invoke_O__O(arg_2794) } else { tmp1 = linked_2792.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2791, arg_2794) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_2795 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2795, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2797 lang.IFn; if linked_2796 == nil { ifn_2797 = lang.IFn_Cast(root_2795) } else { ifn_2797 = nil }; var arg_2798 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(x__1); if linked_2796 == nil { tmp3 = ifn_2797.Invoke_O__O(arg_2798) } else { tmp3 = linked_2796.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2795, arg_2798) }; var tmp4 any = tmp3; var tmp5 any; var root_2799 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_2800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2799, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_2801 lang.IFn; if linked_2800 == nil { ifn_2801 = lang.IFn_Cast(root_2799) } else { ifn_2801 = nil }; var arg_2802 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(x__1); if linked_2800 == nil { tmp5 = ifn_2801.Invoke_O__O(arg_2802) } else { tmp5 = linked_2800.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_2799, arg_2802) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref() } else { var root_2803 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2803, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2805 lang.IFn; if linked_2804 == nil { ifn_2805 = lang.IFn_Cast(root_2803) } else { ifn_2805 = nil }; var arg_2806 any = x__1; if linked_2804 == nil { return ifn_2805.Invoke_O__O(arg_2806) } else { return linked_2804.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2803, arg_2806) } } }

func A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A{}; t.Ctor_O(p0); return t }
//line :733:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :733:1
func (t *A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A) Invoke_O__O(self any) any { var tmp1 any; var or__1927000174__auto____1 any; var root_2816 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_2817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2816, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2818 lang.IFn; if linked_2817 == nil { ifn_2818 = lang.IFn_Cast(root_2816) } else { ifn_2818 = nil }; var arg_2819 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(t.F_bare); if linked_2817 == nil { or__1927000174__auto____1 = ifn_2818.Invoke_O__O(arg_2819) } else { or__1927000174__auto____1 = linked_2817.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2816, arg_2819) }; if jrt.J2g_Truth(or__1927000174__auto____1) { tmp1 = or__1927000174__auto____1 } else { var tmp2 any = A_arbace_cpp_abi_A_const_318; var tmp3 any; var root_2820 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(t.F_bare); if linked_2821 == nil { tmp3 = ifn_2822.Invoke_O__O(arg_2823) } else { tmp3 = linked_2821.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2820, arg_2823) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }; if jrt.J2g_Truth(tmp1) {
													var root_2824 any = A_arbace_cpp_abi_A_const_317.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, A_arbace_cpp_abi_tspec_unwrapped_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = t.F_bare; if linked_2825 == nil { return ifn_2826.Invoke_O__O(arg_2827) } else { return linked_2825.(*A_arbace_cpp_abi_tspec_unwrapped_A).Invoke_O_O__O(root_2824, arg_2827) } } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_17); var tmp5 any; var root_2828 any = A_arbace_cpp_abi_A_const_317.GetRawRoot__O(); var linked_2829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2828, A_arbace_cpp_abi_tspec_unwrapped_A_fn_class); var ifn_2830 lang.IFn; if linked_2829 == nil { ifn_2830 = lang.IFn_Cast(root_2828) } else { ifn_2830 = nil }; var arg_2831 any = t.F_bare; if linked_2829 == nil { tmp5 = ifn_2830.Invoke_O__O(arg_2831) } else { tmp5 = linked_2829.(*A_arbace_cpp_abi_tspec_unwrapped_A).Invoke_O_O__O(root_2828, arg_2831) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil)).Ref() } }







func A_arbace_cpp_abi_bare_params_A_New() *A_arbace_cpp_abi_bare_params_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_bare_params_A{}; t.Ctor(); return t }
//line :742:1
func (t *A_arbace_cpp_abi_bare_params_A) Ctor() {}
//line :742:1
func (t *A_arbace_cpp_abi_bare_params_A) Invoke_O_O_O__O(self, ps__0, va__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var root_2882 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2884 lang.IFn; if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any = ps__0; if linked_2883 == nil { and__1927000168__auto____3 = ifn_2884.Invoke_O__O(arg_2885) } else { and__1927000168__auto____3 = linked_2883.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2882, arg_2885) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2886 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = va__1; if linked_2887 == nil { tmp1 = ifn_2888.Invoke_O__O(arg_2889) } else { tmp1 = linked_2887.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2886, arg_2889) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return Lit_1 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any; var root_2890 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2892 lang.IFn; if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2894 any; var root_2895 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var arg_2899 any = ps__0; if linked_2896 == nil { arg_2894 = ifn_2897.Invoke_O_O__O(arg_2898, arg_2899) } else { arg_2894 = linked_2896.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2895, arg_2898, arg_2899) }; if linked_2891 == nil { tmp3 = ifn_2892.Invoke_O_O__O(arg_2893, arg_2894) } else { tmp3 = linked_2891.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2890, arg_2893, arg_2894) }; var tmp4 any = tmp3; var tmp5 *jrt.String; if jrt.J2g_Truth(va__1) { tmp5 = Lit_2 } else { tmp5 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())).Ref()
	} }
func A_arbace_cpp_abi_mangle_params_A_New() *A_arbace_cpp_abi_mangle_params_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_params_A{}; t.Ctor(); return t }
//line :745:1
func (t *A_arbace_cpp_abi_mangle_params_A) Ctor() {}
//line :745:1
func (t *A_arbace_cpp_abi_mangle_params_A) Invoke_O_O__O(self, ps__0 any) any {
	var root_2908 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_2909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2908, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2910 lang.IFn; if linked_2909 == nil { ifn_2910 = lang.IFn_Cast(root_2908) } else { ifn_2910 = nil }; var arg_2911 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_202; var tmp3 any; var root_2917 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2917, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2919 lang.IFn; if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = lang.PersistentVector_EMPTY.Ref(); if linked_2918 == nil { tmp3 = ifn_2919.Invoke_O__O(arg_2920) } else { tmp3 = linked_2918.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2917, arg_2920) }; arg_2911 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_2909 == nil { ifn_2910.Invoke_O__O(arg_2911) } else { linked_2909.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2908, arg_2911) }
//line :745:1
	var tmp4 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_2900 any = A_arbace_cpp_abi_A_const_321.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, A_arbace_cpp_abi_bare_params_A_fn_class); var ifn_2902 lang.IFn; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any = ps__0; var arg_2904 any = jrt.Boolean_FALSE.Ref(); if linked_2901 == nil { tmp4 = ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { tmp4 = linked_2901.(*A_arbace_cpp_abi_bare_params_A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) } }
//line :745:1
		return nil }(); var root_2905 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2907 lang.IFn
	if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; if linked_2906 == nil { ifn_2907.Invoke__O() } else { linked_2906.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2905) }
//line :745:1
	if tmp5 != nil { panic(tmp5) }; return tmp4
}



func A_arbace_cpp_abi_unqualified_name_A_New() *A_arbace_cpp_abi_unqualified_name_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_unqualified_name_A{}; t.Ctor(); return t }
//line :750:1
func (t *A_arbace_cpp_abi_unqualified_name_A) Ctor() {}
//line :750:1
func (t *A_arbace_cpp_abi_unqualified_name_A) Invoke_O_O_O__O(self, f__0, variant__1 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_2921 any = A_arbace_cpp_abi_A_const_325.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, A_arbace_cpp_abi_unqualified_name_STAR__A_fn_class); var ifn_2923 lang.IFn; if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any = f__0; var arg_2925 any = variant__1; if linked_2922 == nil { tmp2 = ifn_2923.Invoke_O_O__O(arg_2924, arg_2925) } else { tmp2 = linked_2922.(*A_arbace_cpp_abi_unqualified_name_STAR__A).Invoke_O_O_O__O(root_2921, arg_2924, arg_2925) }; var tmp3 any = tmp2; var tmp4 any; var root_2926 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2926, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2928 lang.IFn; if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_2930 any; var root_2931 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2931, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any; var fnbody__2937 any = A_arbace_cpp_abi_unqualified_name_fn__677000317_A_New(); var tmp5 *jrt.Class; var fncls__2936 *jrt.Class = A_arbace_cpp_abi_unqualified_name_fn__677000317_A_fn_class; if fncls__2936 == nil { var fncls__2936d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_209, false, nil); A_arbace_cpp_abi_unqualified_name_fn__677000317_A_fn_class = fncls__2936d; tmp5 = fncls__2936d } else { tmp5 = fncls__2936 }; arg_2934 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2937, tmp5, nil); var arg_2935 any = A_arbace_cpp_abi_A_const_326.Invoke_O__O(f__0); if linked_2932 == nil { arg_2930 = ifn_2933.Invoke_O_O__O(arg_2934, arg_2935) } else { arg_2930 = linked_2932.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2931, arg_2934, arg_2935) }; if linked_2927 == nil { tmp4 = ifn_2928.Invoke_O_O__O(arg_2929, arg_2930) } else { tmp4 = linked_2927.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2926, arg_2929, arg_2930) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }
//line :754:1
func A_arbace_cpp_abi_unqualified_name_fn__677000317_A_New() *A_arbace_cpp_abi_unqualified_name_fn__677000317_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_unqualified_name_fn__677000317_A{}; t.Ctor(); return t }
//line :754:1
func (t *A_arbace_cpp_abi_unqualified_name_fn__677000317_A) Ctor() {}
//line :754:1
func (t *A_arbace_cpp_abi_unqualified_name_fn__677000317_A) Invoke_O_O__O(self, p1__677000316_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_210, nil, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(p1__677000316_SHARP___1)).Ref(), p1__677000316_SHARP___1)).Ref() }

func A_arbace_cpp_abi_unqualified_name_STAR__A_New() *A_arbace_cpp_abi_unqualified_name_STAR__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_unqualified_name_STAR__A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_cpp_abi_unqualified_name_STAR__A) Ctor() {}
//line :756:1
func (t *A_arbace_cpp_abi_unqualified_name_STAR__A) Invoke_O_O_O__O(self, f__0, variant__1 any) any { var G__677000320__3_ any = A_arbace_cpp_abi_A_const_327.Invoke_O__O(f__0); switch

	lang.Util_Hash_O__I_NoInit(G__677000320__3_) >> 2 & 3 { case 0: if any(G__677000320__3_) == any(A_arbace_cpp_abi_A_const_328) { var temp__1927000408__auto____4 any; var or__1927000174__auto____4 any = A_arbace_cpp_abi_A_const_329.Invoke_O__O(f__0)


		if jrt.J2g_Truth(or__1927000174__auto____4) { temp__1927000408__auto____4 = or__1927000174__auto____4 } else { temp__1927000408__auto____4 = A_arbace_cpp_abi_A_const_330.Invoke_O__O(f__0) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_211, nil, nil); var tmp2 any; var or__1927000174__auto____9 any = variant__1
			if jrt.J2g_Truth(or__1927000174__auto____9) { tmp2 = or__1927000174__auto____9 } else { tmp2 = A_arbace_cpp_abi_A_const_221 }; var tmp3 any = tmp2; var tmp4 any; var root_2939 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_33, A_arbace_cpp_abi_A_const_49, b__5)); if linked_2940 == nil { tmp4 = ifn_2941.Invoke_O__O(arg_2942) } else { tmp4 = linked_2940.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2939, arg_2942) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, tmp4)).Ref() } else {
				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_156, nil); var tmp6 any; var or__1927000174__auto____7 any = variant__1; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp6 = or__1927000174__auto____7 } else { tmp6 = A_arbace_cpp_abi_A_const_221 }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref() } }
//line :758:1
	case 2: if any(G__677000320__3_) == any(A_arbace_cpp_abi_A_const_331) {







		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil); var tmp8 any; var root_2943 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any; var or__1927000174__auto____6 any = A_arbace_cpp_abi_A_const_332.Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____6) { arg_2946 = or__1927000174__auto____6 } else { var tmp9 *lang.Keyword = A_arbace_cpp_abi_A_const_310; arg_2946 = tmp9.Invoke_O__O(A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__0)) }; if linked_2944 == nil { tmp8 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp8 = linked_2944.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2943, arg_2946) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref() }
//line :758:1
	case 3: if any(G__677000320__3_) == any(A_arbace_cpp_abi_A_const_333) {





		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_212, nil); var tmp11 any; var or__1927000174__auto____6_2 any = variant__1; if jrt.J2g_Truth(or__1927000174__auto____6_2) { tmp11 = or__1927000174__auto____6_2 } else { tmp11 = A_arbace_cpp_abi_A_const_221 }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref() }
//line :758:1
	default:}; var temp__1927000408__auto____4_2 any = A_arbace_cpp_abi_A_const_287.Invoke_O__O(f__0); if








	jrt.J2g_Truth(temp__1927000408__auto____4_2) { var op__5 any = temp__1927000408__auto____4_2; var or__1927000174__auto____6_3 any; var tmp12 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_334).Invoke_O__O(op__5)
		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var tmp13 *lang.Keyword = A_arbace_cpp_abi_A_const_311; var tmp14 int64 = int64(lang.RT_Count_O__I_NoInit(tmp13.Invoke_O__O(A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__0)))); var tmp15 int64; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_81.Invoke_O__O(f__0)) { tmp15 = 1 } else { tmp15 = 0 }; and__1927000168__auto____7 = lang.Util_Equiv_J_J__Z_NoInit(1, lang.Numbers_Add_J_J__J_NoInit(tmp14, tmp15)); if and__1927000168__auto____7 { var root_2947 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = A_arbace_cpp_abi_A_const_335.Invoke_O__O(f__0); if linked_2948 == nil { tmp12 = ifn_2949.Invoke_O__O(arg_2950) } else { tmp12 = linked_2948.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2947, arg_2950) } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp12) {
			or__1927000174__auto____6_3 = lang.IFn_Cast(A_arbace_cpp_abi_A_const_336.GetRawRoot__O()).Invoke_O__O(op__5) } else {
//line :768:1
				or__1927000174__auto____6_3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____6_3) { return or__1927000174__auto____6_3 } else { var or__1927000174__auto____7_2 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_337.GetRawRoot__O()).Invoke_O__O(op__5); if jrt.J2g_Truth(or__1927000174__auto____7_2) { return or__1927000174__auto____7_2 } else { var or__1927000174__auto____8 any; var temp__1927000414__auto____8 any; var root_2951 any = A_arbace_cpp_abi_A_const_338.GetRawRoot__O(); var linked_2952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2951, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_2953 lang.IFn



					if linked_2952 == nil { ifn_2953 = lang.IFn_Cast(root_2951) } else { ifn_2953 = nil }; var arg_2954 any = A_arbace_cpp_abi_A_const_339; var arg_2955 any = op__5; if linked_2952 == nil { temp__1927000414__auto____8 = ifn_2953.Invoke_O_O__O(arg_2954, arg_2955) } else { temp__1927000414__auto____8 = linked_2952.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_2951, arg_2954, arg_2955) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__677000321__9 any = temp__1927000414__auto____8; var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000321__9, lang.RT_IntCast_J__I_NoInit(0), nil); var sfx__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000321__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_213, nil); var tmp17 any; var root_2956 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2956, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2958 lang.IFn; _ = ___10; if linked_2957 == nil { ifn_2958 = lang.IFn_Cast(root_2956) } else { ifn_2958 = nil }; var arg_2959 any = sfx__11; if linked_2957 == nil { tmp17 = ifn_2958.Invoke_O__O(arg_2959) } else { tmp17 = linked_2957.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2956, arg_2959) }; or__1927000174__auto____8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref() } else { or__1927000174__auto____8 = nil }
//line :768:1
					if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {




						return lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_68, op__5) } } } } else {
							var root_2966 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__0); if linked_2967 == nil { return ifn_2968.Invoke_O__O(arg_2969) } else { return linked_2967.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_2966, arg_2969) } } }

func A_arbace_cpp_abi_q_param_A_New() *A_arbace_cpp_abi_q_param_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_q_param_A{}; t.Ctor(); return t }
//line :776:1
func (t *A_arbace_cpp_abi_q_param_A) Ctor() {}
//line :776:1
func (t *A_arbace_cpp_abi_q_param_A) InvokePrim_O_J_J__O(self any, depth__0, i__1 int64) any {



	var root_2970 any = A_arbace_cpp_abi_A_const_240.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, A_arbace_cpp_abi_sub_or_A_fn_class); var ifn_2972 lang.IFn; if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var tmp1 any = A_arbace_cpp_abi_A_const_309; var arg_2973 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, jrt.Long_ValueOf_J__Long_NoInit(depth__0).Ref(), jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref()); var arg_2974 any; var fnbody__2976 any = A_arbace_cpp_abi_q_param_fn__677000325_A_New_J_J(depth__0, i__1); var tmp2 *jrt.Class; var fncls__2975 *jrt.Class = A_arbace_cpp_abi_q_param_fn__677000325_A_fn_class; if fncls__2975 == nil { var fncls__2975d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, fnbody__2976); A_arbace_cpp_abi_q_param_fn__677000325_A_fn_class = fncls__2975d; tmp2 = fncls__2975d } else { tmp2 = fncls__2975 }; arg_2974 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2976, tmp2, nil); if linked_2971 == nil { return ifn_2972.Invoke_O_O__O(arg_2973, arg_2974) } else { return linked_2971.(*A_arbace_cpp_abi_sub_or_A).Invoke_O_O_O__O(root_2970, arg_2973, arg_2974) } }
//line :776:1
func (t *A_arbace_cpp_abi_q_param_A) Invoke_O_O_O__O(self, p_depth__0, p_i__1 any) any { return t.InvokePrim_O_J_J__O(self, lang.RT_LongCast_O__J_NoInit(p_depth__0), lang.RT_LongCast_O__J_NoInit(p_i__1)) }



func A_arbace_cpp_abi_q_param_fn__677000325_A_New_J_J(p0, p1 int64) *A_arbace_cpp_abi_q_param_fn__677000325_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_q_param_fn__677000325_A{}; t.Ctor_J_J(p0, p1); return t }
//line :780:1
func (t *A_arbace_cpp_abi_q_param_fn__677000325_A) Ctor_J_J(c__depth, c__i int64) { t.F_depth = c__depth; t.F_i = c__i }
//line :780:1
func (t *A_arbace_cpp_abi_q_param_fn__677000325_A) Invoke_O__O(self any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_111, nil, nil, Lit_100); var tmp2 *jrt.String; if lang.Numbers_IsPos_J__Z_NoInit(t.F_depth) { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(t.F_depth)).Ref(), nil)) } else { tmp2 = nil }; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.Long; if lang.Numbers_IsPos_J__Z_NoInit(t.F_i) { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(t.F_i)) } else { tmp4 = nil }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, tmp4.Ref(), nil)).Ref() }

func A_arbace_cpp_abi_mangle_constraint_A_New() *A_arbace_cpp_abi_mangle_constraint_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_A{}; t.Ctor(); return t }
//line :782:1
func (t *A_arbace_cpp_abi_mangle_constraint_A) Ctor() {}
//line :782:1
func (t *A_arbace_cpp_abi_mangle_constraint_A) InvokePrim_O_O_O_J__O(self, n__0, pidx__1 any, depth__2 int64) any { var body_ty__4 *A_arbace_cpp_abi_mangle_constraint_ty__677000330_A = A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_New_J_O_O(depth__2, pidx__1, nil); var body_tt__5 *A_arbace_cpp_abi_mangle_constraint_tt__677000332_A = A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_New_J_O(depth__2, pidx__1); var body_arg__6 *A_arbace_cpp_abi_mangle_constraint_arg__677000334_A = A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_New_J_O_O(depth__2, nil, pidx__1); var body_req__7 *A_arbace_cpp_abi_mangle_constraint_req__677000336_A = A_arbace_cpp_abi_mangle_constraint_req__677000336_A_New_O_O(nil, nil); var body_ex__8 *A_arbace_cpp_abi_mangle_constraint_ex__677000339_A = A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_New_J_O_O_O_O(depth__2, nil, pidx__1, nil, nil); var ty__4 any; var fnbody__3400 any = any(body_ty__4); var tmp1 *jrt.Class; var fncls__3399 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_fn_class; if fncls__3399 == nil { var fncls__3399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__3400); A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_fn_class = fncls__3399d; tmp1 = fncls__3399d } else { tmp1 = fncls__3399 }; ty__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3400, tmp1, nil); var tt__5 any; var fnbody__3402 any = any(body_tt__5); var tmp2 *jrt.Class; var fncls__3401 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_fn_class; if fncls__3401 == nil { var fncls__3401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__3402); A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_fn_class = fncls__3401d; tmp2 = fncls__3401d } else { tmp2 = fncls__3401 }; tt__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3402, tmp2, nil); var arg__6 any; var fnbody__3404 any = any(body_arg__6); var tmp3 *jrt.Class; var fncls__3403 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_fn_class; if fncls__3403 == nil { var fncls__3403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__3404); A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_fn_class = fncls__3403d; tmp3 = fncls__3403d } else { tmp3 = fncls__3403 }; arg__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3404, tmp3, nil); var req__7 any; var fnbody__3406 any = any(body_req__7); var tmp4 *jrt.Class; var fncls__3405 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_req__677000336_A_fn_class; if fncls__3405 == nil { var fncls__3405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__3406); A_arbace_cpp_abi_mangle_constraint_req__677000336_A_fn_class = fncls__3405d; tmp4 = fncls__3405d } else { tmp4 = fncls__3405 }; req__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3406, tmp4, nil); var ex__8 any; var fnbody__3408 any = any(body_ex__8); var tmp5 *jrt.Class; var fncls__3407 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_fn_class; if fncls__3407 == nil { var fncls__3407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__3408); A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_fn_class = fncls__3407d; tmp5 = fncls__3407d } else { tmp5 = fncls__3407 }; ex__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3408, tmp5, nil); body_ty__4.F_tt = tt__5; body_arg__6.F_ty = ty__4; body_req__7.F_ty = ty__4; body_req__7.F_ex = ex__8; body_ex__8.F_ty = ty__4; body_ex__8.F_arg = arg__6; body_ex__8.F_req = req__7; return /*line :847:1*/ lang.IFn_Cast(ex__8).Invoke_O__O(n__0) }
//line :782:1
func (t *A_arbace_cpp_abi_mangle_constraint_A) Invoke_O_O_O_O__O(self, n__0, pidx__1, p_depth__2 any) any { return t.InvokePrim_O_O_O_J__O(self, n__0, pidx__1, lang.RT_LongCast_O__J_NoInit(p_depth__2)) }





func A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_New_J_O_O(p0 int64, p1, p2 any) *A_arbace_cpp_abi_mangle_constraint_arg__677000334_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_arg__677000334_A{}; t.Ctor_J_O_O(p0, p1, p2); return t }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_arg__677000334_A) Ctor_J_O_O(c__depth int64, c__ty, c__pidx any) { t.F_depth = c__depth; t.F_ty = c__ty; t.F_pidx = c__pidx }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_arg__677000334_A) Invoke_O_O__O(self, a__1 any) any { var a__2 any; var root_3083 any = A_arbace_cpp_abi_A_const_340.GetRawRoot__O(); var linked_3084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3083, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_3085 lang.IFn; if


















	linked_3084 == nil { ifn_3085 = lang.IFn_Cast(root_3083) } else { ifn_3085 = nil }; var arg_3086 any = a__1; if linked_3084 == nil { a__2 = ifn_3085.Invoke_O__O(arg_3086) } else { a__2 = linked_3084.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_3083, arg_3086) }; var temp__1927000408__auto____3 any = /*line :788:1*/lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2); if



















	jrt.J2g_Truth(temp__1927000408__auto____3) { var i__4 any = temp__1927000408__auto____3; var root_3087 any = A_arbace_cpp_abi_A_const_341.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3087, A_arbace_cpp_abi_q_param_A_fn_class); var ifn_3089 lang.IFn; if linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 int64 = t.F_depth; var arg_3091 any = i__4; if linked_3088 == nil { return ifn_3089.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_3090).Ref(), arg_3091) } else { return linked_3088.(*A_arbace_cpp_abi_q_param_A).InvokePrim_O_J_J__O(root_3087, arg_3090, lang.RT_LongCast_O__J_NoInit(arg_3091)) } } else { return lang.IFn_Cast(t.F_ty).Invoke_O__O(a__2) } }
//line :788:1
func A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_New_J_O_O_O_O(p0 int64, p1, p2, p3, p4 any) *A_arbace_cpp_abi_mangle_constraint_ex__677000339_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A{}; t.Ctor_J_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_A) Ctor_J_O_O_O_O(c__depth int64, c__ty, c__pidx, c__arg, c__req any) { t.F_depth = c__depth; t.F_ty = c__ty; t.F_pidx = c__pidx; t.F_arg = c__arg; t.F_req = c__req }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_A) Invoke_O_O__O(self, n__1 any) any { var G__677000340__2_ any = A_arbace_cpp_abi_A_const_327.Invoke_O__O(n__1); switch




























	lang.Util_Hash_O__I_NoInit(G__677000340__2_) >> 26 & 31 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_67) {













		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_cpp_abi_A_const_262.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_abi_A_const_350.Invoke_O__O(n__1)); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp4 any = A_arbace_cpp_abi_A_const_260; tmp2 = tmp3.Invoke_O_O_O__O(tmp4, Lit_68, A_arbace_cpp_abi_A_const_350.Invoke_O__O(n__1)) }; var tmp5 any = tmp2; var tmp6 lang.IFn = lang.IFn_Cast(self); var tmp7 any; var root_3196 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3198 lang.IFn; if linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3197 == nil { tmp7 = ifn_3198.Invoke_O__O(arg_3199) } else { tmp7 = linked_3197.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3196, arg_3199) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 lang.IFn = lang.IFn_Cast(self); var tmp10 any; var root_3200 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3202 lang.IFn; if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3201 == nil { tmp10 = ifn_3202.Invoke_O__O(arg_3203) } else { tmp10 = linked_3201.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3200, arg_3203) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp8, tmp9.Invoke_O__O(tmp10))).Ref() }
//line :817:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_69) {

















		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_cpp_abi_A_const_351.Invoke_O__O(n__1), nil)).Ref() }
//line :817:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_71) { var nm__3 any; var root_3119 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3121 lang.IFn



















		if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = n__1; var arg_3123 any = A_arbace_cpp_abi_A_const_352; if linked_3120 == nil { nm__3 = ifn_3121.Invoke_O_O__O(arg_3122, arg_3123) } else { nm__3 = linked_3120.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3119, arg_3122, arg_3123) }
//line :817:1
		var targs__4 any; var temp__1927000414__auto____4 any = A_arbace_cpp_abi_A_const_353.Invoke_O__O(n__1)




















		if jrt.J2g_Truth(temp__1927000414__auto____4) { var as__5 any = temp__1927000414__auto____4; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_17); var tmp12 any; var root_3124 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3124, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3126 lang.IFn; if linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; var arg_3127 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3128 any; var root_3129 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3129, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any = t.F_arg; var arg_3133 any = as__5; if linked_3130 == nil { arg_3128 = ifn_3131.Invoke_O_O__O(arg_3132, arg_3133) } else { arg_3128 = linked_3130.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3129, arg_3132, arg_3133) }; if linked_3125 == nil { tmp12 = ifn_3126.Invoke_O_O__O(arg_3127, arg_3128) } else { tmp12 = linked_3125.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3124, arg_3127, arg_3128) }; targs__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } else { targs__4 = nil }
		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_356.Invoke_O__O(n__1)) { lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_72) }
		var tmp13 any; var root_3134 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3136 lang.IFn

		if linked_3135 == nil { ifn_3136 = lang.IFn_Cast(root_3134) } else { ifn_3136 = nil }; var arg_3137 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3135 == nil { tmp13 = ifn_3136.Invoke_O__O(arg_3137) } else { tmp13 = linked_3135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3134, arg_3137) }
//line :840:1
		if jrt.J2g_Truth(tmp13) {

			var tmp14 any; var root_3209 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3211 lang.IFn; if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any; var fnbody__3224 any = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_New(); var tmp15 *jrt.Class; var fncls__3223 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_fn_class; if fncls__3223 == nil { var fncls__3223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_fn_class = fncls__3223d; tmp15 = fncls__3223d } else { tmp15 = fncls__3223 }; arg_3212 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3224, tmp15, nil); var arg_3213 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3210 == nil { tmp14 = ifn_3211.Invoke_O_O__O(arg_3212, arg_3213) } else { tmp14 = linked_3210.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3209, arg_3212, arg_3213) }; if jrt.J2g_Truth(tmp14) { lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_74) }
			var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, Lit_17, nil, nil); var tmp17 any; var root_3138 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3138, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3140 lang.IFn; if linked_3139 == nil { ifn_3140 = lang.IFn_Cast(root_3138) } else { ifn_3140 = nil }; var arg_3141 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3142 any; var root_3143 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3143, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3145 lang.IFn; if linked_3144 == nil { ifn_3145 = lang.IFn_Cast(root_3143) } else { ifn_3145 = nil }; var arg_3146 any; var fnbody__3157 any = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_New(); var tmp18 *jrt.Class; var fncls__3156 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_fn_class; if fncls__3156 == nil { var fncls__3156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_fn_class = fncls__3156d; tmp18 = fncls__3156d } else { tmp18 = fncls__3156 }; arg_3146 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3157, tmp18, nil); var arg_3147 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3144 == nil { arg_3142 = ifn_3145.Invoke_O_O__O(arg_3146, arg_3147) } else { arg_3142 = linked_3144.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3143, arg_3146, arg_3147) }; if linked_3139 == nil { tmp17 = ifn_3140.Invoke_O_O__O(arg_3141, arg_3142) } else { tmp17 = linked_3139.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3138, arg_3141, arg_3142) }; var tmp19 any = tmp17; var tmp20 any; var root_3158 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3158, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3160 lang.IFn; if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var arg_3161 any = nm__3; if linked_3159 == nil { tmp20 = ifn_3160.Invoke_O__O(arg_3161) } else { tmp20 = linked_3159.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3158, arg_3161) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil, tmp20, targs__4)).Ref() } else {
//line :840:1
				if jrt.J2g_Truth(lang.RT_Get_O_O__O_NoInit(t.F_pidx, nm__3)) {



					var root_3162 any = A_arbace_cpp_abi_A_const_341.GetRawRoot__O(); var linked_3163 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3162, A_arbace_cpp_abi_q_param_A_fn_class); var ifn_3164 lang.IFn; if linked_3163 == nil { ifn_3164 = lang.IFn_Cast(root_3162) } else { ifn_3164 = nil }; var arg_3165 int64 = t.F_depth; var arg_3166 any = lang.RT_Get_O_O__O_NoInit(t.F_pidx, nm__3); if linked_3163 == nil { return ifn_3164.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_3165).Ref(), arg_3166) } else { return linked_3163.(*A_arbace_cpp_abi_q_param_A).InvokePrim_O_J_J__O(root_3162, arg_3165, lang.RT_LongCast_O__J_NoInit(arg_3166)) } } else {
//line :840:1
						if A_arbace_cpp_abi_A_const_118 != nil {




							var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp22 any; var root_3167 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3169 lang.IFn; if linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = nm__3; if linked_3168 == nil { tmp22 = ifn_3169.Invoke_O__O(arg_3170) } else { tmp22 = linked_3168.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3167, arg_3170) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, tmp22, targs__4)).Ref() } else {
//line :840:1
								return nil } } } }
//line :817:1
	case 10: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_76) {


		var tmp23 any; var root_3171 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3173 lang.IFn; if linked_3172 == nil { ifn_3173 = lang.IFn_Cast(root_3171) } else { ifn_3173 = nil }; var arg_3174 any = A_arbace_cpp_abi_A_const_355.Invoke_O__O(n__1); if linked_3172 == nil { tmp23 = ifn_3173.Invoke_O__O(arg_3174) } else { tmp23 = linked_3172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3171, arg_3174) }; if jrt.J2g_Truth(tmp23) { return lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_77) } else { var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_78, nil, Lit_17); var tmp25 any; var root_3180 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3180, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3182 lang.IFn; if linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3184 any; var root_3185 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3186 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3185, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3187 lang.IFn; if linked_3186 == nil { ifn_3187 = lang.IFn_Cast(root_3185) } else { ifn_3187 = nil }; var arg_3188 any = t.F_req; var arg_3189 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3186 == nil { arg_3184 = ifn_3187.Invoke_O_O__O(arg_3188, arg_3189) } else { arg_3184 = linked_3186.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3185, arg_3188, arg_3189) }; if linked_3181 == nil { tmp25 = ifn_3182.Invoke_O_O__O(arg_3183, arg_3184) } else { tmp25 = linked_3181.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3180, arg_3183, arg_3184) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, nil)).Ref() } }
//line :817:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_79) {














		var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp27 any; var G__677000345__5_ any = A_arbace_cpp_abi_A_const_350.Invoke_O__O(n__1); L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__677000345__5_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__677000345__5_, Lit_80) { tmp27 = Lit_81; break L2 }; case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__677000345__5_, Lit_82) { tmp27 = Lit_83; break L2 }; case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__677000345__5_, Lit_84) { tmp27 = Lit_85; break L2 }; default:}; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp29 any = A_arbace_cpp_abi_A_const_260; tmp27 = tmp28.Invoke_O_O_O__O(tmp29, Lit_68, A_arbace_cpp_abi_A_const_350.Invoke_O__O(n__1))}; var tmp30 any = tmp27; var tmp31 lang.IFn = lang.IFn_Cast(self); var tmp32 any; var root_3289 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3291 lang.IFn; if linked_3290 == nil { ifn_3291 = lang.IFn_Cast(root_3289) } else { ifn_3291 = nil }; var arg_3292 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3290 == nil { tmp32 = ifn_3291.Invoke_O__O(arg_3292) } else { tmp32 = linked_3290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3289, arg_3292) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31.Invoke_O__O(tmp32))).Ref() }
//line :817:1
	case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_86) { var nm__3_2 any; var root_3237 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_3238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3237, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3239 lang.IFn



















		if linked_3238 == nil { ifn_3239 = lang.IFn_Cast(root_3237) } else { ifn_3239 = nil }; var arg_3240 any = n__1; var arg_3241 any = A_arbace_cpp_abi_A_const_359; if linked_3238 == nil { nm__3_2 = ifn_3239.Invoke_O_O__O(arg_3240, arg_3241) } else { nm__3_2 = linked_3238.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3237, arg_3240, arg_3241) }
//line :817:1
		var targs__4_2 any; var temp__1927000414__auto____4_2 any = A_arbace_cpp_abi_A_const_353.Invoke_O__O(n__1)




















		if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var as__5_2 any = temp__1927000414__auto____4_2; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_17); var tmp34 any; var root_3242 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3242, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3244 lang.IFn; if linked_3243 == nil { ifn_3244 = lang.IFn_Cast(root_3242) } else { ifn_3244 = nil }; var arg_3245 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3246 any; var root_3247 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3247, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3249 lang.IFn; if linked_3248 == nil { ifn_3249 = lang.IFn_Cast(root_3247) } else { ifn_3249 = nil }; var arg_3250 any = t.F_arg; var arg_3251 any = as__5_2; if linked_3248 == nil { arg_3246 = ifn_3249.Invoke_O_O__O(arg_3250, arg_3251) } else { arg_3246 = linked_3248.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3247, arg_3250, arg_3251) }; if linked_3243 == nil { tmp34 = ifn_3244.Invoke_O_O__O(arg_3245, arg_3246) } else { tmp34 = linked_3243.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3242, arg_3245, arg_3246) }; targs__4_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34, nil)).Ref() } else { targs__4_2 = nil }
		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_356.Invoke_O__O(n__1)) { lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_72) }
		var tmp35 any; var root_3252 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3254 lang.IFn

		if linked_3253 == nil { ifn_3254 = lang.IFn_Cast(root_3252) } else { ifn_3254 = nil }; var arg_3255 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3253 == nil { tmp35 = ifn_3254.Invoke_O__O(arg_3255) } else { tmp35 = linked_3253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3252, arg_3255) }
//line :840:1
		if jrt.J2g_Truth(tmp35) {

			var tmp36 any; var root_3298 any = A_arbace_cpp_abi_A_const_85.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any; var fnbody__3313 any = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_New(); var tmp37 *jrt.Class; var fncls__3312 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_fn_class; if fncls__3312 == nil { var fncls__3312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_fn_class = fncls__3312d; tmp37 = fncls__3312d } else { tmp37 = fncls__3312 }; arg_3301 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3313, tmp37, nil); var arg_3302 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3299 == nil { tmp36 = ifn_3300.Invoke_O_O__O(arg_3301, arg_3302) } else { tmp36 = linked_3299.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3298, arg_3301, arg_3302) }; if jrt.J2g_Truth(tmp36) { lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_74) }
			var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil, Lit_17, nil, nil); var tmp39 any; var root_3256 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3256, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3258 lang.IFn; if linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3260 any; var root_3261 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3261, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3263 lang.IFn; if linked_3262 == nil { ifn_3263 = lang.IFn_Cast(root_3261) } else { ifn_3263 = nil }; var arg_3264 any; var fnbody__3275 any = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_New(); var tmp40 *jrt.Class; var fncls__3274 *jrt.Class = A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_fn_class; if fncls__3274 == nil { var fncls__3274d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_fn_class = fncls__3274d; tmp40 = fncls__3274d } else { tmp40 = fncls__3274 }; arg_3264 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3275, tmp40, nil); var arg_3265 any = A_arbace_cpp_abi_A_const_354.Invoke_O__O(n__1); if linked_3262 == nil { arg_3260 = ifn_3263.Invoke_O_O__O(arg_3264, arg_3265) } else { arg_3260 = linked_3262.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3261, arg_3264, arg_3265) }; if linked_3257 == nil { tmp39 = ifn_3258.Invoke_O_O__O(arg_3259, arg_3260) } else { tmp39 = linked_3257.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3256, arg_3259, arg_3260) }; var tmp41 any = tmp39; var tmp42 any; var root_3276 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = nm__3_2; if linked_3277 == nil { tmp42 = ifn_3278.Invoke_O__O(arg_3279) } else { tmp42 = linked_3277.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3276, arg_3279) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp41, nil, tmp42, targs__4_2)).Ref() } else {
//line :840:1
				if jrt.J2g_Truth(lang.RT_Get_O_O__O_NoInit(t.F_pidx, nm__3_2)) {



					var root_3280 any = A_arbace_cpp_abi_A_const_341.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3280, A_arbace_cpp_abi_q_param_A_fn_class); var ifn_3282 lang.IFn; if linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 int64 = t.F_depth; var arg_3284 any = lang.RT_Get_O_O__O_NoInit(t.F_pidx, nm__3_2); if linked_3281 == nil { return ifn_3282.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_3283).Ref(), arg_3284) } else { return linked_3281.(*A_arbace_cpp_abi_q_param_A).InvokePrim_O_J_J__O(root_3280, arg_3283, lang.RT_LongCast_O__J_NoInit(arg_3284)) } } else {
//line :840:1
						if A_arbace_cpp_abi_A_const_118 != nil {




							var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp44 any; var root_3285 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3285, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3287 lang.IFn; if linked_3286 == nil { ifn_3287 = lang.IFn_Cast(root_3285) } else { ifn_3287 = nil }; var arg_3288 any = nm__3_2; if linked_3286 == nil { tmp44 = ifn_3287.Invoke_O__O(arg_3288) } else { tmp44 = linked_3286.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3285, arg_3288) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp43, jrt.RefArrayOf(jrt.Object_class, tmp44, targs__4_2)).Ref() } else {
//line :840:1
								return nil } } } }
//line :817:1
	case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_89) {












		var tmp45 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp46 lang.IFn = lang.IFn_Cast(self); var tmp47 any; var root_3319 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3319, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3321 lang.IFn; if linked_3320 == nil { ifn_3321 = lang.IFn_Cast(root_3319) } else { ifn_3321 = nil }; var arg_3322 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3320 == nil { tmp47 = ifn_3321.Invoke_O__O(arg_3322) } else { tmp47 = linked_3320.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3319, arg_3322) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp45, jrt.RefArrayOf(jrt.Object_class, nil, tmp46.Invoke_O__O(tmp47))).Ref() }
//line :817:1
	case 17: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_91) {
















		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_351.Invoke_O__O(n__1)) { return Lit_92 } else { return Lit_93 } }
//line :817:1
	case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_94) {











		var tmp48 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil, nil); var tmp49 lang.IFn = lang.IFn_Cast(t.F_ty); var tmp50 any; var root_3363 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3363, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3365 lang.IFn; if linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any = n__1; var arg_3367 any = A_arbace_cpp_abi_A_const_363; if linked_3364 == nil { tmp50 = ifn_3365.Invoke_O_O__O(arg_3366, arg_3367) } else { tmp50 = linked_3364.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3363, arg_3366, arg_3367) }; var tmp51 any = tmp49.Invoke_O__O(tmp50); var tmp52 lang.IFn = lang.IFn_Cast(self); var tmp53 any; var root_3368 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3369 == nil { tmp53 = ifn_3370.Invoke_O__O(arg_3371) } else { tmp53 = linked_3369.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3368, arg_3371) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp48, jrt.RefArrayOf(jrt.Object_class, nil, tmp51, tmp52.Invoke_O__O(tmp53))).Ref() }
//line :817:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_96) { var ks__3 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); var vec__677000350__4 any





		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_360.Invoke_O__O(n__1)) { var tmp54 any; var root_3372 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3372, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3374 lang.IFn; if linked_3373 == nil { ifn_3374 = lang.IFn_Cast(root_3372) } else { ifn_3374 = nil }; var arg_3375 any = ks__3; if linked_3373 == nil { tmp54 = ifn_3374.Invoke_O__O(arg_3375) } else { tmp54 = linked_3373.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3372, arg_3375) }; var tmp55 any = tmp54; var tmp56 any; var root_3376 any = A_arbace_cpp_abi_A_const_235.GetRawRoot__O(); var linked_3377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3376, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3378 lang.IFn; if linked_3377 == nil { ifn_3378 = lang.IFn_Cast(root_3376) } else { ifn_3378 = nil }; var arg_3379 any = ks__3; if linked_3377 == nil { tmp56 = ifn_3378.Invoke_O__O(arg_3379) } else { tmp56 = linked_3377.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3376, arg_3379) }; vec__677000350__4 = lang.Tuple_Create_O_O__IPersistentVector(tmp55, tmp56) } else { vec__677000350__4 = lang.Tuple_Create_O_O__IPersistentVector(nil, ks__3) }
//line :817:1
		var init__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000350__4, lang.RT_IntCast_J__I_NoInit(0), nil); var place__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000350__4, lang.RT_IntCast_J__I_NoInit(1), nil); var t__7 any; var root_3323 any = A_arbace_cpp_abi_A_const_340.GetRawRoot__O(); var linked_3324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3323, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_3325 lang.IFn






		if linked_3324 == nil { ifn_3325 = lang.IFn_Cast(root_3323) } else { ifn_3325 = nil }; var arg_3326 any; var root_3327 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3329 lang.IFn; if linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any = n__1; var arg_3331 any = A_arbace_cpp_abi_A_const_361; if linked_3328 == nil { arg_3326 = ifn_3329.Invoke_O_O__O(arg_3330, arg_3331) } else { arg_3326 = linked_3328.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3327, arg_3330, arg_3331) }; if linked_3324 == nil { t__7 = ifn_3325.Invoke_O__O(arg_3326) } else { t__7 = linked_3324.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_3323, arg_3326) }
//line :817:1
		var et__8 any; var tmp57 any; var root_3332 any = A_arbace_cpp_abi_A_const_342.GetRawRoot__O(); var linked_3333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3332, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3334 lang.IFn







		if linked_3333 == nil { ifn_3334 = lang.IFn_Cast(root_3332) } else { ifn_3334 = nil }; var arg_3335 any = t__7; var arg_3336 any = Lit_97; if linked_3333 == nil { tmp57 = ifn_3334.Invoke_O_O__O(arg_3335, arg_3336) } else { tmp57 = linked_3333.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3332, arg_3335, arg_3336) }; if jrt.J2g_Truth(tmp57) { var root_3337 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3337, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3339 lang.IFn; if linked_3338 == nil { ifn_3339 = lang.IFn_Cast(root_3337) } else { ifn_3339 = nil }; var arg_3340 any = t__7; var arg_3341 any = A_arbace_cpp_abi_A_const_68; var arg_3342 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t__7)))).Ref(); if linked_3338 == nil { et__8 = ifn_3339.Invoke_O_O_O__O(arg_3340, arg_3341, arg_3342) } else { et__8 = linked_3338.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_3337, arg_3340, arg_3341, arg_3342) } } else { et__8 = t__7 }
		if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_364.Invoke_O__O(n__1)) { lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_98) }
		var tmp58 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_99, nil, Lit_100, nil, nil); var tmp59 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_362.Invoke_O__O(n__1)) { tmp59 = Lit_101 } else { tmp59 = nil }; var tmp60 any = tmp59.Ref(); var tmp61 any; var root_3343 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3347 any; var root_3348 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3348, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = self; var arg_3352 any = place__6; if linked_3349 == nil { arg_3347 = ifn_3350.Invoke_O_O__O(arg_3351, arg_3352) } else { arg_3347 = linked_3349.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3348, arg_3351, arg_3352) }; if linked_3344 == nil { tmp61 = ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { tmp61 = linked_3344.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) }; var tmp62 any = tmp61; var tmp63 any = lang.IFn_Cast(t.F_ty).Invoke_O__O(et__8); var tmp64 *jrt.String
		if jrt.J2g_Truth(init__5) { var tmp65 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_17); var tmp66 any; var root_3353 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3357 any; var root_3358 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3358, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3360 lang.IFn; if linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = self; var arg_3362 any; if lang.Util_Equiv_O_O__Z_NoInit(Lit_103, A_arbace_cpp_abi_A_const_327.Invoke_O__O(init__5)) { arg_3362 = A_arbace_cpp_abi_A_const_348.Invoke_O__O(init__5) } else { arg_3362 = lang.Tuple_Create_O__IPersistentVector(init__5) }; if linked_3359 == nil { arg_3357 = ifn_3360.Invoke_O_O__O(arg_3361, arg_3362) } else { arg_3357 = linked_3359.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3358, arg_3361, arg_3362) }; if linked_3354 == nil { tmp66 = ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { tmp66 = linked_3354.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }; tmp64 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp65, jrt.RefArrayOf(jrt.Object_class, nil, tmp66, nil)) } else { tmp64 = Lit_17 }
//line :827:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp58, jrt.RefArrayOf(jrt.Object_class, tmp60, nil, tmp62, nil, tmp63, tmp64.Ref())).Ref() }
//line :817:1
	case 28: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_104) {
		var tmp67 lang.IFn = lang.IFn_Cast(self); var tmp68 any; var root_3395 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3396 == nil { tmp68 = ifn_3397.Invoke_O__O(arg_3398) } else { tmp68 = linked_3396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3395, arg_3398) }; return tmp67.Invoke_O__O(tmp68) }
//line :817:1
	case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__677000340__2_, Lit_105) {















		var tmp69 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_106, nil, Lit_17); var tmp70 any; var root_3385 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3385, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3387 lang.IFn; if linked_3386 == nil { ifn_3387 = lang.IFn_Cast(root_3385) } else { ifn_3387 = nil }; var arg_3388 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3389 any; var root_3390 any = A_arbace_cpp_abi_A_const_151.GetRawRoot__O(); var linked_3391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3390, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3392 lang.IFn; if linked_3391 == nil { ifn_3392 = lang.IFn_Cast(root_3390) } else { ifn_3392 = nil }; var arg_3393 any = self; var arg_3394 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(n__1); if linked_3391 == nil { arg_3389 = ifn_3392.Invoke_O_O__O(arg_3393, arg_3394) } else { arg_3389 = linked_3391.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3390, arg_3393, arg_3394) }; if linked_3386 == nil { tmp70 = ifn_3387.Invoke_O_O__O(arg_3388, arg_3389) } else { tmp70 = linked_3386.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3385, arg_3388, arg_3389) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp69, jrt.RefArrayOf(jrt.Object_class, nil, tmp70, nil)).Ref() }
//line :817:1
	default:}; var tmp71 lang.IFn =




























	lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp72 any = A_arbace_cpp_abi_A_const_260; return tmp71.Invoke_O_O_O__O(tmp72, Lit_107, A_arbace_cpp_abi_A_const_327.Invoke_O__O(n__1)) }
//line :788:1
func A_arbace_cpp_abi_mangle_constraint_req__677000336_A_New_O_O(p0, p1 any) *A_arbace_cpp_abi_mangle_constraint_req__677000336_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_req__677000336_A{}; t.Ctor_O_O(p0, p1); return t }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_req__677000336_A) Ctor_O_O(c__ty, c__ex any) { t.F_ty = c__ty; t.F_ex = c__ex }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_req__677000336_A) Invoke_O_O__O(self, r__1 any) any { var G__677000337__2_ any = A_arbace_cpp_abi_A_const_327.Invoke_O__O(r__1); switch





















	lang.Util_Hash_O__I_NoInit(G__677000337__2_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__677000337__2_, Lit_108) {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil); var tmp2 lang.IFn = lang.IFn_Cast(t.F_ex); var tmp3 any; var root_3099 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(r__1); if linked_3100 == nil { tmp3 = ifn_3101.Invoke_O__O(arg_3102) } else { tmp3 = linked_3100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3099, arg_3102) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O__O(tmp3))).Ref() }
//line :810:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__677000337__2_, Lit_110) {



		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_111, nil); var tmp5 lang.IFn = lang.IFn_Cast(t.F_ty); var tmp6 any; var root_3103 any = A_arbace_cpp_abi_A_const_205.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any = r__1; var arg_3107 any = A_arbace_cpp_abi_A_const_349; if linked_3104 == nil { tmp6 = ifn_3105.Invoke_O_O__O(arg_3106, arg_3107) } else { tmp6 = linked_3104.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3103, arg_3106, arg_3107) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5.Invoke_O__O(tmp6))).Ref() }
//line :810:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__677000337__2_, Lit_112) {


		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil); var tmp8 lang.IFn = lang.IFn_Cast(t.F_ex); var tmp9 any; var root_3108 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any = A_arbace_cpp_abi_A_const_348.Invoke_O__O(r__1); if linked_3109 == nil { tmp9 = ifn_3110.Invoke_O__O(arg_3111) } else { tmp9 = linked_3109.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3108, arg_3111) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))).Ref() }
//line :810:1
	default:}; var tmp10 lang.IFn =




	lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()); var tmp11 any = A_arbace_cpp_abi_A_const_260; return tmp10.Invoke_O_O_O__O(tmp11, Lit_113, A_arbace_cpp_abi_A_const_327.Invoke_O__O(r__1)) }
//line :788:1
func A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_New_J_O(p0 int64, p1 any) *A_arbace_cpp_abi_mangle_constraint_tt__677000332_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_tt__677000332_A{}; t.Ctor_J_O(p0, p1); return t }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_tt__677000332_A) Ctor_J_O(c__depth int64, c__pidx any) { t.F_depth = c__depth; t.F_pidx = c__pidx }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_tt__677000332_A) Invoke_O_O__O(self, a__1 any) any { var a__2 any; var root_3024 any = A_arbace_cpp_abi_A_const_340.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_3026 lang.IFn; if








	linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = a__1; if linked_3025 == nil { a__2 = ifn_3026.Invoke_O__O(arg_3027) } else { a__2 = linked_3025.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_3024, arg_3027) }; var tmp1 any; var root_3028 any =
	A_arbace_cpp_abi_A_const_342.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3030 lang.IFn; if
	linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any = a__2; var arg_3032 any = Lit_97; if linked_3029 == nil { tmp1 = ifn_3030.Invoke_O_O__O(arg_3031, arg_3032) } else { tmp1 = linked_3029.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3028, arg_3031, arg_3032) }; if /*line :798:1*/ jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_cpp_abi_A_const_16; var tmp3 any = A_arbace_cpp_abi_A_const_19; var tmp4 any = A_arbace_cpp_abi_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_3077 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3079 lang.IFn
		if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = a__2; var arg_3081 any = A_arbace_cpp_abi_A_const_68; var arg_3082 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__2)))).Ref(); if linked_3078 == nil { tmp6 = ifn_3079.Invoke_O_O_O__O(arg_3080, arg_3081, arg_3082) } else { tmp6 = linked_3078.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_3077, arg_3080, arg_3081, arg_3082) }
//line :798:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5.Invoke_O__O(tmp6))) } else { var tmp7 any; var root_3033 any = A_arbace_cpp_abi_A_const_344.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3035 lang.IFn

			if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = a__2; var arg_3037 any = Lit_114; if linked_3034 == nil { tmp7 = ifn_3035.Invoke_O_O__O(arg_3036, arg_3037) } else { tmp7 = linked_3034.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3033, arg_3036, arg_3037) }
//line :798:1
			if jrt.J2g_Truth(tmp7) {

				var root_3038 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_3039 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3038, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3040 lang.IFn; if linked_3039 == nil { ifn_3040 = lang.IFn_Cast(root_3038) } else { ifn_3040 = nil }; var arg_3041 any; var tmp8 lang.IFn = lang.IFn_Cast(self); var tmp9 any; var root_3044 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = a__2; var arg_3048 any = A_arbace_cpp_abi_A_const_345; if linked_3045 == nil { tmp9 = ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { tmp9 = linked_3045.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; arg_3041 = tmp8.Invoke_O__O(tmp9); var arg_3042 any = A_arbace_cpp_abi_A_const_26; var arg_3043 any = jrt.Boolean_TRUE.Ref(); if linked_3039 == nil { return ifn_3040.Invoke_O_O_O__O(arg_3041, arg_3042, arg_3043) } else { return linked_3039.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3038, arg_3041, arg_3042, arg_3043) } } else {
//line :798:1
					var tmp10 any; var root_3049 any = A_arbace_cpp_abi_A_const_342.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3051 lang.IFn


					if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any = a__2; var arg_3053 any = Lit_115; if linked_3050 == nil { tmp10 = ifn_3051.Invoke_O_O__O(arg_3052, arg_3053) } else { tmp10 = linked_3050.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3049, arg_3052, arg_3053) }
//line :798:1
					if jrt.J2g_Truth(tmp10) {


						var root_3054 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3056 lang.IFn; if linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any; var tmp11 lang.IFn = lang.IFn_Cast(self); var tmp12 any; var root_3060 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = a__2; var arg_3064 any = A_arbace_cpp_abi_A_const_68; var arg_3065 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__2)), 6)).Ref(); if linked_3061 == nil { tmp12 = ifn_3062.Invoke_O_O_O__O(arg_3063, arg_3064, arg_3065) } else { tmp12 = linked_3061.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_3060, arg_3063, arg_3064, arg_3065) }; arg_3057 = tmp11.Invoke_O__O(tmp12); var arg_3058 any = A_arbace_cpp_abi_A_const_26; var arg_3059 any = jrt.Boolean_TRUE.Ref(); if linked_3055 == nil { return ifn_3056.Invoke_O_O_O__O(arg_3057, arg_3058, arg_3059) } else { return linked_3055.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3054, arg_3057, arg_3058, arg_3059) } } else {
//line :798:1
							if jrt.J2g_Truth(lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2)) {



								if lang.Numbers_IsZero_J__Z_NoInit(t.F_depth) { var tmp13 any = A_arbace_cpp_abi_A_const_16; var tmp14 any = A_arbace_cpp_abi_A_const_258; var tmp15 any = A_arbace_cpp_abi_A_const_243; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2))) } else { return lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_116) } } else {
//line :798:1
									if jrt.J2g_Truth(lang.RT_Get_O_O__O_NoInit(A_arbace_cpp_abi_A_const_346, a__2)) { var tmp16 any = A_arbace_cpp_abi_A_const_16; var tmp17 any = A_arbace_cpp_abi_A_const_17; var tmp18 any = A_arbace_cpp_abi_A_const_18; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.RT_Get_O_O__O_NoInit(A_arbace_cpp_abi_A_const_347, a__2))) } else { if A_arbace_cpp_abi_A_const_118 != nil {






										return lang.IFn_Cast(A_arbace_cpp_abi_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_cpp_abi_A_const_260, Lit_117, a__2) } else {
//line :798:1
											return nil } } } } } } }
//line :788:1
func A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_New_J_O_O(p0 int64, p1, p2 any) *A_arbace_cpp_abi_mangle_constraint_ty__677000330_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ty__677000330_A{}; t.Ctor_J_O_O(p0, p1, p2); return t }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_ty__677000330_A) Ctor_J_O_O(c__depth int64, c__pidx, c__tt any) { t.F_depth = c__depth; t.F_pidx = c__pidx; t.F_tt = c__tt }
//line :788:1
func (t *A_arbace_cpp_abi_mangle_constraint_ty__677000330_A) Invoke_O_O__O(self, a__1 any) any { var a__2 any; var root_2977 any = A_arbace_cpp_abi_A_const_340.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_2979 lang.IFn; if

	linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = a__1; if linked_2978 == nil { a__2 = ifn_2979.Invoke_O__O(arg_2980) } else { a__2 = linked_2978.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_2977, arg_2980) }; if
	jrt.J2g_Truth(lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2)) {
		if lang.Numbers_IsZero_J__Z_NoInit(t.F_depth) { var root_2981 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var tmp1 any = A_arbace_cpp_abi_A_const_16; var tmp2 any = A_arbace_cpp_abi_A_const_258; var tmp3 any = A_arbace_cpp_abi_A_const_243; var arg_2984 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2))); if linked_2982 == nil { return ifn_2983.Invoke_O__O(arg_2984) } else { return linked_2982.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2981, arg_2984) } } else { var root_2985 any = A_arbace_cpp_abi_A_const_341.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2985, A_arbace_cpp_abi_q_param_A_fn_class); var ifn_2987 lang.IFn; if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 int64 = t.F_depth; var arg_2989 any = lang.RT_Get_O_O__O_NoInit(t.F_pidx, a__2); if linked_2986 == nil { return ifn_2987.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_2988).Ref(), arg_2989) } else { return linked_2986.(*A_arbace_cpp_abi_q_param_A).InvokePrim_O_J_J__O(root_2985, arg_2988, lang.RT_LongCast_O__J_NoInit(arg_2989)) } } } else {
//line :791:1
			var tmp4 any; var root_2990 any = A_arbace_cpp_abi_A_const_342.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_2992 lang.IFn

			if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; var arg_2993 any = a__2; var arg_2994 any = Lit_30; if linked_2991 == nil { tmp4 = ifn_2992.Invoke_O_O__O(arg_2993, arg_2994) } else { tmp4 = linked_2991.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_2990, arg_2993, arg_2994) }
//line :791:1
			if jrt.J2g_Truth(tmp4) {

				var root_2995 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any; var tmp5 any = A_arbace_cpp_abi_A_const_16; var tmp6 any = A_arbace_cpp_abi_A_const_22; var tmp7 any = A_arbace_cpp_abi_A_const_20; var tmp8 lang.IFn = lang.IFn_Cast(t.F_tt); var tmp9 any; var root_2999 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3001 lang.IFn; if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any = a__2; var arg_3003 any = A_arbace_cpp_abi_A_const_68; var arg_3004 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__2)), 2)).Ref(); if linked_3000 == nil { tmp9 = ifn_3001.Invoke_O_O_O__O(arg_3002, arg_3003, arg_3004) } else { tmp9 = linked_3000.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2999, arg_3002, arg_3003, arg_3004) }; arg_2998 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8.Invoke_O__O(tmp9))); if linked_2996 == nil { return ifn_2997.Invoke_O__O(arg_2998) } else { return linked_2996.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_2995, arg_2998) } } else {
//line :791:1
					var tmp10 any; var root_3005 any = A_arbace_cpp_abi_A_const_342.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3007 lang.IFn


					if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any = a__2; var arg_3009 any = Lit_28; if linked_3006 == nil { tmp10 = ifn_3007.Invoke_O_O__O(arg_3008, arg_3009) } else { tmp10 = linked_3006.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3005, arg_3008, arg_3009) }
//line :791:1
					if jrt.J2g_Truth(tmp10) {


						var root_3010 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3012 lang.IFn; if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any; var tmp11 any = A_arbace_cpp_abi_A_const_16; var tmp12 any = A_arbace_cpp_abi_A_const_21; var tmp13 any = A_arbace_cpp_abi_A_const_20; var tmp14 lang.IFn = lang.IFn_Cast(t.F_tt); var tmp15 any; var root_3014 any = A_arbace_cpp_abi_A_const_343.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3014, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3016 lang.IFn; if linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var arg_3017 any = a__2; var arg_3018 any = A_arbace_cpp_abi_A_const_68; var arg_3019 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__2)))).Ref(); if linked_3015 == nil { tmp15 = ifn_3016.Invoke_O_O_O__O(arg_3017, arg_3018, arg_3019) } else { tmp15 = linked_3015.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_3014, arg_3017, arg_3018, arg_3019) }; arg_3013 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, tmp14.Invoke_O__O(tmp15))); if linked_3011 == nil { return ifn_3012.Invoke_O__O(arg_3013) } else { return linked_3011.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3010, arg_3013) } } else {
//line :791:1
							if A_arbace_cpp_abi_A_const_118 != nil {



								var root_3020 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = lang.IFn_Cast(t.F_tt).Invoke_O__O(a__2); if linked_3021 == nil { return ifn_3022.Invoke_O__O(arg_3023) } else { return linked_3021.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3020, arg_3023) } } else {
//line :791:1
									return nil } } } } }


















































func A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_New() *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A{}; t.Ctor(); return t }
//line :842:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A) Ctor() {}
//line :842:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A) Invoke_O_O__O(self, p1__677000328_SHARP___1 any) any { var root_3214 any = A_arbace_cpp_abi_A_const_357.GetRawRoot__O(); var linked_3215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3214, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3216 lang.IFn; if linked_3215 == nil { ifn_3216 = lang.IFn_Cast(root_3214) } else { ifn_3216 = nil }; var arg_3217 any = A_arbace_cpp_abi_A_const_358; var arg_3218 any; var root_3219 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3219, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3221 lang.IFn; if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = p1__677000328_SHARP___1; if linked_3220 == nil { arg_3218 = ifn_3221.Invoke_O__O(arg_3222) } else { arg_3218 = linked_3220.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3219, arg_3222) }; if linked_3215 == nil { return ifn_3216.Invoke_O_O__O(arg_3217, arg_3218) } else { return linked_3215.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3214, arg_3217, arg_3218) } }
//line :842:1
func A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_New() *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A{}; t.Ctor(); return t }
//line :842:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A) Ctor() {}
//line :842:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A) Invoke_O_O__O(self, p1__677000328_SHARP___1 any) any { var root_3303 any = A_arbace_cpp_abi_A_const_357.GetRawRoot__O(); var linked_3304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3303, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3305 lang.IFn; if linked_3304 == nil { ifn_3305 = lang.IFn_Cast(root_3303) } else { ifn_3305 = nil }; var arg_3306 any = A_arbace_cpp_abi_A_const_358; var arg_3307 any; var root_3308 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var linked_3309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3308, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3310 lang.IFn; if linked_3309 == nil { ifn_3310 = lang.IFn_Cast(root_3308) } else { ifn_3310 = nil }; var arg_3311 any = p1__677000328_SHARP___1; if linked_3309 == nil { arg_3307 = ifn_3310.Invoke_O__O(arg_3311) } else { arg_3307 = linked_3309.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3308, arg_3311) }; if linked_3304 == nil { return ifn_3305.Invoke_O_O__O(arg_3306, arg_3307) } else { return linked_3304.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3303, arg_3306, arg_3307) } }
func A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_New() *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A{}; t.Ctor(); return t }
//line :843:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A) Ctor() {}
//line :843:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A) Invoke_O_O__O(self, p1__677000329_SHARP___1 any) any { var root_3148 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3150 lang.IFn; if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any; var root_3152 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var linked_3153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3152, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3154 lang.IFn; if linked_3153 == nil { ifn_3154 = lang.IFn_Cast(root_3152) } else { ifn_3154 = nil }; var arg_3155 any = p1__677000329_SHARP___1; if linked_3153 == nil { arg_3151 = ifn_3154.Invoke_O__O(arg_3155) } else { arg_3151 = linked_3153.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3152, arg_3155) }; if linked_3149 == nil { return ifn_3150.Invoke_O__O(arg_3151) } else { return linked_3149.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3148, arg_3151) } }
//line :843:1
func A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_New() *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A{}; t.Ctor(); return t }
//line :843:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A) Ctor() {}
//line :843:1
func (t *A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A) Invoke_O_O__O(self, p1__677000329_SHARP___1 any) any { var root_3266 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3266, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3268 lang.IFn; if linked_3267 == nil { ifn_3268 = lang.IFn_Cast(root_3266) } else { ifn_3268 = nil }; var arg_3269 any; var root_3270 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3270, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3272 lang.IFn; if linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = p1__677000329_SHARP___1; if linked_3271 == nil { arg_3269 = ifn_3272.Invoke_O__O(arg_3273) } else { arg_3269 = linked_3271.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3270, arg_3273) }; if linked_3267 == nil { return ifn_3268.Invoke_O__O(arg_3269) } else { return linked_3267.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3266, arg_3269) } }







func A_arbace_cpp_abi_mangle_fn_A_New() *A_arbace_cpp_abi_mangle_fn_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_fn_A{}; t.Ctor(); return t }
//line :851:1
func (t *A_arbace_cpp_abi_mangle_fn_A) Ctor() {}
//line :851:1
func (t *A_arbace_cpp_abi_mangle_fn_A) Invoke_O_O_O__O(self, f__0, variant__1 any) any {





	var tmp1 any = A_arbace_cpp_abi_A_const_26; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_365.Invoke_O__O(f__0)) {
		return A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__0) } else {
//line :857:1
			var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_60, A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__0))

			if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_3409 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3411 lang.IFn; if linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3410 == nil { and__1927000168__auto____4 = ifn_3411.Invoke_O__O(arg_3412) } else { and__1927000168__auto____4 = linked_3410.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3409, arg_3412) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_3413 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(f__0); if linked_3414 == nil { tmp2 = ifn_3415.Invoke_O__O(arg_3416) } else { tmp2 = linked_3414.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3413, arg_3416) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :857:1
			if jrt.J2g_Truth(tmp2) { return Lit_60 } else { if A_arbace_cpp_abi_A_const_118 != nil {


				var root_3425 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3427 lang.IFn; if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp4 any = A_arbace_cpp_abi_A_const_202; var tmp5 any; var root_3434 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3434, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3436 lang.IFn; if linked_3435 == nil { ifn_3436 = lang.IFn_Cast(root_3434) } else { ifn_3436 = nil }; var arg_3437 any = lang.PersistentVector_EMPTY.Ref(); if linked_3435 == nil { tmp5 = ifn_3436.Invoke_O__O(arg_3437) } else { tmp5 = linked_3435.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3434, arg_3437) }; arg_3428 = tmp3.Invoke_O_O__O(tmp4, tmp5); if linked_3426 == nil { ifn_3427.Invoke_O__O(arg_3428) } else { linked_3426.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3425, arg_3428) }
//line :857:1
				var tmp6 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


					{ var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_136, nil); var tmp8 any; var root_3417 any = A_arbace_cpp_abi_A_const_366.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, A_arbace_cpp_abi_encoding_STAR__A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = f__0; var arg_3421 any = variant__1; if linked_3418 == nil { tmp8 = ifn_3419.Invoke_O_O__O(arg_3420, arg_3421) } else { tmp8 = linked_3418.(*A_arbace_cpp_abi_encoding_STAR__A).Invoke_O_O_O__O(root_3417, arg_3420, arg_3421) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref() }
//line :857:1
					return nil }(); var root_3422 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3422, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3424 lang.IFn


				if linked_3423 == nil { ifn_3424 = lang.IFn_Cast(root_3422) } else { ifn_3424 = nil }; if linked_3423 == nil { ifn_3424.Invoke__O() } else { linked_3423.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3422) }
//line :857:1
				if tmp9 != nil { panic(tmp9) }; return tmp6 } else { return nil } } } }
//line :851:1
func (t *A_arbace_cpp_abi_mangle_fn_A) Invoke_O_O__O(self, f__0 any) any {



	var root_3438 any = A_arbace_cpp_abi_A_const_367.GetRawRoot__O(); var linked_3439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3438, A_arbace_cpp_abi_mangle_fn_A_fn_class); var ifn_3440 lang.IFn; if linked_3439 == nil { ifn_3440 = lang.IFn_Cast(root_3438) } else { ifn_3440 = nil }; var arg_3441 any = f__0; var arg_3442 any; if linked_3439 == nil { return ifn_3440.Invoke_O_O__O(arg_3441, arg_3442) } else { return linked_3439.(*A_arbace_cpp_abi_mangle_fn_A).Invoke_O_O_O__O(root_3438, arg_3441, arg_3442)
	}
}




func A_arbace_cpp_abi_encoding_STAR__A_New() *A_arbace_cpp_abi_encoding_STAR__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_encoding_STAR__A{}; t.Ctor(); return t }
//line :862:1
func (t *A_arbace_cpp_abi_encoding_STAR__A) Ctor() {}
//line :862:1
func (t *A_arbace_cpp_abi_encoding_STAR__A) Invoke_O_O_O__O(self, f__0, variant__1 any) any {



	var tmp1 any = A_arbace_cpp_abi_A_const_233; var tmp2 any; var root_3443 any = A_arbace_cpp_abi_A_const_234.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_ffirst__1927000018_A_fn_class); var ifn_3445 lang.IFn

	if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3444 == nil { tmp2 = ifn_3445.Invoke_O__O(arg_3446) } else { tmp2 = linked_3444.(*aot_arbace_core.A_arbace_core_ffirst__1927000018_A).Invoke_O_O__O(root_3443, arg_3446) }
//line :866:1
	if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) {

		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_17, nil); var tmp4 any; var root_3447 any = A_arbace_cpp_abi_A_const_236.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, A_arbace_cpp_abi_local_enc_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any; var root_3451 any = A_arbace_cpp_abi_A_const_74.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any; var root_3455 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3456 == nil { arg_3454 = ifn_3457.Invoke_O__O(arg_3458) } else { arg_3454 = linked_3456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3455, arg_3458) }; if linked_3452 == nil { arg_3450 = ifn_3453.Invoke_O__O(arg_3454) } else { arg_3450 = linked_3452.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3451, arg_3454) }; if linked_3448 == nil { tmp4 = ifn_3449.Invoke_O__O(arg_3450) } else { tmp4 = linked_3448.(*A_arbace_cpp_abi_local_enc_A).Invoke_O_O__O(root_3447, arg_3450) }; var tmp5 any = tmp4; var tmp6 any; var root_3459 any = A_arbace_cpp_abi_A_const_366.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, A_arbace_cpp_abi_encoding_STAR__A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any; var root_3464 any = A_arbace_cpp_abi_A_const_28.GetRawRoot__O(); var linked_3465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3464, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3466 lang.IFn; if linked_3465 == nil { ifn_3466 = lang.IFn_Cast(root_3464) } else { ifn_3466 = nil }; var arg_3467 any = f__0; var arg_3468 any = A_arbace_cpp_abi_A_const_218; var arg_3469 any; var root_3470 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_3471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3470, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3472 lang.IFn; if linked_3471 == nil { ifn_3472 = lang.IFn_Cast(root_3470) } else { ifn_3472 = nil }; var arg_3473 any; var root_3474 any = A_arbace_cpp_abi_A_const_235.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3475 == nil { arg_3473 = ifn_3476.Invoke_O__O(arg_3477) } else { arg_3473 = linked_3475.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3474, arg_3477) }; if linked_3471 == nil { arg_3469 = ifn_3472.Invoke_O__O(arg_3473) } else { arg_3469 = linked_3471.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3470, arg_3473) }; if linked_3465 == nil { arg_3462 = ifn_3466.Invoke_O_O_O__O(arg_3467, arg_3468, arg_3469) } else { arg_3462 = linked_3465.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3464, arg_3467, arg_3468, arg_3469) }; var arg_3463 any = variant__1; if linked_3460 == nil { tmp6 = ifn_3461.Invoke_O_O__O(arg_3462, arg_3463) } else { tmp6 = linked_3460.(*A_arbace_cpp_abi_encoding_STAR__A).Invoke_O_O_O__O(root_3459, arg_3462, arg_3463) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref() } else {
//line :866:1
			if A_arbace_cpp_abi_A_const_118 != nil { var path__3 any; var root_3478 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_3479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3478, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3480 lang.IFn



				if linked_3479 == nil { ifn_3480 = lang.IFn_Cast(root_3478) } else { ifn_3480 = nil }; var arg_3481 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3479 == nil { path__3 = ifn_3480.Invoke_O__O(arg_3481) } else { path__3 = linked_3479.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3478, arg_3481) }
//line :866:1
				var ti__4 any = A_arbace_cpp_abi_A_const_368.Invoke_O__O(f__0); var uname__5 any; var fnbody__3575 any = A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_New_O_O_O(variant__1, f__0, ti__4); var tmp7 *jrt.Class
				var fncls__3574 /*line :866:1*/*jrt.Class = A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_fn_class





				if fncls__3574 == nil { var fncls__3574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__3575); A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_fn_class = fncls__3574d; tmp7 = fncls__3574d } else { tmp7 = fncls__3574 }; uname__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3575, tmp7, nil)
//line :866:1
				var enc__6 any; var tmp8 any; var root_3576 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3578 lang.IFn
































				if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any = path__3; if linked_3577 == nil { tmp8 = ifn_3578.Invoke_O__O(arg_3579) } else { tmp8 = linked_3577.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3576, arg_3579) }
//line :898:1
				if jrt.J2g_Truth(tmp8) {
					var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_379.Invoke_O__O(f__0)) { tmp10 = Lit_23 } else { tmp10 = nil }; enc__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10.Ref(), lang.IFn_Cast(uname__5).Invoke_O__O(Lit_24))).Ref() } else {
//line :898:1
						var tmp11 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_cpp_abi_A_const_380, path__3)

						if and__1927000168__auto____6 { var root_3580 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_3581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3580, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3582 lang.IFn; if linked_3581 == nil { ifn_3582 = lang.IFn_Cast(root_3580) } else { ifn_3582 = nil }; var arg_3583 any = A_arbace_cpp_abi_A_const_319.Invoke_O__O(f__0); if linked_3581 == nil { tmp11 = ifn_3582.Invoke_O__O(arg_3583) } else { tmp11 = linked_3581.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3580, arg_3583) } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :898:1
						if jrt.J2g_Truth(tmp11) {

							enc__6 = lang.IFn_Cast(uname__5).Invoke_O__O(Lit_25) } else {
//line :898:1
								if A_arbace_cpp_abi_A_const_118 != nil { var pre__6 any; var root_3584 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_3585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3584, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_3586 lang.IFn


									if linked_3585 == nil { ifn_3586 = lang.IFn_Cast(root_3584) } else { ifn_3586 = nil }; var arg_3587 any = path__3; if linked_3585 == nil { pre__6 = ifn_3586.Invoke_O__O(arg_3587) } else { pre__6 = linked_3585.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_3584, arg_3587) }
									var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, nil, Lit_17); var tmp13 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_381.Invoke_O__O(f__0)) { tmp13 = Lit_27 } else { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp15 *jrt.String; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_319.Invoke_O__O(f__0)) { tmp15 = Lit_12 } else { tmp15 = nil }; var tmp16 any = tmp15.Ref(); var tmp17 *jrt.String; var G__677000362__13_ any = A_arbace_cpp_abi_A_const_382.Invoke_O__O(f__0); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__677000362__13_) { case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__677000362__13_, Lit_28) { tmp17 = Lit_29; break L1 }; case 1216: if lang.Util_Equiv_O_O__Z_NoInit(G__677000362__13_, Lit_30) { tmp17 = Lit_31; break L1 }; default:}; tmp17 = nil}; tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17.Ref())) }; enc__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13.Ref(), lang.IFn_Cast(uname__5).Invoke_O__O(pre__6), nil)).Ref() } else {
//line :898:1
										enc__6 = nil } } }
//line :866:1
				var sig__7 any




































				if jrt.J2g_Truth(ti__4) { sig__7 = A_arbace_cpp_abi_A_const_383.Invoke_O__O(ti__4) } else { sig__7 = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__0) }
				var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp19 any; var tmp20 any; var and__1927000168__auto____11 any = ti__4
				if jrt.J2g_Truth(and__1927000168__auto____11) { var root_3589 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3591 lang.IFn; if linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_384); var arg_3592 any = tmp21.Invoke_O__O(A_arbace_cpp_abi_A_const_327.Invoke_O__O(f__0)); if linked_3590 == nil { tmp20 = ifn_3591.Invoke_O__O(arg_3592) } else { tmp20 = linked_3590.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3589, arg_3592) } } else { tmp20 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp20) { var root_3593 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3593, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3595 lang.IFn; if linked_3594 == nil { ifn_3595 = lang.IFn_Cast(root_3593) } else { ifn_3595 = nil }; var arg_3596 any = A_arbace_cpp_abi_A_const_310.Invoke_O__O(sig__7); if linked_3594 == nil { tmp19 = ifn_3595.Invoke_O__O(arg_3596) } else { tmp19 = linked_3594.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3593, arg_3596) } } else { tmp19 = nil }
//line :904:1
				var tmp22 any = tmp19; var tmp23 any; var root_3597 any = A_arbace_cpp_abi_A_const_321.GetRawRoot__O(); var linked_3598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3597, A_arbace_cpp_abi_bare_params_A_fn_class); var ifn_3599 lang.IFn


				if linked_3598 == nil { ifn_3599 = lang.IFn_Cast(root_3597) } else { ifn_3599 = nil }; var arg_3600 any; if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_381.Invoke_O__O(f__0)) { var root_3602 any = A_arbace_cpp_abi_A_const_111.GetRawRoot__O(); var linked_3603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3602, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3604 lang.IFn; if linked_3603 == nil { ifn_3604 = lang.IFn_Cast(root_3602) } else { ifn_3604 = nil }; var arg_3605 any = lang.Tuple_Create_O__IPersistentVector(A_arbace_cpp_abi_A_const_381.Invoke_O__O(f__0)); var arg_3606 any = A_arbace_cpp_abi_A_const_311.Invoke_O__O(sig__7); if linked_3603 == nil { arg_3600 = ifn_3604.Invoke_O_O__O(arg_3605, arg_3606) } else { arg_3600 = linked_3603.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3602, arg_3605, arg_3606) } } else { arg_3600 = A_arbace_cpp_abi_A_const_311.Invoke_O__O(sig__7) }; var arg_3601 any = A_arbace_cpp_abi_A_const_312.Invoke_O__O(sig__7); if linked_3598 == nil { tmp23 = ifn_3599.Invoke_O_O__O(arg_3600, arg_3601) } else { tmp23 = linked_3598.(*A_arbace_cpp_abi_bare_params_A).Invoke_O_O_O__O(root_3597, arg_3600, arg_3601) }
//line :904:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, enc__6, tmp22, tmp23)).Ref() } else {
//line :866:1
					return nil
				}
		}
}


func A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_abi_encoding_STAR__uname__677000356_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_encoding_STAR__uname__677000356_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :872:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_A) Ctor_O_O_O(c__variant, c__f, c__ti any) { t.F_variant = c__variant; t.F_f = c__f; t.F_ti = c__ti }
//line :872:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_A) Invoke_O_O__O(self, out__1 any) any {
	if jrt.J2g_Truth(t.F_ti) {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_369); if jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_cpp_abi_A_const_327.Invoke_O__O(t.F_f))) { var s__4 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 any; var root_3482 any = A_arbace_cpp_abi_A_const_370.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, A_arbace_cpp_abi_unqualified_name_A_fn_class); var ifn_3484 lang.IFn

			if linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any = t.F_f; var arg_3486 any = t.F_variant; if linked_3483 == nil { tmp5 = ifn_3484.Invoke_O_O__O(arg_3485, arg_3486) } else { tmp5 = linked_3483.(*A_arbace_cpp_abi_unqualified_name_A).Invoke_O_O_O__O(root_3482, arg_3485, arg_3486) }; s__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, out__1, tmp5)).Ref(); var root_3562 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_3566 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var tmp6 any = A_arbace_cpp_abi_A_const_215; var arg_3567 any = lang.Tuple_Create_O_O__IPersistentVector(tmp6, A_arbace_cpp_abi_A_const_378.Invoke_O__O(t.F_ti)); if linked_3563 == nil { ifn_3564.Invoke_O_O_O__O(arg_3565, arg_3566, arg_3567) } else { linked_3563.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3562, arg_3565, arg_3566, arg_3567) }
//line :874:1
			tmp2 = s__4 } else { var i__4 int32; var tmp7 any; var root_3487 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3487, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3489 lang.IFn


				if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_3488 == nil { tmp7 = ifn_3489.Invoke_O__O(arg_3490) } else { tmp7 = linked_3488.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3487, arg_3490) }; var tmp8 any = A_arbace_cpp_abi_A_const_215; i__4 = jrt.List_Cast(tmp7).IndexOf_O__I(lang.Tuple_Create_O_O__IPersistentVector(tmp8, A_arbace_cpp_abi_A_const_378.Invoke_O__O(t.F_ti)))
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__4)) { var s__5 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var root_3491 any = A_arbace_cpp_abi_A_const_370.GetRawRoot__O(); var linked_3492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3491, A_arbace_cpp_abi_unqualified_name_A_fn_class); var ifn_3493 lang.IFn
					if linked_3492 == nil { ifn_3493 = lang.IFn_Cast(root_3491) } else { ifn_3493 = nil }; var arg_3494 any = t.F_f; var arg_3495 any = t.F_variant; if linked_3492 == nil { tmp10 = ifn_3493.Invoke_O_O__O(arg_3494, arg_3495) } else { tmp10 = linked_3492.(*A_arbace_cpp_abi_unqualified_name_A).Invoke_O_O_O__O(root_3491, arg_3494, arg_3495) }; s__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, out__1, tmp10)).Ref(); var root_3568 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_3569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3568, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3570 lang.IFn; if linked_3569 == nil { ifn_3570 = lang.IFn_Cast(root_3568) } else { ifn_3570 = nil }; var arg_3571 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_3572 any = A_arbace_cpp_abi_A_const_9.GetRawRoot__O(); var tmp11 any = A_arbace_cpp_abi_A_const_215; var arg_3573 any = lang.Tuple_Create_O_O__IPersistentVector(tmp11, A_arbace_cpp_abi_A_const_378.Invoke_O__O(t.F_ti)); if linked_3569 == nil { ifn_3570.Invoke_O_O_O__O(arg_3571, arg_3572, arg_3573) } else { linked_3569.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_3568, arg_3571, arg_3572, arg_3573) }
//line :878:1
					tmp2 = s__5 } else {

						var root_3496 any = A_arbace_cpp_abi_A_const_203.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3496, A_arbace_cpp_abi_seq_id_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__4).Ref(); if linked_3497 == nil { tmp2 = ifn_3498.Invoke_O__O(arg_3499) } else { tmp2 = linked_3497.(*A_arbace_cpp_abi_seq_id_A).InvokePrim_O_J__O(root_3496, lang.RT_LongCast_O__J_NoInit(arg_3499)) } } }
//line :874:1
		var tmp12 any = tmp2; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, nil, Lit_17); var tmp14 any; var root_3500 any = A_arbace_cpp_abi_A_const_12.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3502 lang.IFn






		if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any = A_arbace_cpp_abi_A_const_13.GetRawRoot__O(); var arg_3504 any; var root_3505 any = A_arbace_cpp_abi_A_const_114.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any; var fnbody__3539 any = A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_New_O(t.F_ti); var tmp15 *jrt.Class; var fncls__3538 *jrt.Class = A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_fn_class; if fncls__3538 == nil { var fncls__3538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__3539); A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_fn_class = fncls__3538d; tmp15 = fncls__3538d } else { tmp15 = fncls__3538 }; arg_3508 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3539, tmp15, nil); var arg_3509 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(t.F_ti); if linked_3506 == nil { arg_3504 = ifn_3507.Invoke_O_O__O(arg_3508, arg_3509) } else { arg_3504 = linked_3506.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_3505, arg_3508, arg_3509) }; if linked_3501 == nil { tmp14 = ifn_3502.Invoke_O_O__O(arg_3503, arg_3504) } else { tmp14 = linked_3501.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3500, arg_3503, arg_3504) }
//line :874:1
		var tmp16 any = tmp14; var tmp17 any; var temp__1927000414__auto____8 any = A_arbace_cpp_abi_A_const_268.Invoke_O__O(t.F_ti)

















		if jrt.J2g_Truth(temp__1927000414__auto____8) { var q__9 any = temp__1927000414__auto____8; var saved__10 any; var root_3540 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3542 lang.IFn
			if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = A_arbace_cpp_abi_A_const_202.Get__O(); if linked_3541 == nil { saved__10 = ifn_3542.Invoke_O__O(arg_3543) } else { saved__10 = linked_3541.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3540, arg_3543) }
			var tmp18 *lang.Compiler_AOTFn; var fnbody__3556 any = A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_New_O_O(q__9, saved__10); var tmp19 *jrt.Class; var fncls__3555 *jrt.Class = A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_fn_class; if fncls__3555 == nil { var fncls__3555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__3556); A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_fn_class = fncls__3555d; tmp19 = fncls__3555d } else { tmp19 = fncls__3555 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3556, tmp19, nil); tmp17 = Up_Compiler_AOTFn_IFn(tmp18).Invoke__O() } else {
//line :892:1
				tmp17 = nil }
//line :874:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, tmp17, nil)).Ref())).Ref() } else {






















			var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp21 any; var root_3557 any = A_arbace_cpp_abi_A_const_370.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, A_arbace_cpp_abi_unqualified_name_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = t.F_f; var arg_3561 any = t.F_variant; if linked_3558 == nil { tmp21 = ifn_3559.Invoke_O_O__O(arg_3560, arg_3561) } else { tmp21 = linked_3558.(*A_arbace_cpp_abi_unqualified_name_A).Invoke_O_O_O__O(root_3557, arg_3560, arg_3561) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, out__1, tmp21)).Ref() } }
//line :881:1
func A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_New_O(p0 any) *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A{}; t.Ctor_O(p0); return t }
//line :881:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A) Ctor_O(c__ti any) { t.F_ti = c__ti }
//line :881:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *jrt.String; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(A_arbace_cpp_abi_A_const_371.Invoke_O__O(t.F_ti), i__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var t__6 any = temp__1927000414__auto____5; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 *jrt.String
															if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_255.Invoke_O__O(t__6)) { tmp4 = Lit_34 } else { tmp4 = nil }; var tmp5 any = tmp4.Ref(); var tmp6 *jrt.String; var temp__1927000408__auto____9 any = A_arbace_cpp_abi_A_const_372.Invoke_O__O(t__6)
															if jrt.J2g_Truth(temp__1927000408__auto____9) { var k__10 any = temp__1927000408__auto____9; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_35, nil); var tmp8 any; var tmp9 any; var root_3510 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3510, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3512 lang.IFn

		if linked_3511 == nil { ifn_3512 = lang.IFn_Cast(root_3510) } else { ifn_3512 = nil }; var arg_3513 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(k__10); if linked_3511 == nil { tmp9 = ifn_3512.Invoke_O__O(arg_3513) } else { tmp9 = linked_3511.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3510, arg_3513) }; if jrt.J2g_Truth(tmp9) { var root_3514 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3516 lang.IFn; if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(k__10); if linked_3515 == nil { tmp8 = ifn_3516.Invoke_O__O(arg_3517) } else { tmp8 = linked_3515.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3514, arg_3517) } } else { var tmp10 any = A_arbace_cpp_abi_A_const_373; if lang.Util_Equiv_O_O__Z_NoInit(tmp10, A_arbace_cpp_abi_A_const_218.Invoke_O__O(k__10)) {
			var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp12 any; var root_3518 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(k__10); if linked_3519 == nil { tmp12 = ifn_3520.Invoke_O__O(arg_3521) } else { tmp12 = linked_3519.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3518, arg_3521) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref() } else {
//line :885:1
				if A_arbace_cpp_abi_A_const_118 != nil {

					var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, nil, Lit_17); var tmp14 any; var root_3522 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_3524 lang.IFn; if linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(k__10); if linked_3523 == nil { tmp14 = ifn_3524.Invoke_O__O(arg_3525) } else { tmp14 = linked_3523.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_3522, arg_3525) }; var tmp15 any = tmp14; var tmp16 any; var root_3526 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(k__10); if linked_3527 == nil { tmp16 = ifn_3528.Invoke_O__O(arg_3529) } else { tmp16 = linked_3527.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3526, arg_3529) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, tmp16, nil)).Ref() } else {
//line :885:1
						tmp8 = nil } } }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)) } else {


							var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp18 any; var root_3530 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3532 lang.IFn; if linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(t__6); if linked_3531 == nil { tmp18 = ifn_3532.Invoke_O__O(arg_3533) } else { tmp18 = linked_3531.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3530, arg_3533) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)) }
//line :882:1
	tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref())) } else {
//line :881:1
		tmp2 = nil }; var tmp19 any = tmp2.Ref(); var tmp20 any; var root_3534 any = A_arbace_cpp_abi_A_const_269.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, A_arbace_cpp_abi_template_arg_A_fn_class); var ifn_3536 lang.IFn; if







	linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = a__2; if linked_3535 == nil { tmp20 = ifn_3536.Invoke_O__O(arg_3537) } else { tmp20 = linked_3535.(*A_arbace_cpp_abi_template_arg_A).Invoke_O_O__O(root_3534, arg_3537) }; return /*line :881:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20)).Ref() }












func A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_New_O_O(p0, p1 any) *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A{}; t.Ctor_O_O(p0, p1); return t }
//line :894:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A) Ctor_O_O(c__q, c__saved any) { t.F_q = c__q; t.F_saved = c__saved }
//line :894:1
func (t *A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil); var tmp3 any; var root_3544 any = A_arbace_cpp_abi_A_const_374.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3544, A_arbace_cpp_abi_mangle_constraint_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = A_arbace_cpp_abi_A_const_375.Invoke_O__O(t.F_q); var arg_3548 any = A_arbace_cpp_abi_A_const_376.Invoke_O__O(t.F_q); var arg_3549 any; var tmp4 *lang.Keyword = A_arbace_cpp_abi_A_const_377; var tmp5 any; var t_ any = t.F_q; t.F_q = nil; tmp5 = t_; arg_3549 = tmp4.Invoke_O__O(tmp5); if linked_3545 == nil { tmp3 = ifn_3546.Invoke_O_O_O__O(arg_3547, arg_3548, arg_3549) } else { tmp3 = linked_3545.(*A_arbace_cpp_abi_mangle_constraint_A).InvokePrim_O_O_O_J__O(root_3544, arg_3547, arg_3548, lang.RT_LongCast_O__J_NoInit(arg_3549)) }; tmp1 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() }; return nil }(); if tmp6 != nil { if lang.ExceptionInfo_InstanceOf(tmp6) { var ___3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp6); var root_3550 any = A_arbace_cpp_abi_A_const_95.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_3552 lang.IFn; _ = ___3
													if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = A_arbace_cpp_abi_A_const_202.Get__O(); var arg_3554 any; var t__2 any = t.F_saved; t.F_saved = nil; arg_3554 = t__2; if linked_3551 == nil { ifn_3552.Invoke_O_O__O(arg_3553, arg_3554) } else { linked_3551.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_3550, arg_3553, arg_3554) }
//line :894:1
	tmp1 = nil } else { panic(tmp6) } }; return tmp1 }














func A_arbace_cpp_abi_mangle_var_A_New() *A_arbace_cpp_abi_mangle_var_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_var_A{}; t.Ctor(); return t }
//line :909:1
func (t *A_arbace_cpp_abi_mangle_var_A) Ctor() {}
//line :909:1
func (t *A_arbace_cpp_abi_mangle_var_A) Invoke_O_O__O(self, v__0 any) any { var path__2 any; var root_3607 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_3608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3607, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3609 lang.IFn; if


	linked_3608 == nil { ifn_3609 = lang.IFn_Cast(root_3607) } else { ifn_3609 = nil }; var arg_3610 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(v__0); if linked_3608 == nil { path__2 = ifn_3609.Invoke_O__O(arg_3610) } else { path__2 = linked_3608.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3607, arg_3610) }; var ti__3 any = /*line :909:1*/A_arbace_cpp_abi_A_const_368.Invoke_O__O(v__0); if




	jrt.J2g_Truth(ti__3) {

		var root_3673 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3673, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3675 lang.IFn; if linked_3674 == nil { ifn_3675 = lang.IFn_Cast(root_3673) } else { ifn_3675 = nil }; var arg_3676 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_202; var tmp3 any; var root_3682 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3682, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3684 lang.IFn; if linked_3683 == nil { ifn_3684 = lang.IFn_Cast(root_3682) } else { ifn_3684 = nil }; var arg_3685 any = lang.PersistentVector_EMPTY.Ref(); if linked_3683 == nil { tmp3 = ifn_3684.Invoke_O__O(arg_3685) } else { tmp3 = linked_3683.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3682, arg_3685) }; arg_3676 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_3674 == nil { ifn_3675.Invoke_O__O(arg_3676) } else { linked_3674.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3673, arg_3676) }
//line :914:1
		var tmp4 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


			{ var tmp5 any; var root_3611 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3611, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3613 lang.IFn; if linked_3612 == nil { ifn_3613 = lang.IFn_Cast(root_3611) } else { ifn_3613 = nil }; var arg_3614 any = path__2; if linked_3612 == nil { tmp5 = ifn_3613.Invoke_O__O(arg_3614) } else { tmp5 = linked_3612.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3611, arg_3614) }; if jrt.J2g_Truth(tmp5) {
				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_136, nil, nil); var tmp7 any; var root_3615 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_3616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3615, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_3617 lang.IFn; if linked_3616 == nil { ifn_3617 = lang.IFn_Cast(root_3615) } else { ifn_3617 = nil }; var arg_3618 any = Lit_24; var arg_3619 any = A_arbace_cpp_abi_A_const_378.Invoke_O__O(ti__3); var arg_3620 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0); if linked_3616 == nil { tmp7 = ifn_3617.Invoke_O_O_O__O(arg_3618, arg_3619, arg_3620) } else { tmp7 = linked_3616.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_3615, arg_3618, arg_3619, arg_3620) }; var tmp8 any = tmp7; var tmp9 any; var root_3621 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3621, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(ti__3); if linked_3622 == nil { tmp9 = ifn_3623.Invoke_O__O(arg_3624) } else { tmp9 = linked_3622.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_3621, arg_3624) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9)).Ref() } else {
					var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil, nil, Lit_17); var tmp11 any; var root_3625 any = A_arbace_cpp_abi_A_const_227.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, A_arbace_cpp_abi_template_prefix_A_fn_class); var ifn_3627 lang.IFn; if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any; var root_3631 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = path__2; if linked_3632 == nil { arg_3628 = ifn_3633.Invoke_O__O(arg_3634) } else { arg_3628 = linked_3632.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_3631, arg_3634) }; var arg_3629 any = A_arbace_cpp_abi_A_const_378.Invoke_O__O(ti__3); var arg_3630 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0); if linked_3626 == nil { tmp11 = ifn_3627.Invoke_O_O_O__O(arg_3628, arg_3629, arg_3630) } else { tmp11 = linked_3626.(*A_arbace_cpp_abi_template_prefix_A).Invoke_O_O_O_O__O(root_3625, arg_3628, arg_3629, arg_3630) }; var tmp12 any = tmp11; var tmp13 any; var root_3635 any = A_arbace_cpp_abi_A_const_228.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, A_arbace_cpp_abi_template_args_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any = A_arbace_cpp_abi_A_const_244.Invoke_O__O(ti__3); if linked_3636 == nil { tmp13 = ifn_3637.Invoke_O__O(arg_3638) } else { tmp13 = linked_3636.(*A_arbace_cpp_abi_template_args_A).Invoke_O_O__O(root_3635, arg_3638) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13, nil)).Ref() } }
//line :914:1
			return nil }(); var root_3639 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3641 lang.IFn

		if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; if linked_3640 == nil { ifn_3641.Invoke__O() } else { linked_3640.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3639) }
//line :914:1
		if tmp14 != nil { panic(tmp14) }; return tmp4 } else { var tmp15 any = A_arbace_cpp_abi_A_const_26; if lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_cpp_abi_A_const_365.Invoke_O__O(v__0)) {





			return A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0) } else {
//line :914:1
				var tmp16 any; var and__1927000168__auto____4 any; var root_3642 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3642, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3644 lang.IFn






				if linked_3643 == nil { ifn_3644 = lang.IFn_Cast(root_3642) } else { ifn_3644 = nil }; var arg_3645 any = path__2; if linked_3643 == nil { and__1927000168__auto____4 = ifn_3644.Invoke_O__O(arg_3645) } else { and__1927000168__auto____4 = linked_3643.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3642, arg_3645) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_3646 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_3647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3646, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3648 lang.IFn; if linked_3647 == nil { ifn_3648 = lang.IFn_Cast(root_3646) } else { ifn_3648 = nil }; var arg_3649 any = A_arbace_cpp_abi_A_const_379.Invoke_O__O(v__0); if linked_3647 == nil { tmp16 = ifn_3648.Invoke_O__O(arg_3649) } else { tmp16 = linked_3647.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3646, arg_3649) } } else { tmp16 = and__1927000168__auto____4 }
//line :914:1
				if jrt.J2g_Truth(tmp16) {






					return A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0) } else {
//line :914:1
						if A_arbace_cpp_abi_A_const_118 != nil {







							var root_3686 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3686, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3688 lang.IFn; if linked_3687 == nil { ifn_3688 = lang.IFn_Cast(root_3686) } else { ifn_3688 = nil }; var arg_3689 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp18 any = A_arbace_cpp_abi_A_const_202; var tmp19 any; var root_3695 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3696 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3695, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3697 lang.IFn; if linked_3696 == nil { ifn_3697 = lang.IFn_Cast(root_3695) } else { ifn_3697 = nil }; var arg_3698 any = lang.PersistentVector_EMPTY.Ref(); if linked_3696 == nil { tmp19 = ifn_3697.Invoke_O__O(arg_3698) } else { tmp19 = linked_3696.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3695, arg_3698) }; arg_3689 = tmp17.Invoke_O_O__O(tmp18, tmp19); if linked_3687 == nil { ifn_3688.Invoke_O__O(arg_3689) } else { linked_3687.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3686, arg_3689) }
//line :914:1
							var tmp20 any; tmp30 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








								{ var tmp21 any; var root_3650 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3650, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3652 lang.IFn
									if linked_3651 == nil { ifn_3652 = lang.IFn_Cast(root_3650) } else { ifn_3652 = nil }; var arg_3653 any = path__2; if linked_3651 == nil { tmp21 = ifn_3652.Invoke_O__O(arg_3653) } else { tmp21 = linked_3651.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3650, arg_3653) }
//line :923:1
									if jrt.J2g_Truth(tmp21) {
										var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_168, nil); var tmp23 any; var root_3654 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3654, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3656 lang.IFn; if linked_3655 == nil { ifn_3656 = lang.IFn_Cast(root_3654) } else { ifn_3656 = nil }; var arg_3657 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0); if linked_3655 == nil { tmp23 = ifn_3656.Invoke_O__O(arg_3657) } else { tmp23 = linked_3655.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3654, arg_3657) }; tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref() } else {
//line :923:1
											if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_cpp_abi_A_const_385, path__2) {


												var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_169, nil); var tmp25 any; var root_3658 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3658, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3660 lang.IFn; if linked_3659 == nil { ifn_3660 = lang.IFn_Cast(root_3658) } else { ifn_3660 = nil }; var arg_3661 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0); if linked_3659 == nil { tmp25 = ifn_3660.Invoke_O__O(arg_3661) } else { tmp25 = linked_3659.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3658, arg_3661) }; tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp25)).Ref() } else {
//line :923:1
													if A_arbace_cpp_abi_A_const_118 != nil {



														var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil, nil, Lit_17); var tmp27 any; var root_3662 any = A_arbace_cpp_abi_A_const_237.GetRawRoot__O(); var linked_3663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3662, A_arbace_cpp_abi_mangle_prefix_A_fn_class); var ifn_3664 lang.IFn; if linked_3663 == nil { ifn_3664 = lang.IFn_Cast(root_3662) } else { ifn_3664 = nil }; var arg_3665 any = path__2; if linked_3663 == nil { tmp27 = ifn_3664.Invoke_O__O(arg_3665) } else { tmp27 = linked_3663.(*A_arbace_cpp_abi_mangle_prefix_A).Invoke_O_O__O(root_3662, arg_3665) }; var tmp28 any = tmp27; var tmp29 any; var root_3666 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3666, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3668 lang.IFn; if linked_3667 == nil { ifn_3668 = lang.IFn_Cast(root_3666) } else { ifn_3668 = nil }; var arg_3669 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(v__0); if linked_3667 == nil { tmp29 = ifn_3668.Invoke_O__O(arg_3669) } else { tmp29 = linked_3667.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3666, arg_3669) }; tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp28, tmp29, nil)).Ref() } else {
//line :923:1
															tmp20 = nil } } } }
//line :914:1
								return nil }(); var root_3670 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3670, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3672 lang.IFn







							if linked_3671 == nil { ifn_3672 = lang.IFn_Cast(root_3670) } else { ifn_3672 = nil }; if linked_3671 == nil { ifn_3672.Invoke__O() } else { linked_3671.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3670) }
//line :914:1
							if tmp30 != nil { panic(tmp30) }; return tmp20 } else { return nil } } } } }














func A_arbace_cpp_abi_local_encoding_A_New() *A_arbace_cpp_abi_local_encoding_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_local_encoding_A{}; t.Ctor(); return t }
//line :929:1
func (t *A_arbace_cpp_abi_local_encoding_A) Ctor() {}
//line :929:1
func (t *A_arbace_cpp_abi_local_encoding_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_60, A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__0))
	if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_3699 any = A_arbace_cpp_abi_A_const_103.GetRawRoot__O(); var linked_3700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3699, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3701 lang.IFn; if linked_3700 == nil { ifn_3701 = lang.IFn_Cast(root_3699) } else { ifn_3701 = nil }; var arg_3702 any = A_arbace_cpp_abi_A_const_218.Invoke_O__O(f__0); if linked_3700 == nil { and__1927000168__auto____3 = ifn_3701.Invoke_O__O(arg_3702) } else { and__1927000168__auto____3 = linked_3700.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3699, arg_3702) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_3703 any = A_arbace_cpp_abi_A_const_90.GetRawRoot__O(); var linked_3704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3703, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3705 lang.IFn; if linked_3704 == nil { ifn_3705 = lang.IFn_Cast(root_3703) } else { ifn_3705 = nil }; var arg_3706 any = A_arbace_cpp_abi_A_const_81.Invoke_O__O(f__0); if linked_3704 == nil { tmp1 = ifn_3705.Invoke_O__O(arg_3706) } else { tmp1 = linked_3704.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3703, arg_3706) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }
//line :933:1
	if jrt.J2g_Truth(tmp1) { return Lit_61 } else { var tmp2 any = A_arbace_cpp_abi_A_const_26; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_cpp_abi_A_const_365.Invoke_O__O(f__0)) {

		var root_3707 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3707, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3709 lang.IFn; if linked_3708 == nil { ifn_3709 = lang.IFn_Cast(root_3707) } else { ifn_3709 = nil }; var arg_3710 any = A_arbace_cpp_abi_A_const_127.Invoke_O__O(f__0); if linked_3708 == nil { return ifn_3709.Invoke_O__O(arg_3710) } else { return linked_3708.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3707, arg_3710) } } else {
//line :933:1
			if A_arbace_cpp_abi_A_const_118 != nil { var v__2 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_386)



				if jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_cpp_abi_A_const_327.Invoke_O__O(f__0))) { v__2 = A_arbace_cpp_abi_A_const_143 } else { v__2 = nil }
				if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_202.Get__O()) { var root_3711 any = A_arbace_cpp_abi_A_const_366.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3711, A_arbace_cpp_abi_encoding_STAR__A_fn_class); var ifn_3713 lang.IFn; if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = f__0; var arg_3715 any = v__2; if linked_3712 == nil { return ifn_3713.Invoke_O_O__O(arg_3714, arg_3715) } else { return linked_3712.(*A_arbace_cpp_abi_encoding_STAR__A).Invoke_O_O_O__O(root_3711, arg_3714, arg_3715) } } else { var root_3724 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3724, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3726 lang.IFn; if linked_3725 == nil { ifn_3726 = lang.IFn_Cast(root_3724) } else { ifn_3726 = nil }; var arg_3727 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp5 any = A_arbace_cpp_abi_A_const_202; var tmp6 any; var root_3733 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = lang.PersistentVector_EMPTY.Ref(); if linked_3734 == nil { tmp6 = ifn_3735.Invoke_O__O(arg_3736) } else { tmp6 = linked_3734.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3733, arg_3736) }; arg_3727 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_3725 == nil { ifn_3726.Invoke_O__O(arg_3727) } else { linked_3725.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3724, arg_3727) }; var tmp7 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3716 any = A_arbace_cpp_abi_A_const_366.GetRawRoot__O(); var linked_3717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3716, A_arbace_cpp_abi_encoding_STAR__A_fn_class); var ifn_3718 lang.IFn; if linked_3717 == nil { ifn_3718 = lang.IFn_Cast(root_3716) } else { ifn_3718 = nil }; var arg_3719 any = f__0; var arg_3720 any = v__2; if linked_3717 == nil { tmp7 = ifn_3718.Invoke_O_O__O(arg_3719, arg_3720) } else { tmp7 = linked_3717.(*A_arbace_cpp_abi_encoding_STAR__A).Invoke_O_O_O__O(root_3716, arg_3719, arg_3720) } }; return nil }(); var root_3721 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3721, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3723 lang.IFn; if linked_3722 == nil { ifn_3723 = lang.IFn_Cast(root_3721) } else { ifn_3723 = nil }; if linked_3722 == nil { ifn_3723.Invoke__O() } else { linked_3722.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3721) }; if tmp8 != nil { panic(tmp8) }; return tmp7 } } else {
//line :933:1
					return nil
				}
		}
	}
}


func A_arbace_cpp_abi_mangle_local_static_A_New() *A_arbace_cpp_abi_mangle_local_static_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_local_static_A{}; t.Ctor(); return t }
//line :940:1
func (t *A_arbace_cpp_abi_mangle_local_static_A) Ctor() {}
//line :940:1
func (t *A_arbace_cpp_abi_mangle_local_static_A) InvokePrim_O_O_O_J__O(self, f__0, nm__1 any, disc__2 int64) any { var enc__4 any; var root_3750 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3750, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3752 lang.IFn; if


	linked_3751 == nil { ifn_3752 = lang.IFn_Cast(root_3750) } else { ifn_3752 = nil }; var arg_3753 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_202; var tmp3 any; var root_3759 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3760 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3759, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3761 lang.IFn; if linked_3760 == nil { ifn_3761 = lang.IFn_Cast(root_3759) } else { ifn_3761 = nil }; var arg_3762 any = lang.PersistentVector_EMPTY.Ref(); if linked_3760 == nil { tmp3 = ifn_3761.Invoke_O__O(arg_3762) } else { tmp3 = linked_3760.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3759, arg_3762) }; arg_3753 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_3751 == nil { ifn_3752.Invoke_O__O(arg_3753) } else { linked_3751.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3750, arg_3753) }; var tmp4 *lang.Compiler_AOTFn; var fnbody__3745 any = A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_New_O(f__0); var tmp5 *jrt.Class; var fncls__3744 *jrt.Class = A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_fn_class; if fncls__3744 == nil { var fncls__3744d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, fnbody__3745); A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_fn_class = fncls__3744d; tmp5 = fncls__3744d } else { tmp5 = fncls__3744 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3745, tmp5, nil); enc__4 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O(); var tmp6 /*line :944:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil, Lit_17, nil, nil); var tmp7 any; var root_3746 any = A_arbace_cpp_abi_A_const_209.GetRawRoot__O(); var linked_3747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3746, A_arbace_cpp_abi_source_name_A_fn_class); var ifn_3748 lang.IFn; if linked_3747 == nil { ifn_3748 = lang.IFn_Cast(root_3746) } else { ifn_3748 = nil }; var arg_3749 any = nm__1; if linked_3747 == nil { tmp7 = ifn_3748.Invoke_O__O(arg_3749) } else { tmp7 = linked_3747.(*A_arbace_cpp_abi_source_name_A).Invoke_O_O__O(root_3746, arg_3749) }; var tmp8 any = tmp7; var tmp9 *jrt.String; if lang.Numbers_IsZero_J__Z_NoInit(disc__2) { tmp9 = Lit_24 } else { if lang.Numbers_Lt_J_J__Z_NoInit(disc__2, 11) { tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(disc__2)).Ref())) } else { if A_arbace_cpp_abi_A_const_118 != nil { tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_139, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(disc__2)).Ref(), nil)) } else { tmp9 = nil } } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, enc__4, nil, tmp8, tmp9.Ref())).Ref() }
//line :940:1
func (t *A_arbace_cpp_abi_mangle_local_static_A) Invoke_O_O_O_O__O(self, f__0, nm__1, p_disc__2 any) any { return t.InvokePrim_O_O_O_J__O(self, f__0, nm__1, lang.RT_LongCast_O__J_NoInit(p_disc__2)) }


func A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_New_O(p0 any) *A_arbace_cpp_abi_mangle_local_static_fn__677000366_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_local_static_fn__677000366_A{}; t.Ctor_O(p0); return t }
//line :943:1
func (t *A_arbace_cpp_abi_mangle_local_static_fn__677000366_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :943:1
func (t *A_arbace_cpp_abi_mangle_local_static_fn__677000366_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3737 any = A_arbace_cpp_abi_A_const_231.GetRawRoot__O(); var linked_3738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3737, A_arbace_cpp_abi_local_encoding_A_fn_class); var ifn_3739 lang.IFn; if linked_3738 == nil { ifn_3739 = lang.IFn_Cast(root_3737) } else { ifn_3739 = nil }; var arg_3740 any; var t_ any = t.F_f; t.F_f = nil; arg_3740 = t_; if linked_3738 == nil { tmp1 = ifn_3739.Invoke_O__O(arg_3740) } else { tmp1 = linked_3738.(*A_arbace_cpp_abi_local_encoding_A).Invoke_O_O__O(root_3737, arg_3740) } }; return nil }(); var root_3741 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3743 lang.IFn; if linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; if linked_3742 == nil { ifn_3743.Invoke__O() } else { linked_3742.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3741) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }


func A_arbace_cpp_abi_mangle_type_name_A_New() *A_arbace_cpp_abi_mangle_type_name_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_type_name_A{}; t.Ctor(); return t }
//line :946:1
func (t *A_arbace_cpp_abi_mangle_type_name_A) Ctor() {}
//line :946:1
func (t *A_arbace_cpp_abi_mangle_type_name_A) Invoke_O_O__O(self, t__0 any) any {


	var root_3770 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3770, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3772 lang.IFn; if linked_3771 == nil { ifn_3772 = lang.IFn_Cast(root_3770) } else { ifn_3772 = nil }; var arg_3773 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_202; var tmp3 any; var root_3779 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3779, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3781 lang.IFn; if linked_3780 == nil { ifn_3781 = lang.IFn_Cast(root_3779) } else { ifn_3781 = nil }; var arg_3782 any = lang.PersistentVector_EMPTY.Ref(); if linked_3780 == nil { tmp3 = ifn_3781.Invoke_O__O(arg_3782) } else { tmp3 = linked_3780.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3779, arg_3782) }; arg_3773 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_3771 == nil { ifn_3772.Invoke_O__O(arg_3773) } else { linked_3771.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3770, arg_3773) }
//line :946:1
	var tmp4 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var root_3763 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3763, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3765 lang.IFn; if linked_3764 == nil { ifn_3765 = lang.IFn_Cast(root_3763) } else { ifn_3765 = nil }; var arg_3766 any = t__0; if linked_3764 == nil { tmp4 = ifn_3765.Invoke_O__O(arg_3766) } else { tmp4 = linked_3764.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3763, arg_3766) } }
//line :946:1
		return nil }(); var root_3767 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3767, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3769 lang.IFn


	if linked_3768 == nil { ifn_3769 = lang.IFn_Cast(root_3767) } else { ifn_3769 = nil }; if linked_3768 == nil { ifn_3769.Invoke__O() } else { linked_3768.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3767) }
//line :946:1
	if tmp5 != nil { panic(tmp5) }; return tmp4
}



func A_arbace_cpp_abi_mangle_ctor_vtable_name_A_New() *A_arbace_cpp_abi_mangle_ctor_vtable_name_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mangle_ctor_vtable_name_A{}; t.Ctor(); return t }
//line :951:1
func (t *A_arbace_cpp_abi_mangle_ctor_vtable_name_A) Ctor() {}
//line :951:1
func (t *A_arbace_cpp_abi_mangle_ctor_vtable_name_A) InvokePrim_O_O_J_O__O(self, derived__0 any, off__1 int64, base__2 any) any {



	var root_3794 any = A_arbace_cpp_abi_A_const_323.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3796 lang.IFn; if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_abi_A_const_324.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_abi_A_const_202; var tmp3 any; var root_3803 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3803, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3805 lang.IFn; if linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = lang.PersistentVector_EMPTY.Ref(); if linked_3804 == nil { tmp3 = ifn_3805.Invoke_O__O(arg_3806) } else { tmp3 = linked_3804.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3803, arg_3806) }; arg_3797 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_3795 == nil { ifn_3796.Invoke_O__O(arg_3797) } else { linked_3795.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3794, arg_3797) }
//line :951:1
	var tmp4 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil, nil, Lit_100, nil); var tmp6 any; var root_3783 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3783, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3785 lang.IFn; if linked_3784 == nil { ifn_3785 = lang.IFn_Cast(root_3783) } else { ifn_3785 = nil }; var arg_3786 any = derived__0; if linked_3784 == nil { tmp6 = ifn_3785.Invoke_O__O(arg_3786) } else { tmp6 = linked_3784.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3783, arg_3786) }; var tmp7 any = tmp6; var tmp8 any = jrt.Long_ValueOf_J__Long_NoInit(off__1).Ref(); var tmp9 any; var root_3787 any = A_arbace_cpp_abi_A_const_259.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, A_arbace_cpp_abi_mangle_type_STAR__A_fn_class); var ifn_3789 lang.IFn; if linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = base__2; if linked_3788 == nil { tmp9 = ifn_3789.Invoke_O__O(arg_3790) } else { tmp9 = linked_3788.(*A_arbace_cpp_abi_mangle_type_STAR__A).Invoke_O_O__O(root_3787, arg_3790) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, tmp8, nil, tmp9)).Ref() }
//line :951:1
		return nil }(); var root_3791 any = A_arbace_cpp_abi_A_const_322.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3793 lang.IFn



	if linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; if linked_3792 == nil { ifn_3793.Invoke__O() } else { linked_3792.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3791) }
//line :951:1
	if tmp10 != nil { panic(tmp10) }; return tmp4 }
//line :951:1
func (t *A_arbace_cpp_abi_mangle_ctor_vtable_name_A) Invoke_O_O_O_O__O(self, derived__0, p_off__1, base__2 any) any { return t.InvokePrim_O_O_J_O__O(self, derived__0, lang.RT_LongCast_O__J_NoInit(p_off__1), base__2) }










func A_arbace_cpp_abi_merge_class_A_New() *A_arbace_cpp_abi_merge_class_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_merge_class_A{}; t.Ctor(); return t }
//line :962:1
func (t *A_arbace_cpp_abi_merge_class_A) Ctor() {}
//line :962:1
func (t *A_arbace_cpp_abi_merge_class_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_cpp_abi_A_const_387) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_cpp_abi_A_const_387) { return a__0 } else { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_cpp_abi_A_const_388); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_cpp_abi_A_const_388) }; if tmp1 { return A_arbace_cpp_abi_A_const_388 } else { var tmp2 bool; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_cpp_abi_A_const_389)
		if or__1927000174__auto____3_2 { tmp2 = or__1927000174__auto____3_2 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_cpp_abi_A_const_389) }
//line :963:1
		if tmp2 { return A_arbace_cpp_abi_A_const_389 } else { var tmp3 bool; var or__1927000174__auto____3_3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_cpp_abi_A_const_390)
			if or__1927000174__auto____3_3 { tmp3 = or__1927000174__auto____3_3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_cpp_abi_A_const_390) }
//line :963:1
			if tmp3 { return A_arbace_cpp_abi_A_const_388 } else { if A_arbace_cpp_abi_A_const_118 != nil { return A_arbace_cpp_abi_A_const_391 } else { return nil
			}
			} } } } } } }
func A_arbace_cpp_abi_scalar_class_A_New() *A_arbace_cpp_abi_scalar_class_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_scalar_class_A{}; t.Ctor(); return t }
//line :966:1
func (t *A_arbace_cpp_abi_scalar_class_A) Ctor() {}
//line :966:1
func (t *A_arbace_cpp_abi_scalar_class_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var root_3807 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, A_arbace_cpp_abi_unq_A_fn_class); var ifn_3809 lang.IFn; if
										linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = t__0; if linked_3808 == nil { t__2 = ifn_3809.Invoke_O__O(arg_3810) } else { t__2 = linked_3808.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_3807, arg_3810) }; var tmp1 any; var root_3811 any =
										A_arbace_cpp_abi_A_const_40.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, A_arbace_cpp_abi_floating_QMARK__A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = t__2; if linked_3812 == nil { tmp1 = ifn_3813.Invoke_O__O(arg_3814) } else { tmp1 = linked_3812.(*A_arbace_cpp_abi_floating_QMARK__A).Invoke_O_O__O(root_3811, arg_3814) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_cpp_abi_A_const_181; var tmp3 any; var root_3815 any = A_arbace_cpp_abi_A_const_30.GetRawRoot__O(); var linked_3816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3815, A_arbace_cpp_abi_bn_A_fn_class); var ifn_3817 lang.IFn; if linked_3816 == nil { ifn_3817 = lang.IFn_Cast(root_3815) } else { ifn_3817 = nil }; var arg_3818 any = t__2; if linked_3816 == nil { tmp3 = ifn_3817.Invoke_O__O(arg_3818) } else { tmp3 = linked_3816.(*A_arbace_cpp_abi_bn_A).Invoke_O_O__O(root_3815, arg_3818) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { return A_arbace_cpp_abi_A_const_390 } else { return A_arbace_cpp_abi_A_const_391 } } else { var tmp4 any = A_arbace_cpp_abi_A_const_41; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__2)) { return A_arbace_cpp_abi_A_const_389 } else { if A_arbace_cpp_abi_A_const_118 != nil { return A_arbace_cpp_abi_A_const_389 } else { return nil } } } }



func A_arbace_cpp_abi_mark_BANG__A_New() *A_arbace_cpp_abi_mark_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mark_BANG__A{}; t.Ctor(); return t }
//line :972:1
func (t *A_arbace_cpp_abi_mark_BANG__A) Ctor() {}
//line :972:1
func (t *A_arbace_cpp_abi_mark_BANG__A) InvokePrim_O_O_J_O_J__O(self, acc__0 any, e__1 int64, cls__2 any, end__3 int64) any {
	if lang.Numbers_Lt_J_J__Z_NoInit(e__1, 2) { var root_3819 any = A_arbace_cpp_abi_A_const_50.GetRawRoot__O(); var linked_3820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3819, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3821 lang.IFn; if linked_3820 == nil { ifn_3821 = lang.IFn_Cast(root_3819) } else { ifn_3821 = nil }; var arg_3822 any = acc__0; var arg_3823 any; var fnbody__3839 any = A_arbace_cpp_abi_mark_BANG__fn__677000374_A_New_J_O_J(e__1, cls__2, end__3); var tmp1 *jrt.Class; var fncls__3838 *jrt.Class = A_arbace_cpp_abi_mark_BANG__fn__677000374_A_fn_class; if fncls__3838 == nil { var fncls__3838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, fnbody__3839); A_arbace_cpp_abi_mark_BANG__fn__677000374_A_fn_class = fncls__3838d; tmp1 = fncls__3838d } else { tmp1 = fncls__3838 }; arg_3823 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3839, tmp1, nil); if linked_3820 == nil { return ifn_3821.Invoke_O_O__O(arg_3822, arg_3823) } else { return linked_3820.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_3819, arg_3822, arg_3823) } } else { return nil } }
//line :972:1
func (t *A_arbace_cpp_abi_mark_BANG__A) Invoke_O_O_O_O_O__O(self, acc__0, p_e__1, cls__2, p_end__3 any) any { return t.InvokePrim_O_O_J_O_J__O(self, acc__0, lang.RT_LongCast_O__J_NoInit(p_e__1), cls__2, lang.RT_LongCast_O__J_NoInit(p_end__3)) }
func A_arbace_cpp_abi_mark_BANG__fn__677000374_A_New_J_O_J(p0 int64, p1 any, p2 int64) *A_arbace_cpp_abi_mark_BANG__fn__677000374_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_mark_BANG__fn__677000374_A{}; t.Ctor_J_O_J(p0, p1, p2); return t }
//line :973:1
func (t *A_arbace_cpp_abi_mark_BANG__fn__677000374_A) Ctor_J_O_J(c__e int64, c__cls any, c__end int64) { t.F_e = c__e; t.F_cls = c__cls; t.F_end = c__end }
//line :973:1
func (t *A_arbace_cpp_abi_mark_BANG__fn__677000374_A) Invoke_O_O__O(self, p1__677000373_SHARP___1 any) any { var root_3824 any = A_arbace_cpp_abi_A_const_51.GetRawRoot__O(); var linked_3825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3824, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3826 lang.IFn; if linked_3825 == nil { ifn_3826 = lang.IFn_Cast(root_3824) } else { ifn_3826 = nil }; var arg_3827 any; var root_3831 any = A_arbace_cpp_abi_A_const_51.GetRawRoot__O(); var linked_3832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3831, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3833 lang.IFn; if linked_3832 == nil { ifn_3833 = lang.IFn_Cast(root_3831) } else { ifn_3833 = nil }; var arg_3834 any = p1__677000373_SHARP___1; var arg_3835 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_e).Ref(); var arg_3836 any = A_arbace_cpp_abi_A_const_392.GetRawRoot__O(); var arg_3837 any = t.F_cls; if linked_3832 == nil { arg_3827 = ifn_3833.Invoke_O_O_O_O__O(arg_3834, arg_3835, arg_3836, arg_3837) } else { arg_3827 = linked_3832.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3831, arg_3834, arg_3835, arg_3836, arg_3837) }; var arg_3828 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(2, t.F_e)).Ref(); var arg_3829 any = A_arbace_cpp_abi_A_const_138.GetRawRoot__O(); var arg_3830 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_end).Ref(); if linked_3825 == nil { return ifn_3826.Invoke_O_O_O_O__O(arg_3827, arg_3828, arg_3829, arg_3830) } else { return linked_3825.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3824, arg_3827, arg_3828, arg_3829, arg_3830) } }

func A_arbace_cpp_abi_classify_into_BANG__A_New() *A_arbace_cpp_abi_classify_into_BANG__A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_classify_into_BANG__A{}; t.Ctor(); return t }
//line :975:1
func (t *A_arbace_cpp_abi_classify_into_BANG__A) Ctor() {}
//line :975:1
func (t *A_arbace_cpp_abi_classify_into_BANG__A) InvokePrim_O_O_O_J__O(self, acc__0, t__1 any, off__2 int64) any { { var t__4 any; var root_3840 any = A_arbace_cpp_abi_A_const_46.GetRawRoot__O(); var linked_3841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3840, A_arbace_cpp_abi_unq_A_fn_class); var ifn_3842 lang.IFn



	if linked_3841 == nil { ifn_3842 = lang.IFn_Cast(root_3840) } else { ifn_3842 = nil }; var arg_3843 any = t__1; if linked_3841 == nil { t__4 = ifn_3842.Invoke_O__O(arg_3843) } else { t__4 = linked_3841.(*A_arbace_cpp_abi_unq_A).Invoke_O_O__O(root_3840, arg_3843) }
	var tmp1 any = A_arbace_cpp_abi_A_const_23; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__4)) { var et__5 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t__4); var es__6 int64; var tmp2 int64; var root_3844 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_3845 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3844, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_3846 lang.IFn

		if linked_3845 == nil { ifn_3846 = lang.IFn_Cast(root_3844) } else { ifn_3846 = nil }; var arg_3847 any = et__5; if linked_3845 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_3846.Invoke_O__O(arg_3847)) } else { tmp2 = linked_3845.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_3844, arg_3847) }; es__6 = lang.RT_LongCast_J__J_NoInit(tmp2)
//line :980:1
		var n__1927000701__auto____7 int64; var tmp3 any; var or__1927000174__auto____7 any = A_arbace_cpp_abi_A_const_18.Invoke_O__O(t__4)

		if jrt.J2g_Truth(or__1927000174__auto____7) { tmp3 = or__1927000174__auto____7 } else { tmp3 = A_arbace_cpp_abi_A_const_68 }; n__1927000701__auto____7 = lang.RT_LongCast_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(tmp3))
//line :980:1
		var i__8 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i__8, n__1927000701__auto____7) { var root_3935 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3935, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_3937 lang.IFn; if linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any = acc__0; var arg_3939 any = et__5; var arg_3940 int64 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.Numbers_Multiply_J_J__J_NoInit(i__8, es__6)); if linked_3936 == nil { ifn_3937.Invoke_O_O_O__O(arg_3938, arg_3939, jrt.Long_ValueOf_J__Long_NoInit(arg_3940).Ref()) } else { linked_3936.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_3935, arg_3938, arg_3939, arg_3940) }; i__8 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__8); continue L1 } else { return nil } } } else {
//line :980:1
				var tmp4 any = A_arbace_cpp_abi_A_const_33; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__4)) { var id__5 any = A_arbace_cpp_abi_A_const_49.Invoke_O__O(t__4); var c__6 any; var root_3848 any = A_arbace_cpp_abi_A_const_48.GetRawRoot__O(); var linked_3849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3848, A_arbace_cpp_abi_cls_A_fn_class); var ifn_3850 lang.IFn



					if linked_3849 == nil { ifn_3850 = lang.IFn_Cast(root_3848) } else { ifn_3850 = nil }; var arg_3851 any = id__5; if linked_3849 == nil { c__6 = ifn_3850.Invoke_O__O(arg_3851) } else { c__6 = linked_3849.(*A_arbace_cpp_abi_cls_A).Invoke_O_O__O(root_3848, arg_3851) }
//line :980:1
					var l__7 any; var root_3852 any = A_arbace_cpp_abi_A_const_59.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, A_arbace_cpp_abi_layout_A_fn_class); var ifn_3854 lang.IFn



					if linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = id__5; if linked_3853 == nil { l__7 = ifn_3854.Invoke_O__O(arg_3855) } else { l__7 = linked_3853.(*A_arbace_cpp_abi_layout_A).Invoke_O_O__O(root_3852, arg_3855) }
					if jrt.J2g_Truth(A_arbace_cpp_abi_A_const_146.Invoke_O__O(l__7)) { var root_3941 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_3942 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3941, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_3943 lang.IFn; if linked_3942 == nil { ifn_3943 = lang.IFn_Cast(root_3941) } else { ifn_3943 = nil }; var arg_3944 any = acc__0; var arg_3945 int64 = lang.Numbers_Quotient_J_J__J_NoInit(off__2, 8); var arg_3946 any = A_arbace_cpp_abi_A_const_389; var arg_3947 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Remainder_J_J__J_NoInit(off__2, 8), 8); if linked_3942 == nil { ifn_3943.Invoke_O_O_O_O__O(arg_3944, jrt.Long_ValueOf_J__Long_NoInit(arg_3945).Ref(), arg_3946, jrt.Long_ValueOf_J__Long_NoInit(arg_3947).Ref()) } else { linked_3942.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_3941, arg_3944, arg_3945, arg_3946, arg_3947) } }
//line :980:1
					var seq_677000377__8 any; var root_3948 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3950 lang.IFn





					if linked_3949 == nil { ifn_3950 = lang.IFn_Cast(root_3948) } else { ifn_3950 = nil }; var arg_3951 any; var root_3952 any = A_arbace_cpp_abi_A_const_114.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3952, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any = A_arbace_cpp_abi_A_const_115.GetRawRoot__O(); var arg_3956 any = A_arbace_cpp_abi_A_const_77.Invoke_O__O(c__6); if linked_3953 == nil { arg_3951 = ifn_3954.Invoke_O_O__O(arg_3955, arg_3956) } else { arg_3951 = linked_3953.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_3952, arg_3955, arg_3956) }; if linked_3949 == nil { seq_677000377__8 = ifn_3950.Invoke_O__O(arg_3951) } else { seq_677000377__8 = linked_3949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3948, arg_3951) }
//line :980:1
					var chunk_677000378__9 any; var count_677000379__10 int64 = 0; var i_677000380__11 int64 = 0; L2: for {





						if lang.Numbers_Lt_J_J__Z_NoInit(i_677000380__11, count_677000379__10) { var vec__677000381__12 any = lang.Indexed_Cast(chunk_677000378__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000380__11)); var i__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000381__12, lang.RT_IntCast_J__I_NoInit(0), nil); var b__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000381__12, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3973 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_3974 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3973, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_3975 lang.IFn
							if linked_3974 == nil { ifn_3975 = lang.IFn_Cast(root_3973) } else { ifn_3975 = nil }; var arg_3976 any = acc__0; var tmp5 any = A_arbace_cpp_abi_A_const_16; var tmp6 any = A_arbace_cpp_abi_A_const_33; var tmp7 any = A_arbace_cpp_abi_A_const_49; var arg_3977 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__14))); var arg_3978 int64 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_77.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__13)))); if linked_3974 == nil { ifn_3975.Invoke_O_O_O__O(arg_3976, arg_3977, jrt.Long_ValueOf_J__Long_NoInit(arg_3978).Ref()) } else { linked_3974.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_3973, arg_3976, arg_3977, arg_3978) }
//line :986:1
							seq_677000377__8, chunk_677000378__9, count_677000379__10, i_677000380__11 = seq_677000377__8, chunk_677000378__9, count_677000379__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000380__11); continue L2 } else { var temp__1927000414__auto____12 any; var root_3957 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3957, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3959 lang.IFn; if linked_3958 == nil { ifn_3959 = lang.IFn_Cast(root_3957) } else { ifn_3959 = nil }; var arg_3960 any = seq_677000377__8; if linked_3958 == nil { temp__1927000414__auto____12 = ifn_3959.Invoke_O__O(arg_3960) } else { temp__1927000414__auto____12 = linked_3958.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3957, arg_3960) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_677000377__13 any = temp__1927000414__auto____12; var tmp8 any; var root_3961 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_3962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3961, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3963 lang.IFn; if linked_3962 == nil { ifn_3963 = lang.IFn_Cast(root_3961) } else { ifn_3963 = nil }; var arg_3964 any = seq_677000377__13; if linked_3962 == nil { tmp8 = ifn_3963.Invoke_O__O(arg_3964) } else { tmp8 = linked_3962.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3961, arg_3964) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____14 any; var root_3965 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_3966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3965, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3967 lang.IFn; if linked_3966 == nil { ifn_3967 = lang.IFn_Cast(root_3965) } else { ifn_3967 = nil }; var arg_3968 any = seq_677000377__13; if linked_3966 == nil { c__1927000678__auto____14 = ifn_3967.Invoke_O__O(arg_3968) } else { c__1927000678__auto____14 = linked_3966.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3965, arg_3968) }; var tmp9 any; var root_3979 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_3980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3979, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3981 lang.IFn; if linked_3980 == nil { ifn_3981 = lang.IFn_Cast(root_3979) } else { ifn_3981 = nil }; var arg_3982 any = seq_677000377__13; if linked_3980 == nil { tmp9 = ifn_3981.Invoke_O__O(arg_3982) } else { tmp9 = linked_3980.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3979, arg_3982) }; seq_677000377__8, chunk_677000378__9, count_677000379__10, i_677000380__11 = tmp9, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__677000384__14 any; var root_3969 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3969, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3971 lang.IFn; if linked_3970 == nil { ifn_3971 = lang.IFn_Cast(root_3969) } else { ifn_3971 = nil }; var arg_3972 any = seq_677000377__13; if linked_3970 == nil { vec__677000384__14 = ifn_3971.Invoke_O__O(arg_3972) } else { vec__677000384__14 = linked_3970.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3969, arg_3972) }; var i__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000384__14, lang.RT_IntCast_J__I_NoInit(0), nil); var b__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000384__14, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3983 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_3984 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3983, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_3985 lang.IFn
								if linked_3984 == nil { ifn_3985 = lang.IFn_Cast(root_3983) } else { ifn_3985 = nil }; var arg_3986 any = acc__0; var tmp10 any = A_arbace_cpp_abi_A_const_16; var tmp11 any = A_arbace_cpp_abi_A_const_33; var tmp12 any = A_arbace_cpp_abi_A_const_49; var arg_3987 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11, tmp12, A_arbace_cpp_abi_A_const_81.Invoke_O__O(b__16))); var arg_3988 int64 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_77.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__15)))); if linked_3984 == nil { ifn_3985.Invoke_O_O_O__O(arg_3986, arg_3987, jrt.Long_ValueOf_J__Long_NoInit(arg_3988).Ref()) } else { linked_3984.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_3983, arg_3986, arg_3987, arg_3988) }
//line :986:1
								var tmp13 any; var root_3989 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_3990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3989, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3991 lang.IFn; if linked_3990 == nil { ifn_3991 = lang.IFn_Cast(root_3989) } else { ifn_3991 = nil }; var arg_3992 any = seq_677000377__13; if linked_3990 == nil { tmp13 = ifn_3991.Invoke_O__O(arg_3992) } else { tmp13 = linked_3990.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3989, arg_3992) }; seq_677000377__8, chunk_677000378__9, count_677000379__10, i_677000380__11 = tmp13, nil, 0, 0; continue L2 } } }
//line :980:1
						break L2 }; var seq_677000387__8 any; var root_3856 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3858 lang.IFn







					if linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any; var root_3860 any = A_arbace_cpp_abi_A_const_114.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_3862 lang.IFn; if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = A_arbace_cpp_abi_A_const_115.GetRawRoot__O(); var arg_3864 any = A_arbace_cpp_abi_A_const_102.Invoke_O__O(c__6); if linked_3861 == nil { arg_3859 = ifn_3862.Invoke_O_O__O(arg_3863, arg_3864) } else { arg_3859 = linked_3861.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_3860, arg_3863, arg_3864) }; if linked_3857 == nil { seq_677000387__8 = ifn_3858.Invoke_O__O(arg_3859) } else { seq_677000387__8 = linked_3857.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3856, arg_3859) }
//line :980:1
					var chunk_677000388__9 any; var count_677000389__10 int64 = 0; var i_677000390__11 int64 = 0; L3: for {







						if lang.Numbers_Lt_J_J__Z_NoInit(i_677000390__11, count_677000389__10) { var vec__677000391__12 any = lang.Indexed_Cast(chunk_677000388__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000390__11)); var i__13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000391__12, lang.RT_IntCast_J__I_NoInit(0), nil); var f__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000391__12, lang.RT_IntCast_J__I_NoInit(1), nil); var bo__15 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_145.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__13_2))

							if lang.Util_Identical_O_O__Z_NoInit(bo__15, nil) {
								var root_3993 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_3994 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3993, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_3995 lang.IFn; if linked_3994 == nil { ifn_3995 = lang.IFn_Cast(root_3993) } else { ifn_3995 = nil }; var arg_3996 any = acc__0; var arg_3997 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__14); var arg_3998 int64 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_102.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__13_2)))); if linked_3994 == nil { ifn_3995.Invoke_O_O_O__O(arg_3996, arg_3997, jrt.Long_ValueOf_J__Long_NoInit(arg_3998).Ref()) } else { linked_3994.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_3993, arg_3996, arg_3997, arg_3998) } } else {
//line :990:1
									if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__14))) { var b0__16 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(8, off__2), lang.RT_LongCast_O__J_NoInit(bo__15)); var b1__17 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b0__16, lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__14))), -1); var seq_677000394__18 any; var root_3999 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_4000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3999, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4001 lang.IFn



										if linked_4000 == nil { ifn_4001 = lang.IFn_Cast(root_3999) } else { ifn_4001 = nil }; var arg_4002 any; var root_4003 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_4004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4003, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_4005 lang.IFn; if linked_4004 == nil { ifn_4005 = lang.IFn_Cast(root_4003) } else { ifn_4005 = nil }; var arg_4006 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(b0__16, 64)).Ref(); var arg_4007 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(b1__17, 64))).Ref(); if linked_4004 == nil { arg_4002 = ifn_4005.Invoke_O_O__O(arg_4006, arg_4007) } else { arg_4002 = linked_4004.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_4003, arg_4006, arg_4007) }; if linked_4000 == nil { seq_677000394__18 = ifn_4001.Invoke_O__O(arg_4002) } else { seq_677000394__18 = linked_4000.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3999, arg_4002) }
//line :990:1
										var chunk_677000395__19 any; var count_677000396__20 int64 = 0; var i_677000397__21 int64 = 0; L4: for {



											if lang.Numbers_Lt_J_J__Z_NoInit(i_677000397__21, count_677000396__20) { var e__22 any = lang.Indexed_Cast(chunk_677000395__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000397__21)); var root_4024 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4024, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4026 lang.IFn
												if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; var arg_4027 any = acc__0; var arg_4028 any = e__22; var arg_4029 any = A_arbace_cpp_abi_A_const_389; var arg_4030 any; var tmp14 jrt.Number_I; var na_4031 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b1__17, 8), 8); var na_4032 any; var na_4033 int64 = 8; var na_4034 any = e__22; if jrt.Long_InstanceOf(na_4034) { var n0_4035 int64 = na_4033; var n1_4036 int64 = jrt.NN(jrt.Long_Cast(na_4034)).LongValue__J(); var nr_4037 int64 = n0_4035 * n1_4036; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; tmp18 = n0_4035 == -9223372036854775808; if tmp18 { tmp18 = n1_4036 < 0 }; tmp17 = tmp18; tmp16 = !tmp17; if tmp16 { var tmp19 bool; tmp19 = n1_4036 == 0; if !tmp19 { tmp19 = nr_4037/n1_4036 == n0_4035 }; tmp16 = tmp19 }; tmp15 = tmp16; if tmp15 { na_4032 = jrt.Long_ValueOf_J__Long_NoInit(nr_4037).Ref() } else { na_4032 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4033, na_4034) } } else { na_4032 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4033, na_4034) }; if jrt.Long_InstanceOf(na_4032) { var n0_4038 int64 = na_4031; var n1_4039 int64 = jrt.NN(jrt.Long_Cast(na_4032)).LongValue__J(); var nr_4040 int64 = n0_4038 - n1_4039; var tmp20 bool; var tmp21 bool; tmp21 = !(n1_4039 == -9223372036854775808); if tmp21 { tmp21 = (n0_4038^n1_4039)&(n0_4038^nr_4040) >= 0 }; tmp20 = tmp21; if tmp20 { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_4040)) } else { tmp14 = lang.Numbers_Minus_J_O__Number_NoInit(na_4031, na_4032) } } else { tmp14 = lang.Numbers_Minus_J_O__Number_NoInit(na_4031, na_4032) }; arg_4030 = lang.Numbers_Min_J_O__O_NoInit(8, tmp14); if linked_4025 == nil { ifn_4026.Invoke_O_O_O_O__O(arg_4027, arg_4028, arg_4029, arg_4030) } else { linked_4025.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4024, arg_4027, lang.RT_LongCast_O__J_NoInit(arg_4028), arg_4029, lang.RT_LongCast_O__J_NoInit(arg_4030)) }
//line :994:1
												seq_677000394__18, chunk_677000395__19, count_677000396__20, i_677000397__21 = seq_677000394__18, chunk_677000395__19, count_677000396__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000397__21); continue L4 } else { var temp__1927000414__auto____22 any; var root_4008 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_4009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4008, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4010 lang.IFn; if linked_4009 == nil { ifn_4010 = lang.IFn_Cast(root_4008) } else { ifn_4010 = nil }; var arg_4011 any = seq_677000394__18; if linked_4009 == nil { temp__1927000414__auto____22 = ifn_4010.Invoke_O__O(arg_4011) } else { temp__1927000414__auto____22 = linked_4009.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4008, arg_4011) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_677000394__23 any = temp__1927000414__auto____22; var tmp22 any; var root_4012 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_4013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4012, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4014 lang.IFn; if linked_4013 == nil { ifn_4014 = lang.IFn_Cast(root_4012) } else { ifn_4014 = nil }; var arg_4015 any = seq_677000394__23; if linked_4013 == nil { tmp22 = ifn_4014.Invoke_O__O(arg_4015) } else { tmp22 = linked_4013.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4012, arg_4015) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____24 any; var root_4016 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_4017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4016, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4018 lang.IFn; if linked_4017 == nil { ifn_4018 = lang.IFn_Cast(root_4016) } else { ifn_4018 = nil }; var arg_4019 any = seq_677000394__23; if linked_4017 == nil { c__1927000678__auto____24 = ifn_4018.Invoke_O__O(arg_4019) } else { c__1927000678__auto____24 = linked_4017.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4016, arg_4019) }; var tmp23 any; var root_4041 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_4042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4041, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4043 lang.IFn; if linked_4042 == nil { ifn_4043 = lang.IFn_Cast(root_4041) } else { ifn_4043 = nil }; var arg_4044 any = seq_677000394__23; if linked_4042 == nil { tmp23 = ifn_4043.Invoke_O__O(arg_4044) } else { tmp23 = linked_4042.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4041, arg_4044) }; seq_677000394__18, chunk_677000395__19, count_677000396__20, i_677000397__21 = tmp23, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var e__24 any; var root_4020 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_4021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4022 lang.IFn; if linked_4021 == nil { ifn_4022 = lang.IFn_Cast(root_4020) } else { ifn_4022 = nil }; var arg_4023 any = seq_677000394__23; if linked_4021 == nil { e__24 = ifn_4022.Invoke_O__O(arg_4023) } else { e__24 = linked_4021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4020, arg_4023) }
													var root_4045 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4045, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = acc__0; var arg_4049 any = e__24; var arg_4050 any = A_arbace_cpp_abi_A_const_389; var arg_4051 any; var tmp24 jrt.Number_I; var na_4052 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b1__17, 8), 8); var na_4053 any; var na_4054 int64 = 8; var na_4055 any = e__24; if jrt.Long_InstanceOf(na_4055) { var n0_4056 int64 = na_4054; var n1_4057 int64 = jrt.NN(jrt.Long_Cast(na_4055)).LongValue__J(); var nr_4058 int64 = n0_4056 * n1_4057; var tmp25 bool; var tmp26 bool; var tmp27 bool; var tmp28 bool; tmp28 = n0_4056 == -9223372036854775808; if tmp28 { tmp28 = n1_4057 < 0 }; tmp27 = tmp28; tmp26 = !tmp27; if tmp26 { var tmp29 bool; tmp29 = n1_4057 == 0; if !tmp29 { tmp29 = nr_4058/n1_4057 == n0_4056 }; tmp26 = tmp29 }; tmp25 = tmp26; if tmp25 { na_4053 = jrt.Long_ValueOf_J__Long_NoInit(nr_4058).Ref() } else { na_4053 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4054, na_4055) } } else { na_4053 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4054, na_4055) }; if jrt.Long_InstanceOf(na_4053) { var n0_4059 int64 = na_4052; var n1_4060 int64 = jrt.NN(jrt.Long_Cast(na_4053)).LongValue__J(); var nr_4061 int64 = n0_4059 - n1_4060; var tmp30 bool; var tmp31 bool; tmp31 = !(n1_4060 == -9223372036854775808); if tmp31 { tmp31 = (n0_4059^n1_4060)&(n0_4059^nr_4061) >= 0 }; tmp30 = tmp31; if tmp30 { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_4061)) } else { tmp24 = lang.Numbers_Minus_J_O__Number_NoInit(na_4052, na_4053) } } else { tmp24 = lang.Numbers_Minus_J_O__Number_NoInit(na_4052, na_4053) }; arg_4051 = lang.Numbers_Min_J_O__O_NoInit(8, tmp24); if linked_4046 == nil { ifn_4047.Invoke_O_O_O_O__O(arg_4048, arg_4049, arg_4050, arg_4051) } else { linked_4046.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4045, arg_4048, lang.RT_LongCast_O__J_NoInit(arg_4049), arg_4050, lang.RT_LongCast_O__J_NoInit(arg_4051)) }
//line :994:1
													var tmp32 any; var root_4062 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_4063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4062, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4064 lang.IFn; if linked_4063 == nil { ifn_4064 = lang.IFn_Cast(root_4062) } else { ifn_4064 = nil }; var arg_4065 any = seq_677000394__23; if linked_4063 == nil { tmp32 = ifn_4064.Invoke_O__O(arg_4065) } else { tmp32 = linked_4063.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4062, arg_4065) }; seq_677000394__18, chunk_677000395__19, count_677000396__20, i_677000397__21 = tmp32, nil, 0, 0; continue L4 } } }
//line :990:1
											break L4 } } else { if A_arbace_cpp_abi_A_const_118 != nil { } } }
//line :988:1
							seq_677000387__8, chunk_677000388__9, count_677000389__10, i_677000390__11 = seq_677000387__8, chunk_677000388__9, count_677000389__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000390__11); continue L3 } else { var temp__1927000414__auto____12_2 any; var root_3865 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = seq_677000387__8; if linked_3866 == nil { temp__1927000414__auto____12_2 = ifn_3867.Invoke_O__O(arg_3868) } else { temp__1927000414__auto____12_2 = linked_3866.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3865, arg_3868) }; if jrt.J2g_Truth(temp__1927000414__auto____12_2) { var seq_677000387__13 any = temp__1927000414__auto____12_2; var tmp33 any; var root_3869 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_3870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3869, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3871 lang.IFn; if linked_3870 == nil { ifn_3871 = lang.IFn_Cast(root_3869) } else { ifn_3871 = nil }; var arg_3872 any = seq_677000387__13; if linked_3870 == nil { tmp33 = ifn_3871.Invoke_O__O(arg_3872) } else { tmp33 = linked_3870.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3869, arg_3872) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____14_2 any; var root_3873 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_3874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3873, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3875 lang.IFn; if linked_3874 == nil { ifn_3875 = lang.IFn_Cast(root_3873) } else { ifn_3875 = nil }; var arg_3876 any = seq_677000387__13; if linked_3874 == nil { c__1927000678__auto____14_2 = ifn_3875.Invoke_O__O(arg_3876) } else { c__1927000678__auto____14_2 = linked_3874.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3873, arg_3876) }; var tmp34 any; var root_4066 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_4067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4066, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4068 lang.IFn; if linked_4067 == nil { ifn_4068 = lang.IFn_Cast(root_4066) } else { ifn_4068 = nil }; var arg_4069 any = seq_677000387__13; if linked_4067 == nil { tmp34 = ifn_4068.Invoke_O__O(arg_4069) } else { tmp34 = linked_4067.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4066, arg_4069) }; seq_677000387__8, chunk_677000388__9, count_677000389__10, i_677000390__11 = tmp34, c__1927000678__auto____14_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__677000398__14 any; var root_3877 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3877, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3879 lang.IFn; if linked_3878 == nil { ifn_3879 = lang.IFn_Cast(root_3877) } else { ifn_3879 = nil }; var arg_3880 any = seq_677000387__13; if linked_3878 == nil { vec__677000398__14 = ifn_3879.Invoke_O__O(arg_3880) } else { vec__677000398__14 = linked_3878.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3877, arg_3880) }; var i__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000398__14, lang.RT_IntCast_J__I_NoInit(0), nil); var f__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000398__14, lang.RT_IntCast_J__I_NoInit(1), nil); var bo__17 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_145.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__15_2))

								if lang.Util_Identical_O_O__Z_NoInit(bo__17, nil) {
									var root_4070 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_4071 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4070, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_4072 lang.IFn; if linked_4071 == nil { ifn_4072 = lang.IFn_Cast(root_4070) } else { ifn_4072 = nil }; var arg_4073 any = acc__0; var arg_4074 any = A_arbace_cpp_abi_A_const_98.Invoke_O__O(f__16); var arg_4075 int64 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(A_arbace_cpp_abi_A_const_102.Invoke_O__O(l__7), lang.RT_IntCast_O__I_NoInit(i__15_2)))); if linked_4071 == nil { ifn_4072.Invoke_O_O_O__O(arg_4073, arg_4074, jrt.Long_ValueOf_J__Long_NoInit(arg_4075).Ref()) } else { linked_4071.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_4070, arg_4073, arg_4074, arg_4075) } } else {
//line :990:1
										if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__16))) { var b0__18 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(8, off__2), lang.RT_LongCast_O__J_NoInit(bo__17)); var b1__19 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b0__18, lang.RT_LongCast_O__J_NoInit(A_arbace_cpp_abi_A_const_120.Invoke_O__O(f__16))), -1); var seq_677000401__20 any; var root_4076 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_4077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4076, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4078 lang.IFn



											if linked_4077 == nil { ifn_4078 = lang.IFn_Cast(root_4076) } else { ifn_4078 = nil }; var arg_4079 any; var root_4080 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_4081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4080, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_4082 lang.IFn; if linked_4081 == nil { ifn_4082 = lang.IFn_Cast(root_4080) } else { ifn_4082 = nil }; var arg_4083 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(b0__18, 64)).Ref(); var arg_4084 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(b1__19, 64))).Ref(); if linked_4081 == nil { arg_4079 = ifn_4082.Invoke_O_O__O(arg_4083, arg_4084) } else { arg_4079 = linked_4081.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_4080, arg_4083, arg_4084) }; if linked_4077 == nil { seq_677000401__20 = ifn_4078.Invoke_O__O(arg_4079) } else { seq_677000401__20 = linked_4077.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4076, arg_4079) }
//line :990:1
											var chunk_677000402__21 any; var count_677000403__22 int64 = 0; var i_677000404__23 int64 = 0; L5: for {



												if lang.Numbers_Lt_J_J__Z_NoInit(i_677000404__23, count_677000403__22) { var e__24_2 any = lang.Indexed_Cast(chunk_677000402__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000404__23)); var root_4101 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4102 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4101, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4103 lang.IFn
													if linked_4102 == nil { ifn_4103 = lang.IFn_Cast(root_4101) } else { ifn_4103 = nil }; var arg_4104 any = acc__0; var arg_4105 any = e__24_2; var arg_4106 any = A_arbace_cpp_abi_A_const_389; var arg_4107 any; var tmp35 jrt.Number_I; var na_4108 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b1__19, 8), 8); var na_4109 any; var na_4110 int64 = 8; var na_4111 any = e__24_2; if jrt.Long_InstanceOf(na_4111) { var n0_4112 int64 = na_4110; var n1_4113 int64 = jrt.NN(jrt.Long_Cast(na_4111)).LongValue__J(); var nr_4114 int64 = n0_4112 * n1_4113; var tmp36 bool; var tmp37 bool; var tmp38 bool; var tmp39 bool; tmp39 = n0_4112 == -9223372036854775808; if tmp39 { tmp39 = n1_4113 < 0 }; tmp38 = tmp39; tmp37 = !tmp38; if tmp37 { var tmp40 bool; tmp40 = n1_4113 == 0; if !tmp40 { tmp40 = nr_4114/n1_4113 == n0_4112 }; tmp37 = tmp40 }; tmp36 = tmp37; if tmp36 { na_4109 = jrt.Long_ValueOf_J__Long_NoInit(nr_4114).Ref() } else { na_4109 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4110, na_4111) } } else { na_4109 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4110, na_4111) }; if jrt.Long_InstanceOf(na_4109) { var n0_4115 int64 = na_4108; var n1_4116 int64 = jrt.NN(jrt.Long_Cast(na_4109)).LongValue__J(); var nr_4117 int64 = n0_4115 - n1_4116; var tmp41 bool; var tmp42 bool; tmp42 = !(n1_4116 == -9223372036854775808); if tmp42 { tmp42 = (n0_4115^n1_4116)&(n0_4115^nr_4117) >= 0 }; tmp41 = tmp42; if tmp41 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_4117)) } else { tmp35 = lang.Numbers_Minus_J_O__Number_NoInit(na_4108, na_4109) } } else { tmp35 = lang.Numbers_Minus_J_O__Number_NoInit(na_4108, na_4109) }; arg_4107 = lang.Numbers_Min_J_O__O_NoInit(8, tmp35); if linked_4102 == nil { ifn_4103.Invoke_O_O_O_O__O(arg_4104, arg_4105, arg_4106, arg_4107) } else { linked_4102.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4101, arg_4104, lang.RT_LongCast_O__J_NoInit(arg_4105), arg_4106, lang.RT_LongCast_O__J_NoInit(arg_4107)) }
//line :994:1
													seq_677000401__20, chunk_677000402__21, count_677000403__22, i_677000404__23 = seq_677000401__20, chunk_677000402__21, count_677000403__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000404__23); continue L5 } else { var temp__1927000414__auto____24 any; var root_4085 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_4086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4085, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4087 lang.IFn; if linked_4086 == nil { ifn_4087 = lang.IFn_Cast(root_4085) } else { ifn_4087 = nil }; var arg_4088 any = seq_677000401__20; if linked_4086 == nil { temp__1927000414__auto____24 = ifn_4087.Invoke_O__O(arg_4088) } else { temp__1927000414__auto____24 = linked_4086.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4085, arg_4088) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_677000401__25 any = temp__1927000414__auto____24; var tmp43 any; var root_4089 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_4090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4089, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4091 lang.IFn; if linked_4090 == nil { ifn_4091 = lang.IFn_Cast(root_4089) } else { ifn_4091 = nil }; var arg_4092 any = seq_677000401__25; if linked_4090 == nil { tmp43 = ifn_4091.Invoke_O__O(arg_4092) } else { tmp43 = linked_4090.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4089, arg_4092) }; if jrt.J2g_Truth(tmp43) { var c__1927000678__auto____26 any; var root_4093 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_4094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4093, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4095 lang.IFn; if linked_4094 == nil { ifn_4095 = lang.IFn_Cast(root_4093) } else { ifn_4095 = nil }; var arg_4096 any = seq_677000401__25; if linked_4094 == nil { c__1927000678__auto____26 = ifn_4095.Invoke_O__O(arg_4096) } else { c__1927000678__auto____26 = linked_4094.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4093, arg_4096) }; var tmp44 any; var root_4118 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_4119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4118, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4120 lang.IFn; if linked_4119 == nil { ifn_4120 = lang.IFn_Cast(root_4118) } else { ifn_4120 = nil }; var arg_4121 any = seq_677000401__25; if linked_4119 == nil { tmp44 = ifn_4120.Invoke_O__O(arg_4121) } else { tmp44 = linked_4119.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4118, arg_4121) }; seq_677000401__20, chunk_677000402__21, count_677000403__22, i_677000404__23 = tmp44, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var e__26 any; var root_4097 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_4098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4097, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4099 lang.IFn; if linked_4098 == nil { ifn_4099 = lang.IFn_Cast(root_4097) } else { ifn_4099 = nil }; var arg_4100 any = seq_677000401__25; if linked_4098 == nil { e__26 = ifn_4099.Invoke_O__O(arg_4100) } else { e__26 = linked_4098.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4097, arg_4100) }
														var root_4122 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4123 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4122, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4124 lang.IFn; if linked_4123 == nil { ifn_4124 = lang.IFn_Cast(root_4122) } else { ifn_4124 = nil }; var arg_4125 any = acc__0; var arg_4126 any = e__26; var arg_4127 any = A_arbace_cpp_abi_A_const_389; var arg_4128 any; var tmp45 jrt.Number_I; var na_4129 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(b1__19, 8), 8); var na_4130 any; var na_4131 int64 = 8; var na_4132 any = e__26; if jrt.Long_InstanceOf(na_4132) { var n0_4133 int64 = na_4131; var n1_4134 int64 = jrt.NN(jrt.Long_Cast(na_4132)).LongValue__J(); var nr_4135 int64 = n0_4133 * n1_4134; var tmp46 bool; var tmp47 bool; var tmp48 bool; var tmp49 bool; tmp49 = n0_4133 == -9223372036854775808; if tmp49 { tmp49 = n1_4134 < 0 }; tmp48 = tmp49; tmp47 = !tmp48; if tmp47 { var tmp50 bool; tmp50 = n1_4134 == 0; if !tmp50 { tmp50 = nr_4135/n1_4134 == n0_4133 }; tmp47 = tmp50 }; tmp46 = tmp47; if tmp46 { na_4130 = jrt.Long_ValueOf_J__Long_NoInit(nr_4135).Ref() } else { na_4130 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4131, na_4132) } } else { na_4130 = lang.Numbers_Multiply_J_O__Number_NoInit(na_4131, na_4132) }; if jrt.Long_InstanceOf(na_4130) { var n0_4136 int64 = na_4129; var n1_4137 int64 = jrt.NN(jrt.Long_Cast(na_4130)).LongValue__J(); var nr_4138 int64 = n0_4136 - n1_4137; var tmp51 bool; var tmp52 bool; tmp52 = !(n1_4137 == -9223372036854775808); if tmp52 { tmp52 = (n0_4136^n1_4137)&(n0_4136^nr_4138) >= 0 }; tmp51 = tmp52; if tmp51 { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_4138)) } else { tmp45 = lang.Numbers_Minus_J_O__Number_NoInit(na_4129, na_4130) } } else { tmp45 = lang.Numbers_Minus_J_O__Number_NoInit(na_4129, na_4130) }; arg_4128 = lang.Numbers_Min_J_O__O_NoInit(8, tmp45); if linked_4123 == nil { ifn_4124.Invoke_O_O_O_O__O(arg_4125, arg_4126, arg_4127, arg_4128) } else { linked_4123.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4122, arg_4125, lang.RT_LongCast_O__J_NoInit(arg_4126), arg_4127, lang.RT_LongCast_O__J_NoInit(arg_4128)) }
//line :994:1
														var tmp53 any; var root_4139 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_4140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4139, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4141 lang.IFn; if linked_4140 == nil { ifn_4141 = lang.IFn_Cast(root_4139) } else { ifn_4141 = nil }; var arg_4142 any = seq_677000401__25; if linked_4140 == nil { tmp53 = ifn_4141.Invoke_O__O(arg_4142) } else { tmp53 = linked_4140.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4139, arg_4142) }; seq_677000401__20, chunk_677000402__21, count_677000403__22, i_677000404__23 = tmp53, nil, 0, 0; continue L5 } } }
//line :990:1
												break L5 } } else { if A_arbace_cpp_abi_A_const_118 != nil { } } }
//line :988:1
								var tmp54 any; var root_4143 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_4144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4143, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4145 lang.IFn; if linked_4144 == nil { ifn_4145 = lang.IFn_Cast(root_4143) } else { ifn_4145 = nil }; var arg_4146 any = seq_677000387__13; if linked_4144 == nil { tmp54 = ifn_4145.Invoke_O__O(arg_4146) } else { tmp54 = linked_4144.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4143, arg_4146) }; seq_677000387__8, chunk_677000388__9, count_677000389__10, i_677000390__11 = tmp54, nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :980:1
									var tmp55 any = A_arbace_cpp_abi_A_const_41; if lang.Util_Equiv_O_O__Z_NoInit(tmp55, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__4)) { var seq_677000405__5 any; var root_3881 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3883 lang.IFn

















										if linked_3882 == nil { ifn_3883 = lang.IFn_Cast(root_3881) } else { ifn_3883 = nil }; var arg_3884 any; var root_3885 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_3886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3885, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3887 lang.IFn; if linked_3886 == nil { ifn_3887 = lang.IFn_Cast(root_3885) } else { ifn_3887 = nil }; var arg_3888 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(off__2, 8)).Ref(); var arg_3889 any; var tmp56 int64; var root_3890 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3890, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_3892 lang.IFn; if linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; var arg_3893 any = t__4; if linked_3891 == nil { tmp56 = lang.RT_LongCast_O__J_NoInit(ifn_3892.Invoke_O__O(arg_3893)) } else { tmp56 = linked_3891.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_3890, arg_3893) }; arg_3889 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_J__J_NoInit(tmp56)), -1), 8))).Ref(); if linked_3886 == nil { arg_3884 = ifn_3887.Invoke_O_O__O(arg_3888, arg_3889) } else { arg_3884 = linked_3886.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3885, arg_3888, arg_3889) }; if linked_3882 == nil { seq_677000405__5 = ifn_3883.Invoke_O__O(arg_3884) } else { seq_677000405__5 = linked_3882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3881, arg_3884) }
//line :980:1
										var chunk_677000406__6 any; var count_677000407__7 int64 = 0; var i_677000408__8 int64 = 0; L6: for {

















											if lang.Numbers_Lt_J_J__Z_NoInit(i_677000408__8, count_677000407__7) { var e__9 any = lang.Indexed_Cast(chunk_677000406__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_677000408__8)); var root_4147 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4148 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4147, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4149 lang.IFn; if linked_4148 == nil { ifn_4149 = lang.IFn_Cast(root_4147) } else { ifn_4149 = nil }; var arg_4150 any = acc__0; var arg_4151 any = e__9; var arg_4152 any = A_arbace_cpp_abi_A_const_389; if linked_4148 == nil { ifn_4149.Invoke_O_O_O_O__O(arg_4150, arg_4151, arg_4152, A_arbace_cpp_abi_A_const_396) } else { linked_4148.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4147, arg_4150, lang.RT_LongCast_O__J_NoInit(arg_4151), arg_4152, 8) }; seq_677000405__5, chunk_677000406__6, count_677000407__7, i_677000408__8 = seq_677000405__5, chunk_677000406__6, count_677000407__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_677000408__8); continue L6 } else { var temp__1927000414__auto____9 any; var root_3894 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3896 lang.IFn; if linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; var arg_3897 any = seq_677000405__5; if linked_3895 == nil { temp__1927000414__auto____9 = ifn_3896.Invoke_O__O(arg_3897) } else { temp__1927000414__auto____9 = linked_3895.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3894, arg_3897) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_677000405__10 any = temp__1927000414__auto____9; var tmp57 any; var root_3898 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = seq_677000405__10; if linked_3899 == nil { tmp57 = ifn_3900.Invoke_O__O(arg_3901) } else { tmp57 = linked_3899.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3898, arg_3901) }; if jrt.J2g_Truth(tmp57) { var c__1927000678__auto____11 any; var root_3902 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = seq_677000405__10; if linked_3903 == nil { c__1927000678__auto____11 = ifn_3904.Invoke_O__O(arg_3905) } else { c__1927000678__auto____11 = linked_3903.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3902, arg_3905) }; var tmp58 any; var root_4154 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_4155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4156 lang.IFn; if linked_4155 == nil { ifn_4156 = lang.IFn_Cast(root_4154) } else { ifn_4156 = nil }; var arg_4157 any = seq_677000405__10; if linked_4155 == nil { tmp58 = ifn_4156.Invoke_O__O(arg_4157) } else { tmp58 = linked_4155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4154, arg_4157) }; seq_677000405__5, chunk_677000406__6, count_677000407__7, i_677000408__8 = tmp58, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var e__11 any; var root_3906 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3908 lang.IFn; if linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = seq_677000405__10; if linked_3907 == nil { e__11 = ifn_3908.Invoke_O__O(arg_3909) } else { e__11 = linked_3907.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3906, arg_3909) }; var root_4158 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_4159 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4158, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_4160 lang.IFn; if linked_4159 == nil { ifn_4160 = lang.IFn_Cast(root_4158) } else { ifn_4160 = nil }; var arg_4161 any = acc__0; var arg_4162 any = e__11; var arg_4163 any = A_arbace_cpp_abi_A_const_389; if linked_4159 == nil { ifn_4160.Invoke_O_O_O_O__O(arg_4161, arg_4162, arg_4163, A_arbace_cpp_abi_A_const_396) } else { linked_4159.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_4158, arg_4161, lang.RT_LongCast_O__J_NoInit(arg_4162), arg_4163, 8) }; var tmp59 any; var root_4165 any = A_arbace_cpp_abi_A_const_83.GetRawRoot__O(); var linked_4166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4165, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4167 lang.IFn; if linked_4166 == nil { ifn_4167 = lang.IFn_Cast(root_4165) } else { ifn_4167 = nil }; var arg_4168 any = seq_677000405__10; if linked_4166 == nil { tmp59 = ifn_4167.Invoke_O__O(arg_4168) } else { tmp59 = linked_4166.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4165, arg_4168) }; seq_677000405__5, chunk_677000406__6, count_677000407__7, i_677000408__8 = tmp59, nil, 0, 0; continue L6 } } else { return nil } } } } else {
//line :980:1
												var tmp60 any = A_arbace_cpp_abi_A_const_57; if lang.Util_Equiv_O_O__Z_NoInit(tmp60, A_arbace_cpp_abi_A_const_16.Invoke_O__O(t__4)) { var et__5_2 any = A_arbace_cpp_abi_A_const_24.Invoke_O__O(t__4); var root_4169 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4169, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_4171 lang.IFn




















													if linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any = acc__0; var arg_4173 any = et__5_2; var arg_4174 int64 = off__2; if linked_4170 == nil { ifn_4171.Invoke_O_O_O__O(arg_4172, arg_4173, jrt.Long_ValueOf_J__Long_NoInit(arg_4174).Ref()) } else { linked_4170.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_4169, arg_4172, arg_4173, arg_4174) }; var root_3910 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_3911 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3910, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_3912 lang.IFn; if linked_3911 == nil { ifn_3912 = lang.IFn_Cast(root_3910) } else { ifn_3912 = nil }; var arg_3913 any = acc__0; var arg_3914 any = et__5_2; var arg_3915 int64; var tmp61 int64; var root_3916 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_3917 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3916, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_3918 lang.IFn; if linked_3917 == nil { ifn_3918 = lang.IFn_Cast(root_3916) } else { ifn_3918 = nil }; var arg_3919 any = et__5_2; if linked_3917 == nil { tmp61 = lang.RT_LongCast_O__J_NoInit(ifn_3918.Invoke_O__O(arg_3919)) } else { tmp61 = linked_3917.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_3916, arg_3919) }; arg_3915 = lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_J__J_NoInit(tmp61)); if linked_3911 == nil { return ifn_3912.Invoke_O_O_O__O(arg_3913, arg_3914, jrt.Long_ValueOf_J__Long_NoInit(arg_3915).Ref()) } else { return linked_3911.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_3910, arg_3913, arg_3914, arg_3915) } } else {
//line :980:1
														if A_arbace_cpp_abi_A_const_118 != nil { var e__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(off__2, 8); var root_3920 any = A_arbace_cpp_abi_A_const_394.GetRawRoot__O(); var linked_3921 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3920, A_arbace_cpp_abi_mark_BANG__A_fn_class); var ifn_3922 lang.IFn






















															if linked_3921 == nil { ifn_3922 = lang.IFn_Cast(root_3920) } else { ifn_3922 = nil }; var arg_3923 any = acc__0; var arg_3924 int64 = e__5; var arg_3925 any; var root_3927 any = A_arbace_cpp_abi_A_const_395.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, A_arbace_cpp_abi_scalar_class_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = t__4; if linked_3928 == nil { arg_3925 = ifn_3929.Invoke_O__O(arg_3930) } else { arg_3925 = linked_3928.(*A_arbace_cpp_abi_scalar_class_A).Invoke_O_O__O(root_3927, arg_3930) }; var arg_3926 int64; var tmp62 int64; var root_3931 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_3932 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_3931, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_3933 lang.IFn; if linked_3932 == nil { ifn_3933 = lang.IFn_Cast(root_3931) } else { ifn_3933 = nil }; var arg_3934 any = t__4; if linked_3932 == nil { tmp62 = lang.RT_LongCast_O__J_NoInit(ifn_3933.Invoke_O__O(arg_3934)) } else { tmp62 = linked_3932.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_3931, arg_3934) }; arg_3926 = lang.Numbers_Minus_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(off__2, lang.RT_LongCast_J__J_NoInit(tmp62)), lang.Numbers_Multiply_J_J__J_NoInit(8, e__5)); if linked_3921 == nil { return ifn_3922.Invoke_O_O_O_O__O(arg_3923, jrt.Long_ValueOf_J__Long_NoInit(arg_3924).Ref(), arg_3925, jrt.Long_ValueOf_J__Long_NoInit(arg_3926).Ref()) } else { return linked_3921.(*A_arbace_cpp_abi_mark_BANG__A).InvokePrim_O_O_J_O_J__O(root_3920, arg_3923, arg_3924, arg_3925, arg_3926) } } else {
//line :980:1
																return nil } } } } } }; /*line :975:1*/panic("j2g: unreachable") }
//line :975:1
func (t *A_arbace_cpp_abi_classify_into_BANG__A) Invoke_O_O_O_O__O(self, acc__0, t__1, p_off__2 any) any { return t.InvokePrim_O_O_O_J__O(self, acc__0, t__1, lang.RT_LongCast_O__J_NoInit(p_off__2)) }





























func A_arbace_cpp_abi_classify_class_A_New() *A_arbace_cpp_abi_classify_class_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_classify_class_A{}; t.Ctor(); return t }
//line :1005:1
func (t *A_arbace_cpp_abi_classify_class_A) Ctor() {}
//line :1005:1
func (t *A_arbace_cpp_abi_classify_class_A) Invoke_O_O__O(self, id__0 any) any { var sz__2 int64; var tmp1 int64; var root_4175 any = A_arbace_cpp_abi_A_const_199.GetRawRoot__O(); var linked_4176 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4175, A_arbace_cpp_abi_size_of_A_fn_class); var ifn_4177 lang.IFn; if



	linked_4176 == nil { ifn_4177 = lang.IFn_Cast(root_4175) } else { ifn_4177 = nil }; var arg_4178 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_33, A_arbace_cpp_abi_A_const_49, id__0)); if linked_4176 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_4177.Invoke_O__O(arg_4178)) } else { tmp1 = linked_4176.(*A_arbace_cpp_abi_size_of_A).InvokePrim_O_O__J(root_4175, arg_4178) }; sz__2 = lang.RT_LongCast_J__J_NoInit(tmp1); var tmp2 any; var and__1927000168__auto____3 any; var root_4179 any =
	A_arbace_cpp_abi_A_const_99.GetRawRoot__O(); var linked_4180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4179, A_arbace_cpp_abi_empty_class_QMARK__A_fn_class); var ifn_4181 lang.IFn; if
	linked_4180 == nil { ifn_4181 = lang.IFn_Cast(root_4179) } else { ifn_4181 = nil }; var arg_4182 any = id__0; if linked_4180 == nil { and__1927000168__auto____3 = ifn_4181.Invoke_O__O(arg_4182) } else { and__1927000168__auto____3 = linked_4180.(*A_arbace_cpp_abi_empty_class_QMARK__A).Invoke_O_O__O(root_4179, arg_4182) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(1, sz__2)).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :1010:1*/ jrt.J2g_Truth(tmp2) { return A_arbace_cpp_abi_A_const_397 } else { if lang.Numbers_Gt_J_J__Z_NoInit(sz__2, 16) { return A_arbace_cpp_abi_A_const_388 } else { if A_arbace_cpp_abi_A_const_118 != nil { var acc__3 any; var root_4183 any = A_arbace_cpp_abi_A_const_92.GetRawRoot__O(); var linked_4184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4183, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_4185 lang.IFn



		if linked_4184 == nil { ifn_4185 = lang.IFn_Cast(root_4183) } else { ifn_4185 = nil }; var arg_4186 any = A_arbace_cpp_abi_A_const_398; if linked_4184 == nil { acc__3 = ifn_4185.Invoke_O__O(arg_4186) } else { acc__3 = linked_4184.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_4183, arg_4186) }
		var root_4261 any = A_arbace_cpp_abi_A_const_393.GetRawRoot__O(); var linked_4262 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_4261, A_arbace_cpp_abi_classify_into_BANG__A_fn_class); var ifn_4263 lang.IFn; if linked_4262 == nil { ifn_4263 = lang.IFn_Cast(root_4261) } else { ifn_4263 = nil }; var arg_4264 any = acc__3; var arg_4265 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_abi_A_const_16, A_arbace_cpp_abi_A_const_33, A_arbace_cpp_abi_A_const_49, id__0)); if linked_4262 == nil { ifn_4263.Invoke_O_O_O__O(arg_4264, arg_4265, A_arbace_cpp_abi_A_const_68) } else { linked_4262.(*A_arbace_cpp_abi_classify_into_BANG__A).InvokePrim_O_O_O_J__O(root_4261, arg_4264, arg_4265, 0) }
//line :1010:1
		var vec__677000410__4 any; var root_4187 any = A_arbace_cpp_abi_A_const_7.GetRawRoot__O(); var linked_4188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4187, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4189 lang.IFn





		if linked_4188 == nil { ifn_4189 = lang.IFn_Cast(root_4187) } else { ifn_4189 = nil }; var arg_4190 any = acc__3; if linked_4188 == nil { vec__677000410__4 = ifn_4189.Invoke_O__O(arg_4190) } else { vec__677000410__4 = linked_4188.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4187, arg_4190) }
//line :1010:1
		var lo__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000410__4, lang.RT_IntCast_J__I_NoInit(0), nil); var hi__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000410__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e0__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000410__4, lang.RT_IntCast_J__I_NoInit(2), nil); var e1__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__677000410__4, lang.RT_IntCast_J__I_NoInit(3), nil); var n__9 int64






		if lang.Numbers_Gt_J_J__Z_NoInit(sz__2, 8) { n__9 = 2 } else { n__9 = 1 }
		var tmp3 bool; var or__1927000174__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(lo__5, A_arbace_cpp_abi_A_const_388); if or__1927000174__auto____10 { tmp3 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(hi__6, A_arbace_cpp_abi_A_const_388); if or__1927000174__auto____11 { tmp3 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(lo__5, A_arbace_cpp_abi_A_const_390); if or__1927000174__auto____12 { tmp3 = or__1927000174__auto____12 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(hi__6, A_arbace_cpp_abi_A_const_390) } } }; if tmp3 { return A_arbace_cpp_abi_A_const_388 } else {

			var root_4191 any = A_arbace_cpp_abi_A_const_75.GetRawRoot__O(); var linked_4192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4191, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4193 lang.IFn; if linked_4192 == nil { ifn_4193 = lang.IFn_Cast(root_4191) } else { ifn_4193 = nil }; var arg_4194 any; var iter__1927001039__auto____10 any; var fnbody__4256 any = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_New_O_O_O_O(e0__7, e1__8, hi__6, lo__5); var tmp4 *jrt.Class; var fncls__4255 *jrt.Class = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_fn_class; if fncls__4255 == nil { var fncls__4255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__4256); A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_fn_class = fncls__4255d; tmp4 = fncls__4255d } else { tmp4 = fncls__4255 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4256, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp6 any; var root_4257 any = A_arbace_cpp_abi_A_const_117.GetRawRoot__O(); var linked_4258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4257, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_4259 lang.IFn; if linked_4258 == nil { ifn_4259 = lang.IFn_Cast(root_4257) } else { ifn_4259 = nil }; var arg_4260 any = jrt.Long_ValueOf_J__Long_NoInit(n__9).Ref(); if linked_4258 == nil { tmp6 = ifn_4259.Invoke_O__O(arg_4260) } else { tmp6 = linked_4258.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_4257, arg_4260) }; arg_4194 = tmp5.Invoke_O__O(tmp6); if linked_4192 == nil { return ifn_4193.Invoke_O__O(arg_4194) } else { return linked_4192.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4191, arg_4194) } } } else {
//line :1010:1
				return nil } } } }









func A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A) Ctor_O_O_O_O(c__e0, c__e1, c__hi, c__lo any) { t.F_e0 = c__e0; t.F_e1 = c__e1; t.F_hi = c__hi; t.F_lo = c__lo }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A) Invoke_O_O__O(self, s__677000414__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4254 any = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_New_O_O_O_O_O_O(self, t.F_e0, t.F_e1, s__677000414__1, t.F_hi, t.F_lo); var tmp2 *jrt.Class; var fncls__4253 *jrt.Class = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_fn_class; if fncls__4253 == nil { var fncls__4253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__4254); A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_fn_class = fncls__4253d; tmp2 = fncls__4253d } else { tmp2 = fncls__4253 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4254, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :1020:1
func A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A) Ctor_O_O_O_O_O_O(c__iter__677000413, c__e0, c__e1, c__s__677000414, c__hi, c__lo any) { t.F_iter__677000413 = c__iter__677000413; t.F_e0 = c__e0; t.F_e1 = c__e1; t.F_s__677000414 = c__s__677000414; t.F_hi = c__hi; t.F_lo = c__lo }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A) Invoke_O__O(self any) any { { var s__677000414__1 any; var t_ any = t.F_s__677000414; t.F_s__677000414 = nil; s__677000414__1 = t_; for { var temp__1927000414__auto____2 any; var root_4195 any = A_arbace_cpp_abi_A_const_76.GetRawRoot__O(); var linked_4196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4195, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4197 lang.IFn; if linked_4196 == nil { ifn_4197 = lang.IFn_Cast(root_4195) } else { ifn_4197 = nil }; var arg_4198 any = s__677000414__1; if linked_4196 == nil { temp__1927000414__auto____2 = ifn_4197.Invoke_O__O(arg_4198) } else { temp__1927000414__auto____2 = linked_4196.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4195, arg_4198) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__677000414__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4199 any = A_arbace_cpp_abi_A_const_78.GetRawRoot__O(); var linked_4200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4199, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4201 lang.IFn; if linked_4200 == nil { ifn_4201 = lang.IFn_Cast(root_4199) } else { ifn_4201 = nil }; var arg_4202 any = s__677000414__3; if linked_4200 == nil { tmp1 = ifn_4201.Invoke_O__O(arg_4202) } else { tmp1 = linked_4200.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4199, arg_4202) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4203 any = A_arbace_cpp_abi_A_const_79.GetRawRoot__O(); var linked_4204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4203, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4205 lang.IFn; if linked_4204 == nil { ifn_4205 = lang.IFn_Cast(root_4203) } else { ifn_4205 = nil }; var arg_4206 any = s__677000414__3; if linked_4204 == nil { c__1927001037__auto____4 = ifn_4205.Invoke_O__O(arg_4206) } else { c__1927001037__auto____4 = linked_4204.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4203, arg_4206) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__677000416__6 any; var root_4207 any = A_arbace_cpp_abi_A_const_399.GetRawRoot__O(); var linked_4208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4207, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4209 lang.IFn; if linked_4208 == nil { ifn_4209 = lang.IFn_Cast(root_4207) } else { ifn_4209 = nil }; var arg_4210 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4208 == nil { b__677000416__6 = ifn_4209.Invoke_O__O(arg_4210) } else { b__677000416__6 = linked_4208.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4207, arg_4210) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4217 any = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_New_O_O_O_O_I_O_O(t.F_e0, t.F_e1, b__677000416__6, t.F_hi, size__1927001038__auto____5, t.F_lo, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4216 *jrt.Class = A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_fn_class; if fncls__4216 == nil { var fncls__4216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__4217); A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_fn_class = fncls__4216d; tmp3 = fncls__4216d } else { tmp3 = fncls__4216 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4217, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4218 any = A_arbace_cpp_abi_A_const_401.GetRawRoot__O(); var linked_4219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4218, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4220 lang.IFn; if linked_4219 == nil { ifn_4220 = lang.IFn_Cast(root_4218) } else { ifn_4220 = nil }; var arg_4221 any; var root_4223 any = A_arbace_cpp_abi_A_const_402.GetRawRoot__O(); var linked_4224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4223, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4225 lang.IFn; if linked_4224 == nil { ifn_4225 = lang.IFn_Cast(root_4223) } else { ifn_4225 = nil }; var arg_4226 any = b__677000416__6; if linked_4224 == nil { arg_4221 = ifn_4225.Invoke_O__O(arg_4226) } else { arg_4221 = linked_4224.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4223, arg_4226) }; var arg_4222 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__677000413); var tmp5 any; var root_4227 any = A_arbace_cpp_abi_A_const_82.GetRawRoot__O(); var linked_4228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4227, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4229 lang.IFn; if linked_4228 == nil { ifn_4229 = lang.IFn_Cast(root_4227) } else { ifn_4229 = nil }; var arg_4230 any = s__677000414__3; if linked_4228 == nil { tmp5 = ifn_4229.Invoke_O__O(arg_4230) } else { tmp5 = linked_4228.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4227, arg_4230) }; arg_4222 = tmp4.Invoke_O__O(tmp5); if linked_4219 == nil { return ifn_4220.Invoke_O_O__O(arg_4221, arg_4222) } else { return linked_4219.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4218, arg_4221, arg_4222) } } else { var root_4231 any = A_arbace_cpp_abi_A_const_401.GetRawRoot__O(); var linked_4232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4231, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4233 lang.IFn; if linked_4232 == nil { ifn_4233 = lang.IFn_Cast(root_4231) } else { ifn_4233 = nil }; var arg_4234 any; var root_4236 any = A_arbace_cpp_abi_A_const_402.GetRawRoot__O(); var linked_4237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4236, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4238 lang.IFn; if linked_4237 == nil { ifn_4238 = lang.IFn_Cast(root_4236) } else { ifn_4238 = nil }; var arg_4239 any = b__677000416__6; if linked_4237 == nil { arg_4234 = ifn_4238.Invoke_O__O(arg_4239) } else { arg_4234 = linked_4237.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4236, arg_4239) }; var arg_4235 any; if linked_4232 == nil { return ifn_4233.Invoke_O_O__O(arg_4234, arg_4235) } else { return linked_4232.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4231, arg_4234, arg_4235) } } } else { var e__4 any; var root_4240 any = A_arbace_cpp_abi_A_const_73.GetRawRoot__O(); var linked_4241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4240, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4242 lang.IFn; if linked_4241 == nil { ifn_4242 = lang.IFn_Cast(root_4240) } else { ifn_4242 = nil }; var arg_4243 any = s__677000414__3; if linked_4241 == nil { e__4 = ifn_4242.Invoke_O__O(arg_4243) } else { e__4 = linked_4241.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4240, arg_4243) }; var c__5 any = lang.RT_Nth_O_I__O_NoInit(lang.Tuple_Create_O_O__IPersistentVector(t.F_lo, t.F_hi), lang.RT_IntCast_O__I_NoInit(e__4)); var c__6 any; if lang.Util_Equiv_O_O__Z_NoInit(c__5, A_arbace_cpp_abi_A_const_387) { c__6 = A_arbace_cpp_abi_A_const_391 } else { c__6 = c__5 }; var root_4244 any = A_arbace_cpp_abi_A_const_130.GetRawRoot__O(); var linked_4245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4244, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4246 lang.IFn; if linked_4245 == nil { ifn_4246 = lang.IFn_Cast(root_4244) } else { ifn_4246 = nil }; var arg_4247 any = lang.Tuple_Create_O_O__IPersistentVector(c__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(1, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lang.Tuple_Create_O_O__IPersistentVector(t.F_e0, t.F_e1), lang.RT_IntCast_O__I_NoInit(e__4))))).Ref()); var arg_4248 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__677000413); var tmp7 any; var root_4249 any = A_arbace_cpp_abi_A_const_235.GetRawRoot__O(); var linked_4250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4249, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4251 lang.IFn; if linked_4250 == nil { ifn_4251 = lang.IFn_Cast(root_4249) } else { ifn_4251 = nil }; var arg_4252 any = s__677000414__3; if linked_4250 == nil { tmp7 = ifn_4251.Invoke_O__O(arg_4252) } else { tmp7 = linked_4250.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4249, arg_4252) }; arg_4248 = tmp6.Invoke_O__O(tmp7); if linked_4245 == nil { return ifn_4246.Invoke_O_O__O(arg_4247, arg_4248) } else { return linked_4245.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4244, arg_4247, arg_4248) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1020:1
func A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A) Ctor_O_O_O_O_I_O_O(c__e0, c__e1, c__b__677000416, c__hi any, c__size__1927001038__auto__ int32, c__lo, c__c__1927001037__auto__ any) { t.F_e0 = c__e0; t.F_e1 = c__e1; t.F_b__677000416 = c__b__677000416; t.F_hi = c__hi; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_lo = c__lo; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1020:1
func (t *A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A) Invoke_O__O(self any) any { { var i__677000415__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__677000415__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__677000415__1)); var c__3 any = lang.RT_Nth_O_I__O_NoInit(lang.Tuple_Create_O_O__IPersistentVector(t.F_lo, t.F_hi), lang.RT_IntCast_O__I_NoInit(e__2)); var c__4 any; if lang.Util_Equiv_O_O__Z_NoInit(c__3, A_arbace_cpp_abi_A_const_387) { c__4 = A_arbace_cpp_abi_A_const_391 } else { c__4 = c__3 }; var root_4211 any = A_arbace_cpp_abi_A_const_400.GetRawRoot__O(); var linked_4212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4211, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4213 lang.IFn; if linked_4212 == nil { ifn_4213 = lang.IFn_Cast(root_4211) } else { ifn_4213 = nil }; var arg_4214 any = t.F_b__677000416; var arg_4215 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(1, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(lang.Tuple_Create_O_O__IPersistentVector(t.F_e0, t.F_e1), lang.RT_IntCast_O__I_NoInit(e__2))))).Ref()); if linked_4212 == nil { ifn_4213.Invoke_O_O__O(arg_4214, arg_4215) } else { linked_4212.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4211, arg_4214, arg_4215) }; i__677000415__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__677000415__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





















































































type A_arbace_cpp_abi_A struct{ jrt.Object }

var A_arbace_cpp_abi_A_const_pool *jrt.RefArray

var A_arbace_cpp_abi_A_const_0 *lang.Var

var A_arbace_cpp_abi_A_const_1 any

var A_arbace_cpp_abi_A_const_2 *lang.Var

var A_arbace_cpp_abi_A_const_3 any

var A_arbace_cpp_abi_A_const_4 *lang.Keyword

var A_arbace_cpp_abi_A_const_5 any

var A_arbace_cpp_abi_A_const_6 *lang.Var

var A_arbace_cpp_abi_A_const_7 *lang.Var

var A_arbace_cpp_abi_A_const_8 *lang.Var

var A_arbace_cpp_abi_A_const_9 *lang.Var

var A_arbace_cpp_abi_A_const_10 any

var A_arbace_cpp_abi_A_const_11 *lang.Var

var A_arbace_cpp_abi_A_const_12 *lang.Var

var A_arbace_cpp_abi_A_const_13 *lang.Var

var A_arbace_cpp_abi_A_const_14 *lang.Keyword

var A_arbace_cpp_abi_A_const_15 *lang.Var

var A_arbace_cpp_abi_A_const_16 *lang.Keyword

var A_arbace_cpp_abi_A_const_17 *lang.Keyword

var A_arbace_cpp_abi_A_const_18 *lang.Keyword

var A_arbace_cpp_abi_A_const_19 *lang.Keyword

var A_arbace_cpp_abi_A_const_20 *lang.Keyword

var A_arbace_cpp_abi_A_const_21 *lang.Keyword

var A_arbace_cpp_abi_A_const_22 *lang.Keyword

var A_arbace_cpp_abi_A_const_23 *lang.Keyword

var A_arbace_cpp_abi_A_const_24 *lang.Keyword

var A_arbace_cpp_abi_A_const_25 *lang.Var

var A_arbace_cpp_abi_A_const_26 *lang.Keyword

var A_arbace_cpp_abi_A_const_27 *lang.Keyword

var A_arbace_cpp_abi_A_const_28 *lang.Var

var A_arbace_cpp_abi_A_const_29 *lang.Keyword

var A_arbace_cpp_abi_A_const_30 *lang.Var

var A_arbace_cpp_abi_A_const_31 any

var A_arbace_cpp_abi_A_const_32 *lang.Var

var A_arbace_cpp_abi_A_const_33 *lang.Keyword

var A_arbace_cpp_abi_A_const_34 *lang.Keyword

var A_arbace_cpp_abi_A_const_35 *lang.Keyword

var A_arbace_cpp_abi_A_const_36 *lang.Var

var A_arbace_cpp_abi_A_const_37 *lang.Var

var A_arbace_cpp_abi_A_const_38 *lang.Var

var A_arbace_cpp_abi_A_const_39 any

var A_arbace_cpp_abi_A_const_40 *lang.Var

var A_arbace_cpp_abi_A_const_41 *lang.Keyword

var A_arbace_cpp_abi_A_const_42 *lang.Var

var A_arbace_cpp_abi_A_const_43 *lang.Var

var A_arbace_cpp_abi_A_const_44 *lang.Var

var A_arbace_cpp_abi_A_const_45 *lang.Keyword

var A_arbace_cpp_abi_A_const_46 *lang.Var

var A_arbace_cpp_abi_A_const_47 *lang.Var

var A_arbace_cpp_abi_A_const_48 *lang.Var

var A_arbace_cpp_abi_A_const_49 *lang.Keyword

var A_arbace_cpp_abi_A_const_50 *lang.Var

var A_arbace_cpp_abi_A_const_51 *lang.Var

var A_arbace_cpp_abi_A_const_52 *lang.Var

var A_arbace_cpp_abi_A_const_53 *lang.Keyword

var A_arbace_cpp_abi_A_const_54 *lang.Var

var A_arbace_cpp_abi_A_const_55 *lang.Var

var A_arbace_cpp_abi_A_const_56 any

var A_arbace_cpp_abi_A_const_57 *lang.Keyword

var A_arbace_cpp_abi_A_const_58 *lang.Var

var A_arbace_cpp_abi_A_const_59 *lang.Var

var A_arbace_cpp_abi_A_const_60 any

var A_arbace_cpp_abi_A_const_61 any

var A_arbace_cpp_abi_A_const_62 *lang.Var

var A_arbace_cpp_abi_A_const_63 *lang.Keyword

var A_arbace_cpp_abi_A_const_64 *lang.Var

var A_arbace_cpp_abi_A_const_65 *lang.Keyword

var A_arbace_cpp_abi_A_const_66 *lang.Keyword

var A_arbace_cpp_abi_A_const_67 any

var A_arbace_cpp_abi_A_const_68 any

var A_arbace_cpp_abi_A_const_69 any

var A_arbace_cpp_abi_A_const_70 any

var A_arbace_cpp_abi_A_const_71 *lang.Var

var A_arbace_cpp_abi_A_const_72 *lang.Var

var A_arbace_cpp_abi_A_const_73 *lang.Var

var A_arbace_cpp_abi_A_const_74 *lang.Var

var A_arbace_cpp_abi_A_const_75 *lang.Var

var A_arbace_cpp_abi_A_const_76 *lang.Var

var A_arbace_cpp_abi_A_const_77 *lang.Keyword

var A_arbace_cpp_abi_A_const_78 *lang.Var

var A_arbace_cpp_abi_A_const_79 *lang.Var

var A_arbace_cpp_abi_A_const_80 *lang.Keyword

var A_arbace_cpp_abi_A_const_81 *lang.Keyword

var A_arbace_cpp_abi_A_const_82 *lang.Var

var A_arbace_cpp_abi_A_const_83 *lang.Var

var A_arbace_cpp_abi_A_const_84 *lang.Keyword

var A_arbace_cpp_abi_A_const_85 *lang.Var

var A_arbace_cpp_abi_A_const_86 *lang.Var

var A_arbace_cpp_abi_A_const_87 *lang.Keyword

var A_arbace_cpp_abi_A_const_88 *lang.Keyword

var A_arbace_cpp_abi_A_const_89 *lang.Var

var A_arbace_cpp_abi_A_const_90 *lang.Var

var A_arbace_cpp_abi_A_const_91 *lang.Var

var A_arbace_cpp_abi_A_const_92 *lang.Var

var A_arbace_cpp_abi_A_const_93 *lang.Var

var A_arbace_cpp_abi_A_const_94 *lang.Var

var A_arbace_cpp_abi_A_const_95 *lang.Var

var A_arbace_cpp_abi_A_const_96 *lang.Keyword

var A_arbace_cpp_abi_A_const_97 *lang.Var

var A_arbace_cpp_abi_A_const_98 *lang.Keyword

var A_arbace_cpp_abi_A_const_99 *lang.Var

var A_arbace_cpp_abi_A_const_100 *lang.Var

var A_arbace_cpp_abi_A_const_101 *lang.Var

var A_arbace_cpp_abi_A_const_102 *lang.Keyword

var A_arbace_cpp_abi_A_const_103 *lang.Var

var A_arbace_cpp_abi_A_const_104 *lang.Keyword

var A_arbace_cpp_abi_A_const_105 *lang.Keyword

var A_arbace_cpp_abi_A_const_106 *lang.Keyword

var A_arbace_cpp_abi_A_const_107 *lang.Keyword

var A_arbace_cpp_abi_A_const_108 *lang.Keyword

var A_arbace_cpp_abi_A_const_109 *lang.Var

var A_arbace_cpp_abi_A_const_110 *lang.Var

var A_arbace_cpp_abi_A_const_111 *lang.Var

var A_arbace_cpp_abi_A_const_112 *lang.Var

var A_arbace_cpp_abi_A_const_113 *lang.Var

var A_arbace_cpp_abi_A_const_114 *lang.Var

var A_arbace_cpp_abi_A_const_115 *lang.Var

var A_arbace_cpp_abi_A_const_116 *lang.Var

var A_arbace_cpp_abi_A_const_117 *lang.Var

var A_arbace_cpp_abi_A_const_118 *lang.Keyword

var A_arbace_cpp_abi_A_const_119 *lang.Keyword

var A_arbace_cpp_abi_A_const_120 *lang.Keyword

var A_arbace_cpp_abi_A_const_121 *lang.Var

var A_arbace_cpp_abi_A_const_122 *lang.Var

var A_arbace_cpp_abi_A_const_123 *lang.Var

var A_arbace_cpp_abi_A_const_124 *lang.Var

var A_arbace_cpp_abi_A_const_125 *lang.Keyword

var A_arbace_cpp_abi_A_const_126 *lang.Var

var A_arbace_cpp_abi_A_const_127 *lang.Keyword

var A_arbace_cpp_abi_A_const_128 *lang.Var

var A_arbace_cpp_abi_A_const_129 *lang.Var

var A_arbace_cpp_abi_A_const_130 *lang.Var

var A_arbace_cpp_abi_A_const_131 *lang.Var

var A_arbace_cpp_abi_A_const_132 *lang.Var

var A_arbace_cpp_abi_A_const_133 *lang.Keyword

var A_arbace_cpp_abi_A_const_134 *lang.Keyword

var A_arbace_cpp_abi_A_const_135 *lang.Var

var A_arbace_cpp_abi_A_const_136 *lang.Var

var A_arbace_cpp_abi_A_const_137 *lang.Var

var A_arbace_cpp_abi_A_const_138 *lang.Var

var A_arbace_cpp_abi_A_const_139 *lang.Var

var A_arbace_cpp_abi_A_const_140 *lang.Keyword

var A_arbace_cpp_abi_A_const_141 *lang.Var

var A_arbace_cpp_abi_A_const_142 *lang.Keyword

var A_arbace_cpp_abi_A_const_143 any

var A_arbace_cpp_abi_A_const_144 *lang.Keyword

var A_arbace_cpp_abi_A_const_145 *lang.Keyword

var A_arbace_cpp_abi_A_const_146 *lang.Keyword

var A_arbace_cpp_abi_A_const_147 *lang.Var

var A_arbace_cpp_abi_A_const_148 *lang.Keyword

var A_arbace_cpp_abi_A_const_149 *lang.Keyword

var A_arbace_cpp_abi_A_const_150 *lang.Keyword

var A_arbace_cpp_abi_A_const_151 *lang.Var

var A_arbace_cpp_abi_A_const_152 *lang.Var

var A_arbace_cpp_abi_A_const_153 *lang.Var

var A_arbace_cpp_abi_A_const_154 *lang.Var

var A_arbace_cpp_abi_A_const_155 any

var A_arbace_cpp_abi_A_const_156 any

var A_arbace_cpp_abi_A_const_157 *lang.Var

var A_arbace_cpp_abi_A_const_158 any

var A_arbace_cpp_abi_A_const_159 any

var A_arbace_cpp_abi_A_const_160 *lang.Keyword

var A_arbace_cpp_abi_A_const_161 any

var A_arbace_cpp_abi_A_const_162 *lang.Keyword

var A_arbace_cpp_abi_A_const_163 any

var A_arbace_cpp_abi_A_const_164 *lang.Keyword

var A_arbace_cpp_abi_A_const_165 *lang.Keyword

var A_arbace_cpp_abi_A_const_166 any

var A_arbace_cpp_abi_A_const_167 any

var A_arbace_cpp_abi_A_const_168 *lang.Var

var A_arbace_cpp_abi_A_const_169 any

var A_arbace_cpp_abi_A_const_170 *lang.Keyword

var A_arbace_cpp_abi_A_const_171 any

var A_arbace_cpp_abi_A_const_172 *lang.Keyword

var A_arbace_cpp_abi_A_const_173 any

var A_arbace_cpp_abi_A_const_174 *lang.Keyword

var A_arbace_cpp_abi_A_const_175 any

var A_arbace_cpp_abi_A_const_176 *lang.Keyword

var A_arbace_cpp_abi_A_const_177 any

var A_arbace_cpp_abi_A_const_178 *lang.Keyword

var A_arbace_cpp_abi_A_const_179 *lang.Keyword

var A_arbace_cpp_abi_A_const_180 any

var A_arbace_cpp_abi_A_const_181 *lang.Keyword

var A_arbace_cpp_abi_A_const_182 any

var A_arbace_cpp_abi_A_const_183 *lang.Keyword

var A_arbace_cpp_abi_A_const_184 *lang.Keyword

var A_arbace_cpp_abi_A_const_185 any

var A_arbace_cpp_abi_A_const_186 *lang.Keyword

var A_arbace_cpp_abi_A_const_187 *lang.Keyword

var A_arbace_cpp_abi_A_const_188 *lang.Keyword

var A_arbace_cpp_abi_A_const_189 *lang.Keyword

var A_arbace_cpp_abi_A_const_190 *lang.Keyword

var A_arbace_cpp_abi_A_const_191 *lang.Keyword

var A_arbace_cpp_abi_A_const_192 *lang.Keyword

var A_arbace_cpp_abi_A_const_193 any

var A_arbace_cpp_abi_A_const_194 any

var A_arbace_cpp_abi_A_const_195 *lang.Keyword

var A_arbace_cpp_abi_A_const_196 *lang.Keyword

var A_arbace_cpp_abi_A_const_197 *lang.Keyword

var A_arbace_cpp_abi_A_const_198 any

var A_arbace_cpp_abi_A_const_199 *lang.Var

var A_arbace_cpp_abi_A_const_200 any

var A_arbace_cpp_abi_A_const_201 *lang.Var

var A_arbace_cpp_abi_A_const_202 *lang.Var

var A_arbace_cpp_abi_A_const_203 *lang.Var

var A_arbace_cpp_abi_A_const_204 *lang.Var

var A_arbace_cpp_abi_A_const_205 *lang.Var

var A_arbace_cpp_abi_A_const_206 *lang.Keyword

var A_arbace_cpp_abi_A_const_207 *lang.Keyword

var A_arbace_cpp_abi_A_const_208 *lang.Keyword

var A_arbace_cpp_abi_A_const_209 *lang.Var

var A_arbace_cpp_abi_A_const_210 *lang.Var

var A_arbace_cpp_abi_A_const_211 *lang.Keyword

var A_arbace_cpp_abi_A_const_212 *lang.Var

var A_arbace_cpp_abi_A_const_213 *lang.Keyword

var A_arbace_cpp_abi_A_const_214 *lang.Keyword

var A_arbace_cpp_abi_A_const_215 *lang.Keyword

var A_arbace_cpp_abi_A_const_216 any

var A_arbace_cpp_abi_A_const_217 any

var A_arbace_cpp_abi_A_const_218 *lang.Keyword

var A_arbace_cpp_abi_A_const_219 *lang.Keyword

var A_arbace_cpp_abi_A_const_220 any

var A_arbace_cpp_abi_A_const_221 any

var A_arbace_cpp_abi_A_const_222 *lang.Keyword

var A_arbace_cpp_abi_A_const_223 *lang.Var

var A_arbace_cpp_abi_A_const_224 any

var A_arbace_cpp_abi_A_const_225 *lang.Var

var A_arbace_cpp_abi_A_const_226 *lang.Var

var A_arbace_cpp_abi_A_const_227 *lang.Var

var A_arbace_cpp_abi_A_const_228 *lang.Var

var A_arbace_cpp_abi_A_const_229 *lang.Var

var A_arbace_cpp_abi_A_const_230 *lang.Var

var A_arbace_cpp_abi_A_const_231 *lang.Var

var A_arbace_cpp_abi_A_const_232 *lang.Var

var A_arbace_cpp_abi_A_const_233 *lang.Keyword

var A_arbace_cpp_abi_A_const_234 *lang.Var

var A_arbace_cpp_abi_A_const_235 *lang.Var

var A_arbace_cpp_abi_A_const_236 *lang.Var

var A_arbace_cpp_abi_A_const_237 *lang.Var

var A_arbace_cpp_abi_A_const_238 any

var A_arbace_cpp_abi_A_const_239 *lang.Keyword

var A_arbace_cpp_abi_A_const_240 *lang.Var

var A_arbace_cpp_abi_A_const_241 *lang.Keyword

var A_arbace_cpp_abi_A_const_242 *lang.Var

var A_arbace_cpp_abi_A_const_243 *lang.Keyword

var A_arbace_cpp_abi_A_const_244 *lang.Keyword

var A_arbace_cpp_abi_A_const_245 *lang.Var

var A_arbace_cpp_abi_A_const_246 *lang.Keyword

var A_arbace_cpp_abi_A_const_247 *lang.Keyword

var A_arbace_cpp_abi_A_const_248 *lang.Keyword

var A_arbace_cpp_abi_A_const_249 *lang.Keyword

var A_arbace_cpp_abi_A_const_250 *lang.Keyword

var A_arbace_cpp_abi_A_const_251 *lang.Keyword

var A_arbace_cpp_abi_A_const_252 *lang.Keyword

var A_arbace_cpp_abi_A_const_253 *lang.Var

var A_arbace_cpp_abi_A_const_254 *lang.Var

var A_arbace_cpp_abi_A_const_255 *lang.Keyword

var A_arbace_cpp_abi_A_const_256 *lang.Keyword

var A_arbace_cpp_abi_A_const_257 any

var A_arbace_cpp_abi_A_const_258 *lang.Keyword

var A_arbace_cpp_abi_A_const_259 *lang.Var

var A_arbace_cpp_abi_A_const_260 *lang.Keyword

var A_arbace_cpp_abi_A_const_261 *lang.Keyword

var A_arbace_cpp_abi_A_const_262 *lang.Var

var A_arbace_cpp_abi_A_const_263 *lang.Var

var A_arbace_cpp_abi_A_const_264 *lang.Keyword

var A_arbace_cpp_abi_A_const_265 *lang.Keyword

var A_arbace_cpp_abi_A_const_266 *lang.Keyword

var A_arbace_cpp_abi_A_const_267 *lang.Keyword

var A_arbace_cpp_abi_A_const_268 *lang.Keyword

var A_arbace_cpp_abi_A_const_269 *lang.Var

var A_arbace_cpp_abi_A_const_270 *lang.Keyword

var A_arbace_cpp_abi_A_const_271 *lang.Keyword

var A_arbace_cpp_abi_A_const_272 *lang.Keyword

var A_arbace_cpp_abi_A_const_273 *lang.Keyword

var A_arbace_cpp_abi_A_const_274 *lang.Var

var A_arbace_cpp_abi_A_const_275 *lang.Keyword

var A_arbace_cpp_abi_A_const_276 *lang.Keyword

var A_arbace_cpp_abi_A_const_277 *lang.Keyword

var A_arbace_cpp_abi_A_const_278 *lang.Keyword

var A_arbace_cpp_abi_A_const_279 *lang.Keyword

var A_arbace_cpp_abi_A_const_280 *lang.Keyword

var A_arbace_cpp_abi_A_const_281 *lang.Keyword

var A_arbace_cpp_abi_A_const_282 *lang.Keyword

var A_arbace_cpp_abi_A_const_283 *lang.Keyword

var A_arbace_cpp_abi_A_const_284 *lang.Keyword

var A_arbace_cpp_abi_A_const_285 *lang.Keyword

var A_arbace_cpp_abi_A_const_286 *lang.Keyword

var A_arbace_cpp_abi_A_const_287 *lang.Keyword

var A_arbace_cpp_abi_A_const_288 *lang.Keyword

var A_arbace_cpp_abi_A_const_289 *lang.Keyword

var A_arbace_cpp_abi_A_const_290 *lang.Keyword

var A_arbace_cpp_abi_A_const_291 *lang.Var

var A_arbace_cpp_abi_A_const_292 *lang.Keyword

var A_arbace_cpp_abi_A_const_293 any

var A_arbace_cpp_abi_A_const_294 any

var A_arbace_cpp_abi_A_const_295 *lang.Keyword

var A_arbace_cpp_abi_A_const_296 *lang.Keyword

var A_arbace_cpp_abi_A_const_297 *lang.Keyword

var A_arbace_cpp_abi_A_const_298 *lang.Keyword

var A_arbace_cpp_abi_A_const_299 *lang.Keyword

var A_arbace_cpp_abi_A_const_300 *lang.Keyword

var A_arbace_cpp_abi_A_const_301 *lang.Var

var A_arbace_cpp_abi_A_const_302 *lang.Var

var A_arbace_cpp_abi_A_const_303 *lang.Var

var A_arbace_cpp_abi_A_const_304 *lang.Var

var A_arbace_cpp_abi_A_const_305 *lang.Keyword

var A_arbace_cpp_abi_A_const_306 *lang.Keyword

var A_arbace_cpp_abi_A_const_307 *lang.Var

var A_arbace_cpp_abi_A_const_308 *lang.Keyword

var A_arbace_cpp_abi_A_const_309 *lang.Keyword

var A_arbace_cpp_abi_A_const_310 *lang.Keyword

var A_arbace_cpp_abi_A_const_311 *lang.Keyword

var A_arbace_cpp_abi_A_const_312 *lang.Keyword

var A_arbace_cpp_abi_A_const_313 *lang.Var

var A_arbace_cpp_abi_A_const_314 *lang.Var

var A_arbace_cpp_abi_A_const_315 *lang.Var

var A_arbace_cpp_abi_A_const_316 *lang.Var

var A_arbace_cpp_abi_A_const_317 *lang.Var

var A_arbace_cpp_abi_A_const_318 any

var A_arbace_cpp_abi_A_const_319 *lang.Keyword

var A_arbace_cpp_abi_A_const_320 *lang.Var

var A_arbace_cpp_abi_A_const_321 *lang.Var

var A_arbace_cpp_abi_A_const_322 *lang.Var

var A_arbace_cpp_abi_A_const_323 *lang.Var

var A_arbace_cpp_abi_A_const_324 *lang.Var

var A_arbace_cpp_abi_A_const_325 *lang.Var

var A_arbace_cpp_abi_A_const_326 *lang.Keyword

var A_arbace_cpp_abi_A_const_327 *lang.Keyword

var A_arbace_cpp_abi_A_const_328 *lang.Keyword

var A_arbace_cpp_abi_A_const_329 *lang.Keyword

var A_arbace_cpp_abi_A_const_330 *lang.Keyword

var A_arbace_cpp_abi_A_const_331 *lang.Keyword

var A_arbace_cpp_abi_A_const_332 *lang.Keyword

var A_arbace_cpp_abi_A_const_333 *lang.Keyword

var A_arbace_cpp_abi_A_const_334 any

var A_arbace_cpp_abi_A_const_335 *lang.Keyword

var A_arbace_cpp_abi_A_const_336 *lang.Var

var A_arbace_cpp_abi_A_const_337 *lang.Var

var A_arbace_cpp_abi_A_const_338 *lang.Var

var A_arbace_cpp_abi_A_const_339 any

var A_arbace_cpp_abi_A_const_340 *lang.Var

var A_arbace_cpp_abi_A_const_341 *lang.Var

var A_arbace_cpp_abi_A_const_342 *lang.Var

var A_arbace_cpp_abi_A_const_343 *lang.Var

var A_arbace_cpp_abi_A_const_344 *lang.Var

var A_arbace_cpp_abi_A_const_345 any

var A_arbace_cpp_abi_A_const_346 any

var A_arbace_cpp_abi_A_const_347 any

var A_arbace_cpp_abi_A_const_348 *lang.Keyword

var A_arbace_cpp_abi_A_const_349 any

var A_arbace_cpp_abi_A_const_350 *lang.Keyword

var A_arbace_cpp_abi_A_const_351 *lang.Keyword

var A_arbace_cpp_abi_A_const_352 any

var A_arbace_cpp_abi_A_const_353 *lang.Keyword

var A_arbace_cpp_abi_A_const_354 *lang.Keyword

var A_arbace_cpp_abi_A_const_355 *lang.Keyword

var A_arbace_cpp_abi_A_const_356 *lang.Keyword

var A_arbace_cpp_abi_A_const_357 *lang.Var

var A_arbace_cpp_abi_A_const_358 any

var A_arbace_cpp_abi_A_const_359 any

var A_arbace_cpp_abi_A_const_360 *lang.Keyword

var A_arbace_cpp_abi_A_const_361 any

var A_arbace_cpp_abi_A_const_362 *lang.Keyword

var A_arbace_cpp_abi_A_const_363 any

var A_arbace_cpp_abi_A_const_364 *lang.Keyword

var A_arbace_cpp_abi_A_const_365 *lang.Keyword

var A_arbace_cpp_abi_A_const_366 *lang.Var

var A_arbace_cpp_abi_A_const_367 *lang.Var

var A_arbace_cpp_abi_A_const_368 *lang.Keyword

var A_arbace_cpp_abi_A_const_369 any

var A_arbace_cpp_abi_A_const_370 *lang.Var

var A_arbace_cpp_abi_A_const_371 *lang.Keyword

var A_arbace_cpp_abi_A_const_372 *lang.Keyword

var A_arbace_cpp_abi_A_const_373 any

var A_arbace_cpp_abi_A_const_374 *lang.Var

var A_arbace_cpp_abi_A_const_375 *lang.Keyword

var A_arbace_cpp_abi_A_const_376 *lang.Keyword

var A_arbace_cpp_abi_A_const_377 *lang.Keyword

var A_arbace_cpp_abi_A_const_378 *lang.Keyword

var A_arbace_cpp_abi_A_const_379 *lang.Keyword

var A_arbace_cpp_abi_A_const_380 any

var A_arbace_cpp_abi_A_const_381 *lang.Keyword

var A_arbace_cpp_abi_A_const_382 *lang.Keyword

var A_arbace_cpp_abi_A_const_383 *lang.Keyword

var A_arbace_cpp_abi_A_const_384 any

var A_arbace_cpp_abi_A_const_385 any

var A_arbace_cpp_abi_A_const_386 any

var A_arbace_cpp_abi_A_const_387 *lang.Keyword

var A_arbace_cpp_abi_A_const_388 *lang.Keyword

var A_arbace_cpp_abi_A_const_389 *lang.Keyword

var A_arbace_cpp_abi_A_const_390 *lang.Keyword

var A_arbace_cpp_abi_A_const_391 *lang.Keyword

var A_arbace_cpp_abi_A_const_392 *lang.Var

var A_arbace_cpp_abi_A_const_393 *lang.Var

var A_arbace_cpp_abi_A_const_394 *lang.Var

var A_arbace_cpp_abi_A_const_395 *lang.Var

var A_arbace_cpp_abi_A_const_396 any

var A_arbace_cpp_abi_A_const_397 *lang.Keyword

var A_arbace_cpp_abi_A_const_398 any

var A_arbace_cpp_abi_A_const_399 *lang.Var

var A_arbace_cpp_abi_A_const_400 *lang.Var

var A_arbace_cpp_abi_A_const_401 *lang.Var

var A_arbace_cpp_abi_A_const_402 *lang.Var

var A_arbace_cpp_abi_A_init jrt.ClassInit

func A_arbace_cpp_abi_A_Init() { if !A_arbace_cpp_abi_A_init.Done() { A_arbace_cpp_abi_A_init.Run(A_arbace_cpp_abi_A_clinit) } }

func A_arbace_cpp_abi_A_clinit() { A_arbace_cpp_abi_A_clinit_p0(); A_arbace_cpp_abi_A_clinit_p1(); A_arbace_cpp_abi_A_clinit_p2(); A_arbace_cpp_abi_A_clinit_p3(); A_arbace_cpp_abi_A_clinit_p4(); A_arbace_cpp_abi_A_clinit_p5(); A_arbace_cpp_abi_A_clinit_p6(); A_arbace_cpp_abi_A_clinit_p7(); A_arbace_cpp_abi_A_clinit_p8(); A_arbace_cpp_abi_A_clinit_p9(); A_arbace_cpp_abi_A_clinit_p10(); A_arbace_cpp_abi_A_clinit_p11(); A_arbace_cpp_abi_A_clinit_p12(); A_arbace_cpp_abi_A_clinit_p13(); A_arbace_cpp_abi_A_clinit_p14(); A_arbace_cpp_abi_A_clinit_p15(); A_arbace_cpp_abi_A_clinit_p16(); A_arbace_cpp_abi_A_clinit_p17(); A_arbace_cpp_abi_A_clinit_p18(); A_arbace_cpp_abi_A_clinit_p19(); A_arbace_cpp_abi_A_clinit_p20(); A_arbace_cpp_abi_A_clinit_p21(); A_arbace_cpp_abi_A_clinit_p22(); A_arbace_cpp_abi_A_clinit_p23(); A_arbace_cpp_abi_A_clinit_p24(); A_arbace_cpp_abi_A_clinit_p25(); A_arbace_cpp_abi_A_clinit_p26(); A_arbace_cpp_abi_A_clinit_p27(); A_arbace_cpp_abi_A_clinit_p28(); A_arbace_cpp_abi_A_clinit_p29(); A_arbace_cpp_abi_A_clinit_p30(); A_arbace_cpp_abi_A_clinit_p31(); A_arbace_cpp_abi_A_clinit_p32(); A_arbace_cpp_abi_A_clinit_p33() }

func A_arbace_cpp_abi_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_abi_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 610); A_arbace_cpp_abi_A_const_0 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[207]); A_arbace_cpp_abi_A_const_1 = A_arbace_cpp_abi_A_const_pool.A[208]; A_arbace_cpp_abi_A_const_2 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[209]); A_arbace_cpp_abi_A_const_3 = A_arbace_cpp_abi_A_const_pool.A[210]; A_arbace_cpp_abi_A_const_4 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[211]); A_arbace_cpp_abi_A_const_5 = A_arbace_cpp_abi_A_const_pool.A[212]; A_arbace_cpp_abi_A_const_6 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[213]); A_arbace_cpp_abi_A_const_7 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[214]); A_arbace_cpp_abi_A_const_8 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[215]); A_arbace_cpp_abi_A_const_9 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[216]); A_arbace_cpp_abi_A_const_10 = A_arbace_cpp_abi_A_const_pool.A[217]; A_arbace_cpp_abi_A_const_11 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[218]) }

func A_arbace_cpp_abi_A_clinit_p1() { A_arbace_cpp_abi_A_const_12 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[219]); A_arbace_cpp_abi_A_const_13 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[220]); A_arbace_cpp_abi_A_const_14 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[221]); A_arbace_cpp_abi_A_const_15 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[222]); A_arbace_cpp_abi_A_const_16 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[223]); A_arbace_cpp_abi_A_const_17 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[224]); A_arbace_cpp_abi_A_const_18 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[225]); A_arbace_cpp_abi_A_const_19 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[226]); A_arbace_cpp_abi_A_const_20 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[227]); A_arbace_cpp_abi_A_const_21 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[228]); A_arbace_cpp_abi_A_const_22 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[229]); A_arbace_cpp_abi_A_const_23 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[230]) }

func A_arbace_cpp_abi_A_clinit_p2() { A_arbace_cpp_abi_A_const_24 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[231]); A_arbace_cpp_abi_A_const_25 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[232]); A_arbace_cpp_abi_A_const_26 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[233]); A_arbace_cpp_abi_A_const_27 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[234]); A_arbace_cpp_abi_A_const_28 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[235]); A_arbace_cpp_abi_A_const_29 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[236]); A_arbace_cpp_abi_A_const_30 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[237]); A_arbace_cpp_abi_A_const_31 = A_arbace_cpp_abi_A_const_pool.A[238]; A_arbace_cpp_abi_A_const_32 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[239]); A_arbace_cpp_abi_A_const_33 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[240]); A_arbace_cpp_abi_A_const_34 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[241]); A_arbace_cpp_abi_A_const_35 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[242]) }

func A_arbace_cpp_abi_A_clinit_p3() { A_arbace_cpp_abi_A_const_36 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[243]); A_arbace_cpp_abi_A_const_37 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[244]); A_arbace_cpp_abi_A_const_38 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[245]); A_arbace_cpp_abi_A_const_39 = A_arbace_cpp_abi_A_const_pool.A[246]; A_arbace_cpp_abi_A_const_40 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[247]); A_arbace_cpp_abi_A_const_41 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[248]); A_arbace_cpp_abi_A_const_42 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[249]); A_arbace_cpp_abi_A_const_43 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[250]); A_arbace_cpp_abi_A_const_44 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[251]); A_arbace_cpp_abi_A_const_45 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[252]); A_arbace_cpp_abi_A_const_46 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[253]); A_arbace_cpp_abi_A_const_47 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[254]) }

func A_arbace_cpp_abi_A_clinit_p4() { A_arbace_cpp_abi_A_const_48 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[255]); A_arbace_cpp_abi_A_const_49 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[256]); A_arbace_cpp_abi_A_const_50 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[257]); A_arbace_cpp_abi_A_const_51 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[258]); A_arbace_cpp_abi_A_const_52 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[259]); A_arbace_cpp_abi_A_const_53 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[260]); A_arbace_cpp_abi_A_const_54 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[261]); A_arbace_cpp_abi_A_const_55 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[262]); A_arbace_cpp_abi_A_const_56 = A_arbace_cpp_abi_A_const_pool.A[263]; A_arbace_cpp_abi_A_const_57 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[264]); A_arbace_cpp_abi_A_const_58 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[265]); A_arbace_cpp_abi_A_const_59 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[266]) }

func A_arbace_cpp_abi_A_clinit_p5() { A_arbace_cpp_abi_A_const_60 = A_arbace_cpp_abi_A_const_pool.A[267]; A_arbace_cpp_abi_A_const_61 = A_arbace_cpp_abi_A_const_pool.A[268]; A_arbace_cpp_abi_A_const_62 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[269]); A_arbace_cpp_abi_A_const_63 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[270]); A_arbace_cpp_abi_A_const_64 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[271]); A_arbace_cpp_abi_A_const_65 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[272]); A_arbace_cpp_abi_A_const_66 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[273]); A_arbace_cpp_abi_A_const_67 = A_arbace_cpp_abi_A_const_pool.A[274]; A_arbace_cpp_abi_A_const_68 = A_arbace_cpp_abi_A_const_pool.A[275]; A_arbace_cpp_abi_A_const_69 = A_arbace_cpp_abi_A_const_pool.A[276]; A_arbace_cpp_abi_A_const_70 = A_arbace_cpp_abi_A_const_pool.A[277]; A_arbace_cpp_abi_A_const_71 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[278]); A_arbace_cpp_abi_A_const_72 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[279]) }

func A_arbace_cpp_abi_A_clinit_p6() { A_arbace_cpp_abi_A_const_73 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[280]); A_arbace_cpp_abi_A_const_74 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[281]); A_arbace_cpp_abi_A_const_75 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[282]); A_arbace_cpp_abi_A_const_76 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[283]); A_arbace_cpp_abi_A_const_77 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[284]); A_arbace_cpp_abi_A_const_78 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[285]); A_arbace_cpp_abi_A_const_79 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[286]); A_arbace_cpp_abi_A_const_80 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[287]); A_arbace_cpp_abi_A_const_81 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[288]); A_arbace_cpp_abi_A_const_82 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[289]); A_arbace_cpp_abi_A_const_83 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[290]); A_arbace_cpp_abi_A_const_84 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[291]) }

func A_arbace_cpp_abi_A_clinit_p7() { A_arbace_cpp_abi_A_const_85 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[292]); A_arbace_cpp_abi_A_const_86 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[293]); A_arbace_cpp_abi_A_const_87 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[294]); A_arbace_cpp_abi_A_const_88 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[295]); A_arbace_cpp_abi_A_const_89 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[296]); A_arbace_cpp_abi_A_const_90 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[297]); A_arbace_cpp_abi_A_const_91 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[298]); A_arbace_cpp_abi_A_const_92 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[299]); A_arbace_cpp_abi_A_const_93 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[300]); A_arbace_cpp_abi_A_const_94 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[301]); A_arbace_cpp_abi_A_const_95 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[302]); A_arbace_cpp_abi_A_const_96 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[303]) }

func A_arbace_cpp_abi_A_clinit_p8() { A_arbace_cpp_abi_A_const_97 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[304]); A_arbace_cpp_abi_A_const_98 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[305]); A_arbace_cpp_abi_A_const_99 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[306]); A_arbace_cpp_abi_A_const_100 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[307]); A_arbace_cpp_abi_A_const_101 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[308]); A_arbace_cpp_abi_A_const_102 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[309]); A_arbace_cpp_abi_A_const_103 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[310]); A_arbace_cpp_abi_A_const_104 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[311]); A_arbace_cpp_abi_A_const_105 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[312]); A_arbace_cpp_abi_A_const_106 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[313]); A_arbace_cpp_abi_A_const_107 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[314]); A_arbace_cpp_abi_A_const_108 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[315]) }

func A_arbace_cpp_abi_A_clinit_p9() { A_arbace_cpp_abi_A_const_109 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[316]); A_arbace_cpp_abi_A_const_110 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[317]); A_arbace_cpp_abi_A_const_111 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[318]); A_arbace_cpp_abi_A_const_112 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[319]); A_arbace_cpp_abi_A_const_113 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[320]); A_arbace_cpp_abi_A_const_114 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[321]); A_arbace_cpp_abi_A_const_115 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[322]); A_arbace_cpp_abi_A_const_116 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[323]); A_arbace_cpp_abi_A_const_117 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[324]); A_arbace_cpp_abi_A_const_118 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[325]); A_arbace_cpp_abi_A_const_119 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[326]); A_arbace_cpp_abi_A_const_120 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[327]) }

func A_arbace_cpp_abi_A_clinit_p10() { A_arbace_cpp_abi_A_const_121 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[328]); A_arbace_cpp_abi_A_const_122 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[329]); A_arbace_cpp_abi_A_const_123 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[330]); A_arbace_cpp_abi_A_const_124 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[331]); A_arbace_cpp_abi_A_const_125 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[332]); A_arbace_cpp_abi_A_const_126 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[333]); A_arbace_cpp_abi_A_const_127 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[334]); A_arbace_cpp_abi_A_const_128 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[335]); A_arbace_cpp_abi_A_const_129 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[336]); A_arbace_cpp_abi_A_const_130 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[337]); A_arbace_cpp_abi_A_const_131 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[338]); A_arbace_cpp_abi_A_const_132 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[339]) }

func A_arbace_cpp_abi_A_clinit_p11() { A_arbace_cpp_abi_A_const_133 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[340]); A_arbace_cpp_abi_A_const_134 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[341]); A_arbace_cpp_abi_A_const_135 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[342]); A_arbace_cpp_abi_A_const_136 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[343]); A_arbace_cpp_abi_A_const_137 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[344]); A_arbace_cpp_abi_A_const_138 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[345]); A_arbace_cpp_abi_A_const_139 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[346]); A_arbace_cpp_abi_A_const_140 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[347]); A_arbace_cpp_abi_A_const_141 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[348]); A_arbace_cpp_abi_A_const_142 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[349]); A_arbace_cpp_abi_A_const_143 = A_arbace_cpp_abi_A_const_pool.A[350]; A_arbace_cpp_abi_A_const_144 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[351]) }

func A_arbace_cpp_abi_A_clinit_p12() { A_arbace_cpp_abi_A_const_145 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[352]); A_arbace_cpp_abi_A_const_146 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[353]); A_arbace_cpp_abi_A_const_147 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[354]); A_arbace_cpp_abi_A_const_148 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[355]); A_arbace_cpp_abi_A_const_149 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[356]); A_arbace_cpp_abi_A_const_150 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[357]); A_arbace_cpp_abi_A_const_151 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[358]); A_arbace_cpp_abi_A_const_152 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[359]); A_arbace_cpp_abi_A_const_153 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[360]); A_arbace_cpp_abi_A_const_154 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[361]); A_arbace_cpp_abi_A_const_155 = A_arbace_cpp_abi_A_const_pool.A[362]; A_arbace_cpp_abi_A_const_156 = A_arbace_cpp_abi_A_const_pool.A[363] }

func A_arbace_cpp_abi_A_clinit_p13() { A_arbace_cpp_abi_A_const_157 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[364]); A_arbace_cpp_abi_A_const_158 = A_arbace_cpp_abi_A_const_pool.A[365]; A_arbace_cpp_abi_A_const_159 = A_arbace_cpp_abi_A_const_pool.A[366]; A_arbace_cpp_abi_A_const_160 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[367]); A_arbace_cpp_abi_A_const_161 = A_arbace_cpp_abi_A_const_pool.A[368]; A_arbace_cpp_abi_A_const_162 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[369]); A_arbace_cpp_abi_A_const_163 = A_arbace_cpp_abi_A_const_pool.A[370]; A_arbace_cpp_abi_A_const_164 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[371]); A_arbace_cpp_abi_A_const_165 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[372]); A_arbace_cpp_abi_A_const_166 = A_arbace_cpp_abi_A_const_pool.A[373]; A_arbace_cpp_abi_A_const_167 = A_arbace_cpp_abi_A_const_pool.A[374]; A_arbace_cpp_abi_A_const_168 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[375]); A_arbace_cpp_abi_A_const_169 = A_arbace_cpp_abi_A_const_pool.A[376] }

func A_arbace_cpp_abi_A_clinit_p14() { A_arbace_cpp_abi_A_const_170 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[377]); A_arbace_cpp_abi_A_const_171 = A_arbace_cpp_abi_A_const_pool.A[378]; A_arbace_cpp_abi_A_const_172 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[379]); A_arbace_cpp_abi_A_const_173 = A_arbace_cpp_abi_A_const_pool.A[380]; A_arbace_cpp_abi_A_const_174 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[381]); A_arbace_cpp_abi_A_const_175 = A_arbace_cpp_abi_A_const_pool.A[382]; A_arbace_cpp_abi_A_const_176 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[383]); A_arbace_cpp_abi_A_const_177 = A_arbace_cpp_abi_A_const_pool.A[384]; A_arbace_cpp_abi_A_const_178 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[385]); A_arbace_cpp_abi_A_const_179 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[386]); A_arbace_cpp_abi_A_const_180 = A_arbace_cpp_abi_A_const_pool.A[387]; A_arbace_cpp_abi_A_const_181 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[388]); A_arbace_cpp_abi_A_const_182 = A_arbace_cpp_abi_A_const_pool.A[389] }

func A_arbace_cpp_abi_A_clinit_p15() { A_arbace_cpp_abi_A_const_183 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[390]); A_arbace_cpp_abi_A_const_184 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[391]); A_arbace_cpp_abi_A_const_185 = A_arbace_cpp_abi_A_const_pool.A[392]; A_arbace_cpp_abi_A_const_186 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[393]); A_arbace_cpp_abi_A_const_187 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[394]); A_arbace_cpp_abi_A_const_188 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[395]); A_arbace_cpp_abi_A_const_189 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[396]); A_arbace_cpp_abi_A_const_190 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[397]); A_arbace_cpp_abi_A_const_191 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[398]); A_arbace_cpp_abi_A_const_192 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[399]); A_arbace_cpp_abi_A_const_193 = A_arbace_cpp_abi_A_const_pool.A[400]; A_arbace_cpp_abi_A_const_194 = A_arbace_cpp_abi_A_const_pool.A[401] }

func A_arbace_cpp_abi_A_clinit_p16() { A_arbace_cpp_abi_A_const_195 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[402]); A_arbace_cpp_abi_A_const_196 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[403]); A_arbace_cpp_abi_A_const_197 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[404]); A_arbace_cpp_abi_A_const_198 = A_arbace_cpp_abi_A_const_pool.A[405]; A_arbace_cpp_abi_A_const_199 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[406]); A_arbace_cpp_abi_A_const_200 = A_arbace_cpp_abi_A_const_pool.A[407]; A_arbace_cpp_abi_A_const_201 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[408]); A_arbace_cpp_abi_A_const_202 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[409]); A_arbace_cpp_abi_A_const_203 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[410]); A_arbace_cpp_abi_A_const_204 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[411]); A_arbace_cpp_abi_A_const_205 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[412]); A_arbace_cpp_abi_A_const_206 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[413]) }

func A_arbace_cpp_abi_A_clinit_p17() { A_arbace_cpp_abi_A_const_207 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[414]); A_arbace_cpp_abi_A_const_208 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[415]); A_arbace_cpp_abi_A_const_209 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[416]); A_arbace_cpp_abi_A_const_210 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[417]); A_arbace_cpp_abi_A_const_211 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[418]); A_arbace_cpp_abi_A_const_212 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[419]); A_arbace_cpp_abi_A_const_213 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[420]); A_arbace_cpp_abi_A_const_214 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[421]); A_arbace_cpp_abi_A_const_215 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[422]); A_arbace_cpp_abi_A_const_216 = A_arbace_cpp_abi_A_const_pool.A[423]; A_arbace_cpp_abi_A_const_217 = A_arbace_cpp_abi_A_const_pool.A[424]; A_arbace_cpp_abi_A_const_218 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[425]) }

func A_arbace_cpp_abi_A_clinit_p18() { A_arbace_cpp_abi_A_const_219 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[426]); A_arbace_cpp_abi_A_const_220 = A_arbace_cpp_abi_A_const_pool.A[427]; A_arbace_cpp_abi_A_const_221 = A_arbace_cpp_abi_A_const_pool.A[428]; A_arbace_cpp_abi_A_const_222 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[429]); A_arbace_cpp_abi_A_const_223 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[430]); A_arbace_cpp_abi_A_const_224 = A_arbace_cpp_abi_A_const_pool.A[431]; A_arbace_cpp_abi_A_const_225 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[432]); A_arbace_cpp_abi_A_const_226 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[433]); A_arbace_cpp_abi_A_const_227 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[434]); A_arbace_cpp_abi_A_const_228 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[435]); A_arbace_cpp_abi_A_const_229 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[436]); A_arbace_cpp_abi_A_const_230 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[437]) }

func A_arbace_cpp_abi_A_clinit_p19() { A_arbace_cpp_abi_A_const_231 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[438]); A_arbace_cpp_abi_A_const_232 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[439]); A_arbace_cpp_abi_A_const_233 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[440]); A_arbace_cpp_abi_A_const_234 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[441]); A_arbace_cpp_abi_A_const_235 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[442]); A_arbace_cpp_abi_A_const_236 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[443]); A_arbace_cpp_abi_A_const_237 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[444]); A_arbace_cpp_abi_A_const_238 = A_arbace_cpp_abi_A_const_pool.A[445]; A_arbace_cpp_abi_A_const_239 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[446]); A_arbace_cpp_abi_A_const_240 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[447]); A_arbace_cpp_abi_A_const_241 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[448]); A_arbace_cpp_abi_A_const_242 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[449]) }

func A_arbace_cpp_abi_A_clinit_p20() { A_arbace_cpp_abi_A_const_243 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[450]); A_arbace_cpp_abi_A_const_244 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[451]); A_arbace_cpp_abi_A_const_245 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[452]); A_arbace_cpp_abi_A_const_246 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[453]); A_arbace_cpp_abi_A_const_247 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[454]); A_arbace_cpp_abi_A_const_248 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[455]); A_arbace_cpp_abi_A_const_249 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[456]); A_arbace_cpp_abi_A_const_250 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[457]); A_arbace_cpp_abi_A_const_251 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[458]); A_arbace_cpp_abi_A_const_252 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[459]); A_arbace_cpp_abi_A_const_253 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[460]); A_arbace_cpp_abi_A_const_254 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[461]) }

func A_arbace_cpp_abi_A_clinit_p21() { A_arbace_cpp_abi_A_const_255 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[462]); A_arbace_cpp_abi_A_const_256 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[463]); A_arbace_cpp_abi_A_const_257 = A_arbace_cpp_abi_A_const_pool.A[464]; A_arbace_cpp_abi_A_const_258 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[465]); A_arbace_cpp_abi_A_const_259 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[466]); A_arbace_cpp_abi_A_const_260 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[467]); A_arbace_cpp_abi_A_const_261 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[468]); A_arbace_cpp_abi_A_const_262 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[469]); A_arbace_cpp_abi_A_const_263 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[470]); A_arbace_cpp_abi_A_const_264 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[471]); A_arbace_cpp_abi_A_const_265 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[472]); A_arbace_cpp_abi_A_const_266 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[473]) }

func A_arbace_cpp_abi_A_clinit_p22() { A_arbace_cpp_abi_A_const_267 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[474]); A_arbace_cpp_abi_A_const_268 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[475]); A_arbace_cpp_abi_A_const_269 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[476]); A_arbace_cpp_abi_A_const_270 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[477]); A_arbace_cpp_abi_A_const_271 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[478]); A_arbace_cpp_abi_A_const_272 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[479]); A_arbace_cpp_abi_A_const_273 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[480]); A_arbace_cpp_abi_A_const_274 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[481]); A_arbace_cpp_abi_A_const_275 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[482]); A_arbace_cpp_abi_A_const_276 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[483]); A_arbace_cpp_abi_A_const_277 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[484]); A_arbace_cpp_abi_A_const_278 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[485]) }

func A_arbace_cpp_abi_A_clinit_p23() { A_arbace_cpp_abi_A_const_279 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[486]); A_arbace_cpp_abi_A_const_280 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[487]); A_arbace_cpp_abi_A_const_281 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[488]); A_arbace_cpp_abi_A_const_282 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[489]); A_arbace_cpp_abi_A_const_283 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[490]); A_arbace_cpp_abi_A_const_284 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[491]); A_arbace_cpp_abi_A_const_285 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[492]); A_arbace_cpp_abi_A_const_286 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[493]); A_arbace_cpp_abi_A_const_287 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[494]); A_arbace_cpp_abi_A_const_288 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[495]); A_arbace_cpp_abi_A_const_289 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[496]); A_arbace_cpp_abi_A_const_290 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[497]) }

func A_arbace_cpp_abi_A_clinit_p24() { A_arbace_cpp_abi_A_const_291 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[498]); A_arbace_cpp_abi_A_const_292 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[499]); A_arbace_cpp_abi_A_const_293 = A_arbace_cpp_abi_A_const_pool.A[500]; A_arbace_cpp_abi_A_const_294 = A_arbace_cpp_abi_A_const_pool.A[501]; A_arbace_cpp_abi_A_const_295 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[502]); A_arbace_cpp_abi_A_const_296 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[503]); A_arbace_cpp_abi_A_const_297 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[504]); A_arbace_cpp_abi_A_const_298 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[505]); A_arbace_cpp_abi_A_const_299 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[506]); A_arbace_cpp_abi_A_const_300 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[507]); A_arbace_cpp_abi_A_const_301 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[508]); A_arbace_cpp_abi_A_const_302 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[509]) }

func A_arbace_cpp_abi_A_clinit_p25() { A_arbace_cpp_abi_A_const_303 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[510]); A_arbace_cpp_abi_A_const_304 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[511]); A_arbace_cpp_abi_A_const_305 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[512]); A_arbace_cpp_abi_A_const_306 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[513]); A_arbace_cpp_abi_A_const_307 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[514]); A_arbace_cpp_abi_A_const_308 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[515]); A_arbace_cpp_abi_A_const_309 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[516]); A_arbace_cpp_abi_A_const_310 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[517]); A_arbace_cpp_abi_A_const_311 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[518]); A_arbace_cpp_abi_A_const_312 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[519]); A_arbace_cpp_abi_A_const_313 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[520]); A_arbace_cpp_abi_A_const_314 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[521]) }

func A_arbace_cpp_abi_A_clinit_p26() { A_arbace_cpp_abi_A_const_315 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[522]); A_arbace_cpp_abi_A_const_316 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[523]); A_arbace_cpp_abi_A_const_317 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[524]); A_arbace_cpp_abi_A_const_318 = A_arbace_cpp_abi_A_const_pool.A[525]; A_arbace_cpp_abi_A_const_319 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[526]); A_arbace_cpp_abi_A_const_320 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[527]); A_arbace_cpp_abi_A_const_321 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[528]); A_arbace_cpp_abi_A_const_322 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[529]); A_arbace_cpp_abi_A_const_323 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[530]); A_arbace_cpp_abi_A_const_324 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[531]); A_arbace_cpp_abi_A_const_325 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[532]); A_arbace_cpp_abi_A_const_326 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[533]) }

func A_arbace_cpp_abi_A_clinit_p27() { A_arbace_cpp_abi_A_const_327 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[534]); A_arbace_cpp_abi_A_const_328 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[535]); A_arbace_cpp_abi_A_const_329 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[536]); A_arbace_cpp_abi_A_const_330 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[537]); A_arbace_cpp_abi_A_const_331 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[538]); A_arbace_cpp_abi_A_const_332 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[539]); A_arbace_cpp_abi_A_const_333 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[540]); A_arbace_cpp_abi_A_const_334 = A_arbace_cpp_abi_A_const_pool.A[541]; A_arbace_cpp_abi_A_const_335 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[542]); A_arbace_cpp_abi_A_const_336 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[543]); A_arbace_cpp_abi_A_const_337 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[544]); A_arbace_cpp_abi_A_const_338 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[545]) }

func A_arbace_cpp_abi_A_clinit_p28() { A_arbace_cpp_abi_A_const_339 = A_arbace_cpp_abi_A_const_pool.A[546]; A_arbace_cpp_abi_A_const_340 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[547]); A_arbace_cpp_abi_A_const_341 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[548]); A_arbace_cpp_abi_A_const_342 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[549]); A_arbace_cpp_abi_A_const_343 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[550]); A_arbace_cpp_abi_A_const_344 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[551]); A_arbace_cpp_abi_A_const_345 = A_arbace_cpp_abi_A_const_pool.A[552]; A_arbace_cpp_abi_A_const_346 = A_arbace_cpp_abi_A_const_pool.A[553]; A_arbace_cpp_abi_A_const_347 = A_arbace_cpp_abi_A_const_pool.A[554]; A_arbace_cpp_abi_A_const_348 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[555]); A_arbace_cpp_abi_A_const_349 = A_arbace_cpp_abi_A_const_pool.A[556]; A_arbace_cpp_abi_A_const_350 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[557]); A_arbace_cpp_abi_A_const_351 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[558]) }

func A_arbace_cpp_abi_A_clinit_p29() { A_arbace_cpp_abi_A_const_352 = A_arbace_cpp_abi_A_const_pool.A[559]; A_arbace_cpp_abi_A_const_353 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[560]); A_arbace_cpp_abi_A_const_354 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[561]); A_arbace_cpp_abi_A_const_355 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[562]); A_arbace_cpp_abi_A_const_356 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[563]); A_arbace_cpp_abi_A_const_357 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[564]); A_arbace_cpp_abi_A_const_358 = A_arbace_cpp_abi_A_const_pool.A[565]; A_arbace_cpp_abi_A_const_359 = A_arbace_cpp_abi_A_const_pool.A[566]; A_arbace_cpp_abi_A_const_360 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[567]); A_arbace_cpp_abi_A_const_361 = A_arbace_cpp_abi_A_const_pool.A[568]; A_arbace_cpp_abi_A_const_362 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[569]); A_arbace_cpp_abi_A_const_363 = A_arbace_cpp_abi_A_const_pool.A[570]; A_arbace_cpp_abi_A_const_364 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[571]) }

func A_arbace_cpp_abi_A_clinit_p30() { A_arbace_cpp_abi_A_const_365 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[572]); A_arbace_cpp_abi_A_const_366 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[573]); A_arbace_cpp_abi_A_const_367 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[574]); A_arbace_cpp_abi_A_const_368 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[575]); A_arbace_cpp_abi_A_const_369 = A_arbace_cpp_abi_A_const_pool.A[576]; A_arbace_cpp_abi_A_const_370 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[577]); A_arbace_cpp_abi_A_const_371 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[578]); A_arbace_cpp_abi_A_const_372 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[579]); A_arbace_cpp_abi_A_const_373 = A_arbace_cpp_abi_A_const_pool.A[580]; A_arbace_cpp_abi_A_const_374 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[581]); A_arbace_cpp_abi_A_const_375 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[582]); A_arbace_cpp_abi_A_const_376 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[583]) }

func A_arbace_cpp_abi_A_clinit_p31() { A_arbace_cpp_abi_A_const_377 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[584]); A_arbace_cpp_abi_A_const_378 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[585]); A_arbace_cpp_abi_A_const_379 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[586]); A_arbace_cpp_abi_A_const_380 = A_arbace_cpp_abi_A_const_pool.A[587]; A_arbace_cpp_abi_A_const_381 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[588]); A_arbace_cpp_abi_A_const_382 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[589]); A_arbace_cpp_abi_A_const_383 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[590]); A_arbace_cpp_abi_A_const_384 = A_arbace_cpp_abi_A_const_pool.A[591]; A_arbace_cpp_abi_A_const_385 = A_arbace_cpp_abi_A_const_pool.A[592]; A_arbace_cpp_abi_A_const_386 = A_arbace_cpp_abi_A_const_pool.A[593]; A_arbace_cpp_abi_A_const_387 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[594]); A_arbace_cpp_abi_A_const_388 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[595]); A_arbace_cpp_abi_A_const_389 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[596]) }

func A_arbace_cpp_abi_A_clinit_p32() { A_arbace_cpp_abi_A_const_390 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[597]); A_arbace_cpp_abi_A_const_391 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[598]); A_arbace_cpp_abi_A_const_392 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[599]); A_arbace_cpp_abi_A_const_393 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[600]); A_arbace_cpp_abi_A_const_394 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[601]); A_arbace_cpp_abi_A_const_395 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[602]); A_arbace_cpp_abi_A_const_396 = A_arbace_cpp_abi_A_const_pool.A[603]; A_arbace_cpp_abi_A_const_397 = lang.Keyword_Cast(A_arbace_cpp_abi_A_const_pool.A[604]); A_arbace_cpp_abi_A_const_398 = A_arbace_cpp_abi_A_const_pool.A[605]; A_arbace_cpp_abi_A_const_399 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[606]); A_arbace_cpp_abi_A_const_400 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[607]); A_arbace_cpp_abi_A_const_401 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[608]) }

func A_arbace_cpp_abi_A_clinit_p33() { A_arbace_cpp_abi_A_const_402 = lang.Var_Cast(A_arbace_cpp_abi_A_const_pool.A[609]) }

func A_arbace_cpp_abi_A_New() *A_arbace_cpp_abi_A { A_arbace_cpp_abi_A_Init(); t := &A_arbace_cpp_abi_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_abi_A) Ctor() {}

func (t *A_arbace_cpp_abi_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_abi_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_abi_A_class }

func (t *A_arbace_cpp_abi_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_abi_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_abi_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_abi_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_abi_A); return ok }

func A_arbace_cpp_abi_A_Cast(x any) *A_arbace_cpp_abi_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_abi_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_abi_A_class)) }; return v }



type A_arbace_cpp_abi_align_of_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_align_of_A_fn_class *jrt.Class



type A_arbace_cpp_abi_align_up_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_align_up_A_fn_class *jrt.Class



type A_arbace_cpp_abi_arith_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_arith_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_arr_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_arr_A_fn_class *jrt.Class



type A_arbace_cpp_abi_arr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_arr_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_b_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_b_A_fn_class *jrt.Class



type A_arbace_cpp_abi_bare_params_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_bare_params_A_fn_class *jrt.Class



type A_arbace_cpp_abi_base_path_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_base_path_A_fn_class *jrt.Class



type A_arbace_cpp_abi_base_path_fn__677000211_A struct{ j2g_header uint64; F_from, F_to any }

var A_arbace_cpp_abi_base_path_fn__677000211_A_fn_class *jrt.Class



type A_arbace_cpp_abi_bn_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_bn_A_fn_class *jrt.Class



type A_arbace_cpp_abi_can_place_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_can_place_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A struct{ j2g_header uint64; F_em any }

var A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_fn_class *jrt.Class



type A_arbace_cpp_abi_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_class_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_class_empties_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_class_empties_A_fn_class *jrt.Class



type A_arbace_cpp_abi_class_empties_fn__677000116_A struct{ j2g_header uint64; F_l any; F_off int64 }

var A_arbace_cpp_abi_class_empties_fn__677000116_A_fn_class *jrt.Class



type A_arbace_cpp_abi_class_empties_fn__677000119_A struct{ j2g_header uint64; F_off int64 }

var A_arbace_cpp_abi_class_empties_fn__677000119_A_fn_class *jrt.Class



type A_arbace_cpp_abi_class_empties_fn__677000124_A struct{ j2g_header uint64; F_off int64 }

var A_arbace_cpp_abi_class_empties_fn__677000124_A_fn_class *jrt.Class



type A_arbace_cpp_abi_classify_class_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_classify_class_A_fn_class *jrt.Class



type A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A struct{ j2g_header uint64; F_e0, F_e1, F_hi, F_lo any }

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_fn_class *jrt.Class



type A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A struct{ j2g_header uint64; F_iter__677000413, F_e0, F_e1, F_s__677000414, F_hi, F_lo any }

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_fn_class *jrt.Class



type A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A struct{ j2g_header uint64; F_e0, F_e1, F_b__677000416, F_hi any; F_size__1927001038__auto__ int32; F_lo, F_c__1927001037__auto__ any }

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_fn_class *jrt.Class



type A_arbace_cpp_abi_classify_into_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_classify_into_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_cls_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_cls_A_fn_class *jrt.Class



type A_arbace_cpp_abi_cls_of_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_cls_of_A_fn_class *jrt.Class



type A_arbace_cpp_abi_constq_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_constq_A_fn_class *jrt.Class



type A_arbace_cpp_abi_cvq_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_cvq_A_fn_class *jrt.Class



type A_arbace_cpp_abi_derived_from_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_derived_from_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_dollar_name_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_dollar_name_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A struct{ j2g_header uint64; F_c, F_k any; F_n int64; F_nm any }

var A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_fn_class *jrt.Class



type A_arbace_cpp_abi_dt_standin_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_dt_standin_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_dt_unresolved_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_dt_unresolved_A_fn_class *jrt.Class



type A_arbace_cpp_abi_dynamic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_dynamic_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_fn_class *jrt.Class



type A_arbace_cpp_abi_empty_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_empty_class_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_fn_class *jrt.Class



type A_arbace_cpp_abi_empty_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_empty_member_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_encoding_STAR__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_encoding_STAR__A_fn_class *jrt.Class



type A_arbace_cpp_abi_encoding_STAR__uname__677000356_A struct{ j2g_header uint64; F_variant, F_f, F_ti any }

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_fn_class *jrt.Class



type A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A struct{ j2g_header uint64; F_ti any }

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_fn_class *jrt.Class



type A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A struct{ j2g_header uint64; F_q, F_saved any }

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_fn_class *jrt.Class



type A_arbace_cpp_abi_enm_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_enm_A_fn_class *jrt.Class



type A_arbace_cpp_abi_enum_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_enum_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_eval677000004_A struct{ jrt.Object }

func A_arbace_cpp_abi_eval677000004_A_New() *A_arbace_cpp_abi_eval677000004_A { t := &A_arbace_cpp_abi_eval677000004_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_abi_eval677000004_A) Ctor() {}

func (t *A_arbace_cpp_abi_eval677000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_abi_eval677000004_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_abi_eval677000004_A_class }

func (t *A_arbace_cpp_abi_eval677000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_abi_eval677000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_abi_eval677000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_abi_eval677000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_abi_eval677000004_A); return ok }

func A_arbace_cpp_abi_eval677000004_A_Cast(x any) *A_arbace_cpp_abi_eval677000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_abi_eval677000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_abi_eval677000004_A_class)) }; return v }



type A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A_fn_class *jrt.Class



type A_arbace_cpp_abi_eval677000008_A struct{ jrt.Object }

func A_arbace_cpp_abi_eval677000008_A_New() *A_arbace_cpp_abi_eval677000008_A { t := &A_arbace_cpp_abi_eval677000008_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_abi_eval677000008_A) Ctor() {}

func (t *A_arbace_cpp_abi_eval677000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_abi_eval677000008_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_abi_eval677000008_A_class }

func (t *A_arbace_cpp_abi_eval677000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_abi_eval677000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_abi_eval677000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_abi_eval677000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_abi_eval677000008_A); return ok }

func A_arbace_cpp_abi_eval677000008_A_Cast(x any) *A_arbace_cpp_abi_eval677000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_abi_eval677000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_abi_eval677000008_A_class)) }; return v }



type A_arbace_cpp_abi_eval677000008_fn__677000009_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_eval677000008_fn__677000009_A_fn_class *jrt.Class



type A_arbace_cpp_abi_fail_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_fail_A_fn_class *jrt.Class



type A_arbace_cpp_abi_field_empties_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_field_empties_A_fn_class *jrt.Class



type A_arbace_cpp_abi_field_empties_fn__677000109_A struct{ j2g_header uint64; F_t any }

var A_arbace_cpp_abi_field_empties_fn__677000109_A_fn_class *jrt.Class



type A_arbace_cpp_abi_field_empties_fn__677000111_A struct{ j2g_header uint64; F_t any }

var A_arbace_cpp_abi_field_empties_fn__677000111_A_fn_class *jrt.Class



type A_arbace_cpp_abi_field_empties_fn__677000113_A struct{ j2g_header uint64; F_sz int64; F_et any; F_off int64 }

var A_arbace_cpp_abi_field_empties_fn__677000113_A_fn_class *jrt.Class



type A_arbace_cpp_abi_field_offset_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_field_offset_A_fn_class *jrt.Class



type A_arbace_cpp_abi_floating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_floating_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_fn_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_fn_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_has_vbases_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_has_vbases_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_indirect_primaries_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_indirect_primaries_A_fn_class *jrt.Class



type A_arbace_cpp_abi_indirect_primaries_walk__677000074_A struct{ j2g_header uint64; F_out any }

var A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_fn_class *jrt.Class



type A_arbace_cpp_abi_integral_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_integral_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_kind_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_kind_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_layout_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_layout_STAR__A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000157_A struct{ j2g_header uint64; F_pb any }

var A_arbace_cpp_abi_layout_STAR__fn__677000157_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000159_A struct{ j2g_header uint64; F_pbi any }

var A_arbace_cpp_abi_layout_STAR__fn__677000159_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000162_A struct{ j2g_header uint64; F_floor, F_pbi, F_bases, F_em any }

var A_arbace_cpp_abi_layout_STAR__fn__677000162_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A struct{ j2g_header uint64; F_off any; F_ba int64; F_bid, F_em any }

var A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000169_A struct{ j2g_header uint64; F_boffm any }

var A_arbace_cpp_abi_layout_STAR__fn__677000169_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000172_A struct{ j2g_header uint64; F_floor, F_em, F_uni any }

var A_arbace_cpp_abi_layout_STAR__fn__677000172_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A struct{ j2g_header uint64; F_f any; F_a, F_dsz, F_o int64; F_em any }

var A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000195_A struct{ j2g_header uint64; F_floor, F_vbo, F_ip, F_mark_BANG_, F_em any }

var A_arbace_cpp_abi_layout_STAR__fn__677000195_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A struct{ j2g_header uint64; F_va int64; F_ds, F_v, F_em any }

var A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000202_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_layout_STAR__fn__677000202_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000204_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_layout_STAR__fn__677000204_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A struct{ j2g_header uint64; F_f any }

var A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_fn_class *jrt.Class



type A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A struct{ j2g_header uint64; F_vbo any }

var A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_fn_class *jrt.Class



type A_arbace_cpp_abi_llvm_type_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_llvm_type_A_fn_class *jrt.Class



type A_arbace_cpp_abi_local_enc_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_local_enc_A_fn_class *jrt.Class



type A_arbace_cpp_abi_local_encoding_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_local_encoding_A_fn_class *jrt.Class



type A_arbace_cpp_abi_lref_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_lref_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_constraint_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_arg__677000334_A struct{ j2g_header uint64; F_depth int64; F_ty, F_pidx any }

var A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ex__677000339_A struct{ j2g_header uint64; F_depth int64; F_ty, F_pidx, F_arg, F_req any }

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_req__677000336_A struct{ j2g_header uint64; F_ty, F_ex any }

var A_arbace_cpp_abi_mangle_constraint_req__677000336_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_tt__677000332_A struct{ j2g_header uint64; F_depth int64; F_pidx any }

var A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_constraint_ty__677000330_A struct{ j2g_header uint64; F_depth int64; F_pidx, F_tt any }

var A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_ctor_vtable_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_ctor_vtable_name_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_dt_expr_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_dt_expr_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_expr_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_expr_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_expr_fn__677000260_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_expr_fn__677000260_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_fn_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_fn_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_local_static_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_local_static_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_local_static_fn__677000366_A struct{ j2g_header uint64; F_f any }

var A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_named_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_named_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_params_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_params_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_prefix_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_prefix_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_prefix_fn__677000246_A struct{ j2g_header uint64; F_n int32; F_idx any }

var A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_prefix_idx__677000244_A struct{ j2g_header uint64; F_parts any }

var A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_type_STAR__A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A struct{ j2g_header uint64; F_bare, F_sk any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A struct{ j2g_header uint64; F_base any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A struct{ j2g_header uint64; F_bare any }

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_type_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_type_name_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mangle_var_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mangle_var_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mark_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mark_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_mark_BANG__fn__677000374_A struct{ j2g_header uint64; F_e int64; F_cls any; F_end int64 }

var A_arbace_cpp_abi_mark_BANG__fn__677000374_A_fn_class *jrt.Class



type A_arbace_cpp_abi_merge_class_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_merge_class_A_fn_class *jrt.Class



type A_arbace_cpp_abi_mfn_ptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mfn_ptr_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_mptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_mptr_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_nearly_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_nearly_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_non_ref_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_non_ref_A_fn_class *jrt.Class



type A_arbace_cpp_abi_nonvirtual_subobjects_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_nonvirtual_subobjects_A_fn_class *jrt.Class



type A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A struct{ j2g_header uint64; F_l any; F_off int64 }

var A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_fn_class *jrt.Class



type A_arbace_cpp_abi_part_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_part_name_A_fn_class *jrt.Class



type A_arbace_cpp_abi_part_targs_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_part_targs_A_fn_class *jrt.Class



type A_arbace_cpp_abi_path_of_type_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_path_of_type_A_fn_class *jrt.Class



type A_arbace_cpp_abi_place_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_place_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_pod_for_layout_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_pod_for_layout_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_fn_class *jrt.Class



type A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_fn_class *jrt.Class



type A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A struct{ j2g_header uint64; F_f any }

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_fn_class *jrt.Class



type A_arbace_cpp_abi_primary_base_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_primary_base_A_fn_class *jrt.Class



type A_arbace_cpp_abi_primary_base_fn__677000082_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_primary_base_fn__677000082_A_fn_class *jrt.Class



type A_arbace_cpp_abi_primary_base_sel__677000084_A struct{ j2g_header uint64; F_first_ne, F_ip any }

var A_arbace_cpp_abi_primary_base_sel__677000084_A_fn_class *jrt.Class



type A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A struct{ j2g_header uint64; F_first_ne, F_ip, F_sel any }

var A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_fn_class *jrt.Class



type A_arbace_cpp_abi_ptr_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_ptr_A_fn_class *jrt.Class



type A_arbace_cpp_abi_ptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_ptr_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_q_param_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_q_param_A_fn_class *jrt.Class



type A_arbace_cpp_abi_q_param_fn__677000325_A struct{ j2g_header uint64; F_depth, F_i int64 }

var A_arbace_cpp_abi_q_param_fn__677000325_A_fn_class *jrt.Class



type A_arbace_cpp_abi_ref_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_rref_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_rref_A_fn_class *jrt.Class



type A_arbace_cpp_abi_same_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_same_type_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_scalar_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_scalar_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_scalar_class_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_scalar_class_A_fn_class *jrt.Class



type A_arbace_cpp_abi_seq_id_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_seq_id_A_fn_class *jrt.Class



type A_arbace_cpp_abi_signed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_signed_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_abi_size_align_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_size_align_A_fn_class *jrt.Class



type A_arbace_cpp_abi_size_of_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_size_of_A_fn_class *jrt.Class



type A_arbace_cpp_abi_skey_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_skey_A_fn_class *jrt.Class



type A_arbace_cpp_abi_skey_fn__677000274_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_skey_fn__677000274_A_fn_class *jrt.Class



type A_arbace_cpp_abi_source_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_source_name_A_fn_class *jrt.Class



type A_arbace_cpp_abi_std_abbreviation_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_std_abbreviation_A_fn_class *jrt.Class



type A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A struct{ j2g_header uint64; F_ch any }

var A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_fn_class *jrt.Class



type A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A struct{ j2g_header uint64; F_ch any }

var A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_fn_class *jrt.Class



type A_arbace_cpp_abi_sub_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_sub_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_sub_or_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_sub_or_A_fn_class *jrt.Class



type A_arbace_cpp_abi_template_arg_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_template_arg_A_fn_class *jrt.Class



type A_arbace_cpp_abi_template_arg_fn__677000267_A struct{ j2g_header uint64; F_a any }

var A_arbace_cpp_abi_template_arg_fn__677000267_A_fn_class *jrt.Class



type A_arbace_cpp_abi_template_args_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_template_args_A_fn_class *jrt.Class



type A_arbace_cpp_abi_template_param_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_template_param_A_fn_class *jrt.Class



type A_arbace_cpp_abi_template_prefix_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_template_prefix_A_fn_class *jrt.Class



type A_arbace_cpp_abi_tspec_unwrapped_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_tspec_unwrapped_A_fn_class *jrt.Class



type A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A struct{ j2g_header uint64; F_tt any }

var A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_fn_class *jrt.Class



type A_arbace_cpp_abi_underlying_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_underlying_A_fn_class *jrt.Class



type A_arbace_cpp_abi_unq_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_unq_A_fn_class *jrt.Class



type A_arbace_cpp_abi_unqualified_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_unqualified_name_A_fn_class *jrt.Class



type A_arbace_cpp_abi_unqualified_name_fn__677000317_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_unqualified_name_fn__677000317_A_fn_class *jrt.Class



type A_arbace_cpp_abi_unqualified_name_STAR__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_unqualified_name_STAR__A_fn_class *jrt.Class



type A_arbace_cpp_abi_update_cls_BANG__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_update_cls_BANG__A_fn_class *jrt.Class



type A_arbace_cpp_abi_vbases_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_vbases_A_fn_class *jrt.Class



type A_arbace_cpp_abi_vbases_walk__677000055_A struct{ j2g_header uint64; F_seen any }

var A_arbace_cpp_abi_vbases_walk__677000055_A_fn_class *jrt.Class



type A_arbace_cpp_abi_vbases_init_A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_vbases_init_A_fn_class *jrt.Class



type A_arbace_cpp_abi_vbases_init_walk__677000062_A struct{ j2g_header uint64; F_seen any }

var A_arbace_cpp_abi_vbases_init_walk__677000062_A_fn_class *jrt.Class



type A_arbace_cpp_abi_void_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_abi_void_QMARK__A_fn_class *jrt.Class
