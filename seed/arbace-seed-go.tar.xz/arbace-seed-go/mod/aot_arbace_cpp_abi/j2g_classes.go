//line j2g_classes.ae:1
package aot_arbace_cpp_abi

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_cpp_abi_align_of_A_class, Name: "arbace.cpp.abi$align_of", Modifiers: 25, Simple: "align_of", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_align_of_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_align_up_A_class, Name: "arbace.cpp.abi$align_up", Modifiers: 25, Simple: "align_up", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_align_up_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_arith_QMARK__A_class, Name: "arbace.cpp.abi$arith_QMARK_", Modifiers: 25, Simple: "arith_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_arith_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_arr_A_class, Name: "arbace.cpp.abi$arr", Modifiers: 25, Simple: "arr", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_arr_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_arr_QMARK__A_class, Name: "arbace.cpp.abi$arr_QMARK_", Modifiers: 25, Simple: "arr_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_arr_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_b_A_class, Name: "arbace.cpp.abi$b", Modifiers: 25, Simple: "b", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_b_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_bare_params_A_class, Name: "arbace.cpp.abi$bare_params", Modifiers: 25, Simple: "bare_params", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_bare_params_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_base_path_A_class, Name: "arbace.cpp.abi$base_path", Modifiers: 25, Simple: "base_path", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_base_path_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_base_path_fn__677000211_A_class, Name: "arbace.cpp.abi$base_path$fn__677000211", Modifiers: 25, Simple: "fn__677000211", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_base_path_fn__677000211_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_base_path_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_bn_A_class, Name: "arbace.cpp.abi$bn", Modifiers: 25, Simple: "bn", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_bn_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_can_place_QMARK__A_class, Name: "arbace.cpp.abi$can_place_QMARK_", Modifiers: 25, Simple: "can_place_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_can_place_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_class, Name: "arbace.cpp.abi$can_place_QMARK_$fn__677000128", Modifiers: 25, Simple: "fn__677000128", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_can_place_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_class_QMARK__A_class, Name: "arbace.cpp.abi$class_QMARK_", Modifiers: 25, Simple: "class_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_class_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_class_empties_A_class, Name: "arbace.cpp.abi$class_empties", Modifiers: 25, Simple: "class_empties", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_class_empties_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_class_empties_fn__677000116_A_class, Name: "arbace.cpp.abi$class_empties$fn__677000116", Modifiers: 25, Simple: "fn__677000116", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_class_empties_fn__677000116_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_class_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_class_empties_fn__677000119_A_class, Name: "arbace.cpp.abi$class_empties$fn__677000119", Modifiers: 25, Simple: "fn__677000119", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_class_empties_fn__677000119_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_class_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_class_empties_fn__677000124_A_class, Name: "arbace.cpp.abi$class_empties$fn__677000124", Modifiers: 25, Simple: "fn__677000124", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_class_empties_fn__677000124_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_class_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_classify_class_A_class, Name: "arbace.cpp.abi$classify_class", Modifiers: 25, Simple: "classify_class", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_classify_class_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_class, Name: "arbace.cpp.abi$classify_class$iter__677000413__677000417", Modifiers: 25, Simple: "iter__677000413__677000417", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_classify_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_class, Name: "arbace.cpp.abi$classify_class$iter__677000413__677000417$fn__677000418", Modifiers: 25, Simple: "fn__677000418", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_class, Name: "arbace.cpp.abi$classify_class$iter__677000413__677000417$fn__677000418$fn__677000419", Modifiers: 25, Simple: "fn__677000419", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_classify_into_BANG__A_class, Name: "arbace.cpp.abi$classify_into_BANG_", Modifiers: 25, Simple: "classify_into_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_classify_into_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_cls_A_class, Name: "arbace.cpp.abi$cls", Modifiers: 25, Simple: "cls", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_cls_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_cls_of_A_class, Name: "arbace.cpp.abi$cls_of", Modifiers: 25, Simple: "cls_of", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_cls_of_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_constq_A_class, Name: "arbace.cpp.abi$constq", Modifiers: 25, Simple: "constq", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_constq_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_cvq_A_class, Name: "arbace.cpp.abi$cvq", Modifiers: 25, Simple: "cvq", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_cvq_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_derived_from_QMARK__A_class, Name: "arbace.cpp.abi$derived_from_QMARK_", Modifiers: 25, Simple: "derived_from_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_derived_from_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dollar_name_BANG__A_class, Name: "arbace.cpp.abi$dollar_name_BANG_", Modifiers: 25, Simple: "dollar_name_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dollar_name_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_class, Name: "arbace.cpp.abi$dollar_name_BANG_$fn__677000231", Modifiers: 25, Simple: "fn__677000231", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_dollar_name_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dt_standin_QMARK__A_class, Name: "arbace.cpp.abi$dt_standin_QMARK_", Modifiers: 25, Simple: "dt_standin_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dt_standin_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dt_unresolved_A_class, Name: "arbace.cpp.abi$dt_unresolved", Modifiers: 25, Simple: "dt_unresolved", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dt_unresolved_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dynamic_QMARK__A_class, Name: "arbace.cpp.abi$dynamic_QMARK_", Modifiers: 25, Simple: "dynamic_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dynamic_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_class, Name: "arbace.cpp.abi$dynamic_QMARK_$fn__677000070", Modifiers: 25, Simple: "fn__677000070", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_dynamic_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_empty_class_QMARK__A_class, Name: "arbace.cpp.abi$empty_class_QMARK_", Modifiers: 25, Simple: "empty_class_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_empty_class_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_class, Name: "arbace.cpp.abi$empty_class_QMARK_$fn__677000091", Modifiers: 25, Simple: "fn__677000091", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_empty_class_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_empty_member_QMARK__A_class, Name: "arbace.cpp.abi$empty_member_QMARK_", Modifiers: 25, Simple: "empty_member_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_empty_member_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_encoding_STAR__A_class, Name: "arbace.cpp.abi$encoding_STAR_", Modifiers: 25, Simple: "encoding_STAR_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_encoding_STAR__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_class, Name: "arbace.cpp.abi$encoding_STAR_$uname__677000356", Modifiers: 25, Simple: "uname__677000356", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_encoding_STAR__uname__677000356_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_encoding_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_class, Name: "arbace.cpp.abi$encoding_STAR_$uname__677000356$fn__677000357", Modifiers: 25, Simple: "fn__677000357", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_class, Name: "arbace.cpp.abi$encoding_STAR_$uname__677000356$fn__677000359", Modifiers: 25, Simple: "fn__677000359", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_enm_A_class, Name: "arbace.cpp.abi$enm", Modifiers: 25, Simple: "enm", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_enm_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_enum_QMARK__A_class, Name: "arbace.cpp.abi$enum_QMARK_", Modifiers: 25, Simple: "enum_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_enum_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A_class, Name: "arbace.cpp.abi$eval677000004$loading__1927001464__auto____677000005", Modifiers: 25, Simple: "loading__1927001464__auto____677000005", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_eval677000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_eval677000008_fn__677000009_A_class, Name: "arbace.cpp.abi$eval677000008$fn__677000009", Modifiers: 25, Simple: "fn__677000009", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_eval677000008_fn__677000009_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_eval677000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_fail_A_class, Name: "arbace.cpp.abi$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_fail_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_field_empties_A_class, Name: "arbace.cpp.abi$field_empties", Modifiers: 25, Simple: "field_empties", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_field_empties_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_field_empties_fn__677000109_A_class, Name: "arbace.cpp.abi$field_empties$fn__677000109", Modifiers: 25, Simple: "fn__677000109", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_field_empties_fn__677000109_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_field_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_field_empties_fn__677000111_A_class, Name: "arbace.cpp.abi$field_empties$fn__677000111", Modifiers: 25, Simple: "fn__677000111", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_field_empties_fn__677000111_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_field_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_field_empties_fn__677000113_A_class, Name: "arbace.cpp.abi$field_empties$fn__677000113", Modifiers: 25, Simple: "fn__677000113", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_field_empties_fn__677000113_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_field_empties_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_field_offset_A_class, Name: "arbace.cpp.abi$field_offset", Modifiers: 25, Simple: "field_offset", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_field_offset_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_floating_QMARK__A_class, Name: "arbace.cpp.abi$floating_QMARK_", Modifiers: 25, Simple: "floating_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_floating_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_fn_QMARK__A_class, Name: "arbace.cpp.abi$fn_QMARK_", Modifiers: 25, Simple: "fn_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_fn_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_has_vbases_QMARK__A_class, Name: "arbace.cpp.abi$has_vbases_QMARK_", Modifiers: 25, Simple: "has_vbases_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_has_vbases_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_indirect_primaries_A_class, Name: "arbace.cpp.abi$indirect_primaries", Modifiers: 25, Simple: "indirect_primaries", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_indirect_primaries_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_class, Name: "arbace.cpp.abi$indirect_primaries$walk__677000074", Modifiers: 25, Simple: "walk__677000074", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_indirect_primaries_walk__677000074_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_indirect_primaries_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_integral_QMARK__A_class, Name: "arbace.cpp.abi$integral_QMARK_", Modifiers: 25, Simple: "integral_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_integral_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_kind_A_class, Name: "arbace.cpp.abi$kind", Modifiers: 25, Simple: "kind", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_kind_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_A_class, Name: "arbace.cpp.abi$layout", Modifiers: 25, Simple: "layout", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__A_class, Name: "arbace.cpp.abi$layout_STAR_", Modifiers: 25, Simple: "layout_STAR_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000157_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000157", Modifiers: 25, Simple: "fn__677000157", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000157_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000159_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000159", Modifiers: 25, Simple: "fn__677000159", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000159_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000162_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000162", Modifiers: 25, Simple: "fn__677000162", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000162_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000162$fn__677000166", Modifiers: 25, Simple: "fn__677000166", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__fn__677000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000169_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000169", Modifiers: 25, Simple: "fn__677000169", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000169_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000172_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000172", Modifiers: 25, Simple: "fn__677000172", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000172_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000172$fn__677000179", Modifiers: 25, Simple: "fn__677000179", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__fn__677000172_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000195_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000195", Modifiers: 25, Simple: "fn__677000195", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000195_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000195$fn__677000199", Modifiers: 25, Simple: "fn__677000199", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__fn__677000195_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000202_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000202", Modifiers: 25, Simple: "fn__677000202", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000202_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000204_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000204", Modifiers: 25, Simple: "fn__677000204", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000204_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_class, Name: "arbace.cpp.abi$layout_STAR_$fn__677000204$fn__677000205", Modifiers: 25, Simple: "fn__677000205", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__fn__677000204_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_class, Name: "arbace.cpp.abi$layout_STAR_$mark_BANG___677000182", Modifiers: 25, Simple: "mark_BANG___677000182", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_layout_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_llvm_type_A_class, Name: "arbace.cpp.abi$llvm_type", Modifiers: 25, Simple: "llvm_type", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_llvm_type_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_local_enc_A_class, Name: "arbace.cpp.abi$local_enc", Modifiers: 25, Simple: "local_enc", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_local_enc_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_local_encoding_A_class, Name: "arbace.cpp.abi$local_encoding", Modifiers: 25, Simple: "local_encoding", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_local_encoding_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_lref_A_class, Name: "arbace.cpp.abi$lref", Modifiers: 25, Simple: "lref", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_lref_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_A_class, Name: "arbace.cpp.abi$mangle_constraint", Modifiers: 25, Simple: "mangle_constraint", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_class, Name: "arbace.cpp.abi$mangle_constraint$arg__677000334", Modifiers: 25, Simple: "arg__677000334", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_arg__677000334_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class, Name: "arbace.cpp.abi$mangle_constraint$ex__677000339", Modifiers: 25, Simple: "ex__677000339", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ex__677000339_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_class, Name: "arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000341", Modifiers: 25, Simple: "fn__677000341", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_class, Name: "arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000343", Modifiers: 25, Simple: "fn__677000343", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_class, Name: "arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000346", Modifiers: 25, Simple: "fn__677000346", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_class, Name: "arbace.cpp.abi$mangle_constraint$ex__677000339$fn__677000348", Modifiers: 25, Simple: "fn__677000348", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_req__677000336_A_class, Name: "arbace.cpp.abi$mangle_constraint$req__677000336", Modifiers: 25, Simple: "req__677000336", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_req__677000336_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_class, Name: "arbace.cpp.abi$mangle_constraint$tt__677000332", Modifiers: 25, Simple: "tt__677000332", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_tt__677000332_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_class, Name: "arbace.cpp.abi$mangle_constraint$ty__677000330", Modifiers: 25, Simple: "ty__677000330", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_constraint_ty__677000330_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_constraint_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_ctor_vtable_name_A_class, Name: "arbace.cpp.abi$mangle_ctor_vtable_name", Modifiers: 25, Simple: "mangle_ctor_vtable_name", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_ctor_vtable_name_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_dt_expr_A_class, Name: "arbace.cpp.abi$mangle_dt_expr", Modifiers: 25, Simple: "mangle_dt_expr", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_dt_expr_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_expr_A_class, Name: "arbace.cpp.abi$mangle_expr", Modifiers: 25, Simple: "mangle_expr", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_expr_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_expr_fn__677000260_A_class, Name: "arbace.cpp.abi$mangle_expr$fn__677000260", Modifiers: 25, Simple: "fn__677000260", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_expr_fn__677000260_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_expr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_fn_A_class, Name: "arbace.cpp.abi$mangle_fn", Modifiers: 25, Simple: "mangle_fn", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_fn_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_local_static_A_class, Name: "arbace.cpp.abi$mangle_local_static", Modifiers: 25, Simple: "mangle_local_static", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_local_static_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_class, Name: "arbace.cpp.abi$mangle_local_static$fn__677000366", Modifiers: 25, Simple: "fn__677000366", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_local_static_fn__677000366_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_local_static_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_named_A_class, Name: "arbace.cpp.abi$mangle_named", Modifiers: 25, Simple: "mangle_named", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_named_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_params_A_class, Name: "arbace.cpp.abi$mangle_params", Modifiers: 25, Simple: "mangle_params", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_params_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_prefix_A_class, Name: "arbace.cpp.abi$mangle_prefix", Modifiers: 25, Simple: "mangle_prefix", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_prefix_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_class, Name: "arbace.cpp.abi$mangle_prefix$fn__677000246", Modifiers: 25, Simple: "fn__677000246", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_prefix_fn__677000246_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_class, Name: "arbace.cpp.abi$mangle_prefix$idx__677000244", Modifiers: 25, Simple: "idx__677000244", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_prefix_idx__677000244_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__A_class, Name: "arbace.cpp.abi$mangle_type_STAR_", Modifiers: 25, Simple: "mangle_type_STAR_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280", Modifiers: 25, Simple: "inner__677000280", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000282", Modifiers: 25, Simple: "fn__677000282", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000284", Modifiers: 25, Simple: "fn__677000284", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000286", Modifiers: 25, Simple: "fn__677000286", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000288", Modifiers: 25, Simple: "fn__677000288", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000290", Modifiers: 25, Simple: "fn__677000290", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000292", Modifiers: 25, Simple: "fn__677000292", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000294", Modifiers: 25, Simple: "fn__677000294", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000296", Modifiers: 25, Simple: "fn__677000296", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298", Modifiers: 25, Simple: "fn__677000298", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000299", Modifiers: 25, Simple: "fn__677000299", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000301", Modifiers: 25, Simple: "fn__677000301", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000303", Modifiers: 25, Simple: "fn__677000303", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000298$fn__677000305", Modifiers: 25, Simple: "fn__677000305", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000308", Modifiers: 25, Simple: "fn__677000308", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_class, Name: "arbace.cpp.abi$mangle_type_STAR_$inner__677000280$fn__677000310", Modifiers: 25, Simple: "fn__677000310", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_type_name_A_class, Name: "arbace.cpp.abi$mangle_type_name", Modifiers: 25, Simple: "mangle_type_name", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_type_name_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mangle_var_A_class, Name: "arbace.cpp.abi$mangle_var", Modifiers: 25, Simple: "mangle_var", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mangle_var_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mark_BANG__A_class, Name: "arbace.cpp.abi$mark_BANG_", Modifiers: 25, Simple: "mark_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mark_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mark_BANG__fn__677000374_A_class, Name: "arbace.cpp.abi$mark_BANG_$fn__677000374", Modifiers: 25, Simple: "fn__677000374", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mark_BANG__fn__677000374_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_mark_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_merge_class_A_class, Name: "arbace.cpp.abi$merge_class", Modifiers: 25, Simple: "merge_class", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_merge_class_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mfn_ptr_QMARK__A_class, Name: "arbace.cpp.abi$mfn_ptr_QMARK_", Modifiers: 25, Simple: "mfn_ptr_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mfn_ptr_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_mptr_QMARK__A_class, Name: "arbace.cpp.abi$mptr_QMARK_", Modifiers: 25, Simple: "mptr_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_mptr_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_nearly_empty_QMARK__A_class, Name: "arbace.cpp.abi$nearly_empty_QMARK_", Modifiers: 25, Simple: "nearly_empty_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_nearly_empty_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_non_ref_A_class, Name: "arbace.cpp.abi$non_ref", Modifiers: 25, Simple: "non_ref", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_non_ref_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_nonvirtual_subobjects_A_class, Name: "arbace.cpp.abi$nonvirtual_subobjects", Modifiers: 25, Simple: "nonvirtual_subobjects", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_nonvirtual_subobjects_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_class, Name: "arbace.cpp.abi$nonvirtual_subobjects$fn__677000103", Modifiers: 25, Simple: "fn__677000103", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_nonvirtual_subobjects_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_part_name_A_class, Name: "arbace.cpp.abi$part_name", Modifiers: 25, Simple: "part_name", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_part_name_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_part_targs_A_class, Name: "arbace.cpp.abi$part_targs", Modifiers: 25, Simple: "part_targs", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_part_targs_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_path_of_type_A_class, Name: "arbace.cpp.abi$path_of_type", Modifiers: 25, Simple: "path_of_type", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_path_of_type_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_place_BANG__A_class, Name: "arbace.cpp.abi$place_BANG_", Modifiers: 25, Simple: "place_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_place_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_pod_for_layout_QMARK__A_class, Name: "arbace.cpp.abi$pod_for_layout_QMARK_", Modifiers: 25, Simple: "pod_for_layout_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_pod_for_layout_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_class, Name: "arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000095", Modifiers: 25, Simple: "fn__677000095", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_pod_for_layout_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_class, Name: "arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000097", Modifiers: 25, Simple: "fn__677000097", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_pod_for_layout_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_class, Name: "arbace.cpp.abi$pod_for_layout_QMARK_$fn__677000097$fn__677000098", Modifiers: 25, Simple: "fn__677000098", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_primary_base_A_class, Name: "arbace.cpp.abi$primary_base", Modifiers: 25, Simple: "primary_base", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_primary_base_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_primary_base_fn__677000082_A_class, Name: "arbace.cpp.abi$primary_base$fn__677000082", Modifiers: 25, Simple: "fn__677000082", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_primary_base_fn__677000082_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_primary_base_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_primary_base_sel__677000084_A_class, Name: "arbace.cpp.abi$primary_base$sel__677000084", Modifiers: 25, Simple: "sel__677000084", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_primary_base_sel__677000084_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_primary_base_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_class, Name: "arbace.cpp.abi$primary_base$sel__677000084$fn__677000085", Modifiers: 25, Simple: "fn__677000085", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_primary_base_sel__677000084_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_ptr_A_class, Name: "arbace.cpp.abi$ptr", Modifiers: 25, Simple: "ptr", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_ptr_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_ptr_QMARK__A_class, Name: "arbace.cpp.abi$ptr_QMARK_", Modifiers: 25, Simple: "ptr_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_ptr_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_q_param_A_class, Name: "arbace.cpp.abi$q_param", Modifiers: 25, Simple: "q_param", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_q_param_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_q_param_fn__677000325_A_class, Name: "arbace.cpp.abi$q_param$fn__677000325", Modifiers: 25, Simple: "fn__677000325", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_q_param_fn__677000325_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_q_param_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_ref_QMARK__A_class, Name: "arbace.cpp.abi$ref_QMARK_", Modifiers: 25, Simple: "ref_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_ref_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_rref_A_class, Name: "arbace.cpp.abi$rref", Modifiers: 25, Simple: "rref", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_rref_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_same_type_QMARK__A_class, Name: "arbace.cpp.abi$same_type_QMARK_", Modifiers: 25, Simple: "same_type_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_same_type_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_scalar_QMARK__A_class, Name: "arbace.cpp.abi$scalar_QMARK_", Modifiers: 25, Simple: "scalar_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_scalar_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_scalar_class_A_class, Name: "arbace.cpp.abi$scalar_class", Modifiers: 25, Simple: "scalar_class", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_scalar_class_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_seq_id_A_class, Name: "arbace.cpp.abi$seq_id", Modifiers: 25, Simple: "seq_id", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_seq_id_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_signed_QMARK__A_class, Name: "arbace.cpp.abi$signed_QMARK_", Modifiers: 25, Simple: "signed_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_signed_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_size_align_A_class, Name: "arbace.cpp.abi$size_align", Modifiers: 25, Simple: "size_align", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_size_align_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_size_of_A_class, Name: "arbace.cpp.abi$size_of", Modifiers: 25, Simple: "size_of", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_size_of_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_skey_A_class, Name: "arbace.cpp.abi$skey", Modifiers: 25, Simple: "skey", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_skey_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_skey_fn__677000274_A_class, Name: "arbace.cpp.abi$skey$fn__677000274", Modifiers: 25, Simple: "fn__677000274", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_skey_fn__677000274_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_skey_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_source_name_A_class, Name: "arbace.cpp.abi$source_name", Modifiers: 25, Simple: "source_name", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_source_name_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_std_abbreviation_A_class, Name: "arbace.cpp.abi$std_abbreviation", Modifiers: 25, Simple: "std_abbreviation", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_std_abbreviation_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_class, Name: "arbace.cpp.abi$std_abbreviation$alloc_QMARK___677000240", Modifiers: 25, Simple: "alloc_QMARK___677000240", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_std_abbreviation_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_class, Name: "arbace.cpp.abi$std_abbreviation$traits_QMARK___677000238", Modifiers: 25, Simple: "traits_QMARK___677000238", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_std_abbreviation_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_sub_BANG__A_class, Name: "arbace.cpp.abi$sub_BANG_", Modifiers: 25, Simple: "sub_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_sub_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_sub_or_A_class, Name: "arbace.cpp.abi$sub_or", Modifiers: 25, Simple: "sub_or", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_sub_or_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_template_arg_A_class, Name: "arbace.cpp.abi$template_arg", Modifiers: 25, Simple: "template_arg", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_template_arg_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_template_arg_fn__677000267_A_class, Name: "arbace.cpp.abi$template_arg$fn__677000267", Modifiers: 25, Simple: "fn__677000267", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_template_arg_fn__677000267_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_template_arg_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_template_args_A_class, Name: "arbace.cpp.abi$template_args", Modifiers: 25, Simple: "template_args", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_template_args_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_template_param_A_class, Name: "arbace.cpp.abi$template_param", Modifiers: 25, Simple: "template_param", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_template_param_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_template_prefix_A_class, Name: "arbace.cpp.abi$template_prefix", Modifiers: 25, Simple: "template_prefix", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_template_prefix_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_tspec_unwrapped_A_class, Name: "arbace.cpp.abi$tspec_unwrapped", Modifiers: 25, Simple: "tspec_unwrapped", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_tspec_unwrapped_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_class, Name: "arbace.cpp.abi$tspec_unwrapped$fn__677000254", Modifiers: 25, Simple: "fn__677000254", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_tspec_unwrapped_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_underlying_A_class, Name: "arbace.cpp.abi$underlying", Modifiers: 25, Simple: "underlying", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_underlying_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_unq_A_class, Name: "arbace.cpp.abi$unq", Modifiers: 25, Simple: "unq", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_unq_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_unqualified_name_A_class, Name: "arbace.cpp.abi$unqualified_name", Modifiers: 25, Simple: "unqualified_name", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_unqualified_name_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_unqualified_name_fn__677000317_A_class, Name: "arbace.cpp.abi$unqualified_name$fn__677000317", Modifiers: 25, Simple: "fn__677000317", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_unqualified_name_fn__677000317_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_unqualified_name_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_unqualified_name_STAR__A_class, Name: "arbace.cpp.abi$unqualified_name_STAR_", Modifiers: 25, Simple: "unqualified_name_STAR_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_unqualified_name_STAR__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_update_cls_BANG__A_class, Name: "arbace.cpp.abi$update_cls_BANG_", Modifiers: 25, Simple: "update_cls_BANG_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_update_cls_BANG__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_vbases_A_class, Name: "arbace.cpp.abi$vbases", Modifiers: 25, Simple: "vbases", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_vbases_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_vbases_walk__677000055_A_class, Name: "arbace.cpp.abi$vbases$walk__677000055", Modifiers: 25, Simple: "walk__677000055", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_vbases_walk__677000055_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_vbases_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_vbases_init_A_class, Name: "arbace.cpp.abi$vbases_init", Modifiers: 25, Simple: "vbases_init", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_vbases_init_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_vbases_init_walk__677000062_A_class, Name: "arbace.cpp.abi$vbases_init$walk__677000062", Modifiers: 25, Simple: "walk__677000062", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_vbases_init_walk__677000062_A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_vbases_init_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_cpp_abi_void_QMARK__A_class, Name: "arbace.cpp.abi$void_QMARK_", Modifiers: 25, Simple: "void_QMARK_", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_void_QMARK__A", Source: "abi.ae", Declaring: &A_arbace_cpp_abi_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_cpp_abi_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_cpp_abi_A_New()}; return nil }

var A_arbace_cpp_abi_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_cpp_abi_A_new}

var A_arbace_cpp_abi_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_A"})

func init() { i := A_arbace_cpp_abi_A_class.Info(); i.IsInstance = A_arbace_cpp_abi_A_InstanceOf; i.Init = A_arbace_cpp_abi_A_Init; i.Table = A_arbace_cpp_abi_A_members }

var A_arbace_cpp_abi_align_of_A_class *jrt.Class

var A_arbace_cpp_abi_align_up_A_class *jrt.Class

var A_arbace_cpp_abi_arith_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_arr_A_class *jrt.Class

var A_arbace_cpp_abi_arr_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_b_A_class *jrt.Class

var A_arbace_cpp_abi_bare_params_A_class *jrt.Class

var A_arbace_cpp_abi_base_path_A_class *jrt.Class

var A_arbace_cpp_abi_base_path_fn__677000211_A_class *jrt.Class

var A_arbace_cpp_abi_bn_A_class *jrt.Class

var A_arbace_cpp_abi_can_place_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_can_place_QMARK__fn__677000128_A_class *jrt.Class

var A_arbace_cpp_abi_class_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_class_empties_A_class *jrt.Class

var A_arbace_cpp_abi_class_empties_fn__677000116_A_class *jrt.Class

var A_arbace_cpp_abi_class_empties_fn__677000119_A_class *jrt.Class

var A_arbace_cpp_abi_class_empties_fn__677000124_A_class *jrt.Class

var A_arbace_cpp_abi_classify_class_A_class *jrt.Class

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_A_class *jrt.Class

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_A_class *jrt.Class

var A_arbace_cpp_abi_classify_class_iter__677000413__677000417_fn__677000418_fn__677000419_A_class *jrt.Class

var A_arbace_cpp_abi_classify_into_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_cls_A_class *jrt.Class

var A_arbace_cpp_abi_cls_of_A_class *jrt.Class

var A_arbace_cpp_abi_constq_A_class *jrt.Class

var A_arbace_cpp_abi_cvq_A_class *jrt.Class

var A_arbace_cpp_abi_derived_from_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_dollar_name_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_dollar_name_BANG__fn__677000231_A_class *jrt.Class

var A_arbace_cpp_abi_dt_standin_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_dt_unresolved_A_class *jrt.Class

var A_arbace_cpp_abi_dynamic_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_dynamic_QMARK__fn__677000070_A_class *jrt.Class

var A_arbace_cpp_abi_empty_class_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_empty_class_QMARK__fn__677000091_A_class *jrt.Class

var A_arbace_cpp_abi_empty_member_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_encoding_STAR__A_class *jrt.Class

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_A_class *jrt.Class

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000357_A_class *jrt.Class

var A_arbace_cpp_abi_encoding_STAR__uname__677000356_fn__677000359_A_class *jrt.Class

var A_arbace_cpp_abi_enm_A_class *jrt.Class

var A_arbace_cpp_abi_enum_QMARK__A_class *jrt.Class

func A_arbace_cpp_abi_eval677000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_cpp_abi_eval677000004_A_New()}; return nil }

var A_arbace_cpp_abi_eval677000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_cpp_abi_eval677000004_A_new}

var A_arbace_cpp_abi_eval677000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi$eval677000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_cpp_abi_A_class, Simple: "eval677000004", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_eval677000004_A"})

func init() { i := A_arbace_cpp_abi_eval677000004_A_class.Info(); i.IsInstance = A_arbace_cpp_abi_eval677000004_A_InstanceOf; i.Table = A_arbace_cpp_abi_eval677000004_A_members }

var A_arbace_cpp_abi_eval677000004_loading__1927001464__auto____677000005_A_class *jrt.Class

func A_arbace_cpp_abi_eval677000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_cpp_abi_eval677000008_A_New()}; return nil }

var A_arbace_cpp_abi_eval677000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_cpp_abi_eval677000008_A_new}

var A_arbace_cpp_abi_eval677000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi$eval677000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_cpp_abi_A_class, Simple: "eval677000008", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi_eval677000008_A"})

func init() { i := A_arbace_cpp_abi_eval677000008_A_class.Info(); i.IsInstance = A_arbace_cpp_abi_eval677000008_A_InstanceOf; i.Table = A_arbace_cpp_abi_eval677000008_A_members }

var A_arbace_cpp_abi_eval677000008_fn__677000009_A_class *jrt.Class

var A_arbace_cpp_abi_fail_A_class *jrt.Class

var A_arbace_cpp_abi_field_empties_A_class *jrt.Class

var A_arbace_cpp_abi_field_empties_fn__677000109_A_class *jrt.Class

var A_arbace_cpp_abi_field_empties_fn__677000111_A_class *jrt.Class

var A_arbace_cpp_abi_field_empties_fn__677000113_A_class *jrt.Class

var A_arbace_cpp_abi_field_offset_A_class *jrt.Class

var A_arbace_cpp_abi_floating_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_fn_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_has_vbases_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_indirect_primaries_A_class *jrt.Class

var A_arbace_cpp_abi_indirect_primaries_walk__677000074_A_class *jrt.Class

var A_arbace_cpp_abi_integral_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_kind_A_class *jrt.Class

var A_arbace_cpp_abi_layout_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000157_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000159_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000162_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000162_fn__677000166_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000169_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000172_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000172_fn__677000179_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000195_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000195_fn__677000199_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000202_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000204_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__fn__677000204_fn__677000205_A_class *jrt.Class

var A_arbace_cpp_abi_layout_STAR__mark_BANG___677000182_A_class *jrt.Class

var A_arbace_cpp_abi_llvm_type_A_class *jrt.Class

var A_arbace_cpp_abi_local_enc_A_class *jrt.Class

var A_arbace_cpp_abi_local_encoding_A_class *jrt.Class

var A_arbace_cpp_abi_lref_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_arg__677000334_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000341_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000343_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000346_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ex__677000339_fn__677000348_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_req__677000336_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_tt__677000332_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_constraint_ty__677000330_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_ctor_vtable_name_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_dt_expr_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_expr_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_expr_fn__677000260_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_fn_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_local_static_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_local_static_fn__677000366_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_named_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_params_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_prefix_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_prefix_fn__677000246_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_prefix_idx__677000244_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000282_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000284_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000286_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000288_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000290_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000292_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000294_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000296_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000299_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000301_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000303_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000298_fn__677000305_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000308_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_STAR__inner__677000280_fn__677000310_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_type_name_A_class *jrt.Class

var A_arbace_cpp_abi_mangle_var_A_class *jrt.Class

var A_arbace_cpp_abi_mark_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_mark_BANG__fn__677000374_A_class *jrt.Class

var A_arbace_cpp_abi_merge_class_A_class *jrt.Class

var A_arbace_cpp_abi_mfn_ptr_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_mptr_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_nearly_empty_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_non_ref_A_class *jrt.Class

var A_arbace_cpp_abi_nonvirtual_subobjects_A_class *jrt.Class

var A_arbace_cpp_abi_nonvirtual_subobjects_fn__677000103_A_class *jrt.Class

var A_arbace_cpp_abi_part_name_A_class *jrt.Class

var A_arbace_cpp_abi_part_targs_A_class *jrt.Class

var A_arbace_cpp_abi_path_of_type_A_class *jrt.Class

var A_arbace_cpp_abi_place_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_pod_for_layout_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000095_A_class *jrt.Class

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_A_class *jrt.Class

var A_arbace_cpp_abi_pod_for_layout_QMARK__fn__677000097_fn__677000098_A_class *jrt.Class

var A_arbace_cpp_abi_primary_base_A_class *jrt.Class

var A_arbace_cpp_abi_primary_base_fn__677000082_A_class *jrt.Class

var A_arbace_cpp_abi_primary_base_sel__677000084_A_class *jrt.Class

var A_arbace_cpp_abi_primary_base_sel__677000084_fn__677000085_A_class *jrt.Class

var A_arbace_cpp_abi_ptr_A_class *jrt.Class

var A_arbace_cpp_abi_ptr_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_q_param_A_class *jrt.Class

var A_arbace_cpp_abi_q_param_fn__677000325_A_class *jrt.Class

var A_arbace_cpp_abi_ref_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_rref_A_class *jrt.Class

var A_arbace_cpp_abi_same_type_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_scalar_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_scalar_class_A_class *jrt.Class

var A_arbace_cpp_abi_seq_id_A_class *jrt.Class

var A_arbace_cpp_abi_signed_QMARK__A_class *jrt.Class

var A_arbace_cpp_abi_size_align_A_class *jrt.Class

var A_arbace_cpp_abi_size_of_A_class *jrt.Class

var A_arbace_cpp_abi_skey_A_class *jrt.Class

var A_arbace_cpp_abi_skey_fn__677000274_A_class *jrt.Class

var A_arbace_cpp_abi_source_name_A_class *jrt.Class

var A_arbace_cpp_abi_std_abbreviation_A_class *jrt.Class

var A_arbace_cpp_abi_std_abbreviation_alloc_QMARK___677000240_A_class *jrt.Class

var A_arbace_cpp_abi_std_abbreviation_traits_QMARK___677000238_A_class *jrt.Class

var A_arbace_cpp_abi_sub_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_sub_or_A_class *jrt.Class

var A_arbace_cpp_abi_template_arg_A_class *jrt.Class

var A_arbace_cpp_abi_template_arg_fn__677000267_A_class *jrt.Class

var A_arbace_cpp_abi_template_args_A_class *jrt.Class

var A_arbace_cpp_abi_template_param_A_class *jrt.Class

var A_arbace_cpp_abi_template_prefix_A_class *jrt.Class

var A_arbace_cpp_abi_tspec_unwrapped_A_class *jrt.Class

var A_arbace_cpp_abi_tspec_unwrapped_fn__677000254_A_class *jrt.Class

var A_arbace_cpp_abi_underlying_A_class *jrt.Class

var A_arbace_cpp_abi_unq_A_class *jrt.Class

var A_arbace_cpp_abi_unqualified_name_A_class *jrt.Class

var A_arbace_cpp_abi_unqualified_name_fn__677000317_A_class *jrt.Class

var A_arbace_cpp_abi_unqualified_name_STAR__A_class *jrt.Class

var A_arbace_cpp_abi_update_cls_BANG__A_class *jrt.Class

var A_arbace_cpp_abi_vbases_A_class *jrt.Class

var A_arbace_cpp_abi_vbases_walk__677000055_A_class *jrt.Class

var A_arbace_cpp_abi_vbases_init_A_class *jrt.Class

var A_arbace_cpp_abi_vbases_init_walk__677000062_A_class *jrt.Class

var A_arbace_cpp_abi_void_QMARK__A_class *jrt.Class

func A_arbace_cpp_abi__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_cpp_abi__init_A_Load__O()}; return nil }

func A_arbace_cpp_abi__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_cpp_abi__init_A_New()}; return nil }

var A_arbace_cpp_abi__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_cpp_abi__init_A_invoke, New: A_arbace_cpp_abi__init_A_new}

var A_arbace_cpp_abi__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi__init_A", Source: "abi.ae"})

func init() { i := A_arbace_cpp_abi__init_A_class.Info(); i.IsInstance = A_arbace_cpp_abi__init_A_InstanceOf; i.Table = A_arbace_cpp_abi__init_A_members }

var A_arbace_cpp_abi__init_part0_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi__init$part0", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_cpp_abi__init_A_class, Simple: "part0", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi__init_part0_A", Source: "abi.ae"})

func init() { i := A_arbace_cpp_abi__init_part0_A_class.Info(); i.IsInstance = A_arbace_cpp_abi__init_part0_A_InstanceOf; i.Init = A_arbace_cpp_abi__init_part0_A_Init }

var A_arbace_cpp_abi__init_part1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.cpp.abi__init$part1", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_cpp_abi__init_A_class, Simple: "part1", Go: "arbace/aot_arbace_cpp_abi.A_arbace_cpp_abi__init_part1_A", Source: "abi.ae"})

func init() { i := A_arbace_cpp_abi__init_part1_A_class.Info(); i.IsInstance = A_arbace_cpp_abi__init_part1_A_InstanceOf; i.Init = A_arbace_cpp_abi__init_part1_A_Init }
