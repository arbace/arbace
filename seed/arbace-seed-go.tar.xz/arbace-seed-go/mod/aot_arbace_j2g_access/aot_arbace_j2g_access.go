//line aot_arbace_j2g_access.ae:1
package aot_arbace_j2g_access

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_New() *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_access_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_access_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_access_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_access_A_const_1, A_arbace_j2g_access_A_const_2, A_arbace_j2g_access_A_const_3, A_arbace_j2g_access_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_access_eval978000008_fn__978000009_A_New() *A_arbace_j2g_access_eval978000008_fn__978000009_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000008_fn__978000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_access_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_j2g_access_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_access_A_const_10.GetRawRoot__O(), A_arbace_j2g_access_A_const_11) }











func A_arbace_j2g_access_accessor_A_New() *A_arbace_j2g_access_accessor_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_accessor_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Invoke_O_O_O__O(self, o__0, mname__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any; var root_22 any = A_arbace_j2g_access_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = mname__1; if linked_23 == nil { and__1927000168__auto____3 = ifn_24.Invoke_O__O(arg_25) } else { and__1927000168__auto____3 = linked_23.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_26 any = A_arbace_j2g_access_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = mname__1; var arg_30 any = Lit_1; if linked_27 == nil { and__1927000168__auto____4 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { and__1927000168__auto____4 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_31 any = A_arbace_j2g_access_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = o__0; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_31, arg_34) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_15; var tmp3 any; var root_39 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_35 any = A_arbace_j2g_access_A_const_16.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = o__0; if linked_36 == nil { arg_42 = ifn_37.Invoke_O__O(arg_38) } else { arg_42 = linked_36.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A).Invoke_O_O__O(root_35, arg_38) }; if linked_40 == nil { tmp3 = ifn_41.Invoke_O__O(arg_42) } else { tmp3 = linked_40.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_39, arg_42) }; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(tmp3), mname__1) } else {
//line :17:1
			return nil
		}
}
func A_arbace_j2g_access_find_field_A_New() *A_arbace_j2g_access_find_field_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_find_field_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Ctor() {}
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Invoke_O_O_O__O(self, owner__0, fname__1 any) any { var or__1927000174__auto____3 any; var root_43 any = A_arbace_j2g_access_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_classes_env.A_arbace_classes_env_find_field_A_fn_class); var ifn_45 lang.IFn; if
												linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = owner__0; var arg_47 any = fname__1; if linked_44 == nil { or__1927000174__auto____3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { or__1927000174__auto____3 = linked_44.(*aot_arbace_classes_env.A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_48 any = A_arbace_j2g_access_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_50 lang.IFn
													if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, owner__0, nil, fname__1)).Ref(); var arg_52 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_49 == nil { tmp1 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp1 = linked_49.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :21:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }


func A_arbace_j2g_access_unaccess_A_New() *A_arbace_j2g_access_unaccess_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Ctor() {}
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Invoke_O_O__O(self, node__0 any) any { var temp__1927000408__auto____2 any; var tmp1 any = A_arbace_j2g_access_A_const_19; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_access_A_const_20.Invoke_O__O(node__0)); if and__1927000168__auto____2 {


	var tmp2 any = A_arbace_j2g_access_A_const_21; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_access_A_const_22.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var root_53 any = A_arbace_j2g_access_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_j2g_access_accessor_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(node__0); var arg_57 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(node__0); if linked_54 == nil { temp__1927000408__auto____2 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { temp__1927000408__auto____2 = linked_54.(*A_arbace_j2g_access_accessor_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var acc__3 any = temp__1927000408__auto____2; var args__4 any = A_arbace_j2g_access_A_const_26.Invoke_O__O(node__0); var G__978000015__5_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)

		switch lang.Util_Hash_O__I_NoInit(G__978000015__5_) >> 4 & 15 { case 0: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_28) { var f__6 any; var root_59 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, A_arbace_j2g_access_find_field_A_fn_class); var ifn_61 lang.IFn





			if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_63 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_60 == nil { f__6 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { f__6 = linked_60.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }
//line :29:1
			var tmp3 any = A_arbace_j2g_access_A_const_20; var tmp4 any = A_arbace_j2g_access_A_const_30; var tmp5 any = A_arbace_j2g_access_A_const_31; var tmp6 any = A_arbace_j2g_access_A_const_24; var tmp7 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6); var tmp8 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, f__6, tmp6, tmp7, tmp8, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6))) }; case 4: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_34) { var tmp9 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7 any; var root_69 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_71 lang.IFn











				if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var tmp10 any = A_arbace_j2g_access_unaccess_fn__978000019_A_New_O(acc__3); var tmp11 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class = fncls__64d; tmp11 = fncls__64d } else { tmp11 = fncls__64 }; arg_72 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_73 any; var tmp12 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp13 any; var root_65 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_67 lang.IFn
				if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_66 == nil { tmp13 = ifn_67.Invoke_O__O(arg_68) } else { tmp13 = linked_66.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_65, arg_68) }; arg_73 = tmp12.Invoke_O__O(tmp13)
//line :41:1
				if linked_70 == nil { m__7 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { m__7 = linked_70.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }
//line :29:1
				var m__8 any; var root_74 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_76 lang.IFn













				if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var or__1927000174__auto____8 any = m__7; if jrt.J2g_Truth(or__1927000174__auto____8) { arg_77 = or__1927000174__auto____8 } else { var tmp14 any = A_arbace_j2g_access_A_const_25; var tmp15 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp16 any = A_arbace_j2g_access_A_const_33; arg_77 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_78 any = A_arbace_j2g_access_A_const_24; var arg_79 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_75 == nil { m__8 = ifn_76.Invoke_O_O_O__O(arg_77, arg_78, arg_79) } else { m__8 = linked_75.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_74, arg_77, arg_78, arg_79) }
//line :29:1
				var vec__978000016__9 any; var root_80 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_82 lang.IFn














				if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_81 == nil { vec__978000016__9 = ifn_82.Invoke_O__O(arg_83) } else { vec__978000016__9 = linked_81.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_80, arg_83) }
//line :29:1
				var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000016__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000016__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp17 any = A_arbace_j2g_access_A_const_20; var tmp18 any = A_arbace_j2g_access_A_const_19; var tmp19 any = A_arbace_j2g_access_A_const_22; var tmp20 *lang.Keyword; var G__978000021__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10
















			L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000021__12_) >> 10 & 3 { case 0: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_42) { tmp20 = A_arbace_j2g_access_A_const_43; break L2 }; case 1: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_44) { tmp20 = A_arbace_j2g_access_A_const_45; break L2 }; case 2: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_34) { tmp20 = A_arbace_j2g_access_A_const_21; break L2 }; default:}; tmp20 = A_arbace_j2g_access_A_const_46}
//line :29:1
				var tmp21 any = tmp20.Ref(); var tmp22 any = A_arbace_j2g_access_A_const_24; var tmp23 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp24 any = A_arbace_j2g_access_A_const_47; var tmp25 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp26 any = A_arbace_j2g_access_A_const_25; var tmp27 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp28 any = A_arbace_j2g_access_A_const_33; var tmp29 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp30 any = A_arbace_j2g_access_A_const_48; var tmp31 any



















				if static_QMARK___6 { tmp31 = nil } else { var root_85 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = args__4; if linked_86 == nil { tmp31 = ifn_87.Invoke_O__O(arg_88) } else { tmp31 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) } }
//line :29:1
				var tmp32 any = tmp31; var tmp33 any = A_arbace_j2g_access_A_const_26; var tmp34 any; var root_93 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_95 lang.IFn



















				if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; if static_QMARK___6 { arg_96 = args__4 } else { var root_89 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = args__4; if linked_90 == nil { arg_96 = ifn_91.Invoke_O__O(arg_92) } else { arg_96 = linked_90.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_89, arg_92) } }; if linked_94 == nil { tmp34 = ifn_95.Invoke_O__O(arg_96) } else { tmp34 = linked_94.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_93, arg_96) }
//line :29:1
				var tmp35 any = tmp34; var tmp36 any = A_arbace_j2g_access_A_const_32; var tmp37 any = A_arbace_j2g_access_A_const_52; var tmp38 any = A_arbace_j2g_access_A_const_53; var tmp39 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp32, tmp33, tmp35, tmp36, r__11, tmp37, m__8, tmp38, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp39, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 6: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_54) { var f__6_2 any; var root_97 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_j2g_access_find_field_A_fn_class); var ifn_99 lang.IFn







					if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_101 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_98 == nil { f__6_2 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { f__6_2 = linked_98.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }
//line :29:1
					var tmp40 any = A_arbace_j2g_access_A_const_20; var tmp41 any = A_arbace_j2g_access_A_const_55; var tmp42 any = A_arbace_j2g_access_A_const_31; var tmp43 any = A_arbace_j2g_access_A_const_24; var tmp44 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_2); var tmp45 any = A_arbace_j2g_access_A_const_56; var tmp46 any; var root_102 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn








					if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = args__4; if linked_103 == nil { tmp46 = ifn_104.Invoke_O__O(arg_105) } else { tmp46 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }
//line :29:1
					var tmp47 any = tmp46; var tmp48 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41, tmp42, f__6_2, tmp43, tmp44, tmp45, tmp47, tmp48, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_2))) }; case 8: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_57) { var tmp49 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp49, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_2 any; var root_111 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_113 lang.IFn











						if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var tmp50 any = A_arbace_j2g_access_unaccess_fn__978000025_A_New_O(acc__3); var tmp51 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class = fncls__106d; tmp51 = fncls__106d } else { tmp51 = fncls__106 }; arg_114 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil); var arg_115 any; var tmp52 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp53 any; var root_107 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_109 lang.IFn
						if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_108 == nil { tmp53 = ifn_109.Invoke_O__O(arg_110) } else { tmp53 = linked_108.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_107, arg_110) }; arg_115 = tmp52.Invoke_O__O(tmp53)
//line :41:1
						if linked_112 == nil { m__7_2 = ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { m__7_2 = linked_112.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) }
//line :29:1
						var m__8_2 any; var root_116 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_118 lang.IFn













						if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var or__1927000174__auto____8_2 any = m__7_2; if jrt.J2g_Truth(or__1927000174__auto____8_2) { arg_119 = or__1927000174__auto____8_2 } else { var tmp54 any = A_arbace_j2g_access_A_const_25; var tmp55 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp56 any = A_arbace_j2g_access_A_const_33; arg_119 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp55, tmp56, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_120 any = A_arbace_j2g_access_A_const_24; var arg_121 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_117 == nil { m__8_2 = ifn_118.Invoke_O_O_O__O(arg_119, arg_120, arg_121) } else { m__8_2 = linked_117.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_116, arg_119, arg_120, arg_121) }
//line :29:1
						var vec__978000022__9 any; var root_122 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_124 lang.IFn














						if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_123 == nil { vec__978000022__9 = ifn_124.Invoke_O__O(arg_125) } else { vec__978000022__9 = linked_123.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_122, arg_125) }
//line :29:1
						var ___10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000022__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000022__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp57 any = A_arbace_j2g_access_A_const_20; var tmp58 any = A_arbace_j2g_access_A_const_19; var tmp59 any = A_arbace_j2g_access_A_const_22; var tmp60 *lang.Keyword; var G__978000027__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_2
















					L3: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000027__12_) >> 10 & 3 { case 0: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_42) { tmp60 = A_arbace_j2g_access_A_const_43; break L3 }; case 1: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_44) { tmp60 = A_arbace_j2g_access_A_const_45; break L3 }; case 2: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_34) { tmp60 = A_arbace_j2g_access_A_const_21; break L3 }; default:}; tmp60 = A_arbace_j2g_access_A_const_46}
//line :29:1
						var tmp61 any = tmp60.Ref(); var tmp62 any = A_arbace_j2g_access_A_const_24; var tmp63 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp64 any = A_arbace_j2g_access_A_const_47; var tmp65 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp66 any = A_arbace_j2g_access_A_const_25; var tmp67 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp68 any = A_arbace_j2g_access_A_const_33; var tmp69 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp70 any = A_arbace_j2g_access_A_const_48; var tmp71 any



















						if static_QMARK___6_2 { tmp71 = nil } else { var root_127 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = args__4; if linked_128 == nil { tmp71 = ifn_129.Invoke_O__O(arg_130) } else { tmp71 = linked_128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_127, arg_130) } }
//line :29:1
						var tmp72 any = tmp71; var tmp73 any = A_arbace_j2g_access_A_const_26; var tmp74 any; var root_135 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_137 lang.IFn



















						if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; if static_QMARK___6_2 { arg_138 = args__4 } else { var root_131 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = args__4; if linked_132 == nil { arg_138 = ifn_133.Invoke_O__O(arg_134) } else { arg_138 = linked_132.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_131, arg_134) } }; if linked_136 == nil { tmp74 = ifn_137.Invoke_O__O(arg_138) } else { tmp74 = linked_136.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_135, arg_138) }
//line :29:1
						var tmp75 any = tmp74; var tmp76 any = A_arbace_j2g_access_A_const_32; var tmp77 any = A_arbace_j2g_access_A_const_52; var tmp78 any = A_arbace_j2g_access_A_const_53; var tmp79 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp57, tmp58, tmp59, tmp61, tmp62, tmp63, tmp64, tmp65, tmp66, tmp67, tmp68, tmp69, tmp70, tmp72, tmp73, tmp75, tmp76, r__11_2, tmp77, m__8_2, tmp78, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp79, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 10: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_58) { var f__6_3 any; var root_139 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_j2g_access_find_field_A_fn_class); var ifn_141 lang.IFn
							if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_143 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_140 == nil { f__6_3 = ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { f__6_3 = linked_140.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_139, arg_142, arg_143) }
//line :29:1
							var tmp80 any = A_arbace_j2g_access_A_const_20; var tmp81 any = A_arbace_j2g_access_A_const_59; var tmp82 any = A_arbace_j2g_access_A_const_31; var tmp83 any = A_arbace_j2g_access_A_const_24; var tmp84 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_3); var tmp85 any = A_arbace_j2g_access_A_const_48; var tmp86 any; var root_144 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_146 lang.IFn

							if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = args__4; if linked_145 == nil { tmp86 = ifn_146.Invoke_O__O(arg_147) } else { tmp86 = linked_145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_144, arg_147) }
//line :29:1
							var tmp87 any = tmp86; var tmp88 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp80, tmp81, tmp82, f__6_3, tmp83, tmp84, tmp85, tmp87, tmp88, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_3))) }; case 11: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_60) { var f__6_4 any; var root_148 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, A_arbace_j2g_access_find_field_A_fn_class); var ifn_150 lang.IFn


								if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_152 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_149 == nil { f__6_4 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { f__6_4 = linked_149.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }
//line :29:1
								var tmp89 any = A_arbace_j2g_access_A_const_20; var tmp90 any = A_arbace_j2g_access_A_const_61; var tmp91 any = A_arbace_j2g_access_A_const_31; var tmp92 any = A_arbace_j2g_access_A_const_24; var tmp93 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_4); var tmp94 any = A_arbace_j2g_access_A_const_48; var tmp95 any; var root_153 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_155 lang.IFn



								if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = args__4; if linked_154 == nil { tmp95 = ifn_155.Invoke_O__O(arg_156) } else { tmp95 = linked_154.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_153, arg_156) }
//line :29:1
								var tmp96 any = tmp95; var tmp97 any = A_arbace_j2g_access_A_const_56; var tmp98 any; var root_157 any = A_arbace_j2g_access_A_const_62.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_159 lang.IFn



								if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = args__4; if linked_158 == nil { tmp98 = ifn_159.Invoke_O__O(arg_160) } else { tmp98 = linked_158.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_157, arg_160) }
//line :29:1
								var tmp99 any = tmp98; var tmp100 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp89, tmp90, tmp91, f__6_4, tmp92, tmp93, tmp94, tmp96, tmp97, tmp99, tmp100, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_4))) }; case 12: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_44) { var tmp101 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp101, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_3 any; var root_166 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_168 lang.IFn











									if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any; var tmp102 any = A_arbace_j2g_access_unaccess_fn__978000031_A_New_O(acc__3); var tmp103 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class = fncls__161d; tmp103 = fncls__161d } else { tmp103 = fncls__161 }; arg_169 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp102, tmp103, nil); var arg_170 any; var tmp104 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp105 any; var root_162 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_164 lang.IFn
									if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_163 == nil { tmp105 = ifn_164.Invoke_O__O(arg_165) } else { tmp105 = linked_163.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_162, arg_165) }; arg_170 = tmp104.Invoke_O__O(tmp105)
//line :41:1
									if linked_167 == nil { m__7_3 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { m__7_3 = linked_167.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) }
//line :29:1
									var m__8_3 any; var root_171 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_173 lang.IFn













									if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var or__1927000174__auto____8_3 any = m__7_3; if jrt.J2g_Truth(or__1927000174__auto____8_3) { arg_174 = or__1927000174__auto____8_3 } else { var tmp106 any = A_arbace_j2g_access_A_const_25; var tmp107 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp108 any = A_arbace_j2g_access_A_const_33; arg_174 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp107, tmp108, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_175 any = A_arbace_j2g_access_A_const_24; var arg_176 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_172 == nil { m__8_3 = ifn_173.Invoke_O_O_O__O(arg_174, arg_175, arg_176) } else { m__8_3 = linked_172.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_171, arg_174, arg_175, arg_176) }
//line :29:1
									var vec__978000028__9 any; var root_177 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_179 lang.IFn














									if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_178 == nil { vec__978000028__9 = ifn_179.Invoke_O__O(arg_180) } else { vec__978000028__9 = linked_178.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_177, arg_180) }
//line :29:1
									var ___10_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000028__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000028__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp109 any = A_arbace_j2g_access_A_const_20; var tmp110 any = A_arbace_j2g_access_A_const_19; var tmp111 any = A_arbace_j2g_access_A_const_22; var tmp112 *lang.Keyword; var G__978000033__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_3
















								L4: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000033__12_) >> 10 & 3 { case 0: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_42) { tmp112 = A_arbace_j2g_access_A_const_43; break L4 }; case 1: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_44) { tmp112 = A_arbace_j2g_access_A_const_45; break L4 }; case 2: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_34) { tmp112 = A_arbace_j2g_access_A_const_21; break L4 }; default:}; tmp112 = A_arbace_j2g_access_A_const_46}
//line :29:1
									var tmp113 any = tmp112.Ref(); var tmp114 any = A_arbace_j2g_access_A_const_24; var tmp115 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp116 any = A_arbace_j2g_access_A_const_47; var tmp117 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp118 any = A_arbace_j2g_access_A_const_25; var tmp119 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp120 any = A_arbace_j2g_access_A_const_33; var tmp121 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp122 any = A_arbace_j2g_access_A_const_48; var tmp123 any



















									if static_QMARK___6_3 { tmp123 = nil } else { var root_182 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = args__4; if linked_183 == nil { tmp123 = ifn_184.Invoke_O__O(arg_185) } else { tmp123 = linked_183.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_182, arg_185) } }
//line :29:1
									var tmp124 any = tmp123; var tmp125 any = A_arbace_j2g_access_A_const_26; var tmp126 any; var root_190 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_192 lang.IFn



















									if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; if static_QMARK___6_3 { arg_193 = args__4 } else { var root_186 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = args__4; if linked_187 == nil { arg_193 = ifn_188.Invoke_O__O(arg_189) } else { arg_193 = linked_187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_186, arg_189) } }; if linked_191 == nil { tmp126 = ifn_192.Invoke_O__O(arg_193) } else { tmp126 = linked_191.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_190, arg_193) }
//line :29:1
									var tmp127 any = tmp126; var tmp128 any = A_arbace_j2g_access_A_const_32; var tmp129 any = A_arbace_j2g_access_A_const_52; var tmp130 any = A_arbace_j2g_access_A_const_53; var tmp131 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp110, tmp111, tmp113, tmp114, tmp115, tmp116, tmp117, tmp118, tmp119, tmp120, tmp121, tmp122, tmp124, tmp125, tmp127, tmp128, r__11_3, tmp129, m__8_3, tmp130, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp131, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 14: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_42) { var tmp132 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp132, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_4 any; var root_199 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_201 lang.IFn











										if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var tmp133 any = A_arbace_j2g_access_unaccess_fn__978000037_A_New_O(acc__3); var tmp134 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class = fncls__194d; tmp134 = fncls__194d } else { tmp134 = fncls__194 }; arg_202 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp133, tmp134, nil); var arg_203 any; var tmp135 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp136 any; var root_195 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_197 lang.IFn
										if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_196 == nil { tmp136 = ifn_197.Invoke_O__O(arg_198) } else { tmp136 = linked_196.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_195, arg_198) }; arg_203 = tmp135.Invoke_O__O(tmp136)
//line :41:1
										if linked_200 == nil { m__7_4 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { m__7_4 = linked_200.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }
//line :29:1
										var m__8_4 any; var root_204 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_206 lang.IFn













										if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var or__1927000174__auto____8_4 any = m__7_4; if jrt.J2g_Truth(or__1927000174__auto____8_4) { arg_207 = or__1927000174__auto____8_4 } else { var tmp137 any = A_arbace_j2g_access_A_const_25; var tmp138 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp139 any = A_arbace_j2g_access_A_const_33; arg_207 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp137, tmp138, tmp139, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_208 any = A_arbace_j2g_access_A_const_24; var arg_209 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_205 == nil { m__8_4 = ifn_206.Invoke_O_O_O__O(arg_207, arg_208, arg_209) } else { m__8_4 = linked_205.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_204, arg_207, arg_208, arg_209) }
//line :29:1
										var vec__978000034__9 any; var root_210 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_212 lang.IFn














										if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_211 == nil { vec__978000034__9 = ifn_212.Invoke_O__O(arg_213) } else { vec__978000034__9 = linked_211.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_210, arg_213) }
//line :29:1
										var ___10_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000034__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000034__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp140 any = A_arbace_j2g_access_A_const_20; var tmp141 any = A_arbace_j2g_access_A_const_19; var tmp142 any = A_arbace_j2g_access_A_const_22; var tmp143 *lang.Keyword; var G__978000039__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_4
















									L5: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000039__12_) >> 10 & 3 { case 0: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_42) { tmp143 = A_arbace_j2g_access_A_const_43; break L5 }; case 1: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_44) { tmp143 = A_arbace_j2g_access_A_const_45; break L5 }; case 2: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_34) { tmp143 = A_arbace_j2g_access_A_const_21; break L5 }; default:}; tmp143 = A_arbace_j2g_access_A_const_46}
//line :29:1
										var tmp144 any = tmp143.Ref(); var tmp145 any = A_arbace_j2g_access_A_const_24; var tmp146 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp147 any = A_arbace_j2g_access_A_const_47; var tmp148 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp149 any = A_arbace_j2g_access_A_const_25; var tmp150 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp151 any = A_arbace_j2g_access_A_const_33; var tmp152 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp153 any = A_arbace_j2g_access_A_const_48; var tmp154 any



















										if static_QMARK___6_4 { tmp154 = nil } else { var root_215 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = args__4; if linked_216 == nil { tmp154 = ifn_217.Invoke_O__O(arg_218) } else { tmp154 = linked_216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_215, arg_218) } }
//line :29:1
										var tmp155 any = tmp154; var tmp156 any = A_arbace_j2g_access_A_const_26; var tmp157 any; var root_223 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_225 lang.IFn



















										if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; if static_QMARK___6_4 { arg_226 = args__4 } else { var root_219 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = args__4; if linked_220 == nil { arg_226 = ifn_221.Invoke_O__O(arg_222) } else { arg_226 = linked_220.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_219, arg_222) } }; if linked_224 == nil { tmp157 = ifn_225.Invoke_O__O(arg_226) } else { tmp157 = linked_224.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_223, arg_226) }
//line :29:1
										var tmp158 any = tmp157; var tmp159 any = A_arbace_j2g_access_A_const_32; var tmp160 any = A_arbace_j2g_access_A_const_52; var tmp161 any = A_arbace_j2g_access_A_const_53; var tmp162 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp140, tmp141, tmp142, tmp144, tmp145, tmp146, tmp147, tmp148, tmp149, tmp150, tmp151, tmp152, tmp153, tmp155, tmp156, tmp158, tmp159, r__11_4, tmp160, m__8_4, tmp161, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp162, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__978000015__5_))))) } else {
//line :27:1
											return node__0 } }













func A_arbace_j2g_access_unaccess_fn__978000019_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000019_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000019_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000019_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000019_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000025_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000025_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000025_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000025_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000025_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000031_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000031_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000031_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000031_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000031_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000037_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000037_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000037_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000037_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000037_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }

























type A_arbace_j2g_access_A struct{ jrt.Object }

var A_arbace_j2g_access_A_const_pool *jrt.RefArray

var A_arbace_j2g_access_A_const_0 *lang.Var

var A_arbace_j2g_access_A_const_1 any

var A_arbace_j2g_access_A_const_2 any

var A_arbace_j2g_access_A_const_3 any

var A_arbace_j2g_access_A_const_4 any

var A_arbace_j2g_access_A_const_5 *lang.Var

var A_arbace_j2g_access_A_const_6 any

var A_arbace_j2g_access_A_const_7 *lang.Var

var A_arbace_j2g_access_A_const_8 *lang.Var

var A_arbace_j2g_access_A_const_9 *lang.Var

var A_arbace_j2g_access_A_const_10 *lang.Var

var A_arbace_j2g_access_A_const_11 any

var A_arbace_j2g_access_A_const_12 *lang.Var

var A_arbace_j2g_access_A_const_13 *lang.Var

var A_arbace_j2g_access_A_const_14 *lang.Var

var A_arbace_j2g_access_A_const_15 *lang.Keyword

var A_arbace_j2g_access_A_const_16 *lang.Var

var A_arbace_j2g_access_A_const_17 *lang.Var

var A_arbace_j2g_access_A_const_18 *lang.Var

var A_arbace_j2g_access_A_const_19 *lang.Keyword

var A_arbace_j2g_access_A_const_20 *lang.Keyword

var A_arbace_j2g_access_A_const_21 *lang.Keyword

var A_arbace_j2g_access_A_const_22 *lang.Keyword

var A_arbace_j2g_access_A_const_23 *lang.Var

var A_arbace_j2g_access_A_const_24 *lang.Keyword

var A_arbace_j2g_access_A_const_25 *lang.Keyword

var A_arbace_j2g_access_A_const_26 *lang.Keyword

var A_arbace_j2g_access_A_const_27 *lang.Keyword

var A_arbace_j2g_access_A_const_28 *lang.Keyword

var A_arbace_j2g_access_A_const_29 *lang.Var

var A_arbace_j2g_access_A_const_30 *lang.Keyword

var A_arbace_j2g_access_A_const_31 *lang.Keyword

var A_arbace_j2g_access_A_const_32 *lang.Keyword

var A_arbace_j2g_access_A_const_33 *lang.Keyword

var A_arbace_j2g_access_A_const_34 *lang.Keyword

var A_arbace_j2g_access_A_const_35 *lang.Var

var A_arbace_j2g_access_A_const_36 *lang.Keyword

var A_arbace_j2g_access_A_const_37 *lang.Var

var A_arbace_j2g_access_A_const_38 *lang.Var

var A_arbace_j2g_access_A_const_39 *lang.Keyword

var A_arbace_j2g_access_A_const_40 any

var A_arbace_j2g_access_A_const_41 *lang.Var

var A_arbace_j2g_access_A_const_42 *lang.Keyword

var A_arbace_j2g_access_A_const_43 *lang.Keyword

var A_arbace_j2g_access_A_const_44 *lang.Keyword

var A_arbace_j2g_access_A_const_45 *lang.Keyword

var A_arbace_j2g_access_A_const_46 *lang.Keyword

var A_arbace_j2g_access_A_const_47 *lang.Keyword

var A_arbace_j2g_access_A_const_48 *lang.Keyword

var A_arbace_j2g_access_A_const_49 *lang.Var

var A_arbace_j2g_access_A_const_50 *lang.Var

var A_arbace_j2g_access_A_const_51 *lang.Var

var A_arbace_j2g_access_A_const_52 *lang.Keyword

var A_arbace_j2g_access_A_const_53 *lang.Keyword

var A_arbace_j2g_access_A_const_54 *lang.Keyword

var A_arbace_j2g_access_A_const_55 *lang.Keyword

var A_arbace_j2g_access_A_const_56 *lang.Keyword

var A_arbace_j2g_access_A_const_57 *lang.Keyword

var A_arbace_j2g_access_A_const_58 *lang.Keyword

var A_arbace_j2g_access_A_const_59 *lang.Keyword

var A_arbace_j2g_access_A_const_60 *lang.Keyword

var A_arbace_j2g_access_A_const_61 *lang.Keyword

var A_arbace_j2g_access_A_const_62 *lang.Var

var A_arbace_j2g_access_A_init jrt.ClassInit

func A_arbace_j2g_access_A_Init() { if !A_arbace_j2g_access_A_init.Done() { A_arbace_j2g_access_A_init.Run(A_arbace_j2g_access_A_clinit) } }

func A_arbace_j2g_access_A_clinit() { A_arbace_j2g_access_A_clinit_p0(); A_arbace_j2g_access_A_clinit_p1(); A_arbace_j2g_access_A_clinit_p2(); A_arbace_j2g_access_A_clinit_p3(); A_arbace_j2g_access_A_clinit_p4(); A_arbace_j2g_access_A_clinit_p5() }

func A_arbace_j2g_access_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_access_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 108); A_arbace_j2g_access_A_const_0 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[45]); A_arbace_j2g_access_A_const_1 = A_arbace_j2g_access_A_const_pool.A[46]; A_arbace_j2g_access_A_const_2 = A_arbace_j2g_access_A_const_pool.A[47]; A_arbace_j2g_access_A_const_3 = A_arbace_j2g_access_A_const_pool.A[48]; A_arbace_j2g_access_A_const_4 = A_arbace_j2g_access_A_const_pool.A[49]; A_arbace_j2g_access_A_const_5 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[50]); A_arbace_j2g_access_A_const_6 = A_arbace_j2g_access_A_const_pool.A[51]; A_arbace_j2g_access_A_const_7 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[52]); A_arbace_j2g_access_A_const_8 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[53]); A_arbace_j2g_access_A_const_9 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[54]); A_arbace_j2g_access_A_const_10 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[55]); A_arbace_j2g_access_A_const_11 = A_arbace_j2g_access_A_const_pool.A[56] }

func A_arbace_j2g_access_A_clinit_p1() { A_arbace_j2g_access_A_const_12 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[57]); A_arbace_j2g_access_A_const_13 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[58]); A_arbace_j2g_access_A_const_14 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[59]); A_arbace_j2g_access_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[60]); A_arbace_j2g_access_A_const_16 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[61]); A_arbace_j2g_access_A_const_17 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[62]); A_arbace_j2g_access_A_const_18 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[63]); A_arbace_j2g_access_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[64]); A_arbace_j2g_access_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[65]); A_arbace_j2g_access_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[66]); A_arbace_j2g_access_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[67]); A_arbace_j2g_access_A_const_23 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[68]) }

func A_arbace_j2g_access_A_clinit_p2() { A_arbace_j2g_access_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[69]); A_arbace_j2g_access_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[70]); A_arbace_j2g_access_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[71]); A_arbace_j2g_access_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[72]); A_arbace_j2g_access_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[73]); A_arbace_j2g_access_A_const_29 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[74]); A_arbace_j2g_access_A_const_30 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[75]); A_arbace_j2g_access_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[76]); A_arbace_j2g_access_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[77]); A_arbace_j2g_access_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[78]); A_arbace_j2g_access_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[79]); A_arbace_j2g_access_A_const_35 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[80]) }

func A_arbace_j2g_access_A_clinit_p3() { A_arbace_j2g_access_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[81]); A_arbace_j2g_access_A_const_37 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[82]); A_arbace_j2g_access_A_const_38 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[83]); A_arbace_j2g_access_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[84]); A_arbace_j2g_access_A_const_40 = A_arbace_j2g_access_A_const_pool.A[85]; A_arbace_j2g_access_A_const_41 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[86]); A_arbace_j2g_access_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[87]); A_arbace_j2g_access_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[88]); A_arbace_j2g_access_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[89]); A_arbace_j2g_access_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[90]); A_arbace_j2g_access_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[91]); A_arbace_j2g_access_A_const_47 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[92]) }

func A_arbace_j2g_access_A_clinit_p4() { A_arbace_j2g_access_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[93]); A_arbace_j2g_access_A_const_49 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[94]); A_arbace_j2g_access_A_const_50 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[95]); A_arbace_j2g_access_A_const_51 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[96]); A_arbace_j2g_access_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[97]); A_arbace_j2g_access_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[98]); A_arbace_j2g_access_A_const_54 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[99]); A_arbace_j2g_access_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[100]); A_arbace_j2g_access_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[101]); A_arbace_j2g_access_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[102]); A_arbace_j2g_access_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[103]); A_arbace_j2g_access_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[104]) }

func A_arbace_j2g_access_A_clinit_p5() { A_arbace_j2g_access_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[105]); A_arbace_j2g_access_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[106]); A_arbace_j2g_access_A_const_62 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[107]) }

func A_arbace_j2g_access_A_New() *A_arbace_j2g_access_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_A) Ctor() {}

func (t *A_arbace_j2g_access_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_A_class }

func (t *A_arbace_j2g_access_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_A); return ok }

func A_arbace_j2g_access_A_Cast(x any) *A_arbace_j2g_access_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_A_class)) }; return v }



type A_arbace_j2g_access_accessor_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_accessor_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000004_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000004_A_New() *A_arbace_j2g_access_eval978000004_A { t := &A_arbace_j2g_access_eval978000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000004_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000004_A_class }

func (t *A_arbace_j2g_access_eval978000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000004_A); return ok }

func A_arbace_j2g_access_eval978000004_A_Cast(x any) *A_arbace_j2g_access_eval978000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000004_A_class)) }; return v }



type A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000008_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000008_A_New() *A_arbace_j2g_access_eval978000008_A { t := &A_arbace_j2g_access_eval978000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000008_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000008_A_class }

func (t *A_arbace_j2g_access_eval978000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000008_A); return ok }

func A_arbace_j2g_access_eval978000008_A_Cast(x any) *A_arbace_j2g_access_eval978000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000008_A_class)) }; return v }



type A_arbace_j2g_access_eval978000008_fn__978000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000008_fn__978000009_A_fn_class *jrt.Class



type A_arbace_j2g_access_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_unaccess_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000019_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000025_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000031_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000037_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class *jrt.Class
