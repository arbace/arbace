//line aot_arbace_j2g_access.ae:1
package aot_arbace_j2g_access

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_New() *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_access_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_access_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_access_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_access_A_const_1, A_arbace_j2g_access_A_const_2, A_arbace_j2g_access_A_const_3, A_arbace_j2g_access_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_access_eval978000008_fn__978000009_A_New() *A_arbace_j2g_access_eval978000008_fn__978000009_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000008_fn__978000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_access_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_access_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_access_A_const_10.GetRawRoot__O(), A_arbace_j2g_access_A_const_11) }











func A_arbace_j2g_access_accessor_A_New() *A_arbace_j2g_access_accessor_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_accessor_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Invoke_O_O_O__O(self, o__0, mname__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any; var root_22 any = A_arbace_j2g_access_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = mname__1; if linked_23 == nil { and__1927000168__auto____3 = ifn_24.Invoke_O__O(arg_25) } else { and__1927000168__auto____3 = linked_23.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_26 any = A_arbace_j2g_access_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = mname__1; var arg_30 any = Lit_1; if linked_27 == nil { and__1927000168__auto____4 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { and__1927000168__auto____4 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_31 any = A_arbace_j2g_access_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = o__0; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_31, arg_34) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_15; var tmp3 any; var root_35 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_j2g_access_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = o__0; if linked_40 == nil { arg_38 = ifn_41.Invoke_O__O(arg_42) } else { arg_38 = linked_40.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A).Invoke_O_O__O(root_39, arg_42) }; if linked_36 == nil { tmp3 = ifn_37.Invoke_O__O(arg_38) } else { tmp3 = linked_36.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_35, arg_38) }; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(tmp3), mname__1) } else {
//line :17:1
			return nil
		}
}
func A_arbace_j2g_access_find_field_A_New() *A_arbace_j2g_access_find_field_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_find_field_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Ctor() {}
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Invoke_O_O_O__O(self, owner__0, fname__1 any) any { var or__1927000174__auto____3 any; var root_43 any = A_arbace_j2g_access_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_classes_env.A_arbace_classes_env_find_field_A_fn_class); var ifn_45 lang.IFn; if
												linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = owner__0; var arg_47 any = fname__1; if linked_44 == nil { or__1927000174__auto____3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { or__1927000174__auto____3 = linked_44.(*aot_arbace_classes_env.A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_48 any = A_arbace_j2g_access_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_50 lang.IFn
													if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, owner__0, nil, fname__1)).Ref(); var arg_52 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_49 == nil { tmp1 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp1 = linked_49.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :21:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }


func A_arbace_j2g_access_unaccess_A_New() *A_arbace_j2g_access_unaccess_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Ctor() {}
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Invoke_O_O__O(self, node__0 any) any { var temp__1927000408__auto____2 any; var tmp1 any = A_arbace_j2g_access_A_const_19; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_access_A_const_20.Invoke_O__O(node__0)); if and__1927000168__auto____2 {


	var tmp2 any = A_arbace_j2g_access_A_const_21; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_access_A_const_22.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var root_53 any = A_arbace_j2g_access_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_j2g_access_accessor_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(node__0); var arg_57 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(node__0); if linked_54 == nil { temp__1927000408__auto____2 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { temp__1927000408__auto____2 = linked_54.(*A_arbace_j2g_access_accessor_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var acc__3 any = temp__1927000408__auto____2; var args__4 any = A_arbace_j2g_access_A_const_26.Invoke_O__O(node__0); var G__978000016__5_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)

		switch lang.Util_Hash_O__I_NoInit(G__978000016__5_) >> 4 & 15 { case 0: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_28) { var f__6 any; var root_59 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, A_arbace_j2g_access_find_field_A_fn_class); var ifn_61 lang.IFn





			if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_63 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_60 == nil { f__6 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { f__6 = linked_60.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }
//line :29:1
			var tmp3 any = A_arbace_j2g_access_A_const_20; var tmp4 any = A_arbace_j2g_access_A_const_30; var tmp5 any = A_arbace_j2g_access_A_const_31; var tmp6 any = A_arbace_j2g_access_A_const_24; var tmp7 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6); var tmp8 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, f__6, tmp6, tmp7, tmp8, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6))) }; case 4: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_34) { var tmp9 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var declared_in__7 any; var fnbody__76 any = A_arbace_j2g_access_unaccess_declared_in__978000020_A_New_O(acc__3); var tmp10 *jrt.Class
				var fncls__75 /*line :29:1*/*jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000020_A_fn_class











				if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__76); A_arbace_j2g_access_unaccess_declared_in__978000020_A_fn_class = fncls__75d; tmp10 = fncls__75d } else { tmp10 = fncls__75 }; declared_in__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp10, nil)
//line :29:1
				var owner__8 any

















				if static_QMARK___6 { var or__1927000174__auto____8 any; var root_77 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_79 lang.IFn
					if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var fnbody__83 any = A_arbace_j2g_access_unaccess_fn__978000024_A_New_O(declared_in__7); var tmp11 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000024_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__83); A_arbace_j2g_access_unaccess_fn__978000024_A_fn_class = fncls__82d; tmp11 = fncls__82d } else { tmp11 = fncls__82 }; arg_80 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp11, nil); var arg_81 any; var root_84 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_85 == nil { arg_81 = ifn_86.Invoke_O__O(arg_87) } else { arg_81 = linked_85.(*aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_84, arg_87) }; if linked_78 == nil { or__1927000174__auto____8 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { or__1927000174__auto____8 = linked_78.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if jrt.J2g_Truth(or__1927000174__auto____8) { owner__8 = or__1927000174__auto____8 } else { owner__8 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) } } else {
						owner__8 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) }
//line :29:1
				var m__9 any = lang.IFn_Cast(declared_in__7).Invoke_O__O(owner__8); var m__10 any; var root_88 any = A_arbace_j2g_access_A_const_39.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_90 lang.IFn





















				if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any; var or__1927000174__auto____10 any = m__9; if jrt.J2g_Truth(or__1927000174__auto____10) { arg_91 = or__1927000174__auto____10 } else { var tmp12 any = A_arbace_j2g_access_A_const_25; var tmp13 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp14 any = A_arbace_j2g_access_A_const_33; arg_91 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_40, A_arbace_j2g_access_A_const_41)) }; var arg_92 any = A_arbace_j2g_access_A_const_24; var arg_93 any = owner__8; if linked_89 == nil { m__10 = ifn_90.Invoke_O_O_O__O(arg_91, arg_92, arg_93) } else { m__10 = linked_89.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_88, arg_91, arg_92, arg_93) }
//line :29:1
				var vec__978000017__11 any; var root_94 any = A_arbace_j2g_access_A_const_42.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_96 lang.IFn






















				if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_95 == nil { vec__978000017__11 = ifn_96.Invoke_O__O(arg_97) } else { vec__978000017__11 = linked_95.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_94, arg_97) }
//line :29:1
				var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000017__11, lang.RT_IntCast_J__I_NoInit(0), nil); var r__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000017__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 any = A_arbace_j2g_access_A_const_20; var tmp16 any = A_arbace_j2g_access_A_const_19; var tmp17 any = A_arbace_j2g_access_A_const_22; var tmp18 *lang.Keyword; var G__978000026__14_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___12
























			L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000026__14_) >> 10 & 3 { case 0: if any(G__978000026__14_) == any(A_arbace_j2g_access_A_const_43) { tmp18 = A_arbace_j2g_access_A_const_44; break L2 }; case 1: if any(G__978000026__14_) == any(A_arbace_j2g_access_A_const_45) { tmp18 = A_arbace_j2g_access_A_const_46; break L2 }; case 2: if any(G__978000026__14_) == any(A_arbace_j2g_access_A_const_34) { tmp18 = A_arbace_j2g_access_A_const_21; break L2 }; default:}; tmp18 = A_arbace_j2g_access_A_const_47}
//line :29:1
				var tmp19 any = tmp18.Ref(); var tmp20 any = A_arbace_j2g_access_A_const_24; var tmp21 any = A_arbace_j2g_access_A_const_48; var tmp22 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_48.Invoke_O__O(acc__3))).Ref(); var tmp23 any = A_arbace_j2g_access_A_const_25; var tmp24 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp25 any = A_arbace_j2g_access_A_const_33; var tmp26 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp27 any = A_arbace_j2g_access_A_const_49; var tmp28 any



























				if static_QMARK___6 { tmp28 = nil } else { var root_99 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = args__4; if linked_100 == nil { tmp28 = ifn_101.Invoke_O__O(arg_102) } else { tmp28 = linked_100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_99, arg_102) } }
//line :29:1
				var tmp29 any = tmp28; var tmp30 any = A_arbace_j2g_access_A_const_26; var tmp31 any; var root_103 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_105 lang.IFn



























				if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; if static_QMARK___6 { arg_106 = args__4 } else { var root_107 any = A_arbace_j2g_access_A_const_52.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = args__4; if linked_108 == nil { arg_106 = ifn_109.Invoke_O__O(arg_110) } else { arg_106 = linked_108.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_107, arg_110) } }; if linked_104 == nil { tmp31 = ifn_105.Invoke_O__O(arg_106) } else { tmp31 = linked_104.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_103, arg_106) }
//line :29:1
				var tmp32 any = tmp31; var tmp33 any = A_arbace_j2g_access_A_const_32; var tmp34 any = A_arbace_j2g_access_A_const_53; var tmp35 any = A_arbace_j2g_access_A_const_54; var tmp36 any = A_arbace_j2g_access_A_const_45; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16, tmp17, tmp19, tmp20, owner__8, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp29, tmp30, tmp32, tmp33, r__13, tmp34, m__10, tmp35, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp36, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 6: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_55) { var f__6_2 any; var root_111 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_j2g_access_find_field_A_fn_class); var ifn_113 lang.IFn







					if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_115 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_112 == nil { f__6_2 = ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { f__6_2 = linked_112.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) }
//line :29:1
					var tmp37 any = A_arbace_j2g_access_A_const_20; var tmp38 any = A_arbace_j2g_access_A_const_56; var tmp39 any = A_arbace_j2g_access_A_const_31; var tmp40 any = A_arbace_j2g_access_A_const_24; var tmp41 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_2); var tmp42 any = A_arbace_j2g_access_A_const_57; var tmp43 any; var root_116 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_118 lang.IFn








					if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = args__4; if linked_117 == nil { tmp43 = ifn_118.Invoke_O__O(arg_119) } else { tmp43 = linked_117.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_116, arg_119) }
//line :29:1
					var tmp44 any = tmp43; var tmp45 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38, tmp39, f__6_2, tmp40, tmp41, tmp42, tmp44, tmp45, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_2))) }; case 8: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_58) { var tmp46 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp46, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var declared_in__7_2 any; var fnbody__132 any = A_arbace_j2g_access_unaccess_declared_in__978000030_A_New_O(acc__3); var tmp47 *jrt.Class
						var fncls__131 /*line :29:1*/*jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000030_A_fn_class











						if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__132); A_arbace_j2g_access_unaccess_declared_in__978000030_A_fn_class = fncls__131d; tmp47 = fncls__131d } else { tmp47 = fncls__131 }; declared_in__7_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp47, nil)
//line :29:1
						var owner__8_2 any

















						if static_QMARK___6_2 { var or__1927000174__auto____8_2 any; var root_133 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_135 lang.IFn
							if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var fnbody__139 any = A_arbace_j2g_access_unaccess_fn__978000034_A_New_O(declared_in__7_2); var tmp48 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000034_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__139); A_arbace_j2g_access_unaccess_fn__978000034_A_fn_class = fncls__138d; tmp48 = fncls__138d } else { tmp48 = fncls__138 }; arg_136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp48, nil); var arg_137 any; var root_140 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_141 == nil { arg_137 = ifn_142.Invoke_O__O(arg_143) } else { arg_137 = linked_141.(*aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_140, arg_143) }; if linked_134 == nil { or__1927000174__auto____8_2 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { or__1927000174__auto____8_2 = linked_134.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }; if jrt.J2g_Truth(or__1927000174__auto____8_2) { owner__8_2 = or__1927000174__auto____8_2 } else { owner__8_2 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) } } else {
								owner__8_2 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) }
//line :29:1
						var m__9_2 any = lang.IFn_Cast(declared_in__7_2).Invoke_O__O(owner__8_2); var m__10_2 any; var root_144 any = A_arbace_j2g_access_A_const_39.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_146 lang.IFn





















						if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any; var or__1927000174__auto____10_2 any = m__9_2; if jrt.J2g_Truth(or__1927000174__auto____10_2) { arg_147 = or__1927000174__auto____10_2 } else { var tmp49 any = A_arbace_j2g_access_A_const_25; var tmp50 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp51 any = A_arbace_j2g_access_A_const_33; arg_147 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp50, tmp51, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_40, A_arbace_j2g_access_A_const_41)) }; var arg_148 any = A_arbace_j2g_access_A_const_24; var arg_149 any = owner__8_2; if linked_145 == nil { m__10_2 = ifn_146.Invoke_O_O_O__O(arg_147, arg_148, arg_149) } else { m__10_2 = linked_145.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_144, arg_147, arg_148, arg_149) }
//line :29:1
						var vec__978000027__11 any; var root_150 any = A_arbace_j2g_access_A_const_42.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_152 lang.IFn






















						if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_151 == nil { vec__978000027__11 = ifn_152.Invoke_O__O(arg_153) } else { vec__978000027__11 = linked_151.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_150, arg_153) }
//line :29:1
						var ___12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000027__11, lang.RT_IntCast_J__I_NoInit(0), nil); var r__13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000027__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp52 any = A_arbace_j2g_access_A_const_20; var tmp53 any = A_arbace_j2g_access_A_const_19; var tmp54 any = A_arbace_j2g_access_A_const_22; var tmp55 *lang.Keyword; var G__978000036__14_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___12_2
























					L3: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000036__14_) >> 10 & 3 { case 0: if any(G__978000036__14_) == any(A_arbace_j2g_access_A_const_43) { tmp55 = A_arbace_j2g_access_A_const_44; break L3 }; case 1: if any(G__978000036__14_) == any(A_arbace_j2g_access_A_const_45) { tmp55 = A_arbace_j2g_access_A_const_46; break L3 }; case 2: if any(G__978000036__14_) == any(A_arbace_j2g_access_A_const_34) { tmp55 = A_arbace_j2g_access_A_const_21; break L3 }; default:}; tmp55 = A_arbace_j2g_access_A_const_47}
//line :29:1
						var tmp56 any = tmp55.Ref(); var tmp57 any = A_arbace_j2g_access_A_const_24; var tmp58 any = A_arbace_j2g_access_A_const_48; var tmp59 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_48.Invoke_O__O(acc__3))).Ref(); var tmp60 any = A_arbace_j2g_access_A_const_25; var tmp61 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp62 any = A_arbace_j2g_access_A_const_33; var tmp63 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp64 any = A_arbace_j2g_access_A_const_49; var tmp65 any



























						if static_QMARK___6_2 { tmp65 = nil } else { var root_155 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = args__4; if linked_156 == nil { tmp65 = ifn_157.Invoke_O__O(arg_158) } else { tmp65 = linked_156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_155, arg_158) } }
//line :29:1
						var tmp66 any = tmp65; var tmp67 any = A_arbace_j2g_access_A_const_26; var tmp68 any; var root_159 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_161 lang.IFn



























						if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; if static_QMARK___6_2 { arg_162 = args__4 } else { var root_163 any = A_arbace_j2g_access_A_const_52.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = args__4; if linked_164 == nil { arg_162 = ifn_165.Invoke_O__O(arg_166) } else { arg_162 = linked_164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_163, arg_166) } }; if linked_160 == nil { tmp68 = ifn_161.Invoke_O__O(arg_162) } else { tmp68 = linked_160.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_159, arg_162) }
//line :29:1
						var tmp69 any = tmp68; var tmp70 any = A_arbace_j2g_access_A_const_32; var tmp71 any = A_arbace_j2g_access_A_const_53; var tmp72 any = A_arbace_j2g_access_A_const_54; var tmp73 any = A_arbace_j2g_access_A_const_45; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp53, tmp54, tmp56, tmp57, owner__8_2, tmp58, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp66, tmp67, tmp69, tmp70, r__13_2, tmp71, m__10_2, tmp72, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp73, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 10: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_59) { var f__6_3 any; var root_167 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_j2g_access_find_field_A_fn_class); var ifn_169 lang.IFn
							if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_171 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_168 == nil { f__6_3 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { f__6_3 = linked_168.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) }
//line :29:1
							var tmp74 any = A_arbace_j2g_access_A_const_20; var tmp75 any = A_arbace_j2g_access_A_const_60; var tmp76 any = A_arbace_j2g_access_A_const_31; var tmp77 any = A_arbace_j2g_access_A_const_24; var tmp78 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_3); var tmp79 any = A_arbace_j2g_access_A_const_49; var tmp80 any; var root_172 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_174 lang.IFn

							if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = args__4; if linked_173 == nil { tmp80 = ifn_174.Invoke_O__O(arg_175) } else { tmp80 = linked_173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_172, arg_175) }
//line :29:1
							var tmp81 any = tmp80; var tmp82 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp75, tmp76, f__6_3, tmp77, tmp78, tmp79, tmp81, tmp82, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_3))) }; case 11: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_61) { var f__6_4 any; var root_176 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_j2g_access_find_field_A_fn_class); var ifn_178 lang.IFn


								if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_180 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_177 == nil { f__6_4 = ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { f__6_4 = linked_177.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) }
//line :29:1
								var tmp83 any = A_arbace_j2g_access_A_const_20; var tmp84 any = A_arbace_j2g_access_A_const_62; var tmp85 any = A_arbace_j2g_access_A_const_31; var tmp86 any = A_arbace_j2g_access_A_const_24; var tmp87 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_4); var tmp88 any = A_arbace_j2g_access_A_const_49; var tmp89 any; var root_181 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_183 lang.IFn



								if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = args__4; if linked_182 == nil { tmp89 = ifn_183.Invoke_O__O(arg_184) } else { tmp89 = linked_182.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_181, arg_184) }
//line :29:1
								var tmp90 any = tmp89; var tmp91 any = A_arbace_j2g_access_A_const_57; var tmp92 any; var root_185 any = A_arbace_j2g_access_A_const_63.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_187 lang.IFn



								if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = args__4; if linked_186 == nil { tmp92 = ifn_187.Invoke_O__O(arg_188) } else { tmp92 = linked_186.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_185, arg_188) }
//line :29:1
								var tmp93 any = tmp92; var tmp94 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp83, tmp84, tmp85, f__6_4, tmp86, tmp87, tmp88, tmp90, tmp91, tmp93, tmp94, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_4))) }; case 12: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_45) { var tmp95 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp95, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var declared_in__7_3 any; var fnbody__201 any = A_arbace_j2g_access_unaccess_declared_in__978000040_A_New_O(acc__3); var tmp96 *jrt.Class
									var fncls__200 /*line :29:1*/*jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000040_A_fn_class











									if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__201); A_arbace_j2g_access_unaccess_declared_in__978000040_A_fn_class = fncls__200d; tmp96 = fncls__200d } else { tmp96 = fncls__200 }; declared_in__7_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__201, tmp96, nil)
//line :29:1
									var owner__8_3 any

















									if static_QMARK___6_3 { var or__1927000174__auto____8_3 any; var root_202 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_204 lang.IFn
										if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var fnbody__208 any = A_arbace_j2g_access_unaccess_fn__978000044_A_New_O(declared_in__7_3); var tmp97 *jrt.Class; var fncls__207 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000044_A_fn_class; if fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__208); A_arbace_j2g_access_unaccess_fn__978000044_A_fn_class = fncls__207d; tmp97 = fncls__207d } else { tmp97 = fncls__207 }; arg_205 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__208, tmp97, nil); var arg_206 any; var root_209 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_210 == nil { arg_206 = ifn_211.Invoke_O__O(arg_212) } else { arg_206 = linked_210.(*aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_209, arg_212) }; if linked_203 == nil { or__1927000174__auto____8_3 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { or__1927000174__auto____8_3 = linked_203.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; if jrt.J2g_Truth(or__1927000174__auto____8_3) { owner__8_3 = or__1927000174__auto____8_3 } else { owner__8_3 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) } } else {
											owner__8_3 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) }
//line :29:1
									var m__9_3 any = lang.IFn_Cast(declared_in__7_3).Invoke_O__O(owner__8_3); var m__10_3 any; var root_213 any = A_arbace_j2g_access_A_const_39.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_215 lang.IFn





















									if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var or__1927000174__auto____10_3 any = m__9_3; if jrt.J2g_Truth(or__1927000174__auto____10_3) { arg_216 = or__1927000174__auto____10_3 } else { var tmp98 any = A_arbace_j2g_access_A_const_25; var tmp99 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp100 any = A_arbace_j2g_access_A_const_33; arg_216 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp98, tmp99, tmp100, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_40, A_arbace_j2g_access_A_const_41)) }; var arg_217 any = A_arbace_j2g_access_A_const_24; var arg_218 any = owner__8_3; if linked_214 == nil { m__10_3 = ifn_215.Invoke_O_O_O__O(arg_216, arg_217, arg_218) } else { m__10_3 = linked_214.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_213, arg_216, arg_217, arg_218) }
//line :29:1
									var vec__978000037__11 any; var root_219 any = A_arbace_j2g_access_A_const_42.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_221 lang.IFn






















									if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_220 == nil { vec__978000037__11 = ifn_221.Invoke_O__O(arg_222) } else { vec__978000037__11 = linked_220.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_219, arg_222) }
//line :29:1
									var ___12_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000037__11, lang.RT_IntCast_J__I_NoInit(0), nil); var r__13_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000037__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp101 any = A_arbace_j2g_access_A_const_20; var tmp102 any = A_arbace_j2g_access_A_const_19; var tmp103 any = A_arbace_j2g_access_A_const_22; var tmp104 *lang.Keyword; var G__978000046__14_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___12_3
























								L4: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000046__14_) >> 10 & 3 { case 0: if any(G__978000046__14_) == any(A_arbace_j2g_access_A_const_43) { tmp104 = A_arbace_j2g_access_A_const_44; break L4 }; case 1: if any(G__978000046__14_) == any(A_arbace_j2g_access_A_const_45) { tmp104 = A_arbace_j2g_access_A_const_46; break L4 }; case 2: if any(G__978000046__14_) == any(A_arbace_j2g_access_A_const_34) { tmp104 = A_arbace_j2g_access_A_const_21; break L4 }; default:}; tmp104 = A_arbace_j2g_access_A_const_47}
//line :29:1
									var tmp105 any = tmp104.Ref(); var tmp106 any = A_arbace_j2g_access_A_const_24; var tmp107 any = A_arbace_j2g_access_A_const_48; var tmp108 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_48.Invoke_O__O(acc__3))).Ref(); var tmp109 any = A_arbace_j2g_access_A_const_25; var tmp110 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp111 any = A_arbace_j2g_access_A_const_33; var tmp112 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp113 any = A_arbace_j2g_access_A_const_49; var tmp114 any



























									if static_QMARK___6_3 { tmp114 = nil } else { var root_224 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = args__4; if linked_225 == nil { tmp114 = ifn_226.Invoke_O__O(arg_227) } else { tmp114 = linked_225.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_224, arg_227) } }
//line :29:1
									var tmp115 any = tmp114; var tmp116 any = A_arbace_j2g_access_A_const_26; var tmp117 any; var root_228 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_230 lang.IFn



























									if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; if static_QMARK___6_3 { arg_231 = args__4 } else { var root_232 any = A_arbace_j2g_access_A_const_52.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = args__4; if linked_233 == nil { arg_231 = ifn_234.Invoke_O__O(arg_235) } else { arg_231 = linked_233.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_232, arg_235) } }; if linked_229 == nil { tmp117 = ifn_230.Invoke_O__O(arg_231) } else { tmp117 = linked_229.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_228, arg_231) }
//line :29:1
									var tmp118 any = tmp117; var tmp119 any = A_arbace_j2g_access_A_const_32; var tmp120 any = A_arbace_j2g_access_A_const_53; var tmp121 any = A_arbace_j2g_access_A_const_54; var tmp122 any = A_arbace_j2g_access_A_const_45; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp101, tmp102, tmp103, tmp105, tmp106, owner__8_3, tmp107, tmp108, tmp109, tmp110, tmp111, tmp112, tmp113, tmp115, tmp116, tmp118, tmp119, r__13_3, tmp120, m__10_3, tmp121, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp122, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 14: if any(G__978000016__5_) == any(A_arbace_j2g_access_A_const_43) { var tmp123 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp123, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var declared_in__7_4 any; var fnbody__248 any = A_arbace_j2g_access_unaccess_declared_in__978000050_A_New_O(acc__3); var tmp124 *jrt.Class
										var fncls__247 /*line :29:1*/*jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000050_A_fn_class











										if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__248); A_arbace_j2g_access_unaccess_declared_in__978000050_A_fn_class = fncls__247d; tmp124 = fncls__247d } else { tmp124 = fncls__247 }; declared_in__7_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp124, nil)
//line :29:1
										var owner__8_4 any

















										if static_QMARK___6_4 { var or__1927000174__auto____8_4 any; var root_249 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_251 lang.IFn
											if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var fnbody__255 any = A_arbace_j2g_access_unaccess_fn__978000054_A_New_O(declared_in__7_4); var tmp125 *jrt.Class; var fncls__254 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000054_A_fn_class; if fncls__254 == nil { var fncls__254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__255); A_arbace_j2g_access_unaccess_fn__978000054_A_fn_class = fncls__254d; tmp125 = fncls__254d } else { tmp125 = fncls__254 }; arg_252 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__255, tmp125, nil); var arg_253 any; var root_256 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_257 == nil { arg_253 = ifn_258.Invoke_O__O(arg_259) } else { arg_253 = linked_257.(*aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_256, arg_259) }; if linked_250 == nil { or__1927000174__auto____8_4 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { or__1927000174__auto____8_4 = linked_250.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }; if jrt.J2g_Truth(or__1927000174__auto____8_4) { owner__8_4 = or__1927000174__auto____8_4 } else { owner__8_4 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) } } else {
												owner__8_4 = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3) }
//line :29:1
										var m__9_4 any = lang.IFn_Cast(declared_in__7_4).Invoke_O__O(owner__8_4); var m__10_4 any; var root_260 any = A_arbace_j2g_access_A_const_39.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_262 lang.IFn





















										if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var or__1927000174__auto____10_4 any = m__9_4; if jrt.J2g_Truth(or__1927000174__auto____10_4) { arg_263 = or__1927000174__auto____10_4 } else { var tmp126 any = A_arbace_j2g_access_A_const_25; var tmp127 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp128 any = A_arbace_j2g_access_A_const_33; arg_263 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp126, tmp127, tmp128, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_40, A_arbace_j2g_access_A_const_41)) }; var arg_264 any = A_arbace_j2g_access_A_const_24; var arg_265 any = owner__8_4; if linked_261 == nil { m__10_4 = ifn_262.Invoke_O_O_O__O(arg_263, arg_264, arg_265) } else { m__10_4 = linked_261.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_260, arg_263, arg_264, arg_265) }
//line :29:1
										var vec__978000047__11 any; var root_266 any = A_arbace_j2g_access_A_const_42.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_268 lang.IFn






















										if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_267 == nil { vec__978000047__11 = ifn_268.Invoke_O__O(arg_269) } else { vec__978000047__11 = linked_267.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_266, arg_269) }
//line :29:1
										var ___12_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000047__11, lang.RT_IntCast_J__I_NoInit(0), nil); var r__13_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000047__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp129 any = A_arbace_j2g_access_A_const_20; var tmp130 any = A_arbace_j2g_access_A_const_19; var tmp131 any = A_arbace_j2g_access_A_const_22; var tmp132 *lang.Keyword; var G__978000056__14_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___12_4
























									L5: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000056__14_) >> 10 & 3 { case 0: if any(G__978000056__14_) == any(A_arbace_j2g_access_A_const_43) { tmp132 = A_arbace_j2g_access_A_const_44; break L5 }; case 1: if any(G__978000056__14_) == any(A_arbace_j2g_access_A_const_45) { tmp132 = A_arbace_j2g_access_A_const_46; break L5 }; case 2: if any(G__978000056__14_) == any(A_arbace_j2g_access_A_const_34) { tmp132 = A_arbace_j2g_access_A_const_21; break L5 }; default:}; tmp132 = A_arbace_j2g_access_A_const_47}
//line :29:1
										var tmp133 any = tmp132.Ref(); var tmp134 any = A_arbace_j2g_access_A_const_24; var tmp135 any = A_arbace_j2g_access_A_const_48; var tmp136 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_48.Invoke_O__O(acc__3))).Ref(); var tmp137 any = A_arbace_j2g_access_A_const_25; var tmp138 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp139 any = A_arbace_j2g_access_A_const_33; var tmp140 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp141 any = A_arbace_j2g_access_A_const_49; var tmp142 any



























										if static_QMARK___6_4 { tmp142 = nil } else { var root_271 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = args__4; if linked_272 == nil { tmp142 = ifn_273.Invoke_O__O(arg_274) } else { tmp142 = linked_272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_271, arg_274) } }
//line :29:1
										var tmp143 any = tmp142; var tmp144 any = A_arbace_j2g_access_A_const_26; var tmp145 any; var root_275 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_277 lang.IFn



























										if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any; if static_QMARK___6_4 { arg_278 = args__4 } else { var root_279 any = A_arbace_j2g_access_A_const_52.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = args__4; if linked_280 == nil { arg_278 = ifn_281.Invoke_O__O(arg_282) } else { arg_278 = linked_280.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_279, arg_282) } }; if linked_276 == nil { tmp145 = ifn_277.Invoke_O__O(arg_278) } else { tmp145 = linked_276.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_275, arg_278) }
//line :29:1
										var tmp146 any = tmp145; var tmp147 any = A_arbace_j2g_access_A_const_32; var tmp148 any = A_arbace_j2g_access_A_const_53; var tmp149 any = A_arbace_j2g_access_A_const_54; var tmp150 any = A_arbace_j2g_access_A_const_45; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp129, tmp130, tmp131, tmp133, tmp134, owner__8_4, tmp135, tmp136, tmp137, tmp138, tmp139, tmp140, tmp141, tmp143, tmp144, tmp146, tmp147, r__13_4, tmp148, m__10_4, tmp149, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp150, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__978000016__5_))))) } else {
//line :27:1
											return node__0 } }













func A_arbace_j2g_access_unaccess_declared_in__978000020_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000020_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000020_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000020_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000020_A) Invoke_O_O__O(self, c__1 any) any { var root_64 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__70 any = A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_New_O(t.F_acc); var tmp1 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__70); A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_fn_class = fncls__69d; tmp1 = fncls__69d } else { tmp1 = fncls__69 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp1, nil); var arg_68 any; var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp3 any; var root_71 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_73 lang.IFn; if
													linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = c__1; if linked_72 == nil { tmp3 = ifn_73.Invoke_O__O(arg_74) } else { tmp3 = linked_72.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_71, arg_74) }; arg_68 = tmp2.Invoke_O__O(tmp3); if /*line :41:1*/ linked_65 == nil { return ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { return linked_65.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000030_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000030_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000030_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000030_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000030_A) Invoke_O_O__O(self, c__1 any) any { var root_120 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var fnbody__126 any = A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_New_O(t.F_acc); var tmp1 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__126); A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_fn_class = fncls__125d; tmp1 = fncls__125d } else { tmp1 = fncls__125 }; arg_123 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp1, nil); var arg_124 any; var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp3 any; var root_127 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_129 lang.IFn; if
													linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__1; if linked_128 == nil { tmp3 = ifn_129.Invoke_O__O(arg_130) } else { tmp3 = linked_128.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_127, arg_130) }; arg_124 = tmp2.Invoke_O__O(tmp3); if /*line :41:1*/ linked_121 == nil { return ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { return linked_121.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000040_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000040_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000040_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000040_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000040_A) Invoke_O_O__O(self, c__1 any) any { var root_189 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any; var fnbody__195 any = A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_New_O(t.F_acc); var tmp1 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__195); A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_fn_class = fncls__194d; tmp1 = fncls__194d } else { tmp1 = fncls__194 }; arg_192 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__195, tmp1, nil); var arg_193 any; var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp3 any; var root_196 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_198 lang.IFn; if
													linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = c__1; if linked_197 == nil { tmp3 = ifn_198.Invoke_O__O(arg_199) } else { tmp3 = linked_197.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_196, arg_199) }; arg_193 = tmp2.Invoke_O__O(tmp3); if /*line :41:1*/ linked_190 == nil { return ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { return linked_190.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000050_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000050_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000050_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000050_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000050_A) Invoke_O_O__O(self, c__1 any) any { var root_236 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var fnbody__242 any = A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_New_O(t.F_acc); var tmp1 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__242); A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_fn_class = fncls__241d; tmp1 = fncls__241d } else { tmp1 = fncls__241 }; arg_239 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__242, tmp1, nil); var arg_240 any; var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp3 any; var root_243 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_245 lang.IFn; if
													linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = c__1; if linked_244 == nil { tmp3 = ifn_245.Invoke_O__O(arg_246) } else { tmp3 = linked_244.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_243, arg_246) }; arg_240 = tmp2.Invoke_O__O(tmp3); if /*line :41:1*/ linked_237 == nil { return ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { return linked_237.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_236, arg_239, arg_240) } }
//line :41:1
func A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }






func A_arbace_j2g_access_unaccess_fn__978000024_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000024_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000024_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000024_A) Ctor_O(c__declared_in any) { t.F_declared_in = c__declared_in }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000024_A) Invoke_O_O__O(self, p1__978000015_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_declared_in).Invoke_O__O(p1__978000015_SHARP___1)) { return p1__978000015_SHARP___1 } else { return nil } }
//line :48:1
func A_arbace_j2g_access_unaccess_fn__978000034_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000034_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000034_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000034_A) Ctor_O(c__declared_in any) { t.F_declared_in = c__declared_in }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000034_A) Invoke_O_O__O(self, p1__978000015_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_declared_in).Invoke_O__O(p1__978000015_SHARP___1)) { return p1__978000015_SHARP___1 } else { return nil } }
//line :48:1
func A_arbace_j2g_access_unaccess_fn__978000044_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000044_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000044_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000044_A) Ctor_O(c__declared_in any) { t.F_declared_in = c__declared_in }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000044_A) Invoke_O_O__O(self, p1__978000015_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_declared_in).Invoke_O__O(p1__978000015_SHARP___1)) { return p1__978000015_SHARP___1 } else { return nil } }
//line :48:1
func A_arbace_j2g_access_unaccess_fn__978000054_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000054_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000054_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000054_A) Ctor_O(c__declared_in any) { t.F_declared_in = c__declared_in }
//line :48:1
func (t *A_arbace_j2g_access_unaccess_fn__978000054_A) Invoke_O_O__O(self, p1__978000015_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_declared_in).Invoke_O__O(p1__978000015_SHARP___1)) { return p1__978000015_SHARP___1 } else { return nil } }


































































type A_arbace_j2g_access_A struct{ jrt.Object }

var A_arbace_j2g_access_A_const_pool *jrt.RefArray

var A_arbace_j2g_access_A_const_0 *lang.Var

var A_arbace_j2g_access_A_const_1 any

var A_arbace_j2g_access_A_const_2 any

var A_arbace_j2g_access_A_const_3 any

var A_arbace_j2g_access_A_const_4 any

var A_arbace_j2g_access_A_const_5 *lang.Var

var A_arbace_j2g_access_A_const_6 any

var A_arbace_j2g_access_A_const_7 *lang.Var

var A_arbace_j2g_access_A_const_8 *lang.Var

var A_arbace_j2g_access_A_const_9 *lang.Var

var A_arbace_j2g_access_A_const_10 *lang.Var

var A_arbace_j2g_access_A_const_11 any

var A_arbace_j2g_access_A_const_12 *lang.Var

var A_arbace_j2g_access_A_const_13 *lang.Var

var A_arbace_j2g_access_A_const_14 *lang.Var

var A_arbace_j2g_access_A_const_15 *lang.Keyword

var A_arbace_j2g_access_A_const_16 *lang.Var

var A_arbace_j2g_access_A_const_17 *lang.Var

var A_arbace_j2g_access_A_const_18 *lang.Var

var A_arbace_j2g_access_A_const_19 *lang.Keyword

var A_arbace_j2g_access_A_const_20 *lang.Keyword

var A_arbace_j2g_access_A_const_21 *lang.Keyword

var A_arbace_j2g_access_A_const_22 *lang.Keyword

var A_arbace_j2g_access_A_const_23 *lang.Var

var A_arbace_j2g_access_A_const_24 *lang.Keyword

var A_arbace_j2g_access_A_const_25 *lang.Keyword

var A_arbace_j2g_access_A_const_26 *lang.Keyword

var A_arbace_j2g_access_A_const_27 *lang.Keyword

var A_arbace_j2g_access_A_const_28 *lang.Keyword

var A_arbace_j2g_access_A_const_29 *lang.Var

var A_arbace_j2g_access_A_const_30 *lang.Keyword

var A_arbace_j2g_access_A_const_31 *lang.Keyword

var A_arbace_j2g_access_A_const_32 *lang.Keyword

var A_arbace_j2g_access_A_const_33 *lang.Keyword

var A_arbace_j2g_access_A_const_34 *lang.Keyword

var A_arbace_j2g_access_A_const_35 *lang.Var

var A_arbace_j2g_access_A_const_36 *lang.Keyword

var A_arbace_j2g_access_A_const_37 *lang.Var

var A_arbace_j2g_access_A_const_38 *lang.Var

var A_arbace_j2g_access_A_const_39 *lang.Var

var A_arbace_j2g_access_A_const_40 *lang.Keyword

var A_arbace_j2g_access_A_const_41 any

var A_arbace_j2g_access_A_const_42 *lang.Var

var A_arbace_j2g_access_A_const_43 *lang.Keyword

var A_arbace_j2g_access_A_const_44 *lang.Keyword

var A_arbace_j2g_access_A_const_45 *lang.Keyword

var A_arbace_j2g_access_A_const_46 *lang.Keyword

var A_arbace_j2g_access_A_const_47 *lang.Keyword

var A_arbace_j2g_access_A_const_48 *lang.Keyword

var A_arbace_j2g_access_A_const_49 *lang.Keyword

var A_arbace_j2g_access_A_const_50 *lang.Var

var A_arbace_j2g_access_A_const_51 *lang.Var

var A_arbace_j2g_access_A_const_52 *lang.Var

var A_arbace_j2g_access_A_const_53 *lang.Keyword

var A_arbace_j2g_access_A_const_54 *lang.Keyword

var A_arbace_j2g_access_A_const_55 *lang.Keyword

var A_arbace_j2g_access_A_const_56 *lang.Keyword

var A_arbace_j2g_access_A_const_57 *lang.Keyword

var A_arbace_j2g_access_A_const_58 *lang.Keyword

var A_arbace_j2g_access_A_const_59 *lang.Keyword

var A_arbace_j2g_access_A_const_60 *lang.Keyword

var A_arbace_j2g_access_A_const_61 *lang.Keyword

var A_arbace_j2g_access_A_const_62 *lang.Keyword

var A_arbace_j2g_access_A_const_63 *lang.Var

var A_arbace_j2g_access_A_init jrt.ClassInit

func A_arbace_j2g_access_A_Init() { if !A_arbace_j2g_access_A_init.Done() { A_arbace_j2g_access_A_init.Run(A_arbace_j2g_access_A_clinit) } }

func A_arbace_j2g_access_A_clinit() { A_arbace_j2g_access_A_clinit_p0(); A_arbace_j2g_access_A_clinit_p1(); A_arbace_j2g_access_A_clinit_p2(); A_arbace_j2g_access_A_clinit_p3(); A_arbace_j2g_access_A_clinit_p4(); A_arbace_j2g_access_A_clinit_p5() }

func A_arbace_j2g_access_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_access_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 109); A_arbace_j2g_access_A_const_0 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[45]); A_arbace_j2g_access_A_const_1 = A_arbace_j2g_access_A_const_pool.A[46]; A_arbace_j2g_access_A_const_2 = A_arbace_j2g_access_A_const_pool.A[47]; A_arbace_j2g_access_A_const_3 = A_arbace_j2g_access_A_const_pool.A[48]; A_arbace_j2g_access_A_const_4 = A_arbace_j2g_access_A_const_pool.A[49]; A_arbace_j2g_access_A_const_5 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[50]); A_arbace_j2g_access_A_const_6 = A_arbace_j2g_access_A_const_pool.A[51]; A_arbace_j2g_access_A_const_7 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[52]); A_arbace_j2g_access_A_const_8 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[53]); A_arbace_j2g_access_A_const_9 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[54]); A_arbace_j2g_access_A_const_10 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[55]); A_arbace_j2g_access_A_const_11 = A_arbace_j2g_access_A_const_pool.A[56] }

func A_arbace_j2g_access_A_clinit_p1() { A_arbace_j2g_access_A_const_12 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[57]); A_arbace_j2g_access_A_const_13 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[58]); A_arbace_j2g_access_A_const_14 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[59]); A_arbace_j2g_access_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[60]); A_arbace_j2g_access_A_const_16 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[61]); A_arbace_j2g_access_A_const_17 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[62]); A_arbace_j2g_access_A_const_18 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[63]); A_arbace_j2g_access_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[64]); A_arbace_j2g_access_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[65]); A_arbace_j2g_access_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[66]); A_arbace_j2g_access_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[67]); A_arbace_j2g_access_A_const_23 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[68]) }

func A_arbace_j2g_access_A_clinit_p2() { A_arbace_j2g_access_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[69]); A_arbace_j2g_access_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[70]); A_arbace_j2g_access_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[71]); A_arbace_j2g_access_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[72]); A_arbace_j2g_access_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[73]); A_arbace_j2g_access_A_const_29 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[74]); A_arbace_j2g_access_A_const_30 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[75]); A_arbace_j2g_access_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[76]); A_arbace_j2g_access_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[77]); A_arbace_j2g_access_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[78]); A_arbace_j2g_access_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[79]); A_arbace_j2g_access_A_const_35 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[80]) }

func A_arbace_j2g_access_A_clinit_p3() { A_arbace_j2g_access_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[81]); A_arbace_j2g_access_A_const_37 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[82]); A_arbace_j2g_access_A_const_38 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[83]); A_arbace_j2g_access_A_const_39 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[84]); A_arbace_j2g_access_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[85]); A_arbace_j2g_access_A_const_41 = A_arbace_j2g_access_A_const_pool.A[86]; A_arbace_j2g_access_A_const_42 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[87]); A_arbace_j2g_access_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[88]); A_arbace_j2g_access_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[89]); A_arbace_j2g_access_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[90]); A_arbace_j2g_access_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[91]); A_arbace_j2g_access_A_const_47 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[92]) }

func A_arbace_j2g_access_A_clinit_p4() { A_arbace_j2g_access_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[93]); A_arbace_j2g_access_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[94]); A_arbace_j2g_access_A_const_50 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[95]); A_arbace_j2g_access_A_const_51 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[96]); A_arbace_j2g_access_A_const_52 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[97]); A_arbace_j2g_access_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[98]); A_arbace_j2g_access_A_const_54 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[99]); A_arbace_j2g_access_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[100]); A_arbace_j2g_access_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[101]); A_arbace_j2g_access_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[102]); A_arbace_j2g_access_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[103]); A_arbace_j2g_access_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[104]) }

func A_arbace_j2g_access_A_clinit_p5() { A_arbace_j2g_access_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[105]); A_arbace_j2g_access_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[106]); A_arbace_j2g_access_A_const_62 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[107]); A_arbace_j2g_access_A_const_63 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[108]) }

func A_arbace_j2g_access_A_New() *A_arbace_j2g_access_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_A) Ctor() {}

func (t *A_arbace_j2g_access_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_A_class }

func (t *A_arbace_j2g_access_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_A); return ok }

func A_arbace_j2g_access_A_Cast(x any) *A_arbace_j2g_access_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_A_class)) }; return v }



type A_arbace_j2g_access_accessor_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_accessor_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000004_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000004_A_New() *A_arbace_j2g_access_eval978000004_A { t := &A_arbace_j2g_access_eval978000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000004_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000004_A_class }

func (t *A_arbace_j2g_access_eval978000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000004_A); return ok }

func A_arbace_j2g_access_eval978000004_A_Cast(x any) *A_arbace_j2g_access_eval978000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000004_A_class)) }; return v }



type A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000008_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000008_A_New() *A_arbace_j2g_access_eval978000008_A { t := &A_arbace_j2g_access_eval978000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000008_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000008_A_class }

func (t *A_arbace_j2g_access_eval978000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000008_A); return ok }

func A_arbace_j2g_access_eval978000008_A_Cast(x any) *A_arbace_j2g_access_eval978000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000008_A_class)) }; return v }



type A_arbace_j2g_access_eval978000008_fn__978000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000008_fn__978000009_A_fn_class *jrt.Class



type A_arbace_j2g_access_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_unaccess_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000020_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000020_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000030_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000030_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000040_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000040_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000050_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000050_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000024_A struct{ j2g_header uint64; F_declared_in any }

var A_arbace_j2g_access_unaccess_fn__978000024_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000034_A struct{ j2g_header uint64; F_declared_in any }

var A_arbace_j2g_access_unaccess_fn__978000034_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000044_A struct{ j2g_header uint64; F_declared_in any }

var A_arbace_j2g_access_unaccess_fn__978000044_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000054_A struct{ j2g_header uint64; F_declared_in any }

var A_arbace_j2g_access_unaccess_fn__978000054_A_fn_class *jrt.Class
