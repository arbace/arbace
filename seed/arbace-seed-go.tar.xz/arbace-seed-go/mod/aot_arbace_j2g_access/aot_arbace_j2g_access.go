//line aot_arbace_j2g_access.ae:1
package aot_arbace_j2g_access

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_New() *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_access_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_access_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_access_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_access_A_const_1, A_arbace_j2g_access_A_const_2, A_arbace_j2g_access_A_const_3, A_arbace_j2g_access_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_access_eval978000008_fn__978000009_A_New() *A_arbace_j2g_access_eval978000008_fn__978000009_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_eval978000008_fn__978000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_access_eval978000008_fn__978000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_access_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_access_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_access_A_const_10.GetRawRoot__O(), A_arbace_j2g_access_A_const_11) }











func A_arbace_j2g_access_accessor_A_New() *A_arbace_j2g_access_accessor_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_accessor_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Ctor() {}
//line :13:1
func (t *A_arbace_j2g_access_accessor_A) Invoke_O_O_O__O(self, o__0, mname__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any; var root_22 any = A_arbace_j2g_access_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = mname__1; if linked_23 == nil { and__1927000168__auto____3 = ifn_24.Invoke_O__O(arg_25) } else { and__1927000168__auto____3 = linked_23.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_26 any = A_arbace_j2g_access_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = mname__1; var arg_30 any = Lit_1; if linked_27 == nil { and__1927000168__auto____4 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { and__1927000168__auto____4 = linked_27.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_31 any = A_arbace_j2g_access_A_const_14.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = o__0; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_31, arg_34) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *lang.Keyword = A_arbace_j2g_access_A_const_15; var tmp3 any; var root_35 any = A_arbace_j2g_access_A_const_8.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_j2g_access_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = o__0; if linked_40 == nil { arg_38 = ifn_41.Invoke_O__O(arg_42) } else { arg_38 = linked_40.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_state_A).Invoke_O_O__O(root_39, arg_42) }; if linked_36 == nil { tmp3 = ifn_37.Invoke_O__O(arg_38) } else { tmp3 = linked_36.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_35, arg_38) }; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(tmp3), mname__1) } else {
//line :17:1
			return nil
		}
}
func A_arbace_j2g_access_find_field_A_New() *A_arbace_j2g_access_find_field_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_find_field_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Ctor() {}
//line :20:1
func (t *A_arbace_j2g_access_find_field_A) Invoke_O_O_O__O(self, owner__0, fname__1 any) any { var or__1927000174__auto____3 any; var root_43 any = A_arbace_j2g_access_A_const_17.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_classes_env.A_arbace_classes_env_find_field_A_fn_class); var ifn_45 lang.IFn; if
												linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = owner__0; var arg_47 any = fname__1; if linked_44 == nil { or__1927000174__auto____3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { or__1927000174__auto____3 = linked_44.(*aot_arbace_classes_env.A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_48 any = A_arbace_j2g_access_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_50 lang.IFn
													if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, owner__0, nil, fname__1)).Ref(); var arg_52 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_49 == nil { tmp1 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp1 = linked_49.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :21:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }


func A_arbace_j2g_access_unaccess_A_New() *A_arbace_j2g_access_unaccess_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Ctor() {}
//line :24:1
func (t *A_arbace_j2g_access_unaccess_A) Invoke_O_O__O(self, node__0 any) any { var temp__1927000408__auto____2 any; var tmp1 any = A_arbace_j2g_access_A_const_19; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_access_A_const_20.Invoke_O__O(node__0)); if and__1927000168__auto____2 {


	var tmp2 any = A_arbace_j2g_access_A_const_21; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_access_A_const_22.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var root_53 any = A_arbace_j2g_access_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_j2g_access_accessor_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(node__0); var arg_57 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(node__0); if linked_54 == nil { temp__1927000408__auto____2 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { temp__1927000408__auto____2 = linked_54.(*A_arbace_j2g_access_accessor_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var acc__3 any = temp__1927000408__auto____2; var args__4 any = A_arbace_j2g_access_A_const_26.Invoke_O__O(node__0); var G__978000015__5_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)

		switch lang.Util_Hash_O__I_NoInit(G__978000015__5_) >> 4 & 15 { case 0: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_28) { var f__6 any; var root_59 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, A_arbace_j2g_access_find_field_A_fn_class); var ifn_61 lang.IFn





			if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_63 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_60 == nil { f__6 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { f__6 = linked_60.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }
//line :29:1
			var tmp3 any = A_arbace_j2g_access_A_const_20; var tmp4 any = A_arbace_j2g_access_A_const_30; var tmp5 any = A_arbace_j2g_access_A_const_31; var tmp6 any = A_arbace_j2g_access_A_const_24; var tmp7 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6); var tmp8 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, f__6, tmp6, tmp7, tmp8, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6))) }; case 4: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_34) { var tmp9 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7 any; var root_64 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_66 lang.IFn











				if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__70 any = A_arbace_j2g_access_unaccess_fn__978000019_A_New_O(acc__3); var tmp10 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__70); A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class = fncls__69d; tmp10 = fncls__69d } else { tmp10 = fncls__69 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp10, nil); var arg_68 any; var tmp11 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp12 any; var root_71 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_73 lang.IFn
				if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_72 == nil { tmp12 = ifn_73.Invoke_O__O(arg_74) } else { tmp12 = linked_72.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_71, arg_74) }; arg_68 = tmp11.Invoke_O__O(tmp12)
//line :41:1
				if linked_65 == nil { m__7 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { m__7 = linked_65.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }
//line :29:1
				var m__8 any; var root_75 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_77 lang.IFn













				if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any; var or__1927000174__auto____8 any = m__7; if jrt.J2g_Truth(or__1927000174__auto____8) { arg_78 = or__1927000174__auto____8 } else { var tmp13 any = A_arbace_j2g_access_A_const_25; var tmp14 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp15 any = A_arbace_j2g_access_A_const_33; arg_78 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_79 any = A_arbace_j2g_access_A_const_24; var arg_80 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_76 == nil { m__8 = ifn_77.Invoke_O_O_O__O(arg_78, arg_79, arg_80) } else { m__8 = linked_76.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_75, arg_78, arg_79, arg_80) }
//line :29:1
				var vec__978000016__9 any; var root_81 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_83 lang.IFn














				if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_82 == nil { vec__978000016__9 = ifn_83.Invoke_O__O(arg_84) } else { vec__978000016__9 = linked_82.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_81, arg_84) }
//line :29:1
				var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000016__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000016__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp16 any = A_arbace_j2g_access_A_const_20; var tmp17 any = A_arbace_j2g_access_A_const_19; var tmp18 any = A_arbace_j2g_access_A_const_22; var tmp19 *lang.Keyword; var G__978000021__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10
















			L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000021__12_) >> 10 & 3 { case 0: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_42) { tmp19 = A_arbace_j2g_access_A_const_43; break L2 }; case 1: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_44) { tmp19 = A_arbace_j2g_access_A_const_45; break L2 }; case 2: if any(G__978000021__12_) == any(A_arbace_j2g_access_A_const_34) { tmp19 = A_arbace_j2g_access_A_const_21; break L2 }; default:}; tmp19 = A_arbace_j2g_access_A_const_46}
//line :29:1
				var tmp20 any = tmp19.Ref(); var tmp21 any = A_arbace_j2g_access_A_const_24; var tmp22 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp23 any = A_arbace_j2g_access_A_const_47; var tmp24 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp25 any = A_arbace_j2g_access_A_const_25; var tmp26 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp27 any = A_arbace_j2g_access_A_const_33; var tmp28 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp29 any = A_arbace_j2g_access_A_const_48; var tmp30 any



















				if static_QMARK___6 { tmp30 = nil } else { var root_86 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = args__4; if linked_87 == nil { tmp30 = ifn_88.Invoke_O__O(arg_89) } else { tmp30 = linked_87.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_86, arg_89) } }
//line :29:1
				var tmp31 any = tmp30; var tmp32 any = A_arbace_j2g_access_A_const_26; var tmp33 any; var root_90 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_92 lang.IFn



















				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; if static_QMARK___6 { arg_93 = args__4 } else { var root_94 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = args__4; if linked_95 == nil { arg_93 = ifn_96.Invoke_O__O(arg_97) } else { arg_93 = linked_95.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_94, arg_97) } }; if linked_91 == nil { tmp33 = ifn_92.Invoke_O__O(arg_93) } else { tmp33 = linked_91.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_90, arg_93) }
//line :29:1
				var tmp34 any = tmp33; var tmp35 any = A_arbace_j2g_access_A_const_32; var tmp36 any = A_arbace_j2g_access_A_const_52; var tmp37 any = A_arbace_j2g_access_A_const_53; var tmp38 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp31, tmp32, tmp34, tmp35, r__11, tmp36, m__8, tmp37, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp38, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 6: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_54) { var f__6_2 any; var root_98 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, A_arbace_j2g_access_find_field_A_fn_class); var ifn_100 lang.IFn







					if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_102 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_99 == nil { f__6_2 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { f__6_2 = linked_99.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }
//line :29:1
					var tmp39 any = A_arbace_j2g_access_A_const_20; var tmp40 any = A_arbace_j2g_access_A_const_55; var tmp41 any = A_arbace_j2g_access_A_const_31; var tmp42 any = A_arbace_j2g_access_A_const_24; var tmp43 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_2); var tmp44 any = A_arbace_j2g_access_A_const_56; var tmp45 any; var root_103 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn








					if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = args__4; if linked_104 == nil { tmp45 = ifn_105.Invoke_O__O(arg_106) } else { tmp45 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) }
//line :29:1
					var tmp46 any = tmp45; var tmp47 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp39, tmp40, tmp41, f__6_2, tmp42, tmp43, tmp44, tmp46, tmp47, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_2))) }; case 8: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_57) { var tmp48 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp48, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_2 any; var root_107 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_109 lang.IFn











						if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var fnbody__113 any = A_arbace_j2g_access_unaccess_fn__978000025_A_New_O(acc__3); var tmp49 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__113); A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class = fncls__112d; tmp49 = fncls__112d } else { tmp49 = fncls__112 }; arg_110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__113, tmp49, nil); var arg_111 any; var tmp50 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp51 any; var root_114 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_116 lang.IFn
						if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_115 == nil { tmp51 = ifn_116.Invoke_O__O(arg_117) } else { tmp51 = linked_115.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_114, arg_117) }; arg_111 = tmp50.Invoke_O__O(tmp51)
//line :41:1
						if linked_108 == nil { m__7_2 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { m__7_2 = linked_108.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }
//line :29:1
						var m__8_2 any; var root_118 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_120 lang.IFn













						if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any; var or__1927000174__auto____8_2 any = m__7_2; if jrt.J2g_Truth(or__1927000174__auto____8_2) { arg_121 = or__1927000174__auto____8_2 } else { var tmp52 any = A_arbace_j2g_access_A_const_25; var tmp53 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp54 any = A_arbace_j2g_access_A_const_33; arg_121 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp53, tmp54, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_122 any = A_arbace_j2g_access_A_const_24; var arg_123 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_119 == nil { m__8_2 = ifn_120.Invoke_O_O_O__O(arg_121, arg_122, arg_123) } else { m__8_2 = linked_119.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_118, arg_121, arg_122, arg_123) }
//line :29:1
						var vec__978000022__9 any; var root_124 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_126 lang.IFn














						if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_125 == nil { vec__978000022__9 = ifn_126.Invoke_O__O(arg_127) } else { vec__978000022__9 = linked_125.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_124, arg_127) }
//line :29:1
						var ___10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000022__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000022__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp55 any = A_arbace_j2g_access_A_const_20; var tmp56 any = A_arbace_j2g_access_A_const_19; var tmp57 any = A_arbace_j2g_access_A_const_22; var tmp58 *lang.Keyword; var G__978000027__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_2
















					L3: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000027__12_) >> 10 & 3 { case 0: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_42) { tmp58 = A_arbace_j2g_access_A_const_43; break L3 }; case 1: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_44) { tmp58 = A_arbace_j2g_access_A_const_45; break L3 }; case 2: if any(G__978000027__12_) == any(A_arbace_j2g_access_A_const_34) { tmp58 = A_arbace_j2g_access_A_const_21; break L3 }; default:}; tmp58 = A_arbace_j2g_access_A_const_46}
//line :29:1
						var tmp59 any = tmp58.Ref(); var tmp60 any = A_arbace_j2g_access_A_const_24; var tmp61 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp62 any = A_arbace_j2g_access_A_const_47; var tmp63 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp64 any = A_arbace_j2g_access_A_const_25; var tmp65 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp66 any = A_arbace_j2g_access_A_const_33; var tmp67 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp68 any = A_arbace_j2g_access_A_const_48; var tmp69 any



















						if static_QMARK___6_2 { tmp69 = nil } else { var root_129 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = args__4; if linked_130 == nil { tmp69 = ifn_131.Invoke_O__O(arg_132) } else { tmp69 = linked_130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_129, arg_132) } }
//line :29:1
						var tmp70 any = tmp69; var tmp71 any = A_arbace_j2g_access_A_const_26; var tmp72 any; var root_133 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_135 lang.IFn



















						if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; if static_QMARK___6_2 { arg_136 = args__4 } else { var root_137 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = args__4; if linked_138 == nil { arg_136 = ifn_139.Invoke_O__O(arg_140) } else { arg_136 = linked_138.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_137, arg_140) } }; if linked_134 == nil { tmp72 = ifn_135.Invoke_O__O(arg_136) } else { tmp72 = linked_134.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_133, arg_136) }
//line :29:1
						var tmp73 any = tmp72; var tmp74 any = A_arbace_j2g_access_A_const_32; var tmp75 any = A_arbace_j2g_access_A_const_52; var tmp76 any = A_arbace_j2g_access_A_const_53; var tmp77 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp56, tmp57, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65, tmp66, tmp67, tmp68, tmp70, tmp71, tmp73, tmp74, r__11_2, tmp75, m__8_2, tmp76, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp77, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 10: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_58) { var f__6_3 any; var root_141 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_j2g_access_find_field_A_fn_class); var ifn_143 lang.IFn
							if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_145 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_142 == nil { f__6_3 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { f__6_3 = linked_142.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }
//line :29:1
							var tmp78 any = A_arbace_j2g_access_A_const_20; var tmp79 any = A_arbace_j2g_access_A_const_59; var tmp80 any = A_arbace_j2g_access_A_const_31; var tmp81 any = A_arbace_j2g_access_A_const_24; var tmp82 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_3); var tmp83 any = A_arbace_j2g_access_A_const_48; var tmp84 any; var root_146 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_148 lang.IFn

							if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = args__4; if linked_147 == nil { tmp84 = ifn_148.Invoke_O__O(arg_149) } else { tmp84 = linked_147.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_146, arg_149) }
//line :29:1
							var tmp85 any = tmp84; var tmp86 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp78, tmp79, tmp80, f__6_3, tmp81, tmp82, tmp83, tmp85, tmp86, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_3))) }; case 11: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_60) { var f__6_4 any; var root_150 any = A_arbace_j2g_access_A_const_29.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_j2g_access_find_field_A_fn_class); var ifn_152 lang.IFn


								if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var arg_154 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); if linked_151 == nil { f__6_4 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { f__6_4 = linked_151.(*A_arbace_j2g_access_find_field_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }
//line :29:1
								var tmp87 any = A_arbace_j2g_access_A_const_20; var tmp88 any = A_arbace_j2g_access_A_const_61; var tmp89 any = A_arbace_j2g_access_A_const_31; var tmp90 any = A_arbace_j2g_access_A_const_24; var tmp91 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(f__6_4); var tmp92 any = A_arbace_j2g_access_A_const_48; var tmp93 any; var root_155 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_157 lang.IFn



								if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = args__4; if linked_156 == nil { tmp93 = ifn_157.Invoke_O__O(arg_158) } else { tmp93 = linked_156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_155, arg_158) }
//line :29:1
								var tmp94 any = tmp93; var tmp95 any = A_arbace_j2g_access_A_const_56; var tmp96 any; var root_159 any = A_arbace_j2g_access_A_const_62.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_161 lang.IFn



								if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = args__4; if linked_160 == nil { tmp96 = ifn_161.Invoke_O__O(arg_162) } else { tmp96 = linked_160.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_159, arg_162) }
//line :29:1
								var tmp97 any = tmp96; var tmp98 any = A_arbace_j2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp87, tmp88, tmp89, f__6_4, tmp90, tmp91, tmp92, tmp94, tmp95, tmp97, tmp98, A_arbace_j2g_access_A_const_33.Invoke_O__O(f__6_4))) }; case 12: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_44) { var tmp99 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp99, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_3 any; var root_163 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_165 lang.IFn











									if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var fnbody__169 any = A_arbace_j2g_access_unaccess_fn__978000031_A_New_O(acc__3); var tmp100 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__169); A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class = fncls__168d; tmp100 = fncls__168d } else { tmp100 = fncls__168 }; arg_166 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__169, tmp100, nil); var arg_167 any; var tmp101 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp102 any; var root_170 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_172 lang.IFn
									if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_171 == nil { tmp102 = ifn_172.Invoke_O__O(arg_173) } else { tmp102 = linked_171.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_170, arg_173) }; arg_167 = tmp101.Invoke_O__O(tmp102)
//line :41:1
									if linked_164 == nil { m__7_3 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { m__7_3 = linked_164.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }
//line :29:1
									var m__8_3 any; var root_174 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_176 lang.IFn













									if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var or__1927000174__auto____8_3 any = m__7_3; if jrt.J2g_Truth(or__1927000174__auto____8_3) { arg_177 = or__1927000174__auto____8_3 } else { var tmp103 any = A_arbace_j2g_access_A_const_25; var tmp104 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp105 any = A_arbace_j2g_access_A_const_33; arg_177 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp103, tmp104, tmp105, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_178 any = A_arbace_j2g_access_A_const_24; var arg_179 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_175 == nil { m__8_3 = ifn_176.Invoke_O_O_O__O(arg_177, arg_178, arg_179) } else { m__8_3 = linked_175.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_174, arg_177, arg_178, arg_179) }
//line :29:1
									var vec__978000028__9 any; var root_180 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_182 lang.IFn














									if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_181 == nil { vec__978000028__9 = ifn_182.Invoke_O__O(arg_183) } else { vec__978000028__9 = linked_181.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_180, arg_183) }
//line :29:1
									var ___10_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000028__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000028__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp106 any = A_arbace_j2g_access_A_const_20; var tmp107 any = A_arbace_j2g_access_A_const_19; var tmp108 any = A_arbace_j2g_access_A_const_22; var tmp109 *lang.Keyword; var G__978000033__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_3
















								L4: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000033__12_) >> 10 & 3 { case 0: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_42) { tmp109 = A_arbace_j2g_access_A_const_43; break L4 }; case 1: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_44) { tmp109 = A_arbace_j2g_access_A_const_45; break L4 }; case 2: if any(G__978000033__12_) == any(A_arbace_j2g_access_A_const_34) { tmp109 = A_arbace_j2g_access_A_const_21; break L4 }; default:}; tmp109 = A_arbace_j2g_access_A_const_46}
//line :29:1
									var tmp110 any = tmp109.Ref(); var tmp111 any = A_arbace_j2g_access_A_const_24; var tmp112 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp113 any = A_arbace_j2g_access_A_const_47; var tmp114 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp115 any = A_arbace_j2g_access_A_const_25; var tmp116 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp117 any = A_arbace_j2g_access_A_const_33; var tmp118 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp119 any = A_arbace_j2g_access_A_const_48; var tmp120 any



















									if static_QMARK___6_3 { tmp120 = nil } else { var root_185 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = args__4; if linked_186 == nil { tmp120 = ifn_187.Invoke_O__O(arg_188) } else { tmp120 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) } }
//line :29:1
									var tmp121 any = tmp120; var tmp122 any = A_arbace_j2g_access_A_const_26; var tmp123 any; var root_189 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_191 lang.IFn



















									if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any; if static_QMARK___6_3 { arg_192 = args__4 } else { var root_193 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = args__4; if linked_194 == nil { arg_192 = ifn_195.Invoke_O__O(arg_196) } else { arg_192 = linked_194.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_193, arg_196) } }; if linked_190 == nil { tmp123 = ifn_191.Invoke_O__O(arg_192) } else { tmp123 = linked_190.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_189, arg_192) }
//line :29:1
									var tmp124 any = tmp123; var tmp125 any = A_arbace_j2g_access_A_const_32; var tmp126 any = A_arbace_j2g_access_A_const_52; var tmp127 any = A_arbace_j2g_access_A_const_53; var tmp128 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp107, tmp108, tmp110, tmp111, tmp112, tmp113, tmp114, tmp115, tmp116, tmp117, tmp118, tmp119, tmp121, tmp122, tmp124, tmp125, r__11_3, tmp126, m__8_3, tmp127, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp128, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; case 14: if any(G__978000015__5_) == any(A_arbace_j2g_access_A_const_42) { var tmp129 any = A_arbace_j2g_access_A_const_34; var static_QMARK___6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp129, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3)); var m__7_4 any; var root_197 any = A_arbace_j2g_access_A_const_35.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_199 lang.IFn











										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var fnbody__203 any = A_arbace_j2g_access_unaccess_fn__978000037_A_New_O(acc__3); var tmp130 *jrt.Class; var fncls__202 *jrt.Class = A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class; if fncls__202 == nil { var fncls__202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__203); A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class = fncls__202d; tmp130 = fncls__202d } else { tmp130 = fncls__202 }; arg_200 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__203, tmp130, nil); var arg_201 any; var tmp131 *lang.Keyword = A_arbace_j2g_access_A_const_36; var tmp132 any; var root_204 any = A_arbace_j2g_access_A_const_37.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_206 lang.IFn
										if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_205 == nil { tmp132 = ifn_206.Invoke_O__O(arg_207) } else { tmp132 = linked_205.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_204, arg_207) }; arg_201 = tmp131.Invoke_O__O(tmp132)
//line :41:1
										if linked_198 == nil { m__7_4 = ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { m__7_4 = linked_198.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }
//line :29:1
										var m__8_4 any; var root_208 any = A_arbace_j2g_access_A_const_38.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_210 lang.IFn













										if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var or__1927000174__auto____8_4 any = m__7_4; if jrt.J2g_Truth(or__1927000174__auto____8_4) { arg_211 = or__1927000174__auto____8_4 } else { var tmp133 any = A_arbace_j2g_access_A_const_25; var tmp134 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp135 any = A_arbace_j2g_access_A_const_33; arg_211 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp133, tmp134, tmp135, A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3), A_arbace_j2g_access_A_const_39, A_arbace_j2g_access_A_const_40)) }; var arg_212 any = A_arbace_j2g_access_A_const_24; var arg_213 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); if linked_209 == nil { m__8_4 = ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { m__8_4 = linked_209.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) }
//line :29:1
										var vec__978000034__9 any; var root_214 any = A_arbace_j2g_access_A_const_41.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_216 lang.IFn














										if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); if linked_215 == nil { vec__978000034__9 = ifn_216.Invoke_O__O(arg_217) } else { vec__978000034__9 = linked_215.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_214, arg_217) }
//line :29:1
										var ___10_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000034__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__978000034__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp136 any = A_arbace_j2g_access_A_const_20; var tmp137 any = A_arbace_j2g_access_A_const_19; var tmp138 any = A_arbace_j2g_access_A_const_22; var tmp139 *lang.Keyword; var G__978000039__12_ any = A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3); _ = ___10_4
















									L5: switch { default: switch lang.Util_Hash_O__I_NoInit(G__978000039__12_) >> 10 & 3 { case 0: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_42) { tmp139 = A_arbace_j2g_access_A_const_43; break L5 }; case 1: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_44) { tmp139 = A_arbace_j2g_access_A_const_45; break L5 }; case 2: if any(G__978000039__12_) == any(A_arbace_j2g_access_A_const_34) { tmp139 = A_arbace_j2g_access_A_const_21; break L5 }; default:}; tmp139 = A_arbace_j2g_access_A_const_46}
//line :29:1
										var tmp140 any = tmp139.Ref(); var tmp141 any = A_arbace_j2g_access_A_const_24; var tmp142 any = A_arbace_j2g_access_A_const_24.Invoke_O__O(acc__3); var tmp143 any = A_arbace_j2g_access_A_const_47; var tmp144 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_j2g_access_A_const_47.Invoke_O__O(acc__3))).Ref(); var tmp145 any = A_arbace_j2g_access_A_const_25; var tmp146 any = A_arbace_j2g_access_A_const_25.Invoke_O__O(acc__3); var tmp147 any = A_arbace_j2g_access_A_const_33; var tmp148 any = A_arbace_j2g_access_A_const_33.Invoke_O__O(acc__3); var tmp149 any = A_arbace_j2g_access_A_const_48; var tmp150 any



















										if static_QMARK___6_4 { tmp150 = nil } else { var root_219 any = A_arbace_j2g_access_A_const_49.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = args__4; if linked_220 == nil { tmp150 = ifn_221.Invoke_O__O(arg_222) } else { tmp150 = linked_220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_219, arg_222) } }
//line :29:1
										var tmp151 any = tmp150; var tmp152 any = A_arbace_j2g_access_A_const_26; var tmp153 any; var root_223 any = A_arbace_j2g_access_A_const_50.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_225 lang.IFn



















										if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; if static_QMARK___6_4 { arg_226 = args__4 } else { var root_227 any = A_arbace_j2g_access_A_const_51.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = args__4; if linked_228 == nil { arg_226 = ifn_229.Invoke_O__O(arg_230) } else { arg_226 = linked_228.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_227, arg_230) } }; if linked_224 == nil { tmp153 = ifn_225.Invoke_O__O(arg_226) } else { tmp153 = linked_224.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_223, arg_226) }
//line :29:1
										var tmp154 any = tmp153; var tmp155 any = A_arbace_j2g_access_A_const_32; var tmp156 any = A_arbace_j2g_access_A_const_52; var tmp157 any = A_arbace_j2g_access_A_const_53; var tmp158 any = A_arbace_j2g_access_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp136, tmp137, tmp138, tmp140, tmp141, tmp142, tmp143, tmp144, tmp145, tmp146, tmp147, tmp148, tmp149, tmp151, tmp152, tmp154, tmp155, r__11_4, tmp156, m__8_4, tmp157, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp158, A_arbace_j2g_access_A_const_27.Invoke_O__O(acc__3))).Ref())) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__978000015__5_))))) } else {
//line :27:1
											return node__0 } }













func A_arbace_j2g_access_unaccess_fn__978000019_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000019_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000019_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000019_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000019_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000025_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000025_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000025_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000025_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000025_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000031_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000031_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000031_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000031_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000031_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_j2g_access_unaccess_fn__978000037_A_New_O(p0 any) *A_arbace_j2g_access_unaccess_fn__978000037_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_unaccess_fn__978000037_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000037_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_j2g_access_unaccess_fn__978000037_A) Invoke_O_O__O(self, p1__978000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_25.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_25.Invoke_O__O(p1__978000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_access_A_const_33.Invoke_O__O(t.F_acc), A_arbace_j2g_access_A_const_33.Invoke_O__O(p1__978000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__978000014_SHARP___1 } else { return nil } }

























type A_arbace_j2g_access_A struct{ jrt.Object }

var A_arbace_j2g_access_A_const_pool *jrt.RefArray

var A_arbace_j2g_access_A_const_0 *lang.Var

var A_arbace_j2g_access_A_const_1 any

var A_arbace_j2g_access_A_const_2 any

var A_arbace_j2g_access_A_const_3 any

var A_arbace_j2g_access_A_const_4 any

var A_arbace_j2g_access_A_const_5 *lang.Var

var A_arbace_j2g_access_A_const_6 any

var A_arbace_j2g_access_A_const_7 *lang.Var

var A_arbace_j2g_access_A_const_8 *lang.Var

var A_arbace_j2g_access_A_const_9 *lang.Var

var A_arbace_j2g_access_A_const_10 *lang.Var

var A_arbace_j2g_access_A_const_11 any

var A_arbace_j2g_access_A_const_12 *lang.Var

var A_arbace_j2g_access_A_const_13 *lang.Var

var A_arbace_j2g_access_A_const_14 *lang.Var

var A_arbace_j2g_access_A_const_15 *lang.Keyword

var A_arbace_j2g_access_A_const_16 *lang.Var

var A_arbace_j2g_access_A_const_17 *lang.Var

var A_arbace_j2g_access_A_const_18 *lang.Var

var A_arbace_j2g_access_A_const_19 *lang.Keyword

var A_arbace_j2g_access_A_const_20 *lang.Keyword

var A_arbace_j2g_access_A_const_21 *lang.Keyword

var A_arbace_j2g_access_A_const_22 *lang.Keyword

var A_arbace_j2g_access_A_const_23 *lang.Var

var A_arbace_j2g_access_A_const_24 *lang.Keyword

var A_arbace_j2g_access_A_const_25 *lang.Keyword

var A_arbace_j2g_access_A_const_26 *lang.Keyword

var A_arbace_j2g_access_A_const_27 *lang.Keyword

var A_arbace_j2g_access_A_const_28 *lang.Keyword

var A_arbace_j2g_access_A_const_29 *lang.Var

var A_arbace_j2g_access_A_const_30 *lang.Keyword

var A_arbace_j2g_access_A_const_31 *lang.Keyword

var A_arbace_j2g_access_A_const_32 *lang.Keyword

var A_arbace_j2g_access_A_const_33 *lang.Keyword

var A_arbace_j2g_access_A_const_34 *lang.Keyword

var A_arbace_j2g_access_A_const_35 *lang.Var

var A_arbace_j2g_access_A_const_36 *lang.Keyword

var A_arbace_j2g_access_A_const_37 *lang.Var

var A_arbace_j2g_access_A_const_38 *lang.Var

var A_arbace_j2g_access_A_const_39 *lang.Keyword

var A_arbace_j2g_access_A_const_40 any

var A_arbace_j2g_access_A_const_41 *lang.Var

var A_arbace_j2g_access_A_const_42 *lang.Keyword

var A_arbace_j2g_access_A_const_43 *lang.Keyword

var A_arbace_j2g_access_A_const_44 *lang.Keyword

var A_arbace_j2g_access_A_const_45 *lang.Keyword

var A_arbace_j2g_access_A_const_46 *lang.Keyword

var A_arbace_j2g_access_A_const_47 *lang.Keyword

var A_arbace_j2g_access_A_const_48 *lang.Keyword

var A_arbace_j2g_access_A_const_49 *lang.Var

var A_arbace_j2g_access_A_const_50 *lang.Var

var A_arbace_j2g_access_A_const_51 *lang.Var

var A_arbace_j2g_access_A_const_52 *lang.Keyword

var A_arbace_j2g_access_A_const_53 *lang.Keyword

var A_arbace_j2g_access_A_const_54 *lang.Keyword

var A_arbace_j2g_access_A_const_55 *lang.Keyword

var A_arbace_j2g_access_A_const_56 *lang.Keyword

var A_arbace_j2g_access_A_const_57 *lang.Keyword

var A_arbace_j2g_access_A_const_58 *lang.Keyword

var A_arbace_j2g_access_A_const_59 *lang.Keyword

var A_arbace_j2g_access_A_const_60 *lang.Keyword

var A_arbace_j2g_access_A_const_61 *lang.Keyword

var A_arbace_j2g_access_A_const_62 *lang.Var

var A_arbace_j2g_access_A_init jrt.ClassInit

func A_arbace_j2g_access_A_Init() { if !A_arbace_j2g_access_A_init.Done() { A_arbace_j2g_access_A_init.Run(A_arbace_j2g_access_A_clinit) } }

func A_arbace_j2g_access_A_clinit() { A_arbace_j2g_access_A_clinit_p0(); A_arbace_j2g_access_A_clinit_p1(); A_arbace_j2g_access_A_clinit_p2(); A_arbace_j2g_access_A_clinit_p3(); A_arbace_j2g_access_A_clinit_p4(); A_arbace_j2g_access_A_clinit_p5() }

func A_arbace_j2g_access_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_access_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 108); A_arbace_j2g_access_A_const_0 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[45]); A_arbace_j2g_access_A_const_1 = A_arbace_j2g_access_A_const_pool.A[46]; A_arbace_j2g_access_A_const_2 = A_arbace_j2g_access_A_const_pool.A[47]; A_arbace_j2g_access_A_const_3 = A_arbace_j2g_access_A_const_pool.A[48]; A_arbace_j2g_access_A_const_4 = A_arbace_j2g_access_A_const_pool.A[49]; A_arbace_j2g_access_A_const_5 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[50]); A_arbace_j2g_access_A_const_6 = A_arbace_j2g_access_A_const_pool.A[51]; A_arbace_j2g_access_A_const_7 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[52]); A_arbace_j2g_access_A_const_8 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[53]); A_arbace_j2g_access_A_const_9 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[54]); A_arbace_j2g_access_A_const_10 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[55]); A_arbace_j2g_access_A_const_11 = A_arbace_j2g_access_A_const_pool.A[56] }

func A_arbace_j2g_access_A_clinit_p1() { A_arbace_j2g_access_A_const_12 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[57]); A_arbace_j2g_access_A_const_13 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[58]); A_arbace_j2g_access_A_const_14 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[59]); A_arbace_j2g_access_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[60]); A_arbace_j2g_access_A_const_16 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[61]); A_arbace_j2g_access_A_const_17 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[62]); A_arbace_j2g_access_A_const_18 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[63]); A_arbace_j2g_access_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[64]); A_arbace_j2g_access_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[65]); A_arbace_j2g_access_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[66]); A_arbace_j2g_access_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[67]); A_arbace_j2g_access_A_const_23 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[68]) }

func A_arbace_j2g_access_A_clinit_p2() { A_arbace_j2g_access_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[69]); A_arbace_j2g_access_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[70]); A_arbace_j2g_access_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[71]); A_arbace_j2g_access_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[72]); A_arbace_j2g_access_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[73]); A_arbace_j2g_access_A_const_29 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[74]); A_arbace_j2g_access_A_const_30 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[75]); A_arbace_j2g_access_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[76]); A_arbace_j2g_access_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[77]); A_arbace_j2g_access_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[78]); A_arbace_j2g_access_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[79]); A_arbace_j2g_access_A_const_35 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[80]) }

func A_arbace_j2g_access_A_clinit_p3() { A_arbace_j2g_access_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[81]); A_arbace_j2g_access_A_const_37 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[82]); A_arbace_j2g_access_A_const_38 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[83]); A_arbace_j2g_access_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[84]); A_arbace_j2g_access_A_const_40 = A_arbace_j2g_access_A_const_pool.A[85]; A_arbace_j2g_access_A_const_41 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[86]); A_arbace_j2g_access_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[87]); A_arbace_j2g_access_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[88]); A_arbace_j2g_access_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[89]); A_arbace_j2g_access_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[90]); A_arbace_j2g_access_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[91]); A_arbace_j2g_access_A_const_47 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[92]) }

func A_arbace_j2g_access_A_clinit_p4() { A_arbace_j2g_access_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[93]); A_arbace_j2g_access_A_const_49 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[94]); A_arbace_j2g_access_A_const_50 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[95]); A_arbace_j2g_access_A_const_51 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[96]); A_arbace_j2g_access_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[97]); A_arbace_j2g_access_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[98]); A_arbace_j2g_access_A_const_54 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[99]); A_arbace_j2g_access_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[100]); A_arbace_j2g_access_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[101]); A_arbace_j2g_access_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[102]); A_arbace_j2g_access_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[103]); A_arbace_j2g_access_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[104]) }

func A_arbace_j2g_access_A_clinit_p5() { A_arbace_j2g_access_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[105]); A_arbace_j2g_access_A_const_61 = lang.Keyword_Cast(A_arbace_j2g_access_A_const_pool.A[106]); A_arbace_j2g_access_A_const_62 = lang.Var_Cast(A_arbace_j2g_access_A_const_pool.A[107]) }

func A_arbace_j2g_access_A_New() *A_arbace_j2g_access_A { A_arbace_j2g_access_A_Init(); t := &A_arbace_j2g_access_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_A) Ctor() {}

func (t *A_arbace_j2g_access_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_A_class }

func (t *A_arbace_j2g_access_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_A); return ok }

func A_arbace_j2g_access_A_Cast(x any) *A_arbace_j2g_access_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_A_class)) }; return v }



type A_arbace_j2g_access_accessor_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_accessor_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000004_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000004_A_New() *A_arbace_j2g_access_eval978000004_A { t := &A_arbace_j2g_access_eval978000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000004_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000004_A_class }

func (t *A_arbace_j2g_access_eval978000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000004_A); return ok }

func A_arbace_j2g_access_eval978000004_A_Cast(x any) *A_arbace_j2g_access_eval978000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000004_A_class)) }; return v }



type A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_fn_class *jrt.Class



type A_arbace_j2g_access_eval978000008_A struct{ jrt.Object }

func A_arbace_j2g_access_eval978000008_A_New() *A_arbace_j2g_access_eval978000008_A { t := &A_arbace_j2g_access_eval978000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_access_eval978000008_A) Ctor() {}

func (t *A_arbace_j2g_access_eval978000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_access_eval978000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_access_eval978000008_A_class }

func (t *A_arbace_j2g_access_eval978000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_access_eval978000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_access_eval978000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_access_eval978000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_access_eval978000008_A); return ok }

func A_arbace_j2g_access_eval978000008_A_Cast(x any) *A_arbace_j2g_access_eval978000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_access_eval978000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_access_eval978000008_A_class)) }; return v }



type A_arbace_j2g_access_eval978000008_fn__978000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_eval978000008_fn__978000009_A_fn_class *jrt.Class



type A_arbace_j2g_access_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_A struct{ j2g_header uint64 }

var A_arbace_j2g_access_unaccess_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000019_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000019_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000025_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000025_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000031_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000031_A_fn_class *jrt.Class



type A_arbace_j2g_access_unaccess_fn__978000037_A struct{ j2g_header uint64; F_acc any }

var A_arbace_j2g_access_unaccess_fn__978000037_A_fn_class *jrt.Class
