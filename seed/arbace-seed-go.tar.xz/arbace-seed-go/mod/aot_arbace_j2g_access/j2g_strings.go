//line j2g_strings.ae:1
package aot_arbace_j2g_access

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn11,arbace.corekn3,dockn9,accessorskn6,invokekn2,opkn6,statickn4,kindkn5,ownerkn4,namekn4,argskn4,insnkn9,getstatickn10,get-statickn5,fieldkn4,typekn4,desckn12,invokestatickn7,methodskn5,flagskn15,invokeinterfacekn9,interfacekn13,invokespecialkn7,specialkn7,virtualkn3,itfkn6,targetkn6,methodkn11,outer-superkn9,putstatickn10,set-statickn3,valkn13,invokevirtualkn8,getfieldkn9,get-fieldkn8,putfieldkn9,set-fieldv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn17,arbace.j2g.accessm2,R10,s537,javac's accessor methods (access$NNN, arbace.classes.analyze's accessorize and\n  outer-super-call): the analyzer turns a private member access across a nest into a call of a\n  synthetic static method, whose code it keeps as a bytecode-writing function and, as data, the\n  one member instruction it holds (the class state's :accessors). Go has no private members\n  across the classes of one package, so j2g undoes the indirection: it gives the access node\n  the accessor stands for (no class file is written: doc/STANDALONE-NOTES.md, S2).v11,arbace.core7,string?v13,arbace.string12,starts-with?v22,arbace.classes.analyze4,declR11,v22,arbace.classes.analyze5,statev18,arbace.classes.env10,find-fieldv11,arbace.core7,ex-infoR12,R13,R14,R15,v17,arbace.j2g.access8,accessorR16,R17,R18,R19,R20,v17,arbace.j2g.access10,find-fieldR21,R22,R23,R24,R25,v11,arbace.core4,someR26,v18,arbace.classes.env4,infov11,arbace.core5,assocR27,l0,v20,arbace.classes.types17,parse-method-descR28,R29,R30,R31,R32,R33,R34,v11,arbace.core5,firstv11,arbace.core3,vecv11,arbace.core4,restR35,R36,R37,R38,R39,R40,R41,R42,R43,R44,v11,arbace.core6,second")

var Lit_1 *jrt.String = jrt.Intern("access$")

var Lit_2 *jrt.String = jrt.Intern("j2g: accessor field not found ")

var Lit_3 *jrt.String = jrt.Intern(".")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.access$unaccess$fn__978000019")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.access$unaccess$fn__978000025")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.access$unaccess$fn__978000031")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.access$unaccess$fn__978000037")

var Lit_8 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_9 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,oyn5,mnamekn4,linekn6,columnkn4,filekn7,privateyn5,owneryn5,fnameyn4,nodev11,arbace.core5,in-nsMyn17,arbace.j2g.accessm2,R0,s537,javac's accessor methods (access$NNN, arbace.classes.analyze's accessorize and\n  outer-super-call): the analyzer turns a private member access across a nest into a call of a\n  synthetic static method, whose code it keeps as a bytecode-writing function and, as data, the\n  one member instruction it holds (the class state's :accessors). Go has no private members\n  across the classes of one package, so j2g undoes the indirection: it gives the access node\n  the accessor stands for (no class file is written: doc/STANDALONE-NOTES.md, S2).m2,R0,s537,javac's accessor methods (access$NNN, arbace.classes.analyze's accessorize and\n  outer-super-call): the analyzer turns a private member access across a nest into a call of a\n  synthetic static method, whose code it keeps as a bytecode-writing function and, as data, the\n  one member instruction it holds (the class state's :accessors). Go has no private members\n  across the classes of one package, so j2g undoes the indirection: it gives the access node\n  the accessor stands for (no class file is written: doc/STANDALONE-NOTES.md, S2).R1,v17,arbace.j2g.access8,accessorm10,R2,L1,V2,R3,R4,R0,s105,The member instruction of accessor method mname of class o, {:insn kw :owner :name :desc\n  :itf}, or nil.R5,i13,R6,i1,R7,s20,arbace/j2g/access.aev17,arbace.j2g.access10,find-fieldm10,R8,TR2,L1,V2,R9,R10,R5,i20,R6,i1,R7,s20,arbace/j2g/access.aev17,arbace.j2g.access8,unaccessm10,R2,L1,V1,R11,R0,s69,The access node an accessor call node stands for, or the node itself.R5,i24,R6,i1,R7,s20,arbace/j2g/access.ae")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.access$eval978000004$loading__1927001464__auto____978000005")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.access$eval978000008$fn__978000009")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.access$accessor")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.access$find_field")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.access$unaccess")
