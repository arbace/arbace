//line j2g_classes.ae:1
package aot_arbace_j2g_access

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_access_accessor_A_class, Name: "arbace.j2g.access$accessor", Modifiers: 25, Simple: "accessor", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_accessor_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_class, Name: "arbace.j2g.access$eval978000004$loading__1927001464__auto____978000005", Modifiers: 25, Simple: "loading__1927001464__auto____978000005", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_eval978000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_eval978000008_fn__978000009_A_class, Name: "arbace.j2g.access$eval978000008$fn__978000009", Modifiers: 25, Simple: "fn__978000009", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000008_fn__978000009_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_eval978000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_find_field_A_class, Name: "arbace.j2g.access$find_field", Modifiers: 25, Simple: "find_field", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_find_field_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_A_class, Name: "arbace.j2g.access$unaccess", Modifiers: 25, Simple: "unaccess", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000019_A_class, Name: "arbace.j2g.access$unaccess$fn__978000019", Modifiers: 25, Simple: "fn__978000019", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000019_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000025_A_class, Name: "arbace.j2g.access$unaccess$fn__978000025", Modifiers: 25, Simple: "fn__978000025", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000025_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000031_A_class, Name: "arbace.j2g.access$unaccess$fn__978000031", Modifiers: 25, Simple: "fn__978000031", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000031_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000037_A_class, Name: "arbace.j2g.access$unaccess$fn__978000037", Modifiers: 25, Simple: "fn__978000037", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000037_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_access_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_A_New()}; return nil }

var A_arbace_j2g_access_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_A_new}

var A_arbace_j2g_access_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_A"})

func init() { i := A_arbace_j2g_access_A_class.Info(); i.IsInstance = A_arbace_j2g_access_A_InstanceOf; i.Init = A_arbace_j2g_access_A_Init; i.Table = A_arbace_j2g_access_A_members }

var A_arbace_j2g_access_accessor_A_class *jrt.Class

func A_arbace_j2g_access_eval978000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_eval978000004_A_New()}; return nil }

var A_arbace_j2g_access_eval978000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_eval978000004_A_new}

var A_arbace_j2g_access_eval978000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access$eval978000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_access_A_class, Simple: "eval978000004", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000004_A"})

func init() { i := A_arbace_j2g_access_eval978000004_A_class.Info(); i.IsInstance = A_arbace_j2g_access_eval978000004_A_InstanceOf; i.Table = A_arbace_j2g_access_eval978000004_A_members }

var A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_class *jrt.Class

func A_arbace_j2g_access_eval978000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_eval978000008_A_New()}; return nil }

var A_arbace_j2g_access_eval978000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_eval978000008_A_new}

var A_arbace_j2g_access_eval978000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access$eval978000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_access_A_class, Simple: "eval978000008", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000008_A"})

func init() { i := A_arbace_j2g_access_eval978000008_A_class.Info(); i.IsInstance = A_arbace_j2g_access_eval978000008_A_InstanceOf; i.Table = A_arbace_j2g_access_eval978000008_A_members }

var A_arbace_j2g_access_eval978000008_fn__978000009_A_class *jrt.Class

var A_arbace_j2g_access_find_field_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000019_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000025_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000031_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000037_A_class *jrt.Class

func A_arbace_j2g_access__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_access__init_A_Load__O()}; return nil }

func A_arbace_j2g_access__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access__init_A_New()}; return nil }

var A_arbace_j2g_access__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_access__init_A_invoke, New: A_arbace_j2g_access__init_A_new}

var A_arbace_j2g_access__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access__init_A", Source: "access.ae"})

func init() { i := A_arbace_j2g_access__init_A_class.Info(); i.IsInstance = A_arbace_j2g_access__init_A_InstanceOf; i.Init = A_arbace_j2g_access__init_A_Init; i.Table = A_arbace_j2g_access__init_A_members }
