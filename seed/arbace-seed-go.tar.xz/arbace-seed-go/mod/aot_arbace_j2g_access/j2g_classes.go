//line j2g_classes.ae:1
package aot_arbace_j2g_access

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_access_accessor_A_class, Name: "arbace.j2g.access$accessor", Modifiers: 25, Simple: "accessor", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_accessor_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_class, Name: "arbace.j2g.access$eval978000004$loading__1927001464__auto____978000005", Modifiers: 25, Simple: "loading__1927001464__auto____978000005", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_eval978000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_eval978000008_fn__978000009_A_class, Name: "arbace.j2g.access$eval978000008$fn__978000009", Modifiers: 25, Simple: "fn__978000009", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000008_fn__978000009_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_eval978000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_find_field_A_class, Name: "arbace.j2g.access$find_field", Modifiers: 25, Simple: "find_field", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_find_field_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_A_class, Name: "arbace.j2g.access$unaccess", Modifiers: 25, Simple: "unaccess", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000020_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000020", Modifiers: 25, Simple: "declared_in__978000020", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000020_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000020$fn__978000021", Modifiers: 25, Simple: "fn__978000021", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_declared_in__978000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000030_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000030", Modifiers: 25, Simple: "declared_in__978000030", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000030_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000030$fn__978000031", Modifiers: 25, Simple: "fn__978000031", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_declared_in__978000030_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000040_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000040", Modifiers: 25, Simple: "declared_in__978000040", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000040_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000040$fn__978000041", Modifiers: 25, Simple: "fn__978000041", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_declared_in__978000040_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000050_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000050", Modifiers: 25, Simple: "declared_in__978000050", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000050_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_class, Name: "arbace.j2g.access$unaccess$declared_in__978000050$fn__978000051", Modifiers: 25, Simple: "fn__978000051", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_declared_in__978000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000024_A_class, Name: "arbace.j2g.access$unaccess$fn__978000024", Modifiers: 25, Simple: "fn__978000024", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000024_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000034_A_class, Name: "arbace.j2g.access$unaccess$fn__978000034", Modifiers: 25, Simple: "fn__978000034", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000034_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000044_A_class, Name: "arbace.j2g.access$unaccess$fn__978000044", Modifiers: 25, Simple: "fn__978000044", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000044_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_access_unaccess_fn__978000054_A_class, Name: "arbace.j2g.access$unaccess$fn__978000054", Modifiers: 25, Simple: "fn__978000054", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_fn__978000054_A", Source: "access.ae", Declaring: &A_arbace_j2g_access_unaccess_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_access_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_A_New()}; return nil }

var A_arbace_j2g_access_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_A_new}

var A_arbace_j2g_access_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_A"})

func init() { i := A_arbace_j2g_access_A_class.Info(); i.IsInstance = A_arbace_j2g_access_A_InstanceOf; i.Init = A_arbace_j2g_access_A_Init; i.Table = A_arbace_j2g_access_A_members }

var A_arbace_j2g_access_accessor_A_class *jrt.Class

func A_arbace_j2g_access_eval978000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_eval978000004_A_New()}; return nil }

var A_arbace_j2g_access_eval978000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_eval978000004_A_new}

var A_arbace_j2g_access_eval978000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access$eval978000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_access_A_class, Simple: "eval978000004", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000004_A"})

func init() { i := A_arbace_j2g_access_eval978000004_A_class.Info(); i.IsInstance = A_arbace_j2g_access_eval978000004_A_InstanceOf; i.Table = A_arbace_j2g_access_eval978000004_A_members }

var A_arbace_j2g_access_eval978000004_loading__1927001464__auto____978000005_A_class *jrt.Class

func A_arbace_j2g_access_eval978000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access_eval978000008_A_New()}; return nil }

var A_arbace_j2g_access_eval978000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_access_eval978000008_A_new}

var A_arbace_j2g_access_eval978000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access$eval978000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_access_A_class, Simple: "eval978000008", Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access_eval978000008_A"})

func init() { i := A_arbace_j2g_access_eval978000008_A_class.Info(); i.IsInstance = A_arbace_j2g_access_eval978000008_A_InstanceOf; i.Table = A_arbace_j2g_access_eval978000008_A_members }

var A_arbace_j2g_access_eval978000008_fn__978000009_A_class *jrt.Class

var A_arbace_j2g_access_find_field_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000020_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000020_fn__978000021_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000030_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000030_fn__978000031_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000040_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000040_fn__978000041_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000050_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_declared_in__978000050_fn__978000051_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000024_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000034_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000044_A_class *jrt.Class

var A_arbace_j2g_access_unaccess_fn__978000054_A_class *jrt.Class

func A_arbace_j2g_access__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_access__init_A_Load__O()}; return nil }

func A_arbace_j2g_access__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_access__init_A_New()}; return nil }

var A_arbace_j2g_access__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_access__init_A_invoke, New: A_arbace_j2g_access__init_A_new}

var A_arbace_j2g_access__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.access__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_access.A_arbace_j2g_access__init_A", Source: "access.ae"})

func init() { i := A_arbace_j2g_access__init_A_class.Info(); i.IsInstance = A_arbace_j2g_access__init_A_InstanceOf; i.Init = A_arbace_j2g_access__init_A_Init; i.Table = A_arbace_j2g_access__init_A_members }
