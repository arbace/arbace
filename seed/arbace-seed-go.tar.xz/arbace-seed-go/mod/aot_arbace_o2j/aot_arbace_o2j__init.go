//line aot_arbace_o2j__init.ae:1
package aot_arbace_o2j

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_o2j__init_A_Unit0__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_o2j__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j__init_A_const_1) }
//line :1:1
func A_arbace_o2j__init_A_Unit1__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_o2j__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_2)) }
//line :1:1
func A_arbace_o2j__init_A_Unit2__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_209, false, nil); A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_o2j__init_A_Unit3__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_o2j__init_A_const_1)).Equals_O__Z(A_arbace_o2j__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_o2j_eval1641000008_fn__1641000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_o2j_eval1641000008_fn__1641000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_210, false, nil); A_arbace_o2j_eval1641000008_fn__1641000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_o2j__init_A_Load__O() any { A_arbace_o2j__init_A_Init(); jrt.StartCheck(); A_arbace_o2j__init_A_Unit0__O(); A_arbace_o2j__init_A_Unit1__O(); A_arbace_o2j__init_A_Unit2__O(); A_arbace_o2j__init_A_Unit3__O(); A_arbace_o2j__init_A_Unit4__O(); A_arbace_o2j__init_A_Unit5__O(); A_arbace_o2j__init_A_Unit6__O(); A_arbace_o2j__init_A_Unit7__O(); A_arbace_o2j__init_A_Unit8__O(); A_arbace_o2j__init_A_Unit9__O(); A_arbace_o2j__init_A_Unit10__O(); A_arbace_o2j__init_A_Unit11__O(); A_arbace_o2j__init_A_Unit12__O(); A_arbace_o2j__init_A_Unit13__O(); A_arbace_o2j__init_A_Unit14__O(); A_arbace_o2j__init_A_Unit15__O(); A_arbace_o2j__init_A_Unit16__O(); A_arbace_o2j__init_A_Unit17__O(); A_arbace_o2j__init_A_Unit18__O(); A_arbace_o2j__init_A_Unit19__O(); A_arbace_o2j__init_A_Unit20__O(); A_arbace_o2j__init_A_Unit21__O(); A_arbace_o2j__init_A_Unit22__O(); A_arbace_o2j__init_A_Unit23__O(); A_arbace_o2j__init_A_Unit24__O(); A_arbace_o2j__init_A_Unit25__O(); A_arbace_o2j__init_A_Unit26__O(); A_arbace_o2j__init_A_Unit27__O(); A_arbace_o2j__init_A_Unit28__O(); A_arbace_o2j__init_A_Unit29__O(); A_arbace_o2j__init_A_Unit30__O(); A_arbace_o2j__init_A_Unit31__O(); A_arbace_o2j__init_A_Unit32__O(); A_arbace_o2j__init_A_Unit33__O(); A_arbace_o2j__init_A_Unit34__O(); A_arbace_o2j__init_A_Unit35__O(); A_arbace_o2j__init_A_Unit36__O(); A_arbace_o2j__init_A_Unit37__O(); A_arbace_o2j__init_A_Unit38__O(); A_arbace_o2j__init_A_Unit39__O(); A_arbace_o2j__init_A_Unit40__O(); A_arbace_o2j__init_A_Unit41__O(); A_arbace_o2j__init_A_Unit42__O(); A_arbace_o2j__init_A_Unit43__O(); A_arbace_o2j__init_A_Unit44__O(); A_arbace_o2j__init_A_Unit45__O(); A_arbace_o2j__init_A_Unit46__O(); A_arbace_o2j__init_A_Unit47__O(); A_arbace_o2j__init_A_Unit48__O(); A_arbace_o2j__init_A_Unit49__O(); A_arbace_o2j__init_A_Unit50__O(); A_arbace_o2j__init_A_Unit51__O(); A_arbace_o2j__init_A_Unit52__O(); A_arbace_o2j__init_A_Unit53__O(); A_arbace_o2j__init_A_Unit54__O(); A_arbace_o2j__init_A_Unit55__O(); A_arbace_o2j__init_A_Unit56__O(); A_arbace_o2j__init_A_Unit57__O(); A_arbace_o2j__init_A_Unit58__O(); A_arbace_o2j__init_A_Unit59__O(); A_arbace_o2j__init_A_Unit60__O(); A_arbace_o2j__init_A_Unit61__O(); A_arbace_o2j__init_A_Unit62__O(); A_arbace_o2j__init_A_Unit63__O(); A_arbace_o2j__init_A_Unit64__O(); A_arbace_o2j__init_A_Unit65__O(); A_arbace_o2j__init_A_Unit66__O(); A_arbace_o2j__init_A_Unit67__O(); A_arbace_o2j__init_A_Unit68__O(); return nil }

























func A_arbace_o2j__init_A_Unit4__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_o2j_read_dump_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_o2j_read_dump_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_211, false, nil); A_arbace_o2j_read_dump_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_5)); return A_arbace_o2j__init_A_const_4 }












func A_arbace_o2j__init_A_Unit5__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_o2j_node_body_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_o2j_node_body_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_212, false, nil); A_arbace_o2j_node_body_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_7)); return A_arbace_o2j__init_A_const_6 }




func A_arbace_o2j__init_A_Unit6__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_o2j_realize_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_o2j_realize_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_213, false, nil); A_arbace_o2j_realize_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_9)); return A_arbace_o2j__init_A_const_8 }






func A_arbace_o2j__init_A_Unit7__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_o2j_hd_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_o2j_hd_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_214, false, nil); A_arbace_o2j_hd_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_11)); return A_arbace_o2j__init_A_const_10 }




func A_arbace_o2j__init_A_Unit8__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); A_arbace_o2j__init_A_const_12.BindRoot_O__V(A_arbace_o2j__init_A_const_13); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_14)); return A_arbace_o2j__init_A_const_12 }




func A_arbace_o2j__init_A_Unit9__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_o2j_class_name_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_o2j_class_name_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_215, false, nil); A_arbace_o2j_class_name_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_16)); return A_arbace_o2j__init_A_const_15 }

func A_arbace_o2j__init_A_Unit10__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_o2j_munge_id_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_o2j_munge_id_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_216, false, nil); A_arbace_o2j_munge_id_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_18)); return A_arbace_o2j__init_A_const_17 }

func A_arbace_o2j__init_A_Unit11__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_o2j_global_name_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_o2j_global_name_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_217, false, nil); A_arbace_o2j_global_name_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_20)); return A_arbace_o2j__init_A_const_19 }




func A_arbace_o2j__init_A_Unit12__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_o2j_runtime_externals_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_o2j_runtime_externals_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_218, false, nil); A_arbace_o2j_runtime_externals_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_22)); return A_arbace_o2j__init_A_const_21 }















func A_arbace_o2j__init_A_Unit13__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); A_arbace_o2j__init_A_const_23.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_24)); return A_arbace_o2j__init_A_const_23.SetDynamic_Z__Var(true).Ref() }

func A_arbace_o2j__init_A_Unit14__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_o2j_load_externals_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_o2j_load_externals_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_219, false, nil); A_arbace_o2j_load_externals_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_26)); return A_arbace_o2j__init_A_const_25 }




func A_arbace_o2j__init_A_Unit15__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); A_arbace_o2j__init_A_const_27.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_28)); return A_arbace_o2j__init_A_const_27.SetDynamic_Z__Var(true).Ref() }




func A_arbace_o2j__init_A_Unit16__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_o2j_fresh_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_o2j_fresh_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_220, false, nil); A_arbace_o2j_fresh_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_30)); return A_arbace_o2j__init_A_const_29 }

func A_arbace_o2j__init_A_Unit17__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_o2j_unit_class_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_o2j_unit_class_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_221, false, nil); A_arbace_o2j_unit_class_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_32)); return A_arbace_o2j__init_A_const_31 }

func A_arbace_o2j__init_A_Unit18__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_o2j_note_missing_BANG__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_o2j_note_missing_BANG__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_222, false, nil); A_arbace_o2j_note_missing_BANG__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_34)); return A_arbace_o2j__init_A_const_33 }




func A_arbace_o2j__init_A_Unit19__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); A_arbace_o2j__init_A_const_35.BindRoot_O__V(A_arbace_o2j__init_A_const_36); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_37)); return A_arbace_o2j__init_A_const_35 }

func A_arbace_o2j__init_A_Unit20__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_o2j_latin1_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_o2j_latin1_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_223, false, nil); A_arbace_o2j_latin1_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_39)); return A_arbace_o2j__init_A_const_38 }






func A_arbace_o2j__init_A_Unit21__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_o2j_parse_float_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_o2j_parse_float_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_224, false, nil); A_arbace_o2j_parse_float_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_41)); return A_arbace_o2j__init_A_const_40 }




func A_arbace_o2j__init_A_Unit22__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_o2j_double_form_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_o2j_double_form_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_225, false, nil); A_arbace_o2j_double_form_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_43)); return A_arbace_o2j__init_A_const_42 }




func A_arbace_o2j__init_A_Unit23__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_o2j_const_init_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_o2j_const_init_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_226, false, nil); A_arbace_o2j_const_init_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_45)); return A_arbace_o2j__init_A_const_44 }















func A_arbace_o2j__init_A_Unit24__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_o2j_const_form_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_o2j_const_form_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_227, false, nil); A_arbace_o2j_const_form_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_47)); return A_arbace_o2j__init_A_const_46 }












func A_arbace_o2j__init_A_Unit25__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_49)); return A_arbace_o2j__init_A_const_48 }

func A_arbace_o2j__init_A_Unit26__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_o2j_bound_and_refs_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_o2j_bound_and_refs_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_228, false, nil); A_arbace_o2j_bound_and_refs_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_51)); return A_arbace_o2j__init_A_const_50 }




























func A_arbace_o2j__init_A_Unit27__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_o2j_free_ids_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_o2j_free_ids_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_229, false, nil); A_arbace_o2j_free_ids_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_52)); return A_arbace_o2j__init_A_const_48 }








func A_arbace_o2j__init_A_Unit28__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_54)); return A_arbace_o2j__init_A_const_53 }
//line :200:1
func A_arbace_o2j__init_A_Unit29__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_56)); return A_arbace_o2j__init_A_const_55 }



func A_arbace_o2j__init_A_Unit30__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_o2j_lookup_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_o2j_lookup_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_230, false, nil); A_arbace_o2j_lookup_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_58)); return A_arbace_o2j__init_A_const_57 }



func A_arbace_o2j__init_A_Unit31__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_o2j_simple_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_o2j_simple_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_231, false, nil); A_arbace_o2j_simple_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_60)); return A_arbace_o2j__init_A_const_59 }









func A_arbace_o2j__init_A_Unit32__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_o2j_with_args_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_o2j_with_args_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_232, false, nil); A_arbace_o2j_with_args_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_62)); return A_arbace_o2j__init_A_const_61 }












func A_arbace_o2j__init_A_Unit33__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_o2j_call_form_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_o2j_call_form_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_233, false, nil); A_arbace_o2j_call_form_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_64)); return A_arbace_o2j__init_A_const_63 }











func A_arbace_o2j__init_A_Unit34__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_o2j_apply_node_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_o2j_apply_node_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_234, false, nil); A_arbace_o2j_apply_node_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_66)); return A_arbace_o2j__init_A_const_65 }











func A_arbace_o2j__init_A_Unit35__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_o2j_method_for_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_o2j_method_for_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_235, false, nil); A_arbace_o2j_method_for_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_68)); return A_arbace_o2j__init_A_const_67 }






func A_arbace_o2j__init_A_Unit36__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_o2j_closure_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_o2j_closure_class_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_236, false, nil); A_arbace_o2j_closure_class_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_70)); return A_arbace_o2j__init_A_const_69 }




























func A_arbace_o2j__init_A_Unit37__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_o2j_function_node_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_o2j_function_node_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_237, false, nil); A_arbace_o2j_function_node_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_72)); return A_arbace_o2j__init_A_const_71 }



func A_arbace_o2j__init_A_Unit38__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_o2j_letrec_node_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_o2j_letrec_node_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_238, false, nil); A_arbace_o2j_letrec_node_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_74)); return A_arbace_o2j__init_A_const_73 }

















func A_arbace_o2j__init_A_Unit39__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_o2j_let_chain_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_o2j_let_chain_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_239, false, nil); A_arbace_o2j_let_chain_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_76)); return A_arbace_o2j__init_A_const_75 }














func A_arbace_o2j__init_A_Unit40__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_o2j_num_arg_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_o2j_num_arg_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_240, false, nil); A_arbace_o2j_num_arg_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_78)); return A_arbace_o2j__init_A_const_77 }

func A_arbace_o2j__init_A_Unit41__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_79; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__66 any = A_arbace_o2j_rt_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_o2j_rt_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_241, true, nil); A_arbace_o2j_rt_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__66, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_80)); return A_arbace_o2j__init_A_const_79 }

func A_arbace_o2j__init_A_Unit42__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); A_arbace_o2j__init_A_const_81.BindRoot_O__V(A_arbace_o2j__init_A_const_82); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_83)); return A_arbace_o2j__init_A_const_81 }






func A_arbace_o2j__init_A_Unit43__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); A_arbace_o2j__init_A_const_84.BindRoot_O__V(A_arbace_o2j__init_A_const_85); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_86)); return A_arbace_o2j__init_A_const_84 }



func A_arbace_o2j__init_A_Unit44__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); A_arbace_o2j__init_A_const_87.BindRoot_O__V(A_arbace_o2j__init_A_const_88); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_89)); return A_arbace_o2j__init_A_const_87 }

func A_arbace_o2j__init_A_Unit45__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); A_arbace_o2j__init_A_const_90.BindRoot_O__V(A_arbace_o2j__init_A_const_91); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_92)); return A_arbace_o2j__init_A_const_90 }
func A_arbace_o2j__init_A_Unit46__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); A_arbace_o2j__init_A_const_93.BindRoot_O__V(A_arbace_o2j__init_A_const_94); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_95)); return A_arbace_o2j__init_A_const_93 }

func A_arbace_o2j__init_A_Unit47__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_o2j_array_kind_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_o2j_array_kind_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_242, false, nil); A_arbace_o2j_array_kind_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_97)); return A_arbace_o2j__init_A_const_96 }


func A_arbace_o2j__init_A_Unit48__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_o2j_bigarray_ext_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_o2j_bigarray_ext_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_243, false, nil); A_arbace_o2j_bigarray_ext_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_99)); return A_arbace_o2j__init_A_const_98 }












func A_arbace_o2j__init_A_Unit49__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_o2j_external_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_o2j_external_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_244, false, nil); A_arbace_o2j_external_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_101)); return A_arbace_o2j__init_A_const_100 }






func A_arbace_o2j__init_A_Unit50__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(371, 1); A_arbace_o2j__init_A_const_102.BindRoot_O__V(A_arbace_o2j__init_A_const_103); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_104)); return A_arbace_o2j__init_A_const_102 }


func A_arbace_o2j__init_A_Unit51__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_o2j_prim_value_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_o2j_prim_value_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_245, false, nil); A_arbace_o2j_prim_value_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_106)); return A_arbace_o2j__init_A_const_105 }


































































func A_arbace_o2j__init_A_Unit52__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(441, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_o2j_prim_node_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_o2j_prim_node_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_246, false, nil); A_arbace_o2j_prim_node_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_108)); return A_arbace_o2j__init_A_const_107 }










func A_arbace_o2j__init_A_Unit53__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(452, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_o2j_test_form_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_o2j_test_form_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_247, false, nil); A_arbace_o2j_test_form_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_109)); return A_arbace_o2j__init_A_const_55 }




















func A_arbace_o2j__init_A_Unit54__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_o2j_switch_node_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_o2j_switch_node_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_248, false, nil); A_arbace_o2j_switch_node_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_111)); return A_arbace_o2j__init_A_const_110 }















func A_arbace_o2j__init_A_Unit55__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(489, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_o2j_stringswitch_node_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_o2j_stringswitch_node_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_249, false, nil); A_arbace_o2j_stringswitch_node_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_113)); return A_arbace_o2j__init_A_const_112 }






func A_arbace_o2j__init_A_Unit56__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_o2j_staticcatch_node_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_o2j_staticcatch_node_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_250, false, nil); A_arbace_o2j_staticcatch_node_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_115)); return A_arbace_o2j__init_A_const_114 }











func A_arbace_o2j__init_A_Unit57__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(508, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_o2j_staticraise_node_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_o2j_staticraise_node_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_251, false, nil); A_arbace_o2j_staticraise_node_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_117)); return A_arbace_o2j__init_A_const_116 }








func A_arbace_o2j__init_A_Unit58__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_o2j_trywith_node_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_o2j_trywith_node_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_252, false, nil); A_arbace_o2j_trywith_node_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_119)); return A_arbace_o2j__init_A_const_118 }





func A_arbace_o2j__init_A_Unit59__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(523, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_o2j_for_node_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_o2j_for_node_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_253, false, nil); A_arbace_o2j_for_node_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_121)); return A_arbace_o2j__init_A_const_120 }










func A_arbace_o2j__init_A_Unit60__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(534, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_o2j_flatten_seq_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_o2j_flatten_seq_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_254, false, nil); A_arbace_o2j_flatten_seq_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_123)); return A_arbace_o2j__init_A_const_122 }


func A_arbace_o2j__init_A_Unit61__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(537, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_o2j_expr_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_o2j_expr_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_255, false, nil); A_arbace_o2j_expr_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_124)); return A_arbace_o2j__init_A_const_53 }




































func A_arbace_o2j__init_A_Unit62__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(574, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_o2j_translate_unit_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_o2j_translate_unit_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_256, false, nil); A_arbace_o2j_translate_unit_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_126)); return A_arbace_o2j__init_A_const_125 }




















func A_arbace_o2j__init_A_Unit63__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(595, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_o2j_main_forms_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_o2j_main_forms_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_257, false, nil); A_arbace_o2j_main_forms_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_128)); return A_arbace_o2j__init_A_const_127 }












func A_arbace_o2j__init_A_Unit64__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(608, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_o2j_write_forms_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_o2j_write_forms_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_258, false, nil); A_arbace_o2j_write_forms_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_130)); return A_arbace_o2j__init_A_const_129 }









func A_arbace_o2j__init_A_Unit65__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(618, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_o2j_unit_refs_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_o2j_unit_refs_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_259, false, nil); A_arbace_o2j_unit_refs_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_132)); return A_arbace_o2j__init_A_const_131 }












func A_arbace_o2j__init_A_Unit66__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_o2j_link_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_o2j_link_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_260, false, nil); A_arbace_o2j_link_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_134)); return A_arbace_o2j__init_A_const_133 }












func A_arbace_o2j__init_A_Unit67__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(644, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_o2j_translate_program_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_o2j_translate_program_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_261, false, nil); A_arbace_o2j_translate_program_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_136)); return A_arbace_o2j__init_A_const_135 }





















func A_arbace_o2j__init_A_Unit68__O() any { A_arbace_o2j__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_o2j__init_A_const_137; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__108 any = A_arbace_o2j__main_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_o2j__main_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_262, true, nil); A_arbace_o2j__main_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__108, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_o2j__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_o2j__init_A_const_138)); return A_arbace_o2j__init_A_const_137 }



type A_arbace_o2j__init_A struct{ jrt.Object }

var A_arbace_o2j__init_A_const_pool *jrt.RefArray

var A_arbace_o2j__init_A_const_0 *lang.Var

var A_arbace_o2j__init_A_const_1 any

var A_arbace_o2j__init_A_const_2 any

var A_arbace_o2j__init_A_const_3 any

var A_arbace_o2j__init_A_const_4 *lang.Var

var A_arbace_o2j__init_A_const_5 any

var A_arbace_o2j__init_A_const_6 *lang.Var

var A_arbace_o2j__init_A_const_7 any

var A_arbace_o2j__init_A_const_8 *lang.Var

var A_arbace_o2j__init_A_const_9 any

var A_arbace_o2j__init_A_const_10 *lang.Var

var A_arbace_o2j__init_A_const_11 any

var A_arbace_o2j__init_A_const_12 *lang.Var

var A_arbace_o2j__init_A_const_13 any

var A_arbace_o2j__init_A_const_14 any

var A_arbace_o2j__init_A_const_15 *lang.Var

var A_arbace_o2j__init_A_const_16 any

var A_arbace_o2j__init_A_const_17 *lang.Var

var A_arbace_o2j__init_A_const_18 any

var A_arbace_o2j__init_A_const_19 *lang.Var

var A_arbace_o2j__init_A_const_20 any

var A_arbace_o2j__init_A_const_21 *lang.Var

var A_arbace_o2j__init_A_const_22 any

var A_arbace_o2j__init_A_const_23 *lang.Var

var A_arbace_o2j__init_A_const_24 any

var A_arbace_o2j__init_A_const_25 *lang.Var

var A_arbace_o2j__init_A_const_26 any

var A_arbace_o2j__init_A_const_27 *lang.Var

var A_arbace_o2j__init_A_const_28 any

var A_arbace_o2j__init_A_const_29 *lang.Var

var A_arbace_o2j__init_A_const_30 any

var A_arbace_o2j__init_A_const_31 *lang.Var

var A_arbace_o2j__init_A_const_32 any

var A_arbace_o2j__init_A_const_33 *lang.Var

var A_arbace_o2j__init_A_const_34 any

var A_arbace_o2j__init_A_const_35 *lang.Var

var A_arbace_o2j__init_A_const_36 any

var A_arbace_o2j__init_A_const_37 any

var A_arbace_o2j__init_A_const_38 *lang.Var

var A_arbace_o2j__init_A_const_39 any

var A_arbace_o2j__init_A_const_40 *lang.Var

var A_arbace_o2j__init_A_const_41 any

var A_arbace_o2j__init_A_const_42 *lang.Var

var A_arbace_o2j__init_A_const_43 any

var A_arbace_o2j__init_A_const_44 *lang.Var

var A_arbace_o2j__init_A_const_45 any

var A_arbace_o2j__init_A_const_46 *lang.Var

var A_arbace_o2j__init_A_const_47 any

var A_arbace_o2j__init_A_const_48 *lang.Var

var A_arbace_o2j__init_A_const_49 any

var A_arbace_o2j__init_A_const_50 *lang.Var

var A_arbace_o2j__init_A_const_51 any

var A_arbace_o2j__init_A_const_52 any

var A_arbace_o2j__init_A_const_53 *lang.Var

var A_arbace_o2j__init_A_const_54 any

var A_arbace_o2j__init_A_const_55 *lang.Var

var A_arbace_o2j__init_A_const_56 any

var A_arbace_o2j__init_A_const_57 *lang.Var

var A_arbace_o2j__init_A_const_58 any

var A_arbace_o2j__init_A_const_59 *lang.Var

var A_arbace_o2j__init_A_const_60 any

var A_arbace_o2j__init_A_const_61 *lang.Var

var A_arbace_o2j__init_A_const_62 any

var A_arbace_o2j__init_A_const_63 *lang.Var

var A_arbace_o2j__init_A_const_64 any

var A_arbace_o2j__init_A_const_65 *lang.Var

var A_arbace_o2j__init_A_const_66 any

var A_arbace_o2j__init_A_const_67 *lang.Var

var A_arbace_o2j__init_A_const_68 any

var A_arbace_o2j__init_A_const_69 *lang.Var

var A_arbace_o2j__init_A_const_70 any

var A_arbace_o2j__init_A_const_71 *lang.Var

var A_arbace_o2j__init_A_const_72 any

var A_arbace_o2j__init_A_const_73 *lang.Var

var A_arbace_o2j__init_A_const_74 any

var A_arbace_o2j__init_A_const_75 *lang.Var

var A_arbace_o2j__init_A_const_76 any

var A_arbace_o2j__init_A_const_77 *lang.Var

var A_arbace_o2j__init_A_const_78 any

var A_arbace_o2j__init_A_const_79 *lang.Var

var A_arbace_o2j__init_A_const_80 any

var A_arbace_o2j__init_A_const_81 *lang.Var

var A_arbace_o2j__init_A_const_82 any

var A_arbace_o2j__init_A_const_83 any

var A_arbace_o2j__init_A_const_84 *lang.Var

var A_arbace_o2j__init_A_const_85 any

var A_arbace_o2j__init_A_const_86 any

var A_arbace_o2j__init_A_const_87 *lang.Var

var A_arbace_o2j__init_A_const_88 any

var A_arbace_o2j__init_A_const_89 any

var A_arbace_o2j__init_A_const_90 *lang.Var

var A_arbace_o2j__init_A_const_91 any

var A_arbace_o2j__init_A_const_92 any

var A_arbace_o2j__init_A_const_93 *lang.Var

var A_arbace_o2j__init_A_const_94 any

var A_arbace_o2j__init_A_const_95 any

var A_arbace_o2j__init_A_const_96 *lang.Var

var A_arbace_o2j__init_A_const_97 any

var A_arbace_o2j__init_A_const_98 *lang.Var

var A_arbace_o2j__init_A_const_99 any

var A_arbace_o2j__init_A_const_100 *lang.Var

var A_arbace_o2j__init_A_const_101 any

var A_arbace_o2j__init_A_const_102 *lang.Var

var A_arbace_o2j__init_A_const_103 any

var A_arbace_o2j__init_A_const_104 any

var A_arbace_o2j__init_A_const_105 *lang.Var

var A_arbace_o2j__init_A_const_106 any

var A_arbace_o2j__init_A_const_107 *lang.Var

var A_arbace_o2j__init_A_const_108 any

var A_arbace_o2j__init_A_const_109 any

var A_arbace_o2j__init_A_const_110 *lang.Var

var A_arbace_o2j__init_A_const_111 any

var A_arbace_o2j__init_A_const_112 *lang.Var

var A_arbace_o2j__init_A_const_113 any

var A_arbace_o2j__init_A_const_114 *lang.Var

var A_arbace_o2j__init_A_const_115 any

var A_arbace_o2j__init_A_const_116 *lang.Var

var A_arbace_o2j__init_A_const_117 any

var A_arbace_o2j__init_A_const_118 *lang.Var

var A_arbace_o2j__init_A_const_119 any

var A_arbace_o2j__init_A_const_120 *lang.Var

var A_arbace_o2j__init_A_const_121 any

var A_arbace_o2j__init_A_const_122 *lang.Var

var A_arbace_o2j__init_A_const_123 any

var A_arbace_o2j__init_A_const_124 any

var A_arbace_o2j__init_A_const_125 *lang.Var

var A_arbace_o2j__init_A_const_126 any

var A_arbace_o2j__init_A_const_127 *lang.Var

var A_arbace_o2j__init_A_const_128 any

var A_arbace_o2j__init_A_const_129 *lang.Var

var A_arbace_o2j__init_A_const_130 any

var A_arbace_o2j__init_A_const_131 *lang.Var

var A_arbace_o2j__init_A_const_132 any

var A_arbace_o2j__init_A_const_133 *lang.Var

var A_arbace_o2j__init_A_const_134 any

var A_arbace_o2j__init_A_const_135 *lang.Var

var A_arbace_o2j__init_A_const_136 any

var A_arbace_o2j__init_A_const_137 *lang.Var

var A_arbace_o2j__init_A_const_138 any

var A_arbace_o2j__init_A_init jrt.ClassInit

func A_arbace_o2j__init_A_Init() { if !A_arbace_o2j__init_A_init.Done() { A_arbace_o2j__init_A_init.Run(A_arbace_o2j__init_A_clinit) } }

func A_arbace_o2j__init_A_clinit() { A_arbace_o2j__init_A_clinit_p0(); A_arbace_o2j__init_A_clinit_p1(); A_arbace_o2j__init_A_clinit_p2(); A_arbace_o2j__init_A_clinit_p3(); A_arbace_o2j__init_A_clinit_p4(); A_arbace_o2j__init_A_clinit_p5(); A_arbace_o2j__init_A_clinit_p6(); A_arbace_o2j__init_A_clinit_p7(); A_arbace_o2j__init_A_clinit_p8(); A_arbace_o2j__init_A_clinit_p9(); A_arbace_o2j__init_A_clinit_p10() }

func A_arbace_o2j__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_o2j__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_208, 241); A_arbace_o2j__init_A_const_0 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[102]); A_arbace_o2j__init_A_const_1 = A_arbace_o2j__init_A_const_pool.A[103]; A_arbace_o2j__init_A_const_2 = A_arbace_o2j__init_A_const_pool.A[104]; A_arbace_o2j__init_A_const_3 = A_arbace_o2j__init_A_const_pool.A[105]; A_arbace_o2j__init_A_const_4 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[106]); A_arbace_o2j__init_A_const_5 = A_arbace_o2j__init_A_const_pool.A[107]; A_arbace_o2j__init_A_const_6 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[108]); A_arbace_o2j__init_A_const_7 = A_arbace_o2j__init_A_const_pool.A[109]; A_arbace_o2j__init_A_const_8 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[110]); A_arbace_o2j__init_A_const_9 = A_arbace_o2j__init_A_const_pool.A[111]; A_arbace_o2j__init_A_const_10 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[112]); A_arbace_o2j__init_A_const_11 = A_arbace_o2j__init_A_const_pool.A[113]; A_arbace_o2j__init_A_const_12 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[114]) }

func A_arbace_o2j__init_A_clinit_p1() { A_arbace_o2j__init_A_const_13 = A_arbace_o2j__init_A_const_pool.A[115]; A_arbace_o2j__init_A_const_14 = A_arbace_o2j__init_A_const_pool.A[116]; A_arbace_o2j__init_A_const_15 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[117]); A_arbace_o2j__init_A_const_16 = A_arbace_o2j__init_A_const_pool.A[118]; A_arbace_o2j__init_A_const_17 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[119]); A_arbace_o2j__init_A_const_18 = A_arbace_o2j__init_A_const_pool.A[120]; A_arbace_o2j__init_A_const_19 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[121]); A_arbace_o2j__init_A_const_20 = A_arbace_o2j__init_A_const_pool.A[122]; A_arbace_o2j__init_A_const_21 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[123]); A_arbace_o2j__init_A_const_22 = A_arbace_o2j__init_A_const_pool.A[124]; A_arbace_o2j__init_A_const_23 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[125]); A_arbace_o2j__init_A_const_24 = A_arbace_o2j__init_A_const_pool.A[126]; A_arbace_o2j__init_A_const_25 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[127]); A_arbace_o2j__init_A_const_26 = A_arbace_o2j__init_A_const_pool.A[128] }

func A_arbace_o2j__init_A_clinit_p2() { A_arbace_o2j__init_A_const_27 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[129]); A_arbace_o2j__init_A_const_28 = A_arbace_o2j__init_A_const_pool.A[130]; A_arbace_o2j__init_A_const_29 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[131]); A_arbace_o2j__init_A_const_30 = A_arbace_o2j__init_A_const_pool.A[132]; A_arbace_o2j__init_A_const_31 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[133]); A_arbace_o2j__init_A_const_32 = A_arbace_o2j__init_A_const_pool.A[134]; A_arbace_o2j__init_A_const_33 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[135]); A_arbace_o2j__init_A_const_34 = A_arbace_o2j__init_A_const_pool.A[136]; A_arbace_o2j__init_A_const_35 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[137]); A_arbace_o2j__init_A_const_36 = A_arbace_o2j__init_A_const_pool.A[138]; A_arbace_o2j__init_A_const_37 = A_arbace_o2j__init_A_const_pool.A[139]; A_arbace_o2j__init_A_const_38 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[140]); A_arbace_o2j__init_A_const_39 = A_arbace_o2j__init_A_const_pool.A[141] }

func A_arbace_o2j__init_A_clinit_p3() { A_arbace_o2j__init_A_const_40 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[142]); A_arbace_o2j__init_A_const_41 = A_arbace_o2j__init_A_const_pool.A[143]; A_arbace_o2j__init_A_const_42 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[144]); A_arbace_o2j__init_A_const_43 = A_arbace_o2j__init_A_const_pool.A[145]; A_arbace_o2j__init_A_const_44 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[146]); A_arbace_o2j__init_A_const_45 = A_arbace_o2j__init_A_const_pool.A[147]; A_arbace_o2j__init_A_const_46 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[148]); A_arbace_o2j__init_A_const_47 = A_arbace_o2j__init_A_const_pool.A[149]; A_arbace_o2j__init_A_const_48 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[150]); A_arbace_o2j__init_A_const_49 = A_arbace_o2j__init_A_const_pool.A[151]; A_arbace_o2j__init_A_const_50 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[152]); A_arbace_o2j__init_A_const_51 = A_arbace_o2j__init_A_const_pool.A[153]; A_arbace_o2j__init_A_const_52 = A_arbace_o2j__init_A_const_pool.A[154] }

func A_arbace_o2j__init_A_clinit_p4() { A_arbace_o2j__init_A_const_53 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[155]); A_arbace_o2j__init_A_const_54 = A_arbace_o2j__init_A_const_pool.A[156]; A_arbace_o2j__init_A_const_55 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[157]); A_arbace_o2j__init_A_const_56 = A_arbace_o2j__init_A_const_pool.A[158]; A_arbace_o2j__init_A_const_57 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[159]); A_arbace_o2j__init_A_const_58 = A_arbace_o2j__init_A_const_pool.A[160]; A_arbace_o2j__init_A_const_59 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[161]); A_arbace_o2j__init_A_const_60 = A_arbace_o2j__init_A_const_pool.A[162]; A_arbace_o2j__init_A_const_61 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[163]); A_arbace_o2j__init_A_const_62 = A_arbace_o2j__init_A_const_pool.A[164]; A_arbace_o2j__init_A_const_63 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[165]); A_arbace_o2j__init_A_const_64 = A_arbace_o2j__init_A_const_pool.A[166]; A_arbace_o2j__init_A_const_65 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[167]) }

func A_arbace_o2j__init_A_clinit_p5() { A_arbace_o2j__init_A_const_66 = A_arbace_o2j__init_A_const_pool.A[168]; A_arbace_o2j__init_A_const_67 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[169]); A_arbace_o2j__init_A_const_68 = A_arbace_o2j__init_A_const_pool.A[170]; A_arbace_o2j__init_A_const_69 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[171]); A_arbace_o2j__init_A_const_70 = A_arbace_o2j__init_A_const_pool.A[172]; A_arbace_o2j__init_A_const_71 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[173]); A_arbace_o2j__init_A_const_72 = A_arbace_o2j__init_A_const_pool.A[174]; A_arbace_o2j__init_A_const_73 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[175]); A_arbace_o2j__init_A_const_74 = A_arbace_o2j__init_A_const_pool.A[176]; A_arbace_o2j__init_A_const_75 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[177]); A_arbace_o2j__init_A_const_76 = A_arbace_o2j__init_A_const_pool.A[178]; A_arbace_o2j__init_A_const_77 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[179]); A_arbace_o2j__init_A_const_78 = A_arbace_o2j__init_A_const_pool.A[180] }

func A_arbace_o2j__init_A_clinit_p6() { A_arbace_o2j__init_A_const_79 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[181]); A_arbace_o2j__init_A_const_80 = A_arbace_o2j__init_A_const_pool.A[182]; A_arbace_o2j__init_A_const_81 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[183]); A_arbace_o2j__init_A_const_82 = A_arbace_o2j__init_A_const_pool.A[184]; A_arbace_o2j__init_A_const_83 = A_arbace_o2j__init_A_const_pool.A[185]; A_arbace_o2j__init_A_const_84 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[186]); A_arbace_o2j__init_A_const_85 = A_arbace_o2j__init_A_const_pool.A[187]; A_arbace_o2j__init_A_const_86 = A_arbace_o2j__init_A_const_pool.A[188]; A_arbace_o2j__init_A_const_87 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[189]); A_arbace_o2j__init_A_const_88 = A_arbace_o2j__init_A_const_pool.A[190]; A_arbace_o2j__init_A_const_89 = A_arbace_o2j__init_A_const_pool.A[191]; A_arbace_o2j__init_A_const_90 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[192]); A_arbace_o2j__init_A_const_91 = A_arbace_o2j__init_A_const_pool.A[193]; A_arbace_o2j__init_A_const_92 = A_arbace_o2j__init_A_const_pool.A[194] }

func A_arbace_o2j__init_A_clinit_p7() { A_arbace_o2j__init_A_const_93 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[195]); A_arbace_o2j__init_A_const_94 = A_arbace_o2j__init_A_const_pool.A[196]; A_arbace_o2j__init_A_const_95 = A_arbace_o2j__init_A_const_pool.A[197]; A_arbace_o2j__init_A_const_96 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[198]); A_arbace_o2j__init_A_const_97 = A_arbace_o2j__init_A_const_pool.A[199]; A_arbace_o2j__init_A_const_98 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[200]); A_arbace_o2j__init_A_const_99 = A_arbace_o2j__init_A_const_pool.A[201]; A_arbace_o2j__init_A_const_100 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[202]); A_arbace_o2j__init_A_const_101 = A_arbace_o2j__init_A_const_pool.A[203]; A_arbace_o2j__init_A_const_102 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[204]); A_arbace_o2j__init_A_const_103 = A_arbace_o2j__init_A_const_pool.A[205]; A_arbace_o2j__init_A_const_104 = A_arbace_o2j__init_A_const_pool.A[206]; A_arbace_o2j__init_A_const_105 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[207]); A_arbace_o2j__init_A_const_106 = A_arbace_o2j__init_A_const_pool.A[208] }

func A_arbace_o2j__init_A_clinit_p8() { A_arbace_o2j__init_A_const_107 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[209]); A_arbace_o2j__init_A_const_108 = A_arbace_o2j__init_A_const_pool.A[210]; A_arbace_o2j__init_A_const_109 = A_arbace_o2j__init_A_const_pool.A[211]; A_arbace_o2j__init_A_const_110 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[212]); A_arbace_o2j__init_A_const_111 = A_arbace_o2j__init_A_const_pool.A[213]; A_arbace_o2j__init_A_const_112 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[214]); A_arbace_o2j__init_A_const_113 = A_arbace_o2j__init_A_const_pool.A[215]; A_arbace_o2j__init_A_const_114 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[216]); A_arbace_o2j__init_A_const_115 = A_arbace_o2j__init_A_const_pool.A[217]; A_arbace_o2j__init_A_const_116 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[218]); A_arbace_o2j__init_A_const_117 = A_arbace_o2j__init_A_const_pool.A[219]; A_arbace_o2j__init_A_const_118 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[220]); A_arbace_o2j__init_A_const_119 = A_arbace_o2j__init_A_const_pool.A[221] }

func A_arbace_o2j__init_A_clinit_p9() { A_arbace_o2j__init_A_const_120 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[222]); A_arbace_o2j__init_A_const_121 = A_arbace_o2j__init_A_const_pool.A[223]; A_arbace_o2j__init_A_const_122 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[224]); A_arbace_o2j__init_A_const_123 = A_arbace_o2j__init_A_const_pool.A[225]; A_arbace_o2j__init_A_const_124 = A_arbace_o2j__init_A_const_pool.A[226]; A_arbace_o2j__init_A_const_125 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[227]); A_arbace_o2j__init_A_const_126 = A_arbace_o2j__init_A_const_pool.A[228]; A_arbace_o2j__init_A_const_127 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[229]); A_arbace_o2j__init_A_const_128 = A_arbace_o2j__init_A_const_pool.A[230]; A_arbace_o2j__init_A_const_129 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[231]); A_arbace_o2j__init_A_const_130 = A_arbace_o2j__init_A_const_pool.A[232]; A_arbace_o2j__init_A_const_131 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[233]); A_arbace_o2j__init_A_const_132 = A_arbace_o2j__init_A_const_pool.A[234] }

func A_arbace_o2j__init_A_clinit_p10() { A_arbace_o2j__init_A_const_133 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[235]); A_arbace_o2j__init_A_const_134 = A_arbace_o2j__init_A_const_pool.A[236]; A_arbace_o2j__init_A_const_135 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[237]); A_arbace_o2j__init_A_const_136 = A_arbace_o2j__init_A_const_pool.A[238]; A_arbace_o2j__init_A_const_137 = lang.Var_Cast(A_arbace_o2j__init_A_const_pool.A[239]); A_arbace_o2j__init_A_const_138 = A_arbace_o2j__init_A_const_pool.A[240] }

func A_arbace_o2j__init_A_New() *A_arbace_o2j__init_A { A_arbace_o2j__init_A_Init(); t := &A_arbace_o2j__init_A{}; t.Ctor(); return t }

func (t *A_arbace_o2j__init_A) Ctor() {}

func (t *A_arbace_o2j__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_o2j__init_A) GetClass__Class() *jrt.Class { return A_arbace_o2j__init_A_class }

func (t *A_arbace_o2j__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_o2j__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_o2j__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_o2j__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_o2j__init_A); return ok }

func A_arbace_o2j__init_A_Cast(x any) *A_arbace_o2j__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_o2j__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_o2j__init_A_class)) }; return v }
