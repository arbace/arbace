//line j2g_strings.ae:1
package aot_arbace_o2j

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,iokn3,docyn4,primkn6,modulekn4,sizekn8,requiredkn4,codekn4,nameys5,ocaml6,lambdakn4,headkn4,filekn4,elseyn8,defclassyn6,methodks10,arbace.o2j3,eofkn3,eofkn1,nkn5,classkn7,missingys6,Double16,longBitsToDoubleyn9,immstringyn11,float-arrayyn5,floatyn9,nativeintkn5,constys11,ocaml.rt.Rt1,syn3,newys6,double1,1ys6,Double7,valueOfyn5,blockyn14,ocaml.rt.NInt.yn5,int32ys11,ocaml.rt.Rt5,blockyn13,unchecked-intys6,Object1,1yn4,charys7,Integer7,valueOfyn5,int64ys4,Long7,valueOfyn3,intyn13,ocaml.rt.I64.kn6,constsyn3,foryn6,mutletyn3,letyn3,varyn6,letrecyn11,staticcatchyn5,constyn6,mutvaryn8,functionyn7,trywithyn6,assignkn3,envkn2,idys11,ocaml.rt.Rt2,fnyn2,ifyn2,==yn7,.-arityys11,ocaml.rt.Rt2,apkn4,selfkn5,arityyn8,continuekn5,labelkn4,usedkn6,publicyn4,thisyn2,ankn3,tagyn4,agetkn5,exitsyn5,labelyn4,loopkn6,tupledkn7,classeskn6,statickn7,extendsyn16,ocaml.rt.Closureyn5,fieldyn11,constructoryn6,super.yn4,set!yn2,dokn7,mutableyn6,Objectyn5,throwyn7,missingyn1,byn3,notyn6,offsetyn1,tyn2,iiyn8,setFieldyn12,compareBintsyn3,dupyn10,floatFieldyn13,setFloatFieldyn9,bintOfIntyn4,bintyn3,mkbyn2,bvyn5,alenvyn9,makeArrayyn11,agetCheckedyn11,asetCheckedyn4,asetyn4,slenyn4,sgetyn11,sgetCheckedyn4,ssetyn11,ssetCheckedyn5,sloadyn6,sstoreyn11,sysConstantys11,ocaml.rt.Rt8,setFieldyn15,ocaml.rt.Block.yn13,ocaml.rt.Exn.yn11,unsupportedyn3,andyn2,oryn6,switchyn5,.-tagyn4,castyn14,ocaml.rt.Blockyn5,breakyn9,instance?yn4,Longyn2,jskn4,varsyn3,tryyn5,catchyn9,Throwableyn8,exnValuekn2,toyn4,whenyn2,<=yn2,>=yn1,lyn4,longyn5,recuryn13,unchecked-incyn13,unchecked-decyn8,sequenceyn4,sendyn12,stringswitchyn9,getMethodyn5,eventyn10,ifthenelseyn5,applyyn6,ifusedyn5,whileyn11,staticraiseyn1,Gkn5,finalyn4,inityn4,voidyn2,nsyn7,ocaml.ukn6,importyn8,ocaml.rtyn2,Rtyn5,Blockyn7,Closureyn3,Exnyn7,M__mainyn5,initsyn8,Runnableyn6,lambdayn4,mainyn4,argsys6,String1,1ys6,System4,exitys13,ocaml.rt.Main3,runys15,ocaml.u.M__main5,initskn4,unitkn5,orderkn4,depsv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn10,arbace.o2jm2,R6,s1821,o2j, OCaml's Lambda → Java forms (doc/ocaml/OCAML-SURVEY.md, O6 and OC7 (a); \"As built: O6\n  (write-ahead)\"): a unit's Lambda dump (tools/ocdump's, SPEC §11.2: the bytecode translation,\n  simplified, OC60) becomes one Java form, the class ocaml.u.M_<Unit>, against the runtime\n  ocaml.rt (jdk/ocaml/: values, primitives, externals); a program's units in link order get a\n  main class, ocaml.u.M__main. The Java forms are what j2g translates for the compiled level and\n  what the Java forms' interpreter runs at the light level (test/ocaml/o2j/run.ae).\n\n  The translation (OC82-OC86):\n  - a unit's module block is the static field G, its initialisation the static method init;\n    the constants are static fields; a global is the unit's G, a predefined exception Rt's field;\n  - a Lambda function is a member class of the unit's (F<n>, extends Closure), its free\n    variables as fields given to its constructor, its code the method a<arity> (an above six);\n    a letrec's closures are made first and their fields that name each other set after;\n  - an application calls a<n> when the closure's arity is the argument count, else Rt/ap;\n    the arguments (and then the function) are evaluated right to left, as ocamlc's code does;\n    a function's application of itself in tail position is a loop (continue), other tail\n    calls are calls (OC84);\n  - staticcatch is a label around the body, the exit a break to it, its variables mutable locals;\n    a switch is Java's switch on the int or the block's tag; trywith catches every Throwable\n    and asks Rt/exnValue for the OCaml exception (the Java stack's overflow is Stack_overflow);\n  - the primitives are Rt's methods; the externals (\"caml_...\") the Ext classes' static\n    methods of the same name and argument count, or a throw of Rt/missing when the runtime has none.v14,arbace.java.io6,readerv11,arbace.core4,readv11,arbace.core6,secondR7,v13,arbace.string12,starts-with?v11,arbace.core4,subsl10,R8,R9,R10,R11,R12,v13,arbace.string7,replacep2,!$p4,/.*$v11,arbace.core4,seq?R13,v11,arbace.core5,firstv11,arbace.core7,ex-infoR14,R15,v11,arbace.core3,strv11,arbace.core4,restv11,arbace.core3,seqv11,arbace.core4,map?v11,arbace.core4,lastv11,arbace.core7,butlastv11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core3,mapv10,arbace.o2j7,realizev11,arbace.core7,vector?v11,arbace.core4,mapvR16,v11,arbace.core6,symbolp13,[^A-Za-z0-9_]p2,!$p4,/.*$v11,arbace.core4,intov13,arbace.string10,ends-with?R17,v10,arbace.o2j2,hdv11,arbace.core4,namev11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferR18,v11,arbace.core6,filterv11,arbace.core4,dropl2,v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core6,concatv11,arbace.core5,doallv11,arbace.core10,take-whilev11,arbace.core4,not=R19,v11,arbace.core10,repeatedlym2,R20,R19,v11,arbace.core7,sort-byv11,arbace.core14,alter-var-rootv10,arbace.o2j11,*externals*v11,arbace.core10,constantlyv10,arbace.o2j17,runtime-externalsv14,arbace.java.io4,filev11,arbace.core5,swap!R21,v10,arbace.o2j6,*unit*v11,arbace.core3,incR22,R23,v11,arbace.core6,updatev11,arbace.core4,fnill0,v11,arbace.core7,string?v11,arbace.core7,re-findp8,^-?0[xX]v11,arbace.core3,notp4,[pP]R24,R25,R26,R27,R28,R29,R30,v10,arbace.o2j6,latin1R31,R32,v10,arbace.o2j11,double-formv10,arbace.o2j11,parse-floatR33,R34,R35,R36,R37,R38,R31,R39,v10,arbace.o2j10,const-initR40,R41,R38,R42,R43,R44,R45,S2,R40,R44,v10,arbace.o2j5,freshv10,arbace.o2j10,unit-classR43,R46,v11,arbace.core9,volatile!v10,arbace.o2j9,node-bodyR47,R48,R49,l1,R49,R50,R51,R52,v11,arbace.core4,nextR53,R54,R55,R56,R57,v10,arbace.o2j14,bound-and-refsv11,arbace.core4,sortv11,arbace.core6,removeR58,R59,R50,R53,R7,v10,arbace.o2j7,simple?v11,arbace.core12,keep-indexedv11,arbace.core3,setv11,arbace.core3,vecv11,arbace.core11,map-indexedv10,arbace.o2j4,exprv11,arbace.core6,mapcatv11,arbace.core7,reverseR49,v11,arbace.core2,<=l6,R49,R60,R61,R62,R63,R64,R31,R39,R64,R31,R39,R65,R50,R66,v10,arbace.o2j9,with-argsR67,R68,v10,arbace.o2j9,call-formv11,arbace.core6,reset!R69,R18,m2,R70,TV1,R71,R18,R72,m2,R70,TR71,m2,R73,R39,R49,R74,v11,arbace.core5,rangev10,arbace.o2j8,free-idsv11,arbace.core4,compv10,arbace.o2j8,munge-idv11,arbace.core5,mergeR71,v11,arbace.core4,atomv11,arbace.core7,keywordR75,R76,R77,R78,R79,R17,m4,R70,TR80,TR81,R82,R83,m2,R70,Tm2,R70,TR84,V1,R71,m2,R70,TR85,R86,R71,v10,arbace.o2j10,method-forv10,arbace.o2j14,closure-class!v10,arbace.o2j6,lookupR49,R87,R86,R49,R48,m4,R88,TR73,R89,v11,arbace.core8,assoc-inR49,v13,arbace.string5,splitv13,arbace.string4,trimp3,\\s+l13,v13,arbace.string9,includes?v10,arbace.o2j13,note-missing!R90,v10,arbace.o2j2,rtR91,R90,R91,p5,[ \\[]v10,arbace.o2j7,int-opsv10,arbace.o2j8,test-opsR92,v10,arbace.o2j16,negated-test-opsR92,R93,v11,arbace.core10,re-matchesp7,-?\\d+\\+R94,R92,R93,R95,S2,s11,makemutables9,makeblockv10,arbace.o2j7,num-argR34,R38,R31,R39,R34,l254,R31,R39,S3,s9,field_imms9,field_ints9,field_mutR83,R38,R83,R96,R97,R96,R98,R99,R97,R96,R97,R38,R100,R38,R101,R96,R101,R38,v10,arbace.o2j10,bint-kindsR102,R103,v11,arbace.core5,some?p50,(int32|int64|nativeint)_of_(int32|int64|nativeint)R104,v10,arbace.o2j10,bint-namesp4,_of_R105,R106,S2,s13,makearray_imms9,makearrayR107,v10,arbace.o2j10,array-kindR31,R39,R108,R74,R109,R110,S2,s13,string.lengths12,bytes.lengthR111,S2,s16,bytes.unsafe_gets17,string.unsafe_getR112,S2,s9,bytes.gets10,string.getR113,R114,R115,p39,(string|bytes)\\.(unsafe_)?get(16|32|64)R116,p4,\\d+$p30,bytes\\.(unsafe_)?set(16|32|64)R117,p4,\\d+$S5,s15,bytes_of_strings9,obj_magics15,bytes_to_strings6,opaques14,int_as_pointerS3,s7,reraises13,raise_notraces5,raiseR118,R83,v10,arbace.o2j8,externalv10,arbace.o2j4,UNITv10,arbace.o2j12,effect-primsv10,arbace.o2j12,bigarray-extR119,R94,R83,l3,R120,l246,R31,R39,R120,l250,R31,R39,p2,\\.p2,\\.R87,R90,R121,R90,R122,v10,arbace.o2j11,global-namel7,v10,arbace.o2j7,predefsv10,arbace.o2j10,class-nameS4,s2,&&s7,sequands6,sequors2,||R92,v10,arbace.o2j9,test-formR7,v10,arbace.o2j10,prim-valueR7,S2,s2,&&s7,sequandR7,S2,s6,sequors2,||R7,R7,R7,R93,R53,S2,R40,R44,R95,R123,R124,R93,R125,R96,R125,R126,R127,R128,R129,R61,R130,R131,R49,R76,R76,R129,R49,R125,R132,R133,v11,arbace.core6,zipmapR76,R49,m4,R88,TR73,R89,R76,R129,v11,arbace.core6,get-inv11,arbace.core8,to-arrayv11,arbace.core6,empty?R129,R49,R87,R86,R129,R134,R135,R136,R49,R137,R138,R49,R139,R140,R141,R142,R142,R77,m2,R73,R143,R142,R49,R43,R139,R93,R62,R142,R144,R145,R146,R147,v10,arbace.o2j11,flatten-seqR148,R149,v10,arbace.o2j17,stringswitch-nodeR147,R87,R52,v10,arbace.o2j16,staticcatch-nodeR49,R150,R53,v10,arbace.o2j10,const-formR56,v10,arbace.o2j12,trywith-nodeR7,v10,arbace.o2j9,prim-nodeR151,R152,R57,R61,R50,R87,R86,R55,v10,arbace.o2j13,function-nodeR153,v10,arbace.o2j10,apply-nodeR51,v10,arbace.o2j11,letrec-nodeR154,R125,v10,arbace.o2j11,switch-nodeR54,R47,v10,arbace.o2j8,for-nodeR48,v10,arbace.o2j9,let-chainR49,R155,R156,v10,arbace.o2j16,staticraise-nodeR87,R155,R17,m2,R70,TR83,R157,m4,R70,TR80,TR83,m6,R70,TR80,TR158,Tm6,R70,TR80,TR158,TR18,R159,m4,R70,TR80,Tm2,R73,R160,R86,R157,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapR161,R162,R163,R164,R165,R166,R167,R168,R161,R162,R17,R169,m2,R70,TR18,R170,m4,R70,TR80,Tm2,R73,R171,R172,R171,V1,nR18,R173,m4,R70,TR80,TR174,m2,R73,R175,m2,R73,R160,R176,R177,R174,R178,v14,arbace.java.io6,writerv14,arbace.java.io12,make-parentsv11,arbace.core5,*out*v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core7,printlnv11,arbace.core3,prnv11,arbace.core7,newlinev11,arbace.core4,disjv11,arbace.core4,run!R7,v11,arbace.core7,filtervv11,arbace.core9,contains?R179,v10,arbace.o2j9,unit-refsv11,arbace.core11,read-stringv11,arbace.core5,slurpR180,R181,v10,arbace.o2j9,read-dumpv10,arbace.o2j4,linkv11,arbace.core4,spitv13,arbace.string4,joinv10,arbace.o2j11,write-formsv10,arbace.o2j10,main-formsv10,arbace.o2j14,translate-unitv13,arbace.string11,split-linesv11,arbace.core9,partitionv11,arbace.core6,pr-strv10,arbace.o2j17,translate-programv10,arbace.o2j15,load-externals!p2,\\tp3,\\s+")

var Lit_1 *jrt.String = jrt.Intern("O2J_RT")

var Lit_2 *jrt.String = jrt.Intern("jdk/ocaml/ocaml/rt")

var Lit_3 *jrt.String = jrt.Intern("progs")

var Lit_4 *jrt.String = jrt.Intern("arbace.o2j$_main$fn__1641000555")

var Lit_5 *jrt.String = jrt.Intern("arbace.o2j$_main$fn__1641000560")

var Lit_6 *jrt.String = jrt.Intern("unit")

var Lit_7 *jrt.String = jrt.Intern("Translated by arbace.o2j from the Lambda of ")

var Lit_8 *jrt.String = jrt.Intern(". Regenerate rather than edit.")

var Lit_9 *jrt.String = jrt.Intern("missing\t")

var Lit_10 *jrt.String = jrt.Intern("\t")

var Lit_11 *jrt.String = jrt.Intern("lib")

var Lit_12 *jrt.String = jrt.Intern("order.txt")

var Lit_13 *jrt.String = jrt.Intern("arbace.o2j$_main$iter__1641000601__1641000605")

var Lit_14 *jrt.String = jrt.Intern("deps.edn")

var Lit_15 *jrt.String = jrt.Intern("prog")

var Lit_16 *jrt.String = jrt.Intern("main")

var Lit_17 *jrt.String = jrt.Intern("The program's main class, by arbace.o2j.")

var Lit_18 *jrt.String = jrt.Intern("usage: o2j lib LAMBDA-DIR OUT-DIR | prog LIB-OUT OUT-DIR DUMP... | unit DUMP OUT [DUMP OUT...] | main OUT UNIT...")

var Lit_19 *jrt.String = jrt.Intern("refused\t")

var Lit_20 *jrt.String = jrt.Intern(" ")

var Lit_21 *jrt.String = jrt.Intern("arbace.o2j$_main$iter__1641000601__1641000605$fn__1641000606")

var Lit_22 *jrt.String = jrt.Intern("arbace.o2j$_main$iter__1641000601__1641000605$fn__1641000606$fn__1641000607")

var Lit_23 *jrt.String = jrt.Intern(".ae")

var Lit_24 *jrt.String = jrt.Intern("arbace.o2j$apply_node$fn__1641000187")

var Lit_25 *jrt.String = jrt.Intern("arbace.o2j$apply_node$fn__1641000189")

var Lit_26 *jrt.String = jrt.Intern("arbace.o2j$apply_node$fn__1641000191")

var Lit_27 *jrt.String = jrt.Intern("[")

var Lit_28 *jrt.String = jrt.Intern("gen")

var Lit_29 *jrt.String = jrt.Intern("]")

var Lit_30 *jrt.String = jrt.Intern("Bigarray.dim_")

var Lit_31 *jrt.String = jrt.Intern("caml_ba_dim_")

var Lit_32 *jrt.String = jrt.Intern("get16")

var Lit_33 *jrt.String = jrt.Intern("caml_ba_uint8_get16")

var Lit_34 *jrt.String = jrt.Intern("get32")

var Lit_35 *jrt.String = jrt.Intern("caml_ba_uint8_get32")

var Lit_36 *jrt.String = jrt.Intern("get64")

var Lit_37 *jrt.String = jrt.Intern("caml_ba_uint8_get64")

var Lit_38 *jrt.String = jrt.Intern("set16")

var Lit_39 *jrt.String = jrt.Intern("caml_ba_uint8_set16")

var Lit_40 *jrt.String = jrt.Intern("set32")

var Lit_41 *jrt.String = jrt.Intern("caml_ba_uint8_set32")

var Lit_42 *jrt.String = jrt.Intern("set64")

var Lit_43 *jrt.String = jrt.Intern("caml_ba_uint8_set64")

var Lit_44 *jrt.String = jrt.Intern("get")

var Lit_45 *jrt.String = jrt.Intern("caml_ba_get_")

var Lit_46 *jrt.String = jrt.Intern("set")

var Lit_47 *jrt.String = jrt.Intern("caml_ba_set_")

var Lit_48 *jrt.String = jrt.Intern("arbace.o2j$bound_and_refs$walk__1641000085")

var Lit_49 *jrt.String = jrt.Intern("arbace.o2j$bound_and_refs$walk_any__1641000149")

var Lit_50 *jrt.String = jrt.Intern("c$")

var Lit_51 *jrt.String = jrt.Intern(".a")

var Lit_52 *jrt.String = jrt.Intern("M_")

var Lit_53 *jrt.String = jrt.Intern("F")

var Lit_54 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$fn__1641000201")

var Lit_55 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$fn__1641000203")

var Lit_56 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$fn__1641000206")

var Lit_57 *jrt.String = jrt.Intern("self")

var Lit_58 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$fn__1641000211")

var Lit_59 *jrt.String = jrt.Intern("tupled function")

var Lit_60 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000213__1641000217")

var Lit_61 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000223__1641000227")

var Lit_62 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000213__1641000217$fn__1641000218")

var Lit_63 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000213__1641000217$fn__1641000218$fn__1641000219")

var Lit_64 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000223__1641000227$fn__1641000228")

var Lit_65 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_$iter__1641000223__1641000227$fn__1641000228$fn__1641000229")

var Lit_66 *jrt.String = jrt.Intern(".-")

var Lit_67 *jrt.String = jrt.Intern("k")

var Lit_68 *jrt.String = jrt.Intern("arbace.o2j$const_init$fn__1641000075")

var Lit_69 *jrt.String = jrt.Intern("constant ")

var Lit_70 *jrt.String = jrt.Intern("java.io.File")

var Lit_71 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_72 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_73 *jrt.String = jrt.Intern("arbace.o2j$expr$fn__1641000416")

var Lit_74 *jrt.String = jrt.Intern("o$")

var Lit_75 *jrt.String = jrt.Intern("m$")

var Lit_76 *jrt.String = jrt.Intern("arbace.o2j$expr$fn__1641000418")

var Lit_77 *jrt.String = jrt.Intern("arbace.o2j$expr$fn__1641000420")

var Lit_78 *jrt.String = jrt.Intern("Lambda node ")

var Lit_79 *jrt.String = jrt.Intern(" not known")

var Lit_80 *jrt.String = jrt.Intern("t$")

var Lit_81 *jrt.String = jrt.Intern("/")

var Lit_82 *jrt.String = jrt.Intern("lo$")

var Lit_83 *jrt.String = jrt.Intern("hi$")

var Lit_84 *jrt.String = jrt.Intern("i$")

var Lit_85 *jrt.String = jrt.Intern(".")

var Lit_86 *jrt.String = jrt.Intern("arbace.o2j$function_node$fn__1641000238")

var Lit_87 *jrt.String = jrt.Intern("")

var Lit_88 *jrt.String = jrt.Intern("arbace.o2j$latin1$fn__1641000065")

var Lit_89 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000246__1641000250")

var Lit_90 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000256__1641000260")

var Lit_91 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$fn__1641000279")

var Lit_92 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000286__1641000292")

var Lit_93 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$fn__1641000279$fn__1641000283")

var Lit_94 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000246__1641000250$fn__1641000251")

var Lit_95 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000246__1641000250$fn__1641000251$fn__1641000252")

var Lit_96 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000256__1641000260$fn__1641000261")

var Lit_97 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000256__1641000260$fn__1641000261$fn__1641000262")

var Lit_98 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000286__1641000292$fn__1641000293")

var Lit_99 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000286__1641000292$fn__1641000293$iter__1641000288__1641000297")

var Lit_100 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000286__1641000292$fn__1641000293$iter__1641000288__1641000297$fn__1641000298")

var Lit_101 *jrt.String = jrt.Intern("arbace.o2j$letrec_node$iter__1641000286__1641000292$fn__1641000293$iter__1641000288__1641000297$fn__1641000298$fn__1641000299")

var Lit_102 *jrt.String = jrt.Intern("arbace.o2j$link$visit__1641000477")

var Lit_103 *jrt.String = jrt.Intern("no unit ")

var Lit_104 *jrt.String = jrt.Intern(" in the library")

var Lit_105 *jrt.String = jrt.Intern("unbound Lambda variable ")

var Lit_106 *jrt.String = jrt.Intern("arbace.o2j$main_forms$iter__1641000458__1641000462")

var Lit_107 *jrt.String = jrt.Intern("arbace.o2j$main_forms$iter__1641000458__1641000462$fn__1641000463")

var Lit_108 *jrt.String = jrt.Intern("arbace.o2j$main_forms$iter__1641000458__1641000462$fn__1641000463$fn__1641000464")

var Lit_109 *jrt.String = jrt.Intern("ocaml.u.")

var Lit_110 *jrt.String = jrt.Intern("init")

var Lit_111 *jrt.String = jrt.Intern("a")

var Lit_112 *jrt.String = jrt.Intern("args$")

var Lit_113 *jrt.String = jrt.Intern("arbace.o2j$method_for$fn__1641000194")

var Lit_114 *jrt.String = jrt.Intern("_")

var Lit_115 *jrt.String = jrt.Intern("p0")

var Lit_116 *jrt.String = jrt.Intern("global ")

var Lit_117 *jrt.String = jrt.Intern("ocaml.rt.Rt")

var Lit_118 *jrt.String = jrt.Intern("G")

var Lit_119 *jrt.String = jrt.Intern("arbace.o2j$prim_node$fn__1641000331")

var Lit_120 *jrt.String = jrt.Intern("+:=")

var Lit_121 *jrt.String = jrt.Intern("not")

var Lit_122 *jrt.String = jrt.Intern("makefloatblock")

var Lit_123 *jrt.String = jrt.Intern("makelazyblock")

var Lit_124 *jrt.String = jrt.Intern("makeforwardblock")

var Lit_125 *jrt.String = jrt.Intern("field_computed")

var Lit_126 *jrt.String = jrt.Intern("setfield_computed")

var Lit_127 *jrt.String = jrt.Intern("compare_bints")

var Lit_128 *jrt.String = jrt.Intern("duparray")

var Lit_129 *jrt.String = jrt.Intern("setfield_")

var Lit_130 *jrt.String = jrt.Intern("computed")

var Lit_131 *jrt.String = jrt.Intern("floatfield")

var Lit_132 *jrt.String = jrt.Intern("setfloatfield")

var Lit_133 *jrt.String = jrt.Intern("of_int")

var Lit_134 *jrt.String = jrt.Intern("array.length")

var Lit_135 *jrt.String = jrt.Intern("array.get")

var Lit_136 *jrt.String = jrt.Intern("array.unsafe_get")

var Lit_137 *jrt.String = jrt.Intern("array.set")

var Lit_138 *jrt.String = jrt.Intern("array.unsafe_set")

var Lit_139 *jrt.String = jrt.Intern("bytes.unsafe_set")

var Lit_140 *jrt.String = jrt.Intern("bytes.set")

var Lit_141 *jrt.String = jrt.Intern("ignore")

var Lit_142 *jrt.String = jrt.Intern("sys.constant_")

var Lit_143 *jrt.String = jrt.Intern("atomic_load")

var Lit_144 *jrt.String = jrt.Intern("dls_get")

var Lit_145 *jrt.String = jrt.Intern("caml_domain_dls_get")

var Lit_146 *jrt.String = jrt.Intern("poll")

var Lit_147 *jrt.String = jrt.Intern("ocaml.rt.Effects")

var Lit_148 *jrt.String = jrt.Intern("Bigarray.")

var Lit_149 *jrt.String = jrt.Intern("bigarray.")

var Lit_150 *jrt.String = jrt.Intern("caml_")

var Lit_151 *jrt.String = jrt.Intern("%")

var Lit_152 *jrt.String = jrt.Intern("arbace.o2j$read_dump$fn__1641000012")

var Lit_153 *jrt.String = jrt.Intern("not a Lambda dump: ")

var Lit_154 *jrt.String = jrt.Intern("setglobal ")

var Lit_155 *jrt.String = jrt.Intern("the unit's code is not a setglobal")

var Lit_156 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037")

var Lit_157 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$fn__1641000057")

var Lit_158 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038")

var Lit_159 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$iter__1641000031__1641000039")

var Lit_160 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$fn__1641000049")

var Lit_161 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$fn__1641000049$fn__1641000050")

var Lit_162 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$fn__1641000049$fn__1641000052")

var Lit_163 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$iter__1641000031__1641000039$fn__1641000040")

var Lit_164 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$iter__1641000031__1641000039$fn__1641000040$iter__1641000033__1641000041")

var Lit_165 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$iter__1641000031__1641000039$fn__1641000040$iter__1641000033__1641000041$fn__1641000042")

var Lit_166 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals$iter__1641000029__1641000037$fn__1641000038$iter__1641000031__1641000039$fn__1641000040$iter__1641000033__1641000041$fn__1641000042$fn__1641000043")

var Lit_167 *jrt.String = jrt.Intern("ocaml.rt.")

var Lit_168 *jrt.String = jrt.Intern("field_imm ")

var Lit_169 *jrt.String = jrt.Intern("exit")

var Lit_170 *jrt.String = jrt.Intern("arbace.o2j$staticcatch_node$fn__1641000382")

var Lit_171 *jrt.String = jrt.Intern("arbace.o2j$staticcatch_node$fn__1641000384")

var Lit_172 *jrt.String = jrt.Intern("h$")

var Lit_173 *jrt.String = jrt.Intern("exit ")

var Lit_174 *jrt.String = jrt.Intern(" not in scope")

var Lit_175 *jrt.String = jrt.Intern("arbace.o2j$staticraise_node$fn__1641000393")

var Lit_176 *jrt.String = jrt.Intern("arbace.o2j$staticraise_node$fn__1641000395")

var Lit_177 *jrt.String = jrt.Intern("arbace.o2j$staticraise_node$fn__1641000397")

var Lit_178 *jrt.String = jrt.Intern("s$")

var Lit_179 *jrt.String = jrt.Intern("arbace.o2j$stringswitch_node$fn__1641000369")

var Lit_180 *jrt.String = jrt.Intern("fail")

var Lit_181 *jrt.String = jrt.Intern("sw")

var Lit_182 *jrt.String = jrt.Intern("arbace.o2j$switch_node$cases__1641000355")

var Lit_183 *jrt.String = jrt.Intern("arbace.o2j$switch_node$cases__1641000355$fn__1641000357")

var Lit_184 *jrt.String = jrt.Intern("arbace.o2j$test_form$fn__1641000343")

var Lit_185 *jrt.String = jrt.Intern("arbace.o2j$test_form$fn__1641000348")

var Lit_186 *jrt.String = jrt.Intern("arbace.o2j$translate_program$fn__1641000487")

var Lit_187 *jrt.String = jrt.Intern("M__main.ae")

var Lit_188 *jrt.String = jrt.Intern("files.txt")

var Lit_189 *jrt.String = jrt.Intern("\n")

var Lit_190 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000519__1641000523")

var Lit_191 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000529__1641000533")

var Lit_192 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000519__1641000523$fn__1641000524")

var Lit_193 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000519__1641000523$fn__1641000524$fn__1641000525")

var Lit_194 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000529__1641000533$fn__1641000534")

var Lit_195 *jrt.String = jrt.Intern("arbace.o2j$translate_program$iter__1641000529__1641000533$fn__1641000534$fn__1641000535")

var Lit_196 *jrt.String = jrt.Intern("arbace.o2j$translate_unit$iter__1641000441__1641000445")

var Lit_197 *jrt.String = jrt.Intern("arbace.o2j$translate_unit$iter__1641000441__1641000445$fn__1641000446")

var Lit_198 *jrt.String = jrt.Intern("arbace.o2j$translate_unit$iter__1641000441__1641000445$fn__1641000446$fn__1641000447")

var Lit_199 *jrt.String = jrt.Intern("e$")

var Lit_200 *jrt.String = jrt.Intern("arbace.o2j$unit_refs$walk__1641000474")

var Lit_201 *jrt.String = jrt.Intern("arbace.o2j$with_args$fn__1641000165")

var Lit_202 *jrt.String = jrt.Intern("arbace.o2j$with_args$iter__1641000167__1641000171")

var Lit_203 *jrt.String = jrt.Intern("arbace.o2j$with_args$fn__1641000177")

var Lit_204 *jrt.String = jrt.Intern("arbace.o2j$with_args$fn__1641000179")

var Lit_205 *jrt.String = jrt.Intern("arbace.o2j$with_args$iter__1641000167__1641000171$fn__1641000172")

var Lit_206 *jrt.String = jrt.Intern("arbace.o2j$with_args$iter__1641000167__1641000171$fn__1641000172$fn__1641000173")

var Lit_207 *jrt.String = jrt.Intern(";; ")

var Lit_208 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn4,Filekn4,linekn6,columnkn4,filekn7,privateyn1,xyn1,myn6,Stringkn7,dynamicyn3,diryn6,prefixyn1,nys11,ocaml.rt.Rt4,UNITyn1,syn6,doubleyn1,ckn8,declaredyn1,fyn3,ctxyn2,idyn5,nodesyn1,kyn4,argsyn5,tail?yn5,arityyn6,paramsyn4,bodyyn7,self-idyn2,bsyn1,&yn10,floatOfIntyn3,mulyn4,fdivyn4,fnegyn10,intOfFloatyn3,negyn4,fmulyn3,divyn4,faddyn3,subyn3,dupyn3,modyn3,lsryn3,lslyn7,bswap16yn11,compareIntsyn12,compareBintsyn3,loryn4,fabsyn4,landyn3,asryn4,fsubyn3,addyn4,lxoryn13,compareFloatsyn3,fgtyn5,isintyn2,leyn5,isoutyn3,fltyn3,feqyn3,fleyn2,geyn2,ltyn2,eqyn3,fgeyn2,gtyn5,nargsyn4,nameyn7,performyn8,runstackyn6,resumeyn9,reperformyn2,asyn5,scrutyn2,ncyn6,constsyn2,nbyn6,blocksyn4,failyn5,casesyn4,dfltyn4,varsyn7,handleryn2,loyn2,hikn4,keysyn4,codeyn5,unitsyn5,formsyn6,headeryn1,uyn9,lib-orderyn4,depsyn10,prog-unitsyn2,odyn5,dumpsyn3,cmdv11,arbace.core5,in-nsMyn10,arbace.o2jm2,R0,s1821,o2j, OCaml's Lambda → Java forms (doc/ocaml/OCAML-SURVEY.md, O6 and OC7 (a); \"As built: O6\n  (write-ahead)\"): a unit's Lambda dump (tools/ocdump's, SPEC §11.2: the bytecode translation,\n  simplified, OC60) becomes one Java form, the class ocaml.u.M_<Unit>, against the runtime\n  ocaml.rt (jdk/ocaml/: values, primitives, externals); a program's units in link order get a\n  main class, ocaml.u.M__main. The Java forms are what j2g translates for the compiled level and\n  what the Java forms' interpreter runs at the light level (test/ocaml/o2j/run.ae).\n\n  The translation (OC82-OC86):\n  - a unit's module block is the static field G, its initialisation the static method init;\n    the constants are static fields; a global is the unit's G, a predefined exception Rt's field;\n  - a Lambda function is a member class of the unit's (F<n>, extends Closure), its free\n    variables as fields given to its constructor, its code the method a<arity> (an above six);\n    a letrec's closures are made first and their fields that name each other set after;\n  - an application calls a<n> when the closure's arity is the argument count, else Rt/ap;\n    the arguments (and then the function) are evaluated right to left, as ocamlc's code does;\n    a function's application of itself in tail position is a loop (continue), other tail\n    calls are calls (OC84);\n  - staticcatch is a label around the body, the exit a break to it, its variables mutable locals;\n    a switch is Java's switch on the int or the block's tag; trywith catches every Throwable\n    and asks Rt/exnValue for the OCaml exception (the Java stack's overflow is Stack_overflow);\n  - the primitives are Rt's methods; the externals (\"caml_...\") the Ext classes' static\n    methods of the same name and argument count, or a throw of Rt/missing when the runtime has none.m2,R0,s1821,o2j, OCaml's Lambda → Java forms (doc/ocaml/OCAML-SURVEY.md, O6 and OC7 (a); \"As built: O6\n  (write-ahead)\"): a unit's Lambda dump (tools/ocdump's, SPEC §11.2: the bytecode translation,\n  simplified, OC60) becomes one Java form, the class ocaml.u.M_<Unit>, against the runtime\n  ocaml.rt (jdk/ocaml/: values, primitives, externals); a program's units in link order get a\n  main class, ocaml.u.M__main. The Java forms are what j2g translates for the compiled level and\n  what the Java forms' interpreter runs at the light level (test/ocaml/o2j/run.ae).\n\n  The translation (OC82-OC86):\n  - a unit's module block is the static field G, its initialisation the static method init;\n    the constants are static fields; a global is the unit's G, a predefined exception Rt's field;\n  - a Lambda function is a member class of the unit's (F<n>, extends Closure), its free\n    variables as fields given to its constructor, its code the method a<arity> (an above six);\n    a letrec's closures are made first and their fields that name each other set after;\n  - an application calls a<n> when the closure's arity is the argument count, else Rt/ap;\n    the arguments (and then the function) are evaluated right to left, as ocamlc's code does;\n    a function's application of itself in tail position is a loop (continue), other tail\n    calls are calls (OC84);\n  - staticcatch is a label around the body, the exit a break to it, its variables mutable locals;\n    a switch is Java's switch on the int or the block's tag; trywith catches every Throwable\n    and asks Rt/exnValue for the OCaml exception (the Java stack's overflow is Stack_overflow);\n  - the primitives are Rt's methods; the externals (\"caml_...\") the Ext classes' static\n    methods of the same name and argument count, or a throw of Rt/missing when the runtime has none.R1,v10,arbace.o2j9,read-dumpm10,R2,L1,V1,Myn1,fm2,R3,R4,R0,s53,A Lambda dump: {:module :name :size :required :code}.R5,i31,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,node-bodym12,R8,TR2,L1,V1,R9,R0,s68,A node's fields: the form less its head and a trailing metadata map.R5,i44,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j7,realizem12,R8,TR2,L1,V1,R9,R0,s76,x with every lazy sequence in it realized (they read *unit*), metadata kept.R5,i49,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j2,hdm10,R8,TR2,L1,V1,R9,R5,i56,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j7,predefsS12,s9,Sys_errors26,Undefined_recursive_modules9,Not_founds14,Stack_overflows11,End_of_files16,Division_by_zeros7,Failures16,Invalid_arguments13,Out_of_memorys14,Sys_blocked_ios14,Assert_failures13,Match_failurem6,R5,i61,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,class-namem10,R2,L1,V1,R10,R0,s25,The Java class of unit M.R5,i66,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j8,munge-idm10,R8,TR2,L1,V1,Myn2,idm2,R3,R11,R5,i68,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,global-namem10,R8,TR2,L1,V1,Myn1,sm2,R3,R11,R5,i70,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j17,runtime-externalsm12,R8,TR2,L1,V1,Myn3,dirm2,R3,R4,R0,s156,The externals the runtime's Java forms define: every public static method named caml_...\n  of a class of DIR (jdk/ocaml/ocaml/rt), with its parameter count.R5,i75,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,*externals*m8,R12,TR5,i91,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j15,load-externals!m8,R2,L1,V1,R13,R5,i93,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j6,*unit*m10,R12,TR5,i98,R6,i1,R7,s13,arbace/o2j.aeR0,s137,{:class sym, :name the unit, :n counter atom, :classes atom (member classes), :consts atom\n  ([sym init]...), :missing atom {name count}}v10,arbace.o2j5,freshm10,R8,TR2,L1,V1,R14,R5,i103,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,unit-classm10,R8,TR2,L1,V0,R5,i105,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j13,note-missing!m10,R8,TR2,L1,V1,R15,R5,i107,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j4,UNITR16,m8,R8,TR5,i112,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j6,latin1m12,R8,TR2,L1,V1,R17,R0,s83,A Java string of chars 0-255 from an immstring's payload (a string or byte values).R5,i114,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,parse-floatm10,R8,TR2,L1,V1,Myn1,tm2,R3,R11,R5,i121,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,double-formm10,R8,TR2,L1,V1,Myn1,dm2,R3,R18,R5,i126,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,const-initm12,R8,TR2,L1,V1,R19,R0,s77,The Java form that makes constant c (once: the unit's static field holds it).R5,i131,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,const-formm12,R8,TR2,L1,V1,R19,R0,s84,A constant as an expression: small ints inline, the rest a static field of the unit.R5,i147,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j8,free-idsm8,R20,TR5,i160,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j14,bound-and-refsm12,R8,TR2,L1,V1,R9,R0,s85,[bound refs]: the ids a node binds and those it refers to, nested functions included.R5,i162,R6,i1,R7,s13,arbace/o2j.aem12,R8,TR2,L1,V1,R21,R0,s60,The ids function node f refers to and does not bind, sorted.R5,i191,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j4,exprm8,R20,TR5,i200,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,test-formm8,R20,TR5,i200,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j6,lookupm10,R8,TR2,L1,V2,R22,R23,R5,i204,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j7,simple?m12,R8,TR2,L1,V1,R9,R0,s98,A node whose evaluation has no effect and reads nothing mutable: it may be evaluated out of order.R5,i208,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,with-argsm12,R8,TR2,L1,V3,R22,R24,R25,R0,s187,Evaluates arg nodes right to left (as ocamlc's code does) and calls (k forms): every argument\n  that is not simple but the leftmost such one is bound to a temporary first, from the right.R5,i218,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,call-formm12,R8,TR2,L1,V2,R21,R26,R0,s81,The application of function form f to argument forms (already evaluated, simple).R5,i231,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,apply-nodem10,R8,TR2,L1,V3,R22,V2,R21,R26,R27,R5,i243,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,method-form10,R8,TR2,L1,V3,R28,R29,R30,R5,i255,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j14,closure-class!m12,R8,TR2,L1,V3,R22,R21,R31,R0,s133,Defines the member class of function node f (its free variables fields, self-id's references\n  `this`); returns [class-sym free-ids].R5,i262,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j13,function-nodem10,R8,TR2,L1,V2,R22,R21,R5,i291,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,letrec-nodem10,R8,TR2,L1,V3,R22,V2,R32,R30,R27,R5,i295,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,let-chainm12,R8,TR2,L1,V3,R22,R9,R27,R0,s44,Consecutive let and mutlet nodes as one let.R5,i313,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j7,num-argm10,R8,TR2,L1,V1,Myn1,nm2,R3,R11,R5,i328,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j2,rtm10,R8,TR2,L1,V3,R10,R33,R26,R5,i330,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j7,int-opsm58,s12,float_of_intR34,s1,*R35,s2,/.R36,s2,~.R37,s12,int_of_floatR38,s1,~R39,s2,*.R40,s1,/R41,s2,+.R42,s1,-R43,s9,duprecordR44,s10,mod_unsafeR45,s3,lsrR46,s2,/uR41,s3,lslR47,s7,bswap16R48,s12,compare_intsR49,s13,compare_bintsR50,s2,orR51,s8,duparrayR44,s4,abs.R52,s3,andR53,s3,modR45,s3,asrR54,s2,-.R55,s1,+R56,s3,xorR57,s14,compare_floatsR58,s12,duparray_immR44,m8,R8,TR5,i332,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j8,test-opsm24,s2,>.R59,s5,isintR60,s2,<=R61,s5,isoutR62,s2,<.R63,s3,==.R64,s3,<=.R65,s2,>=R66,s1,<R67,s2,==R68,s3,>=.R69,s1,>R70,m8,R8,TR5,i339,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j16,negated-test-opsm12,s2,!=s2,==s3,!=.s3,==.s3,!<.s2,<.s4,!<=.s3,<=.s3,!>.s2,>.s4,!>=.s3,>=.m8,R8,TR5,i343,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,bint-kindsm6,s5,Int32l0,s5,Int64l1,s9,Nativeintl2,m8,R8,TR5,i345,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,bint-namesm6,s5,int32l0,s5,int64l1,s9,nativeintl2,m8,R8,TR5,i346,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,array-kindm10,R8,TR2,L1,V1,Myn1,nm2,R3,R11,R5,i348,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j12,bigarray-extm10,R8,TR2,L1,V2,Myn1,nm2,R3,R11,R71,R5,i351,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j8,externalm10,R8,TR2,L1,V2,R72,R26,R5,i364,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j12,effect-primsm8,s7,performR73,s8,runstackR74,s6,resumeR75,s9,reperformR76,m8,R8,TR5,i371,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,prim-valuem12,R8,TR2,L1,V2,Myn1,nm2,R3,R11,R77,R0,s88,The Java form of primitive n applied to argument forms as (already evaluated, in order).R5,i374,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,prim-nodem10,R8,TR2,L1,V3,R22,V2,Myn1,nm2,R3,R11,R26,R27,R5,i441,R6,i1,R7,s13,arbace/o2j.aem10,R2,L1,V2,R22,R9,R0,s83,Node x as a Java boolean: comparisons, not, && and || directly, anything else Rt/t.R5,i452,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,switch-nodem10,R8,TR2,L1,V3,R22,V6,R78,R79,R80,R81,R82,R83,R27,R5,i473,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j17,stringswitch-nodem10,R8,TR2,L1,V3,R22,V3,R78,R84,R85,R27,R5,i489,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j16,staticcatch-nodem10,R8,TR2,L1,V3,R22,V3,R30,V2,R15,R86,R87,R27,R5,i496,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j16,staticraise-nodem10,R8,TR2,L1,V2,R22,V2,R15,R26,R5,i508,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j12,trywith-nodem10,R8,TR2,L1,V3,R22,V3,R30,R23,R87,R27,R5,i517,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j8,for-nodem10,R8,TR2,L1,V2,R22,V5,R23,R88,R89,R13,R30,R5,i523,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,flatten-seqm10,R8,TR2,L1,V1,R9,R5,i534,R6,i1,R7,s13,arbace/o2j.aem10,R2,L1,V3,R22,R9,R27,R0,s89,Lambda node x as a Java form (an Object's value); tail? when x is in its function's tail.R5,i537,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j14,translate-unitm10,R2,L1,V1,m2,R90,V2,R72,R91,R0,s125,The Java forms of a unit's dump: [forms missing], missing the externals and primitives the\n  runtime lacks with their counts.R5,i574,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j10,main-formsm10,R2,L1,V1,R92,R0,s135,The program's main class: inits, the units' initialisation in link order as one Runnable, and\n  main, Main/run's ending and the status.R5,i595,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j11,write-formsm8,R2,L1,V3,Myn1,fm2,R3,R4,R93,R94,R5,i608,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j9,unit-refsm10,R2,L1,V1,R95,R0,s99,The units unit u's code names (global X, the predefined exceptions left out) and those it requires.R5,i618,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j4,linkm10,R2,L1,V3,R96,R97,R98,R0,s87,The library units programs' units need, in lib-order; deps: unit -> the units it needs.R5,i631,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j17,translate-programm10,R2,L1,V3,R88,R99,R100,R0,s167,A program's units (DUMPS, in order) translated into OD with its main class and OD/files.txt,\n  the files to define in order: the library's units it needs (LO's) first.R5,i644,R6,i1,R7,s13,arbace/o2j.aev10,arbace.o2j5,-mainm8,R2,L1,V2,R33,V3,R101,R33,R26,R5,i666,R6,i1,R7,s13,arbace/o2j.ae")

var Lit_209 *jrt.String = jrt.Intern("arbace.o2j$eval1641000004$loading__1927001464__auto____1641000005")

var Lit_210 *jrt.String = jrt.Intern("arbace.o2j$eval1641000008$fn__1641000009")

var Lit_211 *jrt.String = jrt.Intern("arbace.o2j$read_dump")

var Lit_212 *jrt.String = jrt.Intern("arbace.o2j$node_body")

var Lit_213 *jrt.String = jrt.Intern("arbace.o2j$realize")

var Lit_214 *jrt.String = jrt.Intern("arbace.o2j$hd")

var Lit_215 *jrt.String = jrt.Intern("arbace.o2j$class_name")

var Lit_216 *jrt.String = jrt.Intern("arbace.o2j$munge_id")

var Lit_217 *jrt.String = jrt.Intern("arbace.o2j$global_name")

var Lit_218 *jrt.String = jrt.Intern("arbace.o2j$runtime_externals")

var Lit_219 *jrt.String = jrt.Intern("arbace.o2j$load_externals_BANG_")

var Lit_220 *jrt.String = jrt.Intern("arbace.o2j$fresh")

var Lit_221 *jrt.String = jrt.Intern("arbace.o2j$unit_class")

var Lit_222 *jrt.String = jrt.Intern("arbace.o2j$note_missing_BANG_")

var Lit_223 *jrt.String = jrt.Intern("arbace.o2j$latin1")

var Lit_224 *jrt.String = jrt.Intern("arbace.o2j$parse_float")

var Lit_225 *jrt.String = jrt.Intern("arbace.o2j$double_form")

var Lit_226 *jrt.String = jrt.Intern("arbace.o2j$const_init")

var Lit_227 *jrt.String = jrt.Intern("arbace.o2j$const_form")

var Lit_228 *jrt.String = jrt.Intern("arbace.o2j$bound_and_refs")

var Lit_229 *jrt.String = jrt.Intern("arbace.o2j$free_ids")

var Lit_230 *jrt.String = jrt.Intern("arbace.o2j$lookup")

var Lit_231 *jrt.String = jrt.Intern("arbace.o2j$simple_QMARK_")

var Lit_232 *jrt.String = jrt.Intern("arbace.o2j$with_args")

var Lit_233 *jrt.String = jrt.Intern("arbace.o2j$call_form")

var Lit_234 *jrt.String = jrt.Intern("arbace.o2j$apply_node")

var Lit_235 *jrt.String = jrt.Intern("arbace.o2j$method_for")

var Lit_236 *jrt.String = jrt.Intern("arbace.o2j$closure_class_BANG_")

var Lit_237 *jrt.String = jrt.Intern("arbace.o2j$function_node")

var Lit_238 *jrt.String = jrt.Intern("arbace.o2j$letrec_node")

var Lit_239 *jrt.String = jrt.Intern("arbace.o2j$let_chain")

var Lit_240 *jrt.String = jrt.Intern("arbace.o2j$num_arg")

var Lit_241 *jrt.String = jrt.Intern("arbace.o2j$rt")

var Lit_242 *jrt.String = jrt.Intern("arbace.o2j$array_kind")

var Lit_243 *jrt.String = jrt.Intern("arbace.o2j$bigarray_ext")

var Lit_244 *jrt.String = jrt.Intern("arbace.o2j$external")

var Lit_245 *jrt.String = jrt.Intern("arbace.o2j$prim_value")

var Lit_246 *jrt.String = jrt.Intern("arbace.o2j$prim_node")

var Lit_247 *jrt.String = jrt.Intern("arbace.o2j$test_form")

var Lit_248 *jrt.String = jrt.Intern("arbace.o2j$switch_node")

var Lit_249 *jrt.String = jrt.Intern("arbace.o2j$stringswitch_node")

var Lit_250 *jrt.String = jrt.Intern("arbace.o2j$staticcatch_node")

var Lit_251 *jrt.String = jrt.Intern("arbace.o2j$staticraise_node")

var Lit_252 *jrt.String = jrt.Intern("arbace.o2j$trywith_node")

var Lit_253 *jrt.String = jrt.Intern("arbace.o2j$for_node")

var Lit_254 *jrt.String = jrt.Intern("arbace.o2j$flatten_seq")

var Lit_255 *jrt.String = jrt.Intern("arbace.o2j$expr")

var Lit_256 *jrt.String = jrt.Intern("arbace.o2j$translate_unit")

var Lit_257 *jrt.String = jrt.Intern("arbace.o2j$main_forms")

var Lit_258 *jrt.String = jrt.Intern("arbace.o2j$write_forms")

var Lit_259 *jrt.String = jrt.Intern("arbace.o2j$unit_refs")

var Lit_260 *jrt.String = jrt.Intern("arbace.o2j$link")

var Lit_261 *jrt.String = jrt.Intern("arbace.o2j$translate_program")

var Lit_262 *jrt.String = jrt.Intern("arbace.o2j$_main")
