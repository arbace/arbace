//line aot_arbace_o2j.ae:1
package aot_arbace_o2j

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A_New() *A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_o2j_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j_A_const_1); lang.IFn_Cast(A_arbace_o2j_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_3, A_arbace_o2j_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_70)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_71)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_72)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_o2j_eval1641000008_fn__1641000009_A_New() *A_arbace_o2j_eval1641000008_fn__1641000009_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_eval1641000008_fn__1641000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_o2j_eval1641000008_fn__1641000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_o2j_eval1641000008_fn__1641000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_o2j_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_o2j_A_const_8.GetRawRoot__O(), A_arbace_o2j_A_const_9) }





























func A_arbace_o2j_read_dump_A_New() *A_arbace_o2j_read_dump_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_read_dump_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_o2j_read_dump_A) Ctor() {}
//line :31:1
func (t *A_arbace_o2j_read_dump_A) Invoke_O_O__O(self, f__0 any) any { var x__2 any; var r__2 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_o2j_A_const_10.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 *lang.Compiler_AOTFn; var fnbody__29 any = A_arbace_o2j_read_dump_fn__1641000012_A_New_O(r__2); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_o2j_read_dump_fn__1641000012_A_fn_class; if


	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, fnbody__29); A_arbace_o2j_read_dump_fn__1641000012_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__29, tmp2, nil); x__2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var tmp3 any; var and__1927000168__auto____3 any; var root_56 any =
	A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = x__2; if linked_57 == nil { and__1927000168__auto____3 = ifn_58.Invoke_O__O(arg_59) } else { and__1927000168__auto____3 = linked_57.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_56, arg_59) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp4 any = A_arbace_o2j_A_const_26; var tmp5 any; var root_60 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = x__2; if linked_61 == nil { tmp5 = ifn_62.Invoke_O__O(arg_63) } else { tmp5 = linked_61.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_60, arg_63) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else { tmp3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp3) { } else { var tmp6 any; var root_64 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_66 lang.IFn
		if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_153, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__0)).Ref(); var arg_68 any; var tmp7 any = A_arbace_o2j_A_const_29; var tmp8 any; var tmp9 any; var root_69 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = x__2; if linked_70 == nil { tmp9 = ifn_71.Invoke_O__O(arg_72) } else { tmp9 = linked_70.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(tmp9) { var root_73 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = x__2; if linked_74 == nil { tmp8 = ifn_75.Invoke_O__O(arg_76) } else { tmp8 = linked_74.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_73, arg_76) } } else { tmp8 = nil }; arg_68 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)); if linked_65 == nil { tmp6 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { tmp6 = linked_65.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }
//line :35:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }; var vec__1641000014__3 any; var root_30 any = /*line :31:1*/A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_32 lang.IFn; if





	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = x__2; if linked_31 == nil { vec__1641000014__3 = ifn_32.Invoke_O__O(arg_33) } else { vec__1641000014__3 = linked_31.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_30, arg_33) }; var ___4 any = /*line :31:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1641000014__3, lang.RT_IntCast_J__I_NoInit(0), nil); var module__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000014__3, lang.RT_IntCast_J__I_NoInit(1), nil); var size__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000014__3, lang.RT_IntCast_J__I_NoInit(2), nil); var required__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000014__3, lang.RT_IntCast_J__I_NoInit(3), nil); var code__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000014__3, lang.RT_IntCast_J__I_NoInit(4), nil); var vec__1641000017__9 any = code__8; var h__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000017__9, lang.RT_IntCast_J__I_NoInit(0), nil); var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000017__9, lang.RT_IntCast_J__I_NoInit(1), nil); var nm__12 any; var tmp10 any; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_13, h__10); _ = ___4; if and__1927000168__auto____12 {







		var root_34 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = n__11; var arg_38 any = Lit_154; if linked_35 == nil { tmp10 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { tmp10 = linked_35.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_34, arg_37, arg_38) } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp10) { var root_39 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = n__11; var arg_43 any = A_arbace_o2j_A_const_16; if linked_40 == nil { nm__12 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { nm__12 = linked_40.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) } } else { nm__12 = nil }; if
	jrt.J2g_Truth(nm__12) { } else { var tmp11 any; var root_77 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = Lit_155; var arg_81 any; var tmp12 any = A_arbace_o2j_A_const_30; var tmp13 any; var root_82 any = A_arbace_o2j_A_const_31.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = f__0; if linked_83 == nil { tmp13 = ifn_84.Invoke_O__O(arg_85) } else { tmp13 = linked_83.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_82, arg_85) }; arg_81 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); if linked_78 == nil { tmp11 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { tmp11 = linked_78.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))) }; var tmp14 any = A_arbace_o2j_A_const_17; var tmp15 any = A_arbace_o2j_A_const_18; var tmp16 any = A_arbace_o2j_A_const_19; var tmp17 any = A_arbace_o2j_A_const_20; var tmp18 any = A_arbace_o2j_A_const_21; var tmp19 any; var root_44 any = /*line :31:1*/A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_46 lang.IFn; if










	linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any; var root_50 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = nm__12; var arg_54 any = A_arbace_o2j_A_const_23; var arg_55 any = Lit_87; if linked_51 == nil { arg_47 = ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { arg_47 = linked_51.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) }; var arg_48 any = A_arbace_o2j_A_const_24; var arg_49 any = Lit_87; if linked_45 == nil { tmp19 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { tmp19 = linked_45.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; return /*line :31:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, module__5, tmp15, size__6, tmp16, required__7, tmp17, code__8, tmp18, tmp19)) }


func A_arbace_o2j_read_dump_fn__1641000012_A_New_O(p0 any) *A_arbace_o2j_read_dump_fn__1641000012_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_read_dump_fn__1641000012_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_o2j_read_dump_fn__1641000012_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :34:1
func (t *A_arbace_o2j_read_dump_fn__1641000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_24 any = A_arbace_o2j_A_const_11.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = t.F_r; if linked_25 == nil { tmp1 = ifn_26.Invoke_O__O(arg_27) } else { tmp1 = linked_25.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O__O(root_24, arg_27) } }; return nil }(); var tmp3 any; var t_ any = t.F_r; t.F_r = nil; tmp3 = t_; jrt.PushbackReader_Cast(tmp3).Close__V(); if tmp2 != nil { panic(tmp2) }; return tmp1 }









func A_arbace_o2j_node_body_A_New() *A_arbace_o2j_node_body_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_node_body_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_o2j_node_body_A) Ctor() {}
//line :44:1
func (t *A_arbace_o2j_node_body_A) Invoke_O_O__O(self, x__0 any) any { var t__2 any; var root_86 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_88 lang.IFn; if


	linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = x__0; if linked_87 == nil { t__2 = ifn_88.Invoke_O__O(arg_89) } else { t__2 = linked_87.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_86, arg_89) }; var tmp1 any; var and__1927000168__auto____3 any; var root_90 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = t__2; if linked_91 == nil { and__1927000168__auto____3 = ifn_92.Invoke_O__O(arg_93) } else { and__1927000168__auto____3 = linked_91.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_94 any = A_arbace_o2j_A_const_34.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_98 any = A_arbace_o2j_A_const_35.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = t__2; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_98, arg_101) }; if linked_95 == nil { tmp1 = ifn_96.Invoke_O__O(arg_97) } else { tmp1 = linked_95.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_94, arg_97) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_102 any = A_arbace_o2j_A_const_36.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = t__2; if linked_103 == nil { return ifn_104.Invoke_O__O(arg_105) } else { return linked_103.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_102, arg_105) } } else { return t__2 } }

func A_arbace_o2j_realize_A_New() *A_arbace_o2j_realize_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_realize_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_o2j_realize_A) Ctor() {}
//line :49:1
func (t *A_arbace_o2j_realize_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_106 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = x__0; if linked_107 == nil { tmp1 = ifn_108.Invoke_O__O(arg_109) } else { tmp1 = linked_107.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_106, arg_109) }; if jrt.J2g_Truth(tmp1) { var root_110 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var root_115 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_119 any; var root_120 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var arg_124 any = x__0; if linked_121 == nil { arg_119 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { arg_119 = linked_121.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) }; if linked_116 == nil { arg_113 = ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { arg_113 = linked_116.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) }; var arg_114 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if linked_111 == nil { return ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { return linked_111.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) } } else { var tmp2 any; var root_125 any = A_arbace_o2j_A_const_42.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_127 lang.IFn
		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = x__0; if linked_126 == nil { tmp2 = ifn_127.Invoke_O__O(arg_128) } else { tmp2 = linked_126.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_125, arg_128) }
//line :52:1
		if jrt.J2g_Truth(tmp2) {
			var root_129 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_134 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var arg_138 any = x__0; if linked_135 == nil { arg_132 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { arg_132 = linked_135.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }; var arg_133 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } } else {
//line :52:1
				if A_arbace_o2j_A_const_44 != nil { return x__0 } else { return nil
				}
			}
	} }
func A_arbace_o2j_hd_A_New() *A_arbace_o2j_hd_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_hd_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_o2j_hd_A) Ctor() {}
//line :56:1
func (t *A_arbace_o2j_hd_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_139 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = x__0; if linked_140 == nil { tmp1 = ifn_141.Invoke_O__O(arg_142) } else { tmp1 = linked_140.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(tmp1) { var root_143 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = x__0; if linked_144 == nil { return ifn_145.Invoke_O__O(arg_146) } else { return linked_144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_143, arg_146) } } else { return nil } }









func A_arbace_o2j_class_name_A_New() *A_arbace_o2j_class_name_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_class_name_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_o2j_class_name_A) Ctor() {}
//line :66:1
func (t *A_arbace_o2j_class_name_A) Invoke_O_O__O(self, m__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__0)).Ref() }

func A_arbace_o2j_munge_id_A_New() *A_arbace_o2j_munge_id_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_munge_id_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_o2j_munge_id_A) Ctor() {}
//line :68:1
func (t *A_arbace_o2j_munge_id_A) Invoke_O_O__O(self, id__0 any) any { var root_147 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_151 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = id__0; var arg_155 any = A_arbace_o2j_A_const_46; var arg_156 any = Lit_114; if linked_152 == nil { arg_150 = ifn_153.Invoke_O_O_O__O(arg_154, arg_155, arg_156) } else { arg_150 = linked_152.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_151, arg_154, arg_155, arg_156) }; if linked_148 == nil { return ifn_149.Invoke_O__O(arg_150) } else { return linked_148.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_147, arg_150) } }

func A_arbace_o2j_global_name_A_New() *A_arbace_o2j_global_name_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_global_name_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_o2j_global_name_A) Ctor() {}
//line :70:1
func (t *A_arbace_o2j_global_name_A) Invoke_O_O__O(self, s__0 any) any { var root_157 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_163 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__0; var arg_167 any = A_arbace_o2j_A_const_47; var arg_168 any = Lit_87; if linked_164 == nil { arg_160 = ifn_165.Invoke_O_O_O__O(arg_166, arg_167, arg_168) } else { arg_160 = linked_164.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_163, arg_166, arg_167, arg_168) }; var arg_161 any = A_arbace_o2j_A_const_48; var arg_162 any = Lit_87; if linked_158 == nil { return ifn_159.Invoke_O_O_O__O(arg_160, arg_161, arg_162) } else { return linked_158.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_157, arg_160, arg_161, arg_162) } }




func A_arbace_o2j_runtime_externals_A_New() *A_arbace_o2j_runtime_externals_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_o2j_runtime_externals_A) Ctor() {}
//line :75:1
func (t *A_arbace_o2j_runtime_externals_A) Invoke_O_O__O(self, dir__0 any) any {



	var root_169 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_173 any; var iter__1927001039__auto____2 any; var fnbody__445 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A_New(); var tmp1 *jrt.Class; var fncls__444 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A_fn_class
	if fncls__444 == nil { var fncls__444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A_fn_class = fncls__444d; tmp1 = fncls__444d } else { tmp1 = fncls__444 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__445, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_446 any = A_arbace_o2j_A_const_73.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var fnbody__452 any = A_arbace_o2j_runtime_externals_fn__1641000057_A_New(); var tmp4 *jrt.Class; var fncls__451 *jrt.Class = A_arbace_o2j_runtime_externals_fn__1641000057_A_fn_class; if fncls__451 == nil { var fncls__451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, nil); A_arbace_o2j_runtime_externals_fn__1641000057_A_fn_class = fncls__451d; tmp4 = fncls__451d } else { tmp4 = fncls__451 }; arg_449 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__452, tmp4, nil); var arg_450 any = jrt.File_Cast(dir__0).ListFiles__File1().Ref(); if linked_447 == nil { tmp3 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { tmp3 = linked_447.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }; arg_173 = tmp2.Invoke_O__O(tmp3)
//line :79:1
	if linked_170 == nil { return ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { return linked_170.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) } }
func A_arbace_o2j_runtime_externals_fn__1641000057_A_New() *A_arbace_o2j_runtime_externals_fn__1641000057_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_fn__1641000057_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_fn__1641000057_A) Ctor() {}
//line :80:1
func (t *A_arbace_o2j_runtime_externals_fn__1641000057_A) Invoke_O_O__O(self, p1__1641000027_SHARP___1 any) any { return jrt.File_Cast(p1__1641000027_SHARP___1).GetName__String().Ref() }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A_New() *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A) Ctor() {}
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A) Invoke_O_O__O(self, s__1641000030__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__443 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A_New_O_O(self, s__1641000030__1); var tmp2 *jrt.Class; var fncls__442 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A_fn_class; if fncls__442 == nil { var fncls__442d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__443); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A_fn_class = fncls__442d; tmp2 = fncls__442d } else { tmp2 = fncls__442 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__443, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A_New_O_O(p0, p1 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A) Ctor_O_O(c__iter__1641000029, c__s__1641000030 any) { t.F_iter__1641000029 = c__iter__1641000029; t.F_s__1641000030 = c__s__1641000030 }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A) Invoke_O__O(self any) any { { var s__1641000030__1 any; var t_ any = t.F_s__1641000030; t.F_s__1641000030 = nil; s__1641000030__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_174 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__1641000030__1; if linked_175 == nil { temp__1927000414__auto____2 = ifn_176.Invoke_O__O(arg_177) } else { temp__1927000414__auto____2 = linked_175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_174, arg_177) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_178 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = xs__1927001018__auto____3; if linked_179 == nil { f__4 = ifn_180.Invoke_O__O(arg_181) } else { f__4 = linked_179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_178, arg_181) }; var tmp1 any; var root_182 any = A_arbace_o2j_A_const_50.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_184 lang.IFn
															if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_186 any = Lit_23; if linked_183 == nil { tmp1 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp1 = linked_183.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_182, arg_185, arg_186) }
//line :80:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__387 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A_New(); var tmp2 *jrt.Class; var fncls__386 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A_fn_class; if fncls__386 == nil { var fncls__386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, nil); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A_fn_class = fncls__386d; tmp2 = fncls__386d } else { tmp2 = fncls__386 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__387, tmp2, nil); var fs__1927001036__auto____6 any; var root_388 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var r__6 any = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_o2j_A_const_10.GetRawRoot__O()).Invoke_O__O(f__4))); var tmp5 *lang.Compiler_AOTFn; var fnbody__424 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A_New_O(r__6); var tmp6 *jrt.Class
		var fncls__423 /*line :80:1*/*jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A_fn_class

		if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__424); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A_fn_class = fncls__423d; tmp6 = fncls__423d } else { tmp6 = fncls__423 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp6, nil); tmp4 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :80:1
		arg_391 = tmp3.Invoke_O__O(tmp4); if linked_389 == nil { fs__1927001036__auto____6 = ifn_390.Invoke_O__O(arg_391) } else { fs__1927001036__auto____6 = linked_389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_388, arg_391) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_425 any = A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = fs__1927001036__auto____6; var arg_429 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1641000029); var tmp8 any; var root_430 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = s__1641000030__1; if linked_431 == nil { tmp8 = ifn_432.Invoke_O__O(arg_433) } else { tmp8 = linked_431.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_430, arg_433) }; arg_429 = tmp7.Invoke_O__O(tmp8); if linked_426 == nil { return ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { return linked_426.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) } } else { var tmp9 any; var root_434 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = s__1641000030__1; if linked_435 == nil { tmp9 = ifn_436.Invoke_O__O(arg_437) } else { tmp9 = linked_435.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_434, arg_437) }; s__1641000030__1 = tmp9; continue L1 } } else { var tmp10 any; var root_438 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = s__1641000030__1; if linked_439 == nil { tmp10 = ifn_440.Invoke_O__O(arg_441) } else { tmp10 = linked_439.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_438, arg_441) }; s__1641000030__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A_New() *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A) Ctor() {}
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A) Invoke_O_O__O(self, s__1641000032__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__385 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A_New_O_O(s__1641000032__1, self); var tmp2 *jrt.Class; var fncls__384 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A_fn_class; if fncls__384 == nil { var fncls__384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, fnbody__385); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A_fn_class = fncls__384d; tmp2 = fncls__384d } else { tmp2 = fncls__384 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__385, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A_New_O_O(p0, p1 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A) Ctor_O_O(c__s__1641000032, c__iter__1641000031 any) { t.F_s__1641000032 = c__s__1641000032; t.F_iter__1641000031 = c__iter__1641000031 }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A) Invoke_O__O(self any) any { { var s__1641000032__1 any; var t_ any = t.F_s__1641000032; t.F_s__1641000032 = nil; s__1641000032__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_187 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__1641000032__1; if linked_188 == nil { temp__1927000414__auto____2 = ifn_189.Invoke_O__O(arg_190) } else { temp__1927000414__auto____2 = linked_188.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var form__4 any; var root_191 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = xs__1927001018__auto____3; if linked_192 == nil { form__4 = ifn_193.Invoke_O__O(arg_194) } else { form__4 = linked_192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_191, arg_194) }; var tmp1 any = A_arbace_o2j_A_const_51; var tmp2 any; var root_195 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, A_arbace_o2j_hd_A_fn_class); var ifn_197 lang.IFn



	if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = form__4; if linked_196 == nil { tmp2 = ifn_197.Invoke_O__O(arg_198) } else { tmp2 = linked_196.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_195, arg_198) }
//line :80:1
	if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var cls__5 any; var root_199 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_201 lang.IFn




		if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_203 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = form__4; if linked_204 == nil { arg_202 = ifn_205.Invoke_O__O(arg_206) } else { arg_202 = linked_204.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_203, arg_206) }; if linked_200 == nil { cls__5 = ifn_201.Invoke_O__O(arg_202) } else { cls__5 = linked_200.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_199, arg_202) }
//line :80:1
		var iterys__1927001035__auto____6 any; var fnbody__358 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A_New_O(cls__5); var tmp3 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A_fn_class; if fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__358); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A_fn_class = fncls__357d; tmp3 = fncls__357d } else { tmp3 = fncls__357 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__358, tmp3, nil); var fs__1927001036__auto____7 any; var root_359 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp5 any; var root_363 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_365 lang.IFn





		if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = form__4; if linked_364 == nil { tmp5 = ifn_365.Invoke_O__O(arg_366) } else { tmp5 = linked_364.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_363, arg_366) }
//line :80:1
		arg_362 = tmp4.Invoke_O__O(tmp5); if linked_360 == nil { fs__1927001036__auto____7 = ifn_361.Invoke_O__O(arg_362) } else { fs__1927001036__auto____7 = linked_360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_359, arg_362) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_367 any = A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = fs__1927001036__auto____7; var arg_371 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1641000031); var tmp7 any; var root_372 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = s__1641000032__1; if linked_373 == nil { tmp7 = ifn_374.Invoke_O__O(arg_375) } else { tmp7 = linked_373.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_372, arg_375) }; arg_371 = tmp6.Invoke_O__O(tmp7); if linked_368 == nil { return ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { return linked_368.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) } } else { var tmp8 any; var root_376 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = s__1641000032__1; if linked_377 == nil { tmp8 = ifn_378.Invoke_O__O(arg_379) } else { tmp8 = linked_377.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_376, arg_379) }; s__1641000032__1 = tmp8; continue L1 } } else { var tmp9 any; var root_380 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = s__1641000032__1; if linked_381 == nil { tmp9 = ifn_382.Invoke_O__O(arg_383) } else { tmp9 = linked_381.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_380, arg_383) }; s__1641000032__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A_New_O(p0 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A) Ctor_O(c__cls any) { t.F_cls = c__cls }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A) Invoke_O_O__O(self, s__1641000034__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__356 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A_New_O_O_O(t.F_cls, s__1641000034__1, self); var tmp2 *jrt.Class; var fncls__355 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A_fn_class; if fncls__355 == nil { var fncls__355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, fnbody__356); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A_fn_class = fncls__355d; tmp2 = fncls__355d } else { tmp2 = fncls__355 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__356, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A) Ctor_O_O_O(c__cls, c__s__1641000034, c__iter__1641000033 any) { t.F_cls = c__cls; t.F_s__1641000034 = c__s__1641000034; t.F_iter__1641000033 = c__iter__1641000033 }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A) Invoke_O__O(self any) any { { var s__1641000034__1 any; var t_ any = t.F_s__1641000034; t.F_s__1641000034 = nil; s__1641000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_207 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__1641000034__1; if linked_208 == nil { temp__1927000414__auto____2 = ifn_209.Invoke_O__O(arg_210) } else { temp__1927000414__auto____2 = linked_208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_207, arg_210) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_211 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = s__1641000034__3; if linked_212 == nil { tmp1 = ifn_213.Invoke_O__O(arg_214) } else { tmp1 = linked_212.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_211, arg_214) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_215 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = s__1641000034__3; if linked_216 == nil { c__1927001037__auto____4 = ifn_217.Invoke_O__O(arg_218) } else { c__1927001037__auto____4 = linked_216.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_215, arg_218) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000036__6 any; var root_219 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_220 == nil { b__1641000036__6 = ifn_221.Invoke_O__O(arg_222) } else { b__1641000036__6 = linked_220.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_219, arg_222) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__272 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A_New_O_O_I_O(b__1641000036__6, t.F_cls, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__271 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A_fn_class; if fncls__271 == nil { var fncls__271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, fnbody__272); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A_fn_class = fncls__271d; tmp3 = fncls__271d } else { tmp3 = fncls__271 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__272, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_273 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any; var root_278 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = b__1641000036__6; if linked_279 == nil { arg_276 = ifn_280.Invoke_O__O(arg_281) } else { arg_276 = linked_279.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_278, arg_281) }; var arg_277 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000033); var tmp5 any; var root_282 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = s__1641000034__3; if linked_283 == nil { tmp5 = ifn_284.Invoke_O__O(arg_285) } else { tmp5 = linked_283.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_282, arg_285) }; arg_277 = tmp4.Invoke_O__O(tmp5); if linked_274 == nil { return ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { return linked_274.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_273, arg_276, arg_277) } } else { var root_286 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var root_291 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = b__1641000036__6; if linked_292 == nil { arg_289 = ifn_293.Invoke_O__O(arg_294) } else { arg_289 = linked_292.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_291, arg_294) }; var arg_290 any; if linked_287 == nil { return ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { return linked_287.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) } } } else { var m__4 any; var root_295 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = s__1641000034__3; if linked_296 == nil { m__4 = ifn_297.Invoke_O__O(arg_298) } else { m__4 = linked_296.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_295, arg_298) }; var tmp6 any; var and__1927000168__auto____5 bool; var tmp7 any = A_arbace_o2j_A_const_57; var tmp8 any; var root_299 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_o2j_hd_A_fn_class); var ifn_301 lang.IFn






	if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = m__4; if linked_300 == nil { tmp8 = ifn_301.Invoke_O__O(arg_302) } else { tmp8 = linked_300.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_299, arg_302) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____5 { var root_303 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_308 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var root_312 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = m__4; if linked_313 == nil { arg_311 = ifn_314.Invoke_O__O(arg_315) } else { arg_311 = linked_313.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_312, arg_315) }; if linked_309 == nil { arg_306 = ifn_310.Invoke_O__O(arg_311) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_308, arg_311) }; var arg_307 any = Lit_150; if linked_304 == nil { tmp6 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { tmp6 = linked_304.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :80:1
	if jrt.J2g_Truth(tmp6) { var params__5 any; var root_316 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_318 lang.IFn







		if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var root_320 any = A_arbace_o2j_A_const_58.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_o2j_A_const_42.GetRawRoot__O(); var arg_324 any; var root_325 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_325, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_329 any = m__4; if linked_326 == nil { arg_324 = ifn_327.Invoke_O_O__O(A_arbace_o2j_A_const_60, arg_329) } else { arg_324 = linked_326.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_325, 2, A_arbace_o2j_A_const_60, arg_329) }; if linked_321 == nil { arg_319 = ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { arg_319 = linked_321.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_320, arg_323, arg_324) }; if linked_317 == nil { params__5 = ifn_318.Invoke_O__O(arg_319) } else { params__5 = linked_317.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_316, arg_319) }
//line :80:1
		var root_330 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var tmp9 any; var root_335 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_337 lang.IFn








		if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any; var root_339 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = m__4; if linked_340 == nil { arg_338 = ifn_341.Invoke_O__O(arg_342) } else { arg_338 = linked_340.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_339, arg_342) }; if linked_336 == nil { tmp9 = ifn_337.Invoke_O__O(arg_338) } else { tmp9 = linked_336.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_335, arg_338) }
//line :80:1
		var tmp10 any = tmp9; var tmp11 any; var root_343 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_345 lang.IFn








		if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_167, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_cls)).Ref(); if linked_344 == nil { tmp11 = ifn_345.Invoke_O__O(arg_346) } else { tmp11 = linked_344.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_343, arg_346) }
//line :80:1
		arg_333 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Tuple_Create_O_O__IPersistentVector(tmp11, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(params__5)).Ref())); var arg_334 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1641000033); var tmp13 any; var root_347 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = s__1641000034__3; if linked_348 == nil { tmp13 = ifn_349.Invoke_O__O(arg_350) } else { tmp13 = linked_348.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_347, arg_350) }; arg_334 = tmp12.Invoke_O__O(tmp13); if linked_331 == nil { return ifn_332.Invoke_O_O__O(arg_333, arg_334) } else { return linked_331.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_330, arg_333, arg_334) } } else { var tmp14 any; var root_351 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = s__1641000034__3; if linked_352 == nil { tmp14 = ifn_353.Invoke_O__O(arg_354) } else { tmp14 = linked_352.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_351, arg_354) }; s__1641000034__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A) Ctor_O_O_I_O(c__b__1641000036, c__cls any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000036 = c__b__1641000036; t.F_cls = c__cls; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A) Invoke_O__O(self any) any { { var i__1641000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000035__1)); var tmp2 any; var and__1927000168__auto____3 bool; var tmp3 any = A_arbace_o2j_A_const_57; var tmp4 any; var root_223 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, A_arbace_o2j_hd_A_fn_class); var ifn_225 lang.IFn






	if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = m__2; if linked_224 == nil { tmp4 = ifn_225.Invoke_O__O(arg_226) } else { tmp4 = linked_224.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_223, arg_226) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____3 { var root_227 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var root_232 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var root_236 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = m__2; if linked_237 == nil { arg_235 = ifn_238.Invoke_O__O(arg_239) } else { arg_235 = linked_237.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_236, arg_239) }; if linked_233 == nil { arg_230 = ifn_234.Invoke_O__O(arg_235) } else { arg_230 = linked_233.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_232, arg_235) }; var arg_231 any = Lit_150; if linked_228 == nil { tmp2 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { tmp2 = linked_228.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_227, arg_230, arg_231) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :80:1
	if jrt.J2g_Truth(tmp2) { var params__3 any; var root_240 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_242 lang.IFn







		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var root_244 any = A_arbace_o2j_A_const_58.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = A_arbace_o2j_A_const_42.GetRawRoot__O(); var arg_248 any; var root_249 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_249, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_253 any = m__2; if linked_250 == nil { arg_248 = ifn_251.Invoke_O_O__O(A_arbace_o2j_A_const_60, arg_253) } else { arg_248 = linked_250.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_249, 2, A_arbace_o2j_A_const_60, arg_253) }; if linked_245 == nil { arg_243 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { arg_243 = linked_245.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; if linked_241 == nil { params__3 = ifn_242.Invoke_O__O(arg_243) } else { params__3 = linked_241.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_240, arg_243) }
//line :80:1
		var root_254 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = t.F_b__1641000036; var arg_258 any; var tmp5 any; var root_259 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_261 lang.IFn








		if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var root_263 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = m__2; if linked_264 == nil { arg_262 = ifn_265.Invoke_O__O(arg_266) } else { arg_262 = linked_264.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_263, arg_266) }; if linked_260 == nil { tmp5 = ifn_261.Invoke_O__O(arg_262) } else { tmp5 = linked_260.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_259, arg_262) }
//line :80:1
		var tmp6 any = tmp5; var tmp7 any; var root_267 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_269 lang.IFn








		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_167, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_cls)).Ref(); if linked_268 == nil { tmp7 = ifn_269.Invoke_O__O(arg_270) } else { tmp7 = linked_268.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_267, arg_270) }
//line :80:1
		arg_258 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(params__3)).Ref())); if linked_255 == nil { ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { linked_255.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) }; i__1641000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000035__1); continue L1 } else { i__1641000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A_New_O(p0 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :82:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var root_396 any = A_arbace_o2j_A_const_67.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any; var root_400 any = A_arbace_o2j_A_const_68.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any; var fnbody__411 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A_New(); var tmp2 *jrt.Class; var fncls__410 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A_fn_class; if fncls__410 == nil { var fncls__410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A_fn_class = fncls__410d; tmp2 = fncls__410d } else { tmp2 = fncls__410 }; arg_403 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__411, tmp2, nil); var arg_404 any; var root_412 any = A_arbace_o2j_A_const_71.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var fnbody__422 any = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A_New_O(t.F_r); var tmp3 *jrt.Class; var fncls__421 *jrt.Class = A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A_fn_class; if fncls__421 == nil { var fncls__421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__422); A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A_fn_class = fncls__421d; tmp3 = fncls__421d } else { tmp3 = fncls__421 }; arg_415 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__422, tmp3, nil); if linked_413 == nil { arg_404 = ifn_414.Invoke_O__O(arg_415) } else { arg_404 = linked_413.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O__O(root_412, arg_415) }; if linked_401 == nil { arg_399 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { arg_399 = linked_401.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; if linked_397 == nil { tmp1 = ifn_398.Invoke_O__O(arg_399) } else { tmp1 = linked_397.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_396, arg_399) } }
//line :82:1
	return nil }(); var tmp5 any; var t_ any = t.F_r; t.F_r = nil; tmp5 = t_; jrt.PushbackReader_Cast(tmp5).Close__V(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A_New() *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A) Ctor() {}
//line :83:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A) Invoke_O_O__O(self, p1__1641000028_SHARP___1 any) any { var root_405 any = A_arbace_o2j_A_const_69.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = p1__1641000028_SHARP___1; var arg_409 any = A_arbace_o2j_A_const_70; if linked_406 == nil { return ifn_407.Invoke_O_O__O(arg_408, arg_409) } else { return linked_406.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_405, arg_408, arg_409) } }
//line :83:1
func A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A_New_O(p0 any) *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :83:1
func (t *A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A) Invoke_O__O(self any) any { var root_416 any = A_arbace_o2j_A_const_11.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = A_arbace_o2j_A_const_72; var arg_420 any = t.F_r; if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } }









func A_arbace_o2j_load_externals_BANG__A_New() *A_arbace_o2j_load_externals_BANG__A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_load_externals_BANG__A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_o2j_load_externals_BANG__A) Ctor() {}
//line :93:1
func (t *A_arbace_o2j_load_externals_BANG__A) Invoke_O_O__O(self, dir__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_74.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_75; var tmp3 any; var root_458 any = A_arbace_o2j_A_const_76.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any; var root_462 any = A_arbace_o2j_A_const_77.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_o2j_runtime_externals_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_466 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_466, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = dir__0; if linked_467 == nil { arg_465 = ifn_468.Invoke_O__O(arg_469) } else { arg_465 = linked_467.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_466, arg_469) }; if linked_463 == nil { arg_461 = ifn_464.Invoke_O__O(arg_465) } else { arg_461 = linked_463.(*A_arbace_o2j_runtime_externals_A).Invoke_O_O__O(root_462, arg_465) }; if linked_459 == nil { tmp3 = ifn_460.Invoke_O__O(arg_461) } else { tmp3 = linked_459.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_458, arg_461) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }









func A_arbace_o2j_fresh_A_New() *A_arbace_o2j_fresh_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_fresh_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_o2j_fresh_A) Ctor() {}
//line :103:1
func (t *A_arbace_o2j_fresh_A) Invoke_O_O__O(self, prefix__0 any) any { var root_470 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_474 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var tmp3 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_477 any = tmp3.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_478 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_475 == nil { tmp2 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { tmp2 = linked_475.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }; arg_473 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, prefix__0, tmp2)).Ref(); if linked_471 == nil { return ifn_472.Invoke_O__O(arg_473) } else { return linked_471.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_470, arg_473) } }

func A_arbace_o2j_unit_class_A_New() *A_arbace_o2j_unit_class_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_unit_class_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_o2j_unit_class_A) Ctor() {}
//line :105:1
func (t *A_arbace_o2j_unit_class_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_o2j_A_const_83; return tmp1.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()) }

func A_arbace_o2j_note_missing_BANG__A_New() *A_arbace_o2j_note_missing_BANG__A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_note_missing_BANG__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_o2j_note_missing_BANG__A) Ctor() {}
//line :107:1
func (t *A_arbace_o2j_note_missing_BANG__A) Invoke_O_O__O(self, n__0 any) any { var root_479 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var tmp1 *lang.Keyword = A_arbace_o2j_A_const_84; var arg_482 any = tmp1.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_483 any = A_arbace_o2j_A_const_85.GetRawRoot__O(); var arg_484 any = n__0; var arg_485 any; var root_486 any = A_arbace_o2j_A_const_86.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); var arg_490 any = A_arbace_o2j_A_const_87; if linked_487 == nil { arg_485 = ifn_488.Invoke_O_O__O(arg_489, arg_490) } else { arg_485 = linked_487.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_486, arg_489, arg_490) }; if linked_480 == nil { return ifn_481.Invoke_O_O_O_O__O(arg_482, arg_483, arg_484, arg_485) } else { return linked_480.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_479, arg_482, arg_483, arg_484, arg_485) } }






func A_arbace_o2j_latin1_A_New() *A_arbace_o2j_latin1_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_latin1_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_o2j_latin1_A) Ctor() {}
//line :114:1
func (t *A_arbace_o2j_latin1_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 any; var root_491 any = A_arbace_o2j_A_const_88.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = s__0; if linked_492 == nil { tmp1 = ifn_493.Invoke_O__O(arg_494) } else { tmp1 = linked_492.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(tmp1) { var b__2 any = jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); return jrt.String_New_B1_Charset(jrt.ByteArray_Cast(b__2), jrt.StandardCharsets_ISO_8859_1) } else { var tmp2 any; var root_495 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_497 lang.IFn


		if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any; var fnbody__501 any = A_arbace_o2j_latin1_fn__1641000065_A_New(); var tmp3 *jrt.Class; var fncls__500 *jrt.Class = A_arbace_o2j_latin1_fn__1641000065_A_fn_class; if fncls__500 == nil { var fncls__500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_o2j_latin1_fn__1641000065_A_fn_class = fncls__500d; tmp3 = fncls__500d } else { tmp3 = fncls__500 }; arg_498 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__501, tmp3, nil); var arg_499 any = s__0; if linked_496 == nil { tmp2 = ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { tmp2 = linked_496.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) }
//line :116:1
		return jrt.String_New_C1(lang.Numbers_Char_array_O__C1_NoInit(tmp2))
	}
}
func A_arbace_o2j_latin1_fn__1641000065_A_New() *A_arbace_o2j_latin1_fn__1641000065_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_latin1_fn__1641000065_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_o2j_latin1_fn__1641000065_A) Ctor() {}
//line :119:1
func (t *A_arbace_o2j_latin1_fn__1641000065_A) Invoke_O_O__O(self, p1__1641000064_SHARP___1 any) any { return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(p1__1641000064_SHARP___1), 255))).Ref() }

func A_arbace_o2j_parse_float_A_New() *A_arbace_o2j_parse_float_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_parse_float_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_o2j_parse_float_A) Ctor() {}
//line :121:1
func (t *A_arbace_o2j_parse_float_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var root_502 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_504 lang.IFn; if
									linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = t__0; var arg_506 any = Lit_114; var arg_507 any = Lit_87; if linked_503 == nil { t__2 = ifn_504.Invoke_O_O_O__O(arg_505, arg_506, arg_507) } else { t__2 = linked_503.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_502, arg_505, arg_506, arg_507) }; var t__3 any; var tmp1 any; var and__1927000168__auto____3 any; var root_508 any = /*line :121:1*/A_arbace_o2j_A_const_89.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_510 lang.IFn; if

	linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = A_arbace_o2j_A_const_90; var arg_512 any = t__2; if linked_509 == nil { and__1927000168__auto____3 = ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { and__1927000168__auto____3 = linked_509.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_513 any = A_arbace_o2j_A_const_91.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any; var root_517 any = A_arbace_o2j_A_const_89.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = A_arbace_o2j_A_const_92; var arg_521 any = t__2; if linked_518 == nil { arg_516 = ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { arg_516 = linked_518.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) }; if linked_514 == nil { tmp1 = ifn_515.Invoke_O__O(arg_516) } else { tmp1 = linked_514.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_513, arg_516) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { t__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, t__2, nil)).Ref() } else { t__3 = t__2 }; return /*line :124:1*/ jrt.Double_ValueOf_D__Double_NoInit(jrt.Double_ParseDouble_String__D_NoInit(jrt.String_Cast(t__3))).Ref() }

func A_arbace_o2j_double_form_A_New() *A_arbace_o2j_double_form_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_double_form_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_o2j_double_form_A) Ctor() {}
//line :126:1
func (t *A_arbace_o2j_double_form_A) InvokePrim_O_D__O(self any, d__0 float64) any {
	var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Double_IsNaN_D__Z_NoInit(d__0); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Double_IsInfinite_D__Z_NoInit(d__0) }; if tmp1 {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_93; return tmp2.Invoke_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(d__0)).Ref()) } else {
//line :127:1
			return jrt.Double_ValueOf_D__Double_NoInit(d__0).Ref() } }
//line :126:1
func (t *A_arbace_o2j_double_form_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }




func A_arbace_o2j_const_init_A_New() *A_arbace_o2j_const_init_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_const_init_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_o2j_const_init_A) Ctor() {}
//line :131:1
func (t *A_arbace_o2j_const_init_A) Invoke_O_O__O(self, c__0 any) any { var vec__1641000071__2 any = c__0; var h__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var G__1641000074__5_ any = h__3; switch



	lang.Util_Hash_O__I_NoInit(G__1641000074__5_) >> 0 & 31 { case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_94) {





		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_99; var tmp3 any; var root_528 any = A_arbace_o2j_A_const_100.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_o2j_latin1_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = a__4; if linked_529 == nil { tmp3 = ifn_530.Invoke_O__O(arg_531) } else { tmp3 = linked_529.(*A_arbace_o2j_latin1_A).Invoke_O_O__O(root_528, arg_531) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }
//line :135:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_95) {






		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_o2j_A_const_101; var tmp6 any = A_arbace_o2j_A_const_102; var tmp7 any; var root_532 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var fnbody__546 any = A_arbace_o2j_const_init_fn__1641000075_A_New(); var tmp8 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_o2j_const_init_fn__1641000075_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_o2j_const_init_fn__1641000075_A_fn_class = fncls__545d; tmp8 = fncls__545d } else { tmp8 = fncls__545 }; arg_535 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__546, tmp8, nil); var arg_536 any = a__4; if linked_533 == nil { tmp7 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { tmp7 = linked_533.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7) }
//line :135:1
	case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_96) {

		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_o2j_A_const_105; var tmp11 any; var root_547 any = A_arbace_o2j_A_const_103.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_547, A_arbace_o2j_double_form_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_551 any = A_arbace_o2j_A_const_104.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_o2j_parse_float_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = a__4; if linked_552 == nil { arg_550 = ifn_553.Invoke_O__O(arg_554) } else { arg_550 = linked_552.(*A_arbace_o2j_parse_float_A).Invoke_O_O__O(root_551, arg_554) }; if linked_548 == nil { tmp11 = ifn_549.Invoke_O__O(arg_550) } else { tmp11 = linked_548.(*A_arbace_o2j_double_form_A).InvokePrim_O_D__O(root_547, lang.RT_DoubleCast_O__D_NoInit(arg_550)) }; return tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :135:1
	case 15: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_97) {




		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_o2j_A_const_107; return tmp12.Invoke_O_O__O(tmp13, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(a__4))).Ref()) }
//line :135:1
	case 17: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_106) { var vec__1641000077__6 any = c__0; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000077__6, lang.RT_IntCast_J__I_NoInit(0), nil); var tag__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000077__6, lang.RT_IntCast_J__I_NoInit(1), nil); var fs__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000077__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_o2j_A_const_109; var tmp16 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_110, tag__8); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_111; var tmp19 any = A_arbace_o2j_A_const_112; var tmp20 any; var root_555 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_557 lang.IFn; _ = ___7








		if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = A_arbace_o2j_A_const_113.GetRawRoot__O(); var arg_559 any = fs__9; if linked_556 == nil { tmp20 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { tmp20 = linked_556.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; return tmp14.Invoke_O_O_O__O(tmp15, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19, tmp20)) }
//line :135:1
	case 18: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_108) {


		var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp22 any = A_arbace_o2j_A_const_115; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp24 any = A_arbace_o2j_A_const_116; return tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O__O(tmp24, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(a__4))).Ref())) }
//line :135:1
	case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_114) {
		return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_118, a__4) }
//line :135:1
	case 25: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_117) {



		var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_120; return tmp25.Invoke_O_O__O(tmp26, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(a__4))).Ref()) }
//line :135:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000074__5_, A_arbace_o2j_A_const_119) {
		return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_118, a__4) }
//line :135:1
	default:}; var tmp27 any; var root_523 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_525 lang.IFn; if









	linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__3)).Ref(); var arg_527 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_98, c__0)); if linked_524 == nil { tmp27 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp27 = linked_524.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; /*line :135:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp27))) }






func A_arbace_o2j_const_init_fn__1641000075_A_New() *A_arbace_o2j_const_init_fn__1641000075_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_const_init_fn__1641000075_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_o2j_const_init_fn__1641000075_A) Ctor() {}
//line :142:1
func (t *A_arbace_o2j_const_init_fn__1641000075_A) Invoke_O_O__O(self, p1__1641000070_SHARP___1 any) any { var root_537 any = A_arbace_o2j_A_const_103.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_537, A_arbace_o2j_double_form_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_541 any = A_arbace_o2j_A_const_104.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, A_arbace_o2j_parse_float_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = p1__1641000070_SHARP___1; if linked_542 == nil { arg_540 = ifn_543.Invoke_O__O(arg_544) } else { arg_540 = linked_542.(*A_arbace_o2j_parse_float_A).Invoke_O_O__O(root_541, arg_544) }; if linked_538 == nil { return ifn_539.Invoke_O__O(arg_540) } else { return linked_538.(*A_arbace_o2j_double_form_A).InvokePrim_O_D__O(root_537, lang.RT_DoubleCast_O__D_NoInit(arg_540)) } }




func A_arbace_o2j_const_form_A_New() *A_arbace_o2j_const_form_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_const_form_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_o2j_const_form_A) Ctor() {}
//line :147:1
func (t *A_arbace_o2j_const_form_A) Invoke_O_O__O(self, c__0 any) any { var vec__1641000081__2 any = c__0; var h__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000081__2, lang.RT_IntCast_J__I_NoInit(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000081__2, lang.RT_IntCast_J__I_NoInit(1), nil); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_121).Invoke_O__O(h__3)) {
		return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_124, a__4) } else {
//line :151:1
			var k__5 any; var root_560 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, A_arbace_o2j_fresh_A_fn_class); var ifn_562 lang.IFn

			if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = Lit_67; if linked_561 == nil { k__5 = ifn_562.Invoke_O__O(arg_563) } else { k__5 = linked_561.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_560, arg_563) }
			var root_580 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var tmp1 *lang.Keyword = A_arbace_o2j_A_const_125; var arg_583 any = tmp1.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_584 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var arg_585 any; var tmp2 any; var root_586 any = A_arbace_o2j_A_const_113.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_o2j_const_init_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = c__0; if linked_587 == nil { tmp2 = ifn_588.Invoke_O__O(arg_589) } else { tmp2 = linked_587.(*A_arbace_o2j_const_init_A).Invoke_O_O__O(root_586, arg_589) }; arg_585 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp2); if linked_581 == nil { ifn_582.Invoke_O_O_O__O(arg_583, arg_584, arg_585) } else { linked_581.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_580, arg_583, arg_584, arg_585) }
			var root_564 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_569 any = A_arbace_o2j_A_const_31.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var root_573 any = A_arbace_o2j_A_const_123.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_o2j_unit_class_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; if linked_574 == nil { arg_572 = ifn_575.Invoke__O() } else { arg_572 = linked_574.(*A_arbace_o2j_unit_class_A).Invoke_O__O(root_573) }; if linked_570 == nil { arg_567 = ifn_571.Invoke_O__O(arg_572) } else { arg_567 = linked_570.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_569, arg_572) }; var arg_568 any; var root_576 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = k__5; if linked_577 == nil { arg_568 = ifn_578.Invoke_O__O(arg_579) } else { arg_568 = linked_577.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_576, arg_579) }; if linked_565 == nil { return ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { return linked_565.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_564, arg_567, arg_568) } } }






func A_arbace_o2j_bound_and_refs_A_New() *A_arbace_o2j_bound_and_refs_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_bound_and_refs_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_o2j_bound_and_refs_A) Ctor() {}
//line :162:1
func (t *A_arbace_o2j_bound_and_refs_A) Invoke_O_O__O(self, x__0 any) any { var bound__2 any; var root_590 any = A_arbace_o2j_A_const_126.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_592 lang.IFn; if


	linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_591 == nil { bound__2 = ifn_592.Invoke_O__O(arg_593) } else { bound__2 = linked_591.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_590, arg_593) }; var refs__3 any; var root_594 any = /*line :162:1*/A_arbace_o2j_A_const_126.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_596 lang.IFn; if


	linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_595 == nil { refs__3 = ifn_596.Invoke_O__O(arg_597) } else { refs__3 = linked_595.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_594, arg_597) }; var body_walk__4 /*line :162:1*/*A_arbace_o2j_bound_and_refs_walk__1641000085_A = A_arbace_o2j_bound_and_refs_walk__1641000085_A_New_O_O_O(nil, bound__2, refs__3); var body_walk_any__5 *A_arbace_o2j_bound_and_refs_walk_any__1641000149_A = A_arbace_o2j_bound_and_refs_walk_any__1641000149_A_New_O(nil); var walk__4 any; var fnbody__853 any = any(body_walk__4); var tmp1 *jrt.Class; var fncls__852 *jrt.Class = A_arbace_o2j_bound_and_refs_walk__1641000085_A_fn_class; if fncls__852 == nil { var fncls__852d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__853); A_arbace_o2j_bound_and_refs_walk__1641000085_A_fn_class = fncls__852d; tmp1 = fncls__852d } else { tmp1 = fncls__852 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__853, tmp1, nil); var walk_any__5 any; var fnbody__855 any = any(body_walk_any__5); var tmp2 *jrt.Class; var fncls__854 *jrt.Class = A_arbace_o2j_bound_and_refs_walk_any__1641000149_A_fn_class; if fncls__854 == nil { var fncls__854d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__855); A_arbace_o2j_bound_and_refs_walk_any__1641000149_A_fn_class = fncls__854d; tmp2 = fncls__854d } else { tmp2 = fncls__854 }; walk_any__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__855, tmp2, nil); body_walk__4.F_walk_any = walk_any__5; body_walk_any__5.F_walk = walk__4;

























	lang.IFn_Cast(walk__4).Invoke_O__O(x__0); var tmp3 any; var root_856 any = /*line :162:1*/A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_858 lang.IFn; if


	linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = bound__2; if linked_857 == nil { tmp3 = ifn_858.Invoke_O__O(arg_859) } else { tmp3 = linked_857.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_856, arg_859) }; var tmp4 any = tmp3; var tmp5 any; var root_860 any = /*line :162:1*/A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_862 lang.IFn; if


	linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = refs__3; if linked_861 == nil { tmp5 = ifn_862.Invoke_O__O(arg_863) } else { tmp5 = linked_861.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_860, arg_863) }; return /*line :162:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) }



func A_arbace_o2j_bound_and_refs_walk__1641000085_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_bound_and_refs_walk__1641000085_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_bound_and_refs_walk__1641000085_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :166:1
func (t *A_arbace_o2j_bound_and_refs_walk__1641000085_A) Ctor_O_O_O(c__walk_any, c__bound, c__refs any) { t.F_walk_any = c__walk_any; t.F_bound = c__bound; t.F_refs = c__refs }
//line :166:1
func (t *A_arbace_o2j_bound_and_refs_walk__1641000085_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_598 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = x__1; if linked_599 == nil { tmp1 = ifn_600.Invoke_O__O(arg_601) } else { tmp1 = linked_599.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp1) { var h__2 any; var root_602 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_604 lang.IFn
		if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = x__1; if linked_603 == nil { h__2 = ifn_604.Invoke_O__O(arg_605) } else { h__2 = linked_603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_602, arg_605) }
//line :167:1
		var b__3 any; var root_606 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_o2j_node_body_A_fn_class); var ifn_608 lang.IFn
		if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = x__1; if linked_607 == nil { b__3 = ifn_608.Invoke_O__O(arg_609) } else { b__3 = linked_607.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_606, arg_609) }
//line :167:1
		var G__1641000086__4_ any = h__2

		switch lang.Util_Hash_O__I_NoInit(G__1641000086__4_) >> 0 & 31 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_128) { var vec__1641000087__5 any = b__3; var id__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000087__5, lang.RT_IntCast_J__I_NoInit(0), nil); var lo__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000087__5, lang.RT_IntCast_J__I_NoInit(1), nil); var hi__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000087__5, lang.RT_IntCast_J__I_NoInit(2), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000087__5, lang.RT_IntCast_J__I_NoInit(3), nil); var body__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000087__5, lang.RT_IntCast_J__I_NoInit(4), nil); var tmp2 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp3 any; var root_660 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_662 lang.IFn; _ = ___9










			if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_664 any = id__6; if linked_661 == nil { tmp3 = ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { tmp3 = linked_661.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) }; jrt.NN(tmp2).Reset_O__O(tmp3); lang.IFn_Cast(self).Invoke_O__O(lo__7); lang.IFn_Cast(self).Invoke_O__O(hi__8); return lang.IFn_Cast(self).Invoke_O__O(body__10) }
//line :169:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_129) { var vec__1641000090__5 any





			if lang.Util_Equiv_O_O__Z_NoInit(h__2, A_arbace_o2j_A_const_130) { var root_611 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_611, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_615 any = b__3; if linked_612 == nil { vec__1641000090__5 = ifn_613.Invoke_O_O__O(A_arbace_o2j_A_const_60, arg_615) } else { vec__1641000090__5 = linked_612.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_611, 2, A_arbace_o2j_A_const_60, arg_615) } } else { var root_616 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_616, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_620 any = b__3; if linked_617 == nil { vec__1641000090__5 = ifn_618.Invoke_O_O__O(A_arbace_o2j_A_const_131, arg_620) } else { vec__1641000090__5 = linked_617.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_616, 1, A_arbace_o2j_A_const_131, arg_620) } }
//line :169:1
			var id__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000090__5, lang.RT_IntCast_J__I_NoInit(0), nil); var def__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000090__5, lang.RT_IntCast_J__I_NoInit(1), nil); var body__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000090__5, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp4 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp5 any; var root_665 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_667 lang.IFn






			if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_669 any = id__6_2; if linked_666 == nil { tmp5 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { tmp5 = linked_666.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; jrt.NN(tmp4).Reset_O__O(tmp5); lang.IFn_Cast(self).Invoke_O__O(def__7); return lang.IFn_Cast(self).Invoke_O__O(body__8) }
//line :169:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_132) { var vec__1641000093__5 any





			if lang.Util_Equiv_O_O__Z_NoInit(h__2, A_arbace_o2j_A_const_130) { var root_621 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_621, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_625 any = b__3; if linked_622 == nil { vec__1641000093__5 = ifn_623.Invoke_O_O__O(A_arbace_o2j_A_const_60, arg_625) } else { vec__1641000093__5 = linked_622.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_621, 2, A_arbace_o2j_A_const_60, arg_625) } } else { var root_626 any = A_arbace_o2j_A_const_59.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_626, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_630 any = b__3; if linked_627 == nil { vec__1641000093__5 = ifn_628.Invoke_O_O__O(A_arbace_o2j_A_const_131, arg_630) } else { vec__1641000093__5 = linked_627.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_626, 1, A_arbace_o2j_A_const_131, arg_630) } }
//line :169:1
			var id__6_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000093__5, lang.RT_IntCast_J__I_NoInit(0), nil); var def__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000093__5, lang.RT_IntCast_J__I_NoInit(1), nil); var body__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000093__5, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp7 any; var root_670 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_672 lang.IFn






			if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_674 any = id__6_3; if linked_671 == nil { tmp7 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { tmp7 = linked_671.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; jrt.NN(tmp6).Reset_O__O(tmp7); lang.IFn_Cast(self).Invoke_O__O(def__7_2); return lang.IFn_Cast(self).Invoke_O__O(body__8_2) }
//line :169:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_133) {
			var tmp8 *lang.Volatile = lang.Volatile_Cast(t.F_refs); var tmp9 any; var root_631 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = jrt.NN(lang.Volatile_Cast(t.F_refs)).Deref__O(); var arg_635 any; var root_636 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = b__3; if linked_637 == nil { arg_635 = ifn_638.Invoke_O__O(arg_639) } else { arg_635 = linked_637.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_636, arg_639) }; if linked_632 == nil { tmp9 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { tmp9 = linked_632.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }; return jrt.NN(tmp8).Reset_O__O(tmp9) }
//line :169:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_134) { var vec__1641000096__5 any = b__3; var bs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000096__5, lang.RT_IntCast_J__I_NoInit(0), nil); var body__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000096__5, lang.RT_IntCast_J__I_NoInit(1), nil); var seq_1641000099__8 any; var root_675 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn








			if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = bs__6; if linked_676 == nil { seq_1641000099__8 = ifn_677.Invoke_O__O(arg_678) } else { seq_1641000099__8 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }
//line :169:1
			var chunk_1641000100__9 any; var count_1641000101__10 int64 = 0; var i_1641000102__11 int64 = 0; L2: for {








				if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000102__11, count_1641000101__10) { var vec__1641000103__12 any = lang.Indexed_Cast(chunk_1641000100__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000102__11)); var id__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000103__12, lang.RT_IntCast_J__I_NoInit(0), nil); var f__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000103__12, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp11 any; var root_695 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_699 any = id__13; if linked_696 == nil { tmp11 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { tmp11 = linked_696.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; jrt.NN(tmp10).Reset_O__O(tmp11); lang.IFn_Cast(self).Invoke_O__O(f__14); seq_1641000099__8, chunk_1641000100__9, count_1641000101__10, i_1641000102__11 = seq_1641000099__8, chunk_1641000100__9, count_1641000101__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000102__11); continue L2 } else { var temp__1927000414__auto____12 any; var root_679 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq_1641000099__8; if linked_680 == nil { temp__1927000414__auto____12 = ifn_681.Invoke_O__O(arg_682) } else { temp__1927000414__auto____12 = linked_680.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1641000099__13 any = temp__1927000414__auto____12; var tmp12 any; var root_683 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = seq_1641000099__13; if linked_684 == nil { tmp12 = ifn_685.Invoke_O__O(arg_686) } else { tmp12 = linked_684.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_683, arg_686) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____14 any; var root_687 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = seq_1641000099__13; if linked_688 == nil { c__1927000678__auto____14 = ifn_689.Invoke_O__O(arg_690) } else { c__1927000678__auto____14 = linked_688.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_687, arg_690) }; var tmp13 any; var root_700 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = seq_1641000099__13; if linked_701 == nil { tmp13 = ifn_702.Invoke_O__O(arg_703) } else { tmp13 = linked_701.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_700, arg_703) }; seq_1641000099__8, chunk_1641000100__9, count_1641000101__10, i_1641000102__11 = tmp13, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1641000106__14 any; var root_691 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = seq_1641000099__13; if linked_692 == nil { vec__1641000106__14 = ifn_693.Invoke_O__O(arg_694) } else { vec__1641000106__14 = linked_692.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_691, arg_694) }; var id__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000106__14, lang.RT_IntCast_J__I_NoInit(0), nil); var f__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000106__14, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp15 any; var root_704 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_708 any = id__15; if linked_705 == nil { tmp15 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { tmp15 = linked_705.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }; jrt.NN(tmp14).Reset_O__O(tmp15); lang.IFn_Cast(self).Invoke_O__O(f__16); var tmp16 any; var root_709 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_1641000099__13; if linked_710 == nil { tmp16 = ifn_711.Invoke_O__O(arg_712) } else { tmp16 = linked_710.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_709, arg_712) }; seq_1641000099__8, chunk_1641000100__9, count_1641000101__10, i_1641000102__11 = tmp16, nil, 0, 0; continue L2 } } }
//line :169:1
				break L2
			}








			return lang.IFn_Cast(self).Invoke_O__O(body__7) }
//line :169:1
		case 17: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_135) { var vec__1641000109__5 any = b__3; var body__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000109__5, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1641000112__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000109__5, lang.RT_IntCast_J__I_NoInit(1), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000112__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vs__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000112__7, lang.RT_IntCast_J__I_NoInit(1), nil); var handler__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000109__5, lang.RT_IntCast_J__I_NoInit(2), nil); var seq_1641000115__11 any; var root_713 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_715 lang.IFn; _ = ___8













			if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = vs__9; if linked_714 == nil { seq_1641000115__11 = ifn_715.Invoke_O__O(arg_716) } else { seq_1641000115__11 = linked_714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_713, arg_716) }
//line :169:1
			var chunk_1641000116__12 any; var count_1641000117__13 int64 = 0; var i_1641000118__14 int64 = 0; L3: for {













				if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000118__14, count_1641000117__13) { var vec__1641000119__15 any = lang.Indexed_Cast(chunk_1641000116__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000118__14)); var v__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000119__15, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp17 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp18 any; var root_733 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_737 any = v__16; if linked_734 == nil { tmp18 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { tmp18 = linked_734.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }; jrt.NN(tmp17).Reset_O__O(tmp18); seq_1641000115__11, chunk_1641000116__12, count_1641000117__13, i_1641000118__14 = seq_1641000115__11, chunk_1641000116__12, count_1641000117__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000118__14); continue L3 } else { var temp__1927000414__auto____15 any; var root_717 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1641000115__11; if linked_718 == nil { temp__1927000414__auto____15 = ifn_719.Invoke_O__O(arg_720) } else { temp__1927000414__auto____15 = linked_718.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1641000115__16 any = temp__1927000414__auto____15; var tmp19 any; var root_721 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seq_1641000115__16; if linked_722 == nil { tmp19 = ifn_723.Invoke_O__O(arg_724) } else { tmp19 = linked_722.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_721, arg_724) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____17 any; var root_725 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1641000115__16; if linked_726 == nil { c__1927000678__auto____17 = ifn_727.Invoke_O__O(arg_728) } else { c__1927000678__auto____17 = linked_726.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_725, arg_728) }; var tmp20 any; var root_738 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = seq_1641000115__16; if linked_739 == nil { tmp20 = ifn_740.Invoke_O__O(arg_741) } else { tmp20 = linked_739.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_738, arg_741) }; seq_1641000115__11, chunk_1641000116__12, count_1641000117__13, i_1641000118__14 = tmp20, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1641000122__17 any; var root_729 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1641000115__16; if linked_730 == nil { vec__1641000122__17 = ifn_731.Invoke_O__O(arg_732) } else { vec__1641000122__17 = linked_730.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_729, arg_732) }; var v__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000122__17, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp21 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp22 any; var root_742 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_746 any = v__18; if linked_743 == nil { tmp22 = ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { tmp22 = linked_743.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_742, arg_745, arg_746) }; jrt.NN(tmp21).Reset_O__O(tmp22); var tmp23 any; var root_747 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = seq_1641000115__16; if linked_748 == nil { tmp23 = ifn_749.Invoke_O__O(arg_750) } else { tmp23 = linked_748.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_747, arg_750) }; seq_1641000115__11, chunk_1641000116__12, count_1641000117__13, i_1641000118__14 = tmp23, nil, 0, 0; continue L3 } } }
//line :169:1
				break L3
			}













			lang.IFn_Cast(self).Invoke_O__O(body__6); return lang.IFn_Cast(self).Invoke_O__O(handler__10) }
//line :169:1
		case 18: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_137) { return nil }; case 20: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_138) {
			var tmp24 *lang.Volatile = lang.Volatile_Cast(t.F_refs); var tmp25 any; var root_751 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = jrt.NN(lang.Volatile_Cast(t.F_refs)).Deref__O(); var arg_755 any; var root_756 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = b__3; if linked_757 == nil { arg_755 = ifn_758.Invoke_O__O(arg_759) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_756, arg_759) }; if linked_752 == nil { tmp25 = ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { tmp25 = linked_752.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_751, arg_754, arg_755) }; return jrt.NN(tmp24).Reset_O__O(tmp25) }
//line :169:1
		case 23: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_139) { var vec__1641000125__5 any = b__3; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000125__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000125__5, lang.RT_IntCast_J__I_NoInit(1), nil); var ___8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000125__5, lang.RT_IntCast_J__I_NoInit(2), nil); var body__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000125__5, lang.RT_IntCast_J__I_NoInit(3), nil); var seq_1641000128__10 any; var root_760 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_762 lang.IFn; _ = ___6; _ = ___8_2



			if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = ps__7; if linked_761 == nil { seq_1641000128__10 = ifn_762.Invoke_O__O(arg_763) } else { seq_1641000128__10 = linked_761.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_760, arg_763) }
//line :169:1
			var chunk_1641000129__11 any; var count_1641000130__12 int64 = 0; var i_1641000131__13 int64 = 0; L4: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000131__13, count_1641000130__12) { var vec__1641000132__14 any = lang.Indexed_Cast(chunk_1641000129__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000131__13)); var p__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000132__14, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp26 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp27 any; var root_780 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_784 any = p__15; if linked_781 == nil { tmp27 = ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { tmp27 = linked_781.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_780, arg_783, arg_784) }; jrt.NN(tmp26).Reset_O__O(tmp27); seq_1641000128__10, chunk_1641000129__11, count_1641000130__12, i_1641000131__13 = seq_1641000128__10, chunk_1641000129__11, count_1641000130__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000131__13); continue L4 } else { var temp__1927000414__auto____14 any; var root_764 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = seq_1641000128__10; if linked_765 == nil { temp__1927000414__auto____14 = ifn_766.Invoke_O__O(arg_767) } else { temp__1927000414__auto____14 = linked_765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_764, arg_767) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1641000128__15 any = temp__1927000414__auto____14; var tmp28 any; var root_768 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = seq_1641000128__15; if linked_769 == nil { tmp28 = ifn_770.Invoke_O__O(arg_771) } else { tmp28 = linked_769.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(tmp28) { var c__1927000678__auto____16 any; var root_772 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = seq_1641000128__15; if linked_773 == nil { c__1927000678__auto____16 = ifn_774.Invoke_O__O(arg_775) } else { c__1927000678__auto____16 = linked_773.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_772, arg_775) }; var tmp29 any; var root_785 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = seq_1641000128__15; if linked_786 == nil { tmp29 = ifn_787.Invoke_O__O(arg_788) } else { tmp29 = linked_786.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_785, arg_788) }; seq_1641000128__10, chunk_1641000129__11, count_1641000130__12, i_1641000131__13 = tmp29, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1641000135__16 any; var root_776 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = seq_1641000128__15; if linked_777 == nil { vec__1641000135__16 = ifn_778.Invoke_O__O(arg_779) } else { vec__1641000135__16 = linked_777.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_776, arg_779) }; var p__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000135__16, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp30 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp31 any; var root_789 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_793 any = p__17; if linked_790 == nil { tmp31 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { tmp31 = linked_790.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; jrt.NN(tmp30).Reset_O__O(tmp31); var tmp32 any; var root_794 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = seq_1641000128__15; if linked_795 == nil { tmp32 = ifn_796.Invoke_O__O(arg_797) } else { tmp32 = linked_795.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_794, arg_797) }; seq_1641000128__10, chunk_1641000129__11, count_1641000130__12, i_1641000131__13 = tmp32, nil, 0, 0; continue L4 } } }
//line :169:1
				break L4
			}



			return lang.IFn_Cast(self).Invoke_O__O(body__9) }
//line :169:1
		case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_140) { var vec__1641000138__5 any = b__3; var body__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000138__5, lang.RT_IntCast_J__I_NoInit(0), nil); var id__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000138__5, lang.RT_IntCast_J__I_NoInit(1), nil); var handler__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000138__5, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp33 *lang.Volatile = lang.Volatile_Cast(t.F_bound); var tmp34 any; var root_798 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_800 lang.IFn











			if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = jrt.NN(lang.Volatile_Cast(t.F_bound)).Deref__O(); var arg_802 any = id__7; if linked_799 == nil { tmp34 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { tmp34 = linked_799.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; jrt.NN(tmp33).Reset_O__O(tmp34); lang.IFn_Cast(self).Invoke_O__O(body__6_2); return lang.IFn_Cast(self).Invoke_O__O(handler__8) }
//line :169:1
		case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000086__4_, A_arbace_o2j_A_const_141) { var vec__1641000141__5 any = b__3; var id__6_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000141__5, lang.RT_IntCast_J__I_NoInit(0), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000141__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp35 *lang.Volatile = lang.Volatile_Cast(t.F_refs); var tmp36 any; var root_803 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_805 lang.IFn















			if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = jrt.NN(lang.Volatile_Cast(t.F_refs)).Deref__O(); var arg_807 any = id__6_4; if linked_804 == nil { tmp36 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { tmp36 = linked_804.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; jrt.NN(tmp35).Reset_O__O(tmp36); return lang.IFn_Cast(self).Invoke_O__O(e__7) }
//line :169:1
		default:}; var seq_1641000144__5 any; var root_640 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_642 lang.IFn
















		if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = b__3; if linked_641 == nil { seq_1641000144__5 = ifn_642.Invoke_O__O(arg_643) } else { seq_1641000144__5 = linked_641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_640, arg_643) }
//line :169:1
		var chunk_1641000145__6 any; var count_1641000146__7 int64 = 0; var i_1641000147__8 int64 = 0; L5: for {
















			if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000147__8, count_1641000146__7) { var y__9 any = lang.Indexed_Cast(chunk_1641000145__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000147__8)); lang.IFn_Cast(t.F_walk_any).Invoke_O__O(y__9); seq_1641000144__5, chunk_1641000145__6, count_1641000146__7, i_1641000147__8 = seq_1641000144__5, chunk_1641000145__6, count_1641000146__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000147__8); continue L5 } else { var temp__1927000414__auto____9 any; var root_644 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = seq_1641000144__5; if linked_645 == nil { temp__1927000414__auto____9 = ifn_646.Invoke_O__O(arg_647) } else { temp__1927000414__auto____9 = linked_645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_644, arg_647) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1641000144__10 any = temp__1927000414__auto____9; var tmp37 any; var root_648 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = seq_1641000144__10; if linked_649 == nil { tmp37 = ifn_650.Invoke_O__O(arg_651) } else { tmp37 = linked_649.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp37) { var c__1927000678__auto____11 any; var root_652 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = seq_1641000144__10; if linked_653 == nil { c__1927000678__auto____11 = ifn_654.Invoke_O__O(arg_655) } else { c__1927000678__auto____11 = linked_653.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_652, arg_655) }; var tmp38 any; var root_808 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = seq_1641000144__10; if linked_809 == nil { tmp38 = ifn_810.Invoke_O__O(arg_811) } else { tmp38 = linked_809.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_808, arg_811) }; seq_1641000144__5, chunk_1641000145__6, count_1641000146__7, i_1641000147__8 = tmp38, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var y__11 any; var root_656 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = seq_1641000144__10; if linked_657 == nil { y__11 = ifn_658.Invoke_O__O(arg_659) } else { y__11 = linked_657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_656, arg_659) }; lang.IFn_Cast(t.F_walk_any).Invoke_O__O(y__11); var tmp39 any; var root_812 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = seq_1641000144__10; if linked_813 == nil { tmp39 = ifn_814.Invoke_O__O(arg_815) } else { tmp39 = linked_813.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_812, arg_815) }; seq_1641000144__5, chunk_1641000145__6, count_1641000146__7, i_1641000147__8 = tmp39, nil, 0, 0; continue L5 } } else { return nil } } } } else {
//line :167:1
				return nil } }
//line :166:1
	panic("j2g: unreachable") }
//line :166:1
func A_arbace_o2j_bound_and_refs_walk_any__1641000149_A_New_O(p0 any) *A_arbace_o2j_bound_and_refs_walk_any__1641000149_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_bound_and_refs_walk_any__1641000149_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_o2j_bound_and_refs_walk_any__1641000149_A) Ctor_O(c__walk any) { t.F_walk = c__walk }
//line :166:1
func (t *A_arbace_o2j_bound_and_refs_walk_any__1641000149_A) Invoke_O_O__O(self, y__1 any) any {




















	{ var tmp1 any; var root_816 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = y__1; if linked_817 == nil { tmp1 = ifn_818.Invoke_O__O(arg_819) } else { tmp1 = linked_817.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_816, arg_819) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(t.F_walk).Invoke_O__O(y__1) } else { var tmp2 any; var root_820 any = A_arbace_o2j_A_const_42.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = y__1; if linked_821 == nil { tmp2 = ifn_822.Invoke_O__O(arg_823) } else { tmp2 = linked_821.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_820, arg_823) }; if jrt.J2g_Truth(tmp2) { var seq_1641000150__2 any; var root_824 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = y__1; if linked_825 == nil { seq_1641000150__2 = ifn_826.Invoke_O__O(arg_827) } else { seq_1641000150__2 = linked_825.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_824, arg_827) }; var chunk_1641000151__3 any; var count_1641000152__4 int64 = 0; var i_1641000153__5 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000153__5, count_1641000152__4) { var z__6 any = lang.Indexed_Cast(chunk_1641000151__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000153__5)); lang.IFn_Cast(self).Invoke_O__O(z__6); seq_1641000150__2, chunk_1641000151__3, count_1641000152__4, i_1641000153__5 = seq_1641000150__2, chunk_1641000151__3, count_1641000152__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000153__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_828 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = seq_1641000150__2; if linked_829 == nil { temp__1927000414__auto____6 = ifn_830.Invoke_O__O(arg_831) } else { temp__1927000414__auto____6 = linked_829.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_828, arg_831) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1641000150__7 any = temp__1927000414__auto____6; var tmp3 any; var root_832 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = seq_1641000150__7; if linked_833 == nil { tmp3 = ifn_834.Invoke_O__O(arg_835) } else { tmp3 = linked_833.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_832, arg_835) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_836 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = seq_1641000150__7; if linked_837 == nil { c__1927000678__auto____8 = ifn_838.Invoke_O__O(arg_839) } else { c__1927000678__auto____8 = linked_837.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_836, arg_839) }; var tmp4 any; var root_844 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = seq_1641000150__7; if linked_845 == nil { tmp4 = ifn_846.Invoke_O__O(arg_847) } else { tmp4 = linked_845.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_844, arg_847) }; seq_1641000150__2, chunk_1641000151__3, count_1641000152__4, i_1641000153__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var z__8 any; var root_840 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = seq_1641000150__7; if linked_841 == nil { z__8 = ifn_842.Invoke_O__O(arg_843) } else { z__8 = linked_841.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_840, arg_843) }; lang.IFn_Cast(self).Invoke_O__O(z__8); var tmp5 any; var root_848 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = seq_1641000150__7; if linked_849 == nil { tmp5 = ifn_850.Invoke_O__O(arg_851) } else { tmp5 = linked_849.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_848, arg_851) }; seq_1641000150__2, chunk_1641000151__3, count_1641000152__4, i_1641000153__5 = tmp5, nil, 0, 0; continue L1 } } else { return nil } } } } else { if A_arbace_o2j_A_const_44 != nil { return nil } else { return nil } } } }
//line :166:1
	panic("j2g: unreachable")
}























func A_arbace_o2j_free_ids_A_New() *A_arbace_o2j_free_ids_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_free_ids_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_o2j_free_ids_A) Ctor() {}
//line :191:1
func (t *A_arbace_o2j_free_ids_A) Invoke_O_O__O(self, f__0 any) any { var vec__1641000156__2 any; var root_864 any = A_arbace_o2j_A_const_142.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_o2j_bound_and_refs_A_fn_class); var ifn_866 lang.IFn; if


	linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = f__0; if linked_865 == nil { vec__1641000156__2 = ifn_866.Invoke_O__O(arg_867) } else { vec__1641000156__2 = linked_865.(*A_arbace_o2j_bound_and_refs_A).Invoke_O_O__O(root_864, arg_867) }; var bound__3 any = /*line :191:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1641000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var refs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_868 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_870 lang.IFn; if



	linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any; var root_872 any = A_arbace_o2j_A_const_144.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = bound__3; var arg_876 any = refs__4; if linked_873 == nil { arg_871 = ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { arg_871 = linked_873.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_872, arg_875, arg_876) }; if linked_869 == nil { return ifn_870.Invoke_O__O(arg_871) } else { return linked_869.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_868, arg_871) } }








func A_arbace_o2j_lookup_A_New() *A_arbace_o2j_lookup_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_lookup_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_o2j_lookup_A) Ctor() {}
//line :204:1
func (t *A_arbace_o2j_lookup_A) Invoke_O_O_O__O(self, ctx__0, id__1 any) any { var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_o2j_A_const_145.Invoke_O__O(ctx__0), id__1); if
										jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_877 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_879 lang.IFn
											if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, id__1)).Ref(); var arg_881 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_146, id__1)); if linked_878 == nil { tmp1 = ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { tmp1 = linked_878.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_877, arg_880, arg_881) }
//line :205:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }


func A_arbace_o2j_simple_QMARK__A_New() *A_arbace_o2j_simple_QMARK__A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_simple_QMARK__A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_o2j_simple_QMARK__A) Ctor() {}
//line :208:1
func (t *A_arbace_o2j_simple_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var h__2 any; var root_882 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, A_arbace_o2j_hd_A_fn_class); var ifn_884 lang.IFn; if


	linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = x__0; if linked_883 == nil { h__2 = ifn_884.Invoke_O__O(arg_885) } else { h__2 = linked_883.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_882, arg_885) }; var or__1927000174__auto____3 bool = /*line :208:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_147, h__2); if or__1927000174__auto____3 {



		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_148, h__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_149, h__2)
			if and__1927000168__auto____5 { var vec__1641000161__6 any; var root_886 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_o2j_node_body_A_fn_class); var ifn_888 lang.IFn
				if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = x__0; if linked_887 == nil { vec__1641000161__6 = ifn_888.Invoke_O__O(arg_889) } else { vec__1641000161__6 = linked_887.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_886, arg_889) }
//line :213:1
				var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000161__6, lang.RT_IntCast_J__I_NoInit(0), nil); var args__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000161__6, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____9 any; var root_890 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_892 lang.IFn

				if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = n__7; var arg_894 any = Lit_116; if linked_891 == nil { or__1927000174__auto____9 = ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { or__1927000174__auto____9 = linked_891.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_890, arg_893, arg_894) }; if jrt.J2g_Truth(or__1927000174__auto____9) { return or__1927000174__auto____9 } else { var and__1927000168__auto____10 any; var root_895 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_897 lang.IFn
					if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = n__7; var arg_899 any = Lit_168; if linked_896 == nil { and__1927000168__auto____10 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { and__1927000168__auto____10 = linked_896.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_900 any = A_arbace_o2j_A_const_150.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_o2j_simple_QMARK__A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_904 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = args__8; if linked_905 == nil { arg_903 = ifn_906.Invoke_O__O(arg_907) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_904, arg_907) }; if linked_901 == nil { return ifn_902.Invoke_O__O(arg_903) } else { return linked_901.(*A_arbace_o2j_simple_QMARK__A).Invoke_O_O__O(root_900, arg_903) } } else { return and__1927000168__auto____10 } } } else {
//line :213:1
						return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } } }




func A_arbace_o2j_with_args_A_New() *A_arbace_o2j_with_args_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_o2j_with_args_A) Ctor() {}
//line :218:1
func (t *A_arbace_o2j_with_args_A) Invoke_O_O_O_O__O(self, ctx__0, nodes__1, k__2 any) any { var impure__4 any; var root_908 any = A_arbace_o2j_A_const_151.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_910 lang.IFn; if



	linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any; var fnbody__918 any = A_arbace_o2j_with_args_fn__1641000165_A_New(); var tmp1 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_o2j_with_args_fn__1641000165_A_fn_class; if fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_201, false, nil); A_arbace_o2j_with_args_fn__1641000165_A_fn_class = fncls__917d; tmp1 = fncls__917d } else { tmp1 = fncls__917 }; arg_911 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__918, tmp1, nil); var arg_912 any = nodes__1; if linked_909 == nil { impure__4 = ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { impure__4 = linked_909.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_908, arg_911, arg_912) }; var bind__5 any; var root_919 any = /*line :218:1*/A_arbace_o2j_A_const_152.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_921 lang.IFn; if




	linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any; var root_923 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = impure__4; if linked_924 == nil { arg_922 = ifn_925.Invoke_O__O(arg_926) } else { arg_922 = linked_924.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_923, arg_926) }; if linked_920 == nil { bind__5 = ifn_921.Invoke_O__O(arg_922) } else { bind__5 = linked_920.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_919, arg_922) }; var temps__6 any; var root_927 any = /*line :218:1*/A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_929 lang.IFn; if





	linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_931 any; var iter__1927001039__auto____6 any; var fnbody__1001 any = A_arbace_o2j_with_args_iter__1641000167__1641000171_A_New(); var tmp2 *jrt.Class; var fncls__1000 *jrt.Class = A_arbace_o2j_with_args_iter__1641000167__1641000171_A_fn_class; if fncls__1000 == nil { var fncls__1000d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_202, false, nil); A_arbace_o2j_with_args_iter__1641000167__1641000171_A_fn_class = fncls__1000d; tmp2 = fncls__1000d } else { tmp2 = fncls__1000 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1001, tmp2, nil); arg_931 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(bind__5); if linked_928 == nil { temps__6 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { temps__6 = linked_928.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; var forms__7 any; var root_1002 any = /*line :218:1*/A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1004 lang.IFn; if






	linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var root_1006 any = A_arbace_o2j_A_const_154.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any; var fnbody__1018 any = A_arbace_o2j_with_args_fn__1641000177_A_New_O_O(ctx__0, temps__6); var tmp3 *jrt.Class; var fncls__1017 *jrt.Class = A_arbace_o2j_with_args_fn__1641000177_A_fn_class; if fncls__1017 == nil { var fncls__1017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_203, false, fnbody__1018); A_arbace_o2j_with_args_fn__1641000177_A_fn_class = fncls__1017d; tmp3 = fncls__1017d } else { tmp3 = fncls__1017 }; arg_1009 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1018, tmp3, nil); var arg_1010 any = nodes__1; if linked_1007 == nil { arg_1005 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { arg_1005 = linked_1007.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }; if linked_1003 == nil { forms__7 = ifn_1004.Invoke_O__O(arg_1005) } else { forms__7 = linked_1003.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1002, arg_1005) }; var bindings__8 any; var root_1019 any = /*line :218:1*/A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1021 lang.IFn; if







	linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__1035 any = A_arbace_o2j_with_args_fn__1641000179_A_New_O_O_O(ctx__0, nodes__1, temps__6); var tmp6 *jrt.Class; var fncls__1034 *jrt.Class = A_arbace_o2j_with_args_fn__1641000179_A_fn_class; if fncls__1034 == nil { var fncls__1034d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_204, false, fnbody__1035); A_arbace_o2j_with_args_fn__1641000179_A_fn_class = fncls__1034d; tmp6 = fncls__1034d } else { tmp6 = fncls__1034 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1035, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 any; var root_1036 any = A_arbace_o2j_A_const_157.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1038 lang.IFn; if
	linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any; var root_1040 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = bind__5; if linked_1041 == nil { arg_1039 = ifn_1042.Invoke_O__O(arg_1043) } else { arg_1039 = linked_1041.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1040, arg_1043) }; if linked_1037 == nil { tmp8 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp8 = linked_1037.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1036, arg_1039) }; arg_1022 = /*line :226:1*/tmp4.Invoke_O_O__O(tmp7, tmp8); if linked_1020 == nil { bindings__8 = ifn_1021.Invoke_O__O(arg_1022) } else { bindings__8 = linked_1020.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1019, arg_1022) }; var body__9 any = /*line :218:1*/lang.IFn_Cast(k__2).Invoke_O__O(forms__7); var tmp9 any; var root_1044 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1046 lang.IFn; if










	linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = bindings__8; if linked_1045 == nil { tmp9 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp9 = linked_1045.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1044, arg_1047) }; if jrt.J2g_Truth(tmp9) { return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_158, bindings__8, body__9) } else { return body__9 } }
//line :222:1
func A_arbace_o2j_with_args_fn__1641000165_A_New() *A_arbace_o2j_with_args_fn__1641000165_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_fn__1641000165_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_o2j_with_args_fn__1641000165_A) Ctor() {}
//line :222:1
func (t *A_arbace_o2j_with_args_fn__1641000165_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var tmp1 any; var root_913 any = A_arbace_o2j_A_const_150.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_o2j_simple_QMARK__A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = x__2; if linked_914 == nil { tmp1 = ifn_915.Invoke_O__O(arg_916) } else { tmp1 = linked_914.(*A_arbace_o2j_simple_QMARK__A).Invoke_O_O__O(root_913, arg_916) }; if jrt.J2g_Truth(tmp1) { return nil } else { return i__1 } }

func A_arbace_o2j_with_args_iter__1641000167__1641000171_A_New() *A_arbace_o2j_with_args_iter__1641000167__1641000171_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_iter__1641000167__1641000171_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_A) Ctor() {}
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_A) Invoke_O_O__O(self, s__1641000168__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__999 any = A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A_New_O_O(s__1641000168__1, self); var tmp2 *jrt.Class; var fncls__998 *jrt.Class = A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A_fn_class; if fncls__998 == nil { var fncls__998d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_205, false, fnbody__999); A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A_fn_class = fncls__998d; tmp2 = fncls__998d } else { tmp2 = fncls__998 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__999, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :224:1
func A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A_New_O_O(p0, p1 any) *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A{}; t.Ctor_O_O(p0, p1); return t }
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A) Ctor_O_O(c__s__1641000168, c__iter__1641000167 any) { t.F_s__1641000168 = c__s__1641000168; t.F_iter__1641000167 = c__iter__1641000167 }
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A) Invoke_O__O(self any) any { { var s__1641000168__1 any; var t_ any = t.F_s__1641000168; t.F_s__1641000168 = nil; s__1641000168__1 = t_; for { var temp__1927000414__auto____2 any; var root_932 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = s__1641000168__1; if linked_933 == nil { temp__1927000414__auto____2 = ifn_934.Invoke_O__O(arg_935) } else { temp__1927000414__auto____2 = linked_933.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_932, arg_935) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000168__3 any = temp__1927000414__auto____2; var tmp1 any; var root_936 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__1641000168__3; if linked_937 == nil { tmp1 = ifn_938.Invoke_O__O(arg_939) } else { tmp1 = linked_937.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_936, arg_939) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_940 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = s__1641000168__3; if linked_941 == nil { c__1927001037__auto____4 = ifn_942.Invoke_O__O(arg_943) } else { c__1927001037__auto____4 = linked_941.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_940, arg_943) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000170__6 any; var root_944 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_945 == nil { b__1641000170__6 = ifn_946.Invoke_O__O(arg_947) } else { b__1641000170__6 = linked_945.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_944, arg_947) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__958 any = A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A_New_O_I_O(b__1641000170__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__957 *jrt.Class = A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A_fn_class; if fncls__957 == nil { var fncls__957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_206, false, fnbody__958); A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A_fn_class = fncls__957d; tmp3 = fncls__957d } else { tmp3 = fncls__957 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__958, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_959 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var root_964 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = b__1641000170__6; if linked_965 == nil { arg_962 = ifn_966.Invoke_O__O(arg_967) } else { arg_962 = linked_965.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_964, arg_967) }; var arg_963 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000167); var tmp5 any; var root_968 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__1641000168__3; if linked_969 == nil { tmp5 = ifn_970.Invoke_O__O(arg_971) } else { tmp5 = linked_969.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_968, arg_971) }; arg_963 = tmp4.Invoke_O__O(tmp5); if linked_960 == nil { return ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { return linked_960.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) } } else { var root_972 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var root_977 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = b__1641000170__6; if linked_978 == nil { arg_975 = ifn_979.Invoke_O__O(arg_980) } else { arg_975 = linked_978.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_977, arg_980) }; var arg_976 any; if linked_973 == nil { return ifn_974.Invoke_O_O__O(arg_975, arg_976) } else { return linked_973.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_972, arg_975, arg_976) } } } else { var i__4 any; var root_981 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = s__1641000168__3; if linked_982 == nil { i__4 = ifn_983.Invoke_O__O(arg_984) } else { i__4 = linked_982.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_981, arg_984) }; var root_985 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any; var tmp6 any; var root_990 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, A_arbace_o2j_fresh_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = Lit_80; if linked_991 == nil { tmp6 = ifn_992.Invoke_O__O(arg_993) } else { tmp6 = linked_991.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_990, arg_993) }; arg_988 = lang.Tuple_Create_O_O__IPersistentVector(i__4, tmp6); var arg_989 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1641000167); var tmp8 any; var root_994 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = s__1641000168__3; if linked_995 == nil { tmp8 = ifn_996.Invoke_O__O(arg_997) } else { tmp8 = linked_995.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_994, arg_997) }; arg_989 = tmp7.Invoke_O__O(tmp8); if linked_986 == nil { return ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { return linked_986.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_985, arg_988, arg_989) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :224:1
func A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A) Ctor_O_I_O(c__b__1641000170 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000170 = c__b__1641000170; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :224:1
func (t *A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A) Invoke_O__O(self any) any { { var i__1641000169__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000169__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000169__1)); var root_948 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = t.F_b__1641000170; var arg_952 any; var tmp2 any; var root_953 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, A_arbace_o2j_fresh_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = Lit_80; if linked_954 == nil { tmp2 = ifn_955.Invoke_O__O(arg_956) } else { tmp2 = linked_954.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_953, arg_956) }; arg_952 = lang.Tuple_Create_O_O__IPersistentVector(i__2, tmp2); if linked_949 == nil { ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { linked_949.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_948, arg_951, arg_952) }; i__1641000169__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000169__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_o2j_with_args_fn__1641000177_A_New_O_O(p0, p1 any) *A_arbace_o2j_with_args_fn__1641000177_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_fn__1641000177_A{}; t.Ctor_O_O(p0, p1); return t }
//line :225:1
func (t *A_arbace_o2j_with_args_fn__1641000177_A) Ctor_O_O(c__ctx, c__temps any) { t.F_ctx = c__ctx; t.F_temps = c__temps }
//line :225:1
func (t *A_arbace_o2j_with_args_fn__1641000177_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(t.F_temps).Invoke_O__O(i__1); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_1011 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_o2j_expr_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = t.F_ctx; var arg_1015 any = x__2; var arg_1016 any = jrt.Boolean_FALSE.Ref(); if linked_1012 == nil { return ifn_1013.Invoke_O_O_O__O(arg_1014, arg_1015, arg_1016) } else { return linked_1012.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1011, arg_1014, arg_1015, arg_1016) } } }
func A_arbace_o2j_with_args_fn__1641000179_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_with_args_fn__1641000179_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_with_args_fn__1641000179_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :226:1
func (t *A_arbace_o2j_with_args_fn__1641000179_A) Ctor_O_O_O(c__ctx, c__nodes, c__temps any) { t.F_ctx = c__ctx; t.F_nodes = c__nodes; t.F_temps = c__temps }
//line :226:1
func (t *A_arbace_o2j_with_args_fn__1641000179_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 any = lang.IFn_Cast(t.F_temps).Invoke_O__O(i__1); var tmp2 any; var root_1028 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, A_arbace_o2j_expr_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = t.F_ctx; var tmp3 any = t.F_nodes; var arg_1032 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__1)); var arg_1033 any = jrt.Boolean_FALSE.Ref(); if linked_1029 == nil { tmp2 = ifn_1030.Invoke_O_O_O__O(arg_1031, arg_1032, arg_1033) } else { tmp2 = linked_1029.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1028, arg_1031, arg_1032, arg_1033) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_o2j_call_form_A_New() *A_arbace_o2j_call_form_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_call_form_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_o2j_call_form_A) Ctor() {}
//line :231:1
func (t *A_arbace_o2j_call_form_A) Invoke_O_O_O__O(self, f__0, args__1 any) any { var n__3 int32 = lang.RT_Count_O__I_NoInit(args__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_159.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_131; if



	jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(), A_arbace_o2j_A_const_160)) { var c__4 any; var root_1054 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, A_arbace_o2j_fresh_A_fn_class); var ifn_1056 lang.IFn
		if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = Lit_50; if linked_1055 == nil { c__4 = ifn_1056.Invoke_O__O(arg_1057) } else { c__4 = linked_1055.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_1054, arg_1057) }
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_o2j_A_const_161; var tmp5 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_162, f__0)); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_163; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_o2j_A_const_164; var tmp10 any = tmp8.Invoke_O_O_O__O(tmp9, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_165, c__4), jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()); var tmp11 any; var root_1058 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1060 lang.IFn

		if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_1062 any; var root_1065 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref())).Ref(); if linked_1066 == nil { arg_1062 = ifn_1067.Invoke_O__O(arg_1068) } else { arg_1062 = linked_1066.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1065, arg_1068) }; var arg_1063 any = c__4; var arg_1064 any = args__1; if linked_1059 == nil { tmp11 = ifn_1060.Invoke_O_O_O_O__O(arg_1061, arg_1062, arg_1063, arg_1064) } else { tmp11 = linked_1059.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063, arg_1064) }
//line :237:1
		var tmp12 any = tmp11; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp14 any = A_arbace_o2j_A_const_166; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_o2j_A_const_167; var tmp17 any = A_arbace_o2j_A_const_168; var tmp18 any; var root_1069 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1071 lang.IFn


		if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = args__1; if linked_1070 == nil { tmp18 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp18 = linked_1070.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1069, arg_1072) }
//line :237:1
		return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp10, tmp12, tmp13.Invoke_O_O_O__O(tmp14, c__4, tmp15.Invoke_O_O_O__O(tmp16, tmp17, tmp18)))) } else {



			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_o2j_A_const_169; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp22 any = A_arbace_o2j_A_const_170; var tmp23 any = A_arbace_o2j_A_const_171; var tmp24 any; var root_1073 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = args__1; if linked_1074 == nil { tmp24 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp24 = linked_1074.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1073, arg_1076) }; return tmp19.Invoke_O_O_O__O(tmp20, f__0, tmp21.Invoke_O_O_O__O(tmp22, tmp23, tmp24)) } }

func A_arbace_o2j_apply_node_A_New() *A_arbace_o2j_apply_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_apply_node_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_o2j_apply_node_A) Ctor() {}
//line :243:1
func (t *A_arbace_o2j_apply_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000183__1, tail_QMARK___2 any) any { var vec__1641000184__4 any = p__1641000183__1; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000184__4, lang.RT_IntCast_J__I_NoInit(0), nil); var args__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000184__4, lang.RT_IntCast_J__I_NoInit(1), nil); var self__7 any = A_arbace_o2j_A_const_172.Invoke_O__O(ctx__0); var tmp1 any; var and__1927000168__auto____8 any = tail_QMARK___2; if

	jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = self__7; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp2 any = A_arbace_o2j_A_const_173; var tmp3 any; var root_1077 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, A_arbace_o2j_hd_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = f__5; if linked_1078 == nil { tmp3 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp3 = linked_1078.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_1077, arg_1080) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____10 { var and__1927000168__auto____11 bool; var tmp4 any; var root_1081 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = f__5; if linked_1082 == nil { tmp4 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp4 = linked_1082.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1081, arg_1084) }; and__1927000168__auto____11 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_o2j_A_const_146.Invoke_O__O(self__7)); if and__1927000168__auto____11 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_O__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(args__6)), A_arbace_o2j_A_const_174.Invoke_O__O(self__7))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
		var root_1149 any = A_arbace_o2j_A_const_179.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_o2j_A_const_180.Invoke_O__O(self__7); var arg_1153 any = jrt.Boolean_TRUE.Ref(); if linked_1150 == nil { ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { linked_1150.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }
		var root_1085 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, A_arbace_o2j_with_args_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = ctx__0; var arg_1089 any = args__6; var arg_1090 any; var fnbody__1099 any = A_arbace_o2j_apply_node_fn__1641000187_A_New_O(self__7); var tmp5 *jrt.Class; var fncls__1098 *jrt.Class = A_arbace_o2j_apply_node_fn__1641000187_A_fn_class; if fncls__1098 == nil { var fncls__1098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__1099); A_arbace_o2j_apply_node_fn__1641000187_A_fn_class = fncls__1098d; tmp5 = fncls__1098d } else { tmp5 = fncls__1098 }; arg_1090 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1099, tmp5, nil); if linked_1086 == nil { return ifn_1087.Invoke_O_O_O__O(arg_1088, arg_1089, arg_1090) } else { return linked_1086.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_1085, arg_1088, arg_1089, arg_1090) } } else {

			var tmp6 any; var root_1100 any = A_arbace_o2j_A_const_150.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, A_arbace_o2j_simple_QMARK__A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = f__5; if linked_1101 == nil { tmp6 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp6 = linked_1101.(*A_arbace_o2j_simple_QMARK__A).Invoke_O_O__O(root_1100, arg_1103) }; if jrt.J2g_Truth(tmp6) {
				var root_1104 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_o2j_with_args_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = ctx__0; var arg_1108 any = args__6; var arg_1109 any; var fnbody__1122 any = A_arbace_o2j_apply_node_fn__1641000189_A_New_O_O(f__5, ctx__0); var tmp7 *jrt.Class; var fncls__1121 *jrt.Class = A_arbace_o2j_apply_node_fn__1641000189_A_fn_class; if fncls__1121 == nil { var fncls__1121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1122); A_arbace_o2j_apply_node_fn__1641000189_A_fn_class = fncls__1121d; tmp7 = fncls__1121d } else { tmp7 = fncls__1121 }; arg_1109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1122, tmp7, nil); if linked_1105 == nil { return ifn_1106.Invoke_O_O_O__O(arg_1107, arg_1108, arg_1109) } else { return linked_1105.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_1104, arg_1107, arg_1108, arg_1109) } } else {
					var root_1123 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_o2j_with_args_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = ctx__0; var arg_1127 any; var root_1129 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = lang.Tuple_Create_O__IPersistentVector(f__5); var arg_1133 any = args__6; if linked_1130 == nil { arg_1127 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { arg_1127 = linked_1130.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; var arg_1128 any; var fnbody__1148 any = A_arbace_o2j_apply_node_fn__1641000191_A_New(); var tmp8 *jrt.Class; var fncls__1147 *jrt.Class = A_arbace_o2j_apply_node_fn__1641000191_A_fn_class; if fncls__1147 == nil { var fncls__1147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_o2j_apply_node_fn__1641000191_A_fn_class = fncls__1147d; tmp8 = fncls__1147d } else { tmp8 = fncls__1147 }; arg_1128 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1148, tmp8, nil); if linked_1124 == nil { return ifn_1125.Invoke_O_O_O__O(arg_1126, arg_1127, arg_1128) } else { return linked_1124.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_1123, arg_1126, arg_1127, arg_1128) } } } }
//line :247:1
func A_arbace_o2j_apply_node_fn__1641000187_A_New_O(p0 any) *A_arbace_o2j_apply_node_fn__1641000187_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_apply_node_fn__1641000187_A{}; t.Ctor_O(p0); return t }
//line :247:1
func (t *A_arbace_o2j_apply_node_fn__1641000187_A) Ctor_O(c__self any) { t.F_self = c__self }
//line :247:1
func (t *A_arbace_o2j_apply_node_fn__1641000187_A) Invoke_O_O__O(self, as__1 any) any { var root_1091 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_1095 any = A_arbace_o2j_A_const_176; var arg_1096 any = A_arbace_o2j_A_const_177.Invoke_O__O(t.F_self); var arg_1097 any = as__1; if linked_1092 == nil { return ifn_1093.Invoke_O_O_O_O__O(arg_1094, arg_1095, arg_1096, arg_1097) } else { return linked_1092.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1091, arg_1094, arg_1095, arg_1096, arg_1097) } }


func A_arbace_o2j_apply_node_fn__1641000189_A_New_O_O(p0, p1 any) *A_arbace_o2j_apply_node_fn__1641000189_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_apply_node_fn__1641000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_o2j_apply_node_fn__1641000189_A) Ctor_O_O(c__f, c__ctx any) { t.F_f = c__f; t.F_ctx = c__ctx }
//line :250:1
func (t *A_arbace_o2j_apply_node_fn__1641000189_A) Invoke_O_O__O(self, as__1 any) any { var root_1110 any = A_arbace_o2j_A_const_178.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, A_arbace_o2j_call_form_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any; var root_1115 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_o2j_expr_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = t.F_ctx; var arg_1119 any = t.F_f; var arg_1120 any = jrt.Boolean_FALSE.Ref(); if linked_1116 == nil { arg_1113 = ifn_1117.Invoke_O_O_O__O(arg_1118, arg_1119, arg_1120) } else { arg_1113 = linked_1116.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1115, arg_1118, arg_1119, arg_1120) }; var arg_1114 any = as__1; if linked_1111 == nil { return ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { return linked_1111.(*A_arbace_o2j_call_form_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) } }
func A_arbace_o2j_apply_node_fn__1641000191_A_New() *A_arbace_o2j_apply_node_fn__1641000191_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_apply_node_fn__1641000191_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_o2j_apply_node_fn__1641000191_A) Ctor() {}
//line :251:1
func (t *A_arbace_o2j_apply_node_fn__1641000191_A) Invoke_O_O__O(self, as__1 any) any { var root_1134 any = A_arbace_o2j_A_const_178.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_o2j_call_form_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var root_1139 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = as__1; if linked_1140 == nil { arg_1137 = ifn_1141.Invoke_O__O(arg_1142) } else { arg_1137 = linked_1140.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1139, arg_1142) }; var arg_1138 any; var root_1143 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = as__1; if linked_1144 == nil { arg_1138 = ifn_1145.Invoke_O__O(arg_1146) } else { arg_1138 = linked_1144.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1143, arg_1146) }; if linked_1135 == nil { return ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { return linked_1135.(*A_arbace_o2j_call_form_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) } }



func A_arbace_o2j_method_for_A_New() *A_arbace_o2j_method_for_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_method_for_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_o2j_method_for_A) Ctor() {}
//line :255:1
func (t *A_arbace_o2j_method_for_A) Invoke_O_O_O_O__O(self, arity__0, params__1, body__2 any) any { if jrt.Long_InstanceOf(arity__0) { return t.InvokeSpec_O_J_O_O_O__O(self, jrt.NN(jrt.Long_Cast(arity__0)).LongValue__J(), arity__0, params__1, body__2) } else {
													var tmp1 bool; var na_1154 any = arity__0; var na_1155 int64 = 6; if jrt.Long_InstanceOf(na_1154) { var n0_1156 int64 = jrt.NN(jrt.Long_Cast(na_1154)).LongValue__J(); var n1_1157 int64 = na_1155; tmp1 = n0_1156 <= n1_1157 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_1154, na_1155) }; if tmp1 {
														var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_181; var tmp4 any; var root_1163 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1168 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, arity__0)).Ref(); if linked_1169 == nil { arg_1166 = ifn_1170.Invoke_O__O(arg_1171) } else { arg_1166 = linked_1169.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1168, arg_1171) }; var arg_1167 any = A_arbace_o2j_A_const_182; if linked_1164 == nil { tmp4 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { tmp4 = linked_1164.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }; var tmp5 any = tmp4; var tmp6 any; var root_1172 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = A_arbace_o2j_A_const_183; var arg_1176 any = params__1; if linked_1173 == nil { tmp6 = ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { tmp6 = linked_1173.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) }; return tmp2.Invoke_O_O_O_O__O(tmp3, tmp5, tmp6, body__2) } else {
//line :256:1
			var a__4 any; var root_1159 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1161 lang.IFn

			if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = Lit_112; if linked_1160 == nil { a__4 = ifn_1161.Invoke_O__O(arg_1162) } else { a__4 = linked_1160.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1159, arg_1162) }
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_o2j_A_const_184; var tmp9 any; var root_1177 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = A_arbace_o2j_A_const_185; var arg_1181 any = A_arbace_o2j_A_const_186; if linked_1178 == nil { tmp9 = ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { tmp9 = linked_1178.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_o2j_A_const_187; var tmp12 any; var root_1182 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = a__4; var arg_1186 any = A_arbace_o2j_A_const_188; if linked_1183 == nil { tmp12 = ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { tmp12 = linked_1183.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) }; var tmp13 any = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_o2j_A_const_189; var tmp16 any; var root_1187 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1189 lang.IFn
			if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp18 *lang.Compiler_AOTFn; var fnbody__1198 any = A_arbace_o2j_method_for_fn__1641000194_A_New_O(a__4); var tmp19 *jrt.Class; var fncls__1197 *jrt.Class = A_arbace_o2j_method_for_fn__1641000194_A_fn_class; if fncls__1197 == nil { var fncls__1197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__1198); A_arbace_o2j_method_for_fn__1641000194_A_fn_class = fncls__1197d; tmp19 = fncls__1197d } else { tmp19 = fncls__1197 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1198, tmp19, nil); var tmp20 any = tmp18.Ref(); var tmp21 any; var root_1199 any = A_arbace_o2j_A_const_191.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; if linked_1200 == nil { tmp21 = ifn_1201.Invoke__O() } else { tmp21 = linked_1200.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O__O(root_1199) }; arg_1190 = tmp17.Invoke_O_O_O__O(tmp20, tmp21, params__1); if linked_1188 == nil { tmp16 = ifn_1189.Invoke_O__O(arg_1190) } else { tmp16 = linked_1188.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1187, arg_1190) }
//line :259:1
			return tmp7.Invoke_O_O_O_O__O(tmp8, tmp10, tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp16, body__2)) } } }
//line :255:1
func (t *A_arbace_o2j_method_for_A) InvokeSpec_O_J_O_O_O__O(self any, arity__0_l int64, arity__0_b, params__1, body__2 any) any {
	var tmp1 bool; var na_1202 int64 = 6; var n0_1203 int64 = arity__0_l; var n1_1204 int64 = na_1202; tmp1 = n0_1203 <= n1_1204; if tmp1 {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_181; var tmp4 any; var root_1210 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var root_1215 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_111, nil); var tmp6 any; if arity__0_b == nil { arity__0_b = jrt.Long_ValueOf_J__Long_NoInit(arity__0_l).Ref(); tmp6 = arity__0_b } else { tmp6 = arity__0_b }; arg_1218 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_1216 == nil { arg_1213 = ifn_1217.Invoke_O__O(arg_1218) } else { arg_1213 = linked_1216.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1215, arg_1218) }; var arg_1214 any = A_arbace_o2j_A_const_182; if linked_1211 == nil { tmp4 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { tmp4 = linked_1211.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; var tmp7 any = tmp4; var tmp8 any; var root_1219 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = A_arbace_o2j_A_const_183; var arg_1223 any = params__1; if linked_1220 == nil { tmp8 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { tmp8 = linked_1220.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) }; return tmp2.Invoke_O_O_O_O__O(tmp3, tmp7, tmp8, body__2) } else {
//line :256:1
			var a__4 any; var root_1206 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1208 lang.IFn

			if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = Lit_112; if linked_1207 == nil { a__4 = ifn_1208.Invoke_O__O(arg_1209) } else { a__4 = linked_1207.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1206, arg_1209) }
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_o2j_A_const_184; var tmp11 any; var root_1224 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = A_arbace_o2j_A_const_185; var arg_1228 any = A_arbace_o2j_A_const_186; if linked_1225 == nil { tmp11 = ifn_1226.Invoke_O_O__O(arg_1227, arg_1228) } else { tmp11 = linked_1225.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1224, arg_1227, arg_1228) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_o2j_A_const_187; var tmp14 any; var root_1229 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = a__4; var arg_1233 any = A_arbace_o2j_A_const_188; if linked_1230 == nil { tmp14 = ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { tmp14 = linked_1230.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) }; var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp17 any = A_arbace_o2j_A_const_189; var tmp18 any; var root_1234 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1236 lang.IFn
			if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp20 *lang.Compiler_AOTFn; var fnbody__1245 any = A_arbace_o2j_method_for_fn__1641000194_A_New_O(a__4); var tmp21 *jrt.Class; var fncls__1244 *jrt.Class = A_arbace_o2j_method_for_fn__1641000194_A_fn_class; if fncls__1244 == nil { var fncls__1244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__1245); A_arbace_o2j_method_for_fn__1641000194_A_fn_class = fncls__1244d; tmp21 = fncls__1244d } else { tmp21 = fncls__1244 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1245, tmp21, nil); var tmp22 any = tmp20.Ref(); var tmp23 any; var root_1246 any = A_arbace_o2j_A_const_191.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; if linked_1247 == nil { tmp23 = ifn_1248.Invoke__O() } else { tmp23 = linked_1247.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O__O(root_1246) }; arg_1237 = tmp19.Invoke_O_O_O__O(tmp22, tmp23, params__1); if linked_1235 == nil { tmp18 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp18 = linked_1235.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1234, arg_1237) }
//line :259:1
			return tmp9.Invoke_O_O_O_O__O(tmp10, tmp12, tmp15, tmp16.Invoke_O_O_O__O(tmp17, tmp18, body__2)) } }
func A_arbace_o2j_method_for_fn__1641000194_A_New_O(p0 any) *A_arbace_o2j_method_for_fn__1641000194_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_method_for_fn__1641000194_A{}; t.Ctor_O(p0); return t }
//line :260:1
func (t *A_arbace_o2j_method_for_fn__1641000194_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :260:1
func (t *A_arbace_o2j_method_for_fn__1641000194_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(p__2, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_190, t.F_a, i__1)) }

func A_arbace_o2j_closure_class_BANG__A_New() *A_arbace_o2j_closure_class_BANG__A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_o2j_closure_class_BANG__A) Ctor() {}
//line :262:1
func (t *A_arbace_o2j_closure_class_BANG__A) Invoke_O_O_O_O__O(self, ctx__0, f__1, self_id__2 any) any { var vec__1641000198__4 any; var root_1249 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, A_arbace_o2j_node_body_A_fn_class); var ifn_1251 lang.IFn; if



	linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = f__1; if linked_1250 == nil { vec__1641000198__4 = ifn_1251.Invoke_O__O(arg_1252) } else { vec__1641000198__4 = linked_1250.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_1249, arg_1252) }; var kind__5 any = /*line :262:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1641000198__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000198__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000198__4, lang.RT_IntCast_J__I_NoInit(2), nil); var body__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000198__4, lang.RT_IntCast_J__I_NoInit(3), nil); var cls__9 any; var root_1253 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, A_arbace_o2j_fresh_A_fn_class); var ifn_1255 lang.IFn; _ = ___7; if




	linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = Lit_53; if linked_1254 == nil { cls__9 = ifn_1255.Invoke_O__O(arg_1256) } else { cls__9 = linked_1254.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_1253, arg_1256) }; var free__10 any; var root_1257 any = /*line :262:1*/A_arbace_o2j_A_const_144.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1259 lang.IFn; if





	linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any; var fnbody__1263 any = A_arbace_o2j_closure_class_BANG__fn__1641000201_A_New_O(self_id__2); var tmp1 *jrt.Class; var fncls__1262 *jrt.Class = A_arbace_o2j_closure_class_BANG__fn__1641000201_A_fn_class; if fncls__1262 == nil { var fncls__1262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__1263); A_arbace_o2j_closure_class_BANG__fn__1641000201_A_fn_class = fncls__1262d; tmp1 = fncls__1262d } else { tmp1 = fncls__1262 }; arg_1260 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1263, tmp1, nil); var arg_1261 any; var root_1264 any = A_arbace_o2j_A_const_192.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, A_arbace_o2j_free_ids_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = f__1; if linked_1265 == nil { arg_1261 = ifn_1266.Invoke_O__O(arg_1267) } else { arg_1261 = linked_1265.(*A_arbace_o2j_free_ids_A).Invoke_O_O__O(root_1264, arg_1267) }; if linked_1258 == nil { free__10 = ifn_1259.Invoke_O_O__O(arg_1260, arg_1261) } else { free__10 = linked_1258.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1257, arg_1260, arg_1261) }; var params__11 any; var root_1268 any = /*line :262:1*/A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1270 lang.IFn; if






	linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any; var root_1273 any = A_arbace_o2j_A_const_193.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var arg_1277 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); if linked_1274 == nil { arg_1271 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { arg_1271 = linked_1274.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; var arg_1272 any = ps__6; if linked_1269 == nil { params__11 = ifn_1270.Invoke_O_O__O(arg_1271, arg_1272) } else { params__11 = linked_1269.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1268, arg_1271, arg_1272) }; var arity__12 int32 = /*line :262:1*/lang.RT_Count_O__I_NoInit(ps__6); var fields__13 any; var root_1278 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1280 lang.IFn; if








	linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var arg_1282 any = free__10; if linked_1279 == nil { fields__13 = ifn_1280.Invoke_O_O__O(arg_1281, arg_1282) } else { fields__13 = linked_1279.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1278, arg_1281, arg_1282) }; var env__14 any; var tmp2 lang.IFn = /*line :262:1*/lang.IFn_Cast(A_arbace_o2j_A_const_195.GetRawRoot__O()); var tmp3 any; var root_1289 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1291 lang.IFn; if









	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1293 any; var root_1294 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any; var fnbody__1301 any = A_arbace_o2j_closure_class_BANG__fn__1641000203_A_New(); var tmp4 *jrt.Class; var fncls__1300 *jrt.Class = A_arbace_o2j_closure_class_BANG__fn__1641000203_A_fn_class; if fncls__1300 == nil { var fncls__1300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_o2j_closure_class_BANG__fn__1641000203_A_fn_class = fncls__1300d; tmp4 = fncls__1300d } else { tmp4 = fncls__1300 }; arg_1297 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1301, tmp4, nil); var arg_1298 any = free__10; var arg_1299 any = fields__13; if linked_1295 == nil { arg_1293 = ifn_1296.Invoke_O_O_O__O(arg_1297, arg_1298, arg_1299) } else { arg_1293 = linked_1295.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1294, arg_1297, arg_1298, arg_1299) }; if linked_1290 == nil { tmp3 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { tmp3 = linked_1290.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var tmp5 any = tmp3; var tmp6 any; var root_1302 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1304 lang.IFn; if
	linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1306 any; var root_1307 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var fnbody__1314 any = A_arbace_o2j_closure_class_BANG__fn__1641000206_A_New(); var tmp7 *jrt.Class; var fncls__1313 *jrt.Class = A_arbace_o2j_closure_class_BANG__fn__1641000206_A_fn_class; if fncls__1313 == nil { var fncls__1313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_o2j_closure_class_BANG__fn__1641000206_A_fn_class = fncls__1313d; tmp7 = fncls__1313d } else { tmp7 = fncls__1313 }; arg_1310 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1314, tmp7, nil); var arg_1311 any = ps__6; var arg_1312 any = params__11; if linked_1308 == nil { arg_1306 = ifn_1309.Invoke_O_O_O__O(arg_1310, arg_1311, arg_1312) } else { arg_1306 = linked_1308.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1307, arg_1310, arg_1311, arg_1312) }; if linked_1303 == nil { tmp6 = ifn_1304.Invoke_O_O__O(arg_1305, arg_1306) } else { tmp6 = linked_1303.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1302, arg_1305, arg_1306) }; var tmp8 any = tmp6; var tmp9 lang.IPersistentMap; if
	jrt.J2g_Truth(self_id__2) { tmp9 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, self_id__2, A_arbace_o2j_A_const_196)) } else { tmp9 = nil }; env__14 = /*line :272:1*/tmp2.Invoke_O_O_O__O(tmp5, tmp8, tmp9); var used__15 any; var root_1315 any = /*line :262:1*/A_arbace_o2j_A_const_197.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1317 lang.IFn; if












	linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = jrt.Boolean_FALSE.Ref(); if linked_1316 == nil { used__15 = ifn_1317.Invoke_O__O(arg_1318) } else { used__15 = linked_1316.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1315, arg_1318) }; var lbl__16 any; var root_1319 any = /*line :262:1*/A_arbace_o2j_A_const_198.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_1321 lang.IFn; if













	linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_57, nil); var tmp11 any; var root_1323 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var tmp12 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_1326 any = tmp12.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_1327 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_1324 == nil { tmp11 = ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { tmp11 = linked_1324.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) }; arg_1322 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); if linked_1320 == nil { lbl__16 = ifn_1321.Invoke_O__O(arg_1322) } else { lbl__16 = linked_1320.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_1319, arg_1322) }; var ictx__17 any; var tmp13 any = A_arbace_o2j_A_const_145; var tmp14 any = A_arbace_o2j_A_const_199; var tmp15 any = /*line :262:1*/lang.PersistentArrayMap_EMPTY.Ref(); var tmp16 any = A_arbace_o2j_A_const_172; var tmp17 lang.IPersistentMap; if














	jrt.J2g_Truth(self_id__2) { var tmp18 any = A_arbace_o2j_A_const_146; var tmp19 any = A_arbace_o2j_A_const_177; var tmp20 any = A_arbace_o2j_A_const_180; var tmp21 any = A_arbace_o2j_A_const_174; tmp17 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, self_id__2, tmp19, lbl__16, tmp20, used__15, tmp21, jrt.Integer_ValueOf_I__Integer_NoInit(arity__12).Ref())) } else { tmp17 = nil }; ictx__17 = /*line :262:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, env__14, tmp14, tmp15, tmp16, tmp17)); var b__18 any; var root_1328 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, A_arbace_o2j_realize_A_fn_class); var ifn_1330 lang.IFn; if















	linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any; var root_1332 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, A_arbace_o2j_expr_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = ictx__17; var arg_1336 any = body__8; var arg_1337 any = jrt.Boolean_TRUE.Ref(); if linked_1333 == nil { arg_1331 = ifn_1334.Invoke_O_O_O__O(arg_1335, arg_1336, arg_1337) } else { arg_1331 = linked_1333.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1332, arg_1335, arg_1336, arg_1337) }; if linked_1329 == nil { b__18 = ifn_1330.Invoke_O__O(arg_1331) } else { b__18 = linked_1329.(*A_arbace_o2j_realize_A).Invoke_O_O__O(root_1328, arg_1331) }; var b__19 any; var tmp22 any; var root_1338 any = /*line :262:1*/A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1340 lang.IFn; if
















	linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = used__15; if linked_1339 == nil { tmp22 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp22 = linked_1339.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1338, arg_1341) }; if jrt.J2g_Truth(tmp22) { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp24 any = A_arbace_o2j_A_const_200; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_201; var tmp27 any; var root_1342 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp29 *lang.Compiler_AOTFn; var fnbody__1352 any = A_arbace_o2j_closure_class_BANG__fn__1641000211_A_New(); var tmp30 *jrt.Class; var fncls__1351 *jrt.Class = A_arbace_o2j_closure_class_BANG__fn__1641000211_A_fn_class; if fncls__1351 == nil { var fncls__1351d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_o2j_closure_class_BANG__fn__1641000211_A_fn_class = fncls__1351d; tmp30 = fncls__1351d } else { tmp30 = fncls__1351 }; tmp29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1352, tmp30, nil); arg_1345 = tmp28.Invoke_O_O__O(tmp29.Ref(), params__11); if linked_1343 == nil { tmp27 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp27 = linked_1343.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1342, arg_1345) }; b__19 = tmp23.Invoke_O_O_O__O(tmp24, lbl__16, tmp25.Invoke_O_O_O__O(tmp26, tmp27, b__18)) } else { b__19 = b__18 }; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__5, A_arbace_o2j_A_const_202) { var tmp31 any; var root_1353 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = Lit_59; var arg_1357 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1354 == nil { tmp31 = ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { tmp31 = linked_1354.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp31))) }; var root_1358 any =
	A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var tmp32 *lang.Keyword = A_arbace_o2j_A_const_203; var arg_1361 any = tmp32.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_1362 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var arg_1363 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp35 any = A_arbace_o2j_A_const_204; var tmp36 any; var root_1370 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1372 lang.IFn; if

	linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = cls__9; var arg_1374 any = A_arbace_o2j_A_const_205; if linked_1371 == nil { tmp36 = ifn_1372.Invoke_O_O__O(arg_1373, arg_1374) } else { tmp36 = linked_1371.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1370, arg_1373, arg_1374) }; var tmp37 any = /*line :282:1*/tmp34.Invoke_O_O_O_O__O(tmp35, tmp36, A_arbace_o2j_A_const_206, A_arbace_o2j_A_const_207); var tmp38 any; var iter__1927001039__auto____20 any; var fnbody__1446 any = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A_New(); var tmp39 *jrt.Class; var fncls__1445 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A_fn_class; if

	fncls__1445 == nil { var fncls__1445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A_fn_class = fncls__1445d; tmp39 = fncls__1445d } else { tmp39 = fncls__1445 }; iter__1927001039__auto____20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1446, tmp39, nil); tmp38 = lang.IFn_Cast(iter__1927001039__auto____20).Invoke_O__O(fields__13); var tmp40 any = tmp38; var tmp41 any; var root_1447 any = /*line :282:1*/A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1449 lang.IFn; if


	linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp43 any = A_arbace_o2j_A_const_211; var tmp44 any; var root_1452 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var root_1457 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = A_arbace_o2j_A_const_212; var arg_1461 any = fields__13; if linked_1458 == nil { arg_1455 = ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { arg_1455 = linked_1458.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) }; var arg_1456 any = A_arbace_o2j_A_const_213; if linked_1453 == nil { tmp44 = ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { tmp44 = linked_1453.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp46 any = A_arbace_o2j_A_const_214; arg_1450 = tmp42.Invoke_O_O_O__O(tmp43, tmp44, tmp45.Invoke_O_O__O(tmp46, jrt.Integer_ValueOf_I__Integer_NoInit(arity__12).Ref())); var arg_1451 any; var iter__1927001039__auto____20_2 any; var fnbody__1531 any = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A_New(); var tmp47 *jrt.Class; var fncls__1530 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A_fn_class; if

	fncls__1530 == nil { var fncls__1530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A_fn_class = fncls__1530d; tmp47 = fncls__1530d } else { tmp47 = fncls__1530 }; iter__1927001039__auto____20_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1531, tmp47, nil); arg_1451 = lang.IFn_Cast(iter__1927001039__auto____20_2).Invoke_O__O(fields__13); if /*line :285:1*/ linked_1448 == nil { tmp41 = ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { tmp41 = linked_1448.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) }; var tmp48 any = tmp41; var tmp49 any; var root_1532 any = /*line :282:1*/A_arbace_o2j_A_const_217.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1532, A_arbace_o2j_method_for_A_fn_class); var ifn_1534 lang.IFn; if





	linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = jrt.Integer_ValueOf_I__Integer_NoInit(arity__12).Ref(); var arg_1536 any = params__11; var arg_1537 any = b__19; if linked_1533 == nil { tmp49 = ifn_1534.Invoke_O_O_O__O(arg_1535, arg_1536, arg_1537) } else { if jrt.Long_InstanceOf(arg_1535) { tmp49 = linked_1533.(*A_arbace_o2j_method_for_A).InvokeSpec_O_J_O_O_O__O(root_1532, jrt.NN(jrt.Long_Cast(arg_1535)).LongValue__J(), arg_1535, arg_1536, arg_1537) } else { tmp49 = linked_1533.(*A_arbace_o2j_method_for_A).Invoke_O_O_O_O__O(root_1532, arg_1535, arg_1536, arg_1537) } }; arg_1363 = /*line :282:1*/tmp33.Invoke_O_O_O__O(tmp37, tmp40, lang.Tuple_Create_O_O__IPersistentVector(tmp48, tmp49)); if /*line :281:1*/ linked_1359 == nil { ifn_1360.Invoke_O_O_O__O(arg_1361, arg_1362, arg_1363) } else { linked_1359.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1358, arg_1361, arg_1362, arg_1363) }; return /*line :262:1*/ lang.Tuple_Create_O_O__IPersistentVector(cls__9, free__10) }





func A_arbace_o2j_closure_class_BANG__fn__1641000201_A_New_O(p0 any) *A_arbace_o2j_closure_class_BANG__fn__1641000201_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__fn__1641000201_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000201_A) Ctor_O(c__self_id any) { t.F_self_id = c__self_id }
//line :268:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000201_A) Invoke_O_O__O(self, p1__1641000197_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1641000197_SHARP___1, t.F_self_id)).Ref() }



func A_arbace_o2j_closure_class_BANG__fn__1641000203_A_New() *A_arbace_o2j_closure_class_BANG__fn__1641000203_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__fn__1641000203_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000203_A) Ctor() {}
//line :272:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000203_A) Invoke_O_O_O__O(self, id__1, s__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(id__1, s__2) }
func A_arbace_o2j_closure_class_BANG__fn__1641000206_A_New() *A_arbace_o2j_closure_class_BANG__fn__1641000206_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__fn__1641000206_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000206_A) Ctor() {}
//line :273:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000206_A) Invoke_O_O_O__O(self, p__1641000205__1, s__2 any) any { var vec__1641000207__3 any = p__1641000205__1; var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000207__3, lang.RT_IntCast_J__I_NoInit(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(p__4, s__2) }





func A_arbace_o2j_closure_class_BANG__fn__1641000211_A_New() *A_arbace_o2j_closure_class_BANG__fn__1641000211_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__fn__1641000211_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000211_A) Ctor() {}
//line :279:1
func (t *A_arbace_o2j_closure_class_BANG__fn__1641000211_A) Invoke_O_O__O(self, p__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(p__1, p__1) }




func A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A_New() *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A) Ctor() {}
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A) Invoke_O_O__O(self, s__1641000214__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1444 any = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A_New_O_O(s__1641000214__1, self); var tmp2 *jrt.Class; var fncls__1443 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A_fn_class; if fncls__1443 == nil { var fncls__1443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__1444); A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A_fn_class = fncls__1443d; tmp2 = fncls__1443d } else { tmp2 = fncls__1443 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1444, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :284:1
func A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A_New_O_O(p0, p1 any) *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A{}; t.Ctor_O_O(p0, p1); return t }
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A) Ctor_O_O(c__s__1641000214, c__iter__1641000213 any) { t.F_s__1641000214 = c__s__1641000214; t.F_iter__1641000213 = c__iter__1641000213 }
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A) Invoke_O__O(self any) any { { var s__1641000214__1 any; var t_ any = t.F_s__1641000214; t.F_s__1641000214 = nil; s__1641000214__1 = t_; for { var temp__1927000414__auto____2 any; var root_1375 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = s__1641000214__1; if linked_1376 == nil { temp__1927000414__auto____2 = ifn_1377.Invoke_O__O(arg_1378) } else { temp__1927000414__auto____2 = linked_1376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1375, arg_1378) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1379 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = s__1641000214__3; if linked_1380 == nil { tmp1 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp1 = linked_1380.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1379, arg_1382) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1383 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = s__1641000214__3; if linked_1384 == nil { c__1927001037__auto____4 = ifn_1385.Invoke_O__O(arg_1386) } else { c__1927001037__auto____4 = linked_1384.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1383, arg_1386) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000216__6 any; var root_1387 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1388 == nil { b__1641000216__6 = ifn_1389.Invoke_O__O(arg_1390) } else { b__1641000216__6 = linked_1388.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1387, arg_1390) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1402 any = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A_New_O_I_O(b__1641000216__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1401 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A_fn_class; if fncls__1401 == nil { var fncls__1401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1402); A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A_fn_class = fncls__1401d; tmp3 = fncls__1401d } else { tmp3 = fncls__1401 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1402, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1403 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any; var root_1408 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = b__1641000216__6; if linked_1409 == nil { arg_1406 = ifn_1410.Invoke_O__O(arg_1411) } else { arg_1406 = linked_1409.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1408, arg_1411) }; var arg_1407 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000213); var tmp5 any; var root_1412 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__1641000214__3; if linked_1413 == nil { tmp5 = ifn_1414.Invoke_O__O(arg_1415) } else { tmp5 = linked_1413.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1412, arg_1415) }; arg_1407 = tmp4.Invoke_O__O(tmp5); if linked_1404 == nil { return ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { return linked_1404.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) } } else { var root_1416 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var root_1421 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = b__1641000216__6; if linked_1422 == nil { arg_1419 = ifn_1423.Invoke_O__O(arg_1424) } else { arg_1419 = linked_1422.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1421, arg_1424) }; var arg_1420 any; if linked_1417 == nil { return ifn_1418.Invoke_O_O__O(arg_1419, arg_1420) } else { return linked_1417.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1416, arg_1419, arg_1420) } } } else { var fl__4 any; var root_1425 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = s__1641000214__3; if linked_1426 == nil { fl__4 = ifn_1427.Invoke_O__O(arg_1428) } else { fl__4 = linked_1426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1425, arg_1428) }; var root_1429 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_208; var tmp8 any; var root_1434 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = fl__4; var arg_1438 any = A_arbace_o2j_A_const_210; if linked_1435 == nil { tmp8 = ifn_1436.Invoke_O_O__O(arg_1437, arg_1438) } else { tmp8 = linked_1435.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1434, arg_1437, arg_1438) }; arg_1432 = tmp6.Invoke_O_O__O(tmp7, tmp8); var arg_1433 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1641000213); var tmp10 any; var root_1439 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = s__1641000214__3; if linked_1440 == nil { tmp10 = ifn_1441.Invoke_O__O(arg_1442) } else { tmp10 = linked_1440.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1439, arg_1442) }; arg_1433 = tmp9.Invoke_O__O(tmp10); if linked_1430 == nil { return ifn_1431.Invoke_O_O__O(arg_1432, arg_1433) } else { return linked_1430.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1429, arg_1432, arg_1433) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :284:1
func A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A) Ctor_O_I_O(c__b__1641000216 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000216 = c__b__1641000216; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :284:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A) Invoke_O__O(self any) any { { var i__1641000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fl__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000215__1)); var root_1391 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = t.F_b__1641000216; var arg_1395 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_208; var tmp4 any; var root_1396 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = fl__2; var arg_1400 any = A_arbace_o2j_A_const_209; if linked_1397 == nil { tmp4 = ifn_1398.Invoke_O_O__O(arg_1399, arg_1400) } else { tmp4 = linked_1397.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1396, arg_1399, arg_1400) }; arg_1395 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_1392 == nil { ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { linked_1392.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) }; i__1641000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000215__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A_New() *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A) Ctor() {}
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A) Invoke_O_O__O(self, s__1641000224__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1529 any = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A_New_O_O(s__1641000224__1, self); var tmp2 *jrt.Class; var fncls__1528 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A_fn_class; if fncls__1528 == nil { var fncls__1528d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__1529); A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A_fn_class = fncls__1528d; tmp2 = fncls__1528d } else { tmp2 = fncls__1528 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1529, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :287:1
func A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A_New_O_O(p0, p1 any) *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A) Ctor_O_O(c__s__1641000224, c__iter__1641000223 any) { t.F_s__1641000224 = c__s__1641000224; t.F_iter__1641000223 = c__iter__1641000223 }
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A) Invoke_O__O(self any) any { { var s__1641000224__1 any; var t_ any = t.F_s__1641000224; t.F_s__1641000224 = nil; s__1641000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_1462 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = s__1641000224__1; if linked_1463 == nil { temp__1927000414__auto____2 = ifn_1464.Invoke_O__O(arg_1465) } else { temp__1927000414__auto____2 = linked_1463.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1462, arg_1465) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1466 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = s__1641000224__3; if linked_1467 == nil { tmp1 = ifn_1468.Invoke_O__O(arg_1469) } else { tmp1 = linked_1467.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1466, arg_1469) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1470 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = s__1641000224__3; if linked_1471 == nil { c__1927001037__auto____4 = ifn_1472.Invoke_O__O(arg_1473) } else { c__1927001037__auto____4 = linked_1471.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1470, arg_1473) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000226__6 any; var root_1474 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1475 == nil { b__1641000226__6 = ifn_1476.Invoke_O__O(arg_1477) } else { b__1641000226__6 = linked_1475.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1474, arg_1477) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1488 any = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A_New_O_I_O(b__1641000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1487 *jrt.Class = A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A_fn_class; if fncls__1487 == nil { var fncls__1487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__1488); A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A_fn_class = fncls__1487d; tmp3 = fncls__1487d } else { tmp3 = fncls__1487 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1488, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1489 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any; var root_1494 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = b__1641000226__6; if linked_1495 == nil { arg_1492 = ifn_1496.Invoke_O__O(arg_1497) } else { arg_1492 = linked_1495.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1494, arg_1497) }; var arg_1493 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000223); var tmp5 any; var root_1498 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = s__1641000224__3; if linked_1499 == nil { tmp5 = ifn_1500.Invoke_O__O(arg_1501) } else { tmp5 = linked_1499.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1498, arg_1501) }; arg_1493 = tmp4.Invoke_O__O(tmp5); if linked_1490 == nil { return ifn_1491.Invoke_O_O__O(arg_1492, arg_1493) } else { return linked_1490.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1489, arg_1492, arg_1493) } } else { var root_1502 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any; var root_1507 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = b__1641000226__6; if linked_1508 == nil { arg_1505 = ifn_1509.Invoke_O__O(arg_1510) } else { arg_1505 = linked_1508.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1507, arg_1510) }; var arg_1506 any; if linked_1503 == nil { return ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { return linked_1503.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) } } } else { var fl__4 any; var root_1511 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = s__1641000224__3; if linked_1512 == nil { fl__4 = ifn_1513.Invoke_O__O(arg_1514) } else { fl__4 = linked_1512.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1511, arg_1514) }; var root_1515 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_215; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp9 any; var root_1520 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, fl__4)).Ref(); if linked_1521 == nil { tmp9 = ifn_1522.Invoke_O__O(arg_1523) } else { tmp9 = linked_1521.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1520, arg_1523) }; arg_1518 = tmp6.Invoke_O_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, A_arbace_o2j_A_const_216), fl__4); var arg_1519 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1641000223); var tmp11 any; var root_1524 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = s__1641000224__3; if linked_1525 == nil { tmp11 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp11 = linked_1525.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1524, arg_1527) }; arg_1519 = tmp10.Invoke_O__O(tmp11); if linked_1516 == nil { return ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { return linked_1516.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A) Ctor_O_I_O(c__b__1641000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000226 = c__b__1641000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A) Invoke_O__O(self any) any { { var i__1641000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fl__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000225__1)); var root_1478 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = t.F_b__1641000226; var arg_1482 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_215; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp5 any; var root_1483 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, fl__2)).Ref(); if linked_1484 == nil { tmp5 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp5 = linked_1484.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1483, arg_1486) }; arg_1482 = tmp2.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, A_arbace_o2j_A_const_216), fl__2); if linked_1479 == nil { ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { linked_1479.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }; i__1641000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_o2j_function_node_A_New() *A_arbace_o2j_function_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_function_node_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_o2j_function_node_A) Ctor() {}
//line :291:1
func (t *A_arbace_o2j_function_node_A) Invoke_O_O_O__O(self, ctx__0, f__1 any) any { var vec__1641000235__3 any; var root_1538 any = A_arbace_o2j_A_const_218.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, A_arbace_o2j_closure_class_BANG__A_fn_class); var ifn_1540 lang.IFn; if
											linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = ctx__0; var arg_1542 any = f__1; var arg_1543 any; if linked_1539 == nil { vec__1641000235__3 = ifn_1540.Invoke_O_O_O__O(arg_1541, arg_1542, arg_1543) } else { vec__1641000235__3 = linked_1539.(*A_arbace_o2j_closure_class_BANG__A).Invoke_O_O_O_O__O(root_1538, arg_1541, arg_1542, arg_1543) }; var cls__4 any = /*line :291:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1641000235__3, lang.RT_IntCast_J__I_NoInit(0), nil); var free__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000235__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1544 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1546 lang.IFn; if

	linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_1548 any; var root_1550 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, cls__4, nil)).Ref(); if linked_1551 == nil { arg_1548 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1548 = linked_1551.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1550, arg_1553) }; var arg_1549 any; var root_1554 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any; var fnbody__1565 any = A_arbace_o2j_function_node_fn__1641000238_A_New_O(ctx__0); var tmp1 *jrt.Class; var fncls__1564 *jrt.Class = A_arbace_o2j_function_node_fn__1641000238_A_fn_class; if fncls__1564 == nil { var fncls__1564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1565); A_arbace_o2j_function_node_fn__1641000238_A_fn_class = fncls__1564d; tmp1 = fncls__1564d } else { tmp1 = fncls__1564 }; arg_1557 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1565, tmp1, nil); var arg_1558 any = free__5; if linked_1555 == nil { arg_1549 = ifn_1556.Invoke_O_O__O(arg_1557, arg_1558) } else { arg_1549 = linked_1555.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1554, arg_1557, arg_1558) }; if linked_1545 == nil { return ifn_1546.Invoke_O_O_O__O(arg_1547, arg_1548, arg_1549) } else { return linked_1545.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1544, arg_1547, arg_1548, arg_1549) } }
//line :293:1
func A_arbace_o2j_function_node_fn__1641000238_A_New_O(p0 any) *A_arbace_o2j_function_node_fn__1641000238_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_function_node_fn__1641000238_A{}; t.Ctor_O(p0); return t }
//line :293:1
func (t *A_arbace_o2j_function_node_fn__1641000238_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :293:1
func (t *A_arbace_o2j_function_node_fn__1641000238_A) Invoke_O_O__O(self, p1__1641000234_SHARP___1 any) any { var root_1559 any = A_arbace_o2j_A_const_219.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, A_arbace_o2j_lookup_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = t.F_ctx; var arg_1563 any = p1__1641000234_SHARP___1; if linked_1560 == nil { return ifn_1561.Invoke_O_O__O(arg_1562, arg_1563) } else { return linked_1560.(*A_arbace_o2j_lookup_A).Invoke_O_O_O__O(root_1559, arg_1562, arg_1563) } }

func A_arbace_o2j_letrec_node_A_New() *A_arbace_o2j_letrec_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_o2j_letrec_node_A) Ctor() {}
//line :295:1
func (t *A_arbace_o2j_letrec_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000242__1, tail_QMARK___2 any) any { var vec__1641000243__4 any = p__1641000242__1; var bs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000243__4, lang.RT_IntCast_J__I_NoInit(0), nil); var body__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000243__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ids__7 any; var root_1566 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1568 lang.IFn; if
														linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var arg_1570 any = bs__5; if linked_1567 == nil { ids__7 = ifn_1568.Invoke_O_O__O(arg_1569, arg_1570) } else { ids__7 = linked_1567.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1566, arg_1569, arg_1570) }; var idset__8 any; var root_1571 any = /*line :295:1*/A_arbace_o2j_A_const_152.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1573 lang.IFn; if

	linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = ids__7; if linked_1572 == nil { idset__8 = ifn_1573.Invoke_O__O(arg_1574) } else { idset__8 = linked_1572.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1571, arg_1574) }; var syms__9 any; var root_1575 any = /*line :295:1*/A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1577 lang.IFn; if


	linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1579 any; var iter__1927001039__auto____9 any; var fnbody__1649 any = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A_New(); var tmp1 *jrt.Class; var fncls__1648 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A_fn_class; if fncls__1648 == nil { var fncls__1648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A_fn_class = fncls__1648d; tmp1 = fncls__1648d } else { tmp1 = fncls__1648 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1649, tmp1, nil); arg_1579 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(ids__7); if linked_1576 == nil { syms__9 = ifn_1577.Invoke_O_O__O(arg_1578, arg_1579) } else { syms__9 = linked_1576.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1575, arg_1578, arg_1579) }; var ctx2__10 any; var root_1650 any = /*line :295:1*/A_arbace_o2j_A_const_85.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1652 lang.IFn; if



	linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = ctx__0; var arg_1654 any = A_arbace_o2j_A_const_145; var arg_1655 any = A_arbace_o2j_A_const_195.GetRawRoot__O(); var arg_1656 any = syms__9; if linked_1651 == nil { ctx2__10 = ifn_1652.Invoke_O_O_O_O__O(arg_1653, arg_1654, arg_1655, arg_1656) } else { ctx2__10 = linked_1651.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1650, arg_1653, arg_1654, arg_1655, arg_1656) }; var made__11 any; var iter__1927001039__auto____11 any; var fnbody__1730 any = /*line :295:1*/A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A_New_O(ctx2__10); var tmp2 *jrt.Class; var fncls__1729 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A_fn_class; if




	fncls__1729 == nil { var fncls__1729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__1730); A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A_fn_class = fncls__1729d; tmp2 = fncls__1729d } else { tmp2 = fncls__1729 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1730, tmp2, nil); made__11 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(bs__5); var made__12 any; var root_1731 any = /*line :295:1*/A_arbace_o2j_A_const_67.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1733 lang.IFn; if





	linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = made__11; if linked_1732 == nil { made__12 = ifn_1733.Invoke_O__O(arg_1734) } else { made__12 = linked_1732.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1731, arg_1734) }; var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_o2j_A_const_220; var tmp5 any; var root_1735 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp7 *lang.Compiler_AOTFn; var fnbody__1767 any = A_arbace_o2j_letrec_node_fn__1641000279_A_New_O_O_O(ctx2__10, syms__9, idset__8); var tmp8 *jrt.Class; var fncls__1766 *jrt.Class = A_arbace_o2j_letrec_node_fn__1641000279_A_fn_class; if fncls__1766 == nil { var fncls__1766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__1767); A_arbace_o2j_letrec_node_fn__1641000279_A_fn_class = fncls__1766d; tmp8 = fncls__1766d } else { tmp8 = fncls__1766 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1767, tmp8, nil); arg_1738 = tmp6.Invoke_O_O__O(tmp7.Ref(), made__12); if linked_1736 == nil { tmp5 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp5 = linked_1736.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1735, arg_1738) }; var tmp9 any = tmp5; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j_A_const_221); var tmp12 any; var iter__1927001039__auto____13 any; var fnbody__1884 any = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A_New_O_O(syms__9, idset__8); var tmp13 *jrt.Class; var fncls__1883 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A_fn_class; if




	fncls__1883 == nil { var fncls__1883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__1884); A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A_fn_class = fncls__1883d; tmp13 = fncls__1883d } else { tmp13 = fncls__1883 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1884, tmp13, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(made__12); var tmp14 any = tmp12; var tmp15 any; var root_1885 any = /*line :302:1*/A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, A_arbace_o2j_expr_A_fn_class); var ifn_1887 lang.IFn; if






	linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = ctx2__10; var arg_1889 any = body__6; var arg_1890 any = tail_QMARK___2; if linked_1886 == nil { tmp15 = ifn_1887.Invoke_O_O_O__O(arg_1888, arg_1889, arg_1890) } else { tmp15 = linked_1886.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1885, arg_1888, arg_1889, arg_1890) }; return /*line :302:1*/ tmp3.Invoke_O_O_O__O(tmp4, tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp14, lang.Tuple_Create_O__IPersistentVector(tmp15))) }
//line :298:1
func A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A_New() *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A) Ctor() {}
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A) Invoke_O_O__O(self, s__1641000247__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1647 any = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A_New_O_O(s__1641000247__1, self); var tmp2 *jrt.Class; var fncls__1646 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A_fn_class; if fncls__1646 == nil { var fncls__1646d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__1647); A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A_fn_class = fncls__1646d; tmp2 = fncls__1646d } else { tmp2 = fncls__1646 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1647, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :298:1
func A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A_New_O_O(p0, p1 any) *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A) Ctor_O_O(c__s__1641000247, c__iter__1641000246 any) { t.F_s__1641000247 = c__s__1641000247; t.F_iter__1641000246 = c__iter__1641000246 }
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A) Invoke_O__O(self any) any { { var s__1641000247__1 any; var t_ any = t.F_s__1641000247; t.F_s__1641000247 = nil; s__1641000247__1 = t_; for { var temp__1927000414__auto____2 any; var root_1580 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = s__1641000247__1; if linked_1581 == nil { temp__1927000414__auto____2 = ifn_1582.Invoke_O__O(arg_1583) } else { temp__1927000414__auto____2 = linked_1581.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1580, arg_1583) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000247__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1584 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = s__1641000247__3; if linked_1585 == nil { tmp1 = ifn_1586.Invoke_O__O(arg_1587) } else { tmp1 = linked_1585.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1584, arg_1587) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1588 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = s__1641000247__3; if linked_1589 == nil { c__1927001037__auto____4 = ifn_1590.Invoke_O__O(arg_1591) } else { c__1927001037__auto____4 = linked_1589.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1588, arg_1591) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000249__6 any; var root_1592 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1593 == nil { b__1641000249__6 = ifn_1594.Invoke_O__O(arg_1595) } else { b__1641000249__6 = linked_1593.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1592, arg_1595) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1606 any = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A_New_O_I_O(b__1641000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1605 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A_fn_class; if fncls__1605 == nil { var fncls__1605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__1606); A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A_fn_class = fncls__1605d; tmp3 = fncls__1605d } else { tmp3 = fncls__1605 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1606, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1607 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any; var root_1612 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = b__1641000249__6; if linked_1613 == nil { arg_1610 = ifn_1614.Invoke_O__O(arg_1615) } else { arg_1610 = linked_1613.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1612, arg_1615) }; var arg_1611 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000246); var tmp5 any; var root_1616 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = s__1641000247__3; if linked_1617 == nil { tmp5 = ifn_1618.Invoke_O__O(arg_1619) } else { tmp5 = linked_1617.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1616, arg_1619) }; arg_1611 = tmp4.Invoke_O__O(tmp5); if linked_1608 == nil { return ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { return linked_1608.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) } } else { var root_1620 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any; var root_1625 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = b__1641000249__6; if linked_1626 == nil { arg_1623 = ifn_1627.Invoke_O__O(arg_1628) } else { arg_1623 = linked_1626.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1625, arg_1628) }; var arg_1624 any; if linked_1621 == nil { return ifn_1622.Invoke_O_O__O(arg_1623, arg_1624) } else { return linked_1621.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1620, arg_1623, arg_1624) } } } else { var id__4 any; var root_1629 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = s__1641000247__3; if linked_1630 == nil { id__4 = ifn_1631.Invoke_O__O(arg_1632) } else { id__4 = linked_1630.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1629, arg_1632) }; var root_1633 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any; var tmp6 any; var root_1638 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, A_arbace_o2j_munge_id_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = id__4; if linked_1639 == nil { tmp6 = ifn_1640.Invoke_O__O(arg_1641) } else { tmp6 = linked_1639.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1638, arg_1641) }; arg_1636 = lang.Tuple_Create_O_O__IPersistentVector(id__4, tmp6); var arg_1637 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1641000246); var tmp8 any; var root_1642 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = s__1641000247__3; if linked_1643 == nil { tmp8 = ifn_1644.Invoke_O__O(arg_1645) } else { tmp8 = linked_1643.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1642, arg_1645) }; arg_1637 = tmp7.Invoke_O__O(tmp8); if linked_1634 == nil { return ifn_1635.Invoke_O_O__O(arg_1636, arg_1637) } else { return linked_1634.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1633, arg_1636, arg_1637) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :298:1
func A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A) Ctor_O_I_O(c__b__1641000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000249 = c__b__1641000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :298:1
func (t *A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A) Invoke_O__O(self any) any { { var i__1641000248__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var id__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000248__1)); var root_1596 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = t.F_b__1641000249; var arg_1600 any; var tmp2 any; var root_1601 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, A_arbace_o2j_munge_id_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = id__2; if linked_1602 == nil { tmp2 = ifn_1603.Invoke_O__O(arg_1604) } else { tmp2 = linked_1602.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1601, arg_1604) }; arg_1600 = lang.Tuple_Create_O_O__IPersistentVector(id__2, tmp2); if linked_1597 == nil { ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { linked_1597.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) }; i__1641000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000248__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A_New_O(p0 any) *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A) Ctor_O(c__ctx2 any) { t.F_ctx2 = c__ctx2 }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A) Invoke_O_O__O(self, s__1641000257__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1728 any = A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A_New_O_O_O(t.F_ctx2, s__1641000257__1, self); var tmp2 *jrt.Class; var fncls__1727 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A_fn_class; if fncls__1727 == nil { var fncls__1727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__1728); A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A_fn_class = fncls__1727d; tmp2 = fncls__1727d } else { tmp2 = fncls__1727 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1728, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :300:1
func A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A) Ctor_O_O_O(c__ctx2, c__s__1641000257, c__iter__1641000256 any) { t.F_ctx2 = c__ctx2; t.F_s__1641000257 = c__s__1641000257; t.F_iter__1641000256 = c__iter__1641000256 }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A) Invoke_O__O(self any) any { { var s__1641000257__1 any; var t_ any = t.F_s__1641000257; t.F_s__1641000257 = nil; s__1641000257__1 = t_; for { var temp__1927000414__auto____2 any; var root_1657 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = s__1641000257__1; if linked_1658 == nil { temp__1927000414__auto____2 = ifn_1659.Invoke_O__O(arg_1660) } else { temp__1927000414__auto____2 = linked_1658.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1657, arg_1660) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000257__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1661 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = s__1641000257__3; if linked_1662 == nil { tmp1 = ifn_1663.Invoke_O__O(arg_1664) } else { tmp1 = linked_1662.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1661, arg_1664) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1665 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = s__1641000257__3; if linked_1666 == nil { c__1927001037__auto____4 = ifn_1667.Invoke_O__O(arg_1668) } else { c__1927001037__auto____4 = linked_1666.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1665, arg_1668) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000259__6 any; var root_1669 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1670 == nil { b__1641000259__6 = ifn_1671.Invoke_O__O(arg_1672) } else { b__1641000259__6 = linked_1670.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1669, arg_1672) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1685 any = A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A_New_O_O_I_O(t.F_ctx2, b__1641000259__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1684 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A_fn_class; if fncls__1684 == nil { var fncls__1684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__1685); A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A_fn_class = fncls__1684d; tmp3 = fncls__1684d } else { tmp3 = fncls__1684 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1685, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1686 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any; var root_1691 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = b__1641000259__6; if linked_1692 == nil { arg_1689 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1689 = linked_1692.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1691, arg_1694) }; var arg_1690 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000256); var tmp5 any; var root_1695 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = s__1641000257__3; if linked_1696 == nil { tmp5 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp5 = linked_1696.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1695, arg_1698) }; arg_1690 = tmp4.Invoke_O__O(tmp5); if linked_1687 == nil { return ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { return linked_1687.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) } } else { var root_1699 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any; var root_1704 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = b__1641000259__6; if linked_1705 == nil { arg_1702 = ifn_1706.Invoke_O__O(arg_1707) } else { arg_1702 = linked_1705.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1704, arg_1707) }; var arg_1703 any; if linked_1700 == nil { return ifn_1701.Invoke_O_O__O(arg_1702, arg_1703) } else { return linked_1700.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1699, arg_1702, arg_1703) } } } else { var vec__1641000270__4 any; var root_1708 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = s__1641000257__3; if linked_1709 == nil { vec__1641000270__4 = ifn_1710.Invoke_O__O(arg_1711) } else { vec__1641000270__4 = linked_1709.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1708, arg_1711) }; var id__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000270__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000270__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1712 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any; var vec__1641000273__7 any; var root_1717 any = A_arbace_o2j_A_const_218.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, A_arbace_o2j_closure_class_BANG__A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = t.F_ctx2; var arg_1721 any = f__6; var arg_1722 any = id__5; if linked_1718 == nil { vec__1641000273__7 = ifn_1719.Invoke_O_O_O__O(arg_1720, arg_1721, arg_1722) } else { vec__1641000273__7 = linked_1718.(*A_arbace_o2j_closure_class_BANG__A).Invoke_O_O_O_O__O(root_1717, arg_1720, arg_1721, arg_1722) }; var cls__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000273__7, lang.RT_IntCast_J__I_NoInit(0), nil); var free__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000273__7, lang.RT_IntCast_J__I_NoInit(1), nil); arg_1715 = lang.Tuple_Create_O_O_O__IPersistentVector(id__5, cls__8, free__9); var arg_1716 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1641000256); var tmp7 any; var root_1723 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = s__1641000257__3; if linked_1724 == nil { tmp7 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp7 = linked_1724.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1723, arg_1726) }; arg_1716 = tmp6.Invoke_O__O(tmp7); if linked_1713 == nil { return ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { return linked_1713.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :300:1
func A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A) Ctor_O_O_I_O(c__ctx2, c__b__1641000259 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx2 = c__ctx2; t.F_b__1641000259 = c__b__1641000259; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :300:1
func (t *A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A) Invoke_O__O(self any) any { { var i__1641000258__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000258__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1641000263__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000258__1)); var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000263__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000263__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1673 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = t.F_b__1641000259; var arg_1677 any; var vec__1641000266__5 any; var root_1678 any = A_arbace_o2j_A_const_218.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, A_arbace_o2j_closure_class_BANG__A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = t.F_ctx2; var arg_1682 any = f__4; var arg_1683 any = id__3; if linked_1679 == nil { vec__1641000266__5 = ifn_1680.Invoke_O_O_O__O(arg_1681, arg_1682, arg_1683) } else { vec__1641000266__5 = linked_1679.(*A_arbace_o2j_closure_class_BANG__A).Invoke_O_O_O_O__O(root_1678, arg_1681, arg_1682, arg_1683) }; var cls__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000266__5, lang.RT_IntCast_J__I_NoInit(0), nil); var free__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000266__5, lang.RT_IntCast_J__I_NoInit(1), nil); arg_1677 = lang.Tuple_Create_O_O_O__IPersistentVector(id__3, cls__6, free__7); if linked_1674 == nil { ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { linked_1674.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }; i__1641000258__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000258__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_o2j_letrec_node_fn__1641000279_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_letrec_node_fn__1641000279_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_fn__1641000279_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :302:1
func (t *A_arbace_o2j_letrec_node_fn__1641000279_A) Ctor_O_O_O(c__ctx2, c__syms, c__idset any) { t.F_ctx2 = c__ctx2; t.F_syms = c__syms; t.F_idset = c__idset }
//line :302:1
func (t *A_arbace_o2j_letrec_node_fn__1641000279_A) Invoke_O_O__O(self, p__1641000278__1 any) any { var vec__1641000280__2 any = p__1641000278__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000280__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cls__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000280__2, lang.RT_IntCast_J__I_NoInit(1), nil); var free__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000280__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any = lang.IFn_Cast(t.F_syms).Invoke_O__O(id__3); var tmp2 any; var root_1744 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1746 lang.IFn; if
													linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_1748 any; var root_1750 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, cls__4, nil)).Ref(); if linked_1751 == nil { arg_1748 = ifn_1752.Invoke_O__O(arg_1753) } else { arg_1748 = linked_1751.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1750, arg_1753) }; var arg_1749 any; var root_1754 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1756 lang.IFn; if
													linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any; var fnbody__1765 any = A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A_New_O_O(t.F_ctx2, t.F_idset); var tmp3 *jrt.Class; var fncls__1764 *jrt.Class = A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A_fn_class; if fncls__1764 == nil { var fncls__1764d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__1765); A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A_fn_class = fncls__1764d; tmp3 = fncls__1764d } else { tmp3 = fncls__1764 }; arg_1757 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1765, tmp3, nil); var arg_1758 any = free__5; if linked_1755 == nil { arg_1749 = ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { arg_1749 = linked_1755.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) }; if /*line :303:1*/ linked_1745 == nil { tmp2 = ifn_1746.Invoke_O_O_O__O(arg_1747, arg_1748, arg_1749) } else { tmp2 = linked_1745.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1744, arg_1747, arg_1748, arg_1749) }; return /*line :302:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A_New_O_O(p0, p1 any) *A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A{}; t.Ctor_O_O(p0, p1); return t }
//line :304:1
func (t *A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A) Ctor_O_O(c__ctx2, c__idset any) { t.F_ctx2 = c__ctx2; t.F_idset = c__idset }
//line :304:1
func (t *A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A) Invoke_O_O__O(self, p1__1641000241_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_idset).Invoke_O__O(p1__1641000241_SHARP___1)) { return nil } else { var root_1759 any = A_arbace_o2j_A_const_219.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, A_arbace_o2j_lookup_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = t.F_ctx2; var arg_1763 any = p1__1641000241_SHARP___1; if linked_1760 == nil { return ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { return linked_1760.(*A_arbace_o2j_lookup_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) } } }


func A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A_New_O_O(p0, p1 any) *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A{}; t.Ctor_O_O(p0, p1); return t }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A) Ctor_O_O(c__syms, c__idset any) { t.F_syms = c__syms; t.F_idset = c__idset }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A) Invoke_O_O__O(self, s__1641000287__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1882 any = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A_New_O_O_O_O(t.F_syms, s__1641000287__1, self, t.F_idset); var tmp2 *jrt.Class; var fncls__1881 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A_fn_class; if fncls__1881 == nil { var fncls__1881d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__1882); A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A_fn_class = fncls__1881d; tmp2 = fncls__1881d } else { tmp2 = fncls__1881 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1882, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :307:1
func A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A) Ctor_O_O_O_O(c__syms, c__s__1641000287, c__iter__1641000286, c__idset any) { t.F_syms = c__syms; t.F_s__1641000287 = c__s__1641000287; t.F_iter__1641000286 = c__iter__1641000286; t.F_idset = c__idset }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A) Invoke_O__O(self any) any { { var s__1641000287__1 any; var t_ any = t.F_s__1641000287; t.F_s__1641000287 = nil; s__1641000287__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1774 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = s__1641000287__1; if linked_1775 == nil { temp__1927000414__auto____2 = ifn_1776.Invoke_O__O(arg_1777) } else { temp__1927000414__auto____2 = linked_1775.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1774, arg_1777) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1641000294__4 any; var root_1778 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = xs__1927001018__auto____3; if linked_1779 == nil { vec__1641000294__4 = ifn_1780.Invoke_O__O(arg_1781) } else { vec__1641000294__4 = linked_1779.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1778, arg_1781) }; var id__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000294__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000294__4, lang.RT_IntCast_J__I_NoInit(1), nil); var free__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000294__4, lang.RT_IntCast_J__I_NoInit(2), nil); var iterys__1927001035__auto____8 any; var fnbody__1863 any = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A_New_O_O_O(t.F_syms, id__5, t.F_idset); var tmp1 *jrt.Class; var fncls__1862 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A_fn_class; _ = ___6; if fncls__1862 == nil { var fncls__1862d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__1863); A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A_fn_class = fncls__1862d; tmp1 = fncls__1862d } else { tmp1 = fncls__1862 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1863, tmp1, nil); var fs__1927001036__auto____9 any; var root_1864 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(free__7); if linked_1865 == nil { fs__1927001036__auto____9 = ifn_1866.Invoke_O__O(arg_1867) } else { fs__1927001036__auto____9 = linked_1865.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1864, arg_1867) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_1868 any = A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = fs__1927001036__auto____9; var arg_1872 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1641000286); var tmp3 any; var root_1873 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = s__1641000287__1; if linked_1874 == nil { tmp3 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp3 = linked_1874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1873, arg_1876) }; arg_1872 = tmp2.Invoke_O__O(tmp3); if linked_1869 == nil { return ifn_1870.Invoke_O_O__O(arg_1871, arg_1872) } else { return linked_1869.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1868, arg_1871, arg_1872) } } else { var tmp4 any; var root_1877 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = s__1641000287__1; if linked_1878 == nil { tmp4 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp4 = linked_1878.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1877, arg_1880) }; s__1641000287__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :307:1
func A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A) Ctor_O_O_O(c__syms, c__id, c__idset any) { t.F_syms = c__syms; t.F_id = c__id; t.F_idset = c__idset }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A) Invoke_O_O__O(self, s__1641000289__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1861 any = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A_New_O_O_O_O_O(t.F_syms, t.F_id, s__1641000289__1, self, t.F_idset); var tmp2 *jrt.Class; var fncls__1860 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A_fn_class; if fncls__1860 == nil { var fncls__1860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__1861); A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A_fn_class = fncls__1860d; tmp2 = fncls__1860d } else { tmp2 = fncls__1860 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1861, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :307:1
func A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A) Ctor_O_O_O_O_O(c__syms, c__id, c__s__1641000289, c__iter__1641000288, c__idset any) { t.F_syms = c__syms; t.F_id = c__id; t.F_s__1641000289 = c__s__1641000289; t.F_iter__1641000288 = c__iter__1641000288; t.F_idset = c__idset }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A) Invoke_O__O(self any) any { { var s__1641000289__1 any; var t_ any = t.F_s__1641000289; t.F_s__1641000289 = nil; s__1641000289__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1782 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = s__1641000289__1; if linked_1783 == nil { temp__1927000414__auto____2 = ifn_1784.Invoke_O__O(arg_1785) } else { temp__1927000414__auto____2 = linked_1783.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1782, arg_1785) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000289__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1786 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = s__1641000289__3; if linked_1787 == nil { tmp1 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp1 = linked_1787.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1786, arg_1789) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1790 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = s__1641000289__3; if linked_1791 == nil { c__1927001037__auto____4 = ifn_1792.Invoke_O__O(arg_1793) } else { c__1927001037__auto____4 = linked_1791.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1790, arg_1793) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000291__6 any; var root_1794 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1795 == nil { b__1641000291__6 = ifn_1796.Invoke_O__O(arg_1797) } else { b__1641000291__6 = linked_1795.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1794, arg_1797) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1812 any = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A_New_O_O_O_I_O_O(t.F_syms, t.F_id, b__1641000291__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_idset); var tmp3 *jrt.Class; var fncls__1811 *jrt.Class = A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A_fn_class; if fncls__1811 == nil { var fncls__1811d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__1812); A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A_fn_class = fncls__1811d; tmp3 = fncls__1811d } else { tmp3 = fncls__1811 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1812, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1813 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var root_1818 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = b__1641000291__6; if linked_1819 == nil { arg_1816 = ifn_1820.Invoke_O__O(arg_1821) } else { arg_1816 = linked_1819.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1818, arg_1821) }; var arg_1817 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000288); var tmp5 any; var root_1822 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = s__1641000289__3; if linked_1823 == nil { tmp5 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp5 = linked_1823.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1822, arg_1825) }; arg_1817 = tmp4.Invoke_O__O(tmp5); if linked_1814 == nil { return ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { return linked_1814.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) } } else { var root_1826 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any; var root_1831 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = b__1641000291__6; if linked_1832 == nil { arg_1829 = ifn_1833.Invoke_O__O(arg_1834) } else { arg_1829 = linked_1832.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1831, arg_1834) }; var arg_1830 any; if linked_1827 == nil { return ifn_1828.Invoke_O_O__O(arg_1829, arg_1830) } else { return linked_1827.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1826, arg_1829, arg_1830) } } } else { var fr__4 any; var root_1835 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1837 lang.IFn; if linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any = s__1641000289__3; if linked_1836 == nil { fr__4 = ifn_1837.Invoke_O__O(arg_1838) } else { fr__4 = linked_1836.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1835, arg_1838) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_idset).Invoke_O__O(fr__4)) { var root_1839 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_222; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp9 any; var root_1844 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1846 lang.IFn
																			if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp11 any; var root_1848 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, A_arbace_o2j_munge_id_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = fr__4; if linked_1849 == nil { tmp11 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp11 = linked_1849.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1848, arg_1851) }; arg_1847 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); if linked_1845 == nil { tmp9 = ifn_1846.Invoke_O__O(arg_1847) } else { tmp9 = linked_1845.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1844, arg_1847) }; arg_1842 = tmp6.Invoke_O_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(t.F_syms).Invoke_O__O(t.F_id)), lang.IFn_Cast(t.F_syms).Invoke_O__O(fr__4))
//line :307:1
	var arg_1843 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1641000288); var tmp13 any; var root_1852 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = s__1641000289__3; if linked_1853 == nil { tmp13 = ifn_1854.Invoke_O__O(arg_1855) } else { tmp13 = linked_1853.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1852, arg_1855) }; arg_1843 = tmp12.Invoke_O__O(tmp13); if linked_1840 == nil { return ifn_1841.Invoke_O_O__O(arg_1842, arg_1843) } else { return linked_1840.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1839, arg_1842, arg_1843) } } else { var tmp14 any; var root_1856 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = s__1641000289__3; if linked_1857 == nil { tmp14 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp14 = linked_1857.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1856, arg_1859) }; s__1641000289__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :307:1
func A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A) Ctor_O_O_O_I_O_O(c__syms, c__id, c__b__1641000291 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__idset any) { t.F_syms = c__syms; t.F_id = c__id; t.F_b__1641000291 = c__b__1641000291; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_idset = c__idset }
//line :307:1
func (t *A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A) Invoke_O__O(self any) any { { var i__1641000290__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000290__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fr__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000290__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_idset).Invoke_O__O(fr__2)) { var root_1798 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = t.F_b__1641000291; var arg_1802 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_222; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp5 any; var root_1803 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1805 lang.IFn
																					if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp7 any; var root_1807 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, A_arbace_o2j_munge_id_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = fr__2; if linked_1808 == nil { tmp7 = ifn_1809.Invoke_O__O(arg_1810) } else { tmp7 = linked_1808.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1807, arg_1810) }; arg_1806 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if linked_1804 == nil { tmp5 = ifn_1805.Invoke_O__O(arg_1806) } else { tmp5 = linked_1804.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1803, arg_1806) }; arg_1802 = tmp2.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(t.F_syms).Invoke_O__O(t.F_id)), lang.IFn_Cast(t.F_syms).Invoke_O__O(fr__2))
//line :307:1
	if linked_1799 == nil { ifn_1800.Invoke_O_O__O(arg_1801, arg_1802) } else { linked_1799.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1798, arg_1801, arg_1802) }; i__1641000290__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000290__1); continue L1 } else { i__1641000290__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000290__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_o2j_let_chain_A_New() *A_arbace_o2j_let_chain_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_let_chain_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_o2j_let_chain_A) Ctor() {}
//line :313:1
func (t *A_arbace_o2j_let_chain_A) Invoke_O_O_O_O__O(self, ctx__0, x__1, tail_QMARK___2 any) any { { var x__4 any = x__1; var ctx__5 any = ctx__0; var bindings__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var G__1641000306__7_ any; var root_1891 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, A_arbace_o2j_hd_A_fn_class); var ifn_1893 lang.IFn



	if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = x__4; if linked_1892 == nil { G__1641000306__7_ = ifn_1893.Invoke_O__O(arg_1894) } else { G__1641000306__7_ = linked_1892.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_1891, arg_1894) }; switch lang.Util_Hash_O__I_NoInit(G__1641000306__7_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000306__7_, A_arbace_o2j_A_const_223) { var vec__1641000307__8 any; var root_1896 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, A_arbace_o2j_node_body_A_fn_class); var ifn_1898 lang.IFn
		if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = x__4; if linked_1897 == nil { vec__1641000307__8 = ifn_1898.Invoke_O__O(arg_1899) } else { vec__1641000307__8 = linked_1897.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_1896, arg_1899) }
//line :317:1
		var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000307__8, lang.RT_IntCast_J__I_NoInit(0), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000307__8, lang.RT_IntCast_J__I_NoInit(1), nil); var id__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000307__8, lang.RT_IntCast_J__I_NoInit(2), nil); var def__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000307__8, lang.RT_IntCast_J__I_NoInit(3), nil); var body__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000307__8, lang.RT_IntCast_J__I_NoInit(4), nil); var s__14 any; var root_1900 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, A_arbace_o2j_munge_id_A_fn_class); var ifn_1902 lang.IFn; _ = ___9; _ = ___10

		if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = id__11; if linked_1901 == nil { s__14 = ifn_1902.Invoke_O__O(arg_1903) } else { s__14 = linked_1901.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1900, arg_1903) }
		var tmp1 any; var root_1917 any = A_arbace_o2j_A_const_226.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = ctx__5; var arg_1921 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_145, id__11); var arg_1922 any = s__14; if linked_1918 == nil { tmp1 = ifn_1919.Invoke_O_O_O__O(arg_1920, arg_1921, arg_1922) } else { tmp1 = linked_1918.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1917, arg_1920, arg_1921, arg_1922) }; var tmp2 any = tmp1; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_8.GetRawRoot__O()); var tmp4 any; var root_1929 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, A_arbace_o2j_expr_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = ctx__5; var arg_1933 any = def__12; var arg_1934 any = jrt.Boolean_FALSE.Ref(); if linked_1930 == nil { tmp4 = ifn_1931.Invoke_O_O_O__O(arg_1932, arg_1933, arg_1934) } else { tmp4 = linked_1930.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1929, arg_1932, arg_1933, arg_1934) }; x__4, ctx__5, bindings__6 = body__13, tmp2, tmp3.Invoke_O_O_O__O(bindings__6, s__14, tmp4); continue L1 }
//line :317:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000306__7_, A_arbace_o2j_A_const_224) { var vec__1641000310__8 any; var root_1904 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, A_arbace_o2j_node_body_A_fn_class); var ifn_1906 lang.IFn



		if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = x__4; if linked_1905 == nil { vec__1641000310__8 = ifn_1906.Invoke_O__O(arg_1907) } else { vec__1641000310__8 = linked_1905.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_1904, arg_1907) }
//line :317:1
		var ___9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000310__8, lang.RT_IntCast_J__I_NoInit(0), nil); var id__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000310__8, lang.RT_IntCast_J__I_NoInit(1), nil); var def__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000310__8, lang.RT_IntCast_J__I_NoInit(2), nil); var body__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000310__8, lang.RT_IntCast_J__I_NoInit(3), nil); var s__13 any; var root_1908 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1910 lang.IFn; _ = ___9_2




		if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any; var root_1913 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, A_arbace_o2j_munge_id_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = id__10; if linked_1914 == nil { arg_1911 = ifn_1915.Invoke_O__O(arg_1916) } else { arg_1911 = linked_1914.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1913, arg_1916) }; var arg_1912 any = A_arbace_o2j_A_const_225; if linked_1909 == nil { s__13 = ifn_1910.Invoke_O_O__O(arg_1911, arg_1912) } else { s__13 = linked_1909.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1908, arg_1911, arg_1912) }
		var tmp5 any; var root_1935 any = A_arbace_o2j_A_const_226.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = ctx__5; var arg_1939 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_145, id__10); var arg_1940 any; var root_1941 any = A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, A_arbace_o2j_munge_id_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = id__10; if linked_1942 == nil { arg_1940 = ifn_1943.Invoke_O__O(arg_1944) } else { arg_1940 = linked_1942.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_1941, arg_1944) }; if linked_1936 == nil { tmp5 = ifn_1937.Invoke_O_O_O__O(arg_1938, arg_1939, arg_1940) } else { tmp5 = linked_1936.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1935, arg_1938, arg_1939, arg_1940) }; var tmp6 any = tmp5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_8.GetRawRoot__O()); var tmp8 any; var root_1951 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, A_arbace_o2j_expr_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = ctx__5; var arg_1955 any = def__11; var arg_1956 any = jrt.Boolean_FALSE.Ref(); if linked_1952 == nil { tmp8 = ifn_1953.Invoke_O_O_O__O(arg_1954, arg_1955, arg_1956) } else { tmp8 = linked_1952.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1951, arg_1954, arg_1955, arg_1956) }; x__4, ctx__5, bindings__6 = body__12, tmp6, tmp7.Invoke_O_O_O__O(bindings__6, s__13, tmp8); continue L1 }
//line :317:1
	default:
	}





	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_o2j_A_const_227; var tmp11 any; var root_1957 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, A_arbace_o2j_expr_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = ctx__5; var arg_1961 any = x__4; var arg_1962 any = tail_QMARK___2; if linked_1958 == nil { tmp11 = ifn_1959.Invoke_O_O_O__O(arg_1960, arg_1961, arg_1962) } else { tmp11 = linked_1958.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_1957, arg_1960, arg_1961, arg_1962) }; return tmp9.Invoke_O_O_O__O(tmp10, bindings__6, tmp11) } }; /*line :313:1*/panic("j2g: unreachable") }














func A_arbace_o2j_num_arg_A_New() *A_arbace_o2j_num_arg_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_num_arg_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_o2j_num_arg_A) Ctor() {}
//line :328:1
func (t *A_arbace_o2j_num_arg_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var root_1963 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any; var root_1967 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any; var root_1972 any = A_arbace_o2j_A_const_229.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any; var root_1976 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = n__0; var arg_1980 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_20)))).Ref(); if linked_1977 == nil { arg_1975 = ifn_1978.Invoke_O_O__O(arg_1979, arg_1980) } else { arg_1975 = linked_1977.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1976, arg_1979, arg_1980) }; if linked_1973 == nil { arg_1970 = ifn_1974.Invoke_O__O(arg_1975) } else { arg_1970 = linked_1973.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1972, arg_1975) }; var arg_1971 any = A_arbace_o2j_A_const_230; if linked_1968 == nil { arg_1966 = ifn_1969.Invoke_O_O__O(arg_1970, arg_1971) } else { arg_1966 = linked_1968.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1967, arg_1970, arg_1971) }; if linked_1964 == nil { tmp1 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp1 = linked_1964.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1963, arg_1966) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp1))).Ref() }

func A_arbace_o2j_rt_A_New() *A_arbace_o2j_rt_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_rt_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_o2j_rt_A) Ctor() {}
//line :330:1
func (t *A_arbace_o2j_rt_A) DoInvoke_O_O_O__O(self, m__0, args__1 any) any { var root_1981 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_1985 any; var root_1987 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = Lit_117; var arg_1991 any; var root_1992 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = m__0; if linked_1993 == nil { arg_1991 = ifn_1994.Invoke_O__O(arg_1995) } else { arg_1991 = linked_1993.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1992, arg_1995) }; if linked_1988 == nil { arg_1985 = ifn_1989.Invoke_O_O__O(arg_1990, arg_1991) } else { arg_1985 = linked_1988.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1987, arg_1990, arg_1991) }; var arg_1986 any = args__1; if linked_1982 == nil { return ifn_1983.Invoke_O_O_O__O(arg_1984, arg_1985, arg_1986) } else { return linked_1982.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1981, arg_1984, arg_1985, arg_1986) } }

















func A_arbace_o2j_array_kind_A_New() *A_arbace_o2j_array_kind_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_array_kind_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_o2j_array_kind_A) Ctor() {}
//line :348:1
func (t *A_arbace_o2j_array_kind_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_27); if
									lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_28 } else { var root_1996 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = n__0; var arg_2000 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__2))).Ref(); var arg_2001 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_29)).Ref(); if linked_1997 == nil { return ifn_1998.Invoke_O_O_O__O(arg_1999, arg_2000, arg_2001) } else { return linked_1997.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1996, arg_1999, arg_2000, arg_2001) } } }

func A_arbace_o2j_bigarray_ext_A_New() *A_arbace_o2j_bigarray_ext_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_bigarray_ext_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_o2j_bigarray_ext_A) Ctor() {}
//line :351:1
func (t *A_arbace_o2j_bigarray_ext_A) Invoke_O_O_O__O(self, n__0, nargs__1 any) any { if jrt.Long_InstanceOf(nargs__1) { return t.InvokeSpec_O_O_J_O__O(self, n__0, jrt.NN(jrt.Long_Cast(nargs__1)).LongValue__J(), nargs__1) } else {
											var tmp1 any; var root_2002 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = n__0; var arg_2006 any = Lit_30; if linked_2003 == nil { tmp1 = ifn_2004.Invoke_O_O__O(arg_2005, arg_2006) } else { tmp1 = linked_2003.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2002, arg_2005, arg_2006) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp3 any; var root_2007 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = n__0; var arg_2011 any = A_arbace_o2j_A_const_231; if linked_2008 == nil { tmp3 = ifn_2009.Invoke_O_O__O(arg_2010, arg_2011) } else { tmp3 = linked_2008.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2007, arg_2010, arg_2011) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else { var tmp4 any; var root_2012 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2014 lang.IFn
												if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = n__0; var arg_2016 any = Lit_32; if linked_2013 == nil { tmp4 = ifn_2014.Invoke_O_O__O(arg_2015, arg_2016) } else { tmp4 = linked_2013.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2012, arg_2015, arg_2016) }
//line :352:1
		if jrt.J2g_Truth(tmp4) { return Lit_33 } else { var tmp5 any; var root_2017 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2019 lang.IFn

			if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = n__0; var arg_2021 any = Lit_34; if linked_2018 == nil { tmp5 = ifn_2019.Invoke_O_O__O(arg_2020, arg_2021) } else { tmp5 = linked_2018.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2017, arg_2020, arg_2021) }
//line :352:1
			if jrt.J2g_Truth(tmp5) { return Lit_35 } else { var tmp6 any; var root_2022 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2024 lang.IFn


				if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = n__0; var arg_2026 any = Lit_36; if linked_2023 == nil { tmp6 = ifn_2024.Invoke_O_O__O(arg_2025, arg_2026) } else { tmp6 = linked_2023.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2022, arg_2025, arg_2026) }
//line :352:1
				if jrt.J2g_Truth(tmp6) { return Lit_37 } else { var tmp7 any; var root_2027 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2029 lang.IFn



					if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = n__0; var arg_2031 any = Lit_38; if linked_2028 == nil { tmp7 = ifn_2029.Invoke_O_O__O(arg_2030, arg_2031) } else { tmp7 = linked_2028.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2027, arg_2030, arg_2031) }
//line :352:1
					if jrt.J2g_Truth(tmp7) { return Lit_39 } else { var tmp8 any; var root_2032 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2034 lang.IFn




						if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = n__0; var arg_2036 any = Lit_40; if linked_2033 == nil { tmp8 = ifn_2034.Invoke_O_O__O(arg_2035, arg_2036) } else { tmp8 = linked_2033.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2032, arg_2035, arg_2036) }
//line :352:1
						if jrt.J2g_Truth(tmp8) { return Lit_41 } else { var tmp9 any; var root_2037 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2039 lang.IFn





							if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = n__0; var arg_2041 any = Lit_42; if linked_2038 == nil { tmp9 = ifn_2039.Invoke_O_O__O(arg_2040, arg_2041) } else { tmp9 = linked_2038.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2037, arg_2040, arg_2041) }
//line :352:1
							if jrt.J2g_Truth(tmp9) { return Lit_43 } else { var tmp10 any; var root_2042 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2044 lang.IFn







								if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = n__0; var arg_2046 any = Lit_44; if linked_2043 == nil { tmp10 = ifn_2044.Invoke_O_O__O(arg_2045, arg_2046) } else { tmp10 = linked_2043.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2042, arg_2045, arg_2046) }
//line :352:1
								if jrt.J2g_Truth(tmp10) {







									var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp12 jrt.Number_I; var na_2047 any = nargs__1; if jrt.Long_InstanceOf(na_2047) { var n0_2048 int64 = jrt.NN(jrt.Long_Cast(na_2047)).LongValue__J(); if n0_2048 == -9223372036854775808 { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_2047) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_2048 - 1)) } } else { if jrt.Double_InstanceOf(na_2047) { var n0_2048_2 float64 = jrt.NN(jrt.Double_Cast(na_2047)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2048_2 - 1.0)) } else { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_2047) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref() } else {
//line :352:1
										var tmp13 any; var root_2049 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2051 lang.IFn








										if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = n__0; var arg_2053 any = Lit_46; if linked_2050 == nil { tmp13 = ifn_2051.Invoke_O_O__O(arg_2052, arg_2053) } else { tmp13 = linked_2050.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2049, arg_2052, arg_2053) }
//line :352:1
										if jrt.J2g_Truth(tmp13) {








											var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil); var tmp15 jrt.Number_I; var na_2054 any = nargs__1; var na_2055 int64 = 2; if jrt.Long_InstanceOf(na_2054) { var n0_2056 int64 = jrt.NN(jrt.Long_Cast(na_2054)).LongValue__J(); var n1_2057 int64 = na_2055; var nr_2058 int64 = n0_2056 - n1_2057; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_2057 == -9223372036854775808); if tmp17 { tmp17 = (n0_2056^n1_2057)&(n0_2056^nr_2058) >= 0 }; tmp16 = tmp17; if tmp16 { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2058)) } else { tmp15 = lang.Numbers_Minus_O_J__Number_NoInit(na_2054, na_2055) } } else { tmp15 = lang.Numbers_Minus_O_J__Number_NoInit(na_2054, na_2055) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)).Ref() } else {
//line :352:1
												if A_arbace_o2j_A_const_44 != nil { return n__0 } else { return nil } } } } } } } } } } } }
//line :351:1
func (t *A_arbace_o2j_bigarray_ext_A) InvokeSpec_O_O_J_O__O(self, n__0 any, nargs__1_l int64, nargs__1_b any) any {
	var tmp1 any; var root_2059 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = n__0; var arg_2063 any = Lit_30; if linked_2060 == nil { tmp1 = ifn_2061.Invoke_O_O__O(arg_2062, arg_2063) } else { tmp1 = linked_2060.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2059, arg_2062, arg_2063) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp3 any; var root_2064 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = n__0; var arg_2068 any = A_arbace_o2j_A_const_231; if linked_2065 == nil { tmp3 = ifn_2066.Invoke_O_O__O(arg_2067, arg_2068) } else { tmp3 = linked_2065.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2064, arg_2067, arg_2068) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else { var tmp4 any; var root_2069 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2071 lang.IFn
		if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = n__0; var arg_2073 any = Lit_32; if linked_2070 == nil { tmp4 = ifn_2071.Invoke_O_O__O(arg_2072, arg_2073) } else { tmp4 = linked_2070.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2069, arg_2072, arg_2073) }
//line :352:1
		if jrt.J2g_Truth(tmp4) { return Lit_33 } else { var tmp5 any; var root_2074 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2076 lang.IFn

			if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = n__0; var arg_2078 any = Lit_34; if linked_2075 == nil { tmp5 = ifn_2076.Invoke_O_O__O(arg_2077, arg_2078) } else { tmp5 = linked_2075.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2074, arg_2077, arg_2078) }
//line :352:1
			if jrt.J2g_Truth(tmp5) { return Lit_35 } else { var tmp6 any; var root_2079 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2081 lang.IFn


				if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = n__0; var arg_2083 any = Lit_36; if linked_2080 == nil { tmp6 = ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { tmp6 = linked_2080.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083) }
//line :352:1
				if jrt.J2g_Truth(tmp6) { return Lit_37 } else { var tmp7 any; var root_2084 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2086 lang.IFn



					if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = n__0; var arg_2088 any = Lit_38; if linked_2085 == nil { tmp7 = ifn_2086.Invoke_O_O__O(arg_2087, arg_2088) } else { tmp7 = linked_2085.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2084, arg_2087, arg_2088) }
//line :352:1
					if jrt.J2g_Truth(tmp7) { return Lit_39 } else { var tmp8 any; var root_2089 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2091 lang.IFn




						if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = n__0; var arg_2093 any = Lit_40; if linked_2090 == nil { tmp8 = ifn_2091.Invoke_O_O__O(arg_2092, arg_2093) } else { tmp8 = linked_2090.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2089, arg_2092, arg_2093) }
//line :352:1
						if jrt.J2g_Truth(tmp8) { return Lit_41 } else { var tmp9 any; var root_2094 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2096 lang.IFn





							if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = n__0; var arg_2098 any = Lit_42; if linked_2095 == nil { tmp9 = ifn_2096.Invoke_O_O__O(arg_2097, arg_2098) } else { tmp9 = linked_2095.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2094, arg_2097, arg_2098) }
//line :352:1
							if jrt.J2g_Truth(tmp9) { return Lit_43 } else { var tmp10 any; var root_2099 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2101 lang.IFn







								if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = n__0; var arg_2103 any = Lit_44; if linked_2100 == nil { tmp10 = ifn_2101.Invoke_O_O__O(arg_2102, arg_2103) } else { tmp10 = linked_2100.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2099, arg_2102, arg_2103) }
//line :352:1
								if jrt.J2g_Truth(tmp10) {







									var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp12 jrt.Number_I; var n0_2104 int64 = nargs__1_l; if n0_2104 == -9223372036854775808 { var tmp13 any; if nargs__1_b == nil { nargs__1_b = jrt.Long_ValueOf_J__Long_NoInit(nargs__1_l).Ref(); tmp13 = nargs__1_b } else { tmp13 = nargs__1_b }; tmp12 = lang.Numbers_Dec_O__Number_NoInit(tmp13) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_2104 - 1)) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref() } else {
//line :352:1
										var tmp14 any; var root_2105 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2107 lang.IFn








										if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = n__0; var arg_2109 any = Lit_46; if linked_2106 == nil { tmp14 = ifn_2107.Invoke_O_O__O(arg_2108, arg_2109) } else { tmp14 = linked_2106.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2105, arg_2108, arg_2109) }
//line :352:1
										if jrt.J2g_Truth(tmp14) {








											var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_47, nil); var tmp16 jrt.Number_I; var na_2110 int64 = 2; var n0_2111 int64 = nargs__1_l; var n1_2112 int64 = na_2110; var nr_2113 int64 = n0_2111 - n1_2112; var tmp17 bool; var tmp18 bool; tmp18 = !(n1_2112 == -9223372036854775808); if tmp18 { tmp18 = (n0_2111^n1_2112)&(n0_2111^nr_2113) >= 0 }; tmp17 = tmp18; if tmp17 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2113)) } else { var tmp19 any; if nargs__1_b == nil { nargs__1_b = jrt.Long_ValueOf_J__Long_NoInit(nargs__1_l).Ref(); tmp19 = nargs__1_b } else { tmp19 = nargs__1_b }; tmp16 = lang.Numbers_Minus_O_J__Number_NoInit(tmp19, na_2110) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)).Ref() } else {
//line :352:1
												if A_arbace_o2j_A_const_44 != nil { return n__0 } else { return nil
												}
											}
									}
							}
						}
					}
				}
			}
		}
	}
}
func A_arbace_o2j_external_A_New() *A_arbace_o2j_external_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_external_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_o2j_external_A) Ctor() {}
//line :364:1
func (t *A_arbace_o2j_external_A) Invoke_O_O_O__O(self, name__0, args__1 any) any { var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_o2j_A_const_75.Get__O(), name__0); if
											jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1641000318__4 any = temp__1927000408__auto____3; var cls__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var arity__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000318__4, lang.RT_IntCast_J__I_NoInit(1), nil)
												if lang.Util_Equiv_O_J__Z_NoInit(arity__6, int64(lang.RT_Count_O__I_NoInit(args__1))) {
													var root_2114 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_2118 any; var root_2120 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any; var root_2125 any = A_arbace_o2j_A_const_31.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = cls__5; if linked_2126 == nil { arg_2123 = ifn_2127.Invoke_O__O(arg_2128) } else { arg_2123 = linked_2126.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2125, arg_2128) }; var arg_2124 any = name__0; if linked_2121 == nil { arg_2118 = ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { arg_2118 = linked_2121.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) }; var arg_2119 any = args__1; if linked_2115 == nil { return ifn_2116.Invoke_O_O_O__O(arg_2117, arg_2118, arg_2119) } else { return linked_2115.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2114, arg_2117, arg_2118, arg_2119) } } else {
														var root_2129 any = A_arbace_o2j_A_const_233.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, A_arbace_o2j_note_missing_BANG__A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_81, nil), jrt.RefArrayOf(jrt.Object_class, name__0, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__1)).Ref())).Ref(); if linked_2130 == nil { ifn_2131.Invoke_O__O(arg_2132) } else { linked_2130.(*A_arbace_o2j_note_missing_BANG__A).Invoke_O_O__O(root_2129, arg_2132) }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_234; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp4 any = A_arbace_o2j_A_const_236; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_81, nil), jrt.RefArrayOf(jrt.Object_class, name__0, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__1)).Ref())).Ref())) } } else {
															var root_2138 any = A_arbace_o2j_A_const_233.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, A_arbace_o2j_note_missing_BANG__A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = name__0; if linked_2139 == nil { ifn_2140.Invoke_O__O(arg_2141) } else { linked_2139.(*A_arbace_o2j_note_missing_BANG__A).Invoke_O_O__O(root_2138, arg_2141) }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_o2j_A_const_237; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_238, name__0)) } }




func A_arbace_o2j_prim_value_A_New() *A_arbace_o2j_prim_value_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_prim_value_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_o2j_prim_value_A) Ctor() {}
//line :374:1
func (t *A_arbace_o2j_prim_value_A) Invoke_O_O_O__O(self, n__0, as__1 any) any { var vec__1641000322__3 any = as__1; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000322__3, lang.RT_IntCast_J__I_NoInit(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000322__3, lang.RT_IntCast_J__I_NoInit(1), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000322__3, lang.RT_IntCast_J__I_NoInit(2), nil); var word__7 any; var root_2147 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2149 lang.IFn; if



	linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2151 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any = n__0; var arg_2155 any = A_arbace_o2j_A_const_239; if linked_2152 == nil { arg_2150 = ifn_2153.Invoke_O_O__O(arg_2154, arg_2155) } else { arg_2150 = linked_2152.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2151, arg_2154, arg_2155) }; if linked_2148 == nil { word__7 = ifn_2149.Invoke_O__O(arg_2150) } else { word__7 = linked_2148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2147, arg_2150) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_240.GetRawRoot__O()).Invoke_O__O(n__0)) {
		var root_2156 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = A_arbace_o2j_A_const_235.GetRawRoot__O(); var arg_2160 any = lang.IFn_Cast(A_arbace_o2j_A_const_240.GetRawRoot__O()).Invoke_O__O(n__0); var arg_2161 any = as__1; if linked_2157 == nil { return ifn_2158.Invoke_O_O_O__O(arg_2159, arg_2160, arg_2161) } else { return linked_2157.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2156, arg_2159, arg_2160, arg_2161) } } else {
//line :379:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()).Invoke_O__O(n__0)) {

				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_242; var tmp3 any; var root_2167 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = A_arbace_o2j_A_const_235.GetRawRoot__O(); var arg_2171 any = lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()).Invoke_O__O(n__0); var arg_2172 any = as__1; if linked_2168 == nil { tmp3 = ifn_2169.Invoke_O_O_O__O(arg_2170, arg_2171, arg_2172) } else { tmp3 = linked_2168.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2167, arg_2170, arg_2171, arg_2172) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) } else {
//line :379:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_243.GetRawRoot__O()).Invoke_O__O(n__0)) {


						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp5 any = A_arbace_o2j_A_const_244; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_245; var tmp8 any; var root_2178 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = A_arbace_o2j_A_const_235.GetRawRoot__O(); var arg_2182 any = lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_o2j_A_const_243.GetRawRoot__O()).Invoke_O__O(n__0)); var arg_2183 any = as__1; if linked_2179 == nil { tmp8 = ifn_2180.Invoke_O_O_O__O(arg_2181, arg_2182, arg_2183) } else { tmp8 = linked_2179.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2178, arg_2181, arg_2182, arg_2183) }; return tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } else {
//line :379:1
							var tmp9 any; var root_2184 any = A_arbace_o2j_A_const_246.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_2186 lang.IFn



							if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = A_arbace_o2j_A_const_247; var arg_2188 any = n__0; if linked_2185 == nil { tmp9 = ifn_2186.Invoke_O_O__O(arg_2187, arg_2188) } else { tmp9 = linked_2185.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_2184, arg_2187, arg_2188) }
//line :379:1
							if jrt.J2g_Truth(tmp9) {



								var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp11 any = A_arbace_o2j_A_const_248; var tmp12 any; var root_2195 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = n__0; var arg_2199 any = A_arbace_o2j_A_const_87; var arg_2200 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__0)))).Ref(); if linked_2196 == nil { tmp12 = ifn_2197.Invoke_O_O_O__O(arg_2198, arg_2199, arg_2200) } else { tmp12 = linked_2196.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2195, arg_2198, arg_2199, arg_2200) }; return tmp10.Invoke_O_O_O__O(tmp11, a__4, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp12))).Ref()) } else {
//line :379:1
									var tmp13 any; var root_2201 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2203 lang.IFn




									if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = n__0; var arg_2205 any = Lit_120; if linked_2202 == nil { tmp13 = ifn_2203.Invoke_O_O__O(arg_2204, arg_2205) } else { tmp13 = linked_2202.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2201, arg_2204, arg_2205) }
//line :379:1
									if jrt.J2g_Truth(tmp13) {




										var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_o2j_A_const_322; var tmp16 any = A_arbace_o2j_A_const_87; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_323; var tmp19 any = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_324, a__4, A_arbace_o2j_A_const_87); var tmp20 any; var root_2622 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = n__0; var arg_2626 any = A_arbace_o2j_A_const_325; if linked_2623 == nil { tmp20 = ifn_2624.Invoke_O_O__O(arg_2625, arg_2626) } else { tmp20 = linked_2623.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2622, arg_2625, arg_2626) }; return tmp14.Invoke_O_O_O_O__O(tmp15, a__4, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp20))).Ref())) } else {
//line :379:1
											if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_121) {





												var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp22 any = A_arbace_o2j_A_const_249; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp24 any = A_arbace_o2j_A_const_250; return tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_251, a__4))) } else {
//line :379:1
													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_252).Invoke_O__O(word__7)) { var tag__8 any; var root_2216 any = A_arbace_o2j_A_const_253.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, A_arbace_o2j_num_arg_A_fn_class); var ifn_2218 lang.IFn







														if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = n__0; if linked_2217 == nil { tag__8 = ifn_2218.Invoke_O__O(arg_2219) } else { tag__8 = linked_2217.(*A_arbace_o2j_num_arg_A).Invoke_O_O__O(root_2216, arg_2219) }; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_254; var tmp27 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_255, tag__8); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp29 any = A_arbace_o2j_A_const_256; var tmp30 any = A_arbace_o2j_A_const_257; var tmp31 any; var root_2226 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = as__1; if linked_2227 == nil { tmp31 = ifn_2228.Invoke_O__O(arg_2229) } else { tmp31 = linked_2227.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2226, arg_2229) }; return tmp25.Invoke_O_O_O__O(tmp26, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, tmp31)) } else {
//line :379:1
															if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_122) {








																var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp33 any = A_arbace_o2j_A_const_258; var tmp34 any = A_arbace_o2j_A_const_259; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp36 any = A_arbace_o2j_A_const_260; var tmp37 any = A_arbace_o2j_A_const_261; var tmp38 any; var root_2236 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = as__1; if linked_2237 == nil { tmp38 = ifn_2238.Invoke_O__O(arg_2239) } else { tmp38 = linked_2237.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2236, arg_2239) }; return tmp32.Invoke_O_O_O__O(tmp33, tmp34, tmp35.Invoke_O_O_O__O(tmp36, tmp37, tmp38)) } else {
//line :379:1
																	if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_123) {









																		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp40 any = A_arbace_o2j_A_const_326; var tmp41 any = A_arbace_o2j_A_const_327; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp43 any = A_arbace_o2j_A_const_328; var tmp44 any = A_arbace_o2j_A_const_329; var tmp45 any; var root_2627 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any = as__1; if linked_2628 == nil { tmp45 = ifn_2629.Invoke_O__O(arg_2630) } else { tmp45 = linked_2628.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2627, arg_2630) }; return tmp39.Invoke_O_O_O__O(tmp40, tmp41, tmp42.Invoke_O_O_O__O(tmp43, tmp44, tmp45)) } else {
//line :379:1
																			if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_124) {










																				var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp47 any = A_arbace_o2j_A_const_330; var tmp48 any = A_arbace_o2j_A_const_331; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp50 any = A_arbace_o2j_A_const_332; var tmp51 any = A_arbace_o2j_A_const_333; var tmp52 any; var root_2631 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = as__1; if linked_2632 == nil { tmp52 = ifn_2633.Invoke_O__O(arg_2634) } else { tmp52 = linked_2632.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2631, arg_2634) }; return tmp46.Invoke_O_O_O__O(tmp47, tmp48, tmp49.Invoke_O_O_O__O(tmp50, tmp51, tmp52)) } else {
//line :379:1
																					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_262).Invoke_O__O(word__7)) {











																						var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp54 any = A_arbace_o2j_A_const_263; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp56 any = A_arbace_o2j_A_const_264; var tmp57 any; var root_2246 any = A_arbace_o2j_A_const_253.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, A_arbace_o2j_num_arg_A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = n__0; if linked_2247 == nil { tmp57 = ifn_2248.Invoke_O__O(arg_2249) } else { tmp57 = linked_2247.(*A_arbace_o2j_num_arg_A).Invoke_O_O__O(root_2246, arg_2249) }; return tmp53.Invoke_O_O_O__O(tmp54, a__4, tmp55.Invoke_O_O__O(tmp56, tmp57)) } else {
//line :379:1
																							if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_125) {












																								var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp59 any = A_arbace_o2j_A_const_265; return tmp58.Invoke_O_O_O__O(tmp59, a__4, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_266, b__5)) } else {
//line :379:1
																									if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_126) {













																										var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp61 any = A_arbace_o2j_A_const_267; return tmp60.Invoke_O_O_O_O__O(tmp61, a__4, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_268, b__5), c__6) } else {
//line :379:1
																											var tmp62 any; var root_2273 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2275 lang.IFn














																											if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = n__0; var arg_2277 any = Lit_127; if linked_2274 == nil { tmp62 = ifn_2275.Invoke_O_O__O(arg_2276, arg_2277) } else { tmp62 = linked_2274.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2273, arg_2276, arg_2277) }
//line :379:1
																											if jrt.J2g_Truth(tmp62) {














																												return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_269, a__4, b__5) } else {
//line :379:1
																													var tmp63 any; var root_2284 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2286 lang.IFn















																													if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = n__0; var arg_2288 any = Lit_128; if linked_2285 == nil { tmp63 = ifn_2286.Invoke_O_O__O(arg_2287, arg_2288) } else { tmp63 = linked_2285.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2284, arg_2287, arg_2288) }
//line :379:1
																													if jrt.J2g_Truth(tmp63) {















																														return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_270, a__4) } else {
//line :379:1
																															var tmp64 any; var and__1927000168__auto____8 any; var root_2294 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2296 lang.IFn
















																															if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = n__0; var arg_2298 any = Lit_129; if linked_2295 == nil { and__1927000168__auto____8 = ifn_2296.Invoke_O_O__O(arg_2297, arg_2298) } else { and__1927000168__auto____8 = linked_2295.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2294, arg_2297, arg_2298) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2299 any = A_arbace_o2j_A_const_91.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any; var root_2303 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = n__0; var arg_2307 any = Lit_126; if linked_2304 == nil { arg_2302 = ifn_2305.Invoke_O_O__O(arg_2306, arg_2307) } else { arg_2302 = linked_2304.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2303, arg_2306, arg_2307) }; if linked_2300 == nil { tmp64 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp64 = linked_2300.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2299, arg_2302) } } else { tmp64 = and__1927000168__auto____8 }
//line :379:1
																															if jrt.J2g_Truth(tmp64) {

















																																var tmp65 any; var root_2308 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = n__0; var arg_2312 any = Lit_130; if linked_2309 == nil { tmp65 = ifn_2310.Invoke_O_O__O(arg_2311, arg_2312) } else { tmp65 = linked_2309.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2308, arg_2311, arg_2312) }; if jrt.J2g_Truth(tmp65) {
																																	var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp67 any = A_arbace_o2j_A_const_271; return tmp66.Invoke_O_O_O_O__O(tmp67, a__4, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_272, b__5), c__6) } else {
																																		var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp69 any = A_arbace_o2j_A_const_273; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp71 any = A_arbace_o2j_A_const_274; var tmp72 any; var root_2332 any = A_arbace_o2j_A_const_253.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, A_arbace_o2j_num_arg_A_fn_class); var ifn_2334 lang.IFn; if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = n__0; if linked_2333 == nil { tmp72 = ifn_2334.Invoke_O__O(arg_2335) } else { tmp72 = linked_2333.(*A_arbace_o2j_num_arg_A).Invoke_O_O__O(root_2332, arg_2335) }; return tmp68.Invoke_O_O_O_O__O(tmp69, a__4, tmp70.Invoke_O_O__O(tmp71, tmp72), b__5) } } else {
//line :379:1
																																			if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_131) {




















																																				var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp74 any = A_arbace_o2j_A_const_275; var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp76 any = A_arbace_o2j_A_const_276; var tmp77 any; var root_2342 any = A_arbace_o2j_A_const_253.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, A_arbace_o2j_num_arg_A_fn_class); var ifn_2344 lang.IFn; if linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; var arg_2345 any = n__0; if linked_2343 == nil { tmp77 = ifn_2344.Invoke_O__O(arg_2345) } else { tmp77 = linked_2343.(*A_arbace_o2j_num_arg_A).Invoke_O_O__O(root_2342, arg_2345) }; return tmp73.Invoke_O_O_O__O(tmp74, a__4, tmp75.Invoke_O_O__O(tmp76, tmp77)) } else {
//line :379:1
																																					if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_132) {





















																																						var tmp78 any; var root_2346 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = n__0; var arg_2350 any = Lit_130; if linked_2347 == nil { tmp78 = ifn_2348.Invoke_O_O__O(arg_2349, arg_2350) } else { tmp78 = linked_2347.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2346, arg_2349, arg_2350) }; if jrt.J2g_Truth(tmp78) {
																																							var tmp79 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp80 any = A_arbace_o2j_A_const_277; return tmp79.Invoke_O_O_O_O__O(tmp80, a__4, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_278, b__5), c__6) } else {
																																								var tmp81 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp82 any = A_arbace_o2j_A_const_279; var tmp83 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp84 any = A_arbace_o2j_A_const_280; var tmp85 any; var root_2370 any = A_arbace_o2j_A_const_253.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, A_arbace_o2j_num_arg_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = n__0; if linked_2371 == nil { tmp85 = ifn_2372.Invoke_O__O(arg_2373) } else { tmp85 = linked_2371.(*A_arbace_o2j_num_arg_A).Invoke_O_O__O(root_2370, arg_2373) }; return tmp81.Invoke_O_O_O_O__O(tmp82, a__4, tmp83.Invoke_O_O__O(tmp84, tmp85), b__5) } } else {
//line :379:1
																																									var tmp86 any; var and__1927000168__auto____8_2 any; var root_2374 any = A_arbace_o2j_A_const_232.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2376 lang.IFn

























																																									if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = n__0; var arg_2378 any = Lit_85; if linked_2375 == nil { and__1927000168__auto____8_2 = ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { and__1927000168__auto____8_2 = linked_2375.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) }; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_281.GetRawRoot__O()); var tmp88 any; var root_2635 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any; var root_2639 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = n__0; var arg_2643 any = A_arbace_o2j_A_const_334; if linked_2640 == nil { arg_2638 = ifn_2641.Invoke_O_O__O(arg_2642, arg_2643) } else { arg_2638 = linked_2640.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2639, arg_2642, arg_2643) }; if linked_2636 == nil { tmp88 = ifn_2637.Invoke_O__O(arg_2638) } else { tmp88 = linked_2636.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2635, arg_2638) }; tmp86 = tmp87.Invoke_O__O(tmp88) } else { tmp86 = and__1927000168__auto____8_2 }
//line :379:1
																																									if jrt.J2g_Truth(tmp86) { var k__8 any; var tmp89 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_281.GetRawRoot__O()); var tmp90 any; var root_2644 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2646 lang.IFn


























																																										if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any; var root_2648 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = n__0; var arg_2652 any = A_arbace_o2j_A_const_335; if linked_2649 == nil { arg_2647 = ifn_2650.Invoke_O_O__O(arg_2651, arg_2652) } else { arg_2647 = linked_2649.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2648, arg_2651, arg_2652) }; if linked_2645 == nil { tmp90 = ifn_2646.Invoke_O__O(arg_2647) } else { tmp90 = linked_2645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2644, arg_2647) }; k__8 = tmp89.Invoke_O__O(tmp90)
//line :379:1
																																										var op__9 any; var root_2379 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2381 lang.IFn


























																																										if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = n__0; var arg_2383 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_85)))).Ref(); if linked_2380 == nil { op__9 = ifn_2381.Invoke_O_O__O(arg_2382, arg_2383) } else { op__9 = linked_2380.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2379, arg_2382, arg_2383) }
//line :379:1
																																										var G__1641000325__10_ any = op__9



























																																										switch lang.Util_Hash_O__I_NoInit(G__1641000325__10_) { case -1019997817: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000325__10_, Lit_133) {
																																											return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_282, k__8, a__4) }
//line :407:1
																																										default:
																																										}
																																										var tmp91 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp92 any = A_arbace_o2j_A_const_283; var tmp93 any; var tmp94 any; var root_2399 any = A_arbace_o2j_A_const_284.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = b__5; if linked_2400 == nil { tmp94 = ifn_2401.Invoke_O__O(arg_2402) } else { tmp94 = linked_2400.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2399, arg_2402) }; if jrt.J2g_Truth(tmp94) { tmp93 = b__5 } else { tmp93 = nil }; return tmp91.Invoke_O_O_O_O_O__O(tmp92, k__8, op__9, a__4, tmp93) } else {
//line :379:1
																																											var tmp95 any; var root_2403 any = A_arbace_o2j_A_const_246.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_2405 lang.IFn






























																																											if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = A_arbace_o2j_A_const_285; var arg_2407 any = n__0; if linked_2404 == nil { tmp95 = ifn_2405.Invoke_O_O__O(arg_2406, arg_2407) } else { tmp95 = linked_2404.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_2403, arg_2406, arg_2407) }
//line :379:1
																																											if jrt.J2g_Truth(tmp95) {































																																												var tmp96 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp97 any = A_arbace_o2j_A_const_286; var tmp98 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_287.GetRawRoot__O()); var tmp99 any; var root_2414 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any; var root_2418 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2420 lang.IFn; if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any = n__0; var arg_2422 any = A_arbace_o2j_A_const_288; if linked_2419 == nil { arg_2417 = ifn_2420.Invoke_O_O__O(arg_2421, arg_2422) } else { arg_2417 = linked_2419.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2418, arg_2421, arg_2422) }; if linked_2415 == nil { tmp99 = ifn_2416.Invoke_O__O(arg_2417) } else { tmp99 = linked_2415.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2414, arg_2417) }; return tmp96.Invoke_O_O_O__O(tmp97, tmp98.Invoke_O__O(tmp99), lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_289, a__4)) } else {
//line :379:1
																																													if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_134) {

































																																														return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_290, a__4) } else {
//line :379:1
																																															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_291).Invoke_O__O(word__7)) {


































																																																var tmp100 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp101 any = A_arbace_o2j_A_const_292; var tmp102 any; var root_2439 any = A_arbace_o2j_A_const_293.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, A_arbace_o2j_array_kind_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = n__0; if linked_2440 == nil { tmp102 = ifn_2441.Invoke_O__O(arg_2442) } else { tmp102 = linked_2440.(*A_arbace_o2j_array_kind_A).Invoke_O_O__O(root_2439, arg_2442) }; var tmp103 any = tmp102; var tmp104 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp105 any = A_arbace_o2j_A_const_294; var tmp106 any = A_arbace_o2j_A_const_295; var tmp107 any; var root_2443 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2445 lang.IFn; if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = as__1; if linked_2444 == nil { tmp107 = ifn_2445.Invoke_O__O(arg_2446) } else { tmp107 = linked_2444.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2443, arg_2446) }; return tmp100.Invoke_O_O_O__O(tmp101, tmp103, tmp104.Invoke_O_O_O__O(tmp105, tmp106, tmp107)) } else {
//line :379:1
																																																	if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_135) {



































																																																		return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_296, a__4, b__5) } else {
//line :379:1
																																																			if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_136) {




































																																																				return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_297, a__4, b__5) } else {
//line :379:1
																																																					if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_137) {





































																																																						return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_o2j_A_const_298, a__4, b__5, c__6) } else {
//line :379:1
																																																							if lang.Util_Equiv_O_O__Z_NoInit(word__7, Lit_138) {






































																																																								return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_o2j_A_const_299, a__4, b__5, c__6) } else {
//line :379:1
																																																									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_300).Invoke_O__O(n__0)) {








































																																																										return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_301, a__4) } else {
//line :379:1
																																																											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_302).Invoke_O__O(n__0)) {









































																																																												return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_303, a__4, b__5) } else {
//line :379:1
																																																													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_304).Invoke_O__O(n__0)) {










































																																																														return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_305, a__4, b__5) } else {
//line :379:1
																																																															if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_139) {











































																																																																return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_o2j_A_const_306, a__4, b__5, c__6) } else {
//line :379:1
																																																																	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_140) {












































																																																																		return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_o2j_A_const_307, a__4, b__5, c__6) } else {
//line :379:1
																																																																			var tmp108 any; var root_2504 any = A_arbace_o2j_A_const_246.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_2506 lang.IFn













































																																																																			if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = A_arbace_o2j_A_const_308; var arg_2508 any = n__0; if linked_2505 == nil { tmp108 = ifn_2506.Invoke_O_O__O(arg_2507, arg_2508) } else { tmp108 = linked_2505.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_2504, arg_2507, arg_2508) }
//line :379:1
																																																																			if jrt.J2g_Truth(tmp108) {














































																																																																				var tmp109 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp110 any = A_arbace_o2j_A_const_309; var tmp111 any; var root_2516 any = A_arbace_o2j_A_const_89.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = A_arbace_o2j_A_const_310; var arg_2520 any = n__0; if linked_2517 == nil { tmp111 = ifn_2518.Invoke_O_O__O(arg_2519, arg_2520) } else { tmp111 = linked_2517.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2516, arg_2519, arg_2520) }; return tmp109.Invoke_O_O_O_O__O(tmp110, a__4, b__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp111)), 8)).Ref()) } else {
//line :379:1
																																																																					var tmp112 any; var root_2521 any = A_arbace_o2j_A_const_246.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_2523 lang.IFn















































																																																																					if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = A_arbace_o2j_A_const_311; var arg_2525 any = n__0; if linked_2522 == nil { tmp112 = ifn_2523.Invoke_O_O__O(arg_2524, arg_2525) } else { tmp112 = linked_2522.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_2521, arg_2524, arg_2525) }
//line :379:1
																																																																					if jrt.J2g_Truth(tmp112) {
















































																																																																						var tmp113 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp114 any = A_arbace_o2j_A_const_312; var tmp115 any; var root_2534 any = A_arbace_o2j_A_const_89.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = A_arbace_o2j_A_const_313; var arg_2538 any = n__0; if linked_2535 == nil { tmp115 = ifn_2536.Invoke_O_O__O(arg_2537, arg_2538) } else { tmp115 = linked_2535.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2534, arg_2537, arg_2538) }; return tmp113.Invoke_O_O_O_O_O__O(tmp114, a__4, b__5, c__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp115)), 8)).Ref()) } else {
//line :379:1
																																																																							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_314).Invoke_O__O(n__0)) { return a__4 } else { if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_141) {


















































																																																																								var tmp116 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp117 any = A_arbace_o2j_A_const_336; return tmp116.Invoke_O_O_O__O(tmp117, a__4, A_arbace_o2j_A_const_319.GetRawRoot__O()) } else {
//line :379:1
																																																																									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_315).Invoke_O__O(n__0)) {



















































																																																																										var tmp118 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp119 any = A_arbace_o2j_A_const_337; return tmp118.Invoke_O_O__O(tmp119, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_338, a__4)) } else {
//line :379:1
																																																																											var tmp120 any; var root_2539 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2541 lang.IFn




















































																																																																											if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = n__0; var arg_2543 any = Lit_142; if linked_2540 == nil { tmp120 = ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { tmp120 = linked_2540.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) }
//line :379:1
																																																																											if jrt.J2g_Truth(tmp120) {




















































																																																																												var tmp121 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp122 any = A_arbace_o2j_A_const_316; var tmp123 any; var root_2549 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any = n__0; var arg_2553 any = A_arbace_o2j_A_const_231; if linked_2550 == nil { tmp123 = ifn_2551.Invoke_O_O__O(arg_2552, arg_2553) } else { tmp123 = linked_2550.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2549, arg_2552, arg_2553) }; return tmp121.Invoke_O_O__O(tmp122, tmp123) } else {
//line :379:1
																																																																													if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_143) {





















































																																																																														return lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_317, a__4, A_arbace_o2j_A_const_87) } else {
//line :379:1
																																																																															if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_144) {






















































																																																																																var root_2560 any = A_arbace_o2j_A_const_318.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, A_arbace_o2j_external_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = Lit_145; var arg_2564 any = lang.Tuple_Create_O__IPersistentVector(A_arbace_o2j_A_const_319.GetRawRoot__O()); if linked_2561 == nil { return ifn_2562.Invoke_O_O__O(arg_2563, arg_2564) } else { return linked_2561.(*A_arbace_o2j_external_A).Invoke_O_O_O__O(root_2560, arg_2563, arg_2564) } } else {
//line :379:1
																																																																																	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_146) { return a__4 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_320.GetRawRoot__O()).Invoke_O__O(n__0)) {
























































																																																																																		var root_2565 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any = A_arbace_o2j_A_const_39.GetRawRoot__O(); var arg_2569 any; var root_2571 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = Lit_147; var arg_2575 any; var root_2576 any = A_arbace_o2j_A_const_53.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = lang.IFn_Cast(A_arbace_o2j_A_const_320.GetRawRoot__O()).Invoke_O__O(n__0); if linked_2577 == nil { arg_2575 = ifn_2578.Invoke_O__O(arg_2579) } else { arg_2575 = linked_2577.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2576, arg_2579) }; if linked_2572 == nil { arg_2569 = ifn_2573.Invoke_O_O__O(arg_2574, arg_2575) } else { arg_2569 = linked_2572.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2571, arg_2574, arg_2575) }; var arg_2570 any = as__1; if linked_2566 == nil { return ifn_2567.Invoke_O_O_O__O(arg_2568, arg_2569, arg_2570) } else { return linked_2566.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2565, arg_2568, arg_2569, arg_2570) } } else {
//line :379:1
																																																																																			var tmp124 any; var or__1927000174__auto____8 any; var root_2580 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2582 lang.IFn

























































																																																																																			if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = n__0; var arg_2584 any = Lit_148; if linked_2581 == nil { or__1927000174__auto____8 = ifn_2582.Invoke_O_O__O(arg_2583, arg_2584) } else { or__1927000174__auto____8 = linked_2581.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2580, arg_2583, arg_2584) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp124 = or__1927000174__auto____8 } else { var root_2585 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2587 lang.IFn; if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = n__0; var arg_2589 any = Lit_149; if linked_2586 == nil { tmp124 = ifn_2587.Invoke_O_O__O(arg_2588, arg_2589) } else { tmp124 = linked_2586.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2585, arg_2588, arg_2589) } }
//line :379:1
																																																																																			if jrt.J2g_Truth(tmp124) {

























































																																																																																				var root_2590 any = A_arbace_o2j_A_const_318.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, A_arbace_o2j_external_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any; var root_2595 any = A_arbace_o2j_A_const_321.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2595, A_arbace_o2j_bigarray_ext_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = n__0; var arg_2599 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(as__1)).Ref(); if linked_2596 == nil { arg_2593 = ifn_2597.Invoke_O_O__O(arg_2598, arg_2599) } else { if jrt.Long_InstanceOf(arg_2599) { arg_2593 = linked_2596.(*A_arbace_o2j_bigarray_ext_A).InvokeSpec_O_O_J_O__O(root_2595, arg_2598, jrt.NN(jrt.Long_Cast(arg_2599)).LongValue__J(), arg_2599) } else { arg_2593 = linked_2596.(*A_arbace_o2j_bigarray_ext_A).Invoke_O_O_O__O(root_2595, arg_2598, arg_2599) } }; var arg_2594 any = as__1; if linked_2591 == nil { return ifn_2592.Invoke_O_O__O(arg_2593, arg_2594) } else { return linked_2591.(*A_arbace_o2j_external_A).Invoke_O_O_O__O(root_2590, arg_2593, arg_2594) } } else {
//line :379:1
																																																																																					var tmp125 any; var root_2600 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2602 lang.IFn


























































																																																																																					if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = n__0; var arg_2604 any = Lit_150; if linked_2601 == nil { tmp125 = ifn_2602.Invoke_O_O__O(arg_2603, arg_2604) } else { tmp125 = linked_2601.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2600, arg_2603, arg_2604) }
//line :379:1
																																																																																					if jrt.J2g_Truth(tmp125) {


























































																																																																																						var root_2605 any = A_arbace_o2j_A_const_318.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, A_arbace_o2j_external_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = n__0; var arg_2609 any = as__1; if linked_2606 == nil { return ifn_2607.Invoke_O_O__O(arg_2608, arg_2609) } else { return linked_2606.(*A_arbace_o2j_external_A).Invoke_O_O_O__O(root_2605, arg_2608, arg_2609) } } else {
//line :379:1
																																																																																							if A_arbace_o2j_A_const_44 != nil {



























































																																																																																								var root_2653 any = A_arbace_o2j_A_const_233.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, A_arbace_o2j_note_missing_BANG__A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__0)).Ref(); if linked_2654 == nil { ifn_2655.Invoke_O__O(arg_2656) } else { linked_2654.(*A_arbace_o2j_note_missing_BANG__A).Invoke_O_O__O(root_2653, arg_2656) }; var tmp126 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp127 any = A_arbace_o2j_A_const_339; return tmp126.Invoke_O_O__O(tmp127, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_340, n__0)) } else {
//line :379:1
																																																																																									return nil } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }





























































func A_arbace_o2j_prim_node_A_New() *A_arbace_o2j_prim_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_prim_node_A{}; t.Ctor(); return t }
//line :441:1
func (t *A_arbace_o2j_prim_node_A) Ctor() {}
//line :441:1
func (t *A_arbace_o2j_prim_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000327__1, tail_QMARK___2 any) any { var vec__1641000328__4 any = p__1641000327__1; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000328__4, lang.RT_IntCast_J__I_NoInit(0), nil); var args__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000328__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_2662 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2664 lang.IFn; if

	linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = n__5; var arg_2666 any = Lit_116; if linked_2663 == nil { tmp1 = ifn_2664.Invoke_O_O__O(arg_2665, arg_2666) } else { tmp1 = linked_2663.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2662, arg_2665, arg_2666) }; if /*line :442:1*/ jrt.J2g_Truth(tmp1) { var g__7 any; var root_2667 any = A_arbace_o2j_A_const_341.GetRawRoot__O(); var linked_2668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2667, A_arbace_o2j_global_name_A_fn_class); var ifn_2669 lang.IFn

		if linked_2668 == nil { ifn_2669 = lang.IFn_Cast(root_2667) } else { ifn_2669 = nil }; var arg_2670 any; var root_2671 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any = n__5; var arg_2675 any = A_arbace_o2j_A_const_342; if linked_2672 == nil { arg_2670 = ifn_2673.Invoke_O_O__O(arg_2674, arg_2675) } else { arg_2670 = linked_2672.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2671, arg_2674, arg_2675) }; if linked_2668 == nil { g__7 = ifn_2669.Invoke_O__O(arg_2670) } else { g__7 = linked_2668.(*A_arbace_o2j_global_name_A).Invoke_O_O__O(root_2667, arg_2670) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_343.GetRawRoot__O()).Invoke_O__O(g__7)) { var root_2676 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any = Lit_117; var arg_2680 any = g__7; if linked_2677 == nil { return ifn_2678.Invoke_O_O__O(arg_2679, arg_2680) } else { return linked_2677.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2676, arg_2679, arg_2680) } } else { if A_arbace_o2j_A_const_44 != nil {
			var root_2681 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil); var tmp3 any; var root_2686 any = A_arbace_o2j_A_const_344.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, A_arbace_o2j_class_name_A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any = g__7; if linked_2687 == nil { tmp3 = ifn_2688.Invoke_O__O(arg_2689) } else { tmp3 = linked_2687.(*A_arbace_o2j_class_name_A).Invoke_O_O__O(root_2686, arg_2689) }; arg_2684 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_2685 any = Lit_118; if linked_2682 == nil { return ifn_2683.Invoke_O_O__O(arg_2684, arg_2685) } else { return linked_2682.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_2681, arg_2684, arg_2685) } } else {
//line :445:1
				return nil } } } else {
//line :442:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_345).Invoke_O__O(n__5)) {




						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp5 any = A_arbace_o2j_A_const_346; var tmp6 any; var root_2695 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, A_arbace_o2j_test_form_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = ctx__0; var arg_2699 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_348, n__5, args__6); if linked_2696 == nil { tmp6 = ifn_2697.Invoke_O_O__O(arg_2698, arg_2699) } else { tmp6 = linked_2696.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2695, arg_2698, arg_2699) }; return tmp4.Invoke_O_O__O(tmp5, tmp6) } else {
//line :442:1
							if A_arbace_o2j_A_const_44 != nil {





								var root_2700 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_2701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2700, A_arbace_o2j_with_args_A_fn_class); var ifn_2702 lang.IFn; if linked_2701 == nil { ifn_2702 = lang.IFn_Cast(root_2700) } else { ifn_2702 = nil }; var arg_2703 any = ctx__0; var arg_2704 any = args__6; var arg_2705 any; var fnbody__2712 any = A_arbace_o2j_prim_node_fn__1641000331_A_New_O(n__5); var tmp7 *jrt.Class; var fncls__2711 *jrt.Class = A_arbace_o2j_prim_node_fn__1641000331_A_fn_class; if fncls__2711 == nil { var fncls__2711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__2712); A_arbace_o2j_prim_node_fn__1641000331_A_fn_class = fncls__2711d; tmp7 = fncls__2711d } else { tmp7 = fncls__2711 }; arg_2705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2712, tmp7, nil); if linked_2701 == nil { return ifn_2702.Invoke_O_O_O__O(arg_2703, arg_2704, arg_2705) } else { return linked_2701.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_2700, arg_2703, arg_2704, arg_2705) } } else {
//line :442:1
									return nil } } } }





func A_arbace_o2j_prim_node_fn__1641000331_A_New_O(p0 any) *A_arbace_o2j_prim_node_fn__1641000331_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_prim_node_fn__1641000331_A{}; t.Ctor_O(p0); return t }
//line :448:1
func (t *A_arbace_o2j_prim_node_fn__1641000331_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :448:1
func (t *A_arbace_o2j_prim_node_fn__1641000331_A) Invoke_O_O__O(self, as__1 any) any { var root_2706 any = A_arbace_o2j_A_const_349.GetRawRoot__O(); var linked_2707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2706, A_arbace_o2j_prim_value_A_fn_class); var ifn_2708 lang.IFn; if linked_2707 == nil { ifn_2708 = lang.IFn_Cast(root_2706) } else { ifn_2708 = nil }; var arg_2709 any = t.F_n; var arg_2710 any = as__1; if linked_2707 == nil { return ifn_2708.Invoke_O_O__O(arg_2709, arg_2710) } else { return linked_2707.(*A_arbace_o2j_prim_value_A).Invoke_O_O_O__O(root_2706, arg_2709, arg_2710) } }



func A_arbace_o2j_test_form_A_New() *A_arbace_o2j_test_form_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_test_form_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_o2j_test_form_A) Ctor() {}
//line :452:1
func (t *A_arbace_o2j_test_form_A) Invoke_O_O_O__O(self, ctx__0, x__1 any) any { var h__3 any; var root_2713 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, A_arbace_o2j_hd_A_fn_class); var ifn_2715 lang.IFn; if


	linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = x__1; if linked_2714 == nil { h__3 = ifn_2715.Invoke_O__O(arg_2716) } else { h__3 = linked_2714.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_2713, arg_2716) }; var tmp1 any; var and__1927000168__auto____4 bool =
	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_350, h__3); if and__1927000168__auto____4 {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_351); var tmp3 any; var root_2802 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2804 lang.IFn; if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any; var root_2806 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, A_arbace_o2j_node_body_A_fn_class); var ifn_2808 lang.IFn; if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = x__1; if linked_2807 == nil { arg_2805 = ifn_2808.Invoke_O__O(arg_2809) } else { arg_2805 = linked_2807.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2806, arg_2809) }; if linked_2803 == nil { tmp3 = ifn_2804.Invoke_O__O(arg_2805) } else { tmp3 = linked_2803.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2802, arg_2805) }; tmp1 = tmp2.Invoke_O__O(tmp3) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if /*line :456:1*/ jrt.J2g_Truth(tmp1) { var vec__1641000334__4 any; var root_2717 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2719 lang.IFn

			if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any; var root_2721 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, A_arbace_o2j_node_body_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = x__1; if linked_2722 == nil { arg_2720 = ifn_2723.Invoke_O__O(arg_2724) } else { arg_2720 = linked_2722.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2721, arg_2724) }; if linked_2718 == nil { vec__1641000334__4 = ifn_2719.Invoke_O__O(arg_2720) } else { vec__1641000334__4 = linked_2718.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2717, arg_2720) }
//line :456:1
			var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000334__4, lang.RT_IntCast_J__I_NoInit(0), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000334__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_o2j_A_const_361; var tmp6 any; var root_2810 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, A_arbace_o2j_test_form_A_fn_class); var ifn_2812 lang.IFn

			if linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any = ctx__0; var arg_2814 any = a__5; if linked_2811 == nil { tmp6 = ifn_2812.Invoke_O_O__O(arg_2813, arg_2814) } else { tmp6 = linked_2811.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2810, arg_2813, arg_2814) }; var tmp7 any = tmp6; var tmp8 any; var root_2815 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, A_arbace_o2j_test_form_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = ctx__0; var arg_2819 any = b__6; if linked_2816 == nil { tmp8 = ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { tmp8 = linked_2816.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp7, tmp8) } else {
//line :456:1
				var tmp9 any; var and__1927000168__auto____4_2 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_352, h__3)


				if and__1927000168__auto____4_2 { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_353); var tmp11 any; var root_2820 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any; var root_2824 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, A_arbace_o2j_node_body_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = x__1; if linked_2825 == nil { arg_2823 = ifn_2826.Invoke_O__O(arg_2827) } else { arg_2823 = linked_2825.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2824, arg_2827) }; if linked_2821 == nil { tmp11 = ifn_2822.Invoke_O__O(arg_2823) } else { tmp11 = linked_2821.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2820, arg_2823) }; tmp9 = tmp10.Invoke_O__O(tmp11) } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }
//line :456:1
				if jrt.J2g_Truth(tmp9) { var vec__1641000337__4 any; var root_2725 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2727 lang.IFn



					if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any; var root_2729 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, A_arbace_o2j_node_body_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; var arg_2732 any = x__1; if linked_2730 == nil { arg_2728 = ifn_2731.Invoke_O__O(arg_2732) } else { arg_2728 = linked_2730.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2729, arg_2732) }; if linked_2726 == nil { vec__1641000337__4 = ifn_2727.Invoke_O__O(arg_2728) } else { vec__1641000337__4 = linked_2726.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2725, arg_2728) }
//line :456:1
					var a__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000337__4, lang.RT_IntCast_J__I_NoInit(0), nil); var b__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000337__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_o2j_A_const_362; var tmp14 any; var root_2828 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2828, A_arbace_o2j_test_form_A_fn_class); var ifn_2830 lang.IFn



					if linked_2829 == nil { ifn_2830 = lang.IFn_Cast(root_2828) } else { ifn_2830 = nil }; var arg_2831 any = ctx__0; var arg_2832 any = a__5_2; if linked_2829 == nil { tmp14 = ifn_2830.Invoke_O_O__O(arg_2831, arg_2832) } else { tmp14 = linked_2829.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2828, arg_2831, arg_2832) }; var tmp15 any = tmp14; var tmp16 any; var root_2833 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, A_arbace_o2j_test_form_A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any = ctx__0; var arg_2837 any = b__6_2; if linked_2834 == nil { tmp16 = ifn_2835.Invoke_O_O__O(arg_2836, arg_2837) } else { tmp16 = linked_2834.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2833, arg_2836, arg_2837) }; return tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16) } else {
//line :456:1
						var tmp17 bool; var and__1927000168__auto____4_3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_354, h__3)




						if and__1927000168__auto____4_3 { var tmp18 any; var root_2733 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2735 lang.IFn; if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any; var root_2737 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2737, A_arbace_o2j_node_body_A_fn_class); var ifn_2739 lang.IFn; if linked_2738 == nil { ifn_2739 = lang.IFn_Cast(root_2737) } else { ifn_2739 = nil }; var arg_2740 any = x__1; if linked_2738 == nil { arg_2736 = ifn_2739.Invoke_O__O(arg_2740) } else { arg_2736 = linked_2738.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2737, arg_2740) }; if linked_2734 == nil { tmp18 = ifn_2735.Invoke_O__O(arg_2736) } else { tmp18 = linked_2734.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2733, arg_2736) }; tmp17 = lang.Util_Equiv_O_O__Z_NoInit(Lit_121, tmp18) } else { tmp17 = and__1927000168__auto____4_3 }
//line :456:1
						if tmp17 {





							var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_o2j_A_const_363; var tmp21 any; var root_2838 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, A_arbace_o2j_test_form_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = ctx__0; var arg_2842 any; var root_2843 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any; var root_2847 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any; var root_2851 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, A_arbace_o2j_node_body_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = x__1; if linked_2852 == nil { arg_2850 = ifn_2853.Invoke_O__O(arg_2854) } else { arg_2850 = linked_2852.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2851, arg_2854) }; if linked_2848 == nil { arg_2846 = ifn_2849.Invoke_O__O(arg_2850) } else { arg_2846 = linked_2848.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2847, arg_2850) }; if linked_2844 == nil { arg_2842 = ifn_2845.Invoke_O__O(arg_2846) } else { arg_2842 = linked_2844.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2843, arg_2846) }; if linked_2839 == nil { tmp21 = ifn_2840.Invoke_O_O__O(arg_2841, arg_2842) } else { tmp21 = linked_2839.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_2838, arg_2841, arg_2842) }; return tmp19.Invoke_O_O__O(tmp20, tmp21) } else {
//line :456:1
								var tmp22 any; var and__1927000168__auto____4_4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_355, h__3)






								if and__1927000168__auto____4_4 { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()); var tmp24 any; var root_2855 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any; var root_2859 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, A_arbace_o2j_node_body_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = x__1; if linked_2860 == nil { arg_2858 = ifn_2861.Invoke_O__O(arg_2862) } else { arg_2858 = linked_2860.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2859, arg_2862) }; if linked_2856 == nil { tmp24 = ifn_2857.Invoke_O__O(arg_2858) } else { tmp24 = linked_2856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2855, arg_2858) }; tmp22 = tmp23.Invoke_O__O(tmp24) } else { tmp22 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_4).Ref() }
//line :456:1
								if jrt.J2g_Truth(tmp22) { var vec__1641000340__4 any; var root_2741 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2741, A_arbace_o2j_node_body_A_fn_class); var ifn_2743 lang.IFn







									if linked_2742 == nil { ifn_2743 = lang.IFn_Cast(root_2741) } else { ifn_2743 = nil }; var arg_2744 any = x__1; if linked_2742 == nil { vec__1641000340__4 = ifn_2743.Invoke_O__O(arg_2744) } else { vec__1641000340__4 = linked_2742.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2741, arg_2744) }
//line :456:1
									var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var args__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2745 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, A_arbace_o2j_with_args_A_fn_class); var ifn_2747 lang.IFn







									if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = ctx__0; var arg_2749 any = args__6; var arg_2750 any; var fnbody__2758 any = A_arbace_o2j_test_form_fn__1641000343_A_New_O(n__5); var tmp25 *jrt.Class; var fncls__2757 *jrt.Class = A_arbace_o2j_test_form_fn__1641000343_A_fn_class; if fncls__2757 == nil { var fncls__2757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, fnbody__2758); A_arbace_o2j_test_form_fn__1641000343_A_fn_class = fncls__2757d; tmp25 = fncls__2757d } else { tmp25 = fncls__2757 }; arg_2750 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2758, tmp25, nil); if linked_2746 == nil { return ifn_2747.Invoke_O_O_O__O(arg_2748, arg_2749, arg_2750) } else { return linked_2746.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_2745, arg_2748, arg_2749, arg_2750) } } else {
//line :456:1
										var tmp26 any; var and__1927000168__auto____4_5 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_356, h__3)








										if and__1927000168__auto____4_5 { var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_243.GetRawRoot__O()); var tmp28 any; var root_2863 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any; var root_2867 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, A_arbace_o2j_node_body_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = x__1; if linked_2868 == nil { arg_2866 = ifn_2869.Invoke_O__O(arg_2870) } else { arg_2866 = linked_2868.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2867, arg_2870) }; if linked_2864 == nil { tmp28 = ifn_2865.Invoke_O__O(arg_2866) } else { tmp28 = linked_2864.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2863, arg_2866) }; tmp26 = tmp27.Invoke_O__O(tmp28) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_5).Ref() }
//line :456:1
										if jrt.J2g_Truth(tmp26) { var vec__1641000345__4 any; var root_2759 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_2760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2759, A_arbace_o2j_node_body_A_fn_class); var ifn_2761 lang.IFn









											if linked_2760 == nil { ifn_2761 = lang.IFn_Cast(root_2759) } else { ifn_2761 = nil }; var arg_2762 any = x__1; if linked_2760 == nil { vec__1641000345__4 = ifn_2761.Invoke_O__O(arg_2762) } else { vec__1641000345__4 = linked_2760.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_2759, arg_2762) }
//line :456:1
											var n__5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000345__4, lang.RT_IntCast_J__I_NoInit(0), nil); var args__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000345__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2763 any = A_arbace_o2j_A_const_175.GetRawRoot__O(); var linked_2764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2763, A_arbace_o2j_with_args_A_fn_class); var ifn_2765 lang.IFn










											if linked_2764 == nil { ifn_2765 = lang.IFn_Cast(root_2763) } else { ifn_2765 = nil }; var arg_2766 any = ctx__0; var arg_2767 any = args__6_2; var arg_2768 any; var fnbody__2776 any = A_arbace_o2j_test_form_fn__1641000348_A_New_O(n__5_2); var tmp29 *jrt.Class; var fncls__2775 *jrt.Class = A_arbace_o2j_test_form_fn__1641000348_A_fn_class; if fncls__2775 == nil { var fncls__2775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, fnbody__2776); A_arbace_o2j_test_form_fn__1641000348_A_fn_class = fncls__2775d; tmp29 = fncls__2775d } else { tmp29 = fncls__2775 }; arg_2768 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2776, tmp29, nil); if linked_2764 == nil { return ifn_2765.Invoke_O_O_O__O(arg_2766, arg_2767, arg_2768) } else { return linked_2764.(*A_arbace_o2j_with_args_A).Invoke_O_O_O_O__O(root_2763, arg_2766, arg_2767, arg_2768) } } else {
//line :456:1
												var tmp30 any; var and__1927000168__auto____4_6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_o2j_A_const_358, h__3)











												if and__1927000168__auto____4_6 { var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_359); var tmp32 any; var root_2871 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any; var root_2875 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2875, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2877 lang.IFn; if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any = x__1; if linked_2876 == nil { arg_2874 = ifn_2877.Invoke_O__O(arg_2878) } else { arg_2874 = linked_2876.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2875, arg_2878) }; if linked_2872 == nil { tmp32 = ifn_2873.Invoke_O__O(arg_2874) } else { tmp32 = linked_2872.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2871, arg_2874) }; tmp30 = tmp31.Invoke_O__O(tmp32) } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_6).Ref() }
//line :456:1
												if jrt.J2g_Truth(tmp30) {











													var root_2777 any = A_arbace_o2j_A_const_91.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any; var tmp33 bool; var na_2781 any; var root_2782 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any; var root_2786 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2788 lang.IFn; if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = x__1; if linked_2787 == nil { arg_2785 = ifn_2788.Invoke_O__O(arg_2789) } else { arg_2785 = linked_2787.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2786, arg_2789) }; if linked_2783 == nil { na_2781 = ifn_2784.Invoke_O__O(arg_2785) } else { na_2781 = linked_2783.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2782, arg_2785) }; if jrt.Long_InstanceOf(na_2781) { var n0_2790 int64 = jrt.NN(jrt.Long_Cast(na_2781)).LongValue__J(); tmp33 = n0_2790 == 0 } else { if jrt.Double_InstanceOf(na_2781) { var n0_2790_2 float64 = jrt.NN(jrt.Double_Cast(na_2781)).DoubleValue__D(); tmp33 = n0_2790_2 == 0.0 } else { tmp33 = lang.Numbers_IsZero_O__Z_NoInit(na_2781) } }; arg_2780 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp33).Ref(); if linked_2778 == nil { return ifn_2779.Invoke_O__O(arg_2780) } else { return linked_2778.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2777, arg_2780) } } else {
//line :456:1
														if A_arbace_o2j_A_const_44 != nil {












															var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp35 any = A_arbace_o2j_A_const_360; var tmp36 any; var root_2796 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2796, A_arbace_o2j_expr_A_fn_class); var ifn_2798 lang.IFn; if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var arg_2799 any = ctx__0; var arg_2800 any = x__1; var arg_2801 any = jrt.Boolean_FALSE.Ref(); if linked_2797 == nil { tmp36 = ifn_2798.Invoke_O_O_O__O(arg_2799, arg_2800, arg_2801) } else { tmp36 = linked_2797.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2796, arg_2799, arg_2800, arg_2801) }; return tmp34.Invoke_O_O__O(tmp35, tmp36) } else {
//line :456:1
																return nil } } } } } } } }







func A_arbace_o2j_test_form_fn__1641000343_A_New_O(p0 any) *A_arbace_o2j_test_form_fn__1641000343_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_test_form_fn__1641000343_A{}; t.Ctor_O(p0); return t }
//line :464:1
func (t *A_arbace_o2j_test_form_fn__1641000343_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :464:1
func (t *A_arbace_o2j_test_form_fn__1641000343_A) Invoke_O_O__O(self, as__1 any) any { var root_2751 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2751, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2753 lang.IFn; if linked_2752 == nil { ifn_2753 = lang.IFn_Cast(root_2751) } else { ifn_2753 = nil }; var arg_2754 any = A_arbace_o2j_A_const_235.GetRawRoot__O(); var arg_2755 any = lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()).Invoke_O__O(t.F_n); var arg_2756 any = as__1; if linked_2752 == nil { return ifn_2753.Invoke_O_O_O__O(arg_2754, arg_2755, arg_2756) } else { return linked_2752.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2751, arg_2754, arg_2755, arg_2756) } }


func A_arbace_o2j_test_form_fn__1641000348_A_New_O(p0 any) *A_arbace_o2j_test_form_fn__1641000348_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_test_form_fn__1641000348_A{}; t.Ctor_O(p0); return t }
//line :467:1
func (t *A_arbace_o2j_test_form_fn__1641000348_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :467:1
func (t *A_arbace_o2j_test_form_fn__1641000348_A) Invoke_O_O__O(self, as__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_357; var tmp3 any; var root_2769 any = A_arbace_o2j_A_const_38.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2769, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any = A_arbace_o2j_A_const_235.GetRawRoot__O(); var arg_2773 any = lang.IFn_Cast(A_arbace_o2j_A_const_241.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_o2j_A_const_243.GetRawRoot__O()).Invoke_O__O(t.F_n)); var arg_2774 any = as__1; if linked_2770 == nil { tmp3 = ifn_2771.Invoke_O_O_O__O(arg_2772, arg_2773, arg_2774) } else { tmp3 = linked_2770.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2769, arg_2772, arg_2773, arg_2774) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }





func A_arbace_o2j_switch_node_A_New() *A_arbace_o2j_switch_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_switch_node_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_o2j_switch_node_A) Ctor() {}
//line :473:1
func (t *A_arbace_o2j_switch_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000351__1, tail_QMARK___2 any) any { var vec__1641000352__4 any = p__1641000351__1; var scrut__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(1), nil); var consts__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(2), nil); var nb__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(3), nil); var blocks__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(4), nil); var fail__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000352__4, lang.RT_IntCast_J__I_NoInit(5), nil); var s__11 any; var root_2879 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_2880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2879, A_arbace_o2j_fresh_A_fn_class); var ifn_2881 lang.IFn; if
														linked_2880 == nil { ifn_2881 = lang.IFn_Cast(root_2879) } else { ifn_2881 = nil }; var arg_2882 any = Lit_178; if linked_2880 == nil { s__11 = ifn_2881.Invoke_O__O(arg_2882) } else { s__11 = linked_2880.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_2879, arg_2882) }; var fl__12 any; var tmp1 any; var root_2883 any = /*line :473:1*/A_arbace_o2j_A_const_284.GetRawRoot__O(); var linked_2884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2883, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2885 lang.IFn; if

	linked_2884 == nil { ifn_2885 = lang.IFn_Cast(root_2883) } else { ifn_2885 = nil }; var arg_2886 any = fail__10; if linked_2884 == nil { tmp1 = ifn_2885.Invoke_O__O(arg_2886) } else { tmp1 = linked_2884.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2883, arg_2886) }; if jrt.J2g_Truth(tmp1) { var root_2887 any = A_arbace_o2j_A_const_198.GetRawRoot__O(); var linked_2888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2887, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2889 lang.IFn; if linked_2888 == nil { ifn_2889 = lang.IFn_Cast(root_2887) } else { ifn_2889 = nil }; var arg_2890 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_180, nil); var tmp3 any; var root_2891 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var tmp4 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_2894 any = tmp4.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_2895 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_2892 == nil { tmp3 = ifn_2893.Invoke_O_O__O(arg_2894, arg_2895) } else { tmp3 = linked_2892.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_2891, arg_2894, arg_2895) }; arg_2890 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if linked_2888 == nil { fl__12 = ifn_2889.Invoke_O__O(arg_2890) } else { fl__12 = linked_2888.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2887, arg_2890) } } else { fl__12 = nil }; var k__13 any; if
	jrt.J2g_Truth(fl__12) { var root_2896 any = A_arbace_o2j_A_const_198.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_181, nil); var tmp6 any; var root_2900 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2900, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2902 lang.IFn; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var tmp7 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_2903 any = tmp7.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_2904 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_2901 == nil { tmp6 = ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { tmp6 = linked_2901.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) }; arg_2899 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_2897 == nil { k__13 = ifn_2898.Invoke_O__O(arg_2899) } else { k__13 = linked_2897.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2896, arg_2899) } } else { k__13 = nil }; var dflt__14 any; if
	jrt.J2g_Truth(fl__12) { dflt__14 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_370, fl__12)) } else { dflt__14 = nil }; var cases__15 any; var fnbody__2919 any = /*line :473:1*/A_arbace_o2j_switch_node_cases__1641000355_A_New_O_O(ctx__0, tail_QMARK___2); var tmp8 *jrt.Class; var fncls__2918 *jrt.Class = A_arbace_o2j_switch_node_cases__1641000355_A_fn_class; if




	fncls__2918 == nil { var fncls__2918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, fnbody__2919); A_arbace_o2j_switch_node_cases__1641000355_A_fn_class = fncls__2918d; tmp8 = fncls__2918d } else { tmp8 = fncls__2918 }; cases__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2919, tmp8, nil); var tmp9 lang.IFn = /*line :473:1*/lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_o2j_A_const_364; var int_sw__16 any = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()).Invoke_O_O_O__O(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_365, s__11)), lang.IFn_Cast(cases__15).Invoke_O__O(consts__7), dflt__14); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_o2j_A_const_366; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp14 any = A_arbace_o2j_A_const_367; var blk_sw__17 any = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()).Invoke_O_O_O__O(tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_368, A_arbace_o2j_A_const_369, s__11))), lang.IFn_Cast(cases__15).Invoke_O__O(blocks__9), dflt__14); var body__18 any; var tmp15 bool; var na_2937 any = nb__8; if







	jrt.Long_InstanceOf(na_2937) { var n0_2938 int64 = jrt.NN(jrt.Long_Cast(na_2937)).LongValue__J(); tmp15 = n0_2938 == 0 } else { if jrt.Double_InstanceOf(na_2937) { var n0_2938_2 float64 = jrt.NN(jrt.Double_Cast(na_2937)).DoubleValue__D(); tmp15 = n0_2938_2 == 0.0 } else { tmp15 = lang.Numbers_IsZero_O__Z_NoInit(na_2937) } }; if tmp15 { body__18 = int_sw__16 } else { var tmp16 bool; var na_2939 any = nc__6
		if jrt.Long_InstanceOf(na_2939) { var n0_2940 int64 = jrt.NN(jrt.Long_Cast(na_2939)).LongValue__J(); tmp16 = n0_2940 == 0 } else { if jrt.Double_InstanceOf(na_2939) { var n0_2940_2 float64 = jrt.NN(jrt.Double_Cast(na_2939)).DoubleValue__D(); tmp16 = n0_2940_2 == 0.0 } else { tmp16 = lang.Numbers_IsZero_O__Z_NoInit(na_2939) } }
//line :481:1
		if tmp16 { body__18 = blk_sw__17 } else { if A_arbace_o2j_A_const_44 != nil {

			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_371; body__18 = tmp17.Invoke_O_O_O_O__O(tmp18, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_372, A_arbace_o2j_A_const_373, s__11), int_sw__16, blk_sw__17) } else {
//line :481:1
				body__18 = nil } } }; var sw__19 any; var tmp19 lang.IFn = /*line :473:1*/lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_o2j_A_const_374; var tmp21 any; var root_2941 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, A_arbace_o2j_expr_A_fn_class); var ifn_2943 lang.IFn; if










	linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any = ctx__0; var arg_2945 any = scrut__5; var arg_2946 any = jrt.Boolean_FALSE.Ref(); if linked_2942 == nil { tmp21 = ifn_2943.Invoke_O_O_O__O(arg_2944, arg_2945, arg_2946) } else { tmp21 = linked_2942.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2941, arg_2944, arg_2945, arg_2946) }; sw__19 = tmp19.Invoke_O_O_O__O(tmp20, lang.Tuple_Create_O_O__IPersistentVector(s__11, tmp21), body__18); if
	jrt.J2g_Truth(fl__12) {
		var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp23 any = A_arbace_o2j_A_const_375; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp25 any = A_arbace_o2j_A_const_376; var tmp26 any = tmp24.Invoke_O_O_O__O(tmp25, fl__12, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_377, k__13, sw__19)); var tmp27 any; var root_2947 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2947, A_arbace_o2j_expr_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = ctx__0; var arg_2951 any = fail__10; var arg_2952 any = tail_QMARK___2; if linked_2948 == nil { tmp27 = ifn_2949.Invoke_O_O_O__O(arg_2950, arg_2951, arg_2952) } else { tmp27 = linked_2948.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2947, arg_2950, arg_2951, arg_2952) }; return tmp22.Invoke_O_O_O_O__O(tmp23, k__13, tmp26, tmp27) } else {
//line :485:1
			return sw__19 } }
//line :478:1
func A_arbace_o2j_switch_node_cases__1641000355_A_New_O_O(p0, p1 any) *A_arbace_o2j_switch_node_cases__1641000355_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_switch_node_cases__1641000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :478:1
func (t *A_arbace_o2j_switch_node_cases__1641000355_A) Ctor_O_O(c__ctx, c__tail_QMARK_ any) { t.F_ctx = c__ctx; t.F_tail_QMARK_ = c__tail_QMARK_ }
//line :478:1
func (t *A_arbace_o2j_switch_node_cases__1641000355_A) Invoke_O_O__O(self, cs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__2917 any = A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A_New_O_O(t.F_ctx, t.F_tail_QMARK_); var tmp3 *jrt.Class; var fncls__2916 *jrt.Class = A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A_fn_class; if fncls__2916 == nil { var fncls__2916d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, fnbody__2917); A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A_fn_class = fncls__2916d; tmp3 = fncls__2916d } else { tmp3 = fncls__2916 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2917, tmp3, nil); return tmp1.Invoke_O_O__O(tmp2.Ref(), cs__1) }
//line :478:1
func A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A_New_O_O(p0, p1 any) *A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A{}; t.Ctor_O_O(p0, p1); return t }
//line :478:1
func (t *A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A) Ctor_O_O(c__ctx, c__tail_QMARK_ any) { t.F_ctx = c__ctx; t.F_tail_QMARK_ = c__tail_QMARK_ }
//line :478:1
func (t *A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A) Invoke_O_O__O(self, p__1641000356__1 any) any { var vec__1641000358__2 any = p__1641000356__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000358__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000358__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_2910 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2910, A_arbace_o2j_expr_A_fn_class); var ifn_2912 lang.IFn; if linked_2911 == nil { ifn_2912 = lang.IFn_Cast(root_2910) } else { ifn_2912 = nil }; var arg_2913 any = t.F_ctx; var arg_2914 any = e__4; var arg_2915 any = t.F_tail_QMARK_; if linked_2911 == nil { tmp1 = ifn_2912.Invoke_O_O_O__O(arg_2913, arg_2914, arg_2915) } else { tmp1 = linked_2911.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2910, arg_2913, arg_2914, arg_2915) }; return lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp1) }










func A_arbace_o2j_stringswitch_node_A_New() *A_arbace_o2j_stringswitch_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_stringswitch_node_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_o2j_stringswitch_node_A) Ctor() {}
//line :489:1
func (t *A_arbace_o2j_stringswitch_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000364__1, tail_QMARK___2 any) any { var vec__1641000365__4 any = p__1641000364__1; var scrut__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000365__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cases__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000365__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dflt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000365__4, lang.RT_IntCast_J__I_NoInit(2), nil); var s__8 any; var root_2953 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, A_arbace_o2j_fresh_A_fn_class); var ifn_2955 lang.IFn; if
															linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = Lit_178; if linked_2954 == nil { s__8 = ifn_2955.Invoke_O__O(arg_2956) } else { s__8 = linked_2954.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_2953, arg_2956) }; var tmp1 lang.IFn =
															lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_378; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp4 any = A_arbace_o2j_A_const_380; var tmp5 any; var root_2995 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, A_arbace_o2j_expr_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any = ctx__0; var arg_2999 any = scrut__5; var arg_3000 any = jrt.Boolean_FALSE.Ref(); if linked_2996 == nil { tmp5 = ifn_2997.Invoke_O_O_O__O(arg_2998, arg_2999, arg_3000) } else { tmp5 = linked_2996.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2995, arg_2998, arg_2999, arg_3000) }; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(s__8, tmp3.Invoke_O_O__O(tmp4, tmp5)); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_379, s__8); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__2979 any = A_arbace_o2j_stringswitch_node_fn__1641000369_A_New_O_O(ctx__0, tail_QMARK___2); var tmp11 *jrt.Class; var fncls__2978 *jrt.Class = A_arbace_o2j_stringswitch_node_fn__1641000369_A_fn_class; if

	fncls__2978 == nil { var fncls__2978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, fnbody__2979); A_arbace_o2j_stringswitch_node_fn__1641000369_A_fn_class = fncls__2978d; tmp11 = fncls__2978d } else { tmp11 = fncls__2978 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2979, tmp11, nil); var tmp12 any = /*line :491:1*/tmp9.Invoke_O_O__O(tmp10.Ref(), cases__6); var tmp13 lang.IPersistentVector; var tmp14 any; var root_2980 any = A_arbace_o2j_A_const_284.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2982 lang.IFn; if


	linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = dflt__7; if linked_2981 == nil { tmp14 = ifn_2982.Invoke_O__O(arg_2983) } else { tmp14 = linked_2981.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2980, arg_2983) }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var root_2984 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2984, A_arbace_o2j_expr_A_fn_class); var ifn_2986 lang.IFn; if linked_2985 == nil { ifn_2986 = lang.IFn_Cast(root_2984) } else { ifn_2986 = nil }; var arg_2987 any = ctx__0; var arg_2988 any = dflt__7; var arg_2989 any = tail_QMARK___2; if linked_2985 == nil { tmp15 = ifn_2986.Invoke_O_O_O__O(arg_2987, arg_2988, arg_2989) } else { tmp15 = linked_2985.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2984, arg_2987, arg_2988, arg_2989) }; tmp13 = lang.Tuple_Create_O__IPersistentVector(tmp15) } else { tmp13 = nil }; return /*line :491:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp12, tmp13)) }

func A_arbace_o2j_stringswitch_node_fn__1641000369_A_New_O_O(p0, p1 any) *A_arbace_o2j_stringswitch_node_fn__1641000369_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_stringswitch_node_fn__1641000369_A{}; t.Ctor_O_O(p0, p1); return t }
//line :493:1
func (t *A_arbace_o2j_stringswitch_node_fn__1641000369_A) Ctor_O_O(c__ctx, c__tail_QMARK_ any) { t.F_ctx = c__ctx; t.F_tail_QMARK_ = c__tail_QMARK_ }
//line :493:1
func (t *A_arbace_o2j_stringswitch_node_fn__1641000369_A) Invoke_O_O__O(self, p__1641000368__1 any) any { var vec__1641000370__2 any = p__1641000368__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000370__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000370__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_2968 any = A_arbace_o2j_A_const_100.GetRawRoot__O(); var linked_2969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2968, A_arbace_o2j_latin1_A_fn_class); var ifn_2970 lang.IFn; if linked_2969 == nil { ifn_2970 = lang.IFn_Cast(root_2968) } else { ifn_2970 = nil }; var arg_2971 any = k__3; if linked_2969 == nil { tmp1 = ifn_2970.Invoke_O__O(arg_2971) } else { tmp1 = linked_2969.(*A_arbace_o2j_latin1_A).Invoke_O_O__O(root_2968, arg_2971) }; var tmp2 any = tmp1; var tmp3 any; var root_2972 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2972, A_arbace_o2j_expr_A_fn_class); var ifn_2974 lang.IFn; if linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any = t.F_ctx; var arg_2976 any = e__4; var arg_2977 any = t.F_tail_QMARK_; if linked_2973 == nil { tmp3 = ifn_2974.Invoke_O_O_O__O(arg_2975, arg_2976, arg_2977) } else { tmp3 = linked_2973.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_2972, arg_2975, arg_2976, arg_2977) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


func A_arbace_o2j_staticcatch_node_A_New() *A_arbace_o2j_staticcatch_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticcatch_node_A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_o2j_staticcatch_node_A) Ctor() {}
//line :496:1
func (t *A_arbace_o2j_staticcatch_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000375__1, tail_QMARK___2 any) any { var vec__1641000376__4 any = p__1641000375__1; var body__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000376__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1641000379__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000376__4, lang.RT_IntCast_J__I_NoInit(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000379__6, lang.RT_IntCast_J__I_NoInit(0), nil); var vars__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000379__6, lang.RT_IntCast_J__I_NoInit(1), nil); var handler__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000376__4, lang.RT_IntCast_J__I_NoInit(2), nil); var k__10 any; var root_3001 any = A_arbace_o2j_A_const_198.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_3003 lang.IFn; if
															linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; var arg_3004 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp2 any; var root_3005 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3005, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3007 lang.IFn; if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var tmp3 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_3008 any = tmp3.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_3009 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_3006 == nil { tmp2 = ifn_3007.Invoke_O_O__O(arg_3008, arg_3009) } else { tmp2 = linked_3006.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_3005, arg_3008, arg_3009) }; arg_3004 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_3002 == nil { k__10 = ifn_3003.Invoke_O__O(arg_3004) } else { k__10 = linked_3002.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_3001, arg_3004) }; var e__11 any; var root_3010 any = /*line :496:1*/A_arbace_o2j_A_const_198.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_3012 lang.IFn; if

	linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_169, nil); var tmp5 any; var root_3014 any = A_arbace_o2j_A_const_79.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3014, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3016 lang.IFn; if linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var tmp6 *lang.Keyword = A_arbace_o2j_A_const_80; var arg_3017 any = tmp6.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); var arg_3018 any = A_arbace_o2j_A_const_82.GetRawRoot__O(); if linked_3015 == nil { tmp5 = ifn_3016.Invoke_O_O__O(arg_3017, arg_3018) } else { tmp5 = linked_3015.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_3014, arg_3017, arg_3018) }; arg_3013 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref(); if linked_3011 == nil { e__11 = ifn_3012.Invoke_O__O(arg_3013) } else { e__11 = linked_3011.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_3010, arg_3013) }; var syms__12 any; var root_3019 any = /*line :496:1*/A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_3020 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3019, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3021 lang.IFn; if



	linked_3020 == nil { ifn_3021 = lang.IFn_Cast(root_3019) } else { ifn_3021 = nil }; var arg_3022 any; var fnbody__3029 any = A_arbace_o2j_staticcatch_node_fn__1641000382_A_New(); var tmp7 *jrt.Class; var fncls__3028 *jrt.Class = A_arbace_o2j_staticcatch_node_fn__1641000382_A_fn_class; if fncls__3028 == nil { var fncls__3028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_o2j_staticcatch_node_fn__1641000382_A_fn_class = fncls__3028d; tmp7 = fncls__3028d } else { tmp7 = fncls__3028 }; arg_3022 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3029, tmp7, nil); var arg_3023 any = vars__8; if linked_3020 == nil { syms__12 = ifn_3021.Invoke_O_O__O(arg_3022, arg_3023) } else { syms__12 = linked_3020.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3019, arg_3022, arg_3023) }; var bctx__13 any; var root_3030 any = /*line :496:1*/A_arbace_o2j_A_const_226.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_3032 lang.IFn; if




	linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any = ctx__0; var arg_3034 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_199, n__7); var arg_3035 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_177, e__11, A_arbace_o2j_A_const_381, syms__12)); if linked_3031 == nil { bctx__13 = ifn_3032.Invoke_O_O_O__O(arg_3033, arg_3034, arg_3035) } else { bctx__13 = linked_3031.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_3030, arg_3033, arg_3034, arg_3035) }; var hctx__14 any; var root_3036 any = /*line :496:1*/A_arbace_o2j_A_const_85.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3038 lang.IFn; if





	linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any = ctx__0; var arg_3040 any = A_arbace_o2j_A_const_145; var arg_3041 any = A_arbace_o2j_A_const_195.GetRawRoot__O(); var arg_3042 any; var root_3043 any = A_arbace_o2j_A_const_382.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any; var root_3048 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3048, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var arg_3052 any = vars__8; if linked_3049 == nil { arg_3046 = ifn_3050.Invoke_O_O__O(arg_3051, arg_3052) } else { arg_3046 = linked_3049.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3048, arg_3051, arg_3052) }; var arg_3047 any = syms__12; if linked_3044 == nil { arg_3042 = ifn_3045.Invoke_O_O__O(arg_3046, arg_3047) } else { arg_3042 = linked_3044.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_3043, arg_3046, arg_3047) }; if linked_3037 == nil { hctx__14 = ifn_3038.Invoke_O_O_O_O__O(arg_3039, arg_3040, arg_3041, arg_3042) } else { hctx__14 = linked_3037.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3036, arg_3039, arg_3040, arg_3041, arg_3042) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_o2j_A_const_383; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_o2j_A_const_384; var tmp12 any; var root_3053 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3055 lang.IFn; if
	linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp14 *lang.Compiler_AOTFn; var fnbody__3068 any = A_arbace_o2j_staticcatch_node_fn__1641000384_A_New(); var tmp15 *jrt.Class; var fncls__3067 *jrt.Class = A_arbace_o2j_staticcatch_node_fn__1641000384_A_fn_class; if fncls__3067 == nil { var fncls__3067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_o2j_staticcatch_node_fn__1641000384_A_fn_class = fncls__3067d; tmp15 = fncls__3067d } else { tmp15 = fncls__3067 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3068, tmp15, nil); arg_3056 = tmp13.Invoke_O_O__O(tmp14.Ref(), syms__12); if linked_3054 == nil { tmp12 = ifn_3055.Invoke_O__O(arg_3056) } else { tmp12 = linked_3054.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3053, arg_3056) }; var tmp16 any = tmp12; var tmp17 lang.IFn = /*line :503:1*/lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_386; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_o2j_A_const_387; var tmp21 any; var root_3075 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, A_arbace_o2j_expr_A_fn_class); var ifn_3077 lang.IFn; if

	linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any = bctx__13; var arg_3079 any = body__5; var arg_3080 any = tail_QMARK___2; if linked_3076 == nil { tmp21 = ifn_3077.Invoke_O_O_O__O(arg_3078, arg_3079, arg_3080) } else { tmp21 = linked_3076.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3075, arg_3078, arg_3079, arg_3080) }; var tmp22 any = /*line :503:1*/tmp17.Invoke_O_O_O__O(tmp18, e__11, tmp19.Invoke_O_O_O__O(tmp20, k__10, tmp21)); var tmp23 any; var root_3069 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3069, A_arbace_o2j_expr_A_fn_class); var ifn_3071 lang.IFn; if


	linked_3070 == nil { ifn_3071 = lang.IFn_Cast(root_3069) } else { ifn_3071 = nil }; var arg_3072 any = hctx__14; var arg_3073 any = handler__9; var arg_3074 any = tail_QMARK___2; if linked_3070 == nil { tmp23 = ifn_3071.Invoke_O_O_O__O(arg_3072, arg_3073, arg_3074) } else { tmp23 = linked_3070.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3069, arg_3072, arg_3073, arg_3074) }; return /*line :503:1*/ tmp8.Invoke_O_O_O__O(tmp9, k__10, tmp10.Invoke_O_O_O_O__O(tmp11, tmp16, tmp22, tmp23)) }
//line :500:1
func A_arbace_o2j_staticcatch_node_fn__1641000382_A_New() *A_arbace_o2j_staticcatch_node_fn__1641000382_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticcatch_node_fn__1641000382_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_o2j_staticcatch_node_fn__1641000382_A) Ctor() {}
//line :500:1
func (t *A_arbace_o2j_staticcatch_node_fn__1641000382_A) Invoke_O_O__O(self, ___1 any) any { var root_3024 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, A_arbace_o2j_fresh_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = Lit_172; if linked_3025 == nil { return ifn_3026.Invoke_O__O(arg_3027) } else { return linked_3025.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3024, arg_3027) } }



func A_arbace_o2j_staticcatch_node_fn__1641000384_A_New() *A_arbace_o2j_staticcatch_node_fn__1641000384_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticcatch_node_fn__1641000384_A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_o2j_staticcatch_node_fn__1641000384_A) Ctor() {}
//line :504:1
func (t *A_arbace_o2j_staticcatch_node_fn__1641000384_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 any; var root_3062 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3064 lang.IFn; if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any = s__1; var arg_3066 any = A_arbace_o2j_A_const_385; if linked_3063 == nil { tmp1 = ifn_3064.Invoke_O_O__O(arg_3065, arg_3066) } else { tmp1 = linked_3063.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3062, arg_3065, arg_3066) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, nil) }



func A_arbace_o2j_staticraise_node_A_New() *A_arbace_o2j_staticraise_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticraise_node_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_o2j_staticraise_node_A) Ctor() {}
//line :508:1
func (t *A_arbace_o2j_staticraise_node_A) Invoke_O_O_O__O(self, ctx__0, p__1641000387__1 any) any { var vec__1641000388__3 any = p__1641000387__1; var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000388__3, lang.RT_IntCast_J__I_NoInit(0), nil); var args__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000388__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1641000391__6 any; var or__1927000174__auto____6 any; var root_3081 any = A_arbace_o2j_A_const_388.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3083 lang.IFn; if
													linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = ctx__0; var arg_3085 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_199, n__4); if linked_3082 == nil { or__1927000174__auto____6 = ifn_3083.Invoke_O_O__O(arg_3084, arg_3085) } else { or__1927000174__auto____6 = linked_3082.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3081, arg_3084, arg_3085) }; if jrt.J2g_Truth(or__1927000174__auto____6) { map__1641000391__6 = or__1927000174__auto____6 } else { var tmp1 any; var root_3086 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_174), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil)).Ref(); var arg_3090 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3087 == nil { tmp1 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { tmp1 = linked_3087.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; var map__1641000391__7 any; if lang.ISeq_InstanceOf(map__1641000391__6) { var tmp2 any; var root_3091 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = map__1641000391__6; if linked_3092 == nil { tmp2 = ifn_3093.Invoke_O__O(arg_3094) } else { tmp2 = linked_3092.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3091, arg_3094) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_3095 any = A_arbace_o2j_A_const_389.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3097 lang.IFn; if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any = map__1641000391__6; if linked_3096 == nil { tmp3 = ifn_3097.Invoke_O__O(arg_3098) } else { tmp3 = linked_3096.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3095, arg_3098) }; map__1641000391__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_3099 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = map__1641000391__6; if linked_3100 == nil { tmp4 = ifn_3101.Invoke_O__O(arg_3102) } else { tmp4 = linked_3100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3099, arg_3102) }; if jrt.J2g_Truth(tmp4) { var root_3103 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any = map__1641000391__6; if linked_3104 == nil { map__1641000391__7 = ifn_3105.Invoke_O__O(arg_3106) } else { map__1641000391__7 = linked_3104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3103, arg_3106) } } else { map__1641000391__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1641000391__7 = map__1641000391__6 }; var label__8 any = /*line :508:1*/lang.RT_Get_O_O__O_NoInit(map__1641000391__7, A_arbace_o2j_A_const_177); var vars__9 any = lang.RT_Get_O_O__O_NoInit(map__1641000391__7, A_arbace_o2j_A_const_381); var tmp5 any; var root_3107 any = A_arbace_o2j_A_const_390.GetRawRoot__O(); var linked_3108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3107, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3109 lang.IFn; if

	linked_3108 == nil { ifn_3109 = lang.IFn_Cast(root_3107) } else { ifn_3109 = nil }; var arg_3110 any = args__5; if linked_3108 == nil { tmp5 = ifn_3109.Invoke_O__O(arg_3110) } else { tmp5 = linked_3108.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3107, arg_3110) }; if jrt.J2g_Truth(tmp5) {
		return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_391, label__8) } else {
//line :510:1
			var ts__10 any; var root_3111 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3113 lang.IFn

			if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any; var root_3115 any = A_arbace_o2j_A_const_71.GetRawRoot__O(); var linked_3116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3115, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_3117 lang.IFn; if linked_3116 == nil { ifn_3117 = lang.IFn_Cast(root_3115) } else { ifn_3117 = nil }; var arg_3118 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__5)).Ref(); var arg_3119 any; var fnbody__3125 any = A_arbace_o2j_staticraise_node_fn__1641000393_A_New(); var tmp6 *jrt.Class; var fncls__3124 *jrt.Class = A_arbace_o2j_staticraise_node_fn__1641000393_A_fn_class; if fncls__3124 == nil { var fncls__3124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_o2j_staticraise_node_fn__1641000393_A_fn_class = fncls__3124d; tmp6 = fncls__3124d } else { tmp6 = fncls__3124 }; arg_3119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3125, tmp6, nil); if linked_3116 == nil { arg_3114 = ifn_3117.Invoke_O_O__O(arg_3118, arg_3119) } else { arg_3114 = linked_3116.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_3115, arg_3118, arg_3119) }; if linked_3112 == nil { ts__10 = ifn_3113.Invoke_O__O(arg_3114) } else { ts__10 = linked_3112.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3111, arg_3114)
			}
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_o2j_A_const_392; var tmp9 any; var root_3126 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3126, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3128 lang.IFn; if linked_3127 == nil { ifn_3128 = lang.IFn_Cast(root_3126) } else { ifn_3128 = nil }; var arg_3129 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp11 *lang.Compiler_AOTFn; var fnbody__3143 any = A_arbace_o2j_staticraise_node_fn__1641000395_A_New_O(ctx__0); var tmp12 *jrt.Class; var fncls__3142 *jrt.Class = A_arbace_o2j_staticraise_node_fn__1641000395_A_fn_class; if fncls__3142 == nil { var fncls__3142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, fnbody__3143); A_arbace_o2j_staticraise_node_fn__1641000395_A_fn_class = fncls__3142d; tmp12 = fncls__3142d } else { tmp12 = fncls__3142 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3143, tmp12, nil); var tmp13 any = tmp11.Ref(); var tmp14 any; var root_3144 any = A_arbace_o2j_A_const_157.GetRawRoot__O(); var linked_3145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3144, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_3146 lang.IFn; if linked_3145 == nil { ifn_3146 = lang.IFn_Cast(root_3144) } else { ifn_3146 = nil }; var arg_3147 any = ts__10; if linked_3145 == nil { tmp14 = ifn_3146.Invoke_O__O(arg_3147) } else { tmp14 = linked_3145.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_3144, arg_3147) }; var tmp15 any = tmp14; var tmp16 any; var root_3148 any = A_arbace_o2j_A_const_157.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_3150 lang.IFn; if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any = args__5; if linked_3149 == nil { tmp16 = ifn_3150.Invoke_O__O(arg_3151) } else { tmp16 = linked_3149.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_3148, arg_3151) }; arg_3129 = tmp10.Invoke_O_O_O__O(tmp13, tmp15, tmp16); if linked_3127 == nil { tmp9 = ifn_3128.Invoke_O__O(arg_3129) } else { tmp9 = linked_3127.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3126, arg_3129) }; var tmp17 any = tmp9; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j_A_const_393); var tmp20 any; var root_3158 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3158, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3160 lang.IFn
			if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var arg_3161 any; var fnbody__3165 any = A_arbace_o2j_staticraise_node_fn__1641000397_A_New(); var tmp21 *jrt.Class; var fncls__3164 *jrt.Class = A_arbace_o2j_staticraise_node_fn__1641000397_A_fn_class; if fncls__3164 == nil { var fncls__3164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_o2j_staticraise_node_fn__1641000397_A_fn_class = fncls__3164d; tmp21 = fncls__3164d } else { tmp21 = fncls__3164 }; arg_3161 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3165, tmp21, nil); var arg_3162 any = vars__9; var arg_3163 any = ts__10; if linked_3159 == nil { tmp20 = ifn_3160.Invoke_O_O_O__O(arg_3161, arg_3162, arg_3163) } else { tmp20 = linked_3159.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_3158, arg_3161, arg_3162, arg_3163) }
//line :514:1
			return tmp7.Invoke_O_O_O__O(tmp8, tmp17, tmp18.Invoke_O_O_O__O(tmp19, tmp20, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_395, label__8)))) } }
//line :512:1
func A_arbace_o2j_staticraise_node_fn__1641000393_A_New() *A_arbace_o2j_staticraise_node_fn__1641000393_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticraise_node_fn__1641000393_A{}; t.Ctor(); return t }
//line :512:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000393_A) Ctor() {}
//line :512:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000393_A) Invoke_O__O(self any) any { var root_3120 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3120, A_arbace_o2j_fresh_A_fn_class); var ifn_3122 lang.IFn; if linked_3121 == nil { ifn_3122 = lang.IFn_Cast(root_3120) } else { ifn_3122 = nil }; var arg_3123 any = Lit_80; if linked_3121 == nil { return ifn_3122.Invoke_O__O(arg_3123) } else { return linked_3121.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3120, arg_3123) } }

func A_arbace_o2j_staticraise_node_fn__1641000395_A_New_O(p0 any) *A_arbace_o2j_staticraise_node_fn__1641000395_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticraise_node_fn__1641000395_A{}; t.Ctor_O(p0); return t }
//line :514:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000395_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :514:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000395_A) Invoke_O_O_O__O(self, t__1, x__2 any) any { var tmp1 any; var root_3136 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, A_arbace_o2j_expr_A_fn_class); var ifn_3138 lang.IFn; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = t.F_ctx; var arg_3140 any = x__2; var arg_3141 any = jrt.Boolean_FALSE.Ref(); if linked_3137 == nil { tmp1 = ifn_3138.Invoke_O_O_O__O(arg_3139, arg_3140, arg_3141) } else { tmp1 = linked_3137.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3136, arg_3139, arg_3140, arg_3141) }; return lang.Tuple_Create_O_O__IPersistentVector(t__1, tmp1) }
func A_arbace_o2j_staticraise_node_fn__1641000397_A_New() *A_arbace_o2j_staticraise_node_fn__1641000397_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_staticraise_node_fn__1641000397_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000397_A) Ctor() {}
//line :515:1
func (t *A_arbace_o2j_staticraise_node_fn__1641000397_A) Invoke_O_O_O__O(self, v__1, t__2 any) any { return lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_394, v__1, t__2) }

func A_arbace_o2j_trywith_node_A_New() *A_arbace_o2j_trywith_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_trywith_node_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_o2j_trywith_node_A) Ctor() {}
//line :517:1
func (t *A_arbace_o2j_trywith_node_A) Invoke_O_O_O_O__O(self, ctx__0, p__1641000400__1, tail_QMARK___2 any) any { var vec__1641000401__4 any = p__1641000400__1; var body__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000401__4, lang.RT_IntCast_J__I_NoInit(0), nil); var id__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000401__4, lang.RT_IntCast_J__I_NoInit(1), nil); var handler__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000401__4, lang.RT_IntCast_J__I_NoInit(2), nil); var e__8 any; var root_3166 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3166, A_arbace_o2j_fresh_A_fn_class); var ifn_3168 lang.IFn; if
														linked_3167 == nil { ifn_3168 = lang.IFn_Cast(root_3166) } else { ifn_3168 = nil }; var arg_3169 any = Lit_199; if linked_3167 == nil { e__8 = ifn_3168.Invoke_O__O(arg_3169) } else { e__8 = linked_3167.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3166, arg_3169) }; var s__9 any; var root_3170 any = /*line :517:1*/A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_3171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3170, A_arbace_o2j_munge_id_A_fn_class); var ifn_3172 lang.IFn; if
														linked_3171 == nil { ifn_3172 = lang.IFn_Cast(root_3170) } else { ifn_3172 = nil }; var arg_3173 any = id__6; if linked_3171 == nil { s__9 = ifn_3172.Invoke_O__O(arg_3173) } else { s__9 = linked_3171.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_3170, arg_3173) }; var tmp1 lang.IFn =
														lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_396; var tmp3 any; var root_3174 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3174, A_arbace_o2j_expr_A_fn_class); var ifn_3176 lang.IFn; if linked_3175 == nil { ifn_3176 = lang.IFn_Cast(root_3174) } else { ifn_3176 = nil }; var arg_3177 any = ctx__0; var arg_3178 any = body__5; var arg_3179 any = jrt.Boolean_FALSE.Ref(); if linked_3175 == nil { tmp3 = ifn_3176.Invoke_O_O_O__O(arg_3177, arg_3178, arg_3179) } else { tmp3 = linked_3175.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3174, arg_3177, arg_3178, arg_3179) }; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_o2j_A_const_397; var tmp7 any = A_arbace_o2j_A_const_398; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_o2j_A_const_399; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(s__9, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_400, e__8)); var tmp11 any; var root_3180 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3180, A_arbace_o2j_expr_A_fn_class); var ifn_3182 lang.IFn; if

	linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any; var root_3186 any = A_arbace_o2j_A_const_226.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any = ctx__0; var arg_3190 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_145, id__6); var arg_3191 any = s__9; if linked_3187 == nil { arg_3183 = ifn_3188.Invoke_O_O_O__O(arg_3189, arg_3190, arg_3191) } else { arg_3183 = linked_3187.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_3186, arg_3189, arg_3190, arg_3191) }; var arg_3184 any = handler__7; var arg_3185 any = tail_QMARK___2; if linked_3181 == nil { tmp11 = ifn_3182.Invoke_O_O_O__O(arg_3183, arg_3184, arg_3185) } else { tmp11 = linked_3181.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3180, arg_3183, arg_3184, arg_3185) }; return /*line :519:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, e__8, tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11))) }



func A_arbace_o2j_for_node_A_New() *A_arbace_o2j_for_node_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_for_node_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_o2j_for_node_A) Ctor() {}
//line :523:1
func (t *A_arbace_o2j_for_node_A) Invoke_O_O_O__O(self, ctx__0, p__1641000405__1 any) any { var vec__1641000406__3 any = p__1641000405__1; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000406__3, lang.RT_IntCast_J__I_NoInit(0), nil); var lo__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000406__3, lang.RT_IntCast_J__I_NoInit(1), nil); var hi__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000406__3, lang.RT_IntCast_J__I_NoInit(2), nil); var dir__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000406__3, lang.RT_IntCast_J__I_NoInit(3), nil); var body__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000406__3, lang.RT_IntCast_J__I_NoInit(4), nil); var l__9 any; var root_3197 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, A_arbace_o2j_fresh_A_fn_class); var ifn_3199 lang.IFn; if
												linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = Lit_82; if linked_3198 == nil { l__9 = ifn_3199.Invoke_O__O(arg_3200) } else { l__9 = linked_3198.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3197, arg_3200) }; var h__10 any; var root_3201 any = /*line :523:1*/A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, A_arbace_o2j_fresh_A_fn_class); var ifn_3203 lang.IFn; if
												linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any = Lit_83; if linked_3202 == nil { h__10 = ifn_3203.Invoke_O__O(arg_3204) } else { h__10 = linked_3202.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3201, arg_3204) }; var i__11 any; var root_3205 any = /*line :523:1*/A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3205, A_arbace_o2j_fresh_A_fn_class); var ifn_3207 lang.IFn; if
												linked_3206 == nil { ifn_3207 = lang.IFn_Cast(root_3205) } else { ifn_3207 = nil }; var arg_3208 any = Lit_84; if linked_3206 == nil { i__11 = ifn_3207.Invoke_O__O(arg_3208) } else { i__11 = linked_3206.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3205, arg_3208) }; var s__12 any; var root_3209 any = /*line :523:1*/A_arbace_o2j_A_const_194.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, A_arbace_o2j_munge_id_A_fn_class); var ifn_3211 lang.IFn; if
												linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any = id__4; if linked_3210 == nil { s__12 = ifn_3211.Invoke_O__O(arg_3212) } else { s__12 = linked_3210.(*A_arbace_o2j_munge_id_A).Invoke_O_O__O(root_3209, arg_3212) }; var up__13 bool = /*line :523:1*/lang.Util_Equiv_O_O__Z_NoInit(dir__7, A_arbace_o2j_A_const_401); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_o2j_A_const_402; var tmp3 any; var root_3213 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, A_arbace_o2j_expr_A_fn_class); var ifn_3215 lang.IFn; if


	linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = ctx__0; var arg_3217 any = lo__5; var arg_3218 any = jrt.Boolean_FALSE.Ref(); if linked_3214 == nil { tmp3 = ifn_3215.Invoke_O_O_O__O(arg_3216, arg_3217, arg_3218) } else { tmp3 = linked_3214.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3213, arg_3216, arg_3217, arg_3218) }; var tmp4 any = tmp3; var tmp5 any; var root_3219 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, A_arbace_o2j_expr_A_fn_class); var ifn_3221 lang.IFn; if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = ctx__0; var arg_3223 any = hi__6; var arg_3224 any = jrt.Boolean_FALSE.Ref(); if linked_3220 == nil { tmp5 = ifn_3221.Invoke_O_O_O__O(arg_3222, arg_3223, arg_3224) } else { tmp5 = linked_3220.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3219, arg_3222, arg_3223, arg_3224) }; var tmp6 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(l__9, tmp4, h__10, tmp5); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_o2j_A_const_403; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp10 any; if up__13 {
		tmp10 = A_arbace_o2j_A_const_404 } else { tmp10 = A_arbace_o2j_A_const_405 }; var tmp11 any = /*line :526:1*/tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_406, l__9), lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_407, h__10)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_o2j_A_const_408; var tmp14 any; var root_3235 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3235, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3237 lang.IFn; if

	linked_3236 == nil { ifn_3237 = lang.IFn_Cast(root_3235) } else { ifn_3237 = nil }; var arg_3238 any = i__11; var arg_3239 any = A_arbace_o2j_A_const_409; if linked_3236 == nil { tmp14 = ifn_3237.Invoke_O_O__O(arg_3238, arg_3239) } else { tmp14 = linked_3236.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3235, arg_3238, arg_3239) }; var tmp15 any = /*line :526:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp14, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_410, l__9)); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp17 any = A_arbace_o2j_A_const_411; var tmp18 any = lang.Tuple_Create_O_O__IPersistentVector(s__12, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_412, i__11)); var tmp19 any; var root_3245 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, A_arbace_o2j_expr_A_fn_class); var ifn_3247 lang.IFn; if


	linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any; var root_3251 any = A_arbace_o2j_A_const_226.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_3253 lang.IFn; if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any = ctx__0; var arg_3255 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_o2j_A_const_145, id__4); var arg_3256 any = s__12; if linked_3252 == nil { arg_3248 = ifn_3253.Invoke_O_O_O__O(arg_3254, arg_3255, arg_3256) } else { arg_3248 = linked_3252.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_3251, arg_3254, arg_3255, arg_3256) }; var arg_3249 any = body__8; var arg_3250 any = jrt.Boolean_FALSE.Ref(); if linked_3246 == nil { tmp19 = ifn_3247.Invoke_O_O_O__O(arg_3248, arg_3249, arg_3250) } else { tmp19 = linked_3246.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3245, arg_3248, arg_3249, arg_3250) }; var tmp20 any = /*line :526:1*/tmp16.Invoke_O_O_O__O(tmp17, tmp18, tmp19); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp22 any = A_arbace_o2j_A_const_413; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp24 any = A_arbace_o2j_A_const_414; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_415; var tmp27 any = tmp23.Invoke_O_O__O(tmp24, tmp25.Invoke_O_O_O__O(tmp26, i__11, lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_416, h__10))); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp29 any = A_arbace_o2j_A_const_417; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp31 any; if up__13 {




		tmp31 = A_arbace_o2j_A_const_418 } else { tmp31 = A_arbace_o2j_A_const_419 }; return /*line :526:1*/ tmp1.Invoke_O_O_O_O__O(tmp2, tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp11, tmp12.Invoke_O_O_O_O__O(tmp13, tmp15, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O__O(tmp31, i__11))))), A_arbace_o2j_A_const_319.GetRawRoot__O()) }







func A_arbace_o2j_flatten_seq_A_New() *A_arbace_o2j_flatten_seq_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_flatten_seq_A{}; t.Ctor(); return t }
//line :534:1
func (t *A_arbace_o2j_flatten_seq_A) Ctor() {}
//line :534:1
func (t *A_arbace_o2j_flatten_seq_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any = A_arbace_o2j_A_const_420; var tmp2 any; var root_3262 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, A_arbace_o2j_hd_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = x__0; if linked_3263 == nil { tmp2 = ifn_3264.Invoke_O__O(arg_3265) } else { tmp2 = linked_3263.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_3262, arg_3265) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp4 any = A_arbace_o2j_A_const_421.GetRawRoot__O(); var tmp5 any; var root_3271 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_3272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3271, A_arbace_o2j_node_body_A_fn_class); var ifn_3273 lang.IFn; if linked_3272 == nil { ifn_3273 = lang.IFn_Cast(root_3271) } else { ifn_3273 = nil }; var arg_3274 any = x__0; if linked_3272 == nil { tmp5 = ifn_3273.Invoke_O__O(arg_3274) } else { tmp5 = linked_3272.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_3271, arg_3274) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else { return lang.Tuple_Create_O__IPersistentVector(x__0)
	} }
func A_arbace_o2j_expr_A_New() *A_arbace_o2j_expr_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_expr_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_o2j_expr_A) Ctor() {}
//line :537:1
func (t *A_arbace_o2j_expr_A) Invoke_O_O_O_O__O(self, ctx__0, x__1, tail_QMARK___2 any) any { var h__4 any; var root_3275 any = A_arbace_o2j_A_const_52.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, A_arbace_o2j_hd_A_fn_class); var ifn_3277 lang.IFn; if


	linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; var arg_3278 any = x__1; if linked_3276 == nil { h__4 = ifn_3277.Invoke_O__O(arg_3278) } else { h__4 = linked_3276.(*A_arbace_o2j_hd_A).Invoke_O_O__O(root_3275, arg_3278) }; var b__5 any; var root_3279 any = /*line :537:1*/A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_3280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3279, A_arbace_o2j_node_body_A_fn_class); var ifn_3281 lang.IFn; if


	linked_3280 == nil { ifn_3281 = lang.IFn_Cast(root_3279) } else { ifn_3281 = nil }; var arg_3282 any = x__1; if linked_3280 == nil { b__5 = ifn_3281.Invoke_O__O(arg_3282) } else { b__5 = linked_3280.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_3279, arg_3282) }; var G__1641000412__6_ any = h__4; switch
	lang.Util_Hash_O__I_NoInit(G__1641000412__6_) >> 0 & 255 { case 19: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_422) { var vec__1641000413__7 any = b__5; var kind__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000413__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000413__7, lang.RT_IntCast_J__I_NoInit(1), nil); var o__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000413__7, lang.RT_IntCast_J__I_NoInit(2), nil); var args__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000413__7, lang.RT_IntCast_J__I_NoInit(3), nil); var ts__12 any; var root_3284 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3284, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3286 lang.IFn



















		if linked_3285 == nil { ifn_3286 = lang.IFn_Cast(root_3284) } else { ifn_3286 = nil }; var arg_3287 any; var root_3288 any = A_arbace_o2j_A_const_71.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__11)).Ref(); var arg_3292 any; var fnbody__3298 any = A_arbace_o2j_expr_fn__1641000416_A_New(); var tmp1 *jrt.Class; var fncls__3297 *jrt.Class = A_arbace_o2j_expr_fn__1641000416_A_fn_class; if fncls__3297 == nil { var fncls__3297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_o2j_expr_fn__1641000416_A_fn_class = fncls__3297d; tmp1 = fncls__3297d } else { tmp1 = fncls__3297 }; arg_3292 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3298, tmp1, nil); if linked_3289 == nil { arg_3287 = ifn_3290.Invoke_O_O__O(arg_3291, arg_3292) } else { arg_3287 = linked_3289.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_3288, arg_3291, arg_3292) }; if linked_3285 == nil { ts__12 = ifn_3286.Invoke_O__O(arg_3287) } else { ts__12 = linked_3285.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3284, arg_3287) }
//line :541:1
		var ov__13 any; var root_3299 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3299, A_arbace_o2j_fresh_A_fn_class); var ifn_3301 lang.IFn




















		if linked_3300 == nil { ifn_3301 = lang.IFn_Cast(root_3299) } else { ifn_3301 = nil }; var arg_3302 any = Lit_74; if linked_3300 == nil { ov__13 = ifn_3301.Invoke_O__O(arg_3302) } else { ov__13 = linked_3300.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3299, arg_3302) }
//line :541:1
		var mv__14 any; var root_3303 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3303, A_arbace_o2j_fresh_A_fn_class); var ifn_3305 lang.IFn




















		if linked_3304 == nil { ifn_3305 = lang.IFn_Cast(root_3303) } else { ifn_3305 = nil }; var arg_3306 any = Lit_75; if linked_3304 == nil { mv__14 = ifn_3305.Invoke_O__O(arg_3306) } else { mv__14 = linked_3304.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3303, arg_3306)
		}
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_429; var tmp4 any; var root_3361 any = A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3361, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3363 lang.IFn; if linked_3362 == nil { ifn_3363 = lang.IFn_Cast(root_3361) } else { ifn_3363 = nil }; var arg_3364 any; var root_3365 any = A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3365, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3367 lang.IFn; if linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_156.GetRawRoot__O()); var tmp6 *lang.Compiler_AOTFn; var fnbody__3383 any = A_arbace_o2j_expr_fn__1641000418_A_New_O(ctx__0); var tmp7 *jrt.Class; var fncls__3382 *jrt.Class = A_arbace_o2j_expr_fn__1641000418_A_fn_class; if fncls__3382 == nil { var fncls__3382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__3383); A_arbace_o2j_expr_fn__1641000418_A_fn_class = fncls__3382d; tmp7 = fncls__3382d } else { tmp7 = fncls__3382 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3383, tmp7, nil); var tmp8 any = tmp6.Ref(); var tmp9 any; var root_3384 any = A_arbace_o2j_A_const_157.GetRawRoot__O(); var linked_3385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3384, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_3386 lang.IFn; if linked_3385 == nil { ifn_3386 = lang.IFn_Cast(root_3384) } else { ifn_3386 = nil }; var arg_3387 any = ts__12; if linked_3385 == nil { tmp9 = ifn_3386.Invoke_O__O(arg_3387) } else { tmp9 = linked_3385.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_3384, arg_3387) }; var tmp10 any = tmp9; var tmp11 any; var root_3388 any = A_arbace_o2j_A_const_157.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_3390 lang.IFn; if linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any = args__11; if linked_3389 == nil { tmp11 = ifn_3390.Invoke_O__O(arg_3391) } else { tmp11 = linked_3389.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_3388, arg_3391) }; arg_3368 = tmp5.Invoke_O_O_O__O(tmp8, tmp10, tmp11); var arg_3369 any; var tmp12 any; var root_3392 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3392, A_arbace_o2j_expr_A_fn_class); var ifn_3394 lang.IFn
		if linked_3393 == nil { ifn_3394 = lang.IFn_Cast(root_3392) } else { ifn_3394 = nil }; var arg_3395 any = ctx__0; var arg_3396 any = o__10; var arg_3397 any = jrt.Boolean_FALSE.Ref(); if linked_3393 == nil { tmp12 = ifn_3394.Invoke_O_O_O__O(arg_3395, arg_3396, arg_3397) } else { tmp12 = linked_3393.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3392, arg_3395, arg_3396, arg_3397) }
//line :564:1
		var tmp13 any = tmp12; var tmp14 any; var root_3398 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3398, A_arbace_o2j_expr_A_fn_class); var ifn_3400 lang.IFn
		if linked_3399 == nil { ifn_3400 = lang.IFn_Cast(root_3398) } else { ifn_3400 = nil }; var arg_3401 any = ctx__0; var arg_3402 any = m__9; var arg_3403 any = jrt.Boolean_FALSE.Ref(); if linked_3399 == nil { tmp14 = ifn_3400.Invoke_O_O_O__O(arg_3401, arg_3402, arg_3403) } else { tmp14 = linked_3399.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3398, arg_3401, arg_3402, arg_3403) }
//line :564:1
		arg_3369 = lang.Tuple_Create_O_O_O_O__IPersistentVector(ov__13, tmp13, mv__14, tmp14); if linked_3366 == nil { arg_3364 = ifn_3367.Invoke_O_O__O(arg_3368, arg_3369) } else { arg_3364 = linked_3366.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3365, arg_3368, arg_3369) }; if linked_3362 == nil { tmp4 = ifn_3363.Invoke_O__O(arg_3364) } else { tmp4 = linked_3362.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3361, arg_3364) }; var tmp15 any = tmp4; var tmp16 any; var root_3404 any = A_arbace_o2j_A_const_178.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, A_arbace_o2j_call_form_A_fn_class); var ifn_3406 lang.IFn

		if linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_235.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_430; var arg_3407 any = tmp17.Invoke_O_O_O_O__O(tmp18, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kind__8, A_arbace_o2j_A_const_172)).Ref(), ov__13, mv__14); var arg_3408 any; var root_3416 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3418 lang.IFn; if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any = lang.Tuple_Create_O__IPersistentVector(ov__13); var arg_3420 any = ts__12; if linked_3417 == nil { arg_3408 = ifn_3418.Invoke_O_O__O(arg_3419, arg_3420) } else { arg_3408 = linked_3417.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3416, arg_3419, arg_3420) }; if linked_3405 == nil { tmp16 = ifn_3406.Invoke_O_O__O(arg_3407, arg_3408) } else { tmp16 = linked_3405.(*A_arbace_o2j_call_form_A).Invoke_O_O_O__O(root_3404, arg_3407, arg_3408) }
//line :564:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp15, tmp16) }
//line :541:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_423) {








		var root_3307 any = A_arbace_o2j_A_const_424.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, A_arbace_o2j_stringswitch_node_A_fn_class); var ifn_3309 lang.IFn; if linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any = ctx__0; var arg_3311 any = b__5; var arg_3312 any = tail_QMARK___2; if linked_3308 == nil { return ifn_3309.Invoke_O_O_O__O(arg_3310, arg_3311, arg_3312) } else { return linked_3308.(*A_arbace_o2j_stringswitch_node_A).Invoke_O_O_O_O__O(root_3307, arg_3310, arg_3311, arg_3312) } }
//line :541:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_425) { var xs__7 any; var root_3313 any = A_arbace_o2j_A_const_421.GetRawRoot__O(); var linked_3314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3313, A_arbace_o2j_flatten_seq_A_fn_class); var ifn_3315 lang.IFn













		if linked_3314 == nil { ifn_3315 = lang.IFn_Cast(root_3313) } else { ifn_3315 = nil }; var arg_3316 any = x__1; if linked_3314 == nil { xs__7 = ifn_3315.Invoke_O__O(arg_3316) } else { xs__7 = linked_3314.(*A_arbace_o2j_flatten_seq_A).Invoke_O_O__O(root_3313, arg_3316) }
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp20 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j_A_const_426); var tmp21 any; var root_3323 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_3324 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3323, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3325 lang.IFn; if linked_3324 == nil { ifn_3325 = lang.IFn_Cast(root_3323) } else { ifn_3325 = nil }; var arg_3326 any; var fnbody__3335 any = A_arbace_o2j_expr_fn__1641000420_A_New_O(ctx__0); var tmp22 *jrt.Class; var fncls__3334 *jrt.Class = A_arbace_o2j_expr_fn__1641000420_A_fn_class; if fncls__3334 == nil { var fncls__3334d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__3335); A_arbace_o2j_expr_fn__1641000420_A_fn_class = fncls__3334d; tmp22 = fncls__3334d } else { tmp22 = fncls__3334 }; arg_3326 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3335, tmp22, nil); var arg_3327 any; var root_3336 any = A_arbace_o2j_A_const_36.GetRawRoot__O(); var linked_3337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3336, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_3338 lang.IFn; if linked_3337 == nil { ifn_3338 = lang.IFn_Cast(root_3336) } else { ifn_3338 = nil }; var arg_3339 any = xs__7; if linked_3337 == nil { arg_3327 = ifn_3338.Invoke_O__O(arg_3339) } else { arg_3327 = linked_3337.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_3336, arg_3339) }; if linked_3324 == nil { tmp21 = ifn_3325.Invoke_O_O__O(arg_3326, arg_3327) } else { tmp21 = linked_3324.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3323, arg_3326, arg_3327) }; var tmp23 any = tmp21; var tmp24 any; var root_3340 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3340, A_arbace_o2j_expr_A_fn_class); var ifn_3342 lang.IFn; if linked_3341 == nil { ifn_3342 = lang.IFn_Cast(root_3340) } else { ifn_3342 = nil }; var arg_3343 any = ctx__0; var arg_3344 any; var root_3346 any = A_arbace_o2j_A_const_35.GetRawRoot__O(); var linked_3347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3346, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_3348 lang.IFn; if linked_3347 == nil { ifn_3348 = lang.IFn_Cast(root_3346) } else { ifn_3348 = nil }; var arg_3349 any = xs__7; if linked_3347 == nil { arg_3344 = ifn_3348.Invoke_O__O(arg_3349) } else { arg_3344 = linked_3347.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_3346, arg_3349) }; var arg_3345 any = tail_QMARK___2; if linked_3341 == nil { tmp24 = ifn_3342.Invoke_O_O_O__O(arg_3343, arg_3344, arg_3345) } else { tmp24 = linked_3341.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3340, arg_3343, arg_3344, arg_3345) }; return tmp19.Invoke_O_O_O__O(tmp20, tmp23, lang.Tuple_Create_O__IPersistentVector(tmp24)) }
//line :541:1
	case 49: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_427) {










		var root_3350 any = A_arbace_o2j_A_const_428.GetRawRoot__O(); var linked_3351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3350, A_arbace_o2j_staticcatch_node_A_fn_class); var ifn_3352 lang.IFn; if linked_3351 == nil { ifn_3352 = lang.IFn_Cast(root_3350) } else { ifn_3352 = nil }; var arg_3353 any = ctx__0; var arg_3354 any = b__5; var arg_3355 any = tail_QMARK___2; if linked_3351 == nil { return ifn_3352.Invoke_O_O_O__O(arg_3353, arg_3354, arg_3355) } else { return linked_3351.(*A_arbace_o2j_staticcatch_node_A).Invoke_O_O_O_O__O(root_3350, arg_3353, arg_3354, arg_3355) } }
//line :541:1
	case 50: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_431) {

		var root_3421 any = A_arbace_o2j_A_const_432.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, A_arbace_o2j_const_form_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any; var root_3425 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3427 lang.IFn; if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = b__5; if linked_3426 == nil { arg_3424 = ifn_3427.Invoke_O__O(arg_3428) } else { arg_3424 = linked_3426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3425, arg_3428) }; if linked_3422 == nil { return ifn_3423.Invoke_O__O(arg_3424) } else { return linked_3422.(*A_arbace_o2j_const_form_A).Invoke_O_O__O(root_3421, arg_3424) } }
//line :541:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_433) {











		var root_3429 any = A_arbace_o2j_A_const_434.GetRawRoot__O(); var linked_3430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3429, A_arbace_o2j_trywith_node_A_fn_class); var ifn_3431 lang.IFn; if linked_3430 == nil { ifn_3431 = lang.IFn_Cast(root_3429) } else { ifn_3431 = nil }; var arg_3432 any = ctx__0; var arg_3433 any = b__5; var arg_3434 any = tail_QMARK___2; if linked_3430 == nil { return ifn_3431.Invoke_O_O_O__O(arg_3432, arg_3433, arg_3434) } else { return linked_3430.(*A_arbace_o2j_trywith_node_A).Invoke_O_O_O_O__O(root_3429, arg_3432, arg_3433, arg_3434) } }
//line :541:1
	case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_435) {






		var root_3435 any = A_arbace_o2j_A_const_436.GetRawRoot__O(); var linked_3436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3435, A_arbace_o2j_prim_node_A_fn_class); var ifn_3437 lang.IFn; if linked_3436 == nil { ifn_3437 = lang.IFn_Cast(root_3435) } else { ifn_3437 = nil }; var arg_3438 any = ctx__0; var arg_3439 any = b__5; var arg_3440 any = tail_QMARK___2; if linked_3436 == nil { return ifn_3437.Invoke_O_O_O__O(arg_3438, arg_3439, arg_3440) } else { return linked_3436.(*A_arbace_o2j_prim_node_A).Invoke_O_O_O_O__O(root_3435, arg_3438, arg_3439, arg_3440) } }
//line :541:1
	case 69: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_437) {

























		var root_3441 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, A_arbace_o2j_expr_A_fn_class); var ifn_3443 lang.IFn; if linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any = ctx__0; var arg_3445 any; var root_3447 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any = b__5; if linked_3448 == nil { arg_3445 = ifn_3449.Invoke_O__O(arg_3450) } else { arg_3445 = linked_3448.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3447, arg_3450) }; var arg_3446 any = tail_QMARK___2; if linked_3442 == nil { return ifn_3443.Invoke_O_O_O__O(arg_3444, arg_3445, arg_3446) } else { return linked_3442.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3441, arg_3444, arg_3445, arg_3446) } }
//line :541:1
	case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_438) { var vec__1641000422__7 any = b__5; var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000422__7, lang.RT_IntCast_J__I_NoInit(0), nil); var t__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000422__7, lang.RT_IntCast_J__I_NoInit(1), nil); var f__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000422__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_440; var tmp27 any; var root_3451 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, A_arbace_o2j_test_form_A_fn_class); var ifn_3453 lang.IFn












		if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = ctx__0; var arg_3455 any = c__8; if linked_3452 == nil { tmp27 = ifn_3453.Invoke_O_O__O(arg_3454, arg_3455) } else { tmp27 = linked_3452.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_3451, arg_3454, arg_3455) }; var tmp28 any = tmp27; var tmp29 any; var root_3456 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3456, A_arbace_o2j_expr_A_fn_class); var ifn_3458 lang.IFn; if linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any = ctx__0; var arg_3460 any = t__9; var arg_3461 any = tail_QMARK___2; if linked_3457 == nil { tmp29 = ifn_3458.Invoke_O_O_O__O(arg_3459, arg_3460, arg_3461) } else { tmp29 = linked_3457.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3456, arg_3459, arg_3460, arg_3461) }; var tmp30 any = tmp29; var tmp31 any; var root_3462 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3462, A_arbace_o2j_expr_A_fn_class); var ifn_3464 lang.IFn; if linked_3463 == nil { ifn_3464 = lang.IFn_Cast(root_3462) } else { ifn_3464 = nil }; var arg_3465 any = ctx__0; var arg_3466 any = f__10; var arg_3467 any = tail_QMARK___2; if linked_3463 == nil { tmp31 = ifn_3464.Invoke_O_O_O__O(arg_3465, arg_3466, arg_3467) } else { tmp31 = linked_3463.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3462, arg_3465, arg_3466, arg_3467) }; return tmp25.Invoke_O_O_O_O__O(tmp26, tmp28, tmp30, tmp31) }
//line :541:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_439) { var vec__1641000425__7 any = b__5; var id__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000425__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000425__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp33 any = A_arbace_o2j_A_const_442; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp35 any = A_arbace_o2j_A_const_443; var tmp36 any; var root_3477 any = A_arbace_o2j_A_const_219.GetRawRoot__O(); var linked_3478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3477, A_arbace_o2j_lookup_A_fn_class); var ifn_3479 lang.IFn

















		if linked_3478 == nil { ifn_3479 = lang.IFn_Cast(root_3477) } else { ifn_3479 = nil }; var arg_3480 any = ctx__0; var arg_3481 any = id__8; if linked_3478 == nil { tmp36 = ifn_3479.Invoke_O_O__O(arg_3480, arg_3481) } else { tmp36 = linked_3478.(*A_arbace_o2j_lookup_A).Invoke_O_O_O__O(root_3477, arg_3480, arg_3481) }; var tmp37 any = tmp36; var tmp38 any; var root_3482 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, A_arbace_o2j_expr_A_fn_class); var ifn_3484 lang.IFn; if linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any = ctx__0; var arg_3486 any = e__9; var arg_3487 any = jrt.Boolean_FALSE.Ref(); if linked_3483 == nil { tmp38 = ifn_3484.Invoke_O_O_O__O(arg_3485, arg_3486, arg_3487) } else { tmp38 = linked_3483.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3482, arg_3485, arg_3486, arg_3487) }; return tmp32.Invoke_O_O_O__O(tmp33, tmp34.Invoke_O_O_O__O(tmp35, tmp37, tmp38), A_arbace_o2j_A_const_319.GetRawRoot__O()) }
//line :541:1
	case 101: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_441) {
		var root_3468 any = A_arbace_o2j_A_const_219.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, A_arbace_o2j_lookup_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any = ctx__0; var arg_3472 any; var root_3473 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3475 lang.IFn; if linked_3474 == nil { ifn_3475 = lang.IFn_Cast(root_3473) } else { ifn_3475 = nil }; var arg_3476 any = b__5; if linked_3474 == nil { arg_3472 = ifn_3475.Invoke_O__O(arg_3476) } else { arg_3472 = linked_3474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3473, arg_3476) }; if linked_3469 == nil { return ifn_3470.Invoke_O_O__O(arg_3471, arg_3472) } else { return linked_3469.(*A_arbace_o2j_lookup_A).Invoke_O_O_O__O(root_3468, arg_3471, arg_3472) } }
//line :541:1
	case 119: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_444) {



		var root_3488 any = A_arbace_o2j_A_const_445.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, A_arbace_o2j_function_node_A_fn_class); var ifn_3490 lang.IFn; if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = ctx__0; var arg_3492 any = x__1; if linked_3489 == nil { return ifn_3490.Invoke_O_O__O(arg_3491, arg_3492) } else { return linked_3489.(*A_arbace_o2j_function_node_A).Invoke_O_O_O__O(root_3488, arg_3491, arg_3492) } }
//line :541:1
	case 122: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_446) {


		var root_3493 any = A_arbace_o2j_A_const_447.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, A_arbace_o2j_apply_node_A_fn_class); var ifn_3495 lang.IFn; if linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any = ctx__0; var arg_3497 any = b__5; var arg_3498 any = tail_QMARK___2; if linked_3494 == nil { return ifn_3495.Invoke_O_O_O__O(arg_3496, arg_3497, arg_3498) } else { return linked_3494.(*A_arbace_o2j_apply_node_A).Invoke_O_O_O_O__O(root_3493, arg_3496, arg_3497, arg_3498) } }
//line :541:1
	case 139: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_448) {





		var root_3499 any = A_arbace_o2j_A_const_449.GetRawRoot__O(); var linked_3500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3499, A_arbace_o2j_letrec_node_A_fn_class); var ifn_3501 lang.IFn; if linked_3500 == nil { ifn_3501 = lang.IFn_Cast(root_3499) } else { ifn_3501 = nil }; var arg_3502 any = ctx__0; var arg_3503 any = b__5; var arg_3504 any = tail_QMARK___2; if linked_3500 == nil { return ifn_3501.Invoke_O_O_O__O(arg_3502, arg_3503, arg_3504) } else { return linked_3500.(*A_arbace_o2j_letrec_node_A).Invoke_O_O_O_O__O(root_3499, arg_3502, arg_3503, arg_3504) } }
//line :541:1
	case 149: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_450) {


























		var root_3505 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, A_arbace_o2j_expr_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = ctx__0; var arg_3509 any; var root_3511 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_3512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3511, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3513 lang.IFn; if linked_3512 == nil { ifn_3513 = lang.IFn_Cast(root_3511) } else { ifn_3513 = nil }; var arg_3514 any = b__5; if linked_3512 == nil { arg_3509 = ifn_3513.Invoke_O__O(arg_3514) } else { arg_3509 = linked_3512.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3511, arg_3514) }; var arg_3510 any = tail_QMARK___2; if linked_3506 == nil { return ifn_3507.Invoke_O_O_O__O(arg_3508, arg_3509, arg_3510) } else { return linked_3506.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3505, arg_3508, arg_3509, arg_3510) } }
//line :541:1
	case 178: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_451) {







		var root_3515 any = A_arbace_o2j_A_const_452.GetRawRoot__O(); var linked_3516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3515, A_arbace_o2j_switch_node_A_fn_class); var ifn_3517 lang.IFn; if linked_3516 == nil { ifn_3517 = lang.IFn_Cast(root_3515) } else { ifn_3517 = nil }; var arg_3518 any = ctx__0; var arg_3519 any = b__5; var arg_3520 any = tail_QMARK___2; if linked_3516 == nil { return ifn_3517.Invoke_O_O_O__O(arg_3518, arg_3519, arg_3520) } else { return linked_3516.(*A_arbace_o2j_switch_node_A).Invoke_O_O_O_O__O(root_3515, arg_3518, arg_3519, arg_3520) } }
//line :541:1
	case 180: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_453) {
		var root_3521 any = A_arbace_o2j_A_const_219.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3521, A_arbace_o2j_lookup_A_fn_class); var ifn_3523 lang.IFn; if linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any = ctx__0; var arg_3525 any; var root_3526 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any = b__5; if linked_3527 == nil { arg_3525 = ifn_3528.Invoke_O__O(arg_3529) } else { arg_3525 = linked_3527.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3526, arg_3529) }; if linked_3522 == nil { return ifn_3523.Invoke_O_O__O(arg_3524, arg_3525) } else { return linked_3522.(*A_arbace_o2j_lookup_A).Invoke_O_O_O__O(root_3521, arg_3524, arg_3525) } }
//line :541:1
	case 226: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_454) {
















		var root_3530 any = A_arbace_o2j_A_const_455.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, A_arbace_o2j_for_node_A_fn_class); var ifn_3532 lang.IFn; if linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any = ctx__0; var arg_3534 any = b__5; if linked_3531 == nil { return ifn_3532.Invoke_O_O__O(arg_3533, arg_3534) } else { return linked_3531.(*A_arbace_o2j_for_node_A).Invoke_O_O_O__O(root_3530, arg_3533, arg_3534) } }
//line :541:1
	case 227: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_456) {




		var root_3535 any = A_arbace_o2j_A_const_457.GetRawRoot__O(); var linked_3536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3535, A_arbace_o2j_let_chain_A_fn_class); var ifn_3537 lang.IFn; if linked_3536 == nil { ifn_3537 = lang.IFn_Cast(root_3535) } else { ifn_3537 = nil }; var arg_3538 any = ctx__0; var arg_3539 any = x__1; var arg_3540 any = tail_QMARK___2; if linked_3536 == nil { return ifn_3537.Invoke_O_O_O__O(arg_3538, arg_3539, arg_3540) } else { return linked_3536.(*A_arbace_o2j_let_chain_A).Invoke_O_O_O_O__O(root_3535, arg_3538, arg_3539, arg_3540) } }
//line :541:1
	case 228: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_458) {




		var root_3541 any = A_arbace_o2j_A_const_457.GetRawRoot__O(); var linked_3542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3541, A_arbace_o2j_let_chain_A_fn_class); var ifn_3543 lang.IFn; if linked_3542 == nil { ifn_3543 = lang.IFn_Cast(root_3541) } else { ifn_3543 = nil }; var arg_3544 any = ctx__0; var arg_3545 any = x__1; var arg_3546 any = tail_QMARK___2; if linked_3542 == nil { return ifn_3543.Invoke_O_O_O__O(arg_3544, arg_3545, arg_3546) } else { return linked_3542.(*A_arbace_o2j_let_chain_A).Invoke_O_O_O_O__O(root_3541, arg_3544, arg_3545, arg_3546) } }
//line :541:1
	case 244: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_459) { var vec__1641000428__7 any = b__5; var c__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000428__7, lang.RT_IntCast_J__I_NoInit(0), nil); var body__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000428__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp40 any = A_arbace_o2j_A_const_462; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp42 any = A_arbace_o2j_A_const_463; var tmp43 any; var root_3552 any = A_arbace_o2j_A_const_347.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, A_arbace_o2j_test_form_A_fn_class); var ifn_3554 lang.IFn















		if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any = ctx__0; var arg_3556 any = c__8_2; if linked_3553 == nil { tmp43 = ifn_3554.Invoke_O_O__O(arg_3555, arg_3556) } else { tmp43 = linked_3553.(*A_arbace_o2j_test_form_A).Invoke_O_O_O__O(root_3552, arg_3555, arg_3556) }; var tmp44 any = tmp43; var tmp45 any; var root_3557 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, A_arbace_o2j_expr_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = ctx__0; var arg_3561 any = body__9; var arg_3562 any = jrt.Boolean_FALSE.Ref(); if linked_3558 == nil { tmp45 = ifn_3559.Invoke_O_O_O__O(arg_3560, arg_3561, arg_3562) } else { tmp45 = linked_3558.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3557, arg_3560, arg_3561, arg_3562) }; return tmp39.Invoke_O_O_O__O(tmp40, tmp41.Invoke_O_O_O__O(tmp42, tmp44, tmp45), A_arbace_o2j_A_const_319.GetRawRoot__O()) }
//line :541:1
	case 246: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000412__6_, A_arbace_o2j_A_const_460) {









		var root_3547 any = A_arbace_o2j_A_const_461.GetRawRoot__O(); var linked_3548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3547, A_arbace_o2j_staticraise_node_A_fn_class); var ifn_3549 lang.IFn; if linked_3548 == nil { ifn_3549 = lang.IFn_Cast(root_3547) } else { ifn_3549 = nil }; var arg_3550 any = ctx__0; var arg_3551 any = b__5; if linked_3548 == nil { return ifn_3549.Invoke_O_O__O(arg_3550, arg_3551) } else { return linked_3548.(*A_arbace_o2j_staticraise_node_A).Invoke_O_O_O__O(root_3547, arg_3550, arg_3551) } }
//line :541:1
	default:}; var tmp46 any; var root_3356 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_3357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3356, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3358 lang.IFn; if



























	linked_3357 == nil { ifn_3358 = lang.IFn_Cast(root_3356) } else { ifn_3358 = nil }; var arg_3359 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_78, nil, Lit_79), jrt.RefArrayOf(jrt.Object_class, nil, h__4, nil)).Ref(); var arg_3360 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_29, h__4)); if linked_3357 == nil { tmp46 = ifn_3358.Invoke_O_O__O(arg_3359, arg_3360) } else { tmp46 = linked_3357.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3356, arg_3359, arg_3360) }; /*line :541:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp46))) }














func A_arbace_o2j_expr_fn__1641000420_A_New_O(p0 any) *A_arbace_o2j_expr_fn__1641000420_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_expr_fn__1641000420_A{}; t.Ctor_O(p0); return t }
//line :556:1
func (t *A_arbace_o2j_expr_fn__1641000420_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :556:1
func (t *A_arbace_o2j_expr_fn__1641000420_A) Invoke_O_O__O(self, p1__1641000411_SHARP___1 any) any { var root_3328 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, A_arbace_o2j_expr_A_fn_class); var ifn_3330 lang.IFn; if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any = t.F_ctx; var arg_3332 any = p1__1641000411_SHARP___1; var arg_3333 any = jrt.Boolean_FALSE.Ref(); if linked_3329 == nil { return ifn_3330.Invoke_O_O_O__O(arg_3331, arg_3332, arg_3333) } else { return linked_3329.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3328, arg_3331, arg_3332, arg_3333) } }




func A_arbace_o2j_expr_fn__1641000416_A_New() *A_arbace_o2j_expr_fn__1641000416_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_expr_fn__1641000416_A{}; t.Ctor(); return t }
//line :561:1
func (t *A_arbace_o2j_expr_fn__1641000416_A) Ctor() {}
//line :561:1
func (t *A_arbace_o2j_expr_fn__1641000416_A) Invoke_O__O(self any) any { var root_3293 any = A_arbace_o2j_A_const_122.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, A_arbace_o2j_fresh_A_fn_class); var ifn_3295 lang.IFn; if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = Lit_80; if linked_3294 == nil { return ifn_3295.Invoke_O__O(arg_3296) } else { return linked_3294.(*A_arbace_o2j_fresh_A).Invoke_O_O__O(root_3293, arg_3296) } }


func A_arbace_o2j_expr_fn__1641000418_A_New_O(p0 any) *A_arbace_o2j_expr_fn__1641000418_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_expr_fn__1641000418_A{}; t.Ctor_O(p0); return t }
//line :564:1
func (t *A_arbace_o2j_expr_fn__1641000418_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :564:1
func (t *A_arbace_o2j_expr_fn__1641000418_A) Invoke_O_O_O__O(self, t__1, x__2 any) any { var tmp1 any; var root_3376 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3376, A_arbace_o2j_expr_A_fn_class); var ifn_3378 lang.IFn; if linked_3377 == nil { ifn_3378 = lang.IFn_Cast(root_3376) } else { ifn_3378 = nil }; var arg_3379 any = t.F_ctx; var arg_3380 any = x__2; var arg_3381 any = jrt.Boolean_FALSE.Ref(); if linked_3377 == nil { tmp1 = ifn_3378.Invoke_O_O_O__O(arg_3379, arg_3380, arg_3381) } else { tmp1 = linked_3377.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3376, arg_3379, arg_3380, arg_3381) }; return lang.Tuple_Create_O_O__IPersistentVector(t__1, tmp1) }









func A_arbace_o2j_translate_unit_A_New() *A_arbace_o2j_translate_unit_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_unit_A{}; t.Ctor(); return t }
//line :574:1
func (t *A_arbace_o2j_translate_unit_A) Ctor() {}
//line :574:1
func (t *A_arbace_o2j_translate_unit_A) Invoke_O_O__O(self, p__1641000432__0 any) any { var map__1641000433__2 any = p__1641000432__0; var map__1641000433__3 any; if lang.ISeq_InstanceOf(map__1641000433__2) { var tmp1 any; var root_3563 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any = map__1641000433__2; if linked_3564 == nil { tmp1 = ifn_3565.Invoke_O__O(arg_3566) } else { tmp1 = linked_3564.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3563, arg_3566) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3567 any = A_arbace_o2j_A_const_389.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3567, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3569 lang.IFn; if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any = map__1641000433__2; if linked_3568 == nil { tmp2 = ifn_3569.Invoke_O__O(arg_3570) } else { tmp2 = linked_3568.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3567, arg_3570) }; map__1641000433__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3571 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3573 lang.IFn; if linked_3572 == nil { ifn_3573 = lang.IFn_Cast(root_3571) } else { ifn_3573 = nil }; var arg_3574 any = map__1641000433__2; if linked_3572 == nil { tmp3 = ifn_3573.Invoke_O__O(arg_3574) } else { tmp3 = linked_3572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3571, arg_3574) }; if jrt.J2g_Truth(tmp3) { var root_3575 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3575, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3577 lang.IFn; if linked_3576 == nil { ifn_3577 = lang.IFn_Cast(root_3575) } else { ifn_3577 = nil }; var arg_3578 any = map__1641000433__2; if linked_3576 == nil { map__1641000433__3 = ifn_3577.Invoke_O__O(arg_3578) } else { map__1641000433__3 = linked_3576.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3575, arg_3578) } } else { map__1641000433__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1641000433__3 = map__1641000433__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__1641000433__3, A_arbace_o2j_A_const_21); var code__5 any = lang.RT_Get_O_O__O_NoInit(map__1641000433__3, A_arbace_o2j_A_const_20); var cls__6 any; var root_3579 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3581 lang.IFn; if



	linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any; var root_3583 any = A_arbace_o2j_A_const_344.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, A_arbace_o2j_class_name_A_fn_class); var ifn_3585 lang.IFn; if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = name__4; if linked_3584 == nil { arg_3582 = ifn_3585.Invoke_O__O(arg_3586) } else { arg_3582 = linked_3584.(*A_arbace_o2j_class_name_A).Invoke_O_O__O(root_3583, arg_3586) }; if linked_3580 == nil { cls__6 = ifn_3581.Invoke_O__O(arg_3582) } else { cls__6 = linked_3580.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3579, arg_3582) }; var root_3717 any =
	A_arbace_o2j_A_const_479.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3719 lang.IFn; if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_480.GetRawRoot__O()); var tmp5 any = A_arbace_o2j_A_const_81; var tmp6 any = A_arbace_o2j_A_const_83; var tmp7 any; var root_3726 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_3727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3726, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3728 lang.IFn; if linked_3727 == nil { ifn_3728 = lang.IFn_Cast(root_3726) } else { ifn_3728 = nil }; var arg_3729 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_109, nil), jrt.RefArrayOf(jrt.Object_class, nil, cls__6)).Ref(); if linked_3727 == nil { tmp7 = ifn_3728.Invoke_O__O(arg_3729) } else { tmp7 = linked_3727.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3726, arg_3729) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_o2j_A_const_21; var tmp10 any = A_arbace_o2j_A_const_80; var tmp11 any; var root_3730 any = A_arbace_o2j_A_const_197.GetRawRoot__O(); var linked_3731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3730, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3732 lang.IFn; if linked_3731 == nil { ifn_3732 = lang.IFn_Cast(root_3730) } else { ifn_3732 = nil }; var arg_3733 any = A_arbace_o2j_A_const_87; if linked_3731 == nil { tmp11 = ifn_3732.Invoke_O__O(arg_3733) } else { tmp11 = linked_3731.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3730, arg_3733) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_o2j_A_const_203; var tmp14 any; var root_3734 any = A_arbace_o2j_A_const_197.GetRawRoot__O(); var linked_3735 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3734, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3736 lang.IFn; if
	linked_3735 == nil { ifn_3736 = lang.IFn_Cast(root_3734) } else { ifn_3736 = nil }; var arg_3737 any = lang.PersistentVector_EMPTY.Ref(); if linked_3735 == nil { tmp14 = ifn_3736.Invoke_O__O(arg_3737) } else { tmp14 = linked_3735.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3734, arg_3737) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_o2j_A_const_125; var tmp17 any; var root_3738 any = /*line :579:1*/A_arbace_o2j_A_const_197.GetRawRoot__O(); var linked_3739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3738, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3740 lang.IFn; if
	linked_3739 == nil { ifn_3740 = lang.IFn_Cast(root_3738) } else { ifn_3740 = nil }; var arg_3741 any = lang.PersistentVector_EMPTY.Ref(); if linked_3739 == nil { tmp17 = ifn_3740.Invoke_O__O(arg_3741) } else { tmp17 = linked_3739.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3738, arg_3741) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_o2j_A_const_84; var tmp20 any; var root_3742 any = /*line :579:1*/A_arbace_o2j_A_const_197.GetRawRoot__O(); var linked_3743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3742, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_3744 lang.IFn; if
	linked_3743 == nil { ifn_3744 = lang.IFn_Cast(root_3742) } else { ifn_3744 = nil }; var arg_3745 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3743 == nil { tmp20 = ifn_3744.Invoke_O__O(arg_3745) } else { tmp20 = linked_3743.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3742, arg_3745) }; arg_3720 = /*line :579:1*/tmp4.Invoke_O_O__O(tmp5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, name__4, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp20))); if linked_3718 == nil { ifn_3719.Invoke_O__O(arg_3720) } else { linked_3718.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3717, arg_3720) }; var tmp21 any; tmp53 := /*line :574:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1641000435__9 any; var root_3587 any = A_arbace_o2j_A_const_127.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, A_arbace_o2j_node_body_A_fn_class); var ifn_3589 lang.IFn






		if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any = code__5; if linked_3588 == nil { vec__1641000435__9 = ifn_3589.Invoke_O__O(arg_3590) } else { vec__1641000435__9 = linked_3588.(*A_arbace_o2j_node_body_A).Invoke_O_O__O(root_3587, arg_3590) }
//line :574:1
		var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000435__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1641000438__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000435__9, lang.RT_IntCast_J__I_NoInit(1), nil); var body__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000438__11, lang.RT_IntCast_J__I_NoInit(0), nil); var init__13 any; var root_3591 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var linked_3592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3591, A_arbace_o2j_realize_A_fn_class); var ifn_3593 lang.IFn; _ = ___10







		if linked_3592 == nil { ifn_3593 = lang.IFn_Cast(root_3591) } else { ifn_3593 = nil }; var arg_3594 any; var root_3595 any = A_arbace_o2j_A_const_155.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, A_arbace_o2j_expr_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_145, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_o2j_A_const_199, lang.PersistentArrayMap_EMPTY.Ref())); var arg_3599 any = body__12; var arg_3600 any = jrt.Boolean_FALSE.Ref(); if linked_3596 == nil { arg_3594 = ifn_3597.Invoke_O_O_O__O(arg_3598, arg_3599, arg_3600) } else { arg_3594 = linked_3596.(*A_arbace_o2j_expr_A).Invoke_O_O_O_O__O(root_3595, arg_3598, arg_3599, arg_3600) }; if linked_3592 == nil { init__13 = ifn_3593.Invoke_O__O(arg_3594) } else { init__13 = linked_3592.(*A_arbace_o2j_realize_A).Invoke_O_O__O(root_3591, arg_3594) }
//line :574:1
		var classes__14 any; var root_3601 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3601, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3603 lang.IFn








		if linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var arg_3605 any; var root_3606 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_3607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3606, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3608 lang.IFn; if linked_3607 == nil { ifn_3608 = lang.IFn_Cast(root_3606) } else { ifn_3608 = nil }; var tmp22 *lang.Keyword = A_arbace_o2j_A_const_203; var arg_3609 any = tmp22.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); if linked_3607 == nil { arg_3605 = ifn_3608.Invoke_O__O(arg_3609) } else { arg_3605 = linked_3607.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3606, arg_3609) }; if linked_3602 == nil { classes__14 = ifn_3603.Invoke_O_O__O(arg_3604, arg_3605) } else { classes__14 = linked_3602.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3601, arg_3604, arg_3605) }
//line :574:1
		var klass__15 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp25 any = A_arbace_o2j_A_const_464; var tmp26 any; var root_3618 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3620 lang.IFn










		if linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any = cls__6; var arg_3622 any = A_arbace_o2j_A_const_465; if linked_3619 == nil { tmp26 = ifn_3620.Invoke_O_O__O(arg_3621, arg_3622) } else { tmp26 = linked_3619.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3618, arg_3621, arg_3622) }
//line :584:1
		var tmp27 any = tmp24.Invoke_O_O__O(tmp25, tmp26); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp29 any = A_arbace_o2j_A_const_466; var tmp30 any; var root_3623 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3623, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3625 lang.IFn

		if linked_3624 == nil { ifn_3625 = lang.IFn_Cast(root_3623) } else { ifn_3625 = nil }; var arg_3626 any = A_arbace_o2j_A_const_467; var arg_3627 any = A_arbace_o2j_A_const_468; if linked_3624 == nil { tmp30 = ifn_3625.Invoke_O_O__O(arg_3626, arg_3627) } else { tmp30 = linked_3624.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3623, arg_3626, arg_3627) }
//line :584:1
		var tmp31 any = lang.Tuple_Create_O__IPersistentVector(tmp28.Invoke_O_O__O(tmp29, tmp30)); var tmp32 any; var iter__1927001039__auto____15 any; var fnbody__3699 any = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A_New(); var tmp33 *jrt.Class
		var fncls__3698 /*line :584:1*/*jrt.Class = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A_fn_class


		if fncls__3698 == nil { var fncls__3698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_196, false, nil); A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A_fn_class = fncls__3698d; tmp33 = fncls__3698d } else { tmp33 = fncls__3698 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3699, tmp33, nil); var tmp34 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp35 any; var root_3700 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_3701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3700, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3702 lang.IFn; if linked_3701 == nil { ifn_3702 = lang.IFn_Cast(root_3700) } else { ifn_3702 = nil }; var tmp36 *lang.Keyword = A_arbace_o2j_A_const_125; var arg_3703 any = tmp36.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); if linked_3701 == nil { tmp35 = ifn_3702.Invoke_O__O(arg_3703) } else { tmp35 = linked_3701.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3700, arg_3703) }; tmp32 = tmp34.Invoke_O__O(tmp35)
//line :584:1
		var tmp37 any = tmp32; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp39 any = A_arbace_o2j_A_const_472; var tmp40 any; var root_3704 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3704, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3706 lang.IFn




		if linked_3705 == nil { ifn_3706 = lang.IFn_Cast(root_3704) } else { ifn_3706 = nil }; var arg_3707 any = A_arbace_o2j_A_const_473; var arg_3708 any = A_arbace_o2j_A_const_474; if linked_3705 == nil { tmp40 = ifn_3706.Invoke_O_O__O(arg_3707, arg_3708) } else { tmp40 = linked_3705.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3704, arg_3707, arg_3708) }
//line :584:1
		var tmp41 any = tmp40; var tmp42 any; var root_3709 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3709, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3711 lang.IFn




		if linked_3710 == nil { ifn_3711 = lang.IFn_Cast(root_3709) } else { ifn_3711 = nil }; var arg_3712 any = lang.PersistentVector_EMPTY.Ref(); var arg_3713 any = A_arbace_o2j_A_const_475; if linked_3710 == nil { tmp42 = ifn_3711.Invoke_O_O__O(arg_3712, arg_3713) } else { tmp42 = linked_3710.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3709, arg_3712, arg_3713) }
//line :584:1
		klass__15 = tmp23.Invoke_O_O_O_O_O__O(tmp27, tmp31, tmp37, classes__14, lang.Tuple_Create_O__IPersistentVector(tmp38.Invoke_O_O_O_O__O(tmp39, tmp41, tmp42, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_476, A_arbace_o2j_A_const_477, init__13))))
//line :574:1
		var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp44 any = A_arbace_o2j_A_const_481; var tmp45 any = A_arbace_o2j_A_const_482; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp47 any = A_arbace_o2j_A_const_483; var tmp48 any = tmp43.Invoke_O_O_O__O(tmp44, tmp45, tmp46.Invoke_O_O__O(tmp47, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_o2j_A_const_484, A_arbace_o2j_A_const_485, A_arbace_o2j_A_const_486, A_arbace_o2j_A_const_487, A_arbace_o2j_A_const_488))); var tmp49 any; var root_3750 any = A_arbace_o2j_A_const_41.GetRawRoot__O(); var linked_3751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3750, A_arbace_o2j_realize_A_fn_class); var ifn_3752 lang.IFn

















		if linked_3751 == nil { ifn_3752 = lang.IFn_Cast(root_3750) } else { ifn_3752 = nil }; var arg_3753 any = klass__15; if linked_3751 == nil { tmp49 = ifn_3752.Invoke_O__O(arg_3753) } else { tmp49 = linked_3751.(*A_arbace_o2j_realize_A).Invoke_O_O__O(root_3750, arg_3753) }
//line :574:1
		var tmp50 any = lang.Tuple_Create_O_O__IPersistentVector(tmp48, tmp49); var tmp51 any; var root_3746 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_3747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3746, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3748 lang.IFn






		if linked_3747 == nil { ifn_3748 = lang.IFn_Cast(root_3746) } else { ifn_3748 = nil }; var tmp52 *lang.Keyword = A_arbace_o2j_A_const_84; var arg_3749 any = tmp52.Invoke_O__O(A_arbace_o2j_A_const_81.Get__O()); if linked_3747 == nil { tmp51 = ifn_3748.Invoke_O__O(arg_3749) } else { tmp51 = linked_3747.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3746, arg_3749) }
//line :574:1
		tmp21 = lang.Tuple_Create_O_O__IPersistentVector(tmp50, tmp51) }; return nil }(); var root_3714 any = A_arbace_o2j_A_const_478.GetRawRoot__O(); var linked_3715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3714, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3716 lang.IFn; if




	linked_3715 == nil { ifn_3716 = lang.IFn_Cast(root_3714) } else { ifn_3716 = nil }; if linked_3715 == nil { ifn_3716.Invoke__O() } else { linked_3715.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3714) }; if /*line :574:1*/ tmp53 != nil { panic(tmp53) }; return tmp21 }












func A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A_New() *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A{}; t.Ctor(); return t }
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A) Ctor() {}
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A) Invoke_O_O__O(self, s__1641000442__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3697 any = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A_New_O_O(s__1641000442__1, self); var tmp2 *jrt.Class; var fncls__3696 *jrt.Class = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A_fn_class; if fncls__3696 == nil { var fncls__3696d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_197, false, fnbody__3697); A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A_fn_class = fncls__3696d; tmp2 = fncls__3696d } else { tmp2 = fncls__3696 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3697, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :587:1
func A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A_New_O_O(p0, p1 any) *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A{}; t.Ctor_O_O(p0, p1); return t }
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A) Ctor_O_O(c__s__1641000442, c__iter__1641000441 any) { t.F_s__1641000442 = c__s__1641000442; t.F_iter__1641000441 = c__iter__1641000441 }
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A) Invoke_O__O(self any) any { { var s__1641000442__1 any; var t_ any = t.F_s__1641000442; t.F_s__1641000442 = nil; s__1641000442__1 = t_; for { var temp__1927000414__auto____2 any; var root_3628 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3628, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3630 lang.IFn; if linked_3629 == nil { ifn_3630 = lang.IFn_Cast(root_3628) } else { ifn_3630 = nil }; var arg_3631 any = s__1641000442__1; if linked_3629 == nil { temp__1927000414__auto____2 = ifn_3630.Invoke_O__O(arg_3631) } else { temp__1927000414__auto____2 = linked_3629.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3628, arg_3631) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000442__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3632 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_3633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3632, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3634 lang.IFn; if linked_3633 == nil { ifn_3634 = lang.IFn_Cast(root_3632) } else { ifn_3634 = nil }; var arg_3635 any = s__1641000442__3; if linked_3633 == nil { tmp1 = ifn_3634.Invoke_O__O(arg_3635) } else { tmp1 = linked_3633.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3632, arg_3635) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3636 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_3637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3636, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3638 lang.IFn; if linked_3637 == nil { ifn_3638 = lang.IFn_Cast(root_3636) } else { ifn_3638 = nil }; var arg_3639 any = s__1641000442__3; if linked_3637 == nil { c__1927001037__auto____4 = ifn_3638.Invoke_O__O(arg_3639) } else { c__1927001037__auto____4 = linked_3637.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3636, arg_3639) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000444__6 any; var root_3640 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_3641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3640, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3642 lang.IFn; if linked_3641 == nil { ifn_3642 = lang.IFn_Cast(root_3640) } else { ifn_3642 = nil }; var arg_3643 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3641 == nil { b__1641000444__6 = ifn_3642.Invoke_O__O(arg_3643) } else { b__1641000444__6 = linked_3641.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3640, arg_3643) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3655 any = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A_New_O_I_O(b__1641000444__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3654 *jrt.Class = A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A_fn_class; if fncls__3654 == nil { var fncls__3654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_198, false, fnbody__3655); A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A_fn_class = fncls__3654d; tmp3 = fncls__3654d } else { tmp3 = fncls__3654 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3655, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3656 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_3657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3656, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3658 lang.IFn; if linked_3657 == nil { ifn_3658 = lang.IFn_Cast(root_3656) } else { ifn_3658 = nil }; var arg_3659 any; var root_3661 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_3662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3661, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3663 lang.IFn; if linked_3662 == nil { ifn_3663 = lang.IFn_Cast(root_3661) } else { ifn_3663 = nil }; var arg_3664 any = b__1641000444__6; if linked_3662 == nil { arg_3659 = ifn_3663.Invoke_O__O(arg_3664) } else { arg_3659 = linked_3662.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3661, arg_3664) }; var arg_3660 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000441); var tmp5 any; var root_3665 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_3666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3667 lang.IFn; if linked_3666 == nil { ifn_3667 = lang.IFn_Cast(root_3665) } else { ifn_3667 = nil }; var arg_3668 any = s__1641000442__3; if linked_3666 == nil { tmp5 = ifn_3667.Invoke_O__O(arg_3668) } else { tmp5 = linked_3666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3665, arg_3668) }; arg_3660 = tmp4.Invoke_O__O(tmp5); if linked_3657 == nil { return ifn_3658.Invoke_O_O__O(arg_3659, arg_3660) } else { return linked_3657.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3656, arg_3659, arg_3660) } } else { var root_3669 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_3670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3669, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3671 lang.IFn; if linked_3670 == nil { ifn_3671 = lang.IFn_Cast(root_3669) } else { ifn_3671 = nil }; var arg_3672 any; var root_3674 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_3675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3674, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3676 lang.IFn; if linked_3675 == nil { ifn_3676 = lang.IFn_Cast(root_3674) } else { ifn_3676 = nil }; var arg_3677 any = b__1641000444__6; if linked_3675 == nil { arg_3672 = ifn_3676.Invoke_O__O(arg_3677) } else { arg_3672 = linked_3675.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3674, arg_3677) }; var arg_3673 any; if linked_3670 == nil { return ifn_3671.Invoke_O_O__O(arg_3672, arg_3673) } else { return linked_3670.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3669, arg_3672, arg_3673) } } } else { var vec__1641000452__4 any; var root_3678 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3678, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3680 lang.IFn; if linked_3679 == nil { ifn_3680 = lang.IFn_Cast(root_3678) } else { ifn_3680 = nil }; var arg_3681 any = s__1641000442__3; if linked_3679 == nil { vec__1641000452__4 = ifn_3680.Invoke_O__O(arg_3681) } else { vec__1641000452__4 = linked_3679.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3678, arg_3681) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000452__4, lang.RT_IntCast_J__I_NoInit(0), nil); var init__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000452__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3682 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_3683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3682, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3684 lang.IFn; if linked_3683 == nil { ifn_3684 = lang.IFn_Cast(root_3682) } else { ifn_3684 = nil }; var arg_3685 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_469; var tmp8 any; var root_3687 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3687, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3689 lang.IFn; if linked_3688 == nil { ifn_3689 = lang.IFn_Cast(root_3687) } else { ifn_3689 = nil }; var arg_3690 any = k__5; var arg_3691 any = A_arbace_o2j_A_const_471; if linked_3688 == nil { tmp8 = ifn_3689.Invoke_O_O__O(arg_3690, arg_3691) } else { tmp8 = linked_3688.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3687, arg_3690, arg_3691) }; arg_3685 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, init__6); var arg_3686 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1641000441); var tmp10 any; var root_3692 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_3693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3692, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3694 lang.IFn; if linked_3693 == nil { ifn_3694 = lang.IFn_Cast(root_3692) } else { ifn_3694 = nil }; var arg_3695 any = s__1641000442__3; if linked_3693 == nil { tmp10 = ifn_3694.Invoke_O__O(arg_3695) } else { tmp10 = linked_3693.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3692, arg_3695) }; arg_3686 = tmp9.Invoke_O__O(tmp10); if linked_3683 == nil { return ifn_3684.Invoke_O_O__O(arg_3685, arg_3686) } else { return linked_3683.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3682, arg_3685, arg_3686) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :587:1
func A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A) Ctor_O_I_O(c__b__1641000444 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000444 = c__b__1641000444; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :587:1
func (t *A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A) Invoke_O__O(self any) any { { var i__1641000443__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000443__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1641000448__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000443__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000448__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000448__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3644 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3646 lang.IFn; if linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any = t.F_b__1641000444; var arg_3648 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_469; var tmp4 any; var root_3649 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3651 lang.IFn; if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any = k__3; var arg_3653 any = A_arbace_o2j_A_const_470; if linked_3650 == nil { tmp4 = ifn_3651.Invoke_O_O__O(arg_3652, arg_3653) } else { tmp4 = linked_3650.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3649, arg_3652, arg_3653) }; arg_3648 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, init__4); if linked_3645 == nil { ifn_3646.Invoke_O_O__O(arg_3647, arg_3648) } else { linked_3645.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3644, arg_3647, arg_3648) }; i__1641000443__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000443__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_o2j_main_forms_A_New() *A_arbace_o2j_main_forms_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_main_forms_A{}; t.Ctor(); return t }
//line :595:1
func (t *A_arbace_o2j_main_forms_A) Ctor() {}
//line :595:1
func (t *A_arbace_o2j_main_forms_A) Invoke_O_O__O(self, units__0 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_o2j_A_const_489, A_arbace_o2j_A_const_490); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_o2j_A_const_491; var tmp4 any; var root_3754 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3754, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3756 lang.IFn; if




	linked_3755 == nil { ifn_3756 = lang.IFn_Cast(root_3754) } else { ifn_3756 = nil }; var arg_3757 any = A_arbace_o2j_A_const_492; var arg_3758 any = A_arbace_o2j_A_const_493; if linked_3755 == nil { tmp4 = ifn_3756.Invoke_O_O__O(arg_3757, arg_3758) } else { tmp4 = linked_3755.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3754, arg_3757, arg_3758) }; var tmp5 any = tmp4; var tmp6 lang.IFn = /*line :595:1*/lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_o2j_A_const_494; var tmp8 any; var root_3759 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3759, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3761 lang.IFn; if





	linked_3760 == nil { ifn_3761 = lang.IFn_Cast(root_3759) } else { ifn_3761 = nil }; var arg_3762 any = A_arbace_o2j_A_const_495; var arg_3763 any = A_arbace_o2j_A_const_496; if linked_3760 == nil { tmp8 = ifn_3761.Invoke_O_O__O(arg_3762, arg_3763) } else { tmp8 = linked_3760.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3759, arg_3762, arg_3763) }; var tmp9 any = tmp8; var tmp10 any; var root_3764 any = /*line :595:1*/A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3766 lang.IFn; if





	linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any = lang.PersistentVector_EMPTY.Ref(); var arg_3768 any = A_arbace_o2j_A_const_497; if linked_3765 == nil { tmp10 = ifn_3766.Invoke_O_O__O(arg_3767, arg_3768) } else { tmp10 = linked_3765.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3764, arg_3767, arg_3768) }; var tmp11 any = tmp10; var tmp12 lang.IFn = /*line :595:1*/lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_o2j_A_const_498, A_arbace_o2j_A_const_499, lang.PersistentVector_EMPTY.Ref()); var tmp14 any; var iter__1927001039__auto____2 any; var fnbody__3854 any = A_arbace_o2j_main_forms_iter__1641000458__1641000462_A_New(); var tmp15 *jrt.Class; var fncls__3853 *jrt.Class = A_arbace_o2j_main_forms_iter__1641000458__1641000462_A_fn_class; if







	fncls__3853 == nil { var fncls__3853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_o2j_main_forms_iter__1641000458__1641000462_A_fn_class = fncls__3853d; tmp15 = fncls__3853d } else { tmp15 = fncls__3853 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3854, tmp15, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(units__0); var tmp16 any = /*line :595:1*/tmp6.Invoke_O_O_O_O__O(tmp7, tmp9, tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp14, A_arbace_o2j_A_const_500)); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_o2j_A_const_501; var tmp19 any; var root_3855 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3855, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3857 lang.IFn; if









	linked_3856 == nil { ifn_3857 = lang.IFn_Cast(root_3855) } else { ifn_3857 = nil }; var arg_3858 any = A_arbace_o2j_A_const_502; var arg_3859 any = A_arbace_o2j_A_const_503; if linked_3856 == nil { tmp19 = ifn_3857.Invoke_O_O__O(arg_3858, arg_3859) } else { tmp19 = linked_3856.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3855, arg_3858, arg_3859) }; var tmp20 any = tmp19; var tmp21 any; var root_3860 any = /*line :595:1*/A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3862 lang.IFn; if









	linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any; var tmp22 any; var root_3865 any = A_arbace_o2j_A_const_37.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = A_arbace_o2j_A_const_504; var arg_3869 any = A_arbace_o2j_A_const_505; if linked_3866 == nil { tmp22 = ifn_3867.Invoke_O_O__O(arg_3868, arg_3869) } else { tmp22 = linked_3866.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3865, arg_3868, arg_3869) }; arg_3863 = lang.Tuple_Create_O__IPersistentVector(tmp22); var arg_3864 any = A_arbace_o2j_A_const_506; if linked_3861 == nil { tmp21 = ifn_3862.Invoke_O_O__O(arg_3863, arg_3864) } else { tmp21 = linked_3861.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3860, arg_3863, arg_3864) }; var tmp23 lang.IFn = /*line :595:1*/lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp24 any = A_arbace_o2j_A_const_507; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_o2j_A_const_508; var tmp27 any = A_arbace_o2j_A_const_509; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O_O_O__O(tmp3, tmp5, tmp16, tmp17.Invoke_O_O_O_O__O(tmp18, tmp20, tmp21, tmp23.Invoke_O_O__O(tmp24, tmp25.Invoke_O_O_O__O(tmp26, tmp27, lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_o2j_A_const_510)))))) }







func A_arbace_o2j_main_forms_iter__1641000458__1641000462_A_New() *A_arbace_o2j_main_forms_iter__1641000458__1641000462_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_main_forms_iter__1641000458__1641000462_A{}; t.Ctor(); return t }
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_A) Ctor() {}
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_A) Invoke_O_O__O(self, s__1641000459__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3852 any = A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A_New_O_O(self, s__1641000459__1); var tmp2 *jrt.Class; var fncls__3851 *jrt.Class = A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A_fn_class; if fncls__3851 == nil { var fncls__3851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__3852); A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A_fn_class = fncls__3851d; tmp2 = fncls__3851d } else { tmp2 = fncls__3851 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3852, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :603:1
func A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A_New_O_O(p0, p1 any) *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A{}; t.Ctor_O_O(p0, p1); return t }
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A) Ctor_O_O(c__iter__1641000458, c__s__1641000459 any) { t.F_iter__1641000458 = c__iter__1641000458; t.F_s__1641000459 = c__s__1641000459 }
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A) Invoke_O__O(self any) any { { var s__1641000459__1 any; var t_ any = t.F_s__1641000459; t.F_s__1641000459 = nil; s__1641000459__1 = t_; for { var temp__1927000414__auto____2 any; var root_3775 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3777 lang.IFn; if linked_3776 == nil { ifn_3777 = lang.IFn_Cast(root_3775) } else { ifn_3777 = nil }; var arg_3778 any = s__1641000459__1; if linked_3776 == nil { temp__1927000414__auto____2 = ifn_3777.Invoke_O__O(arg_3778) } else { temp__1927000414__auto____2 = linked_3776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3775, arg_3778) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000459__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3779 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_3780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3779, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3781 lang.IFn; if linked_3780 == nil { ifn_3781 = lang.IFn_Cast(root_3779) } else { ifn_3781 = nil }; var arg_3782 any = s__1641000459__3; if linked_3780 == nil { tmp1 = ifn_3781.Invoke_O__O(arg_3782) } else { tmp1 = linked_3780.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3779, arg_3782) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3783 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_3784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3783, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3785 lang.IFn; if linked_3784 == nil { ifn_3785 = lang.IFn_Cast(root_3783) } else { ifn_3785 = nil }; var arg_3786 any = s__1641000459__3; if linked_3784 == nil { c__1927001037__auto____4 = ifn_3785.Invoke_O__O(arg_3786) } else { c__1927001037__auto____4 = linked_3784.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3783, arg_3786) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000461__6 any; var root_3787 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3789 lang.IFn; if linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3788 == nil { b__1641000461__6 = ifn_3789.Invoke_O__O(arg_3790) } else { b__1641000461__6 = linked_3788.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3787, arg_3790) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3806 any = A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A_New_I_O_O(size__1927001038__auto____5, b__1641000461__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3805 *jrt.Class = A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A_fn_class; if fncls__3805 == nil { var fncls__3805d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__3806); A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A_fn_class = fncls__3805d; tmp3 = fncls__3805d } else { tmp3 = fncls__3805 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3806, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3807 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any; var root_3812 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_3813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3812, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3814 lang.IFn; if linked_3813 == nil { ifn_3814 = lang.IFn_Cast(root_3812) } else { ifn_3814 = nil }; var arg_3815 any = b__1641000461__6; if linked_3813 == nil { arg_3810 = ifn_3814.Invoke_O__O(arg_3815) } else { arg_3810 = linked_3813.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3812, arg_3815) }; var arg_3811 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000458); var tmp5 any; var root_3816 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_3817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3816, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3818 lang.IFn; if linked_3817 == nil { ifn_3818 = lang.IFn_Cast(root_3816) } else { ifn_3818 = nil }; var arg_3819 any = s__1641000459__3; if linked_3817 == nil { tmp5 = ifn_3818.Invoke_O__O(arg_3819) } else { tmp5 = linked_3817.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3816, arg_3819) }; arg_3811 = tmp4.Invoke_O__O(tmp5); if linked_3808 == nil { return ifn_3809.Invoke_O_O__O(arg_3810, arg_3811) } else { return linked_3808.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3807, arg_3810, arg_3811) } } else { var root_3820 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_3821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3820, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3822 lang.IFn; if linked_3821 == nil { ifn_3822 = lang.IFn_Cast(root_3820) } else { ifn_3822 = nil }; var arg_3823 any; var root_3825 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = b__1641000461__6; if linked_3826 == nil { arg_3823 = ifn_3827.Invoke_O__O(arg_3828) } else { arg_3823 = linked_3826.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3825, arg_3828) }; var arg_3824 any; if linked_3821 == nil { return ifn_3822.Invoke_O_O__O(arg_3823, arg_3824) } else { return linked_3821.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3820, arg_3823, arg_3824) } } } else { var u__4 any; var root_3829 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3831 lang.IFn; if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = s__1641000459__3; if linked_3830 == nil { u__4 = ifn_3831.Invoke_O__O(arg_3832) } else { u__4 = linked_3830.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3829, arg_3832) }; var root_3833 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_3834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3833, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3835 lang.IFn; if linked_3834 == nil { ifn_3835 = lang.IFn_Cast(root_3833) } else { ifn_3835 = nil }; var arg_3836 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp7 any; var root_3838 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_3839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3838, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3840 lang.IFn; if linked_3839 == nil { ifn_3840 = lang.IFn_Cast(root_3838) } else { ifn_3840 = nil }; var arg_3841 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil); var tmp9 any; var root_3843 any = A_arbace_o2j_A_const_344.GetRawRoot__O(); var linked_3844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3843, A_arbace_o2j_class_name_A_fn_class); var ifn_3845 lang.IFn; if linked_3844 == nil { ifn_3845 = lang.IFn_Cast(root_3843) } else { ifn_3845 = nil }; var arg_3846 any = u__4; if linked_3844 == nil { tmp9 = ifn_3845.Invoke_O__O(arg_3846) } else { tmp9 = linked_3844.(*A_arbace_o2j_class_name_A).Invoke_O_O__O(root_3843, arg_3846) }; arg_3841 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9)).Ref(); var arg_3842 any = Lit_110; if linked_3839 == nil { tmp7 = ifn_3840.Invoke_O_O__O(arg_3841, arg_3842) } else { tmp7 = linked_3839.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_3838, arg_3841, arg_3842) }; arg_3836 = tmp6.Invoke_O__O(tmp7); var arg_3837 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1641000458); var tmp11 any; var root_3847 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_3848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3847, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3849 lang.IFn; if linked_3848 == nil { ifn_3849 = lang.IFn_Cast(root_3847) } else { ifn_3849 = nil }; var arg_3850 any = s__1641000459__3; if linked_3848 == nil { tmp11 = ifn_3849.Invoke_O__O(arg_3850) } else { tmp11 = linked_3848.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3847, arg_3850) }; arg_3837 = tmp10.Invoke_O__O(tmp11); if linked_3834 == nil { return ifn_3835.Invoke_O_O__O(arg_3836, arg_3837) } else { return linked_3834.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3833, arg_3836, arg_3837) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :603:1
func A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1641000461, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1641000461 = c__b__1641000461; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :603:1
func (t *A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A) Invoke_O__O(self any) any { { var i__1641000460__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000460__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000460__1)); var root_3791 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3793 lang.IFn; if linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any = t.F_b__1641000461; var arg_3795 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_39.GetRawRoot__O()); var tmp3 any; var root_3796 any = A_arbace_o2j_A_const_45.GetRawRoot__O(); var linked_3797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3796, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3798 lang.IFn; if linked_3797 == nil { ifn_3798 = lang.IFn_Cast(root_3796) } else { ifn_3798 = nil }; var arg_3799 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil); var tmp5 any; var root_3801 any = A_arbace_o2j_A_const_344.GetRawRoot__O(); var linked_3802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3801, A_arbace_o2j_class_name_A_fn_class); var ifn_3803 lang.IFn; if linked_3802 == nil { ifn_3803 = lang.IFn_Cast(root_3801) } else { ifn_3803 = nil }; var arg_3804 any = u__2; if linked_3802 == nil { tmp5 = ifn_3803.Invoke_O__O(arg_3804) } else { tmp5 = linked_3802.(*A_arbace_o2j_class_name_A).Invoke_O_O__O(root_3801, arg_3804) }; arg_3799 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref(); var arg_3800 any = Lit_110; if linked_3797 == nil { tmp3 = ifn_3798.Invoke_O_O__O(arg_3799, arg_3800) } else { tmp3 = linked_3797.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_3796, arg_3799, arg_3800) }; arg_3795 = tmp2.Invoke_O__O(tmp3); if linked_3792 == nil { ifn_3793.Invoke_O_O__O(arg_3794, arg_3795) } else { linked_3792.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3791, arg_3794, arg_3795) }; i__1641000460__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000460__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_o2j_write_forms_A_New() *A_arbace_o2j_write_forms_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_write_forms_A{}; t.Ctor(); return t }
//line :608:1
func (t *A_arbace_o2j_write_forms_A) Ctor() {}
//line :608:1
func (t *A_arbace_o2j_write_forms_A) Invoke_O_O_O_O__O(self, f__0, forms__1, header__2 any) any {
	lang.IFn_Cast(A_arbace_o2j_A_const_512.GetRawRoot__O()).Invoke_O__O(f__0)
//line :608:1
	var w__4 any = lang.IFn_Cast(A_arbace_o2j_A_const_511.GetRawRoot__O()).Invoke_O__O(f__0); var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var root_3901 any = A_arbace_o2j_A_const_479.GetRawRoot__O(); var linked_3902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3901, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3903 lang.IFn; if linked_3902 == nil { ifn_3903 = lang.IFn_Cast(root_3901) } else { ifn_3903 = nil }; var arg_3904 any = lang.IFn_Cast(A_arbace_o2j_A_const_480.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_o2j_A_const_513, w__4, A_arbace_o2j_A_const_514, jrt.Boolean_TRUE.Ref(), A_arbace_o2j_A_const_515, nil, A_arbace_o2j_A_const_516, nil); if linked_3902 == nil { ifn_3903.Invoke_O__O(arg_3904) } else { linked_3902.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3901, arg_3904) }; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_207, nil), jrt.RefArrayOf(jrt.Object_class, nil, header__2)).Ref())
//line :608:1
			{ var seq_1641000469__9 any; var root_3874 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3874, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3876 lang.IFn




				if linked_3875 == nil { ifn_3876 = lang.IFn_Cast(root_3874) } else { ifn_3876 = nil }; var arg_3877 any = forms__1; if linked_3875 == nil { seq_1641000469__9 = ifn_3876.Invoke_O__O(arg_3877) } else { seq_1641000469__9 = linked_3875.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3874, arg_3877) }
//line :608:1
				var chunk_1641000470__10 any; var count_1641000471__11 int64 = 0; var i_1641000472__12 int64 = 0; L1: for {




					if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000472__12, count_1641000471__11) { var x__13 any = lang.Indexed_Cast(chunk_1641000470__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000472__12)); var root_3924 any = A_arbace_o2j_A_const_519.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3924, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_3926 lang.IFn; if linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; if linked_3925 == nil { ifn_3926.Invoke__O() } else { linked_3925.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_3924) }; lang.IFn_Cast(A_arbace_o2j_A_const_518.GetRawRoot__O()).Invoke_O__O(x__13); seq_1641000469__9, chunk_1641000470__10, count_1641000471__11, i_1641000472__12 = seq_1641000469__9, chunk_1641000470__10, count_1641000471__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000472__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_3878 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_3879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3878, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3880 lang.IFn; if linked_3879 == nil { ifn_3880 = lang.IFn_Cast(root_3878) } else { ifn_3880 = nil }; var arg_3881 any = seq_1641000469__9; if linked_3879 == nil { temp__1927000414__auto____13 = ifn_3880.Invoke_O__O(arg_3881) } else { temp__1927000414__auto____13 = linked_3879.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3878, arg_3881) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1641000469__14 any = temp__1927000414__auto____13; var tmp2 any; var root_3882 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_3883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3882, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3884 lang.IFn; if linked_3883 == nil { ifn_3884 = lang.IFn_Cast(root_3882) } else { ifn_3884 = nil }; var arg_3885 any = seq_1641000469__14; if linked_3883 == nil { tmp2 = ifn_3884.Invoke_O__O(arg_3885) } else { tmp2 = linked_3883.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3882, arg_3885) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____15 any; var root_3886 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3886, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3888 lang.IFn; if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = seq_1641000469__14; if linked_3887 == nil { c__1927000678__auto____15 = ifn_3888.Invoke_O__O(arg_3889) } else { c__1927000678__auto____15 = linked_3887.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3886, arg_3889) }; var tmp3 any; var root_3927 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = seq_1641000469__14; if linked_3928 == nil { tmp3 = ifn_3929.Invoke_O__O(arg_3930) } else { tmp3 = linked_3928.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3927, arg_3930) }; seq_1641000469__9, chunk_1641000470__10, count_1641000471__11, i_1641000472__12 = tmp3, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__15 any; var root_3890 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3890, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3892 lang.IFn; if linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; var arg_3893 any = seq_1641000469__14; if linked_3891 == nil { x__15 = ifn_3892.Invoke_O__O(arg_3893) } else { x__15 = linked_3891.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3890, arg_3893) }; var root_3935 any = A_arbace_o2j_A_const_519.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_3937 lang.IFn; if linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; if linked_3936 == nil { ifn_3937.Invoke__O() } else { linked_3936.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_3935) }; lang.IFn_Cast(A_arbace_o2j_A_const_518.GetRawRoot__O()).Invoke_O__O(x__15); var tmp4 any; var root_3938 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_3939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3938, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3940 lang.IFn; if linked_3939 == nil { ifn_3940 = lang.IFn_Cast(root_3938) } else { ifn_3940 = nil }; var arg_3941 any = seq_1641000469__14; if linked_3939 == nil { tmp4 = ifn_3940.Invoke_O__O(arg_3941) } else { tmp4 = linked_3939.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3938, arg_3941) }; seq_1641000469__9, chunk_1641000470__10, count_1641000471__11, i_1641000472__12 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :608:1
					break L1
				}
			}
			return nil }(); var root_3894 any = A_arbace_o2j_A_const_478.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3896 lang.IFn; if linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; if linked_3895 == nil { ifn_3896.Invoke__O() } else { linked_3895.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3894) }
//line :608:1
			if tmp5 != nil { panic(tmp5) } }; return nil
	}()
	jrt.Writer_Cast(w__4).Close__V()
//line :608:1
	if tmp6 != nil { panic(tmp6) }; return tmp1
}








func A_arbace_o2j_unit_refs_A_New() *A_arbace_o2j_unit_refs_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_unit_refs_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_o2j_unit_refs_A) Ctor() {}
//line :618:1
func (t *A_arbace_o2j_unit_refs_A) Invoke_O_O__O(self, u__0 any) any { var acc__2 any; var root_3942 any = A_arbace_o2j_A_const_126.GetRawRoot__O(); var linked_3943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3942, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_3944 lang.IFn; if


	linked_3943 == nil { ifn_3944 = lang.IFn_Cast(root_3942) } else { ifn_3944 = nil }; var arg_3945 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_3943 == nil { acc__2 = ifn_3944.Invoke_O__O(arg_3945) } else { acc__2 = linked_3943.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_3942, arg_3945) }; var body_walk__3 /*line :618:1*/*A_arbace_o2j_unit_refs_walk__1641000474_A = A_arbace_o2j_unit_refs_walk__1641000474_A_New_O(acc__2); var walk__3 any; var fnbody__4026 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__4025 *jrt.Class = A_arbace_o2j_unit_refs_walk__1641000474_A_fn_class; if fncls__4025 == nil { var fncls__4025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_200, false, fnbody__4026); A_arbace_o2j_unit_refs_walk__1641000474_A_fn_class = fncls__4025d; tmp1 = fncls__4025d } else { tmp1 = fncls__4025 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4026, tmp1, nil);









	lang.IFn_Cast(walk__3).Invoke_O__O(A_arbace_o2j_A_const_20.Invoke_O__O(u__0)); var root_3946 any =
	A_arbace_o2j_A_const_153.GetRawRoot__O(); var linked_3947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3946, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3948 lang.IFn; if linked_3947 == nil { ifn_3948 = lang.IFn_Cast(root_3946) } else { ifn_3948 = nil }; var arg_3949 any; var root_3950 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_3951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3950, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3952 lang.IFn; if linked_3951 == nil { ifn_3952 = lang.IFn_Cast(root_3950) } else { ifn_3952 = nil }; var arg_3953 any; var root_3954 any = A_arbace_o2j_A_const_520.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_3956 lang.IFn; if linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any; var root_3959 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_3960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3959, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3961 lang.IFn; if linked_3960 == nil { ifn_3961 = lang.IFn_Cast(root_3959) } else { ifn_3961 = nil }; var arg_3962 any; var root_3964 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_3965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3964, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3966 lang.IFn; if linked_3965 == nil { ifn_3966 = lang.IFn_Cast(root_3964) } else { ifn_3966 = nil }; var arg_3967 any = acc__2; if linked_3965 == nil { arg_3962 = ifn_3966.Invoke_O__O(arg_3967) } else { arg_3962 = linked_3965.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3964, arg_3967) }; var arg_3963 any = A_arbace_o2j_A_const_19.Invoke_O__O(u__0); if linked_3960 == nil { arg_3957 = ifn_3961.Invoke_O_O__O(arg_3962, arg_3963) } else { arg_3957 = linked_3960.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3959, arg_3962, arg_3963) }; var arg_3958 any = A_arbace_o2j_A_const_21.Invoke_O__O(u__0); if linked_3955 == nil { arg_3953 = ifn_3956.Invoke_O_O__O(arg_3957, arg_3958) } else { arg_3953 = linked_3955.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_3954, arg_3957, arg_3958) }; if linked_3951 == nil { arg_3949 = ifn_3952.Invoke_O__O(arg_3953) } else { arg_3949 = linked_3951.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3950, arg_3953) }; if linked_3947 == nil { return ifn_3948.Invoke_O__O(arg_3949) } else { return linked_3947.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3946, arg_3949) } }
//line :622:1
func A_arbace_o2j_unit_refs_walk__1641000474_A_New_O(p0 any) *A_arbace_o2j_unit_refs_walk__1641000474_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_unit_refs_walk__1641000474_A{}; t.Ctor_O(p0); return t }
//line :622:1
func (t *A_arbace_o2j_unit_refs_walk__1641000474_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :622:1
func (t *A_arbace_o2j_unit_refs_walk__1641000474_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var root_3968 any = A_arbace_o2j_A_const_25.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3968, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3970 lang.IFn; if linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; var arg_3971 any = x__1; if linked_3969 == nil { tmp1 = ifn_3970.Invoke_O__O(arg_3971) } else { tmp1 = linked_3969.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3968, arg_3971) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any = A_arbace_o2j_A_const_522; var tmp4 any; var root_3986 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_3987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3988 lang.IFn; if linked_3987 == nil { ifn_3988 = lang.IFn_Cast(root_3986) } else { ifn_3988 = nil }; var arg_3989 any = x__1; if linked_3987 == nil { tmp4 = ifn_3988.Invoke_O__O(arg_3989) } else { tmp4 = linked_3987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3986, arg_3989) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_3990 any = A_arbace_o2j_A_const_88.GetRawRoot__O(); var linked_3991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3990, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_3992 lang.IFn; if linked_3991 == nil { ifn_3992 = lang.IFn_Cast(root_3990) } else { ifn_3992 = nil }; var arg_3993 any; var root_3994 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = x__1; if linked_3995 == nil { arg_3993 = ifn_3996.Invoke_O__O(arg_3997) } else { arg_3993 = linked_3995.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3994, arg_3997) }; if linked_3991 == nil { and__1927000168__auto____3 = ifn_3992.Invoke_O__O(arg_3993) } else { and__1927000168__auto____3 = linked_3991.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_3990, arg_3993) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_3998 any = A_arbace_o2j_A_const_14.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_4000 lang.IFn; if linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any; var root_4003 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_4004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4003, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4005 lang.IFn; if linked_4004 == nil { ifn_4005 = lang.IFn_Cast(root_4003) } else { ifn_4005 = nil }; var arg_4006 any = x__1; if linked_4004 == nil { arg_4001 = ifn_4005.Invoke_O__O(arg_4006) } else { arg_4001 = linked_4004.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4003, arg_4006) }; var arg_4002 any = Lit_116; if linked_3999 == nil { tmp2 = ifn_4000.Invoke_O_O__O(arg_4001, arg_4002) } else { tmp2 = linked_3999.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3998, arg_4001, arg_4002) } } else { tmp2 = and__1927000168__auto____3 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) { var g__2 any; var root_4007 any = A_arbace_o2j_A_const_341.GetRawRoot__O(); var linked_4008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4007, A_arbace_o2j_global_name_A_fn_class); var ifn_4009 lang.IFn
		if linked_4008 == nil { ifn_4009 = lang.IFn_Cast(root_4007) } else { ifn_4009 = nil }; var arg_4010 any; var root_4011 any = A_arbace_o2j_A_const_15.GetRawRoot__O(); var linked_4012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4011, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_4013 lang.IFn; if linked_4012 == nil { ifn_4013 = lang.IFn_Cast(root_4011) } else { ifn_4013 = nil }; var arg_4014 any; var root_4016 any = A_arbace_o2j_A_const_12.GetRawRoot__O(); var linked_4017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4016, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4018 lang.IFn; if linked_4017 == nil { ifn_4018 = lang.IFn_Cast(root_4016) } else { ifn_4018 = nil }; var arg_4019 any = x__1; if linked_4017 == nil { arg_4014 = ifn_4018.Invoke_O__O(arg_4019) } else { arg_4014 = linked_4017.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4016, arg_4019) }; var arg_4015 any = A_arbace_o2j_A_const_342; if linked_4012 == nil { arg_4010 = ifn_4013.Invoke_O_O__O(arg_4014, arg_4015) } else { arg_4010 = linked_4012.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_4011, arg_4014, arg_4015) }; if linked_4008 == nil { g__2 = ifn_4009.Invoke_O__O(arg_4010) } else { g__2 = linked_4008.(*A_arbace_o2j_global_name_A).Invoke_O_O__O(root_4007, arg_4010) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_o2j_A_const_343.GetRawRoot__O()).Invoke_O__O(g__2)) { } else { var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp6 any; var root_4020 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_4021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4020, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_4022 lang.IFn; if linked_4021 == nil { ifn_4022 = lang.IFn_Cast(root_4020) } else { ifn_4022 = nil }; var arg_4023 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_4024 any = g__2; if linked_4021 == nil { tmp6 = ifn_4022.Invoke_O_O__O(arg_4023, arg_4024) } else { tmp6 = linked_4021.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_4020, arg_4023, arg_4024) }; jrt.NN(tmp5).Reset_O__O(tmp6) } }
		var root_3972 any = A_arbace_o2j_A_const_521.GetRawRoot__O(); var linked_3973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3972, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3974 lang.IFn; if linked_3973 == nil { ifn_3974 = lang.IFn_Cast(root_3972) } else { ifn_3974 = nil }; var arg_3975 any = self; var arg_3976 any = x__1; if linked_3973 == nil { return ifn_3974.Invoke_O_O__O(arg_3975, arg_3976) } else { return linked_3973.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3972, arg_3975, arg_3976) } } else {
//line :623:1
			var tmp7 any; var root_3977 any = A_arbace_o2j_A_const_42.GetRawRoot__O(); var linked_3978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3977, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_3979 lang.IFn



			if linked_3978 == nil { ifn_3979 = lang.IFn_Cast(root_3977) } else { ifn_3979 = nil }; var arg_3980 any = x__1; if linked_3978 == nil { tmp7 = ifn_3979.Invoke_O__O(arg_3980) } else { tmp7 = linked_3978.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_3977, arg_3980) }
//line :623:1
			if jrt.J2g_Truth(tmp7) {



				var root_3981 any = A_arbace_o2j_A_const_521.GetRawRoot__O(); var linked_3982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3981, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_3983 lang.IFn; if linked_3982 == nil { ifn_3983 = lang.IFn_Cast(root_3981) } else { ifn_3983 = nil }; var arg_3984 any = self; var arg_3985 any = x__1; if linked_3982 == nil { return ifn_3983.Invoke_O_O__O(arg_3984, arg_3985) } else { return linked_3982.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_3981, arg_3984, arg_3985) } } else {
//line :623:1
					return nil
				}
		}
}




func A_arbace_o2j_link_A_New() *A_arbace_o2j_link_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_link_A{}; t.Ctor(); return t }
//line :631:1
func (t *A_arbace_o2j_link_A) Ctor() {}
//line :631:1
func (t *A_arbace_o2j_link_A) Invoke_O_O_O_O__O(self, lib_order__0, deps__1, prog_units__2 any) any { var progs__4 any; var root_4027 any = A_arbace_o2j_A_const_152.GetRawRoot__O(); var linked_4028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4027, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_4029 lang.IFn; if


	linked_4028 == nil { ifn_4029 = lang.IFn_Cast(root_4027) } else { ifn_4029 = nil }; var arg_4030 any; var root_4031 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_4032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4031, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4033 lang.IFn; if linked_4032 == nil { ifn_4033 = lang.IFn_Cast(root_4031) } else { ifn_4033 = nil }; var arg_4034 any = A_arbace_o2j_A_const_21; var arg_4035 any = prog_units__2; if linked_4032 == nil { arg_4030 = ifn_4033.Invoke_O_O__O(arg_4034, arg_4035) } else { arg_4030 = linked_4032.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4031, arg_4034, arg_4035) }; if linked_4028 == nil { progs__4 = ifn_4029.Invoke_O__O(arg_4030) } else { progs__4 = linked_4028.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_4027, arg_4030) }; var need__5 any; var root_4036 any = /*line :631:1*/A_arbace_o2j_A_const_126.GetRawRoot__O(); var linked_4037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4036, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_4038 lang.IFn; if



	linked_4037 == nil { ifn_4038 = lang.IFn_Cast(root_4036) } else { ifn_4038 = nil }; var arg_4039 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_4037 == nil { need__5 = ifn_4038.Invoke_O__O(arg_4039) } else { need__5 = linked_4037.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_4036, arg_4039) }; var body_visit__6 /*line :631:1*/*A_arbace_o2j_link_visit__1641000477_A = A_arbace_o2j_link_visit__1641000477_A_New_O_O_O(deps__1, need__5, progs__4); var visit__6 any; var fnbody__4074 any = any(body_visit__6); var tmp1 *jrt.Class; var fncls__4073 *jrt.Class = A_arbace_o2j_link_visit__1641000477_A_fn_class; if fncls__4073 == nil { var fncls__4073d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__4074); A_arbace_o2j_link_visit__1641000477_A_fn_class = fncls__4073d; tmp1 = fncls__4073d } else { tmp1 = fncls__4073 }; visit__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4074, tmp1, nil); var seq_1641000479__7 any; var root_4075 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4075, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4077 lang.IFn; if









	linked_4076 == nil { ifn_4077 = lang.IFn_Cast(root_4075) } else { ifn_4077 = nil }; var arg_4078 any = prog_units__2; if linked_4076 == nil { seq_1641000479__7 = ifn_4077.Invoke_O__O(arg_4078) } else { seq_1641000479__7 = linked_4076.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4075, arg_4078) }; var chunk_1641000480__8 any; var count_1641000481__9 int64 = 0; var i_1641000482__10 int64 = 0; L1:
//line :631:1
	for {









		if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000482__10, count_1641000481__9) { var u__11 any = lang.Indexed_Cast(chunk_1641000480__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000482__10)); var root_4095 any = A_arbace_o2j_A_const_521.GetRawRoot__O(); var linked_4096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4095, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_4097 lang.IFn; if linked_4096 == nil { ifn_4097 = lang.IFn_Cast(root_4095) } else { ifn_4097 = nil }; var arg_4098 any = visit__6; var arg_4099 any; var root_4100 any = A_arbace_o2j_A_const_526.GetRawRoot__O(); var linked_4101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4100, A_arbace_o2j_unit_refs_A_fn_class); var ifn_4102 lang.IFn; if linked_4101 == nil { ifn_4102 = lang.IFn_Cast(root_4100) } else { ifn_4102 = nil }; var arg_4103 any = u__11; if linked_4101 == nil { arg_4099 = ifn_4102.Invoke_O__O(arg_4103) } else { arg_4099 = linked_4101.(*A_arbace_o2j_unit_refs_A).Invoke_O_O__O(root_4100, arg_4103) }; if linked_4096 == nil { ifn_4097.Invoke_O_O__O(arg_4098, arg_4099) } else { linked_4096.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_4095, arg_4098, arg_4099) }; seq_1641000479__7, chunk_1641000480__8, count_1641000481__9, i_1641000482__10 = seq_1641000479__7, chunk_1641000480__8, count_1641000481__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000482__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_4079 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4079, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4081 lang.IFn; if linked_4080 == nil { ifn_4081 = lang.IFn_Cast(root_4079) } else { ifn_4081 = nil }; var arg_4082 any = seq_1641000479__7; if linked_4080 == nil { temp__1927000414__auto____11 = ifn_4081.Invoke_O__O(arg_4082) } else { temp__1927000414__auto____11 = linked_4080.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4079, arg_4082) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1641000479__12 any = temp__1927000414__auto____11; var tmp2 any; var root_4083 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4083, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4085 lang.IFn; if linked_4084 == nil { ifn_4085 = lang.IFn_Cast(root_4083) } else { ifn_4085 = nil }; var arg_4086 any = seq_1641000479__12; if linked_4084 == nil { tmp2 = ifn_4085.Invoke_O__O(arg_4086) } else { tmp2 = linked_4084.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4083, arg_4086) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_4087 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4087, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4089 lang.IFn; if linked_4088 == nil { ifn_4089 = lang.IFn_Cast(root_4087) } else { ifn_4089 = nil }; var arg_4090 any = seq_1641000479__12; if linked_4088 == nil { c__1927000678__auto____13 = ifn_4089.Invoke_O__O(arg_4090) } else { c__1927000678__auto____13 = linked_4088.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4087, arg_4090) }; var tmp3 any; var root_4104 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4104, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4106 lang.IFn; if linked_4105 == nil { ifn_4106 = lang.IFn_Cast(root_4104) } else { ifn_4106 = nil }; var arg_4107 any = seq_1641000479__12; if linked_4105 == nil { tmp3 = ifn_4106.Invoke_O__O(arg_4107) } else { tmp3 = linked_4105.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4104, arg_4107) }; seq_1641000479__7, chunk_1641000480__8, count_1641000481__9, i_1641000482__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var u__13 any; var root_4091 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4091, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4093 lang.IFn; if linked_4092 == nil { ifn_4093 = lang.IFn_Cast(root_4091) } else { ifn_4093 = nil }; var arg_4094 any = seq_1641000479__12; if linked_4092 == nil { u__13 = ifn_4093.Invoke_O__O(arg_4094) } else { u__13 = linked_4092.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4091, arg_4094) }; var root_4108 any = A_arbace_o2j_A_const_521.GetRawRoot__O(); var linked_4109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4108, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_4110 lang.IFn; if linked_4109 == nil { ifn_4110 = lang.IFn_Cast(root_4108) } else { ifn_4110 = nil }; var arg_4111 any = visit__6; var arg_4112 any; var root_4113 any = A_arbace_o2j_A_const_526.GetRawRoot__O(); var linked_4114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4113, A_arbace_o2j_unit_refs_A_fn_class); var ifn_4115 lang.IFn; if linked_4114 == nil { ifn_4115 = lang.IFn_Cast(root_4113) } else { ifn_4115 = nil }; var arg_4116 any = u__13; if linked_4114 == nil { arg_4112 = ifn_4115.Invoke_O__O(arg_4116) } else { arg_4112 = linked_4114.(*A_arbace_o2j_unit_refs_A).Invoke_O_O__O(root_4113, arg_4116) }; if linked_4109 == nil { ifn_4110.Invoke_O_O__O(arg_4111, arg_4112) } else { linked_4109.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_4108, arg_4111, arg_4112) }; var tmp4 any; var root_4117 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4117, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4119 lang.IFn; if linked_4118 == nil { ifn_4119 = lang.IFn_Cast(root_4117) } else { ifn_4119 = nil }; var arg_4120 any = seq_1641000479__12; if linked_4118 == nil { tmp4 = ifn_4119.Invoke_O__O(arg_4120) } else { tmp4 = linked_4118.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4117, arg_4120) }; seq_1641000479__7, chunk_1641000480__8, count_1641000481__9, i_1641000482__10 = tmp4, nil, 0, 0; continue L1 } } }
//line :631:1
		break L1 }; var root_4040 any =










	A_arbace_o2j_A_const_523.GetRawRoot__O(); var linked_4041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4040, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_4042 lang.IFn; if linked_4041 == nil { ifn_4042 = lang.IFn_Cast(root_4040) } else { ifn_4042 = nil }; var arg_4043 any; var root_4045 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4045, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = need__5; if linked_4046 == nil { arg_4043 = ifn_4047.Invoke_O__O(arg_4048) } else { arg_4043 = linked_4046.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4045, arg_4048) }; var arg_4044 any = lib_order__0; if linked_4041 == nil { return ifn_4042.Invoke_O_O__O(arg_4043, arg_4044) } else { return linked_4041.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_4040, arg_4043, arg_4044) } }
//line :636:1
func A_arbace_o2j_link_visit__1641000477_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_link_visit__1641000477_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_link_visit__1641000477_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :636:1
func (t *A_arbace_o2j_link_visit__1641000477_A) Ctor_O_O_O(c__deps, c__need, c__progs any) { t.F_deps = c__deps; t.F_need = c__need; t.F_progs = c__progs }
//line :636:1
func (t *A_arbace_o2j_link_visit__1641000477_A) Invoke_O_O__O(self, n__1 any) any {
	var tmp1 any; var or__1927000174__auto____2 any; var tmp2 any; var root_4049 any = A_arbace_o2j_A_const_6.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = t.F_need; if linked_4050 == nil { tmp2 = ifn_4051.Invoke_O__O(arg_4052) } else { tmp2 = linked_4050.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4049, arg_4052) }; or__1927000174__auto____2 = lang.IFn_Cast(tmp2).Invoke_O__O(n__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.IFn_Cast(t.F_progs).Invoke_O__O(n__1) }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var tmp3 any; var root_4058 any = A_arbace_o2j_A_const_524.GetRawRoot__O(); var linked_4059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4058, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_4060 lang.IFn; if linked_4059 == nil { ifn_4060 = lang.IFn_Cast(root_4058) } else { ifn_4060 = nil }; var arg_4061 any = t.F_deps; var arg_4062 any = n__1; if linked_4059 == nil { tmp3 = ifn_4060.Invoke_O_O__O(arg_4061, arg_4062) } else { tmp3 = linked_4059.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_4058, arg_4061, arg_4062) }; if jrt.J2g_Truth(tmp3) { } else { var tmp4 any; var root_4063 any = A_arbace_o2j_A_const_28.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4063, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_4065 lang.IFn; if linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, nil, n__1, nil)).Ref(); var arg_4067 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_525, n__1)); if linked_4064 == nil { tmp4 = ifn_4065.Invoke_O_O__O(arg_4066, arg_4067) } else { tmp4 = linked_4064.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_4063, arg_4066, arg_4067) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
		var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_need); var tmp6 any; var root_4068 any = A_arbace_o2j_A_const_8.GetRawRoot__O(); var linked_4069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4068, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_4070 lang.IFn; if linked_4069 == nil { ifn_4070 = lang.IFn_Cast(root_4068) } else { ifn_4070 = nil }; var arg_4071 any = jrt.NN(lang.Volatile_Cast(t.F_need)).Deref__O(); var arg_4072 any = n__1; if linked_4069 == nil { tmp6 = ifn_4070.Invoke_O_O__O(arg_4071, arg_4072) } else { tmp6 = linked_4069.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_4068, arg_4071, arg_4072) }; jrt.NN(tmp5).Reset_O__O(tmp6)
		var root_4053 any = A_arbace_o2j_A_const_521.GetRawRoot__O(); var linked_4054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4053, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_4055 lang.IFn; if linked_4054 == nil { ifn_4055 = lang.IFn_Cast(root_4053) } else { ifn_4055 = nil }; var arg_4056 any = self; var arg_4057 any = lang.IFn_Cast(t.F_deps).Invoke_O__O(n__1); if linked_4054 == nil { return ifn_4055.Invoke_O_O__O(arg_4056, arg_4057) } else { return linked_4054.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_4053, arg_4056, arg_4057)
		}
	}
}
func A_arbace_o2j_translate_program_A_New() *A_arbace_o2j_translate_program_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_o2j_translate_program_A) Ctor() {}
//line :644:1
func (t *A_arbace_o2j_translate_program_A) Invoke_O_O_O_O__O(self, lo__0, od__1, dumps__2 any) any { var map__1641000485__4 any; var root_4121 any = A_arbace_o2j_A_const_527.GetRawRoot__O(); var linked_4122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4121, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4123 lang.IFn; if



	linked_4122 == nil { ifn_4123 = lang.IFn_Cast(root_4121) } else { ifn_4123 = nil }; var arg_4124 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_528.GetRawRoot__O()); var tmp2 any; var root_4129 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4129, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4131 lang.IFn; if linked_4130 == nil { ifn_4131 = lang.IFn_Cast(root_4129) } else { ifn_4131 = nil }; var arg_4132 any = lo__0; var arg_4133 any = Lit_14; if linked_4130 == nil { tmp2 = ifn_4131.Invoke_O_O__O(arg_4132, arg_4133) } else { tmp2 = linked_4130.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4129, arg_4132, arg_4133) }; arg_4124 = tmp1.Invoke_O__O(tmp2); if linked_4122 == nil { map__1641000485__4 = ifn_4123.Invoke_O__O(arg_4124) } else { map__1641000485__4 = linked_4122.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4121, arg_4124) }; var map__1641000485__5 any; if lang.ISeq_InstanceOf(map__1641000485__4) { var tmp3 any; var root_4134 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4134, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4136 lang.IFn; if linked_4135 == nil { ifn_4136 = lang.IFn_Cast(root_4134) } else { ifn_4136 = nil }; var arg_4137 any = map__1641000485__4; if linked_4135 == nil { tmp3 = ifn_4136.Invoke_O__O(arg_4137) } else { tmp3 = linked_4135.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4134, arg_4137) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_4138 any = A_arbace_o2j_A_const_389.GetRawRoot__O(); var linked_4139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4138, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4140 lang.IFn; if linked_4139 == nil { ifn_4140 = lang.IFn_Cast(root_4138) } else { ifn_4140 = nil }; var arg_4141 any = map__1641000485__4; if linked_4139 == nil { tmp4 = ifn_4140.Invoke_O__O(arg_4141) } else { tmp4 = linked_4139.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4138, arg_4141) }; map__1641000485__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp4)).Ref() } else { var tmp5 any; var root_4142 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4142, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4144 lang.IFn; if linked_4143 == nil { ifn_4144 = lang.IFn_Cast(root_4142) } else { ifn_4144 = nil }; var arg_4145 any = map__1641000485__4; if linked_4143 == nil { tmp5 = ifn_4144.Invoke_O__O(arg_4145) } else { tmp5 = linked_4143.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4142, arg_4145) }; if jrt.J2g_Truth(tmp5) { var root_4146 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4148 lang.IFn; if linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any = map__1641000485__4; if linked_4147 == nil { map__1641000485__5 = ifn_4148.Invoke_O__O(arg_4149) } else { map__1641000485__5 = linked_4147.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4146, arg_4149) } } else { map__1641000485__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1641000485__5 = map__1641000485__4 }; var order__6 any = /*line :644:1*/lang.RT_Get_O_O__O_NoInit(map__1641000485__5, A_arbace_o2j_A_const_529); var deps__7 any = lang.RT_Get_O_O__O_NoInit(map__1641000485__5, A_arbace_o2j_A_const_530); var us__8 any; var root_4150 any = A_arbace_o2j_A_const_43.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_4152 lang.IFn; if




	linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var arg_4153 any; var fnbody__4164 any = A_arbace_o2j_translate_program_fn__1641000487_A_New(); var tmp6 *jrt.Class; var fncls__4163 *jrt.Class = A_arbace_o2j_translate_program_fn__1641000487_A_fn_class; if fncls__4163 == nil { var fncls__4163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_186, false, nil); A_arbace_o2j_translate_program_fn__1641000487_A_fn_class = fncls__4163d; tmp6 = fncls__4163d } else { tmp6 = fncls__4163 }; arg_4153 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4164, tmp6, nil); var arg_4154 any = dumps__2; if linked_4151 == nil { us__8 = ifn_4152.Invoke_O_O__O(arg_4153, arg_4154) } else { us__8 = linked_4151.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_4150, arg_4153, arg_4154) }; var libs__9 any; var root_4165 any = /*line :644:1*/A_arbace_o2j_A_const_532.GetRawRoot__O(); var linked_4166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4165, A_arbace_o2j_link_A_fn_class); var ifn_4167 lang.IFn; if





	linked_4166 == nil { ifn_4167 = lang.IFn_Cast(root_4165) } else { ifn_4167 = nil }; var arg_4168 any = order__6; var arg_4169 any = deps__7; var arg_4170 any = us__8; if linked_4166 == nil { libs__9 = ifn_4167.Invoke_O_O_O__O(arg_4168, arg_4169, arg_4170) } else { libs__9 = linked_4166.(*A_arbace_o2j_link_A).Invoke_O_O_O_O__O(root_4165, arg_4168, arg_4169, arg_4170) }; var seq_1641000489__10 any; var root_4341 any = /*line :644:1*/A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4343 lang.IFn; if






	linked_4342 == nil { ifn_4343 = lang.IFn_Cast(root_4341) } else { ifn_4343 = nil }; var arg_4344 any = us__8; if linked_4342 == nil { seq_1641000489__10 = ifn_4343.Invoke_O__O(arg_4344) } else { seq_1641000489__10 = linked_4342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4341, arg_4344) }; var chunk_1641000490__11 any; var count_1641000491__12 int64 = 0; var i_1641000492__13 int64 = 0; L1:
//line :644:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000492__13, count_1641000491__12) { var u__14 any = lang.Indexed_Cast(chunk_1641000490__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000492__13)); var vec__1641000493__15 any; var root_4386 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_4387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4386, A_arbace_o2j_translate_unit_A_fn_class); var ifn_4388 lang.IFn
			if linked_4387 == nil { ifn_4388 = lang.IFn_Cast(root_4386) } else { ifn_4388 = nil }; var arg_4389 any = u__14; if linked_4387 == nil { vec__1641000493__15 = ifn_4388.Invoke_O__O(arg_4389) } else { vec__1641000493__15 = linked_4387.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_4386, arg_4389) }
//line :651:1
			var forms__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000493__15, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000493__15, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4414 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4414, A_arbace_o2j_write_forms_A_fn_class); var ifn_4416 lang.IFn

			if linked_4415 == nil { ifn_4416 = lang.IFn_Cast(root_4414) } else { ifn_4416 = nil }; var arg_4417 any; var root_4420 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4420, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4422 lang.IFn; if linked_4421 == nil { ifn_4422 = lang.IFn_Cast(root_4420) } else { ifn_4422 = nil }; var arg_4423 any = od__1; var arg_4424 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_21.Invoke_O__O(u__14), nil)).Ref(); if linked_4421 == nil { arg_4417 = ifn_4422.Invoke_O_O__O(arg_4423, arg_4424) } else { arg_4417 = linked_4421.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4420, arg_4423, arg_4424) }; var arg_4418 any = forms__16; var arg_4419 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__14), nil)).Ref(); if linked_4415 == nil { ifn_4416.Invoke_O_O_O__O(arg_4417, arg_4418, arg_4419) } else { linked_4415.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4414, arg_4417, arg_4418, arg_4419) }
//line :651:1
			var seq_1641000496__18 any; var root_4390 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4392 lang.IFn



			if linked_4391 == nil { ifn_4392 = lang.IFn_Cast(root_4390) } else { ifn_4392 = nil }; var arg_4393 any; var root_4394 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_4395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4394, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4396 lang.IFn; if linked_4395 == nil { ifn_4396 = lang.IFn_Cast(root_4394) } else { ifn_4396 = nil }; var arg_4397 any = missing__17; if linked_4395 == nil { arg_4393 = ifn_4396.Invoke_O__O(arg_4397) } else { arg_4393 = linked_4395.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4394, arg_4397) }; if linked_4391 == nil { seq_1641000496__18 = ifn_4392.Invoke_O__O(arg_4393) } else { seq_1641000496__18 = linked_4391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4390, arg_4393) }
//line :651:1
			var chunk_1641000497__19 any; var count_1641000498__20 int64 = 0; var i_1641000499__21 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000499__21, count_1641000498__20) { var vec__1641000500__22 any = lang.Indexed_Cast(chunk_1641000497__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000499__21)); var m__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000500__22, lang.RT_IntCast_J__I_NoInit(0), nil); var c__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000500__22, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,8,s8:missing\tns1:\tns1:\tns1:\tn", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, od__1, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__14), nil, m__23, nil, c__24)).Ref()); seq_1641000496__18, chunk_1641000497__19, count_1641000498__20, i_1641000499__21 = seq_1641000496__18, chunk_1641000497__19, count_1641000498__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000499__21); continue L2 } else { var temp__1927000414__auto____22 any; var root_4398 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4398, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4400 lang.IFn; if linked_4399 == nil { ifn_4400 = lang.IFn_Cast(root_4398) } else { ifn_4400 = nil }; var arg_4401 any = seq_1641000496__18; if linked_4399 == nil { temp__1927000414__auto____22 = ifn_4400.Invoke_O__O(arg_4401) } else { temp__1927000414__auto____22 = linked_4399.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4398, arg_4401) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1641000496__23 any = temp__1927000414__auto____22; var tmp7 any; var root_4402 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4402, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4404 lang.IFn; if linked_4403 == nil { ifn_4404 = lang.IFn_Cast(root_4402) } else { ifn_4404 = nil }; var arg_4405 any = seq_1641000496__23; if linked_4403 == nil { tmp7 = ifn_4404.Invoke_O__O(arg_4405) } else { tmp7 = linked_4403.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4402, arg_4405) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____24 any; var root_4406 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4406, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4408 lang.IFn; if linked_4407 == nil { ifn_4408 = lang.IFn_Cast(root_4406) } else { ifn_4408 = nil }; var arg_4409 any = seq_1641000496__23; if linked_4407 == nil { c__1927000678__auto____24 = ifn_4408.Invoke_O__O(arg_4409) } else { c__1927000678__auto____24 = linked_4407.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4406, arg_4409) }; var tmp8 any; var root_4429 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4429, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4431 lang.IFn; if linked_4430 == nil { ifn_4431 = lang.IFn_Cast(root_4429) } else { ifn_4431 = nil }; var arg_4432 any = seq_1641000496__23; if linked_4430 == nil { tmp8 = ifn_4431.Invoke_O__O(arg_4432) } else { tmp8 = linked_4430.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4429, arg_4432) }; seq_1641000496__18, chunk_1641000497__19, count_1641000498__20, i_1641000499__21 = tmp8, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1641000503__24 any; var root_4410 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4410, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4412 lang.IFn; if linked_4411 == nil { ifn_4412 = lang.IFn_Cast(root_4410) } else { ifn_4412 = nil }; var arg_4413 any = seq_1641000496__23; if linked_4411 == nil { vec__1641000503__24 = ifn_4412.Invoke_O__O(arg_4413) } else { vec__1641000503__24 = linked_4411.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4410, arg_4413) }; var m__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000503__24, lang.RT_IntCast_J__I_NoInit(0), nil); var c__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000503__24, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,8,s8:missing\tns1:\tns1:\tns1:\tn", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, od__1, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__14), nil, m__25, nil, c__26)).Ref()); var tmp9 any; var root_4437 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4437, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4439 lang.IFn; if linked_4438 == nil { ifn_4439 = lang.IFn_Cast(root_4437) } else { ifn_4439 = nil }; var arg_4440 any = seq_1641000496__23; if linked_4438 == nil { tmp9 = ifn_4439.Invoke_O__O(arg_4440) } else { tmp9 = linked_4438.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4437, arg_4440) }; seq_1641000496__18, chunk_1641000497__19, count_1641000498__20, i_1641000499__21 = tmp9, nil, 0, 0; continue L2 } } }
//line :651:1
				break L2 }; seq_1641000489__10, chunk_1641000490__11, count_1641000491__12, i_1641000492__13 = seq_1641000489__10, chunk_1641000490__11, count_1641000491__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000492__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_4345 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4347 lang.IFn; if linked_4346 == nil { ifn_4347 = lang.IFn_Cast(root_4345) } else { ifn_4347 = nil }; var arg_4348 any = seq_1641000489__10; if linked_4346 == nil { temp__1927000414__auto____14 = ifn_4347.Invoke_O__O(arg_4348) } else { temp__1927000414__auto____14 = linked_4346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4345, arg_4348) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1641000489__15 any = temp__1927000414__auto____14; var tmp10 any; var root_4349 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4349, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4351 lang.IFn; if linked_4350 == nil { ifn_4351 = lang.IFn_Cast(root_4349) } else { ifn_4351 = nil }; var arg_4352 any = seq_1641000489__15; if linked_4350 == nil { tmp10 = ifn_4351.Invoke_O__O(arg_4352) } else { tmp10 = linked_4350.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4349, arg_4352) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____16 any; var root_4353 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4353, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4355 lang.IFn; if linked_4354 == nil { ifn_4355 = lang.IFn_Cast(root_4353) } else { ifn_4355 = nil }; var arg_4356 any = seq_1641000489__15; if linked_4354 == nil { c__1927000678__auto____16 = ifn_4355.Invoke_O__O(arg_4356) } else { c__1927000678__auto____16 = linked_4354.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4353, arg_4356) }; var tmp11 any; var root_4441 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4441, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4443 lang.IFn; if linked_4442 == nil { ifn_4443 = lang.IFn_Cast(root_4441) } else { ifn_4443 = nil }; var arg_4444 any = seq_1641000489__15; if linked_4442 == nil { tmp11 = ifn_4443.Invoke_O__O(arg_4444) } else { tmp11 = linked_4442.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4441, arg_4444) }; seq_1641000489__10, chunk_1641000490__11, count_1641000491__12, i_1641000492__13 = tmp11, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var u__16 any; var root_4357 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4357, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4359 lang.IFn; if linked_4358 == nil { ifn_4359 = lang.IFn_Cast(root_4357) } else { ifn_4359 = nil }; var arg_4360 any = seq_1641000489__15; if linked_4358 == nil { u__16 = ifn_4359.Invoke_O__O(arg_4360) } else { u__16 = linked_4358.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4357, arg_4360) }; var vec__1641000506__17 any; var root_4445 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_4446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4445, A_arbace_o2j_translate_unit_A_fn_class); var ifn_4447 lang.IFn
					if linked_4446 == nil { ifn_4447 = lang.IFn_Cast(root_4445) } else { ifn_4447 = nil }; var arg_4448 any = u__16; if linked_4446 == nil { vec__1641000506__17 = ifn_4447.Invoke_O__O(arg_4448) } else { vec__1641000506__17 = linked_4446.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_4445, arg_4448) }
//line :651:1
					var forms__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000506__17, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000506__17, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4473 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4473, A_arbace_o2j_write_forms_A_fn_class); var ifn_4475 lang.IFn

					if linked_4474 == nil { ifn_4475 = lang.IFn_Cast(root_4473) } else { ifn_4475 = nil }; var arg_4476 any; var root_4479 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4479, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4481 lang.IFn; if linked_4480 == nil { ifn_4481 = lang.IFn_Cast(root_4479) } else { ifn_4481 = nil }; var arg_4482 any = od__1; var arg_4483 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil)).Ref(); if linked_4480 == nil { arg_4476 = ifn_4481.Invoke_O_O__O(arg_4482, arg_4483) } else { arg_4476 = linked_4480.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4479, arg_4482, arg_4483) }; var arg_4477 any = forms__18; var arg_4478 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil)).Ref(); if linked_4474 == nil { ifn_4475.Invoke_O_O_O__O(arg_4476, arg_4477, arg_4478) } else { linked_4474.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4473, arg_4476, arg_4477, arg_4478) }
//line :651:1
					var seq_1641000509__20 any; var root_4449 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4451 lang.IFn



					if linked_4450 == nil { ifn_4451 = lang.IFn_Cast(root_4449) } else { ifn_4451 = nil }; var arg_4452 any; var root_4453 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_4454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4453, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4455 lang.IFn; if linked_4454 == nil { ifn_4455 = lang.IFn_Cast(root_4453) } else { ifn_4455 = nil }; var arg_4456 any = missing__19; if linked_4454 == nil { arg_4452 = ifn_4455.Invoke_O__O(arg_4456) } else { arg_4452 = linked_4454.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4453, arg_4456) }; if linked_4450 == nil { seq_1641000509__20 = ifn_4451.Invoke_O__O(arg_4452) } else { seq_1641000509__20 = linked_4450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4449, arg_4452) }
//line :651:1
					var chunk_1641000510__21 any; var count_1641000511__22 int64 = 0; var i_1641000512__23 int64 = 0; L3: for {



						if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000512__23, count_1641000511__22) { var vec__1641000513__24 any = lang.Indexed_Cast(chunk_1641000510__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000512__23)); var m__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000513__24, lang.RT_IntCast_J__I_NoInit(0), nil); var c__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000513__24, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,8,s8:missing\tns1:\tns1:\tns1:\tn", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, od__1, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil, m__25_2, nil, c__26_2)).Ref()); seq_1641000509__20, chunk_1641000510__21, count_1641000511__22, i_1641000512__23 = seq_1641000509__20, chunk_1641000510__21, count_1641000511__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000512__23); continue L3 } else { var temp__1927000414__auto____24 any; var root_4457 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4457, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4459 lang.IFn; if linked_4458 == nil { ifn_4459 = lang.IFn_Cast(root_4457) } else { ifn_4459 = nil }; var arg_4460 any = seq_1641000509__20; if linked_4458 == nil { temp__1927000414__auto____24 = ifn_4459.Invoke_O__O(arg_4460) } else { temp__1927000414__auto____24 = linked_4458.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4457, arg_4460) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1641000509__25 any = temp__1927000414__auto____24; var tmp12 any; var root_4461 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4461, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4463 lang.IFn; if linked_4462 == nil { ifn_4463 = lang.IFn_Cast(root_4461) } else { ifn_4463 = nil }; var arg_4464 any = seq_1641000509__25; if linked_4462 == nil { tmp12 = ifn_4463.Invoke_O__O(arg_4464) } else { tmp12 = linked_4462.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4461, arg_4464) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____26 any; var root_4465 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4465, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4467 lang.IFn; if linked_4466 == nil { ifn_4467 = lang.IFn_Cast(root_4465) } else { ifn_4467 = nil }; var arg_4468 any = seq_1641000509__25; if linked_4466 == nil { c__1927000678__auto____26 = ifn_4467.Invoke_O__O(arg_4468) } else { c__1927000678__auto____26 = linked_4466.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4465, arg_4468) }; var tmp13 any; var root_4488 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = seq_1641000509__25; if linked_4489 == nil { tmp13 = ifn_4490.Invoke_O__O(arg_4491) } else { tmp13 = linked_4489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4488, arg_4491) }; seq_1641000509__20, chunk_1641000510__21, count_1641000511__22, i_1641000512__23 = tmp13, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1641000516__26 any; var root_4469 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4471 lang.IFn; if linked_4470 == nil { ifn_4471 = lang.IFn_Cast(root_4469) } else { ifn_4471 = nil }; var arg_4472 any = seq_1641000509__25; if linked_4470 == nil { vec__1641000516__26 = ifn_4471.Invoke_O__O(arg_4472) } else { vec__1641000516__26 = linked_4470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4469, arg_4472) }; var m__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000516__26, lang.RT_IntCast_J__I_NoInit(0), nil); var c__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000516__26, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,8,s8:missing\tns1:\tns1:\tns1:\tn", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, od__1, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil, m__27, nil, c__28)).Ref()); var tmp14 any; var root_4496 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4496, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4498 lang.IFn; if linked_4497 == nil { ifn_4498 = lang.IFn_Cast(root_4496) } else { ifn_4498 = nil }; var arg_4499 any = seq_1641000509__25; if linked_4497 == nil { tmp14 = ifn_4498.Invoke_O__O(arg_4499) } else { tmp14 = linked_4497.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4496, arg_4499) }; seq_1641000509__20, chunk_1641000510__21, count_1641000511__22, i_1641000512__23 = tmp14, nil, 0, 0; continue L3 } } }
//line :651:1
						break L3 }; var tmp15 any; var root_4500 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4500, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4502 lang.IFn; if linked_4501 == nil { ifn_4502 = lang.IFn_Cast(root_4500) } else { ifn_4502 = nil }; var arg_4503 any = seq_1641000489__15; if linked_4501 == nil { tmp15 = ifn_4502.Invoke_O__O(arg_4503) } else { tmp15 = linked_4501.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4500, arg_4503) }; seq_1641000489__10, chunk_1641000490__11, count_1641000491__12, i_1641000492__13 = tmp15, nil, 0, 0; continue L1 } } }
//line :644:1
		break L1 }; var root_4361 any =











	A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4361, A_arbace_o2j_write_forms_A_fn_class); var ifn_4363 lang.IFn; if linked_4362 == nil { ifn_4363 = lang.IFn_Cast(root_4361) } else { ifn_4363 = nil }; var arg_4364 any; var root_4367 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4367, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4369 lang.IFn; if linked_4368 == nil { ifn_4369 = lang.IFn_Cast(root_4367) } else { ifn_4369 = nil }; var arg_4370 any = od__1; var arg_4371 any = Lit_187; if linked_4368 == nil { arg_4364 = ifn_4369.Invoke_O_O__O(arg_4370, arg_4371) } else { arg_4364 = linked_4368.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4367, arg_4370, arg_4371) }; var arg_4365 any; var root_4372 any = A_arbace_o2j_A_const_536.GetRawRoot__O(); var linked_4373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4372, A_arbace_o2j_main_forms_A_fn_class); var ifn_4374 lang.IFn; if linked_4373 == nil { ifn_4374 = lang.IFn_Cast(root_4372) } else { ifn_4374 = nil }; var arg_4375 any; var root_4376 any = A_arbace_o2j_A_const_66.GetRawRoot__O(); var linked_4377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4376, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4378 lang.IFn; if linked_4377 == nil { ifn_4378 = lang.IFn_Cast(root_4376) } else { ifn_4378 = nil }; var arg_4379 any = libs__9; var arg_4380 any; var root_4381 any = A_arbace_o2j_A_const_40.GetRawRoot__O(); var linked_4382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4381, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4383 lang.IFn; if linked_4382 == nil { ifn_4383 = lang.IFn_Cast(root_4381) } else { ifn_4383 = nil }; var arg_4384 any = A_arbace_o2j_A_const_21; var arg_4385 any = us__8; if linked_4382 == nil { arg_4380 = ifn_4383.Invoke_O_O__O(arg_4384, arg_4385) } else { arg_4380 = linked_4382.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4381, arg_4384, arg_4385) }; if linked_4377 == nil { arg_4375 = ifn_4378.Invoke_O_O__O(arg_4379, arg_4380) } else { arg_4375 = linked_4377.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4376, arg_4379, arg_4380) }; if linked_4373 == nil { arg_4365 = ifn_4374.Invoke_O__O(arg_4375) } else { arg_4365 = linked_4373.(*A_arbace_o2j_main_forms_A).Invoke_O_O__O(root_4372, arg_4375) }; var arg_4366 any = Lit_17; if linked_4362 == nil { ifn_4363.Invoke_O_O_O__O(arg_4364, arg_4365, arg_4366) } else { linked_4362.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4361, arg_4364, arg_4365, arg_4366) }; var tmp16 lang.IFn =
	lang.IFn_Cast(A_arbace_o2j_A_const_533.GetRawRoot__O()); var tmp17 any; var root_4176 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4176, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4178 lang.IFn; if linked_4177 == nil { ifn_4178 = lang.IFn_Cast(root_4176) } else { ifn_4178 = nil }; var arg_4179 any = od__1; var arg_4180 any = Lit_188; if linked_4177 == nil { tmp17 = ifn_4178.Invoke_O_O__O(arg_4179, arg_4180) } else { tmp17 = linked_4177.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4176, arg_4179, arg_4180) }; var tmp18 any = tmp17; var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_189); var tmp20 any; var root_4181 any = A_arbace_o2j_A_const_534.GetRawRoot__O(); var linked_4182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4181, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_4183 lang.IFn; if
	linked_4182 == nil { ifn_4183 = lang.IFn_Cast(root_4181) } else { ifn_4183 = nil }; var arg_4184 any = Lit_189; var arg_4185 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_66.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____12 any; var fnbody__4263 any = A_arbace_o2j_translate_program_iter__1641000519__1641000523_A_New_O(lo__0); var tmp23 *jrt.Class; var fncls__4262 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000519__1641000523_A_fn_class; if fncls__4262 == nil { var fncls__4262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, fnbody__4263); A_arbace_o2j_translate_program_iter__1641000519__1641000523_A_fn_class = fncls__4262d; tmp23 = fncls__4262d } else { tmp23 = fncls__4262 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4263, tmp23, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(libs__9); var tmp24 any = tmp22; var tmp25 any; var iter__1927001039__auto____12_2 any; var fnbody__4335 any = A_arbace_o2j_translate_program_iter__1641000529__1641000533_A_New_O(od__1); var tmp26 *jrt.Class; var fncls__4334 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000529__1641000533_A_fn_class; if
	fncls__4334 == nil { var fncls__4334d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, fnbody__4335); A_arbace_o2j_translate_program_iter__1641000529__1641000533_A_fn_class = fncls__4334d; tmp26 = fncls__4334d } else { tmp26 = fncls__4334 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4335, tmp26, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(us__8); var tmp27 any = tmp25; var tmp28 any; var root_4336 any = /*line :658:1*/A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4336, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4338 lang.IFn; if

	linked_4337 == nil { ifn_4338 = lang.IFn_Cast(root_4336) } else { ifn_4338 = nil }; var arg_4339 any = od__1; var arg_4340 any = Lit_187; if linked_4337 == nil { tmp28 = ifn_4338.Invoke_O_O__O(arg_4339, arg_4340) } else { tmp28 = linked_4337.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4336, arg_4339, arg_4340) }; arg_4185 = /*line :658:1*/tmp21.Invoke_O_O_O__O(tmp24, tmp27, lang.Tuple_Create_O__IPersistentVector(jrt.File_Cast(tmp28).GetPath__String().Ref())); if linked_4182 == nil { tmp20 = ifn_4183.Invoke_O_O__O(arg_4184, arg_4185) } else { tmp20 = linked_4182.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_4181, arg_4184, arg_4185) }; return /*line :657:1*/ tmp16.Invoke_O_O__O(tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp20, nil)).Ref()) }
//line :649:1
func A_arbace_o2j_translate_program_fn__1641000487_A_New() *A_arbace_o2j_translate_program_fn__1641000487_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_fn__1641000487_A{}; t.Ctor(); return t }
//line :649:1
func (t *A_arbace_o2j_translate_program_fn__1641000487_A) Ctor() {}
//line :649:1
func (t *A_arbace_o2j_translate_program_fn__1641000487_A) Invoke_O_O__O(self, p1__1641000484_SHARP___1 any) any { var root_4155 any = A_arbace_o2j_A_const_531.GetRawRoot__O(); var linked_4156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4155, A_arbace_o2j_read_dump_A_fn_class); var ifn_4157 lang.IFn; if linked_4156 == nil { ifn_4157 = lang.IFn_Cast(root_4155) } else { ifn_4157 = nil }; var arg_4158 any; var root_4159 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4159, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4161 lang.IFn; if linked_4160 == nil { ifn_4161 = lang.IFn_Cast(root_4159) } else { ifn_4161 = nil }; var arg_4162 any = p1__1641000484_SHARP___1; if linked_4160 == nil { arg_4158 = ifn_4161.Invoke_O__O(arg_4162) } else { arg_4158 = linked_4160.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_4159, arg_4162) }; if linked_4156 == nil { return ifn_4157.Invoke_O__O(arg_4158) } else { return linked_4156.(*A_arbace_o2j_read_dump_A).Invoke_O_O__O(root_4155, arg_4158) } }








func A_arbace_o2j_translate_program_iter__1641000519__1641000523_A_New_O(p0 any) *A_arbace_o2j_translate_program_iter__1641000519__1641000523_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000519__1641000523_A{}; t.Ctor_O(p0); return t }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_A) Ctor_O(c__lo any) { t.F_lo = c__lo }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_A) Invoke_O_O__O(self, s__1641000520__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4261 any = A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A_New_O_O_O(t.F_lo, self, s__1641000520__1); var tmp2 *jrt.Class; var fncls__4260 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A_fn_class; if fncls__4260 == nil { var fncls__4260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, fnbody__4261); A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A_fn_class = fncls__4260d; tmp2 = fncls__4260d } else { tmp2 = fncls__4260 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4261, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :658:1
func A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A) Ctor_O_O_O(c__lo, c__iter__1641000519, c__s__1641000520 any) { t.F_lo = c__lo; t.F_iter__1641000519 = c__iter__1641000519; t.F_s__1641000520 = c__s__1641000520 }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A) Invoke_O__O(self any) any { { var s__1641000520__1 any; var t_ any = t.F_s__1641000520; t.F_s__1641000520 = nil; s__1641000520__1 = t_; for { var temp__1927000414__auto____2 any; var root_4192 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4194 lang.IFn; if linked_4193 == nil { ifn_4194 = lang.IFn_Cast(root_4192) } else { ifn_4194 = nil }; var arg_4195 any = s__1641000520__1; if linked_4193 == nil { temp__1927000414__auto____2 = ifn_4194.Invoke_O__O(arg_4195) } else { temp__1927000414__auto____2 = linked_4193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4192, arg_4195) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000520__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4196 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4196, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4198 lang.IFn; if linked_4197 == nil { ifn_4198 = lang.IFn_Cast(root_4196) } else { ifn_4198 = nil }; var arg_4199 any = s__1641000520__3; if linked_4197 == nil { tmp1 = ifn_4198.Invoke_O__O(arg_4199) } else { tmp1 = linked_4197.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4196, arg_4199) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4200 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4200, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4202 lang.IFn; if linked_4201 == nil { ifn_4202 = lang.IFn_Cast(root_4200) } else { ifn_4202 = nil }; var arg_4203 any = s__1641000520__3; if linked_4201 == nil { c__1927001037__auto____4 = ifn_4202.Invoke_O__O(arg_4203) } else { c__1927001037__auto____4 = linked_4201.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4200, arg_4203) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000522__6 any; var root_4204 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_4205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4204, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4206 lang.IFn; if linked_4205 == nil { ifn_4206 = lang.IFn_Cast(root_4204) } else { ifn_4206 = nil }; var arg_4207 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4205 == nil { b__1641000522__6 = ifn_4206.Invoke_O__O(arg_4207) } else { b__1641000522__6 = linked_4205.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4204, arg_4207) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4219 any = A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A_New_O_O_I_O(t.F_lo, b__1641000522__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4218 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A_fn_class; if fncls__4218 == nil { var fncls__4218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_193, false, fnbody__4219); A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A_fn_class = fncls__4218d; tmp3 = fncls__4218d } else { tmp3 = fncls__4218 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4219, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4220 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4220, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4222 lang.IFn; if linked_4221 == nil { ifn_4222 = lang.IFn_Cast(root_4220) } else { ifn_4222 = nil }; var arg_4223 any; var root_4225 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4225, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4227 lang.IFn; if linked_4226 == nil { ifn_4227 = lang.IFn_Cast(root_4225) } else { ifn_4227 = nil }; var arg_4228 any = b__1641000522__6; if linked_4226 == nil { arg_4223 = ifn_4227.Invoke_O__O(arg_4228) } else { arg_4223 = linked_4226.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4225, arg_4228) }; var arg_4224 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000519); var tmp5 any; var root_4229 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4231 lang.IFn; if linked_4230 == nil { ifn_4231 = lang.IFn_Cast(root_4229) } else { ifn_4231 = nil }; var arg_4232 any = s__1641000520__3; if linked_4230 == nil { tmp5 = ifn_4231.Invoke_O__O(arg_4232) } else { tmp5 = linked_4230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4229, arg_4232) }; arg_4224 = tmp4.Invoke_O__O(tmp5); if linked_4221 == nil { return ifn_4222.Invoke_O_O__O(arg_4223, arg_4224) } else { return linked_4221.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4220, arg_4223, arg_4224) } } else { var root_4233 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4233, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4235 lang.IFn; if linked_4234 == nil { ifn_4235 = lang.IFn_Cast(root_4233) } else { ifn_4235 = nil }; var arg_4236 any; var root_4238 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4238, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4240 lang.IFn; if linked_4239 == nil { ifn_4240 = lang.IFn_Cast(root_4238) } else { ifn_4240 = nil }; var arg_4241 any = b__1641000522__6; if linked_4239 == nil { arg_4236 = ifn_4240.Invoke_O__O(arg_4241) } else { arg_4236 = linked_4239.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4238, arg_4241) }; var arg_4237 any; if linked_4234 == nil { return ifn_4235.Invoke_O_O__O(arg_4236, arg_4237) } else { return linked_4234.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4233, arg_4236, arg_4237) } } } else { var n__4 any; var root_4242 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4242, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4244 lang.IFn; if linked_4243 == nil { ifn_4244 = lang.IFn_Cast(root_4242) } else { ifn_4244 = nil }; var arg_4245 any = s__1641000520__3; if linked_4243 == nil { n__4 = ifn_4244.Invoke_O__O(arg_4245) } else { n__4 = linked_4243.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4242, arg_4245) }; var root_4246 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_4247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4246, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4248 lang.IFn; if linked_4247 == nil { ifn_4248 = lang.IFn_Cast(root_4246) } else { ifn_4248 = nil }; var arg_4249 any; var tmp6 any; var root_4251 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4251, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4253 lang.IFn; if linked_4252 == nil { ifn_4253 = lang.IFn_Cast(root_4251) } else { ifn_4253 = nil }; var arg_4254 any = t.F_lo; var arg_4255 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__4, nil)).Ref(); if linked_4252 == nil { tmp6 = ifn_4253.Invoke_O_O__O(arg_4254, arg_4255) } else { tmp6 = linked_4252.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4251, arg_4254, arg_4255) }; arg_4249 = jrt.File_Cast(tmp6).GetPath__String().Ref(); var arg_4250 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1641000519); var tmp8 any; var root_4256 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_4257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4258 lang.IFn; if linked_4257 == nil { ifn_4258 = lang.IFn_Cast(root_4256) } else { ifn_4258 = nil }; var arg_4259 any = s__1641000520__3; if linked_4257 == nil { tmp8 = ifn_4258.Invoke_O__O(arg_4259) } else { tmp8 = linked_4257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4256, arg_4259) }; arg_4250 = tmp7.Invoke_O__O(tmp8); if linked_4247 == nil { return ifn_4248.Invoke_O_O__O(arg_4249, arg_4250) } else { return linked_4247.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4246, arg_4249, arg_4250) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :658:1
func A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A) Ctor_O_O_I_O(c__lo, c__b__1641000522 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_lo = c__lo; t.F_b__1641000522 = c__b__1641000522; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :658:1
func (t *A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A) Invoke_O__O(self any) any { { var i__1641000521__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000521__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000521__1)); var root_4208 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_4209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4208, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4210 lang.IFn; if linked_4209 == nil { ifn_4210 = lang.IFn_Cast(root_4208) } else { ifn_4210 = nil }; var arg_4211 any = t.F_b__1641000522; var arg_4212 any; var tmp2 any; var root_4213 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4213, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4215 lang.IFn; if linked_4214 == nil { ifn_4215 = lang.IFn_Cast(root_4213) } else { ifn_4215 = nil }; var arg_4216 any = t.F_lo; var arg_4217 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__2, nil)).Ref(); if linked_4214 == nil { tmp2 = ifn_4215.Invoke_O_O__O(arg_4216, arg_4217) } else { tmp2 = linked_4214.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4213, arg_4216, arg_4217) }; arg_4212 = jrt.File_Cast(tmp2).GetPath__String().Ref(); if linked_4209 == nil { ifn_4210.Invoke_O_O__O(arg_4211, arg_4212) } else { linked_4209.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4208, arg_4211, arg_4212) }; i__1641000521__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000521__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_o2j_translate_program_iter__1641000529__1641000533_A_New_O(p0 any) *A_arbace_o2j_translate_program_iter__1641000529__1641000533_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000529__1641000533_A{}; t.Ctor_O(p0); return t }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_A) Ctor_O(c__od any) { t.F_od = c__od }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_A) Invoke_O_O__O(self, s__1641000530__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4333 any = A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A_New_O_O_O(self, t.F_od, s__1641000530__1); var tmp2 *jrt.Class; var fncls__4332 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A_fn_class; if fncls__4332 == nil { var fncls__4332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, fnbody__4333); A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A_fn_class = fncls__4332d; tmp2 = fncls__4332d } else { tmp2 = fncls__4332 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4333, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :659:1
func A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A) Ctor_O_O_O(c__iter__1641000529, c__od, c__s__1641000530 any) { t.F_iter__1641000529 = c__iter__1641000529; t.F_od = c__od; t.F_s__1641000530 = c__s__1641000530 }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A) Invoke_O__O(self any) any { { var s__1641000530__1 any; var t_ any = t.F_s__1641000530; t.F_s__1641000530 = nil; s__1641000530__1 = t_; for { var temp__1927000414__auto____2 any; var root_4264 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4266 lang.IFn; if linked_4265 == nil { ifn_4266 = lang.IFn_Cast(root_4264) } else { ifn_4266 = nil }; var arg_4267 any = s__1641000530__1; if linked_4265 == nil { temp__1927000414__auto____2 = ifn_4266.Invoke_O__O(arg_4267) } else { temp__1927000414__auto____2 = linked_4265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4264, arg_4267) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000530__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4268 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4268, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4270 lang.IFn; if linked_4269 == nil { ifn_4270 = lang.IFn_Cast(root_4268) } else { ifn_4270 = nil }; var arg_4271 any = s__1641000530__3; if linked_4269 == nil { tmp1 = ifn_4270.Invoke_O__O(arg_4271) } else { tmp1 = linked_4269.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4268, arg_4271) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4272 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4272, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4274 lang.IFn; if linked_4273 == nil { ifn_4274 = lang.IFn_Cast(root_4272) } else { ifn_4274 = nil }; var arg_4275 any = s__1641000530__3; if linked_4273 == nil { c__1927001037__auto____4 = ifn_4274.Invoke_O__O(arg_4275) } else { c__1927001037__auto____4 = linked_4273.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4272, arg_4275) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000532__6 any; var root_4276 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_4277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4276, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4278 lang.IFn; if linked_4277 == nil { ifn_4278 = lang.IFn_Cast(root_4276) } else { ifn_4278 = nil }; var arg_4279 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4277 == nil { b__1641000532__6 = ifn_4278.Invoke_O__O(arg_4279) } else { b__1641000532__6 = linked_4277.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4276, arg_4279) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4291 any = A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A_New_O_O_I_O(b__1641000532__6, t.F_od, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4290 *jrt.Class = A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A_fn_class; if fncls__4290 == nil { var fncls__4290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, fnbody__4291); A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A_fn_class = fncls__4290d; tmp3 = fncls__4290d } else { tmp3 = fncls__4290 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4291, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4292 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4292, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4294 lang.IFn; if linked_4293 == nil { ifn_4294 = lang.IFn_Cast(root_4292) } else { ifn_4294 = nil }; var arg_4295 any; var root_4297 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4297, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4299 lang.IFn; if linked_4298 == nil { ifn_4299 = lang.IFn_Cast(root_4297) } else { ifn_4299 = nil }; var arg_4300 any = b__1641000532__6; if linked_4298 == nil { arg_4295 = ifn_4299.Invoke_O__O(arg_4300) } else { arg_4295 = linked_4298.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4297, arg_4300) }; var arg_4296 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000529); var tmp5 any; var root_4301 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4301, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4303 lang.IFn; if linked_4302 == nil { ifn_4303 = lang.IFn_Cast(root_4301) } else { ifn_4303 = nil }; var arg_4304 any = s__1641000530__3; if linked_4302 == nil { tmp5 = ifn_4303.Invoke_O__O(arg_4304) } else { tmp5 = linked_4302.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4301, arg_4304) }; arg_4296 = tmp4.Invoke_O__O(tmp5); if linked_4293 == nil { return ifn_4294.Invoke_O_O__O(arg_4295, arg_4296) } else { return linked_4293.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4292, arg_4295, arg_4296) } } else { var root_4305 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4305, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4307 lang.IFn; if linked_4306 == nil { ifn_4307 = lang.IFn_Cast(root_4305) } else { ifn_4307 = nil }; var arg_4308 any; var root_4310 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4310, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4312 lang.IFn; if linked_4311 == nil { ifn_4312 = lang.IFn_Cast(root_4310) } else { ifn_4312 = nil }; var arg_4313 any = b__1641000532__6; if linked_4311 == nil { arg_4308 = ifn_4312.Invoke_O__O(arg_4313) } else { arg_4308 = linked_4311.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4310, arg_4313) }; var arg_4309 any; if linked_4306 == nil { return ifn_4307.Invoke_O_O__O(arg_4308, arg_4309) } else { return linked_4306.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4305, arg_4308, arg_4309) } } } else { var u__4 any; var root_4314 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4314, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4316 lang.IFn; if linked_4315 == nil { ifn_4316 = lang.IFn_Cast(root_4314) } else { ifn_4316 = nil }; var arg_4317 any = s__1641000530__3; if linked_4315 == nil { u__4 = ifn_4316.Invoke_O__O(arg_4317) } else { u__4 = linked_4315.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4314, arg_4317) }; var root_4318 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_4319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4318, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4320 lang.IFn; if linked_4319 == nil { ifn_4320 = lang.IFn_Cast(root_4318) } else { ifn_4320 = nil }; var arg_4321 any; var tmp6 any; var root_4323 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4324 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4323, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4325 lang.IFn; if linked_4324 == nil { ifn_4325 = lang.IFn_Cast(root_4323) } else { ifn_4325 = nil }; var arg_4326 any = t.F_od; var arg_4327 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_21.Invoke_O__O(u__4), nil)).Ref(); if linked_4324 == nil { tmp6 = ifn_4325.Invoke_O_O__O(arg_4326, arg_4327) } else { tmp6 = linked_4324.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4323, arg_4326, arg_4327) }; arg_4321 = jrt.File_Cast(tmp6).GetPath__String().Ref(); var arg_4322 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1641000529); var tmp8 any; var root_4328 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_4329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4328, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4330 lang.IFn; if linked_4329 == nil { ifn_4330 = lang.IFn_Cast(root_4328) } else { ifn_4330 = nil }; var arg_4331 any = s__1641000530__3; if linked_4329 == nil { tmp8 = ifn_4330.Invoke_O__O(arg_4331) } else { tmp8 = linked_4329.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4328, arg_4331) }; arg_4322 = tmp7.Invoke_O__O(tmp8); if linked_4319 == nil { return ifn_4320.Invoke_O_O__O(arg_4321, arg_4322) } else { return linked_4319.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4318, arg_4321, arg_4322) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :659:1
func A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A) Ctor_O_O_I_O(c__b__1641000532, c__od any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000532 = c__b__1641000532; t.F_od = c__od; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :659:1
func (t *A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A) Invoke_O__O(self any) any { { var i__1641000531__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000531__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000531__1)); var root_4280 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_4281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4280, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4282 lang.IFn; if linked_4281 == nil { ifn_4282 = lang.IFn_Cast(root_4280) } else { ifn_4282 = nil }; var arg_4283 any = t.F_b__1641000532; var arg_4284 any; var tmp2 any; var root_4285 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4285, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4287 lang.IFn; if linked_4286 == nil { ifn_4287 = lang.IFn_Cast(root_4285) } else { ifn_4287 = nil }; var arg_4288 any = t.F_od; var arg_4289 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_21.Invoke_O__O(u__2), nil)).Ref(); if linked_4286 == nil { tmp2 = ifn_4287.Invoke_O_O__O(arg_4288, arg_4289) } else { tmp2 = linked_4286.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4285, arg_4288, arg_4289) }; arg_4284 = jrt.File_Cast(tmp2).GetPath__String().Ref(); if linked_4281 == nil { ifn_4282.Invoke_O_O__O(arg_4283, arg_4284) } else { linked_4281.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4280, arg_4283, arg_4284) }; i__1641000531__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000531__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_o2j__main_A_New() *A_arbace_o2j__main_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_A{}; t.Ctor(); return t }
//line :666:1
func (t *A_arbace_o2j__main_A) Ctor() {}
//line :666:1
func (t *A_arbace_o2j__main_A) DoInvoke_O_O__O(self, p__1641000540__0 any) any { var vec__1641000541__2 any = p__1641000540__0; var seq__1641000542__3 any; var root_4504 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4504, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4506 lang.IFn; if linked_4505 == nil { ifn_4506 = lang.IFn_Cast(root_4504) } else { ifn_4506 = nil }; var arg_4507 any = vec__1641000541__2; if linked_4505 == nil { seq__1641000542__3 = ifn_4506.Invoke_O__O(arg_4507) } else { seq__1641000542__3 = linked_4505.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4504, arg_4507) }; var first__1641000543__4 any; var root_4508 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4508, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4510 lang.IFn; if linked_4509 == nil { ifn_4510 = lang.IFn_Cast(root_4508) } else { ifn_4510 = nil }; var arg_4511 any = seq__1641000542__3; if linked_4509 == nil { first__1641000543__4 = ifn_4510.Invoke_O__O(arg_4511) } else { first__1641000543__4 = linked_4509.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4508, arg_4511) }; var seq__1641000542__5 any; var root_4512 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4512, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4514 lang.IFn; if linked_4513 == nil { ifn_4514 = lang.IFn_Cast(root_4512) } else { ifn_4514 = nil }; var arg_4515 any = seq__1641000542__3; if linked_4513 == nil { seq__1641000542__5 = ifn_4514.Invoke_O__O(arg_4515) } else { seq__1641000542__5 = linked_4513.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4512, arg_4515) }; var cmd__6 any = first__1641000543__4; var args__7 any = seq__1641000542__5; var root_4834 any = A_arbace_o2j_A_const_542.GetRawRoot__O(); var linked_4835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4834, A_arbace_o2j_load_externals_BANG__A_fn_class); var ifn_4836 lang.IFn; if
										linked_4835 == nil { ifn_4836 = lang.IFn_Cast(root_4834) } else { ifn_4836 = nil }; var arg_4837 any; var or__1927000174__auto____8 any = jrt.System_Getenv_String__String(Lit_1).Ref(); if jrt.J2g_Truth(or__1927000174__auto____8) { arg_4837 = or__1927000174__auto____8 } else { arg_4837 = Lit_2 }; if linked_4835 == nil { ifn_4836.Invoke_O__O(arg_4837) } else { linked_4835.(*A_arbace_o2j_load_externals_BANG__A).Invoke_O_O__O(root_4834, arg_4837) }; var G__1641000544__8_ any = cmd__6; switch
										lang.Util_Hash_O__I_NoInit(G__1641000544__8_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000544__8_, Lit_3) { var vec__1641000545__9 any = args__7; var lo__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000545__9, lang.RT_IntCast_J__I_NoInit(0), nil); var lst__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000545__9, lang.RT_IntCast_J__I_NoInit(1), nil); var seq_1641000548__12 any; var root_4517 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4519 lang.IFn






















		if linked_4518 == nil { ifn_4519 = lang.IFn_Cast(root_4517) } else { ifn_4519 = nil }; var arg_4520 any; var root_4521 any = A_arbace_o2j_A_const_538.GetRawRoot__O(); var linked_4522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4521, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_4523 lang.IFn; if linked_4522 == nil { ifn_4523 = lang.IFn_Cast(root_4521) } else { ifn_4523 = nil }; var arg_4524 any = lang.IFn_Cast(A_arbace_o2j_A_const_528.GetRawRoot__O()).Invoke_O__O(lst__11); if linked_4522 == nil { arg_4520 = ifn_4523.Invoke_O__O(arg_4524) } else { arg_4520 = linked_4522.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_4521, arg_4524) }; if linked_4518 == nil { seq_1641000548__12 = ifn_4519.Invoke_O__O(arg_4520) } else { seq_1641000548__12 = linked_4518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4517, arg_4520) }
//line :668:1
		var chunk_1641000549__13 any; var count_1641000550__14 int64 = 0; var i_1641000551__15 int64 = 0; L2: for {






















			if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000551__15, count_1641000550__14) { var line__16 any = lang.Indexed_Cast(chunk_1641000549__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000551__15)); var tmp1 any; var root_4529 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4529, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4531 lang.IFn; if linked_4530 == nil { ifn_4531 = lang.IFn_Cast(root_4529) } else { ifn_4531 = nil }; var arg_4532 any = line__16; if linked_4530 == nil { tmp1 = ifn_4531.Invoke_O__O(arg_4532) } else { tmp1 = linked_4530.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4529, arg_4532) }; if jrt.J2g_Truth(tmp1) { var vec__1641000552__17 any; var root_4838 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_4839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4838, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_4840 lang.IFn
				if linked_4839 == nil { ifn_4840 = lang.IFn_Cast(root_4838) } else { ifn_4840 = nil }; var arg_4841 any = line__16; var arg_4842 any = A_arbace_o2j_A_const_543; if linked_4839 == nil { vec__1641000552__17 = ifn_4840.Invoke_O_O__O(arg_4841, arg_4842) } else { vec__1641000552__17 = linked_4839.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_4838, arg_4841, arg_4842) }
//line :691:1
				var seq__1641000553__18 any; var root_4843 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4843, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4845 lang.IFn; if linked_4844 == nil { ifn_4845 = lang.IFn_Cast(root_4843) } else { ifn_4845 = nil }; var arg_4846 any = vec__1641000552__17; if linked_4844 == nil { seq__1641000553__18 = ifn_4845.Invoke_O__O(arg_4846) } else { seq__1641000553__18 = linked_4844.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4843, arg_4846) }; var first__1641000554__19 any; var root_4847 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4847, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4849 lang.IFn; if linked_4848 == nil { ifn_4849 = lang.IFn_Cast(root_4847) } else { ifn_4849 = nil }; var arg_4850 any = seq__1641000553__18; if linked_4848 == nil { first__1641000554__19 = ifn_4849.Invoke_O__O(arg_4850) } else { first__1641000554__19 = linked_4848.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4847, arg_4850) }; var seq__1641000553__20 any; var root_4851 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4851, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4853 lang.IFn; if linked_4852 == nil { ifn_4853 = lang.IFn_Cast(root_4851) } else { ifn_4853 = nil }; var arg_4854 any = seq__1641000553__18; if linked_4852 == nil { seq__1641000553__20 = ifn_4853.Invoke_O__O(arg_4854) } else { seq__1641000553__20 = linked_4852.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4851, arg_4854) }; var od__21 any = first__1641000554__19; var dumps__22 any = seq__1641000553__20; var tmp2 *lang.Compiler_AOTFn; var fnbody__4876 any = A_arbace_o2j__main_fn__1641000555_A_New_O_O_O(od__21, dumps__22, lo__10); var tmp3 *jrt.Class
				var fncls__4875 /*line :691:1*/*jrt.Class = A_arbace_o2j__main_fn__1641000555_A_fn_class

				if fncls__4875 == nil { var fncls__4875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__4876); A_arbace_o2j__main_fn__1641000555_A_fn_class = fncls__4875d; tmp3 = fncls__4875d } else { tmp3 = fncls__4875 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4876, tmp3, nil); Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :691:1
				seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, i_1641000551__15 = seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000551__15); continue L2 } else { seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, i_1641000551__15 = seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000551__15); continue L2 } } else { var temp__1927000414__auto____16 any; var root_4533 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4535 lang.IFn; if linked_4534 == nil { ifn_4535 = lang.IFn_Cast(root_4533) } else { ifn_4535 = nil }; var arg_4536 any = seq_1641000548__12; if linked_4534 == nil { temp__1927000414__auto____16 = ifn_4535.Invoke_O__O(arg_4536) } else { temp__1927000414__auto____16 = linked_4534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4533, arg_4536) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1641000548__17 any = temp__1927000414__auto____16; var tmp4 any; var root_4537 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4537, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4539 lang.IFn; if linked_4538 == nil { ifn_4539 = lang.IFn_Cast(root_4537) } else { ifn_4539 = nil }; var arg_4540 any = seq_1641000548__17; if linked_4538 == nil { tmp4 = ifn_4539.Invoke_O__O(arg_4540) } else { tmp4 = linked_4538.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4537, arg_4540) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_4541 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4541, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4543 lang.IFn; if linked_4542 == nil { ifn_4543 = lang.IFn_Cast(root_4541) } else { ifn_4543 = nil }; var arg_4544 any = seq_1641000548__17; if linked_4542 == nil { c__1927000678__auto____18 = ifn_4543.Invoke_O__O(arg_4544) } else { c__1927000678__auto____18 = linked_4542.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4541, arg_4544) }; var tmp5 any; var root_4877 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4877, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4879 lang.IFn; if linked_4878 == nil { ifn_4879 = lang.IFn_Cast(root_4877) } else { ifn_4879 = nil }; var arg_4880 any = seq_1641000548__17; if linked_4878 == nil { tmp5 = ifn_4879.Invoke_O__O(arg_4880) } else { tmp5 = linked_4878.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4877, arg_4880) }; seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, i_1641000551__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var line__18 any; var root_4545 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4545, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4547 lang.IFn; if linked_4546 == nil { ifn_4547 = lang.IFn_Cast(root_4545) } else { ifn_4547 = nil }; var arg_4548 any = seq_1641000548__17; if linked_4546 == nil { line__18 = ifn_4547.Invoke_O__O(arg_4548) } else { line__18 = linked_4546.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4545, arg_4548) }; var tmp6 any; var root_4549 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4549, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4551 lang.IFn; if linked_4550 == nil { ifn_4551 = lang.IFn_Cast(root_4549) } else { ifn_4551 = nil }; var arg_4552 any = line__18; if linked_4550 == nil { tmp6 = ifn_4551.Invoke_O__O(arg_4552) } else { tmp6 = linked_4550.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4549, arg_4552) }; if jrt.J2g_Truth(tmp6) { var vec__1641000557__19 any; var root_4881 any = A_arbace_o2j_A_const_228.GetRawRoot__O(); var linked_4882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4881, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_4883 lang.IFn
					if linked_4882 == nil { ifn_4883 = lang.IFn_Cast(root_4881) } else { ifn_4883 = nil }; var arg_4884 any = line__18; var arg_4885 any = A_arbace_o2j_A_const_543; if linked_4882 == nil { vec__1641000557__19 = ifn_4883.Invoke_O_O__O(arg_4884, arg_4885) } else { vec__1641000557__19 = linked_4882.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_4881, arg_4884, arg_4885) }
//line :691:1
					var seq__1641000558__20 any; var root_4886 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4886, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4888 lang.IFn; if linked_4887 == nil { ifn_4888 = lang.IFn_Cast(root_4886) } else { ifn_4888 = nil }; var arg_4889 any = vec__1641000557__19; if linked_4887 == nil { seq__1641000558__20 = ifn_4888.Invoke_O__O(arg_4889) } else { seq__1641000558__20 = linked_4887.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4886, arg_4889) }; var first__1641000559__21 any; var root_4890 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4890, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4892 lang.IFn; if linked_4891 == nil { ifn_4892 = lang.IFn_Cast(root_4890) } else { ifn_4892 = nil }; var arg_4893 any = seq__1641000558__20; if linked_4891 == nil { first__1641000559__21 = ifn_4892.Invoke_O__O(arg_4893) } else { first__1641000559__21 = linked_4891.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4890, arg_4893) }; var seq__1641000558__22 any; var root_4894 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4894, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4896 lang.IFn; if linked_4895 == nil { ifn_4896 = lang.IFn_Cast(root_4894) } else { ifn_4896 = nil }; var arg_4897 any = seq__1641000558__20; if linked_4895 == nil { seq__1641000558__22 = ifn_4896.Invoke_O__O(arg_4897) } else { seq__1641000558__22 = linked_4895.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4894, arg_4897) }; var od__23 any = first__1641000559__21; var dumps__24 any = seq__1641000558__22; var tmp7 *lang.Compiler_AOTFn; var fnbody__4919 any = A_arbace_o2j__main_fn__1641000560_A_New_O_O_O(dumps__24, lo__10, od__23); var tmp8 *jrt.Class
					var fncls__4918 /*line :691:1*/*jrt.Class = A_arbace_o2j__main_fn__1641000560_A_fn_class

					if fncls__4918 == nil { var fncls__4918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__4919); A_arbace_o2j__main_fn__1641000560_A_fn_class = fncls__4918d; tmp8 = fncls__4918d } else { tmp8 = fncls__4918 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4919, tmp8, nil); Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()
//line :691:1
					var tmp9 any; var root_4920 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4920, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4922 lang.IFn; if linked_4921 == nil { ifn_4922 = lang.IFn_Cast(root_4920) } else { ifn_4922 = nil }; var arg_4923 any = seq_1641000548__17; if linked_4921 == nil { tmp9 = ifn_4922.Invoke_O__O(arg_4923) } else { tmp9 = linked_4921.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4920, arg_4923) }; seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, i_1641000551__15 = tmp9, nil, 0, 0; continue L2 } else { var tmp10 any; var root_4924 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4924, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4926 lang.IFn; if linked_4925 == nil { ifn_4926 = lang.IFn_Cast(root_4924) } else { ifn_4926 = nil }; var arg_4927 any = seq_1641000548__17; if linked_4925 == nil { tmp10 = ifn_4926.Invoke_O__O(arg_4927) } else { tmp10 = linked_4925.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4924, arg_4927) }; seq_1641000548__12, chunk_1641000549__13, count_1641000550__14, i_1641000551__15 = tmp10, nil, 0, 0; continue L2 } } } else { return nil } } } }
//line :668:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000544__8_, Lit_6) { var seq_1641000562__9 any; var root_4553 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4553, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4555 lang.IFn
		if linked_4554 == nil { ifn_4555 = lang.IFn_Cast(root_4553) } else { ifn_4555 = nil }; var arg_4556 any; var root_4557 any = A_arbace_o2j_A_const_539.GetRawRoot__O(); var linked_4558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4557, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_4559 lang.IFn; if linked_4558 == nil { ifn_4559 = lang.IFn_Cast(root_4557) } else { ifn_4559 = nil }; var arg_4560 any = A_arbace_o2j_A_const_60; var arg_4561 any = args__7; if linked_4558 == nil { arg_4556 = ifn_4559.Invoke_O_O__O(arg_4560, arg_4561) } else { arg_4556 = linked_4558.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_4557, arg_4560, arg_4561) }; if linked_4554 == nil { seq_1641000562__9 = ifn_4555.Invoke_O__O(arg_4556) } else { seq_1641000562__9 = linked_4554.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4553, arg_4556) }
//line :668:1
		var chunk_1641000563__10 any; var count_1641000564__11 int64 = 0; var i_1641000565__12 int64 = 0; L3: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000565__12, count_1641000564__11) { var vec__1641000566__13 any = lang.Indexed_Cast(chunk_1641000563__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000565__12)); var d__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000566__13, lang.RT_IntCast_J__I_NoInit(0), nil); var o__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000566__13, lang.RT_IntCast_J__I_NoInit(1), nil); var u__16 any; var root_4928 any = A_arbace_o2j_A_const_531.GetRawRoot__O(); var linked_4929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4928, A_arbace_o2j_read_dump_A_fn_class); var ifn_4930 lang.IFn
				if linked_4929 == nil { ifn_4930 = lang.IFn_Cast(root_4928) } else { ifn_4930 = nil }; var arg_4931 any; var root_4932 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4932, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4934 lang.IFn; if linked_4933 == nil { ifn_4934 = lang.IFn_Cast(root_4932) } else { ifn_4934 = nil }; var arg_4935 any = d__14; if linked_4933 == nil { arg_4931 = ifn_4934.Invoke_O__O(arg_4935) } else { arg_4931 = linked_4933.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_4932, arg_4935) }; if linked_4929 == nil { u__16 = ifn_4930.Invoke_O__O(arg_4931) } else { u__16 = linked_4929.(*A_arbace_o2j_read_dump_A).Invoke_O_O__O(root_4928, arg_4931) }
//line :669:1
				var vec__1641000569__17 any; var root_4936 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_4937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4936, A_arbace_o2j_translate_unit_A_fn_class); var ifn_4938 lang.IFn

				if linked_4937 == nil { ifn_4938 = lang.IFn_Cast(root_4936) } else { ifn_4938 = nil }; var arg_4939 any = u__16; if linked_4937 == nil { vec__1641000569__17 = ifn_4938.Invoke_O__O(arg_4939) } else { vec__1641000569__17 = linked_4937.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_4936, arg_4939) }
//line :669:1
				var forms__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000569__17, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000569__17, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4964 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4964, A_arbace_o2j_write_forms_A_fn_class); var ifn_4966 lang.IFn


				if linked_4965 == nil { ifn_4966 = lang.IFn_Cast(root_4964) } else { ifn_4966 = nil }; var arg_4967 any; var root_4970 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4971 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4970, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4972 lang.IFn; if linked_4971 == nil { ifn_4972 = lang.IFn_Cast(root_4970) } else { ifn_4972 = nil }; var arg_4973 any = o__15; if linked_4971 == nil { arg_4967 = ifn_4972.Invoke_O__O(arg_4973) } else { arg_4967 = linked_4971.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_4970, arg_4973) }; var arg_4968 any = forms__18; var arg_4969 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil)).Ref(); if linked_4965 == nil { ifn_4966.Invoke_O_O_O__O(arg_4967, arg_4968, arg_4969) } else { linked_4965.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4964, arg_4967, arg_4968, arg_4969) }
//line :669:1
				var seq_1641000572__20 any; var root_4940 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4940, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4942 lang.IFn



				if linked_4941 == nil { ifn_4942 = lang.IFn_Cast(root_4940) } else { ifn_4942 = nil }; var arg_4943 any; var root_4944 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_4945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4944, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4946 lang.IFn; if linked_4945 == nil { ifn_4946 = lang.IFn_Cast(root_4944) } else { ifn_4946 = nil }; var arg_4947 any = missing__19; if linked_4945 == nil { arg_4943 = ifn_4946.Invoke_O__O(arg_4947) } else { arg_4943 = linked_4945.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4944, arg_4947) }; if linked_4941 == nil { seq_1641000572__20 = ifn_4942.Invoke_O__O(arg_4943) } else { seq_1641000572__20 = linked_4941.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4940, arg_4943) }
//line :669:1
				var chunk_1641000573__21 any; var count_1641000574__22 int64 = 0; var i_1641000575__23 int64 = 0; L4: for {



					if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000575__23, count_1641000574__22) { var vec__1641000576__24 any = lang.Indexed_Cast(chunk_1641000573__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000575__23)); var n__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000576__24, lang.RT_IntCast_J__I_NoInit(0), nil); var c__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000576__24, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil, n__25, nil, c__26)).Ref()); seq_1641000572__20, chunk_1641000573__21, count_1641000574__22, i_1641000575__23 = seq_1641000572__20, chunk_1641000573__21, count_1641000574__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000575__23); continue L4 } else { var temp__1927000414__auto____24 any; var root_4948 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4950 lang.IFn; if linked_4949 == nil { ifn_4950 = lang.IFn_Cast(root_4948) } else { ifn_4950 = nil }; var arg_4951 any = seq_1641000572__20; if linked_4949 == nil { temp__1927000414__auto____24 = ifn_4950.Invoke_O__O(arg_4951) } else { temp__1927000414__auto____24 = linked_4949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4948, arg_4951) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1641000572__25 any = temp__1927000414__auto____24; var tmp11 any; var root_4952 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4952, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4954 lang.IFn; if linked_4953 == nil { ifn_4954 = lang.IFn_Cast(root_4952) } else { ifn_4954 = nil }; var arg_4955 any = seq_1641000572__25; if linked_4953 == nil { tmp11 = ifn_4954.Invoke_O__O(arg_4955) } else { tmp11 = linked_4953.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4952, arg_4955) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____26 any; var root_4956 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4956, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4958 lang.IFn; if linked_4957 == nil { ifn_4958 = lang.IFn_Cast(root_4956) } else { ifn_4958 = nil }; var arg_4959 any = seq_1641000572__25; if linked_4957 == nil { c__1927000678__auto____26 = ifn_4958.Invoke_O__O(arg_4959) } else { c__1927000678__auto____26 = linked_4957.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4956, arg_4959) }; var tmp12 any; var root_4978 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4978, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4980 lang.IFn; if linked_4979 == nil { ifn_4980 = lang.IFn_Cast(root_4978) } else { ifn_4980 = nil }; var arg_4981 any = seq_1641000572__25; if linked_4979 == nil { tmp12 = ifn_4980.Invoke_O__O(arg_4981) } else { tmp12 = linked_4979.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4978, arg_4981) }; seq_1641000572__20, chunk_1641000573__21, count_1641000574__22, i_1641000575__23 = tmp12, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1641000579__26 any; var root_4960 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4962 lang.IFn; if linked_4961 == nil { ifn_4962 = lang.IFn_Cast(root_4960) } else { ifn_4962 = nil }; var arg_4963 any = seq_1641000572__25; if linked_4961 == nil { vec__1641000579__26 = ifn_4962.Invoke_O__O(arg_4963) } else { vec__1641000579__26 = linked_4961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4960, arg_4963) }; var n__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000579__26, lang.RT_IntCast_J__I_NoInit(0), nil); var c__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000579__26, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__16), nil, n__27, nil, c__28)).Ref()); var tmp13 any; var root_4986 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4986, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4988 lang.IFn; if linked_4987 == nil { ifn_4988 = lang.IFn_Cast(root_4986) } else { ifn_4988 = nil }; var arg_4989 any = seq_1641000572__25; if linked_4987 == nil { tmp13 = ifn_4988.Invoke_O__O(arg_4989) } else { tmp13 = linked_4987.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4986, arg_4989) }; seq_1641000572__20, chunk_1641000573__21, count_1641000574__22, i_1641000575__23 = tmp13, nil, 0, 0; continue L4 } } }
//line :669:1
					break L4 }; seq_1641000562__9, chunk_1641000563__10, count_1641000564__11, i_1641000565__12 = seq_1641000562__9, chunk_1641000563__10, count_1641000564__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000565__12); continue L3 } else { var temp__1927000414__auto____13 any; var root_4562 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4562, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4564 lang.IFn; if linked_4563 == nil { ifn_4564 = lang.IFn_Cast(root_4562) } else { ifn_4564 = nil }; var arg_4565 any = seq_1641000562__9; if linked_4563 == nil { temp__1927000414__auto____13 = ifn_4564.Invoke_O__O(arg_4565) } else { temp__1927000414__auto____13 = linked_4563.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4562, arg_4565) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1641000562__14 any = temp__1927000414__auto____13; var tmp14 any; var root_4566 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4566, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4568 lang.IFn; if linked_4567 == nil { ifn_4568 = lang.IFn_Cast(root_4566) } else { ifn_4568 = nil }; var arg_4569 any = seq_1641000562__14; if linked_4567 == nil { tmp14 = ifn_4568.Invoke_O__O(arg_4569) } else { tmp14 = linked_4567.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4566, arg_4569) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____15 any; var root_4570 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4570, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4572 lang.IFn; if linked_4571 == nil { ifn_4572 = lang.IFn_Cast(root_4570) } else { ifn_4572 = nil }; var arg_4573 any = seq_1641000562__14; if linked_4571 == nil { c__1927000678__auto____15 = ifn_4572.Invoke_O__O(arg_4573) } else { c__1927000678__auto____15 = linked_4571.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4570, arg_4573) }; var tmp15 any; var root_4990 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4990, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4992 lang.IFn; if linked_4991 == nil { ifn_4992 = lang.IFn_Cast(root_4990) } else { ifn_4992 = nil }; var arg_4993 any = seq_1641000562__14; if linked_4991 == nil { tmp15 = ifn_4992.Invoke_O__O(arg_4993) } else { tmp15 = linked_4991.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4990, arg_4993) }; seq_1641000562__9, chunk_1641000563__10, count_1641000564__11, i_1641000565__12 = tmp15, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1641000582__15 any; var root_4574 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4576 lang.IFn; if linked_4575 == nil { ifn_4576 = lang.IFn_Cast(root_4574) } else { ifn_4576 = nil }; var arg_4577 any = seq_1641000562__14; if linked_4575 == nil { vec__1641000582__15 = ifn_4576.Invoke_O__O(arg_4577) } else { vec__1641000582__15 = linked_4575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4574, arg_4577) }; var d__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000582__15, lang.RT_IntCast_J__I_NoInit(0), nil); var o__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000582__15, lang.RT_IntCast_J__I_NoInit(1), nil); var u__18 any; var root_4994 any = A_arbace_o2j_A_const_531.GetRawRoot__O(); var linked_4995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4994, A_arbace_o2j_read_dump_A_fn_class); var ifn_4996 lang.IFn
						if linked_4995 == nil { ifn_4996 = lang.IFn_Cast(root_4994) } else { ifn_4996 = nil }; var arg_4997 any; var root_4998 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4998, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_5000 lang.IFn; if linked_4999 == nil { ifn_5000 = lang.IFn_Cast(root_4998) } else { ifn_5000 = nil }; var arg_5001 any = d__16; if linked_4999 == nil { arg_4997 = ifn_5000.Invoke_O__O(arg_5001) } else { arg_4997 = linked_4999.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_4998, arg_5001) }; if linked_4995 == nil { u__18 = ifn_4996.Invoke_O__O(arg_4997) } else { u__18 = linked_4995.(*A_arbace_o2j_read_dump_A).Invoke_O_O__O(root_4994, arg_4997) }
//line :669:1
						var vec__1641000585__19 any; var root_5002 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_5003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5002, A_arbace_o2j_translate_unit_A_fn_class); var ifn_5004 lang.IFn

						if linked_5003 == nil { ifn_5004 = lang.IFn_Cast(root_5002) } else { ifn_5004 = nil }; var arg_5005 any = u__18; if linked_5003 == nil { vec__1641000585__19 = ifn_5004.Invoke_O__O(arg_5005) } else { vec__1641000585__19 = linked_5003.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_5002, arg_5005) }
//line :669:1
						var forms__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000585__19, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000585__19, lang.RT_IntCast_J__I_NoInit(1), nil); var root_5030 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_5031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5030, A_arbace_o2j_write_forms_A_fn_class); var ifn_5032 lang.IFn


						if linked_5031 == nil { ifn_5032 = lang.IFn_Cast(root_5030) } else { ifn_5032 = nil }; var arg_5033 any; var root_5036 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_5037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5036, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_5038 lang.IFn; if linked_5037 == nil { ifn_5038 = lang.IFn_Cast(root_5036) } else { ifn_5038 = nil }; var arg_5039 any = o__17; if linked_5037 == nil { arg_5033 = ifn_5038.Invoke_O__O(arg_5039) } else { arg_5033 = linked_5037.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_5036, arg_5039) }; var arg_5034 any = forms__20; var arg_5035 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__18), nil)).Ref(); if linked_5031 == nil { ifn_5032.Invoke_O_O_O__O(arg_5033, arg_5034, arg_5035) } else { linked_5031.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_5030, arg_5033, arg_5034, arg_5035) }
//line :669:1
						var seq_1641000588__22 any; var root_5006 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_5007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5006, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_5008 lang.IFn



						if linked_5007 == nil { ifn_5008 = lang.IFn_Cast(root_5006) } else { ifn_5008 = nil }; var arg_5009 any; var root_5010 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_5011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5010, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_5012 lang.IFn; if linked_5011 == nil { ifn_5012 = lang.IFn_Cast(root_5010) } else { ifn_5012 = nil }; var arg_5013 any = missing__21; if linked_5011 == nil { arg_5009 = ifn_5012.Invoke_O__O(arg_5013) } else { arg_5009 = linked_5011.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_5010, arg_5013) }; if linked_5007 == nil { seq_1641000588__22 = ifn_5008.Invoke_O__O(arg_5009) } else { seq_1641000588__22 = linked_5007.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_5006, arg_5009) }
//line :669:1
						var chunk_1641000589__23 any; var count_1641000590__24 int64 = 0; var i_1641000591__25 int64 = 0; L5: for {



							if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000591__25, count_1641000590__24) { var vec__1641000592__26 any = lang.Indexed_Cast(chunk_1641000589__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000591__25)); var n__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000592__26, lang.RT_IntCast_J__I_NoInit(0), nil); var c__28_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000592__26, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__18), nil, n__27_2, nil, c__28_2)).Ref()); seq_1641000588__22, chunk_1641000589__23, count_1641000590__24, i_1641000591__25 = seq_1641000588__22, chunk_1641000589__23, count_1641000590__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000591__25); continue L5 } else { var temp__1927000414__auto____26 any; var root_5014 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_5015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_5016 lang.IFn; if linked_5015 == nil { ifn_5016 = lang.IFn_Cast(root_5014) } else { ifn_5016 = nil }; var arg_5017 any = seq_1641000588__22; if linked_5015 == nil { temp__1927000414__auto____26 = ifn_5016.Invoke_O__O(arg_5017) } else { temp__1927000414__auto____26 = linked_5015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_5014, arg_5017) }; if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1641000588__27 any = temp__1927000414__auto____26; var tmp16 any; var root_5018 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_5019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5018, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_5020 lang.IFn; if linked_5019 == nil { ifn_5020 = lang.IFn_Cast(root_5018) } else { ifn_5020 = nil }; var arg_5021 any = seq_1641000588__27; if linked_5019 == nil { tmp16 = ifn_5020.Invoke_O__O(arg_5021) } else { tmp16 = linked_5019.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_5018, arg_5021) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____28 any; var root_5022 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_5023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5022, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_5024 lang.IFn; if linked_5023 == nil { ifn_5024 = lang.IFn_Cast(root_5022) } else { ifn_5024 = nil }; var arg_5025 any = seq_1641000588__27; if linked_5023 == nil { c__1927000678__auto____28 = ifn_5024.Invoke_O__O(arg_5025) } else { c__1927000678__auto____28 = linked_5023.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_5022, arg_5025) }; var tmp17 any; var root_5044 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_5045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5044, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_5046 lang.IFn; if linked_5045 == nil { ifn_5046 = lang.IFn_Cast(root_5044) } else { ifn_5046 = nil }; var arg_5047 any = seq_1641000588__27; if linked_5045 == nil { tmp17 = ifn_5046.Invoke_O__O(arg_5047) } else { tmp17 = linked_5045.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_5044, arg_5047) }; seq_1641000588__22, chunk_1641000589__23, count_1641000590__24, i_1641000591__25 = tmp17, c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1641000595__28 any; var root_5026 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_5027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_5028 lang.IFn; if linked_5027 == nil { ifn_5028 = lang.IFn_Cast(root_5026) } else { ifn_5028 = nil }; var arg_5029 any = seq_1641000588__27; if linked_5027 == nil { vec__1641000595__28 = ifn_5028.Invoke_O__O(arg_5029) } else { vec__1641000595__28 = linked_5027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_5026, arg_5029) }; var n__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000595__28, lang.RT_IntCast_J__I_NoInit(0), nil); var c__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000595__28, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_o2j_A_const_21.Invoke_O__O(u__18), nil, n__29, nil, c__30)).Ref()); var tmp18 any; var root_5052 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_5053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5052, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_5054 lang.IFn; if linked_5053 == nil { ifn_5054 = lang.IFn_Cast(root_5052) } else { ifn_5054 = nil }; var arg_5055 any = seq_1641000588__27; if linked_5053 == nil { tmp18 = ifn_5054.Invoke_O__O(arg_5055) } else { tmp18 = linked_5053.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_5052, arg_5055) }; seq_1641000588__22, chunk_1641000589__23, count_1641000590__24, i_1641000591__25 = tmp18, nil, 0, 0; continue L5 } } }
//line :669:1
							break L5 }; var tmp19 any; var root_5056 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_5057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5056, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_5058 lang.IFn; if linked_5057 == nil { ifn_5058 = lang.IFn_Cast(root_5056) } else { ifn_5058 = nil }; var arg_5059 any = seq_1641000562__14; if linked_5057 == nil { tmp19 = ifn_5058.Invoke_O__O(arg_5059) } else { tmp19 = linked_5057.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_5056, arg_5059) }; seq_1641000562__9, chunk_1641000563__10, count_1641000564__11, i_1641000565__12 = tmp19, nil, 0, 0; continue L3 } } else { return nil } } } }
//line :668:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000544__8_, Lit_11) { var vec__1641000598__9 any = args__7; var ld__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000598__9, lang.RT_IntCast_J__I_NoInit(0), nil); var od__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000598__9, lang.RT_IntCast_J__I_NoInit(1), nil); var order__12 any; var root_4578 any = A_arbace_o2j_A_const_538.GetRawRoot__O(); var linked_4579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4578, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_4580 lang.IFn







		if linked_4579 == nil { ifn_4580 = lang.IFn_Cast(root_4578) } else { ifn_4580 = nil }; var arg_4581 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_528.GetRawRoot__O()); var tmp21 any; var root_4586 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4587 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4586, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4588 lang.IFn; if linked_4587 == nil { ifn_4588 = lang.IFn_Cast(root_4586) } else { ifn_4588 = nil }; var arg_4589 any = ld__10; var arg_4590 any = Lit_12; if linked_4587 == nil { tmp21 = ifn_4588.Invoke_O_O__O(arg_4589, arg_4590) } else { tmp21 = linked_4587.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4586, arg_4589, arg_4590) }; arg_4581 = tmp20.Invoke_O__O(tmp21); if linked_4579 == nil { order__12 = ifn_4580.Invoke_O__O(arg_4581) } else { order__12 = linked_4579.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_4578, arg_4581) }
//line :668:1
		var deps__13 any; var root_4591 any = A_arbace_o2j_A_const_49.GetRawRoot__O(); var linked_4592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4591, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_4593 lang.IFn








		if linked_4592 == nil { ifn_4593 = lang.IFn_Cast(root_4591) } else { ifn_4593 = nil }; var arg_4594 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_4595 any; var iter__1927001039__auto____13 any; var fnbody__4793 any = A_arbace_o2j__main_iter__1641000601__1641000605_A_New_O_O(od__11, ld__10); var tmp22 *jrt.Class; var fncls__4792 *jrt.Class = A_arbace_o2j__main_iter__1641000601__1641000605_A_fn_class; if fncls__4792 == nil { var fncls__4792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__4793); A_arbace_o2j__main_iter__1641000601__1641000605_A_fn_class = fncls__4792d; tmp22 = fncls__4792d } else { tmp22 = fncls__4792 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4793, tmp22, nil); arg_4595 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(order__12); if linked_4592 == nil { deps__13 = ifn_4593.Invoke_O_O__O(arg_4594, arg_4595) } else { deps__13 = linked_4592.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_4591, arg_4594, arg_4595)
		}





		var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_533.GetRawRoot__O()); var tmp24 any; var root_4799 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4799, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4801 lang.IFn; if linked_4800 == nil { ifn_4801 = lang.IFn_Cast(root_4799) } else { ifn_4801 = nil }; var arg_4802 any = od__11; var arg_4803 any = Lit_14; if linked_4800 == nil { tmp24 = ifn_4801.Invoke_O_O__O(arg_4802, arg_4803) } else { tmp24 = linked_4800.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4799, arg_4802, arg_4803) }; return tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_o2j_A_const_540.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_o2j_A_const_529, order__12, A_arbace_o2j_A_const_530, deps__13)))) }
//line :668:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000544__8_, Lit_15) { var vec__1641000637__9 any = args__7; var seq__1641000638__10 any; var root_4808 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4808, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4810 lang.IFn


















		if linked_4809 == nil { ifn_4810 = lang.IFn_Cast(root_4808) } else { ifn_4810 = nil }; var arg_4811 any = vec__1641000637__9; if linked_4809 == nil { seq__1641000638__10 = ifn_4810.Invoke_O__O(arg_4811) } else { seq__1641000638__10 = linked_4809.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4808, arg_4811) }
//line :668:1
		var first__1641000639__11 any; var root_4812 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4812, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4814 lang.IFn


















		if linked_4813 == nil { ifn_4814 = lang.IFn_Cast(root_4812) } else { ifn_4814 = nil }; var arg_4815 any = seq__1641000638__10; if linked_4813 == nil { first__1641000639__11 = ifn_4814.Invoke_O__O(arg_4815) } else { first__1641000639__11 = linked_4813.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4812, arg_4815) }
//line :668:1
		var seq__1641000638__12 any; var root_4816 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4816, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4818 lang.IFn


















		if linked_4817 == nil { ifn_4818 = lang.IFn_Cast(root_4816) } else { ifn_4818 = nil }; var arg_4819 any = seq__1641000638__10; if linked_4817 == nil { seq__1641000638__12 = ifn_4818.Invoke_O__O(arg_4819) } else { seq__1641000638__12 = linked_4817.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4816, arg_4819) }
//line :668:1
		var lo__13 any = first__1641000639__11; var first__1641000639__14 any; var root_4820 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4820, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4822 lang.IFn


















		if linked_4821 == nil { ifn_4822 = lang.IFn_Cast(root_4820) } else { ifn_4822 = nil }; var arg_4823 any = seq__1641000638__12; if linked_4821 == nil { first__1641000639__14 = ifn_4822.Invoke_O__O(arg_4823) } else { first__1641000639__14 = linked_4821.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4820, arg_4823) }
//line :668:1
		var seq__1641000638__15 any; var root_4824 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4824, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4826 lang.IFn


















		if linked_4825 == nil { ifn_4826 = lang.IFn_Cast(root_4824) } else { ifn_4826 = nil }; var arg_4827 any = seq__1641000638__12; if linked_4825 == nil { seq__1641000638__15 = ifn_4826.Invoke_O__O(arg_4827) } else { seq__1641000638__15 = linked_4825.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4824, arg_4827) }
//line :668:1
		var od__16 any = first__1641000639__14; var dumps__17 any = seq__1641000638__15; var root_4828 any = A_arbace_o2j_A_const_541.GetRawRoot__O(); var linked_4829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4828, A_arbace_o2j_translate_program_A_fn_class); var ifn_4830 lang.IFn


















		if linked_4829 == nil { ifn_4830 = lang.IFn_Cast(root_4828) } else { ifn_4830 = nil }; var arg_4831 any = lo__13; var arg_4832 any = od__16; var arg_4833 any = dumps__17; if linked_4829 == nil { return ifn_4830.Invoke_O_O_O__O(arg_4831, arg_4832, arg_4833) } else { return linked_4829.(*A_arbace_o2j_translate_program_A).Invoke_O_O_O_O__O(root_4828, arg_4831, arg_4832, arg_4833) } }
//line :668:1
	case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1641000544__8_, Lit_16) { var vec__1641000640__9 any = args__7; var seq__1641000641__10 any; var root_5060 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_5061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5060, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_5062 lang.IFn



























		if linked_5061 == nil { ifn_5062 = lang.IFn_Cast(root_5060) } else { ifn_5062 = nil }; var arg_5063 any = vec__1641000640__9; if linked_5061 == nil { seq__1641000641__10 = ifn_5062.Invoke_O__O(arg_5063) } else { seq__1641000641__10 = linked_5061.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_5060, arg_5063) }
//line :668:1
		var first__1641000642__11 any; var root_5064 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_5065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5064, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_5066 lang.IFn



























		if linked_5065 == nil { ifn_5066 = lang.IFn_Cast(root_5064) } else { ifn_5066 = nil }; var arg_5067 any = seq__1641000641__10; if linked_5065 == nil { first__1641000642__11 = ifn_5066.Invoke_O__O(arg_5067) } else { first__1641000642__11 = linked_5065.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_5064, arg_5067) }
//line :668:1
		var seq__1641000641__12 any; var root_5068 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_5069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5068, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_5070 lang.IFn



























		if linked_5069 == nil { ifn_5070 = lang.IFn_Cast(root_5068) } else { ifn_5070 = nil }; var arg_5071 any = seq__1641000641__10; if linked_5069 == nil { seq__1641000641__12 = ifn_5070.Invoke_O__O(arg_5071) } else { seq__1641000641__12 = linked_5069.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_5068, arg_5071) }
//line :668:1
		var o__13 any = first__1641000642__11; var units__14 any = seq__1641000641__12; var root_5072 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_5073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5072, A_arbace_o2j_write_forms_A_fn_class); var ifn_5074 lang.IFn




























		if linked_5073 == nil { ifn_5074 = lang.IFn_Cast(root_5072) } else { ifn_5074 = nil }; var arg_5075 any; var root_5078 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_5079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5078, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_5080 lang.IFn; if linked_5079 == nil { ifn_5080 = lang.IFn_Cast(root_5078) } else { ifn_5080 = nil }; var arg_5081 any = o__13; if linked_5079 == nil { arg_5075 = ifn_5080.Invoke_O__O(arg_5081) } else { arg_5075 = linked_5079.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_5078, arg_5081) }; var arg_5076 any; var root_5082 any = A_arbace_o2j_A_const_536.GetRawRoot__O(); var linked_5083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5082, A_arbace_o2j_main_forms_A_fn_class); var ifn_5084 lang.IFn; if linked_5083 == nil { ifn_5084 = lang.IFn_Cast(root_5082) } else { ifn_5084 = nil }; var arg_5085 any = units__14; if linked_5083 == nil { arg_5076 = ifn_5084.Invoke_O__O(arg_5085) } else { arg_5076 = linked_5083.(*A_arbace_o2j_main_forms_A).Invoke_O_O__O(root_5082, arg_5085) }; var arg_5077 any = Lit_17; if linked_5073 == nil { return ifn_5074.Invoke_O_O_O__O(arg_5075, arg_5076, arg_5077) } else { return linked_5073.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_5072, arg_5075, arg_5076, arg_5077) } }
//line :668:1
	default:};





























	lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(Lit_18); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :677:1
func A_arbace_o2j__main_iter__1641000601__1641000605_A_New_O_O(p0, p1 any) *A_arbace_o2j__main_iter__1641000601__1641000605_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_iter__1641000601__1641000605_A{}; t.Ctor_O_O(p0, p1); return t }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_A) Ctor_O_O(c__od, c__ld any) { t.F_od = c__od; t.F_ld = c__ld }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_A) Invoke_O_O__O(self, s__1641000602__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4791 any = A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A_New_O_O_O_O(self, t.F_od, t.F_ld, s__1641000602__1); var tmp2 *jrt.Class; var fncls__4790 *jrt.Class = A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A_fn_class; if fncls__4790 == nil { var fncls__4790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__4791); A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A_fn_class = fncls__4790d; tmp2 = fncls__4790d } else { tmp2 = fncls__4790 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4791, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :677:1
func A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A) Ctor_O_O_O_O(c__iter__1641000601, c__od, c__ld, c__s__1641000602 any) { t.F_iter__1641000601 = c__iter__1641000601; t.F_od = c__od; t.F_ld = c__ld; t.F_s__1641000602 = c__s__1641000602 }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A) Invoke_O__O(self any) any { { var s__1641000602__1 any; var t_ any = t.F_s__1641000602; t.F_s__1641000602 = nil; s__1641000602__1 = t_; for { var temp__1927000414__auto____2 any; var root_4596 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4596, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4598 lang.IFn; if linked_4597 == nil { ifn_4598 = lang.IFn_Cast(root_4596) } else { ifn_4598 = nil }; var arg_4599 any = s__1641000602__1; if linked_4597 == nil { temp__1927000414__auto____2 = ifn_4598.Invoke_O__O(arg_4599) } else { temp__1927000414__auto____2 = linked_4597.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4596, arg_4599) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1641000602__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4600 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4600, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4602 lang.IFn; if linked_4601 == nil { ifn_4602 = lang.IFn_Cast(root_4600) } else { ifn_4602 = nil }; var arg_4603 any = s__1641000602__3; if linked_4601 == nil { tmp1 = ifn_4602.Invoke_O__O(arg_4603) } else { tmp1 = linked_4601.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4600, arg_4603) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4604 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4604, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4606 lang.IFn; if linked_4605 == nil { ifn_4606 = lang.IFn_Cast(root_4604) } else { ifn_4606 = nil }; var arg_4607 any = s__1641000602__3; if linked_4605 == nil { c__1927001037__auto____4 = ifn_4606.Invoke_O__O(arg_4607) } else { c__1927001037__auto____4 = linked_4605.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4604, arg_4607) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1641000604__6 any; var root_4608 any = A_arbace_o2j_A_const_56.GetRawRoot__O(); var linked_4609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4608, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4610 lang.IFn; if linked_4609 == nil { ifn_4610 = lang.IFn_Cast(root_4608) } else { ifn_4610 = nil }; var arg_4611 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4609 == nil { b__1641000604__6 = ifn_4610.Invoke_O__O(arg_4611) } else { b__1641000604__6 = linked_4609.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4608, arg_4611) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4686 any = A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A_New_O_O_O_I_O(b__1641000604__6, t.F_od, t.F_ld, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4685 *jrt.Class = A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A_fn_class; if fncls__4685 == nil { var fncls__4685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__4686); A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A_fn_class = fncls__4685d; tmp3 = fncls__4685d } else { tmp3 = fncls__4685 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4686, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4687 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4687, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4689 lang.IFn; if linked_4688 == nil { ifn_4689 = lang.IFn_Cast(root_4687) } else { ifn_4689 = nil }; var arg_4690 any; var root_4692 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4692, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4694 lang.IFn; if linked_4693 == nil { ifn_4694 = lang.IFn_Cast(root_4692) } else { ifn_4694 = nil }; var arg_4695 any = b__1641000604__6; if linked_4693 == nil { arg_4690 = ifn_4694.Invoke_O__O(arg_4695) } else { arg_4690 = linked_4693.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4692, arg_4695) }; var arg_4691 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1641000601); var tmp5 any; var root_4696 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4696, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4698 lang.IFn; if linked_4697 == nil { ifn_4698 = lang.IFn_Cast(root_4696) } else { ifn_4698 = nil }; var arg_4699 any = s__1641000602__3; if linked_4697 == nil { tmp5 = ifn_4698.Invoke_O__O(arg_4699) } else { tmp5 = linked_4697.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4696, arg_4699) }; arg_4691 = tmp4.Invoke_O__O(tmp5); if linked_4688 == nil { return ifn_4689.Invoke_O_O__O(arg_4690, arg_4691) } else { return linked_4688.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4687, arg_4690, arg_4691) } } else { var root_4700 any = A_arbace_o2j_A_const_62.GetRawRoot__O(); var linked_4701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4700, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4702 lang.IFn; if linked_4701 == nil { ifn_4702 = lang.IFn_Cast(root_4700) } else { ifn_4702 = nil }; var arg_4703 any; var root_4705 any = A_arbace_o2j_A_const_63.GetRawRoot__O(); var linked_4706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4705, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4707 lang.IFn; if linked_4706 == nil { ifn_4707 = lang.IFn_Cast(root_4705) } else { ifn_4707 = nil }; var arg_4708 any = b__1641000604__6; if linked_4706 == nil { arg_4703 = ifn_4707.Invoke_O__O(arg_4708) } else { arg_4703 = linked_4706.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4705, arg_4708) }; var arg_4704 any; if linked_4701 == nil { return ifn_4702.Invoke_O_O__O(arg_4703, arg_4704) } else { return linked_4701.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4700, arg_4703, arg_4704) } } } else { var n__4 any; var root_4709 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4711 lang.IFn; if linked_4710 == nil { ifn_4711 = lang.IFn_Cast(root_4709) } else { ifn_4711 = nil }; var arg_4712 any = s__1641000602__3; if linked_4710 == nil { n__4 = ifn_4711.Invoke_O__O(arg_4712) } else { n__4 = linked_4710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4709, arg_4712) }; var root_4713 any = A_arbace_o2j_A_const_65.GetRawRoot__O(); var linked_4714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4713, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4715 lang.IFn; if linked_4714 == nil { ifn_4715 = lang.IFn_Cast(root_4713) } else { ifn_4715 = nil }; var arg_4716 any; var u__5 any; var root_4718 any = A_arbace_o2j_A_const_531.GetRawRoot__O(); var linked_4719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4718, A_arbace_o2j_read_dump_A_fn_class); var ifn_4720 lang.IFn
													if linked_4719 == nil { ifn_4720 = lang.IFn_Cast(root_4718) } else { ifn_4720 = nil }; var arg_4721 any; var root_4722 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4723 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4722, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4724 lang.IFn; if linked_4723 == nil { ifn_4724 = lang.IFn_Cast(root_4722) } else { ifn_4724 = nil }; var arg_4725 any = t.F_ld; var arg_4726 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__4, nil)).Ref(); if linked_4723 == nil { arg_4721 = ifn_4724.Invoke_O_O__O(arg_4725, arg_4726) } else { arg_4721 = linked_4723.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4722, arg_4725, arg_4726) }; if linked_4719 == nil { u__5 = ifn_4720.Invoke_O__O(arg_4721) } else { u__5 = linked_4719.(*A_arbace_o2j_read_dump_A).Invoke_O_O__O(root_4718, arg_4721) }
//line :677:1
	var vec__1641000622__6 any; var root_4727 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_4728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4727, A_arbace_o2j_translate_unit_A_fn_class); var ifn_4729 lang.IFn

	if linked_4728 == nil { ifn_4729 = lang.IFn_Cast(root_4727) } else { ifn_4729 = nil }; var arg_4730 any = u__5; if linked_4728 == nil { vec__1641000622__6 = ifn_4729.Invoke_O__O(arg_4730) } else { vec__1641000622__6 = linked_4728.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_4727, arg_4730) }
//line :677:1
	var forms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000622__6, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000622__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4731 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4731, A_arbace_o2j_write_forms_A_fn_class); var ifn_4733 lang.IFn


	if linked_4732 == nil { ifn_4733 = lang.IFn_Cast(root_4731) } else { ifn_4733 = nil }; var arg_4734 any; var root_4737 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4738 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4737, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4739 lang.IFn; if linked_4738 == nil { ifn_4739 = lang.IFn_Cast(root_4737) } else { ifn_4739 = nil }; var arg_4740 any = t.F_od; var arg_4741 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__4, nil)).Ref(); if linked_4738 == nil { arg_4734 = ifn_4739.Invoke_O_O__O(arg_4740, arg_4741) } else { arg_4734 = linked_4738.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4737, arg_4740, arg_4741) }; var arg_4735 any = forms__7; var arg_4736 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil)).Ref(); if linked_4732 == nil { ifn_4733.Invoke_O_O_O__O(arg_4734, arg_4735, arg_4736) } else { linked_4732.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4731, arg_4734, arg_4735, arg_4736) }
//line :677:1
	var seq_1641000625__9 any; var root_4742 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4744 lang.IFn




	if linked_4743 == nil { ifn_4744 = lang.IFn_Cast(root_4742) } else { ifn_4744 = nil }; var arg_4745 any; var root_4746 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_4747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4746, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4748 lang.IFn; if linked_4747 == nil { ifn_4748 = lang.IFn_Cast(root_4746) } else { ifn_4748 = nil }; var arg_4749 any = missing__8; if linked_4747 == nil { arg_4745 = ifn_4748.Invoke_O__O(arg_4749) } else { arg_4745 = linked_4747.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4746, arg_4749) }; if linked_4743 == nil { seq_1641000625__9 = ifn_4744.Invoke_O__O(arg_4745) } else { seq_1641000625__9 = linked_4743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4742, arg_4745) }
//line :677:1
	var chunk_1641000626__10 any; var count_1641000627__11 int64 = 0; var i_1641000628__12 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000628__12, count_1641000627__11) { var vec__1641000629__13 any = lang.Indexed_Cast(chunk_1641000626__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000628__12)); var m__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000629__13, lang.RT_IntCast_J__I_NoInit(0), nil); var c__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000629__13, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, m__14, nil, c__15)).Ref()); seq_1641000625__9, chunk_1641000626__10, count_1641000627__11, i_1641000628__12 = seq_1641000625__9, chunk_1641000626__10, count_1641000627__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000628__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_4750 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4750, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4752 lang.IFn; if linked_4751 == nil { ifn_4752 = lang.IFn_Cast(root_4750) } else { ifn_4752 = nil }; var arg_4753 any = seq_1641000625__9; if linked_4751 == nil { temp__1927000414__auto____13 = ifn_4752.Invoke_O__O(arg_4753) } else { temp__1927000414__auto____13 = linked_4751.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4750, arg_4753) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1641000625__14 any = temp__1927000414__auto____13; var tmp6 any; var root_4754 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4754, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4756 lang.IFn; if linked_4755 == nil { ifn_4756 = lang.IFn_Cast(root_4754) } else { ifn_4756 = nil }; var arg_4757 any = seq_1641000625__14; if linked_4755 == nil { tmp6 = ifn_4756.Invoke_O__O(arg_4757) } else { tmp6 = linked_4755.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4754, arg_4757) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____15 any; var root_4758 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4758, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4760 lang.IFn; if linked_4759 == nil { ifn_4760 = lang.IFn_Cast(root_4758) } else { ifn_4760 = nil }; var arg_4761 any = seq_1641000625__14; if linked_4759 == nil { c__1927000678__auto____15 = ifn_4760.Invoke_O__O(arg_4761) } else { c__1927000678__auto____15 = linked_4759.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4758, arg_4761) }; var tmp7 any; var root_4770 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4770, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4772 lang.IFn; if linked_4771 == nil { ifn_4772 = lang.IFn_Cast(root_4770) } else { ifn_4772 = nil }; var arg_4773 any = seq_1641000625__14; if linked_4771 == nil { tmp7 = ifn_4772.Invoke_O__O(arg_4773) } else { tmp7 = linked_4771.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4770, arg_4773) }; seq_1641000625__9, chunk_1641000626__10, count_1641000627__11, i_1641000628__12 = tmp7, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1641000632__15 any; var root_4762 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4762, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4764 lang.IFn; if linked_4763 == nil { ifn_4764 = lang.IFn_Cast(root_4762) } else { ifn_4764 = nil }; var arg_4765 any = seq_1641000625__14; if linked_4763 == nil { vec__1641000632__15 = ifn_4764.Invoke_O__O(arg_4765) } else { vec__1641000632__15 = linked_4763.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4762, arg_4765) }; var m__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000632__15, lang.RT_IntCast_J__I_NoInit(0), nil); var c__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000632__15, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, m__16, nil, c__17)).Ref()); var tmp8 any; var root_4778 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4778, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4780 lang.IFn; if linked_4779 == nil { ifn_4780 = lang.IFn_Cast(root_4778) } else { ifn_4780 = nil }; var arg_4781 any = seq_1641000625__14; if linked_4779 == nil { tmp8 = ifn_4780.Invoke_O__O(arg_4781) } else { tmp8 = linked_4779.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4778, arg_4781) }; seq_1641000625__9, chunk_1641000626__10, count_1641000627__11, i_1641000628__12 = tmp8, nil, 0, 0; continue L2 } } }
//line :677:1
		break L2 }; var tmp9 any; var root_4782 any = A_arbace_o2j_A_const_526.GetRawRoot__O(); var linked_4783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4782, A_arbace_o2j_unit_refs_A_fn_class); var ifn_4784 lang.IFn





	if linked_4783 == nil { ifn_4784 = lang.IFn_Cast(root_4782) } else { ifn_4784 = nil }; var arg_4785 any = u__5; if linked_4783 == nil { tmp9 = ifn_4784.Invoke_O__O(arg_4785) } else { tmp9 = linked_4783.(*A_arbace_o2j_unit_refs_A).Invoke_O_O__O(root_4782, arg_4785) }
//line :677:1
	arg_4716 = lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp9); var arg_4717 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1641000601); var tmp11 any; var root_4786 any = A_arbace_o2j_A_const_32.GetRawRoot__O(); var linked_4787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4786, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4788 lang.IFn; if linked_4787 == nil { ifn_4788 = lang.IFn_Cast(root_4786) } else { ifn_4788 = nil }; var arg_4789 any = s__1641000602__3; if linked_4787 == nil { tmp11 = ifn_4788.Invoke_O__O(arg_4789) } else { tmp11 = linked_4787.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4786, arg_4789) }; arg_4717 = tmp10.Invoke_O__O(tmp11); if linked_4714 == nil { return ifn_4715.Invoke_O_O__O(arg_4716, arg_4717) } else { return linked_4714.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4713, arg_4716, arg_4717) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :677:1
func A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A) Ctor_O_O_O_I_O(c__b__1641000604, c__od, c__ld any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1641000604 = c__b__1641000604; t.F_od = c__od; t.F_ld = c__ld; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :677:1
func (t *A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A) Invoke_O__O(self any) any { { var i__1641000603__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1641000603__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1641000603__1)); var root_4612 any = A_arbace_o2j_A_const_61.GetRawRoot__O(); var linked_4613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4612, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4614 lang.IFn; if linked_4613 == nil { ifn_4614 = lang.IFn_Cast(root_4612) } else { ifn_4614 = nil }; var arg_4615 any = t.F_b__1641000604; var arg_4616 any; var u__3 any; var root_4617 any = A_arbace_o2j_A_const_531.GetRawRoot__O(); var linked_4618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4617, A_arbace_o2j_read_dump_A_fn_class); var ifn_4619 lang.IFn
															if linked_4618 == nil { ifn_4619 = lang.IFn_Cast(root_4617) } else { ifn_4619 = nil }; var arg_4620 any; var root_4621 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4621, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4623 lang.IFn; if linked_4622 == nil { ifn_4623 = lang.IFn_Cast(root_4621) } else { ifn_4623 = nil }; var arg_4624 any = t.F_ld; var arg_4625 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__2, nil)).Ref(); if linked_4622 == nil { arg_4620 = ifn_4623.Invoke_O_O__O(arg_4624, arg_4625) } else { arg_4620 = linked_4622.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4621, arg_4624, arg_4625) }; if linked_4618 == nil { u__3 = ifn_4619.Invoke_O__O(arg_4620) } else { u__3 = linked_4618.(*A_arbace_o2j_read_dump_A).Invoke_O_O__O(root_4617, arg_4620) }
//line :677:1
	var vec__1641000608__4 any; var root_4626 any = A_arbace_o2j_A_const_537.GetRawRoot__O(); var linked_4627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4626, A_arbace_o2j_translate_unit_A_fn_class); var ifn_4628 lang.IFn

	if linked_4627 == nil { ifn_4628 = lang.IFn_Cast(root_4626) } else { ifn_4628 = nil }; var arg_4629 any = u__3; if linked_4627 == nil { vec__1641000608__4 = ifn_4628.Invoke_O__O(arg_4629) } else { vec__1641000608__4 = linked_4627.(*A_arbace_o2j_translate_unit_A).Invoke_O_O__O(root_4626, arg_4629) }
//line :677:1
	var forms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000608__4, lang.RT_IntCast_J__I_NoInit(0), nil); var missing__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000608__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4630 any = A_arbace_o2j_A_const_535.GetRawRoot__O(); var linked_4631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4630, A_arbace_o2j_write_forms_A_fn_class); var ifn_4632 lang.IFn


	if linked_4631 == nil { ifn_4632 = lang.IFn_Cast(root_4630) } else { ifn_4632 = nil }; var arg_4633 any; var root_4636 any = A_arbace_o2j_A_const_78.GetRawRoot__O(); var linked_4637 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4636, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_4638 lang.IFn; if linked_4637 == nil { ifn_4638 = lang.IFn_Cast(root_4636) } else { ifn_4638 = nil }; var arg_4639 any = t.F_od; var arg_4640 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, n__2, nil)).Ref(); if linked_4637 == nil { arg_4633 = ifn_4638.Invoke_O_O__O(arg_4639, arg_4640) } else { arg_4633 = linked_4637.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_4636, arg_4639, arg_4640) }; var arg_4634 any = forms__5; var arg_4635 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil)).Ref(); if linked_4631 == nil { ifn_4632.Invoke_O_O_O__O(arg_4633, arg_4634, arg_4635) } else { linked_4631.(*A_arbace_o2j_write_forms_A).Invoke_O_O_O_O__O(root_4630, arg_4633, arg_4634, arg_4635) }
//line :677:1
	var seq_1641000611__7 any; var root_4641 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4643 lang.IFn




	if linked_4642 == nil { ifn_4643 = lang.IFn_Cast(root_4641) } else { ifn_4643 = nil }; var arg_4644 any; var root_4645 any = A_arbace_o2j_A_const_143.GetRawRoot__O(); var linked_4646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4645, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_4647 lang.IFn; if linked_4646 == nil { ifn_4647 = lang.IFn_Cast(root_4645) } else { ifn_4647 = nil }; var arg_4648 any = missing__6; if linked_4646 == nil { arg_4644 = ifn_4647.Invoke_O__O(arg_4648) } else { arg_4644 = linked_4646.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_4645, arg_4648) }; if linked_4642 == nil { seq_1641000611__7 = ifn_4643.Invoke_O__O(arg_4644) } else { seq_1641000611__7 = linked_4642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4641, arg_4644) }
//line :677:1
	var chunk_1641000612__8 any; var count_1641000613__9 int64 = 0; var i_1641000614__10 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1641000614__10, count_1641000613__9) { var vec__1641000615__11 any = lang.Indexed_Cast(chunk_1641000612__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1641000614__10)); var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000615__11, lang.RT_IntCast_J__I_NoInit(0), nil); var c__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000615__11, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, m__12, nil, c__13)).Ref()); seq_1641000611__7, chunk_1641000612__8, count_1641000613__9, i_1641000614__10 = seq_1641000611__7, chunk_1641000612__8, count_1641000613__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1641000614__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_4649 any = A_arbace_o2j_A_const_33.GetRawRoot__O(); var linked_4650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4651 lang.IFn; if linked_4650 == nil { ifn_4651 = lang.IFn_Cast(root_4649) } else { ifn_4651 = nil }; var arg_4652 any = seq_1641000611__7; if linked_4650 == nil { temp__1927000414__auto____11 = ifn_4651.Invoke_O__O(arg_4652) } else { temp__1927000414__auto____11 = linked_4650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4649, arg_4652) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1641000611__12 any = temp__1927000414__auto____11; var tmp2 any; var root_4653 any = A_arbace_o2j_A_const_54.GetRawRoot__O(); var linked_4654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4653, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4655 lang.IFn; if linked_4654 == nil { ifn_4655 = lang.IFn_Cast(root_4653) } else { ifn_4655 = nil }; var arg_4656 any = seq_1641000611__12; if linked_4654 == nil { tmp2 = ifn_4655.Invoke_O__O(arg_4656) } else { tmp2 = linked_4654.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4653, arg_4656) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_4657 any = A_arbace_o2j_A_const_55.GetRawRoot__O(); var linked_4658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4657, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4659 lang.IFn; if linked_4658 == nil { ifn_4659 = lang.IFn_Cast(root_4657) } else { ifn_4659 = nil }; var arg_4660 any = seq_1641000611__12; if linked_4658 == nil { c__1927000678__auto____13 = ifn_4659.Invoke_O__O(arg_4660) } else { c__1927000678__auto____13 = linked_4658.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4657, arg_4660) }; var tmp3 any; var root_4669 any = A_arbace_o2j_A_const_64.GetRawRoot__O(); var linked_4670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4669, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4671 lang.IFn; if linked_4670 == nil { ifn_4671 = lang.IFn_Cast(root_4669) } else { ifn_4671 = nil }; var arg_4672 any = seq_1641000611__12; if linked_4670 == nil { tmp3 = ifn_4671.Invoke_O__O(arg_4672) } else { tmp3 = linked_4670.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4669, arg_4672) }; seq_1641000611__7, chunk_1641000612__8, count_1641000613__9, i_1641000614__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1641000618__13 any; var root_4661 any = A_arbace_o2j_A_const_27.GetRawRoot__O(); var linked_4662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4661, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4663 lang.IFn; if linked_4662 == nil { ifn_4663 = lang.IFn_Cast(root_4661) } else { ifn_4663 = nil }; var arg_4664 any = seq_1641000611__12; if linked_4662 == nil { vec__1641000618__13 = ifn_4663.Invoke_O__O(arg_4664) } else { vec__1641000618__13 = linked_4662.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4661, arg_4664) }; var m__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000618__13, lang.RT_IntCast_J__I_NoInit(0), nil); var c__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1641000618__13, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, m__14, nil, c__15)).Ref()); var tmp4 any; var root_4677 any = A_arbace_o2j_A_const_136.GetRawRoot__O(); var linked_4678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4677, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4679 lang.IFn; if linked_4678 == nil { ifn_4679 = lang.IFn_Cast(root_4677) } else { ifn_4679 = nil }; var arg_4680 any = seq_1641000611__12; if linked_4678 == nil { tmp4 = ifn_4679.Invoke_O__O(arg_4680) } else { tmp4 = linked_4678.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4677, arg_4680) }; seq_1641000611__7, chunk_1641000612__8, count_1641000613__9, i_1641000614__10 = tmp4, nil, 0, 0; continue L2 } } }
//line :677:1
		break L2 }; var tmp5 any; var root_4681 any = A_arbace_o2j_A_const_526.GetRawRoot__O(); var linked_4682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4681, A_arbace_o2j_unit_refs_A_fn_class); var ifn_4683 lang.IFn





	if linked_4682 == nil { ifn_4683 = lang.IFn_Cast(root_4681) } else { ifn_4683 = nil }; var arg_4684 any = u__3; if linked_4682 == nil { tmp5 = ifn_4683.Invoke_O__O(arg_4684) } else { tmp5 = linked_4682.(*A_arbace_o2j_unit_refs_A).Invoke_O_O__O(root_4681, arg_4684) }
//line :677:1
	arg_4616 = lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp5); if linked_4613 == nil { ifn_4614.Invoke_O_O__O(arg_4615, arg_4616) } else { linked_4613.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4612, arg_4615, arg_4616) }; i__1641000603__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1641000603__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }















func A_arbace_o2j__main_fn__1641000555_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j__main_fn__1641000555_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_fn__1641000555_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :693:1
func (t *A_arbace_o2j__main_fn__1641000555_A) Ctor_O_O_O(c__od, c__dumps, c__lo any) { t.F_od = c__od; t.F_dumps = c__dumps; t.F_lo = c__lo }
//line :693:1
func (t *A_arbace_o2j__main_fn__1641000555_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4855 any = A_arbace_o2j_A_const_541.GetRawRoot__O(); var linked_4856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4855, A_arbace_o2j_translate_program_A_fn_class); var ifn_4857 lang.IFn; if linked_4856 == nil { ifn_4857 = lang.IFn_Cast(root_4855) } else { ifn_4857 = nil }; var arg_4858 any; var t_ any = t.F_lo; t.F_lo = nil; arg_4858 = t_; var arg_4859 any = t.F_od; var arg_4860 any; var t__2 any = t.F_dumps; t.F_dumps = nil; arg_4860 = t__2; if linked_4856 == nil { tmp1 = ifn_4857.Invoke_O_O_O__O(arg_4858, arg_4859, arg_4860) } else { tmp1 = linked_4856.(*A_arbace_o2j_translate_program_A).Invoke_O_O_O_O__O(root_4855, arg_4858, arg_4859, arg_4860) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_10, nil); var tmp5 any; var t__3 any = t.F_od

	t.F_od = nil; tmp5 = t__3; var tmp6 any = tmp5; var tmp7 any; var root_4865 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_4866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4865, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_4867 lang.IFn; if linked_4866 == nil { ifn_4867 = lang.IFn_Cast(root_4865) } else { ifn_4867 = nil }; var arg_4868 any; var root_4871 any = A_arbace_o2j_A_const_31.GetRawRoot__O(); var linked_4872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4871, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4873 lang.IFn; if linked_4872 == nil { ifn_4873 = lang.IFn_Cast(root_4871) } else { ifn_4873 = nil }; var arg_4874 any = e__3.GetMessage__String().Ref(); if linked_4872 == nil { arg_4868 = ifn_4873.Invoke_O__O(arg_4874) } else { arg_4868 = linked_4872.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4871, arg_4874) }; var arg_4869 any = A_arbace_o2j_A_const_544; var arg_4870 any = Lit_20; if linked_4866 == nil { tmp7 = ifn_4867.Invoke_O_O_O__O(arg_4868, arg_4869, arg_4870) } else { tmp7 = linked_4866.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_4865, arg_4868, arg_4869, arg_4870) }; tmp1 = tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref()) } }; return tmp1 }
//line :693:1
func A_arbace_o2j__main_fn__1641000560_A_New_O_O_O(p0, p1, p2 any) *A_arbace_o2j__main_fn__1641000560_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j__main_fn__1641000560_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :693:1
func (t *A_arbace_o2j__main_fn__1641000560_A) Ctor_O_O_O(c__dumps, c__lo, c__od any) { t.F_dumps = c__dumps; t.F_lo = c__lo; t.F_od = c__od }
//line :693:1
func (t *A_arbace_o2j__main_fn__1641000560_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4898 any = A_arbace_o2j_A_const_541.GetRawRoot__O(); var linked_4899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4898, A_arbace_o2j_translate_program_A_fn_class); var ifn_4900 lang.IFn; if linked_4899 == nil { ifn_4900 = lang.IFn_Cast(root_4898) } else { ifn_4900 = nil }; var arg_4901 any; var t_ any = t.F_lo; t.F_lo = nil; arg_4901 = t_; var arg_4902 any = t.F_od; var arg_4903 any; var t__2 any = t.F_dumps; t.F_dumps = nil; arg_4903 = t__2; if linked_4899 == nil { tmp1 = ifn_4900.Invoke_O_O_O__O(arg_4901, arg_4902, arg_4903) } else { tmp1 = linked_4899.(*A_arbace_o2j_translate_program_A).Invoke_O_O_O_O__O(root_4898, arg_4901, arg_4902, arg_4903) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_o2j_A_const_517.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_10, nil); var tmp5 any; var t__3 any = t.F_od

	t.F_od = nil; tmp5 = t__3; var tmp6 any = tmp5; var tmp7 any; var root_4908 any = A_arbace_o2j_A_const_22.GetRawRoot__O(); var linked_4909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4908, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_4910 lang.IFn; if linked_4909 == nil { ifn_4910 = lang.IFn_Cast(root_4908) } else { ifn_4910 = nil }; var arg_4911 any; var root_4914 any = A_arbace_o2j_A_const_31.GetRawRoot__O(); var linked_4915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4914, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4916 lang.IFn; if linked_4915 == nil { ifn_4916 = lang.IFn_Cast(root_4914) } else { ifn_4916 = nil }; var arg_4917 any = e__3.GetMessage__String().Ref(); if linked_4915 == nil { arg_4911 = ifn_4916.Invoke_O__O(arg_4917) } else { arg_4911 = linked_4915.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4914, arg_4917) }; var arg_4912 any = A_arbace_o2j_A_const_544; var arg_4913 any = Lit_20; if linked_4909 == nil { tmp7 = ifn_4910.Invoke_O_O_O__O(arg_4911, arg_4912, arg_4913) } else { tmp7 = linked_4909.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_4908, arg_4911, arg_4912, arg_4913) }; tmp1 = tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref()) } }; return tmp1 }




































































































































































type A_arbace_o2j_A struct{ jrt.Object }

var A_arbace_o2j_A_const_pool *jrt.RefArray

var A_arbace_o2j_A_const_0 *lang.Var

var A_arbace_o2j_A_const_1 any

var A_arbace_o2j_A_const_2 *lang.Var

var A_arbace_o2j_A_const_3 any

var A_arbace_o2j_A_const_4 any

var A_arbace_o2j_A_const_5 *lang.Var

var A_arbace_o2j_A_const_6 *lang.Var

var A_arbace_o2j_A_const_7 *lang.Var

var A_arbace_o2j_A_const_8 *lang.Var

var A_arbace_o2j_A_const_9 any

var A_arbace_o2j_A_const_10 *lang.Var

var A_arbace_o2j_A_const_11 *lang.Var

var A_arbace_o2j_A_const_12 *lang.Var

var A_arbace_o2j_A_const_13 any

var A_arbace_o2j_A_const_14 *lang.Var

var A_arbace_o2j_A_const_15 *lang.Var

var A_arbace_o2j_A_const_16 any

var A_arbace_o2j_A_const_17 *lang.Keyword

var A_arbace_o2j_A_const_18 *lang.Keyword

var A_arbace_o2j_A_const_19 *lang.Keyword

var A_arbace_o2j_A_const_20 *lang.Keyword

var A_arbace_o2j_A_const_21 *lang.Keyword

var A_arbace_o2j_A_const_22 *lang.Var

var A_arbace_o2j_A_const_23 any

var A_arbace_o2j_A_const_24 any

var A_arbace_o2j_A_const_25 *lang.Var

var A_arbace_o2j_A_const_26 any

var A_arbace_o2j_A_const_27 *lang.Var

var A_arbace_o2j_A_const_28 *lang.Var

var A_arbace_o2j_A_const_29 *lang.Keyword

var A_arbace_o2j_A_const_30 *lang.Keyword

var A_arbace_o2j_A_const_31 *lang.Var

var A_arbace_o2j_A_const_32 *lang.Var

var A_arbace_o2j_A_const_33 *lang.Var

var A_arbace_o2j_A_const_34 *lang.Var

var A_arbace_o2j_A_const_35 *lang.Var

var A_arbace_o2j_A_const_36 *lang.Var

var A_arbace_o2j_A_const_37 *lang.Var

var A_arbace_o2j_A_const_38 *lang.Var

var A_arbace_o2j_A_const_39 *lang.Var

var A_arbace_o2j_A_const_40 *lang.Var

var A_arbace_o2j_A_const_41 *lang.Var

var A_arbace_o2j_A_const_42 *lang.Var

var A_arbace_o2j_A_const_43 *lang.Var

var A_arbace_o2j_A_const_44 *lang.Keyword

var A_arbace_o2j_A_const_45 *lang.Var

var A_arbace_o2j_A_const_46 any

var A_arbace_o2j_A_const_47 any

var A_arbace_o2j_A_const_48 any

var A_arbace_o2j_A_const_49 *lang.Var

var A_arbace_o2j_A_const_50 *lang.Var

var A_arbace_o2j_A_const_51 any

var A_arbace_o2j_A_const_52 *lang.Var

var A_arbace_o2j_A_const_53 *lang.Var

var A_arbace_o2j_A_const_54 *lang.Var

var A_arbace_o2j_A_const_55 *lang.Var

var A_arbace_o2j_A_const_56 *lang.Var

var A_arbace_o2j_A_const_57 any

var A_arbace_o2j_A_const_58 *lang.Var

var A_arbace_o2j_A_const_59 *lang.Var

var A_arbace_o2j_A_const_60 any

var A_arbace_o2j_A_const_61 *lang.Var

var A_arbace_o2j_A_const_62 *lang.Var

var A_arbace_o2j_A_const_63 *lang.Var

var A_arbace_o2j_A_const_64 *lang.Var

var A_arbace_o2j_A_const_65 *lang.Var

var A_arbace_o2j_A_const_66 *lang.Var

var A_arbace_o2j_A_const_67 *lang.Var

var A_arbace_o2j_A_const_68 *lang.Var

var A_arbace_o2j_A_const_69 *lang.Var

var A_arbace_o2j_A_const_70 *lang.Keyword

var A_arbace_o2j_A_const_71 *lang.Var

var A_arbace_o2j_A_const_72 any

var A_arbace_o2j_A_const_73 *lang.Var

var A_arbace_o2j_A_const_74 *lang.Var

var A_arbace_o2j_A_const_75 *lang.Var

var A_arbace_o2j_A_const_76 *lang.Var

var A_arbace_o2j_A_const_77 *lang.Var

var A_arbace_o2j_A_const_78 *lang.Var

var A_arbace_o2j_A_const_79 *lang.Var

var A_arbace_o2j_A_const_80 *lang.Keyword

var A_arbace_o2j_A_const_81 *lang.Var

var A_arbace_o2j_A_const_82 *lang.Var

var A_arbace_o2j_A_const_83 *lang.Keyword

var A_arbace_o2j_A_const_84 *lang.Keyword

var A_arbace_o2j_A_const_85 *lang.Var

var A_arbace_o2j_A_const_86 *lang.Var

var A_arbace_o2j_A_const_87 any

var A_arbace_o2j_A_const_88 *lang.Var

var A_arbace_o2j_A_const_89 *lang.Var

var A_arbace_o2j_A_const_90 any

var A_arbace_o2j_A_const_91 *lang.Var

var A_arbace_o2j_A_const_92 any

var A_arbace_o2j_A_const_93 any

var A_arbace_o2j_A_const_94 any

var A_arbace_o2j_A_const_95 any

var A_arbace_o2j_A_const_96 any

var A_arbace_o2j_A_const_97 any

var A_arbace_o2j_A_const_98 *lang.Keyword

var A_arbace_o2j_A_const_99 any

var A_arbace_o2j_A_const_100 *lang.Var

var A_arbace_o2j_A_const_101 any

var A_arbace_o2j_A_const_102 any

var A_arbace_o2j_A_const_103 *lang.Var

var A_arbace_o2j_A_const_104 *lang.Var

var A_arbace_o2j_A_const_105 any

var A_arbace_o2j_A_const_106 any

var A_arbace_o2j_A_const_107 any

var A_arbace_o2j_A_const_108 any

var A_arbace_o2j_A_const_109 any

var A_arbace_o2j_A_const_110 any

var A_arbace_o2j_A_const_111 any

var A_arbace_o2j_A_const_112 any

var A_arbace_o2j_A_const_113 *lang.Var

var A_arbace_o2j_A_const_114 any

var A_arbace_o2j_A_const_115 any

var A_arbace_o2j_A_const_116 any

var A_arbace_o2j_A_const_117 any

var A_arbace_o2j_A_const_118 any

var A_arbace_o2j_A_const_119 any

var A_arbace_o2j_A_const_120 any

var A_arbace_o2j_A_const_121 any

var A_arbace_o2j_A_const_122 *lang.Var

var A_arbace_o2j_A_const_123 *lang.Var

var A_arbace_o2j_A_const_124 any

var A_arbace_o2j_A_const_125 *lang.Keyword

var A_arbace_o2j_A_const_126 *lang.Var

var A_arbace_o2j_A_const_127 *lang.Var

var A_arbace_o2j_A_const_128 any

var A_arbace_o2j_A_const_129 any

var A_arbace_o2j_A_const_130 any

var A_arbace_o2j_A_const_131 any

var A_arbace_o2j_A_const_132 any

var A_arbace_o2j_A_const_133 any

var A_arbace_o2j_A_const_134 any

var A_arbace_o2j_A_const_135 any

var A_arbace_o2j_A_const_136 *lang.Var

var A_arbace_o2j_A_const_137 any

var A_arbace_o2j_A_const_138 any

var A_arbace_o2j_A_const_139 any

var A_arbace_o2j_A_const_140 any

var A_arbace_o2j_A_const_141 any

var A_arbace_o2j_A_const_142 *lang.Var

var A_arbace_o2j_A_const_143 *lang.Var

var A_arbace_o2j_A_const_144 *lang.Var

var A_arbace_o2j_A_const_145 *lang.Keyword

var A_arbace_o2j_A_const_146 *lang.Keyword

var A_arbace_o2j_A_const_147 any

var A_arbace_o2j_A_const_148 any

var A_arbace_o2j_A_const_149 any

var A_arbace_o2j_A_const_150 *lang.Var

var A_arbace_o2j_A_const_151 *lang.Var

var A_arbace_o2j_A_const_152 *lang.Var

var A_arbace_o2j_A_const_153 *lang.Var

var A_arbace_o2j_A_const_154 *lang.Var

var A_arbace_o2j_A_const_155 *lang.Var

var A_arbace_o2j_A_const_156 *lang.Var

var A_arbace_o2j_A_const_157 *lang.Var

var A_arbace_o2j_A_const_158 any

var A_arbace_o2j_A_const_159 *lang.Var

var A_arbace_o2j_A_const_160 any

var A_arbace_o2j_A_const_161 any

var A_arbace_o2j_A_const_162 any

var A_arbace_o2j_A_const_163 any

var A_arbace_o2j_A_const_164 any

var A_arbace_o2j_A_const_165 any

var A_arbace_o2j_A_const_166 any

var A_arbace_o2j_A_const_167 any

var A_arbace_o2j_A_const_168 any

var A_arbace_o2j_A_const_169 any

var A_arbace_o2j_A_const_170 any

var A_arbace_o2j_A_const_171 any

var A_arbace_o2j_A_const_172 *lang.Keyword

var A_arbace_o2j_A_const_173 any

var A_arbace_o2j_A_const_174 *lang.Keyword

var A_arbace_o2j_A_const_175 *lang.Var

var A_arbace_o2j_A_const_176 any

var A_arbace_o2j_A_const_177 *lang.Keyword

var A_arbace_o2j_A_const_178 *lang.Var

var A_arbace_o2j_A_const_179 *lang.Var

var A_arbace_o2j_A_const_180 *lang.Keyword

var A_arbace_o2j_A_const_181 any

var A_arbace_o2j_A_const_182 any

var A_arbace_o2j_A_const_183 any

var A_arbace_o2j_A_const_184 any

var A_arbace_o2j_A_const_185 any

var A_arbace_o2j_A_const_186 any

var A_arbace_o2j_A_const_187 any

var A_arbace_o2j_A_const_188 any

var A_arbace_o2j_A_const_189 any

var A_arbace_o2j_A_const_190 any

var A_arbace_o2j_A_const_191 *lang.Var

var A_arbace_o2j_A_const_192 *lang.Var

var A_arbace_o2j_A_const_193 *lang.Var

var A_arbace_o2j_A_const_194 *lang.Var

var A_arbace_o2j_A_const_195 *lang.Var

var A_arbace_o2j_A_const_196 any

var A_arbace_o2j_A_const_197 *lang.Var

var A_arbace_o2j_A_const_198 *lang.Var

var A_arbace_o2j_A_const_199 *lang.Keyword

var A_arbace_o2j_A_const_200 any

var A_arbace_o2j_A_const_201 any

var A_arbace_o2j_A_const_202 *lang.Keyword

var A_arbace_o2j_A_const_203 *lang.Keyword

var A_arbace_o2j_A_const_204 any

var A_arbace_o2j_A_const_205 any

var A_arbace_o2j_A_const_206 *lang.Keyword

var A_arbace_o2j_A_const_207 any

var A_arbace_o2j_A_const_208 any

var A_arbace_o2j_A_const_209 any

var A_arbace_o2j_A_const_210 any

var A_arbace_o2j_A_const_211 any

var A_arbace_o2j_A_const_212 any

var A_arbace_o2j_A_const_213 any

var A_arbace_o2j_A_const_214 any

var A_arbace_o2j_A_const_215 any

var A_arbace_o2j_A_const_216 any

var A_arbace_o2j_A_const_217 *lang.Var

var A_arbace_o2j_A_const_218 *lang.Var

var A_arbace_o2j_A_const_219 *lang.Var

var A_arbace_o2j_A_const_220 any

var A_arbace_o2j_A_const_221 any

var A_arbace_o2j_A_const_222 any

var A_arbace_o2j_A_const_223 any

var A_arbace_o2j_A_const_224 any

var A_arbace_o2j_A_const_225 any

var A_arbace_o2j_A_const_226 *lang.Var

var A_arbace_o2j_A_const_227 any

var A_arbace_o2j_A_const_228 *lang.Var

var A_arbace_o2j_A_const_229 *lang.Var

var A_arbace_o2j_A_const_230 any

var A_arbace_o2j_A_const_231 any

var A_arbace_o2j_A_const_232 *lang.Var

var A_arbace_o2j_A_const_233 *lang.Var

var A_arbace_o2j_A_const_234 any

var A_arbace_o2j_A_const_235 *lang.Var

var A_arbace_o2j_A_const_236 any

var A_arbace_o2j_A_const_237 any

var A_arbace_o2j_A_const_238 any

var A_arbace_o2j_A_const_239 any

var A_arbace_o2j_A_const_240 *lang.Var

var A_arbace_o2j_A_const_241 *lang.Var

var A_arbace_o2j_A_const_242 any

var A_arbace_o2j_A_const_243 *lang.Var

var A_arbace_o2j_A_const_244 any

var A_arbace_o2j_A_const_245 any

var A_arbace_o2j_A_const_246 *lang.Var

var A_arbace_o2j_A_const_247 any

var A_arbace_o2j_A_const_248 any

var A_arbace_o2j_A_const_249 any

var A_arbace_o2j_A_const_250 any

var A_arbace_o2j_A_const_251 any

var A_arbace_o2j_A_const_252 any

var A_arbace_o2j_A_const_253 *lang.Var

var A_arbace_o2j_A_const_254 any

var A_arbace_o2j_A_const_255 any

var A_arbace_o2j_A_const_256 any

var A_arbace_o2j_A_const_257 any

var A_arbace_o2j_A_const_258 any

var A_arbace_o2j_A_const_259 any

var A_arbace_o2j_A_const_260 any

var A_arbace_o2j_A_const_261 any

var A_arbace_o2j_A_const_262 any

var A_arbace_o2j_A_const_263 any

var A_arbace_o2j_A_const_264 any

var A_arbace_o2j_A_const_265 any

var A_arbace_o2j_A_const_266 any

var A_arbace_o2j_A_const_267 any

var A_arbace_o2j_A_const_268 any

var A_arbace_o2j_A_const_269 any

var A_arbace_o2j_A_const_270 any

var A_arbace_o2j_A_const_271 any

var A_arbace_o2j_A_const_272 any

var A_arbace_o2j_A_const_273 any

var A_arbace_o2j_A_const_274 any

var A_arbace_o2j_A_const_275 any

var A_arbace_o2j_A_const_276 any

var A_arbace_o2j_A_const_277 any

var A_arbace_o2j_A_const_278 any

var A_arbace_o2j_A_const_279 any

var A_arbace_o2j_A_const_280 any

var A_arbace_o2j_A_const_281 *lang.Var

var A_arbace_o2j_A_const_282 any

var A_arbace_o2j_A_const_283 any

var A_arbace_o2j_A_const_284 *lang.Var

var A_arbace_o2j_A_const_285 any

var A_arbace_o2j_A_const_286 any

var A_arbace_o2j_A_const_287 *lang.Var

var A_arbace_o2j_A_const_288 any

var A_arbace_o2j_A_const_289 any

var A_arbace_o2j_A_const_290 any

var A_arbace_o2j_A_const_291 any

var A_arbace_o2j_A_const_292 any

var A_arbace_o2j_A_const_293 *lang.Var

var A_arbace_o2j_A_const_294 any

var A_arbace_o2j_A_const_295 any

var A_arbace_o2j_A_const_296 any

var A_arbace_o2j_A_const_297 any

var A_arbace_o2j_A_const_298 any

var A_arbace_o2j_A_const_299 any

var A_arbace_o2j_A_const_300 any

var A_arbace_o2j_A_const_301 any

var A_arbace_o2j_A_const_302 any

var A_arbace_o2j_A_const_303 any

var A_arbace_o2j_A_const_304 any

var A_arbace_o2j_A_const_305 any

var A_arbace_o2j_A_const_306 any

var A_arbace_o2j_A_const_307 any

var A_arbace_o2j_A_const_308 any

var A_arbace_o2j_A_const_309 any

var A_arbace_o2j_A_const_310 any

var A_arbace_o2j_A_const_311 any

var A_arbace_o2j_A_const_312 any

var A_arbace_o2j_A_const_313 any

var A_arbace_o2j_A_const_314 any

var A_arbace_o2j_A_const_315 any

var A_arbace_o2j_A_const_316 any

var A_arbace_o2j_A_const_317 any

var A_arbace_o2j_A_const_318 *lang.Var

var A_arbace_o2j_A_const_319 *lang.Var

var A_arbace_o2j_A_const_320 *lang.Var

var A_arbace_o2j_A_const_321 *lang.Var

var A_arbace_o2j_A_const_322 any

var A_arbace_o2j_A_const_323 any

var A_arbace_o2j_A_const_324 any

var A_arbace_o2j_A_const_325 any

var A_arbace_o2j_A_const_326 any

var A_arbace_o2j_A_const_327 any

var A_arbace_o2j_A_const_328 any

var A_arbace_o2j_A_const_329 any

var A_arbace_o2j_A_const_330 any

var A_arbace_o2j_A_const_331 any

var A_arbace_o2j_A_const_332 any

var A_arbace_o2j_A_const_333 any

var A_arbace_o2j_A_const_334 any

var A_arbace_o2j_A_const_335 any

var A_arbace_o2j_A_const_336 any

var A_arbace_o2j_A_const_337 any

var A_arbace_o2j_A_const_338 any

var A_arbace_o2j_A_const_339 any

var A_arbace_o2j_A_const_340 any

var A_arbace_o2j_A_const_341 *lang.Var

var A_arbace_o2j_A_const_342 any

var A_arbace_o2j_A_const_343 *lang.Var

var A_arbace_o2j_A_const_344 *lang.Var

var A_arbace_o2j_A_const_345 any

var A_arbace_o2j_A_const_346 any

var A_arbace_o2j_A_const_347 *lang.Var

var A_arbace_o2j_A_const_348 any

var A_arbace_o2j_A_const_349 *lang.Var

var A_arbace_o2j_A_const_350 any

var A_arbace_o2j_A_const_351 any

var A_arbace_o2j_A_const_352 any

var A_arbace_o2j_A_const_353 any

var A_arbace_o2j_A_const_354 any

var A_arbace_o2j_A_const_355 any

var A_arbace_o2j_A_const_356 any

var A_arbace_o2j_A_const_357 any

var A_arbace_o2j_A_const_358 any

var A_arbace_o2j_A_const_359 any

var A_arbace_o2j_A_const_360 any

var A_arbace_o2j_A_const_361 any

var A_arbace_o2j_A_const_362 any

var A_arbace_o2j_A_const_363 any

var A_arbace_o2j_A_const_364 any

var A_arbace_o2j_A_const_365 any

var A_arbace_o2j_A_const_366 any

var A_arbace_o2j_A_const_367 any

var A_arbace_o2j_A_const_368 any

var A_arbace_o2j_A_const_369 any

var A_arbace_o2j_A_const_370 any

var A_arbace_o2j_A_const_371 any

var A_arbace_o2j_A_const_372 any

var A_arbace_o2j_A_const_373 any

var A_arbace_o2j_A_const_374 any

var A_arbace_o2j_A_const_375 any

var A_arbace_o2j_A_const_376 any

var A_arbace_o2j_A_const_377 any

var A_arbace_o2j_A_const_378 any

var A_arbace_o2j_A_const_379 any

var A_arbace_o2j_A_const_380 any

var A_arbace_o2j_A_const_381 *lang.Keyword

var A_arbace_o2j_A_const_382 *lang.Var

var A_arbace_o2j_A_const_383 any

var A_arbace_o2j_A_const_384 any

var A_arbace_o2j_A_const_385 any

var A_arbace_o2j_A_const_386 any

var A_arbace_o2j_A_const_387 any

var A_arbace_o2j_A_const_388 *lang.Var

var A_arbace_o2j_A_const_389 *lang.Var

var A_arbace_o2j_A_const_390 *lang.Var

var A_arbace_o2j_A_const_391 any

var A_arbace_o2j_A_const_392 any

var A_arbace_o2j_A_const_393 any

var A_arbace_o2j_A_const_394 any

var A_arbace_o2j_A_const_395 any

var A_arbace_o2j_A_const_396 any

var A_arbace_o2j_A_const_397 any

var A_arbace_o2j_A_const_398 any

var A_arbace_o2j_A_const_399 any

var A_arbace_o2j_A_const_400 any

var A_arbace_o2j_A_const_401 *lang.Keyword

var A_arbace_o2j_A_const_402 any

var A_arbace_o2j_A_const_403 any

var A_arbace_o2j_A_const_404 any

var A_arbace_o2j_A_const_405 any

var A_arbace_o2j_A_const_406 any

var A_arbace_o2j_A_const_407 any

var A_arbace_o2j_A_const_408 any

var A_arbace_o2j_A_const_409 any

var A_arbace_o2j_A_const_410 any

var A_arbace_o2j_A_const_411 any

var A_arbace_o2j_A_const_412 any

var A_arbace_o2j_A_const_413 any

var A_arbace_o2j_A_const_414 any

var A_arbace_o2j_A_const_415 any

var A_arbace_o2j_A_const_416 any

var A_arbace_o2j_A_const_417 any

var A_arbace_o2j_A_const_418 any

var A_arbace_o2j_A_const_419 any

var A_arbace_o2j_A_const_420 any

var A_arbace_o2j_A_const_421 *lang.Var

var A_arbace_o2j_A_const_422 any

var A_arbace_o2j_A_const_423 any

var A_arbace_o2j_A_const_424 *lang.Var

var A_arbace_o2j_A_const_425 any

var A_arbace_o2j_A_const_426 any

var A_arbace_o2j_A_const_427 any

var A_arbace_o2j_A_const_428 *lang.Var

var A_arbace_o2j_A_const_429 any

var A_arbace_o2j_A_const_430 any

var A_arbace_o2j_A_const_431 any

var A_arbace_o2j_A_const_432 *lang.Var

var A_arbace_o2j_A_const_433 any

var A_arbace_o2j_A_const_434 *lang.Var

var A_arbace_o2j_A_const_435 any

var A_arbace_o2j_A_const_436 *lang.Var

var A_arbace_o2j_A_const_437 any

var A_arbace_o2j_A_const_438 any

var A_arbace_o2j_A_const_439 any

var A_arbace_o2j_A_const_440 any

var A_arbace_o2j_A_const_441 any

var A_arbace_o2j_A_const_442 any

var A_arbace_o2j_A_const_443 any

var A_arbace_o2j_A_const_444 any

var A_arbace_o2j_A_const_445 *lang.Var

var A_arbace_o2j_A_const_446 any

var A_arbace_o2j_A_const_447 *lang.Var

var A_arbace_o2j_A_const_448 any

var A_arbace_o2j_A_const_449 *lang.Var

var A_arbace_o2j_A_const_450 any

var A_arbace_o2j_A_const_451 any

var A_arbace_o2j_A_const_452 *lang.Var

var A_arbace_o2j_A_const_453 any

var A_arbace_o2j_A_const_454 any

var A_arbace_o2j_A_const_455 *lang.Var

var A_arbace_o2j_A_const_456 any

var A_arbace_o2j_A_const_457 *lang.Var

var A_arbace_o2j_A_const_458 any

var A_arbace_o2j_A_const_459 any

var A_arbace_o2j_A_const_460 any

var A_arbace_o2j_A_const_461 *lang.Var

var A_arbace_o2j_A_const_462 any

var A_arbace_o2j_A_const_463 any

var A_arbace_o2j_A_const_464 any

var A_arbace_o2j_A_const_465 any

var A_arbace_o2j_A_const_466 any

var A_arbace_o2j_A_const_467 any

var A_arbace_o2j_A_const_468 any

var A_arbace_o2j_A_const_469 any

var A_arbace_o2j_A_const_470 any

var A_arbace_o2j_A_const_471 any

var A_arbace_o2j_A_const_472 any

var A_arbace_o2j_A_const_473 any

var A_arbace_o2j_A_const_474 any

var A_arbace_o2j_A_const_475 any

var A_arbace_o2j_A_const_476 any

var A_arbace_o2j_A_const_477 any

var A_arbace_o2j_A_const_478 *lang.Var

var A_arbace_o2j_A_const_479 *lang.Var

var A_arbace_o2j_A_const_480 *lang.Var

var A_arbace_o2j_A_const_481 any

var A_arbace_o2j_A_const_482 any

var A_arbace_o2j_A_const_483 *lang.Keyword

var A_arbace_o2j_A_const_484 any

var A_arbace_o2j_A_const_485 any

var A_arbace_o2j_A_const_486 any

var A_arbace_o2j_A_const_487 any

var A_arbace_o2j_A_const_488 any

var A_arbace_o2j_A_const_489 any

var A_arbace_o2j_A_const_490 any

var A_arbace_o2j_A_const_491 any

var A_arbace_o2j_A_const_492 any

var A_arbace_o2j_A_const_493 any

var A_arbace_o2j_A_const_494 any

var A_arbace_o2j_A_const_495 any

var A_arbace_o2j_A_const_496 any

var A_arbace_o2j_A_const_497 any

var A_arbace_o2j_A_const_498 any

var A_arbace_o2j_A_const_499 any

var A_arbace_o2j_A_const_500 any

var A_arbace_o2j_A_const_501 any

var A_arbace_o2j_A_const_502 any

var A_arbace_o2j_A_const_503 any

var A_arbace_o2j_A_const_504 any

var A_arbace_o2j_A_const_505 any

var A_arbace_o2j_A_const_506 any

var A_arbace_o2j_A_const_507 any

var A_arbace_o2j_A_const_508 any

var A_arbace_o2j_A_const_509 any

var A_arbace_o2j_A_const_510 any

var A_arbace_o2j_A_const_511 *lang.Var

var A_arbace_o2j_A_const_512 *lang.Var

var A_arbace_o2j_A_const_513 *lang.Var

var A_arbace_o2j_A_const_514 *lang.Var

var A_arbace_o2j_A_const_515 *lang.Var

var A_arbace_o2j_A_const_516 *lang.Var

var A_arbace_o2j_A_const_517 *lang.Var

var A_arbace_o2j_A_const_518 *lang.Var

var A_arbace_o2j_A_const_519 *lang.Var

var A_arbace_o2j_A_const_520 *lang.Var

var A_arbace_o2j_A_const_521 *lang.Var

var A_arbace_o2j_A_const_522 any

var A_arbace_o2j_A_const_523 *lang.Var

var A_arbace_o2j_A_const_524 *lang.Var

var A_arbace_o2j_A_const_525 *lang.Keyword

var A_arbace_o2j_A_const_526 *lang.Var

var A_arbace_o2j_A_const_527 *lang.Var

var A_arbace_o2j_A_const_528 *lang.Var

var A_arbace_o2j_A_const_529 *lang.Keyword

var A_arbace_o2j_A_const_530 *lang.Keyword

var A_arbace_o2j_A_const_531 *lang.Var

var A_arbace_o2j_A_const_532 *lang.Var

var A_arbace_o2j_A_const_533 *lang.Var

var A_arbace_o2j_A_const_534 *lang.Var

var A_arbace_o2j_A_const_535 *lang.Var

var A_arbace_o2j_A_const_536 *lang.Var

var A_arbace_o2j_A_const_537 *lang.Var

var A_arbace_o2j_A_const_538 *lang.Var

var A_arbace_o2j_A_const_539 *lang.Var

var A_arbace_o2j_A_const_540 *lang.Var

var A_arbace_o2j_A_const_541 *lang.Var

var A_arbace_o2j_A_const_542 *lang.Var

var A_arbace_o2j_A_const_543 any

var A_arbace_o2j_A_const_544 any

var A_arbace_o2j_A_init jrt.ClassInit

func A_arbace_o2j_A_Init() { if !A_arbace_o2j_A_init.Done() { A_arbace_o2j_A_init.Run(A_arbace_o2j_A_clinit) } }

func A_arbace_o2j_A_clinit() { A_arbace_o2j_A_clinit_p0(); A_arbace_o2j_A_clinit_p1(); A_arbace_o2j_A_clinit_p2(); A_arbace_o2j_A_clinit_p3(); A_arbace_o2j_A_clinit_p4(); A_arbace_o2j_A_clinit_p5(); A_arbace_o2j_A_clinit_p6(); A_arbace_o2j_A_clinit_p7(); A_arbace_o2j_A_clinit_p8(); A_arbace_o2j_A_clinit_p9(); A_arbace_o2j_A_clinit_p10(); A_arbace_o2j_A_clinit_p11(); A_arbace_o2j_A_clinit_p12(); A_arbace_o2j_A_clinit_p13(); A_arbace_o2j_A_clinit_p14(); A_arbace_o2j_A_clinit_p15(); A_arbace_o2j_A_clinit_p16(); A_arbace_o2j_A_clinit_p17(); A_arbace_o2j_A_clinit_p18(); A_arbace_o2j_A_clinit_p19(); A_arbace_o2j_A_clinit_p20(); A_arbace_o2j_A_clinit_p21(); A_arbace_o2j_A_clinit_p22(); A_arbace_o2j_A_clinit_p23(); A_arbace_o2j_A_clinit_p24(); A_arbace_o2j_A_clinit_p25(); A_arbace_o2j_A_clinit_p26(); A_arbace_o2j_A_clinit_p27(); A_arbace_o2j_A_clinit_p28(); A_arbace_o2j_A_clinit_p29(); A_arbace_o2j_A_clinit_p30(); A_arbace_o2j_A_clinit_p31(); A_arbace_o2j_A_clinit_p32(); A_arbace_o2j_A_clinit_p33(); A_arbace_o2j_A_clinit_p34(); A_arbace_o2j_A_clinit_p35(); A_arbace_o2j_A_clinit_p36(); A_arbace_o2j_A_clinit_p37(); A_arbace_o2j_A_clinit_p38(); A_arbace_o2j_A_clinit_p39() }

func A_arbace_o2j_A_clinit_p0() { jrt.StartCheck(); A_arbace_o2j_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 727); A_arbace_o2j_A_const_0 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[182]); A_arbace_o2j_A_const_1 = A_arbace_o2j_A_const_pool.A[183]; A_arbace_o2j_A_const_2 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[184]); A_arbace_o2j_A_const_3 = A_arbace_o2j_A_const_pool.A[185]; A_arbace_o2j_A_const_4 = A_arbace_o2j_A_const_pool.A[186]; A_arbace_o2j_A_const_5 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[187]); A_arbace_o2j_A_const_6 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[188]); A_arbace_o2j_A_const_7 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[189]); A_arbace_o2j_A_const_8 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[190]); A_arbace_o2j_A_const_9 = A_arbace_o2j_A_const_pool.A[191]; A_arbace_o2j_A_const_10 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[192]); A_arbace_o2j_A_const_11 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[193]) }

func A_arbace_o2j_A_clinit_p1() { A_arbace_o2j_A_const_12 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[194]); A_arbace_o2j_A_const_13 = A_arbace_o2j_A_const_pool.A[195]; A_arbace_o2j_A_const_14 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[196]); A_arbace_o2j_A_const_15 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[197]); A_arbace_o2j_A_const_16 = A_arbace_o2j_A_const_pool.A[198]; A_arbace_o2j_A_const_17 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[199]); A_arbace_o2j_A_const_18 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[200]); A_arbace_o2j_A_const_19 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[201]); A_arbace_o2j_A_const_20 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[202]); A_arbace_o2j_A_const_21 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[203]); A_arbace_o2j_A_const_22 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[204]); A_arbace_o2j_A_const_23 = A_arbace_o2j_A_const_pool.A[205]; A_arbace_o2j_A_const_24 = A_arbace_o2j_A_const_pool.A[206] }

func A_arbace_o2j_A_clinit_p2() { A_arbace_o2j_A_const_25 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[207]); A_arbace_o2j_A_const_26 = A_arbace_o2j_A_const_pool.A[208]; A_arbace_o2j_A_const_27 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[209]); A_arbace_o2j_A_const_28 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[210]); A_arbace_o2j_A_const_29 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[211]); A_arbace_o2j_A_const_30 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[212]); A_arbace_o2j_A_const_31 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[213]); A_arbace_o2j_A_const_32 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[214]); A_arbace_o2j_A_const_33 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[215]); A_arbace_o2j_A_const_34 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[216]); A_arbace_o2j_A_const_35 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[217]); A_arbace_o2j_A_const_36 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[218]) }

func A_arbace_o2j_A_clinit_p3() { A_arbace_o2j_A_const_37 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[219]); A_arbace_o2j_A_const_38 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[220]); A_arbace_o2j_A_const_39 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[221]); A_arbace_o2j_A_const_40 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[222]); A_arbace_o2j_A_const_41 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[223]); A_arbace_o2j_A_const_42 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[224]); A_arbace_o2j_A_const_43 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[225]); A_arbace_o2j_A_const_44 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[226]); A_arbace_o2j_A_const_45 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[227]); A_arbace_o2j_A_const_46 = A_arbace_o2j_A_const_pool.A[228]; A_arbace_o2j_A_const_47 = A_arbace_o2j_A_const_pool.A[229]; A_arbace_o2j_A_const_48 = A_arbace_o2j_A_const_pool.A[230] }

func A_arbace_o2j_A_clinit_p4() { A_arbace_o2j_A_const_49 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[231]); A_arbace_o2j_A_const_50 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[232]); A_arbace_o2j_A_const_51 = A_arbace_o2j_A_const_pool.A[233]; A_arbace_o2j_A_const_52 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[234]); A_arbace_o2j_A_const_53 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[235]); A_arbace_o2j_A_const_54 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[236]); A_arbace_o2j_A_const_55 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[237]); A_arbace_o2j_A_const_56 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[238]); A_arbace_o2j_A_const_57 = A_arbace_o2j_A_const_pool.A[239]; A_arbace_o2j_A_const_58 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[240]); A_arbace_o2j_A_const_59 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[241]); A_arbace_o2j_A_const_60 = A_arbace_o2j_A_const_pool.A[242] }

func A_arbace_o2j_A_clinit_p5() { A_arbace_o2j_A_const_61 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[243]); A_arbace_o2j_A_const_62 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[244]); A_arbace_o2j_A_const_63 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[245]); A_arbace_o2j_A_const_64 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[246]); A_arbace_o2j_A_const_65 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[247]); A_arbace_o2j_A_const_66 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[248]); A_arbace_o2j_A_const_67 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[249]); A_arbace_o2j_A_const_68 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[250]); A_arbace_o2j_A_const_69 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[251]); A_arbace_o2j_A_const_70 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[252]); A_arbace_o2j_A_const_71 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[253]); A_arbace_o2j_A_const_72 = A_arbace_o2j_A_const_pool.A[254] }

func A_arbace_o2j_A_clinit_p6() { A_arbace_o2j_A_const_73 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[255]); A_arbace_o2j_A_const_74 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[256]); A_arbace_o2j_A_const_75 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[257]); A_arbace_o2j_A_const_76 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[258]); A_arbace_o2j_A_const_77 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[259]); A_arbace_o2j_A_const_78 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[260]); A_arbace_o2j_A_const_79 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[261]); A_arbace_o2j_A_const_80 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[262]); A_arbace_o2j_A_const_81 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[263]); A_arbace_o2j_A_const_82 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[264]); A_arbace_o2j_A_const_83 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[265]); A_arbace_o2j_A_const_84 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[266]) }

func A_arbace_o2j_A_clinit_p7() { A_arbace_o2j_A_const_85 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[267]); A_arbace_o2j_A_const_86 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[268]); A_arbace_o2j_A_const_87 = A_arbace_o2j_A_const_pool.A[269]; A_arbace_o2j_A_const_88 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[270]); A_arbace_o2j_A_const_89 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[271]); A_arbace_o2j_A_const_90 = A_arbace_o2j_A_const_pool.A[272]; A_arbace_o2j_A_const_91 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[273]); A_arbace_o2j_A_const_92 = A_arbace_o2j_A_const_pool.A[274]; A_arbace_o2j_A_const_93 = A_arbace_o2j_A_const_pool.A[275]; A_arbace_o2j_A_const_94 = A_arbace_o2j_A_const_pool.A[276]; A_arbace_o2j_A_const_95 = A_arbace_o2j_A_const_pool.A[277]; A_arbace_o2j_A_const_96 = A_arbace_o2j_A_const_pool.A[278]; A_arbace_o2j_A_const_97 = A_arbace_o2j_A_const_pool.A[279]; A_arbace_o2j_A_const_98 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[280]) }

func A_arbace_o2j_A_clinit_p8() { A_arbace_o2j_A_const_99 = A_arbace_o2j_A_const_pool.A[281]; A_arbace_o2j_A_const_100 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[282]); A_arbace_o2j_A_const_101 = A_arbace_o2j_A_const_pool.A[283]; A_arbace_o2j_A_const_102 = A_arbace_o2j_A_const_pool.A[284]; A_arbace_o2j_A_const_103 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[285]); A_arbace_o2j_A_const_104 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[286]); A_arbace_o2j_A_const_105 = A_arbace_o2j_A_const_pool.A[287]; A_arbace_o2j_A_const_106 = A_arbace_o2j_A_const_pool.A[288]; A_arbace_o2j_A_const_107 = A_arbace_o2j_A_const_pool.A[289]; A_arbace_o2j_A_const_108 = A_arbace_o2j_A_const_pool.A[290]; A_arbace_o2j_A_const_109 = A_arbace_o2j_A_const_pool.A[291]; A_arbace_o2j_A_const_110 = A_arbace_o2j_A_const_pool.A[292]; A_arbace_o2j_A_const_111 = A_arbace_o2j_A_const_pool.A[293]; A_arbace_o2j_A_const_112 = A_arbace_o2j_A_const_pool.A[294] }

func A_arbace_o2j_A_clinit_p9() { A_arbace_o2j_A_const_113 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[295]); A_arbace_o2j_A_const_114 = A_arbace_o2j_A_const_pool.A[296]; A_arbace_o2j_A_const_115 = A_arbace_o2j_A_const_pool.A[297]; A_arbace_o2j_A_const_116 = A_arbace_o2j_A_const_pool.A[298]; A_arbace_o2j_A_const_117 = A_arbace_o2j_A_const_pool.A[299]; A_arbace_o2j_A_const_118 = A_arbace_o2j_A_const_pool.A[300]; A_arbace_o2j_A_const_119 = A_arbace_o2j_A_const_pool.A[301]; A_arbace_o2j_A_const_120 = A_arbace_o2j_A_const_pool.A[302]; A_arbace_o2j_A_const_121 = A_arbace_o2j_A_const_pool.A[303]; A_arbace_o2j_A_const_122 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[304]); A_arbace_o2j_A_const_123 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[305]); A_arbace_o2j_A_const_124 = A_arbace_o2j_A_const_pool.A[306]; A_arbace_o2j_A_const_125 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[307]); A_arbace_o2j_A_const_126 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[308]) }

func A_arbace_o2j_A_clinit_p10() { A_arbace_o2j_A_const_127 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[309]); A_arbace_o2j_A_const_128 = A_arbace_o2j_A_const_pool.A[310]; A_arbace_o2j_A_const_129 = A_arbace_o2j_A_const_pool.A[311]; A_arbace_o2j_A_const_130 = A_arbace_o2j_A_const_pool.A[312]; A_arbace_o2j_A_const_131 = A_arbace_o2j_A_const_pool.A[313]; A_arbace_o2j_A_const_132 = A_arbace_o2j_A_const_pool.A[314]; A_arbace_o2j_A_const_133 = A_arbace_o2j_A_const_pool.A[315]; A_arbace_o2j_A_const_134 = A_arbace_o2j_A_const_pool.A[316]; A_arbace_o2j_A_const_135 = A_arbace_o2j_A_const_pool.A[317]; A_arbace_o2j_A_const_136 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[318]); A_arbace_o2j_A_const_137 = A_arbace_o2j_A_const_pool.A[319]; A_arbace_o2j_A_const_138 = A_arbace_o2j_A_const_pool.A[320]; A_arbace_o2j_A_const_139 = A_arbace_o2j_A_const_pool.A[321]; A_arbace_o2j_A_const_140 = A_arbace_o2j_A_const_pool.A[322]; A_arbace_o2j_A_const_141 = A_arbace_o2j_A_const_pool.A[323] }

func A_arbace_o2j_A_clinit_p11() { A_arbace_o2j_A_const_142 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[324]); A_arbace_o2j_A_const_143 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[325]); A_arbace_o2j_A_const_144 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[326]); A_arbace_o2j_A_const_145 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[327]); A_arbace_o2j_A_const_146 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[328]); A_arbace_o2j_A_const_147 = A_arbace_o2j_A_const_pool.A[329]; A_arbace_o2j_A_const_148 = A_arbace_o2j_A_const_pool.A[330]; A_arbace_o2j_A_const_149 = A_arbace_o2j_A_const_pool.A[331]; A_arbace_o2j_A_const_150 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[332]); A_arbace_o2j_A_const_151 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[333]); A_arbace_o2j_A_const_152 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[334]); A_arbace_o2j_A_const_153 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[335]) }

func A_arbace_o2j_A_clinit_p12() { A_arbace_o2j_A_const_154 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[336]); A_arbace_o2j_A_const_155 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[337]); A_arbace_o2j_A_const_156 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[338]); A_arbace_o2j_A_const_157 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[339]); A_arbace_o2j_A_const_158 = A_arbace_o2j_A_const_pool.A[340]; A_arbace_o2j_A_const_159 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[341]); A_arbace_o2j_A_const_160 = A_arbace_o2j_A_const_pool.A[342]; A_arbace_o2j_A_const_161 = A_arbace_o2j_A_const_pool.A[343]; A_arbace_o2j_A_const_162 = A_arbace_o2j_A_const_pool.A[344]; A_arbace_o2j_A_const_163 = A_arbace_o2j_A_const_pool.A[345]; A_arbace_o2j_A_const_164 = A_arbace_o2j_A_const_pool.A[346]; A_arbace_o2j_A_const_165 = A_arbace_o2j_A_const_pool.A[347]; A_arbace_o2j_A_const_166 = A_arbace_o2j_A_const_pool.A[348]; A_arbace_o2j_A_const_167 = A_arbace_o2j_A_const_pool.A[349] }

func A_arbace_o2j_A_clinit_p13() { A_arbace_o2j_A_const_168 = A_arbace_o2j_A_const_pool.A[350]; A_arbace_o2j_A_const_169 = A_arbace_o2j_A_const_pool.A[351]; A_arbace_o2j_A_const_170 = A_arbace_o2j_A_const_pool.A[352]; A_arbace_o2j_A_const_171 = A_arbace_o2j_A_const_pool.A[353]; A_arbace_o2j_A_const_172 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[354]); A_arbace_o2j_A_const_173 = A_arbace_o2j_A_const_pool.A[355]; A_arbace_o2j_A_const_174 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[356]); A_arbace_o2j_A_const_175 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[357]); A_arbace_o2j_A_const_176 = A_arbace_o2j_A_const_pool.A[358]; A_arbace_o2j_A_const_177 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[359]); A_arbace_o2j_A_const_178 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[360]); A_arbace_o2j_A_const_179 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[361]); A_arbace_o2j_A_const_180 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[362]) }

func A_arbace_o2j_A_clinit_p14() { A_arbace_o2j_A_const_181 = A_arbace_o2j_A_const_pool.A[363]; A_arbace_o2j_A_const_182 = A_arbace_o2j_A_const_pool.A[364]; A_arbace_o2j_A_const_183 = A_arbace_o2j_A_const_pool.A[365]; A_arbace_o2j_A_const_184 = A_arbace_o2j_A_const_pool.A[366]; A_arbace_o2j_A_const_185 = A_arbace_o2j_A_const_pool.A[367]; A_arbace_o2j_A_const_186 = A_arbace_o2j_A_const_pool.A[368]; A_arbace_o2j_A_const_187 = A_arbace_o2j_A_const_pool.A[369]; A_arbace_o2j_A_const_188 = A_arbace_o2j_A_const_pool.A[370]; A_arbace_o2j_A_const_189 = A_arbace_o2j_A_const_pool.A[371]; A_arbace_o2j_A_const_190 = A_arbace_o2j_A_const_pool.A[372]; A_arbace_o2j_A_const_191 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[373]); A_arbace_o2j_A_const_192 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[374]); A_arbace_o2j_A_const_193 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[375]); A_arbace_o2j_A_const_194 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[376]) }

func A_arbace_o2j_A_clinit_p15() { A_arbace_o2j_A_const_195 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[377]); A_arbace_o2j_A_const_196 = A_arbace_o2j_A_const_pool.A[378]; A_arbace_o2j_A_const_197 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[379]); A_arbace_o2j_A_const_198 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[380]); A_arbace_o2j_A_const_199 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[381]); A_arbace_o2j_A_const_200 = A_arbace_o2j_A_const_pool.A[382]; A_arbace_o2j_A_const_201 = A_arbace_o2j_A_const_pool.A[383]; A_arbace_o2j_A_const_202 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[384]); A_arbace_o2j_A_const_203 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[385]); A_arbace_o2j_A_const_204 = A_arbace_o2j_A_const_pool.A[386]; A_arbace_o2j_A_const_205 = A_arbace_o2j_A_const_pool.A[387]; A_arbace_o2j_A_const_206 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[388]); A_arbace_o2j_A_const_207 = A_arbace_o2j_A_const_pool.A[389] }

func A_arbace_o2j_A_clinit_p16() { A_arbace_o2j_A_const_208 = A_arbace_o2j_A_const_pool.A[390]; A_arbace_o2j_A_const_209 = A_arbace_o2j_A_const_pool.A[391]; A_arbace_o2j_A_const_210 = A_arbace_o2j_A_const_pool.A[392]; A_arbace_o2j_A_const_211 = A_arbace_o2j_A_const_pool.A[393]; A_arbace_o2j_A_const_212 = A_arbace_o2j_A_const_pool.A[394]; A_arbace_o2j_A_const_213 = A_arbace_o2j_A_const_pool.A[395]; A_arbace_o2j_A_const_214 = A_arbace_o2j_A_const_pool.A[396]; A_arbace_o2j_A_const_215 = A_arbace_o2j_A_const_pool.A[397]; A_arbace_o2j_A_const_216 = A_arbace_o2j_A_const_pool.A[398]; A_arbace_o2j_A_const_217 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[399]); A_arbace_o2j_A_const_218 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[400]); A_arbace_o2j_A_const_219 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[401]); A_arbace_o2j_A_const_220 = A_arbace_o2j_A_const_pool.A[402]; A_arbace_o2j_A_const_221 = A_arbace_o2j_A_const_pool.A[403]; A_arbace_o2j_A_const_222 = A_arbace_o2j_A_const_pool.A[404] }

func A_arbace_o2j_A_clinit_p17() { A_arbace_o2j_A_const_223 = A_arbace_o2j_A_const_pool.A[405]; A_arbace_o2j_A_const_224 = A_arbace_o2j_A_const_pool.A[406]; A_arbace_o2j_A_const_225 = A_arbace_o2j_A_const_pool.A[407]; A_arbace_o2j_A_const_226 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[408]); A_arbace_o2j_A_const_227 = A_arbace_o2j_A_const_pool.A[409]; A_arbace_o2j_A_const_228 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[410]); A_arbace_o2j_A_const_229 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[411]); A_arbace_o2j_A_const_230 = A_arbace_o2j_A_const_pool.A[412]; A_arbace_o2j_A_const_231 = A_arbace_o2j_A_const_pool.A[413]; A_arbace_o2j_A_const_232 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[414]); A_arbace_o2j_A_const_233 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[415]); A_arbace_o2j_A_const_234 = A_arbace_o2j_A_const_pool.A[416]; A_arbace_o2j_A_const_235 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[417]); A_arbace_o2j_A_const_236 = A_arbace_o2j_A_const_pool.A[418] }

func A_arbace_o2j_A_clinit_p18() { A_arbace_o2j_A_const_237 = A_arbace_o2j_A_const_pool.A[419]; A_arbace_o2j_A_const_238 = A_arbace_o2j_A_const_pool.A[420]; A_arbace_o2j_A_const_239 = A_arbace_o2j_A_const_pool.A[421]; A_arbace_o2j_A_const_240 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[422]); A_arbace_o2j_A_const_241 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[423]); A_arbace_o2j_A_const_242 = A_arbace_o2j_A_const_pool.A[424]; A_arbace_o2j_A_const_243 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[425]); A_arbace_o2j_A_const_244 = A_arbace_o2j_A_const_pool.A[426]; A_arbace_o2j_A_const_245 = A_arbace_o2j_A_const_pool.A[427]; A_arbace_o2j_A_const_246 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[428]); A_arbace_o2j_A_const_247 = A_arbace_o2j_A_const_pool.A[429]; A_arbace_o2j_A_const_248 = A_arbace_o2j_A_const_pool.A[430]; A_arbace_o2j_A_const_249 = A_arbace_o2j_A_const_pool.A[431]; A_arbace_o2j_A_const_250 = A_arbace_o2j_A_const_pool.A[432] }

func A_arbace_o2j_A_clinit_p19() { A_arbace_o2j_A_const_251 = A_arbace_o2j_A_const_pool.A[433]; A_arbace_o2j_A_const_252 = A_arbace_o2j_A_const_pool.A[434]; A_arbace_o2j_A_const_253 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[435]); A_arbace_o2j_A_const_254 = A_arbace_o2j_A_const_pool.A[436]; A_arbace_o2j_A_const_255 = A_arbace_o2j_A_const_pool.A[437]; A_arbace_o2j_A_const_256 = A_arbace_o2j_A_const_pool.A[438]; A_arbace_o2j_A_const_257 = A_arbace_o2j_A_const_pool.A[439]; A_arbace_o2j_A_const_258 = A_arbace_o2j_A_const_pool.A[440]; A_arbace_o2j_A_const_259 = A_arbace_o2j_A_const_pool.A[441]; A_arbace_o2j_A_const_260 = A_arbace_o2j_A_const_pool.A[442]; A_arbace_o2j_A_const_261 = A_arbace_o2j_A_const_pool.A[443]; A_arbace_o2j_A_const_262 = A_arbace_o2j_A_const_pool.A[444]; A_arbace_o2j_A_const_263 = A_arbace_o2j_A_const_pool.A[445]; A_arbace_o2j_A_const_264 = A_arbace_o2j_A_const_pool.A[446]; A_arbace_o2j_A_const_265 = A_arbace_o2j_A_const_pool.A[447] }

func A_arbace_o2j_A_clinit_p20() { A_arbace_o2j_A_const_266 = A_arbace_o2j_A_const_pool.A[448]; A_arbace_o2j_A_const_267 = A_arbace_o2j_A_const_pool.A[449]; A_arbace_o2j_A_const_268 = A_arbace_o2j_A_const_pool.A[450]; A_arbace_o2j_A_const_269 = A_arbace_o2j_A_const_pool.A[451]; A_arbace_o2j_A_const_270 = A_arbace_o2j_A_const_pool.A[452]; A_arbace_o2j_A_const_271 = A_arbace_o2j_A_const_pool.A[453]; A_arbace_o2j_A_const_272 = A_arbace_o2j_A_const_pool.A[454]; A_arbace_o2j_A_const_273 = A_arbace_o2j_A_const_pool.A[455]; A_arbace_o2j_A_const_274 = A_arbace_o2j_A_const_pool.A[456]; A_arbace_o2j_A_const_275 = A_arbace_o2j_A_const_pool.A[457]; A_arbace_o2j_A_const_276 = A_arbace_o2j_A_const_pool.A[458]; A_arbace_o2j_A_const_277 = A_arbace_o2j_A_const_pool.A[459]; A_arbace_o2j_A_const_278 = A_arbace_o2j_A_const_pool.A[460]; A_arbace_o2j_A_const_279 = A_arbace_o2j_A_const_pool.A[461]; A_arbace_o2j_A_const_280 = A_arbace_o2j_A_const_pool.A[462] }

func A_arbace_o2j_A_clinit_p21() { A_arbace_o2j_A_const_281 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[463]); A_arbace_o2j_A_const_282 = A_arbace_o2j_A_const_pool.A[464]; A_arbace_o2j_A_const_283 = A_arbace_o2j_A_const_pool.A[465]; A_arbace_o2j_A_const_284 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[466]); A_arbace_o2j_A_const_285 = A_arbace_o2j_A_const_pool.A[467]; A_arbace_o2j_A_const_286 = A_arbace_o2j_A_const_pool.A[468]; A_arbace_o2j_A_const_287 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[469]); A_arbace_o2j_A_const_288 = A_arbace_o2j_A_const_pool.A[470]; A_arbace_o2j_A_const_289 = A_arbace_o2j_A_const_pool.A[471]; A_arbace_o2j_A_const_290 = A_arbace_o2j_A_const_pool.A[472]; A_arbace_o2j_A_const_291 = A_arbace_o2j_A_const_pool.A[473]; A_arbace_o2j_A_const_292 = A_arbace_o2j_A_const_pool.A[474]; A_arbace_o2j_A_const_293 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[475]); A_arbace_o2j_A_const_294 = A_arbace_o2j_A_const_pool.A[476] }

func A_arbace_o2j_A_clinit_p22() { A_arbace_o2j_A_const_295 = A_arbace_o2j_A_const_pool.A[477]; A_arbace_o2j_A_const_296 = A_arbace_o2j_A_const_pool.A[478]; A_arbace_o2j_A_const_297 = A_arbace_o2j_A_const_pool.A[479]; A_arbace_o2j_A_const_298 = A_arbace_o2j_A_const_pool.A[480]; A_arbace_o2j_A_const_299 = A_arbace_o2j_A_const_pool.A[481]; A_arbace_o2j_A_const_300 = A_arbace_o2j_A_const_pool.A[482]; A_arbace_o2j_A_const_301 = A_arbace_o2j_A_const_pool.A[483]; A_arbace_o2j_A_const_302 = A_arbace_o2j_A_const_pool.A[484]; A_arbace_o2j_A_const_303 = A_arbace_o2j_A_const_pool.A[485]; A_arbace_o2j_A_const_304 = A_arbace_o2j_A_const_pool.A[486]; A_arbace_o2j_A_const_305 = A_arbace_o2j_A_const_pool.A[487]; A_arbace_o2j_A_const_306 = A_arbace_o2j_A_const_pool.A[488]; A_arbace_o2j_A_const_307 = A_arbace_o2j_A_const_pool.A[489]; A_arbace_o2j_A_const_308 = A_arbace_o2j_A_const_pool.A[490]; A_arbace_o2j_A_const_309 = A_arbace_o2j_A_const_pool.A[491]; A_arbace_o2j_A_const_310 = A_arbace_o2j_A_const_pool.A[492] }

func A_arbace_o2j_A_clinit_p23() { A_arbace_o2j_A_const_311 = A_arbace_o2j_A_const_pool.A[493]; A_arbace_o2j_A_const_312 = A_arbace_o2j_A_const_pool.A[494]; A_arbace_o2j_A_const_313 = A_arbace_o2j_A_const_pool.A[495]; A_arbace_o2j_A_const_314 = A_arbace_o2j_A_const_pool.A[496]; A_arbace_o2j_A_const_315 = A_arbace_o2j_A_const_pool.A[497]; A_arbace_o2j_A_const_316 = A_arbace_o2j_A_const_pool.A[498]; A_arbace_o2j_A_const_317 = A_arbace_o2j_A_const_pool.A[499]; A_arbace_o2j_A_const_318 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[500]); A_arbace_o2j_A_const_319 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[501]); A_arbace_o2j_A_const_320 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[502]); A_arbace_o2j_A_const_321 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[503]); A_arbace_o2j_A_const_322 = A_arbace_o2j_A_const_pool.A[504]; A_arbace_o2j_A_const_323 = A_arbace_o2j_A_const_pool.A[505]; A_arbace_o2j_A_const_324 = A_arbace_o2j_A_const_pool.A[506] }

func A_arbace_o2j_A_clinit_p24() { A_arbace_o2j_A_const_325 = A_arbace_o2j_A_const_pool.A[507]; A_arbace_o2j_A_const_326 = A_arbace_o2j_A_const_pool.A[508]; A_arbace_o2j_A_const_327 = A_arbace_o2j_A_const_pool.A[509]; A_arbace_o2j_A_const_328 = A_arbace_o2j_A_const_pool.A[510]; A_arbace_o2j_A_const_329 = A_arbace_o2j_A_const_pool.A[511]; A_arbace_o2j_A_const_330 = A_arbace_o2j_A_const_pool.A[512]; A_arbace_o2j_A_const_331 = A_arbace_o2j_A_const_pool.A[513]; A_arbace_o2j_A_const_332 = A_arbace_o2j_A_const_pool.A[514]; A_arbace_o2j_A_const_333 = A_arbace_o2j_A_const_pool.A[515]; A_arbace_o2j_A_const_334 = A_arbace_o2j_A_const_pool.A[516]; A_arbace_o2j_A_const_335 = A_arbace_o2j_A_const_pool.A[517]; A_arbace_o2j_A_const_336 = A_arbace_o2j_A_const_pool.A[518]; A_arbace_o2j_A_const_337 = A_arbace_o2j_A_const_pool.A[519]; A_arbace_o2j_A_const_338 = A_arbace_o2j_A_const_pool.A[520]; A_arbace_o2j_A_const_339 = A_arbace_o2j_A_const_pool.A[521]; A_arbace_o2j_A_const_340 = A_arbace_o2j_A_const_pool.A[522] }

func A_arbace_o2j_A_clinit_p25() { A_arbace_o2j_A_const_341 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[523]); A_arbace_o2j_A_const_342 = A_arbace_o2j_A_const_pool.A[524]; A_arbace_o2j_A_const_343 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[525]); A_arbace_o2j_A_const_344 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[526]); A_arbace_o2j_A_const_345 = A_arbace_o2j_A_const_pool.A[527]; A_arbace_o2j_A_const_346 = A_arbace_o2j_A_const_pool.A[528]; A_arbace_o2j_A_const_347 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[529]); A_arbace_o2j_A_const_348 = A_arbace_o2j_A_const_pool.A[530]; A_arbace_o2j_A_const_349 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[531]); A_arbace_o2j_A_const_350 = A_arbace_o2j_A_const_pool.A[532]; A_arbace_o2j_A_const_351 = A_arbace_o2j_A_const_pool.A[533]; A_arbace_o2j_A_const_352 = A_arbace_o2j_A_const_pool.A[534]; A_arbace_o2j_A_const_353 = A_arbace_o2j_A_const_pool.A[535]; A_arbace_o2j_A_const_354 = A_arbace_o2j_A_const_pool.A[536] }

func A_arbace_o2j_A_clinit_p26() { A_arbace_o2j_A_const_355 = A_arbace_o2j_A_const_pool.A[537]; A_arbace_o2j_A_const_356 = A_arbace_o2j_A_const_pool.A[538]; A_arbace_o2j_A_const_357 = A_arbace_o2j_A_const_pool.A[539]; A_arbace_o2j_A_const_358 = A_arbace_o2j_A_const_pool.A[540]; A_arbace_o2j_A_const_359 = A_arbace_o2j_A_const_pool.A[541]; A_arbace_o2j_A_const_360 = A_arbace_o2j_A_const_pool.A[542]; A_arbace_o2j_A_const_361 = A_arbace_o2j_A_const_pool.A[543]; A_arbace_o2j_A_const_362 = A_arbace_o2j_A_const_pool.A[544]; A_arbace_o2j_A_const_363 = A_arbace_o2j_A_const_pool.A[545]; A_arbace_o2j_A_const_364 = A_arbace_o2j_A_const_pool.A[546]; A_arbace_o2j_A_const_365 = A_arbace_o2j_A_const_pool.A[547]; A_arbace_o2j_A_const_366 = A_arbace_o2j_A_const_pool.A[548]; A_arbace_o2j_A_const_367 = A_arbace_o2j_A_const_pool.A[549]; A_arbace_o2j_A_const_368 = A_arbace_o2j_A_const_pool.A[550]; A_arbace_o2j_A_const_369 = A_arbace_o2j_A_const_pool.A[551]; A_arbace_o2j_A_const_370 = A_arbace_o2j_A_const_pool.A[552] }

func A_arbace_o2j_A_clinit_p27() { A_arbace_o2j_A_const_371 = A_arbace_o2j_A_const_pool.A[553]; A_arbace_o2j_A_const_372 = A_arbace_o2j_A_const_pool.A[554]; A_arbace_o2j_A_const_373 = A_arbace_o2j_A_const_pool.A[555]; A_arbace_o2j_A_const_374 = A_arbace_o2j_A_const_pool.A[556]; A_arbace_o2j_A_const_375 = A_arbace_o2j_A_const_pool.A[557]; A_arbace_o2j_A_const_376 = A_arbace_o2j_A_const_pool.A[558]; A_arbace_o2j_A_const_377 = A_arbace_o2j_A_const_pool.A[559]; A_arbace_o2j_A_const_378 = A_arbace_o2j_A_const_pool.A[560]; A_arbace_o2j_A_const_379 = A_arbace_o2j_A_const_pool.A[561]; A_arbace_o2j_A_const_380 = A_arbace_o2j_A_const_pool.A[562]; A_arbace_o2j_A_const_381 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[563]); A_arbace_o2j_A_const_382 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[564]); A_arbace_o2j_A_const_383 = A_arbace_o2j_A_const_pool.A[565]; A_arbace_o2j_A_const_384 = A_arbace_o2j_A_const_pool.A[566]; A_arbace_o2j_A_const_385 = A_arbace_o2j_A_const_pool.A[567] }

func A_arbace_o2j_A_clinit_p28() { A_arbace_o2j_A_const_386 = A_arbace_o2j_A_const_pool.A[568]; A_arbace_o2j_A_const_387 = A_arbace_o2j_A_const_pool.A[569]; A_arbace_o2j_A_const_388 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[570]); A_arbace_o2j_A_const_389 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[571]); A_arbace_o2j_A_const_390 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[572]); A_arbace_o2j_A_const_391 = A_arbace_o2j_A_const_pool.A[573]; A_arbace_o2j_A_const_392 = A_arbace_o2j_A_const_pool.A[574]; A_arbace_o2j_A_const_393 = A_arbace_o2j_A_const_pool.A[575]; A_arbace_o2j_A_const_394 = A_arbace_o2j_A_const_pool.A[576]; A_arbace_o2j_A_const_395 = A_arbace_o2j_A_const_pool.A[577]; A_arbace_o2j_A_const_396 = A_arbace_o2j_A_const_pool.A[578]; A_arbace_o2j_A_const_397 = A_arbace_o2j_A_const_pool.A[579]; A_arbace_o2j_A_const_398 = A_arbace_o2j_A_const_pool.A[580]; A_arbace_o2j_A_const_399 = A_arbace_o2j_A_const_pool.A[581]; A_arbace_o2j_A_const_400 = A_arbace_o2j_A_const_pool.A[582] }

func A_arbace_o2j_A_clinit_p29() { A_arbace_o2j_A_const_401 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[583]); A_arbace_o2j_A_const_402 = A_arbace_o2j_A_const_pool.A[584]; A_arbace_o2j_A_const_403 = A_arbace_o2j_A_const_pool.A[585]; A_arbace_o2j_A_const_404 = A_arbace_o2j_A_const_pool.A[586]; A_arbace_o2j_A_const_405 = A_arbace_o2j_A_const_pool.A[587]; A_arbace_o2j_A_const_406 = A_arbace_o2j_A_const_pool.A[588]; A_arbace_o2j_A_const_407 = A_arbace_o2j_A_const_pool.A[589]; A_arbace_o2j_A_const_408 = A_arbace_o2j_A_const_pool.A[590]; A_arbace_o2j_A_const_409 = A_arbace_o2j_A_const_pool.A[591]; A_arbace_o2j_A_const_410 = A_arbace_o2j_A_const_pool.A[592]; A_arbace_o2j_A_const_411 = A_arbace_o2j_A_const_pool.A[593]; A_arbace_o2j_A_const_412 = A_arbace_o2j_A_const_pool.A[594]; A_arbace_o2j_A_const_413 = A_arbace_o2j_A_const_pool.A[595]; A_arbace_o2j_A_const_414 = A_arbace_o2j_A_const_pool.A[596]; A_arbace_o2j_A_const_415 = A_arbace_o2j_A_const_pool.A[597] }

func A_arbace_o2j_A_clinit_p30() { A_arbace_o2j_A_const_416 = A_arbace_o2j_A_const_pool.A[598]; A_arbace_o2j_A_const_417 = A_arbace_o2j_A_const_pool.A[599]; A_arbace_o2j_A_const_418 = A_arbace_o2j_A_const_pool.A[600]; A_arbace_o2j_A_const_419 = A_arbace_o2j_A_const_pool.A[601]; A_arbace_o2j_A_const_420 = A_arbace_o2j_A_const_pool.A[602]; A_arbace_o2j_A_const_421 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[603]); A_arbace_o2j_A_const_422 = A_arbace_o2j_A_const_pool.A[604]; A_arbace_o2j_A_const_423 = A_arbace_o2j_A_const_pool.A[605]; A_arbace_o2j_A_const_424 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[606]); A_arbace_o2j_A_const_425 = A_arbace_o2j_A_const_pool.A[607]; A_arbace_o2j_A_const_426 = A_arbace_o2j_A_const_pool.A[608]; A_arbace_o2j_A_const_427 = A_arbace_o2j_A_const_pool.A[609]; A_arbace_o2j_A_const_428 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[610]); A_arbace_o2j_A_const_429 = A_arbace_o2j_A_const_pool.A[611]; A_arbace_o2j_A_const_430 = A_arbace_o2j_A_const_pool.A[612] }

func A_arbace_o2j_A_clinit_p31() { A_arbace_o2j_A_const_431 = A_arbace_o2j_A_const_pool.A[613]; A_arbace_o2j_A_const_432 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[614]); A_arbace_o2j_A_const_433 = A_arbace_o2j_A_const_pool.A[615]; A_arbace_o2j_A_const_434 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[616]); A_arbace_o2j_A_const_435 = A_arbace_o2j_A_const_pool.A[617]; A_arbace_o2j_A_const_436 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[618]); A_arbace_o2j_A_const_437 = A_arbace_o2j_A_const_pool.A[619]; A_arbace_o2j_A_const_438 = A_arbace_o2j_A_const_pool.A[620]; A_arbace_o2j_A_const_439 = A_arbace_o2j_A_const_pool.A[621]; A_arbace_o2j_A_const_440 = A_arbace_o2j_A_const_pool.A[622]; A_arbace_o2j_A_const_441 = A_arbace_o2j_A_const_pool.A[623]; A_arbace_o2j_A_const_442 = A_arbace_o2j_A_const_pool.A[624]; A_arbace_o2j_A_const_443 = A_arbace_o2j_A_const_pool.A[625]; A_arbace_o2j_A_const_444 = A_arbace_o2j_A_const_pool.A[626] }

func A_arbace_o2j_A_clinit_p32() { A_arbace_o2j_A_const_445 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[627]); A_arbace_o2j_A_const_446 = A_arbace_o2j_A_const_pool.A[628]; A_arbace_o2j_A_const_447 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[629]); A_arbace_o2j_A_const_448 = A_arbace_o2j_A_const_pool.A[630]; A_arbace_o2j_A_const_449 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[631]); A_arbace_o2j_A_const_450 = A_arbace_o2j_A_const_pool.A[632]; A_arbace_o2j_A_const_451 = A_arbace_o2j_A_const_pool.A[633]; A_arbace_o2j_A_const_452 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[634]); A_arbace_o2j_A_const_453 = A_arbace_o2j_A_const_pool.A[635]; A_arbace_o2j_A_const_454 = A_arbace_o2j_A_const_pool.A[636]; A_arbace_o2j_A_const_455 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[637]); A_arbace_o2j_A_const_456 = A_arbace_o2j_A_const_pool.A[638]; A_arbace_o2j_A_const_457 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[639]); A_arbace_o2j_A_const_458 = A_arbace_o2j_A_const_pool.A[640] }

func A_arbace_o2j_A_clinit_p33() { A_arbace_o2j_A_const_459 = A_arbace_o2j_A_const_pool.A[641]; A_arbace_o2j_A_const_460 = A_arbace_o2j_A_const_pool.A[642]; A_arbace_o2j_A_const_461 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[643]); A_arbace_o2j_A_const_462 = A_arbace_o2j_A_const_pool.A[644]; A_arbace_o2j_A_const_463 = A_arbace_o2j_A_const_pool.A[645]; A_arbace_o2j_A_const_464 = A_arbace_o2j_A_const_pool.A[646]; A_arbace_o2j_A_const_465 = A_arbace_o2j_A_const_pool.A[647]; A_arbace_o2j_A_const_466 = A_arbace_o2j_A_const_pool.A[648]; A_arbace_o2j_A_const_467 = A_arbace_o2j_A_const_pool.A[649]; A_arbace_o2j_A_const_468 = A_arbace_o2j_A_const_pool.A[650]; A_arbace_o2j_A_const_469 = A_arbace_o2j_A_const_pool.A[651]; A_arbace_o2j_A_const_470 = A_arbace_o2j_A_const_pool.A[652]; A_arbace_o2j_A_const_471 = A_arbace_o2j_A_const_pool.A[653]; A_arbace_o2j_A_const_472 = A_arbace_o2j_A_const_pool.A[654]; A_arbace_o2j_A_const_473 = A_arbace_o2j_A_const_pool.A[655] }

func A_arbace_o2j_A_clinit_p34() { A_arbace_o2j_A_const_474 = A_arbace_o2j_A_const_pool.A[656]; A_arbace_o2j_A_const_475 = A_arbace_o2j_A_const_pool.A[657]; A_arbace_o2j_A_const_476 = A_arbace_o2j_A_const_pool.A[658]; A_arbace_o2j_A_const_477 = A_arbace_o2j_A_const_pool.A[659]; A_arbace_o2j_A_const_478 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[660]); A_arbace_o2j_A_const_479 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[661]); A_arbace_o2j_A_const_480 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[662]); A_arbace_o2j_A_const_481 = A_arbace_o2j_A_const_pool.A[663]; A_arbace_o2j_A_const_482 = A_arbace_o2j_A_const_pool.A[664]; A_arbace_o2j_A_const_483 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[665]); A_arbace_o2j_A_const_484 = A_arbace_o2j_A_const_pool.A[666]; A_arbace_o2j_A_const_485 = A_arbace_o2j_A_const_pool.A[667]; A_arbace_o2j_A_const_486 = A_arbace_o2j_A_const_pool.A[668]; A_arbace_o2j_A_const_487 = A_arbace_o2j_A_const_pool.A[669] }

func A_arbace_o2j_A_clinit_p35() { A_arbace_o2j_A_const_488 = A_arbace_o2j_A_const_pool.A[670]; A_arbace_o2j_A_const_489 = A_arbace_o2j_A_const_pool.A[671]; A_arbace_o2j_A_const_490 = A_arbace_o2j_A_const_pool.A[672]; A_arbace_o2j_A_const_491 = A_arbace_o2j_A_const_pool.A[673]; A_arbace_o2j_A_const_492 = A_arbace_o2j_A_const_pool.A[674]; A_arbace_o2j_A_const_493 = A_arbace_o2j_A_const_pool.A[675]; A_arbace_o2j_A_const_494 = A_arbace_o2j_A_const_pool.A[676]; A_arbace_o2j_A_const_495 = A_arbace_o2j_A_const_pool.A[677]; A_arbace_o2j_A_const_496 = A_arbace_o2j_A_const_pool.A[678]; A_arbace_o2j_A_const_497 = A_arbace_o2j_A_const_pool.A[679]; A_arbace_o2j_A_const_498 = A_arbace_o2j_A_const_pool.A[680]; A_arbace_o2j_A_const_499 = A_arbace_o2j_A_const_pool.A[681]; A_arbace_o2j_A_const_500 = A_arbace_o2j_A_const_pool.A[682]; A_arbace_o2j_A_const_501 = A_arbace_o2j_A_const_pool.A[683]; A_arbace_o2j_A_const_502 = A_arbace_o2j_A_const_pool.A[684]; A_arbace_o2j_A_const_503 = A_arbace_o2j_A_const_pool.A[685] }

func A_arbace_o2j_A_clinit_p36() { A_arbace_o2j_A_const_504 = A_arbace_o2j_A_const_pool.A[686]; A_arbace_o2j_A_const_505 = A_arbace_o2j_A_const_pool.A[687]; A_arbace_o2j_A_const_506 = A_arbace_o2j_A_const_pool.A[688]; A_arbace_o2j_A_const_507 = A_arbace_o2j_A_const_pool.A[689]; A_arbace_o2j_A_const_508 = A_arbace_o2j_A_const_pool.A[690]; A_arbace_o2j_A_const_509 = A_arbace_o2j_A_const_pool.A[691]; A_arbace_o2j_A_const_510 = A_arbace_o2j_A_const_pool.A[692]; A_arbace_o2j_A_const_511 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[693]); A_arbace_o2j_A_const_512 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[694]); A_arbace_o2j_A_const_513 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[695]); A_arbace_o2j_A_const_514 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[696]); A_arbace_o2j_A_const_515 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[697]); A_arbace_o2j_A_const_516 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[698]) }

func A_arbace_o2j_A_clinit_p37() { A_arbace_o2j_A_const_517 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[699]); A_arbace_o2j_A_const_518 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[700]); A_arbace_o2j_A_const_519 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[701]); A_arbace_o2j_A_const_520 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[702]); A_arbace_o2j_A_const_521 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[703]); A_arbace_o2j_A_const_522 = A_arbace_o2j_A_const_pool.A[704]; A_arbace_o2j_A_const_523 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[705]); A_arbace_o2j_A_const_524 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[706]); A_arbace_o2j_A_const_525 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[707]); A_arbace_o2j_A_const_526 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[708]); A_arbace_o2j_A_const_527 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[709]); A_arbace_o2j_A_const_528 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[710]) }

func A_arbace_o2j_A_clinit_p38() { A_arbace_o2j_A_const_529 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[711]); A_arbace_o2j_A_const_530 = lang.Keyword_Cast(A_arbace_o2j_A_const_pool.A[712]); A_arbace_o2j_A_const_531 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[713]); A_arbace_o2j_A_const_532 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[714]); A_arbace_o2j_A_const_533 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[715]); A_arbace_o2j_A_const_534 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[716]); A_arbace_o2j_A_const_535 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[717]); A_arbace_o2j_A_const_536 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[718]); A_arbace_o2j_A_const_537 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[719]); A_arbace_o2j_A_const_538 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[720]); A_arbace_o2j_A_const_539 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[721]); A_arbace_o2j_A_const_540 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[722]) }

func A_arbace_o2j_A_clinit_p39() { A_arbace_o2j_A_const_541 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[723]); A_arbace_o2j_A_const_542 = lang.Var_Cast(A_arbace_o2j_A_const_pool.A[724]); A_arbace_o2j_A_const_543 = A_arbace_o2j_A_const_pool.A[725]; A_arbace_o2j_A_const_544 = A_arbace_o2j_A_const_pool.A[726] }

func A_arbace_o2j_A_New() *A_arbace_o2j_A { A_arbace_o2j_A_Init(); t := &A_arbace_o2j_A{}; t.Ctor(); return t }

func (t *A_arbace_o2j_A) Ctor() {}

func (t *A_arbace_o2j_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_o2j_A) GetClass__Class() *jrt.Class { return A_arbace_o2j_A_class }

func (t *A_arbace_o2j_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_o2j_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_o2j_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_o2j_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_o2j_A); return ok }

func A_arbace_o2j_A_Cast(x any) *A_arbace_o2j_A { if x == nil { return nil }; v, ok := x.(*A_arbace_o2j_A); if !ok { panic(jrt.ClassCast(x, A_arbace_o2j_A_class)) }; return v }



type A_arbace_o2j__main_A struct{ j2g_header uint64 }

var A_arbace_o2j__main_A_fn_class *jrt.Class



type A_arbace_o2j__main_fn__1641000555_A struct{ j2g_header uint64; F_od, F_dumps, F_lo any }

var A_arbace_o2j__main_fn__1641000555_A_fn_class *jrt.Class



type A_arbace_o2j__main_fn__1641000560_A struct{ j2g_header uint64; F_dumps, F_lo, F_od any }

var A_arbace_o2j__main_fn__1641000560_A_fn_class *jrt.Class



type A_arbace_o2j__main_iter__1641000601__1641000605_A struct{ j2g_header uint64; F_od, F_ld any }

var A_arbace_o2j__main_iter__1641000601__1641000605_A_fn_class *jrt.Class



type A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A struct{ j2g_header uint64; F_iter__1641000601, F_od, F_ld, F_s__1641000602 any }

var A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_A_fn_class *jrt.Class



type A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A struct{ j2g_header uint64; F_b__1641000604, F_od, F_ld any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j__main_iter__1641000601__1641000605_fn__1641000606_fn__1641000607_A_fn_class *jrt.Class



type A_arbace_o2j_apply_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_apply_node_A_fn_class *jrt.Class



type A_arbace_o2j_apply_node_fn__1641000187_A struct{ j2g_header uint64; F_self any }

var A_arbace_o2j_apply_node_fn__1641000187_A_fn_class *jrt.Class



type A_arbace_o2j_apply_node_fn__1641000189_A struct{ j2g_header uint64; F_f, F_ctx any }

var A_arbace_o2j_apply_node_fn__1641000189_A_fn_class *jrt.Class



type A_arbace_o2j_apply_node_fn__1641000191_A struct{ j2g_header uint64 }

var A_arbace_o2j_apply_node_fn__1641000191_A_fn_class *jrt.Class



type A_arbace_o2j_array_kind_A struct{ j2g_header uint64 }

var A_arbace_o2j_array_kind_A_fn_class *jrt.Class



type A_arbace_o2j_bigarray_ext_A struct{ j2g_header uint64 }

var A_arbace_o2j_bigarray_ext_A_fn_class *jrt.Class



type A_arbace_o2j_bound_and_refs_A struct{ j2g_header uint64 }

var A_arbace_o2j_bound_and_refs_A_fn_class *jrt.Class



type A_arbace_o2j_bound_and_refs_walk__1641000085_A struct{ j2g_header uint64; F_walk_any, F_bound, F_refs any }

var A_arbace_o2j_bound_and_refs_walk__1641000085_A_fn_class *jrt.Class



type A_arbace_o2j_bound_and_refs_walk_any__1641000149_A struct{ j2g_header uint64; F_walk any }

var A_arbace_o2j_bound_and_refs_walk_any__1641000149_A_fn_class *jrt.Class



type A_arbace_o2j_call_form_A struct{ j2g_header uint64 }

var A_arbace_o2j_call_form_A_fn_class *jrt.Class



type A_arbace_o2j_class_name_A struct{ j2g_header uint64 }

var A_arbace_o2j_class_name_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__fn__1641000201_A struct{ j2g_header uint64; F_self_id any }

var A_arbace_o2j_closure_class_BANG__fn__1641000201_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__fn__1641000203_A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__fn__1641000203_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__fn__1641000206_A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__fn__1641000206_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__fn__1641000211_A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__fn__1641000211_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A struct{ j2g_header uint64; F_s__1641000214, F_iter__1641000213 any }

var A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A struct{ j2g_header uint64; F_b__1641000216 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_closure_class_BANG__iter__1641000213__1641000217_fn__1641000218_fn__1641000219_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A struct{ j2g_header uint64 }

var A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A struct{ j2g_header uint64; F_s__1641000224, F_iter__1641000223 any }

var A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_A_fn_class *jrt.Class



type A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A struct{ j2g_header uint64; F_b__1641000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_closure_class_BANG__iter__1641000223__1641000227_fn__1641000228_fn__1641000229_A_fn_class *jrt.Class



type A_arbace_o2j_const_form_A struct{ j2g_header uint64 }

var A_arbace_o2j_const_form_A_fn_class *jrt.Class



type A_arbace_o2j_const_init_A struct{ j2g_header uint64 }

var A_arbace_o2j_const_init_A_fn_class *jrt.Class



type A_arbace_o2j_const_init_fn__1641000075_A struct{ j2g_header uint64 }

var A_arbace_o2j_const_init_fn__1641000075_A_fn_class *jrt.Class



type A_arbace_o2j_double_form_A struct{ j2g_header uint64 }

var A_arbace_o2j_double_form_A_fn_class *jrt.Class



type A_arbace_o2j_eval1641000004_A struct{ jrt.Object }

func A_arbace_o2j_eval1641000004_A_New() *A_arbace_o2j_eval1641000004_A { t := &A_arbace_o2j_eval1641000004_A{}; t.Ctor(); return t }

func (t *A_arbace_o2j_eval1641000004_A) Ctor() {}

func (t *A_arbace_o2j_eval1641000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_o2j_eval1641000004_A) GetClass__Class() *jrt.Class { return A_arbace_o2j_eval1641000004_A_class }

func (t *A_arbace_o2j_eval1641000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_o2j_eval1641000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_o2j_eval1641000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_o2j_eval1641000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_o2j_eval1641000004_A); return ok }

func A_arbace_o2j_eval1641000004_A_Cast(x any) *A_arbace_o2j_eval1641000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_o2j_eval1641000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_o2j_eval1641000004_A_class)) }; return v }



type A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A struct{ j2g_header uint64 }

var A_arbace_o2j_eval1641000004_loading__1927001464__auto____1641000005_A_fn_class *jrt.Class



type A_arbace_o2j_eval1641000008_A struct{ jrt.Object }

func A_arbace_o2j_eval1641000008_A_New() *A_arbace_o2j_eval1641000008_A { t := &A_arbace_o2j_eval1641000008_A{}; t.Ctor(); return t }

func (t *A_arbace_o2j_eval1641000008_A) Ctor() {}

func (t *A_arbace_o2j_eval1641000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_o2j_eval1641000008_A) GetClass__Class() *jrt.Class { return A_arbace_o2j_eval1641000008_A_class }

func (t *A_arbace_o2j_eval1641000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_o2j_eval1641000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_o2j_eval1641000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_o2j_eval1641000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_o2j_eval1641000008_A); return ok }

func A_arbace_o2j_eval1641000008_A_Cast(x any) *A_arbace_o2j_eval1641000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_o2j_eval1641000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_o2j_eval1641000008_A_class)) }; return v }



type A_arbace_o2j_eval1641000008_fn__1641000009_A struct{ j2g_header uint64 }

var A_arbace_o2j_eval1641000008_fn__1641000009_A_fn_class *jrt.Class



type A_arbace_o2j_expr_A struct{ j2g_header uint64 }

var A_arbace_o2j_expr_A_fn_class *jrt.Class



type A_arbace_o2j_expr_fn__1641000416_A struct{ j2g_header uint64 }

var A_arbace_o2j_expr_fn__1641000416_A_fn_class *jrt.Class



type A_arbace_o2j_expr_fn__1641000418_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_o2j_expr_fn__1641000418_A_fn_class *jrt.Class



type A_arbace_o2j_expr_fn__1641000420_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_o2j_expr_fn__1641000420_A_fn_class *jrt.Class



type A_arbace_o2j_external_A struct{ j2g_header uint64 }

var A_arbace_o2j_external_A_fn_class *jrt.Class



type A_arbace_o2j_flatten_seq_A struct{ j2g_header uint64 }

var A_arbace_o2j_flatten_seq_A_fn_class *jrt.Class



type A_arbace_o2j_for_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_for_node_A_fn_class *jrt.Class



type A_arbace_o2j_free_ids_A struct{ j2g_header uint64 }

var A_arbace_o2j_free_ids_A_fn_class *jrt.Class



type A_arbace_o2j_fresh_A struct{ j2g_header uint64 }

var A_arbace_o2j_fresh_A_fn_class *jrt.Class



type A_arbace_o2j_function_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_function_node_A_fn_class *jrt.Class



type A_arbace_o2j_function_node_fn__1641000238_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_o2j_function_node_fn__1641000238_A_fn_class *jrt.Class



type A_arbace_o2j_global_name_A struct{ j2g_header uint64 }

var A_arbace_o2j_global_name_A_fn_class *jrt.Class



type A_arbace_o2j_hd_A struct{ j2g_header uint64 }

var A_arbace_o2j_hd_A_fn_class *jrt.Class



type A_arbace_o2j_latin1_A struct{ j2g_header uint64 }

var A_arbace_o2j_latin1_A_fn_class *jrt.Class



type A_arbace_o2j_latin1_fn__1641000065_A struct{ j2g_header uint64 }

var A_arbace_o2j_latin1_fn__1641000065_A_fn_class *jrt.Class



type A_arbace_o2j_let_chain_A struct{ j2g_header uint64 }

var A_arbace_o2j_let_chain_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_letrec_node_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_fn__1641000279_A struct{ j2g_header uint64; F_ctx2, F_syms, F_idset any }

var A_arbace_o2j_letrec_node_fn__1641000279_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A struct{ j2g_header uint64; F_ctx2, F_idset any }

var A_arbace_o2j_letrec_node_fn__1641000279_fn__1641000283_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A struct{ j2g_header uint64 }

var A_arbace_o2j_letrec_node_iter__1641000246__1641000250_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A struct{ j2g_header uint64; F_s__1641000247, F_iter__1641000246 any }

var A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A struct{ j2g_header uint64; F_b__1641000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_letrec_node_iter__1641000246__1641000250_fn__1641000251_fn__1641000252_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A struct{ j2g_header uint64; F_ctx2 any }

var A_arbace_o2j_letrec_node_iter__1641000256__1641000260_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A struct{ j2g_header uint64; F_ctx2, F_s__1641000257, F_iter__1641000256 any }

var A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A struct{ j2g_header uint64; F_ctx2, F_b__1641000259 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_letrec_node_iter__1641000256__1641000260_fn__1641000261_fn__1641000262_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A struct{ j2g_header uint64; F_syms, F_idset any }

var A_arbace_o2j_letrec_node_iter__1641000286__1641000292_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A struct{ j2g_header uint64; F_syms, F_s__1641000287, F_iter__1641000286, F_idset any }

var A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A struct{ j2g_header uint64; F_syms, F_id, F_idset any }

var A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A struct{ j2g_header uint64; F_syms, F_id, F_s__1641000289, F_iter__1641000288, F_idset any }

var A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_A_fn_class *jrt.Class



type A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A struct{ j2g_header uint64; F_syms, F_id, F_b__1641000291 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_idset any }

var A_arbace_o2j_letrec_node_iter__1641000286__1641000292_fn__1641000293_iter__1641000288__1641000297_fn__1641000298_fn__1641000299_A_fn_class *jrt.Class



type A_arbace_o2j_link_A struct{ j2g_header uint64 }

var A_arbace_o2j_link_A_fn_class *jrt.Class



type A_arbace_o2j_link_visit__1641000477_A struct{ j2g_header uint64; F_deps, F_need, F_progs any }

var A_arbace_o2j_link_visit__1641000477_A_fn_class *jrt.Class



type A_arbace_o2j_load_externals_BANG__A struct{ j2g_header uint64 }

var A_arbace_o2j_load_externals_BANG__A_fn_class *jrt.Class



type A_arbace_o2j_lookup_A struct{ j2g_header uint64 }

var A_arbace_o2j_lookup_A_fn_class *jrt.Class



type A_arbace_o2j_main_forms_A struct{ j2g_header uint64 }

var A_arbace_o2j_main_forms_A_fn_class *jrt.Class



type A_arbace_o2j_main_forms_iter__1641000458__1641000462_A struct{ j2g_header uint64 }

var A_arbace_o2j_main_forms_iter__1641000458__1641000462_A_fn_class *jrt.Class



type A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A struct{ j2g_header uint64; F_iter__1641000458, F_s__1641000459 any }

var A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_A_fn_class *jrt.Class



type A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1641000461, F_c__1927001037__auto__ any }

var A_arbace_o2j_main_forms_iter__1641000458__1641000462_fn__1641000463_fn__1641000464_A_fn_class *jrt.Class



type A_arbace_o2j_method_for_A struct{ j2g_header uint64 }

var A_arbace_o2j_method_for_A_fn_class *jrt.Class



type A_arbace_o2j_method_for_fn__1641000194_A struct{ j2g_header uint64; F_a any }

var A_arbace_o2j_method_for_fn__1641000194_A_fn_class *jrt.Class



type A_arbace_o2j_munge_id_A struct{ j2g_header uint64 }

var A_arbace_o2j_munge_id_A_fn_class *jrt.Class



type A_arbace_o2j_node_body_A struct{ j2g_header uint64 }

var A_arbace_o2j_node_body_A_fn_class *jrt.Class



type A_arbace_o2j_note_missing_BANG__A struct{ j2g_header uint64 }

var A_arbace_o2j_note_missing_BANG__A_fn_class *jrt.Class



type A_arbace_o2j_num_arg_A struct{ j2g_header uint64 }

var A_arbace_o2j_num_arg_A_fn_class *jrt.Class



type A_arbace_o2j_parse_float_A struct{ j2g_header uint64 }

var A_arbace_o2j_parse_float_A_fn_class *jrt.Class



type A_arbace_o2j_prim_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_prim_node_A_fn_class *jrt.Class



type A_arbace_o2j_prim_node_fn__1641000331_A struct{ j2g_header uint64; F_n any }

var A_arbace_o2j_prim_node_fn__1641000331_A_fn_class *jrt.Class



type A_arbace_o2j_prim_value_A struct{ j2g_header uint64 }

var A_arbace_o2j_prim_value_A_fn_class *jrt.Class



type A_arbace_o2j_read_dump_A struct{ j2g_header uint64 }

var A_arbace_o2j_read_dump_A_fn_class *jrt.Class



type A_arbace_o2j_read_dump_fn__1641000012_A struct{ j2g_header uint64; F_r any }

var A_arbace_o2j_read_dump_fn__1641000012_A_fn_class *jrt.Class



type A_arbace_o2j_realize_A struct{ j2g_header uint64 }

var A_arbace_o2j_realize_A_fn_class *jrt.Class



type A_arbace_o2j_rt_A struct{ j2g_header uint64 }

var A_arbace_o2j_rt_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_A struct{ j2g_header uint64 }

var A_arbace_o2j_runtime_externals_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_fn__1641000057_A struct{ j2g_header uint64 }

var A_arbace_o2j_runtime_externals_fn__1641000057_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A struct{ j2g_header uint64 }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A struct{ j2g_header uint64; F_iter__1641000029, F_s__1641000030 any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A struct{ j2g_header uint64; F_r any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A struct{ j2g_header uint64 }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000050_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A struct{ j2g_header uint64; F_r any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_fn__1641000049_fn__1641000052_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A struct{ j2g_header uint64 }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A struct{ j2g_header uint64; F_s__1641000032, F_iter__1641000031 any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A struct{ j2g_header uint64; F_cls any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A struct{ j2g_header uint64; F_cls, F_s__1641000034, F_iter__1641000033 any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_A_fn_class *jrt.Class



type A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A struct{ j2g_header uint64; F_b__1641000036, F_cls any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_runtime_externals_iter__1641000029__1641000037_fn__1641000038_iter__1641000031__1641000039_fn__1641000040_iter__1641000033__1641000041_fn__1641000042_fn__1641000043_A_fn_class *jrt.Class



type A_arbace_o2j_simple_QMARK__A struct{ j2g_header uint64 }

var A_arbace_o2j_simple_QMARK__A_fn_class *jrt.Class



type A_arbace_o2j_staticcatch_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticcatch_node_A_fn_class *jrt.Class



type A_arbace_o2j_staticcatch_node_fn__1641000382_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticcatch_node_fn__1641000382_A_fn_class *jrt.Class



type A_arbace_o2j_staticcatch_node_fn__1641000384_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticcatch_node_fn__1641000384_A_fn_class *jrt.Class



type A_arbace_o2j_staticraise_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticraise_node_A_fn_class *jrt.Class



type A_arbace_o2j_staticraise_node_fn__1641000393_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticraise_node_fn__1641000393_A_fn_class *jrt.Class



type A_arbace_o2j_staticraise_node_fn__1641000395_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_o2j_staticraise_node_fn__1641000395_A_fn_class *jrt.Class



type A_arbace_o2j_staticraise_node_fn__1641000397_A struct{ j2g_header uint64 }

var A_arbace_o2j_staticraise_node_fn__1641000397_A_fn_class *jrt.Class



type A_arbace_o2j_stringswitch_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_stringswitch_node_A_fn_class *jrt.Class



type A_arbace_o2j_stringswitch_node_fn__1641000369_A struct{ j2g_header uint64; F_ctx, F_tail_QMARK_ any }

var A_arbace_o2j_stringswitch_node_fn__1641000369_A_fn_class *jrt.Class



type A_arbace_o2j_switch_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_switch_node_A_fn_class *jrt.Class



type A_arbace_o2j_switch_node_cases__1641000355_A struct{ j2g_header uint64; F_ctx, F_tail_QMARK_ any }

var A_arbace_o2j_switch_node_cases__1641000355_A_fn_class *jrt.Class



type A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A struct{ j2g_header uint64; F_ctx, F_tail_QMARK_ any }

var A_arbace_o2j_switch_node_cases__1641000355_fn__1641000357_A_fn_class *jrt.Class



type A_arbace_o2j_test_form_A struct{ j2g_header uint64 }

var A_arbace_o2j_test_form_A_fn_class *jrt.Class



type A_arbace_o2j_test_form_fn__1641000343_A struct{ j2g_header uint64; F_n any }

var A_arbace_o2j_test_form_fn__1641000343_A_fn_class *jrt.Class



type A_arbace_o2j_test_form_fn__1641000348_A struct{ j2g_header uint64; F_n any }

var A_arbace_o2j_test_form_fn__1641000348_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_A struct{ j2g_header uint64 }

var A_arbace_o2j_translate_program_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_fn__1641000487_A struct{ j2g_header uint64 }

var A_arbace_o2j_translate_program_fn__1641000487_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000519__1641000523_A struct{ j2g_header uint64; F_lo any }

var A_arbace_o2j_translate_program_iter__1641000519__1641000523_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A struct{ j2g_header uint64; F_lo, F_iter__1641000519, F_s__1641000520 any }

var A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A struct{ j2g_header uint64; F_lo, F_b__1641000522 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_translate_program_iter__1641000519__1641000523_fn__1641000524_fn__1641000525_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000529__1641000533_A struct{ j2g_header uint64; F_od any }

var A_arbace_o2j_translate_program_iter__1641000529__1641000533_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A struct{ j2g_header uint64; F_iter__1641000529, F_od, F_s__1641000530 any }

var A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_A_fn_class *jrt.Class



type A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A struct{ j2g_header uint64; F_b__1641000532, F_od any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_translate_program_iter__1641000529__1641000533_fn__1641000534_fn__1641000535_A_fn_class *jrt.Class



type A_arbace_o2j_translate_unit_A struct{ j2g_header uint64 }

var A_arbace_o2j_translate_unit_A_fn_class *jrt.Class



type A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A struct{ j2g_header uint64 }

var A_arbace_o2j_translate_unit_iter__1641000441__1641000445_A_fn_class *jrt.Class



type A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A struct{ j2g_header uint64; F_s__1641000442, F_iter__1641000441 any }

var A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_A_fn_class *jrt.Class



type A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A struct{ j2g_header uint64; F_b__1641000444 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_translate_unit_iter__1641000441__1641000445_fn__1641000446_fn__1641000447_A_fn_class *jrt.Class



type A_arbace_o2j_trywith_node_A struct{ j2g_header uint64 }

var A_arbace_o2j_trywith_node_A_fn_class *jrt.Class



type A_arbace_o2j_unit_class_A struct{ j2g_header uint64 }

var A_arbace_o2j_unit_class_A_fn_class *jrt.Class



type A_arbace_o2j_unit_refs_A struct{ j2g_header uint64 }

var A_arbace_o2j_unit_refs_A_fn_class *jrt.Class



type A_arbace_o2j_unit_refs_walk__1641000474_A struct{ j2g_header uint64; F_acc any }

var A_arbace_o2j_unit_refs_walk__1641000474_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_A struct{ j2g_header uint64 }

var A_arbace_o2j_with_args_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_fn__1641000165_A struct{ j2g_header uint64 }

var A_arbace_o2j_with_args_fn__1641000165_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_fn__1641000177_A struct{ j2g_header uint64; F_ctx, F_temps any }

var A_arbace_o2j_with_args_fn__1641000177_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_fn__1641000179_A struct{ j2g_header uint64; F_ctx, F_nodes, F_temps any }

var A_arbace_o2j_with_args_fn__1641000179_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_iter__1641000167__1641000171_A struct{ j2g_header uint64 }

var A_arbace_o2j_with_args_iter__1641000167__1641000171_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A struct{ j2g_header uint64; F_s__1641000168, F_iter__1641000167 any }

var A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_A_fn_class *jrt.Class



type A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A struct{ j2g_header uint64; F_b__1641000170 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_o2j_with_args_iter__1641000167__1641000171_fn__1641000172_fn__1641000173_A_fn_class *jrt.Class



type A_arbace_o2j_write_forms_A struct{ j2g_header uint64 }

var A_arbace_o2j_write_forms_A_fn_class *jrt.Class
