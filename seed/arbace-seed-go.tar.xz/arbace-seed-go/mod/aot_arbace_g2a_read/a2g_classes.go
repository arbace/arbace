//line a2g_classes.ae:1
package aot_arbace_g2a_read

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_A_New()}; return nil }

var A_arbace_g2a_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_A_new}

var A_arbace_g2a_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_A"})

func init() { i := A_arbace_g2a_read_A_class.Info(); i.IsInstance = A_arbace_g2a_read_A_InstanceOf; i.Init = A_arbace_g2a_read_A_Init; i.Table = A_arbace_g2a_read_A_members; jrt.RegisterGoType(A_arbace_g2a_read_A_class, reflect.TypeFor[A_arbace_g2a_read_A]()) }

func A_arbace_g2a_read__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__main_A_New()}; return nil }

func A_arbace_g2a_read__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read__main_A_fn_class)}; return nil }

var A_arbace_g2a_read__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read__main_A_invoke, New: A_arbace_g2a_read__main_A_new, Get: A_arbace_g2a_read__main_A_get}

var A_arbace_g2a_read__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "_main", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__main_A_class.Info(); i.IsInstance = A_arbace_g2a_read__main_A_InstanceOf; i.Init = A_arbace_g2a_read__main_A_Init; i.Table = A_arbace_g2a_read__main_A_members; jrt.RegisterGoType(A_arbace_g2a_read__main_A_class, reflect.TypeFor[A_arbace_g2a_read__main_A]()) }

func A_arbace_g2a_read__main_fn__103000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read__main_fn__103000068_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read__main_fn__103000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__main_fn__103000068_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_read__main_fn__103000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read__main_fn__103000068_A_fn_class)}; return nil }

var A_arbace_g2a_read__main_fn__103000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read__main_fn__103000068_A_invoke, New: A_arbace_g2a_read__main_fn__103000068_A_new, Get: A_arbace_g2a_read__main_fn__103000068_A_get}

var A_arbace_g2a_read__main_fn__103000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$_main$fn__103000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read__main_A_class, Simple: "fn__103000068", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000068_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__main_fn__103000068_A_class.Info(); i.IsInstance = A_arbace_g2a_read__main_fn__103000068_A_InstanceOf; i.Init = A_arbace_g2a_read__main_fn__103000068_A_Init; i.Table = A_arbace_g2a_read__main_fn__103000068_A_members; jrt.RegisterGoType(A_arbace_g2a_read__main_fn__103000068_A_class, reflect.TypeFor[A_arbace_g2a_read__main_fn__103000068_A]()) }

func A_arbace_g2a_read__main_fn__103000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read__main_fn__103000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read__main_fn__103000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__main_fn__103000074_A_New_O(args[0])}; return nil }

func A_arbace_g2a_read__main_fn__103000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read__main_fn__103000074_A_fn_class)}; return nil }

var A_arbace_g2a_read__main_fn__103000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read__main_fn__103000074_A_invoke, New: A_arbace_g2a_read__main_fn__103000074_A_new, Get: A_arbace_g2a_read__main_fn__103000074_A_get}

var A_arbace_g2a_read__main_fn__103000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$_main$fn__103000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read__main_A_class, Simple: "fn__103000074", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000074_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__main_fn__103000074_A_class.Info(); i.IsInstance = A_arbace_g2a_read__main_fn__103000074_A_InstanceOf; i.Init = A_arbace_g2a_read__main_fn__103000074_A_Init; i.Table = A_arbace_g2a_read__main_fn__103000074_A_members; jrt.RegisterGoType(A_arbace_g2a_read__main_fn__103000074_A_class, reflect.TypeFor[A_arbace_g2a_read__main_fn__103000074_A]()) }

func A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read__main_fn__103000074_fn__103000075_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_New_O(args[0])}; return nil }

func A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_fn_class)}; return nil }

var A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_invoke, New: A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_new, Get: A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_get}

var A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$_main$fn__103000074$fn__103000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read__main_fn__103000074_A_class, Simple: "fn__103000075", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000074_fn__103000075_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_class.Info(); i.IsInstance = A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_InstanceOf; i.Init = A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_Init; i.Table = A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_members; jrt.RegisterGoType(A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_class, reflect.TypeFor[A_arbace_g2a_read__main_fn__103000074_fn__103000075_A]()) }

func A_arbace_g2a_read__main_fn__103000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read__main_fn__103000078_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read__main_fn__103000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__main_fn__103000078_A_New()}; return nil }

func A_arbace_g2a_read__main_fn__103000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read__main_fn__103000078_A_fn_class)}; return nil }

var A_arbace_g2a_read__main_fn__103000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read__main_fn__103000078_A_invoke, New: A_arbace_g2a_read__main_fn__103000078_A_new, Get: A_arbace_g2a_read__main_fn__103000078_A_get}

var A_arbace_g2a_read__main_fn__103000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$_main$fn__103000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read__main_A_class, Simple: "fn__103000078", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000078_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__main_fn__103000078_A_class.Info(); i.IsInstance = A_arbace_g2a_read__main_fn__103000078_A_InstanceOf; i.Init = A_arbace_g2a_read__main_fn__103000078_A_Init; i.Table = A_arbace_g2a_read__main_fn__103000078_A_members; jrt.RegisterGoType(A_arbace_g2a_read__main_fn__103000078_A_class, reflect.TypeFor[A_arbace_g2a_read__main_fn__103000078_A]()) }

func A_arbace_g2a_read_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_check_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_check_A_New()}; return nil }

func A_arbace_g2a_read_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_check_A_fn_class)}; return nil }

var A_arbace_g2a_read_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_check_A_invoke, New: A_arbace_g2a_read_check_A_new, Get: A_arbace_g2a_read_check_A_get}

var A_arbace_g2a_read_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "check", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_check_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_check_A_class.Info(); i.IsInstance = A_arbace_g2a_read_check_A_InstanceOf; i.Init = A_arbace_g2a_read_check_A_Init; i.Table = A_arbace_g2a_read_check_A_members; jrt.RegisterGoType(A_arbace_g2a_read_check_A_class, reflect.TypeFor[A_arbace_g2a_read_check_A]()) }

func A_arbace_g2a_read_check_type_table_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_check_type_table_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_check_type_table_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_check_type_table_A_New()}; return nil }

func A_arbace_g2a_read_check_type_table_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_check_type_table_A_fn_class)}; return nil }

var A_arbace_g2a_read_check_type_table_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_check_type_table_A_invoke, New: A_arbace_g2a_read_check_type_table_A_new, Get: A_arbace_g2a_read_check_type_table_A_get}

var A_arbace_g2a_read_check_type_table_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$check_type_table", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "check_type_table", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_check_type_table_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_check_type_table_A_class.Info(); i.IsInstance = A_arbace_g2a_read_check_type_table_A_InstanceOf; i.Init = A_arbace_g2a_read_check_type_table_A_Init; i.Table = A_arbace_g2a_read_check_type_table_A_members; jrt.RegisterGoType(A_arbace_g2a_read_check_type_table_A_class, reflect.TypeFor[A_arbace_g2a_read_check_type_table_A]()) }

func A_arbace_g2a_read_dump_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_dump_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_A_New()}; return nil }

func A_arbace_g2a_read_dump_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_A_invoke, New: A_arbace_g2a_read_dump_files_A_new, Get: A_arbace_g2a_read_dump_files_A_get}

var A_arbace_g2a_read_dump_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "dump_files", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_A_Init; i.Table = A_arbace_g2a_read_dump_files_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_A]()) }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_iter__103000039__103000045_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_New()}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_invoke, New: A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_new, Get: A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_get}

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files$iter__103000039__103000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_dump_files_A_class, Simple: "iter__103000039__103000045", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_Init; i.Table = A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_iter__103000039__103000045_A]()) }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_invoke, New: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_new, Get: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_get}

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class, Simple: "fn__103000046", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_Init; i.Table = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A]()) }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_New()}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_invoke, New: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_new, Get: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_get}

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class, Simple: "iter__103000041__103000047", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_Init; i.Table = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A]()) }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_invoke, New: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_new, Get: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_get}

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class, Simple: "fn__103000048", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_Init; i.Table = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A]()) }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_fn_class)}; return nil }

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_invoke, New: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_new, Get: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_get}

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048$fn__103000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class, Simple: "fn__103000049", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_class.Info(); i.IsInstance = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_InstanceOf; i.Init = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_Init; i.Table = A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_members; jrt.RegisterGoType(A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_class, reflect.TypeFor[A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A]()) }

func A_arbace_g2a_read_eval103000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000004_A_New()}; return nil }

var A_arbace_g2a_read_eval103000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_eval103000004_A_new}

var A_arbace_g2a_read_eval103000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_read_A_class, Simple: "eval103000004", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000004_A"})

func init() { i := A_arbace_g2a_read_eval103000004_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000004_A_InstanceOf; i.Table = A_arbace_g2a_read_eval103000004_A_members; jrt.RegisterGoType(A_arbace_g2a_read_eval103000004_A_class, reflect.TypeFor[A_arbace_g2a_read_eval103000004_A]()) }

func A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_New()}; return nil }

func A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_fn_class)}; return nil }

var A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_invoke, New: A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_new, Get: A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_get}

var A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000004$loading__1927001464__auto____103000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read_eval103000004_A_class, Simple: "loading__1927001464__auto____103000005", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_InstanceOf; i.Init = A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_Init; i.Table = A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_members; jrt.RegisterGoType(A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_class, reflect.TypeFor[A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A]()) }

func A_arbace_g2a_read_eval103000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000008_A_New()}; return nil }

var A_arbace_g2a_read_eval103000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_eval103000008_A_new}

var A_arbace_g2a_read_eval103000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_read_A_class, Simple: "eval103000008", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000008_A"})

func init() { i := A_arbace_g2a_read_eval103000008_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000008_A_InstanceOf; i.Table = A_arbace_g2a_read_eval103000008_A_members; jrt.RegisterGoType(A_arbace_g2a_read_eval103000008_A_class, reflect.TypeFor[A_arbace_g2a_read_eval103000008_A]()) }

func A_arbace_g2a_read_eval103000008_fn__103000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_eval103000008_fn__103000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_read_eval103000008_fn__103000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000008_fn__103000009_A_New()}; return nil }

func A_arbace_g2a_read_eval103000008_fn__103000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_eval103000008_fn__103000009_A_fn_class)}; return nil }

var A_arbace_g2a_read_eval103000008_fn__103000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_eval103000008_fn__103000009_A_invoke, New: A_arbace_g2a_read_eval103000008_fn__103000009_A_new, Get: A_arbace_g2a_read_eval103000008_fn__103000009_A_get}

var A_arbace_g2a_read_eval103000008_fn__103000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000008$fn__103000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_read_eval103000008_A_class, Simple: "fn__103000009", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000008_fn__103000009_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_eval103000008_fn__103000009_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000008_fn__103000009_A_InstanceOf; i.Init = A_arbace_g2a_read_eval103000008_fn__103000009_A_Init; i.Table = A_arbace_g2a_read_eval103000008_fn__103000009_A_members; jrt.RegisterGoType(A_arbace_g2a_read_eval103000008_fn__103000009_A_class, reflect.TypeFor[A_arbace_g2a_read_eval103000008_fn__103000009_A]()) }

func A_arbace_g2a_read_node_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_node_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_node_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_node_QMARK__A_New()}; return nil }

func A_arbace_g2a_read_node_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_node_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_read_node_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_node_QMARK__A_invoke, New: A_arbace_g2a_read_node_QMARK__A_new, Get: A_arbace_g2a_read_node_QMARK__A_get}

var A_arbace_g2a_read_node_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$node_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "node_QMARK_", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_node_QMARK__A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_node_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_read_node_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_read_node_QMARK__A_Init; i.Table = A_arbace_g2a_read_node_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_read_node_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_read_node_QMARK__A]()) }

func A_arbace_g2a_read_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_nodes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_nodes_A_New()}; return nil }

func A_arbace_g2a_read_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_nodes_A_fn_class)}; return nil }

var A_arbace_g2a_read_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_nodes_A_invoke, New: A_arbace_g2a_read_nodes_A_new, Get: A_arbace_g2a_read_nodes_A_get}

var A_arbace_g2a_read_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "nodes", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_nodes_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_nodes_A_class.Info(); i.IsInstance = A_arbace_g2a_read_nodes_A_InstanceOf; i.Init = A_arbace_g2a_read_nodes_A_Init; i.Table = A_arbace_g2a_read_nodes_A_members; jrt.RegisterGoType(A_arbace_g2a_read_nodes_A_class, reflect.TypeFor[A_arbace_g2a_read_nodes_A]()) }

func A_arbace_g2a_read_nodes_fn__103000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_nodes_fn__103000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_nodes_fn__103000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_nodes_fn__103000014_A_New()}; return nil }

func A_arbace_g2a_read_nodes_fn__103000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_nodes_fn__103000014_A_fn_class)}; return nil }

var A_arbace_g2a_read_nodes_fn__103000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_nodes_fn__103000014_A_invoke, New: A_arbace_g2a_read_nodes_fn__103000014_A_new, Get: A_arbace_g2a_read_nodes_fn__103000014_A_get}

var A_arbace_g2a_read_nodes_fn__103000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$nodes$fn__103000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_nodes_A_class, Simple: "fn__103000014", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_nodes_fn__103000014_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_nodes_fn__103000014_A_class.Info(); i.IsInstance = A_arbace_g2a_read_nodes_fn__103000014_A_InstanceOf; i.Init = A_arbace_g2a_read_nodes_fn__103000014_A_Init; i.Table = A_arbace_g2a_read_nodes_fn__103000014_A_members; jrt.RegisterGoType(A_arbace_g2a_read_nodes_fn__103000014_A_class, reflect.TypeFor[A_arbace_g2a_read_nodes_fn__103000014_A]()) }

func A_arbace_g2a_read_read_dump_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_read_dump_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_read_dump_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_read_dump_A_New()}; return nil }

func A_arbace_g2a_read_read_dump_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_read_dump_A_fn_class)}; return nil }

var A_arbace_g2a_read_read_dump_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_read_dump_A_invoke, New: A_arbace_g2a_read_read_dump_A_new, Get: A_arbace_g2a_read_read_dump_A_get}

var A_arbace_g2a_read_read_dump_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$read_dump", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "read_dump", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_read_dump_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_read_dump_A_class.Info(); i.IsInstance = A_arbace_g2a_read_read_dump_A_InstanceOf; i.Init = A_arbace_g2a_read_read_dump_A_Init; i.Table = A_arbace_g2a_read_read_dump_A_members; jrt.RegisterGoType(A_arbace_g2a_read_read_dump_A_class, reflect.TypeFor[A_arbace_g2a_read_read_dump_A]()) }

func A_arbace_g2a_read_summary_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_summary_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_summary_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_summary_A_New()}; return nil }

func A_arbace_g2a_read_summary_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_summary_A_fn_class)}; return nil }

var A_arbace_g2a_read_summary_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_summary_A_invoke, New: A_arbace_g2a_read_summary_A_new, Get: A_arbace_g2a_read_summary_A_get}

var A_arbace_g2a_read_summary_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$summary", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "summary", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_summary_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_summary_A_class.Info(); i.IsInstance = A_arbace_g2a_read_summary_A_InstanceOf; i.Init = A_arbace_g2a_read_summary_A_Init; i.Table = A_arbace_g2a_read_summary_A_members; jrt.RegisterGoType(A_arbace_g2a_read_summary_A_class, reflect.TypeFor[A_arbace_g2a_read_summary_A]()) }

func A_arbace_g2a_read_type_entry_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_type_entry_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_read_type_entry_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_type_entry_A_New()}; return nil }

func A_arbace_g2a_read_type_entry_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_type_entry_A_fn_class)}; return nil }

var A_arbace_g2a_read_type_entry_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_type_entry_A_invoke, New: A_arbace_g2a_read_type_entry_A_new, Get: A_arbace_g2a_read_type_entry_A_get}

var A_arbace_g2a_read_type_entry_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$type_entry", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "type_entry", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_type_entry_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_type_entry_A_class.Info(); i.IsInstance = A_arbace_g2a_read_type_entry_A_InstanceOf; i.Init = A_arbace_g2a_read_type_entry_A_Init; i.Table = A_arbace_g2a_read_type_entry_A_members; jrt.RegisterGoType(A_arbace_g2a_read_type_entry_A_class, reflect.TypeFor[A_arbace_g2a_read_type_entry_A]()) }

func A_arbace_g2a_read_type_refs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_read_type_refs_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_read_type_refs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_type_refs_A_New()}; return nil }

func A_arbace_g2a_read_type_refs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_read_type_refs_A_fn_class)}; return nil }

var A_arbace_g2a_read_type_refs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_read_type_refs_A_invoke, New: A_arbace_g2a_read_type_refs_A_new, Get: A_arbace_g2a_read_type_refs_A_get}

var A_arbace_g2a_read_type_refs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$type_refs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_read_A_class, Simple: "type_refs", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_type_refs_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read_type_refs_A_class.Info(); i.IsInstance = A_arbace_g2a_read_type_refs_A_InstanceOf; i.Init = A_arbace_g2a_read_type_refs_A_Init; i.Table = A_arbace_g2a_read_type_refs_A_members; jrt.RegisterGoType(A_arbace_g2a_read_type_refs_A_class, reflect.TypeFor[A_arbace_g2a_read_type_refs_A]()) }

func A_arbace_g2a_read__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_read__init_A_Load__O(); case 1: return A_arbace_g2a_read__init_A_Unit0__O(); case 2: return A_arbace_g2a_read__init_A_Unit1__O(); case 3: return A_arbace_g2a_read__init_A_Unit10__O(); case 4: return A_arbace_g2a_read__init_A_Unit11__O(); case 5: return A_arbace_g2a_read__init_A_Unit12__O(); case 6: return A_arbace_g2a_read__init_A_Unit13__O(); case 7: return A_arbace_g2a_read__init_A_Unit2__O(); case 8: return A_arbace_g2a_read__init_A_Unit3__O(); case 9: return A_arbace_g2a_read__init_A_Unit4__O(); case 10: return A_arbace_g2a_read__init_A_Unit5__O(); case 11: return A_arbace_g2a_read__init_A_Unit6__O(); case 12: return A_arbace_g2a_read__init_A_Unit7__O(); case 13: return A_arbace_g2a_read__init_A_Unit8__O(); case 14: return A_arbace_g2a_read__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_read__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__init_A_New()}; return nil }

var A_arbace_g2a_read__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_read__init_A_invoke, New: A_arbace_g2a_read__init_A_new}

var A_arbace_g2a_read__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__init_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__init_A_class.Info(); i.IsInstance = A_arbace_g2a_read__init_A_InstanceOf; i.Init = A_arbace_g2a_read__init_A_Init; i.Table = A_arbace_g2a_read__init_A_members; jrt.RegisterGoType(A_arbace_g2a_read__init_A_class, reflect.TypeFor[A_arbace_g2a_read__init_A]()) }
