//line a2g_classes.ae:1
package aot_arbace_g2a_read

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_read__main_A_class, Name: "arbace.g2a.read$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read__main_fn__103000068_A_class, Name: "arbace.g2a.read$_main$fn__103000068", Modifiers: 25, Simple: "fn__103000068", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000068_A", Source: "read.ae", Declaring: &A_arbace_g2a_read__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read__main_fn__103000074_A_class, Name: "arbace.g2a.read$_main$fn__103000074", Modifiers: 25, Simple: "fn__103000074", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000074_A", Source: "read.ae", Declaring: &A_arbace_g2a_read__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_class, Name: "arbace.g2a.read$_main$fn__103000074$fn__103000075", Modifiers: 25, Simple: "fn__103000075", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000074_fn__103000075_A", Source: "read.ae", Declaring: &A_arbace_g2a_read__main_fn__103000074_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read__main_fn__103000078_A_class, Name: "arbace.g2a.read$_main$fn__103000078", Modifiers: 25, Simple: "fn__103000078", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__main_fn__103000078_A", Source: "read.ae", Declaring: &A_arbace_g2a_read__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_check_A_class, Name: "arbace.g2a.read$check", Modifiers: 25, Simple: "check", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_check_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_check_type_table_A_class, Name: "arbace.g2a.read$check_type_table", Modifiers: 25, Simple: "check_type_table", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_check_type_table_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_A_class, Name: "arbace.g2a.read$dump_files", Modifiers: 25, Simple: "dump_files", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class, Name: "arbace.g2a.read$dump_files$iter__103000039__103000045", Modifiers: 25, Simple: "iter__103000039__103000045", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_dump_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class, Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046", Modifiers: 25, Simple: "fn__103000046", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class, Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047", Modifiers: 25, Simple: "iter__103000041__103000047", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class, Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048", Modifiers: 25, Simple: "fn__103000048", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_class, Name: "arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048$fn__103000049", Modifiers: 25, Simple: "fn__103000049", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_class, Name: "arbace.g2a.read$eval103000004$loading__1927001464__auto____103000005", Modifiers: 25, Simple: "loading__1927001464__auto____103000005", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_eval103000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_eval103000008_fn__103000009_A_class, Name: "arbace.g2a.read$eval103000008$fn__103000009", Modifiers: 25, Simple: "fn__103000009", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000008_fn__103000009_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_eval103000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_node_QMARK__A_class, Name: "arbace.g2a.read$node_QMARK_", Modifiers: 25, Simple: "node_QMARK_", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_node_QMARK__A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_nodes_A_class, Name: "arbace.g2a.read$nodes", Modifiers: 25, Simple: "nodes", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_nodes_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_nodes_fn__103000014_A_class, Name: "arbace.g2a.read$nodes$fn__103000014", Modifiers: 25, Simple: "fn__103000014", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_nodes_fn__103000014_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_nodes_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_read_dump_A_class, Name: "arbace.g2a.read$read_dump", Modifiers: 25, Simple: "read_dump", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_read_dump_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_summary_A_class, Name: "arbace.g2a.read$summary", Modifiers: 25, Simple: "summary", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_summary_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_type_entry_A_class, Name: "arbace.g2a.read$type_entry", Modifiers: 25, Simple: "type_entry", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_type_entry_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_read_type_refs_A_class, Name: "arbace.g2a.read$type_refs", Modifiers: 25, Simple: "type_refs", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_type_refs_A", Source: "read.ae", Declaring: &A_arbace_g2a_read_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_A_New()}; return nil }

var A_arbace_g2a_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_A_new}

var A_arbace_g2a_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_A"})

func init() { i := A_arbace_g2a_read_A_class.Info(); i.IsInstance = A_arbace_g2a_read_A_InstanceOf; i.Init = A_arbace_g2a_read_A_Init; i.Table = A_arbace_g2a_read_A_members }

var A_arbace_g2a_read__main_A_class *jrt.Class

var A_arbace_g2a_read__main_fn__103000068_A_class *jrt.Class

var A_arbace_g2a_read__main_fn__103000074_A_class *jrt.Class

var A_arbace_g2a_read__main_fn__103000074_fn__103000075_A_class *jrt.Class

var A_arbace_g2a_read__main_fn__103000078_A_class *jrt.Class

var A_arbace_g2a_read_check_A_class *jrt.Class

var A_arbace_g2a_read_check_type_table_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_A_class *jrt.Class

var A_arbace_g2a_read_dump_files_iter__103000039__103000045_fn__103000046_iter__103000041__103000047_fn__103000048_fn__103000049_A_class *jrt.Class

func A_arbace_g2a_read_eval103000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000004_A_New()}; return nil }

var A_arbace_g2a_read_eval103000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_eval103000004_A_new}

var A_arbace_g2a_read_eval103000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_read_A_class, Simple: "eval103000004", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000004_A"})

func init() { i := A_arbace_g2a_read_eval103000004_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000004_A_InstanceOf; i.Table = A_arbace_g2a_read_eval103000004_A_members }

var A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_class *jrt.Class

func A_arbace_g2a_read_eval103000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read_eval103000008_A_New()}; return nil }

var A_arbace_g2a_read_eval103000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_read_eval103000008_A_new}

var A_arbace_g2a_read_eval103000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read$eval103000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_read_A_class, Simple: "eval103000008", Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read_eval103000008_A"})

func init() { i := A_arbace_g2a_read_eval103000008_A_class.Info(); i.IsInstance = A_arbace_g2a_read_eval103000008_A_InstanceOf; i.Table = A_arbace_g2a_read_eval103000008_A_members }

var A_arbace_g2a_read_eval103000008_fn__103000009_A_class *jrt.Class

var A_arbace_g2a_read_node_QMARK__A_class *jrt.Class

var A_arbace_g2a_read_nodes_A_class *jrt.Class

var A_arbace_g2a_read_nodes_fn__103000014_A_class *jrt.Class

var A_arbace_g2a_read_read_dump_A_class *jrt.Class

var A_arbace_g2a_read_summary_A_class *jrt.Class

var A_arbace_g2a_read_type_entry_A_class *jrt.Class

var A_arbace_g2a_read_type_refs_A_class *jrt.Class

func A_arbace_g2a_read__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_read__init_A_Load__O()}; return nil }

func A_arbace_g2a_read__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_read__init_A_New()}; return nil }

var A_arbace_g2a_read__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_read__init_A_invoke, New: A_arbace_g2a_read__init_A_new}

var A_arbace_g2a_read__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.read__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_read.A_arbace_g2a_read__init_A", Source: "read.ae"})

func init() { i := A_arbace_g2a_read__init_A_class.Info(); i.IsInstance = A_arbace_g2a_read__init_A_InstanceOf; i.Init = A_arbace_g2a_read__init_A_Init; i.Table = A_arbace_g2a_read__init_A_members }
