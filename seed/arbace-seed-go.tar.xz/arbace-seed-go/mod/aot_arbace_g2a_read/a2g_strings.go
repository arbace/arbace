//line a2g_strings.ae:1
package aot_arbace_g2a_read

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.read")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Reads the dumps of g2a's front end helper (tools/godump, doc/go/HELPER-NOTES.md) with\n  Arbace's reader into data.\n\n  bin/g2a read [--jobs N] [--quiet] FILE|DIR...\n    Reads each dump (DIRs: every .edn below them) with arbace.core/read and *read-eval*\n    false, and prints per dump the time and a summary: files, nodes, annotated nodes, type\n    errors, named types, directives and type table entries. Exits 1 if a dump does not read\n    as one form, or if its type table is not in dependency order (check-type-table).")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("read")

var Lit_14 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_15 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_16 *jrt.String = jrt.Intern("hash-map")

var Lit_17 *jrt.String = jrt.Intern("*read-eval*")

var Lit_18 *jrt.String = jrt.Intern("ex-info")

var Lit_19 *jrt.String = jrt.Intern("path")

var Lit_20 *jrt.String = jrt.Intern("seq?")

var Lit_21 *jrt.String = jrt.Intern("keyword?")

var Lit_22 *jrt.String = jrt.Intern("map?")

var Lit_23 *jrt.String = jrt.Intern("nnext")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("second")

var Lit_26 *jrt.String = jrt.Intern("filter")

var Lit_27 *jrt.String = jrt.Intern("node?")

var Lit_28 *jrt.String = jrt.Intern("tree-seq")

var Lit_29 *jrt.String = jrt.Intern("coll?")

var Lit_30 *jrt.String = jrt.Intern("vals")

var Lit_31 *jrt.String = jrt.Intern("seq")

var Lit_32 *jrt.String = jrt.Intern("type-table")

var Lit_33 *jrt.String = jrt.Intern("concat")

var Lit_34 *jrt.String = jrt.Intern("keep")

var Lit_35 *jrt.String = jrt.Intern("args")

var Lit_36 *jrt.String = jrt.Intern("embeddeds")

var Lit_37 *jrt.String = jrt.Intern("map")

var Lit_38 *jrt.String = jrt.Intern("mapcat")

var Lit_39 *jrt.String = jrt.Intern("elem")

var Lit_40 *jrt.String = jrt.Intern("key")

var Lit_41 *jrt.String = jrt.Intern("origin")

var Lit_42 *jrt.String = jrt.Intern("actual")

var Lit_43 *jrt.String = jrt.Intern("t")

var Lit_44 *jrt.String = jrt.Intern("params")

var Lit_45 *jrt.String = jrt.Intern("results")

var Lit_46 *jrt.String = jrt.Intern("fields")

var Lit_47 *jrt.String = jrt.Intern("methods")

var Lit_48 *jrt.String = jrt.Intern("terms")

var Lit_49 *jrt.String = jrt.Intern("vars")

var Lit_50 *jrt.String = jrt.Intern("juxt")

var Lit_51 *jrt.String = jrt.Intern("type-params")

var Lit_52 *jrt.String = jrt.Intern("constraint")

var Lit_53 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_54 *jrt.String = jrt.Intern("chunk-first")

var Lit_55 *jrt.String = jrt.Intern("map-indexed")

var Lit_56 *jrt.String = jrt.Intern("vector")

var Lit_57 *jrt.String = jrt.Intern("kind")

var Lit_58 *jrt.String = jrt.Intern("pr-str")

var Lit_59 *jrt.String = jrt.Intern("id")

var Lit_60 *jrt.String = jrt.Intern("type-refs")

var Lit_61 *jrt.String = jrt.Intern("int?")

var Lit_62 *jrt.String = jrt.Intern("ref")

var Lit_63 *jrt.String = jrt.Intern("chunk-rest")

var Lit_64 *jrt.String = jrt.Intern("next")

var Lit_65 *jrt.String = jrt.Intern("package")

var Lit_66 *jrt.String = jrt.Intern("files")

var Lit_67 *jrt.String = jrt.Intern("nodes")

var Lit_68 *jrt.String = jrt.Intern("annotated")

var Lit_69 *jrt.String = jrt.Intern("errors")

var Lit_70 *jrt.String = jrt.Intern("types")

var Lit_71 *jrt.String = jrt.Intern("directives")

var Lit_72 *jrt.String = jrt.Intern("type-entries")

var Lit_73 *jrt.String = jrt.Intern("comp")

var Lit_74 *jrt.String = jrt.Intern("ast")

var Lit_75 *jrt.String = jrt.Intern("meta")

var Lit_76 *jrt.String = jrt.Intern("sort")

var Lit_77 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_78 *jrt.String = jrt.Intern("ends-with?")

var Lit_79 *jrt.String = jrt.Intern("chunk-append")

var Lit_80 *jrt.String = jrt.Intern("chunk-cons")

var Lit_81 *jrt.String = jrt.Intern("cons")

var Lit_82 *jrt.String = jrt.Intern("chunk")

var Lit_83 *jrt.String = jrt.Intern("rest")

var Lit_84 *jrt.String = jrt.Intern("file-seq")

var Lit_85 *jrt.String = jrt.Intern("check-type-table")

var Lit_86 *jrt.String = jrt.Intern("assoc")

var Lit_87 *jrt.String = jrt.Intern("read-dump")

var Lit_88 *jrt.String = jrt.Intern("summary")

var Lit_89 *jrt.String = jrt.Intern("ms")

var Lit_90 *jrt.String = jrt.Intern("bytes")

var Lit_91 *jrt.String = jrt.Intern("fail")

var Lit_92 *jrt.String = jrt.Intern("class")

var Lit_93 *jrt.String = jrt.Intern("jobs")

var Lit_94 *jrt.String = jrt.Intern("quiet")

var Lit_95 *jrt.String = jrt.Intern("parse-long")

var Lit_96 *jrt.String = jrt.Intern("dump-files")

var Lit_97 *jrt.String = jrt.Intern("mapv")

var Lit_98 *jrt.String = jrt.Intern("remove")

var Lit_99 *jrt.String = jrt.Intern("check")

var Lit_100 *jrt.String = jrt.Intern("tag")

var Lit_101 *jrt.String = jrt.Intern("java.util.concurrent.Callable")

var Lit_102 *jrt.String = jrt.Intern("println")

var Lit_103 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_104 *jrt.String = jrt.Intern("not")

var Lit_105 *jrt.String = jrt.Intern("format")

var Lit_106 *jrt.String = jrt.Intern("reduce")

var Lit_107 *jrt.String = jrt.Intern("+")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.read$_main")

var Lit_109 *jrt.String = jrt.Intern("FAIL")

var Lit_110 *jrt.String = jrt.Intern("%s: %s, %d files, %d nodes (%d annotated), %d errors, %d types, %d directives, %d type entries, %.1f MB, read in %.0f ms")

var Lit_111 *jrt.String = jrt.Intern("read %d of %d dumps (%.1f MB, %d nodes, %d type entries, %d type errors) in %.1f s with %d threads; %d failed")

var Lit_112 *jrt.String = jrt.Intern("arbace.g2a.read$_main$fn__103000068")

var Lit_113 *jrt.String = jrt.Intern("--quiet")

var Lit_114 *jrt.String = jrt.Intern("--jobs")

var Lit_115 *jrt.String = jrt.Intern("arbace.g2a.read$_main$fn__103000074")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.read$_main$fn__103000074$fn__103000075")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.read$_main$fn__103000078")

var Lit_118 *jrt.String = jrt.Intern("arbace.g2a.read$check")

var Lit_119 *jrt.String = jrt.Intern(": ")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.read$check_type_table")

var Lit_121 *jrt.String = jrt.Intern("type ")

var Lit_122 *jrt.String = jrt.Intern(": not an entry: ")

var Lit_123 *jrt.String = jrt.Intern(" refers to ")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files$iter__103000039__103000045")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048")

var Lit_129 *jrt.String = jrt.Intern(".edn")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.read$dump_files$iter__103000039__103000045$fn__103000046$iter__103000041__103000047$fn__103000048$fn__103000049")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.read$eval103000004$loading__1927001464__auto____103000005")

var Lit_132 *jrt.String = jrt.Intern("java.io.File")

var Lit_133 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_134 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_135 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_136 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_137 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_138 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.read$eval103000008$fn__103000009")

var Lit_140 *jrt.String = jrt.Intern("arbace.g2a.read$node_QMARK_")

var Lit_141 *jrt.String = jrt.Intern("arbace.g2a.read$nodes")

var Lit_142 *jrt.String = jrt.Intern("arbace.g2a.read$nodes$fn__103000014")

var Lit_143 *jrt.String = jrt.Intern("arbace.g2a.read$read_dump")

var Lit_144 *jrt.String = jrt.Intern(": empty dump")

var Lit_145 *jrt.String = jrt.Intern(": more than one form")

var Lit_146 *jrt.String = jrt.Intern("arbace.g2a.read$summary")

var Lit_147 *jrt.String = jrt.Intern("arbace.g2a.read$type_entry")

var Lit_148 *jrt.String = jrt.Intern("arbace.g2a.read$type_refs")

var Lit_149 *jrt.String = jrt.Intern("in-ns")

var Lit_150 *jrt.String = jrt.Intern("arglists")

var Lit_151 *jrt.String = jrt.Intern("Reads the dump at path (one form) with *read-eval* false. Throws if anything but\n  whitespace and comments follows the form.")

var Lit_152 *jrt.String = jrt.Intern("line")

var Lit_153 *jrt.String = jrt.Intern("column")

var Lit_154 *jrt.String = jrt.Intern("file")

var Lit_155 *jrt.String = jrt.Intern("arbace/g2a/read.ae")

var Lit_156 *jrt.String = jrt.Intern("x")

var Lit_157 *jrt.String = jrt.Intern("A node form: (:kebab-type {fields}).")

var Lit_158 *jrt.String = jrt.Intern("tree")

var Lit_159 *jrt.String = jrt.Intern("The node forms of a tree, depth first in source order.")

var Lit_160 *jrt.String = jrt.Intern("type-entry")

var Lit_161 *jrt.String = jrt.Intern("d")

var Lit_162 *jrt.String = jrt.Intern("The entry of type id in the dump's :type-table (doc/go/HELPER-NOTES.md, \"Types\").")

var Lit_163 *jrt.String = jrt.Intern("private")

var Lit_164 *jrt.String = jrt.Intern("e")

var Lit_165 *jrt.String = jrt.Intern("The ids an entry of the type table refers to.")

var Lit_166 *jrt.String = jrt.Intern("Throws unless every entry of the dump's type table is a map with a :kind and refers only to\n  earlier entries (the table is in dependency order; named types are leaves).")

var Lit_167 *jrt.String = jrt.Intern("Counts of a dump.")

var Lit_168 *jrt.String = jrt.Intern("paths")

var Lit_169 *jrt.String = jrt.Intern("The .edn files of the paths (files, or directories searched recursively), sorted.")

var Lit_170 *jrt.String = jrt.Intern("-main")

var Lit_171 *jrt.String = jrt.Intern("&")
