//line aot_arbace_g2a_read__init.ae:1
package aot_arbace_g2a_read

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_read__init_A_Unit0__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_read__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_read__init_A_const_1) }
//line :1:1
func A_arbace_g2a_read__init_A_Unit1__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_read__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_read__init_A_Unit2__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_Init(); tmp2 = A_arbace_g2a_read_eval103000004_loading__1927001464__auto____103000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_read__init_A_Unit3__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_read__init_A_const_1)).Equals_O__Z(A_arbace_g2a_read__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_read_eval103000008_fn__103000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_read_eval103000008_fn__103000009_A_Init(); tmp2 = A_arbace_g2a_read_eval103000008_fn__103000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_read__init_A_Load__O() any { A_arbace_g2a_read__init_A_Init(); A_arbace_g2a_read__init_A_Unit0__O(); A_arbace_g2a_read__init_A_Unit1__O(); A_arbace_g2a_read__init_A_Unit2__O(); A_arbace_g2a_read__init_A_Unit3__O(); A_arbace_g2a_read__init_A_Unit4__O(); A_arbace_g2a_read__init_A_Unit5__O(); A_arbace_g2a_read__init_A_Unit6__O(); A_arbace_g2a_read__init_A_Unit7__O(); A_arbace_g2a_read__init_A_Unit8__O(); A_arbace_g2a_read__init_A_Unit9__O(); A_arbace_g2a_read__init_A_Unit10__O(); A_arbace_g2a_read__init_A_Unit11__O(); A_arbace_g2a_read__init_A_Unit12__O(); A_arbace_g2a_read__init_A_Unit13__O(); return nil }









func A_arbace_g2a_read__init_A_Unit4__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_4; var tmp2 any = A_arbace_g2a_read_read_dump_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_read_dump_A_Init(); tmp3 = A_arbace_g2a_read_read_dump_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_5)); return A_arbace_g2a_read__init_A_const_4.Ref() }















func A_arbace_g2a_read__init_A_Unit5__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_6; var tmp2 any = A_arbace_g2a_read_node_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_node_QMARK__A_Init(); tmp3 = A_arbace_g2a_read_node_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_7)); return A_arbace_g2a_read__init_A_const_6.Ref() }




func A_arbace_g2a_read__init_A_Unit6__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_8; var tmp2 any = A_arbace_g2a_read_nodes_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_nodes_A_Init(); tmp3 = A_arbace_g2a_read_nodes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_9)); return A_arbace_g2a_read__init_A_const_8.Ref() }




func A_arbace_g2a_read__init_A_Unit7__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_10; var tmp2 any = A_arbace_g2a_read_type_entry_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_type_entry_A_Init(); tmp3 = A_arbace_g2a_read_type_entry_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_11)); return A_arbace_g2a_read__init_A_const_10.Ref() }




func A_arbace_g2a_read__init_A_Unit8__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_12; var tmp2 any = A_arbace_g2a_read_type_refs_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_type_refs_A_Init(); tmp3 = A_arbace_g2a_read_type_refs_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_13)); return A_arbace_g2a_read__init_A_const_12.Ref() }







func A_arbace_g2a_read__init_A_Unit9__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(54, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_14; var tmp2 any = A_arbace_g2a_read_check_type_table_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_check_type_table_A_Init(); tmp3 = A_arbace_g2a_read_check_type_table_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_15)); return A_arbace_g2a_read__init_A_const_14.Ref() }











func A_arbace_g2a_read__init_A_Unit10__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_16; var tmp2 any = A_arbace_g2a_read_summary_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_summary_A_Init(); tmp3 = A_arbace_g2a_read_summary_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_17)); return A_arbace_g2a_read__init_A_const_16.Ref() }












func A_arbace_g2a_read__init_A_Unit11__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(79, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_18; var tmp2 any = A_arbace_g2a_read_dump_files_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_dump_files_A_Init(); tmp3 = A_arbace_g2a_read_dump_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_19)); return A_arbace_g2a_read__init_A_const_18.Ref() }







func A_arbace_g2a_read__init_A_Unit12__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_20; var tmp2 any = A_arbace_g2a_read_check_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read_check_A_Init(); tmp3 = A_arbace_g2a_read_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_21)); return A_arbace_g2a_read__init_A_const_20.Ref() }








func A_arbace_g2a_read__init_A_Unit13__O() any { A_arbace_g2a_read__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_g2a_read__init_A_const_22; var tmp2 any = A_arbace_g2a_read__main_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_read__main_A_Init(); tmp3 = A_arbace_g2a_read__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_g2a_read__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_read__init_A_const_23)); return A_arbace_g2a_read__init_A_const_22.Ref() }



type A_arbace_g2a_read__init_A struct{ jrt.Object }

var A_arbace_g2a_read__init_A_const_0 *lang.Var

var A_arbace_g2a_read__init_A_const_1 any

var A_arbace_g2a_read__init_A_const_2 any

var A_arbace_g2a_read__init_A_const_3 any

var A_arbace_g2a_read__init_A_const_4 *lang.Var

var A_arbace_g2a_read__init_A_const_5 any

var A_arbace_g2a_read__init_A_const_6 *lang.Var

var A_arbace_g2a_read__init_A_const_7 any

var A_arbace_g2a_read__init_A_const_8 *lang.Var

var A_arbace_g2a_read__init_A_const_9 any

var A_arbace_g2a_read__init_A_const_10 *lang.Var

var A_arbace_g2a_read__init_A_const_11 any

var A_arbace_g2a_read__init_A_const_12 *lang.Var

var A_arbace_g2a_read__init_A_const_13 any

var A_arbace_g2a_read__init_A_const_14 *lang.Var

var A_arbace_g2a_read__init_A_const_15 any

var A_arbace_g2a_read__init_A_const_16 *lang.Var

var A_arbace_g2a_read__init_A_const_17 any

var A_arbace_g2a_read__init_A_const_18 *lang.Var

var A_arbace_g2a_read__init_A_const_19 any

var A_arbace_g2a_read__init_A_const_20 *lang.Var

var A_arbace_g2a_read__init_A_const_21 any

var A_arbace_g2a_read__init_A_const_22 *lang.Var

var A_arbace_g2a_read__init_A_const_23 any

var A_arbace_g2a_read__init_A_init jrt.ClassInit

func A_arbace_g2a_read__init_A_Init() { if !A_arbace_g2a_read__init_A_init.Done() { A_arbace_g2a_read__init_A_init.Run(A_arbace_g2a_read__init_A_clinit) } }

func A_arbace_g2a_read__init_A_clinit() { A_arbace_g2a_read__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_149); A_arbace_g2a_read__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_g2a_read__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_g2a_read__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_read__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_87); A_arbace_g2a_read__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_151, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_g2a_read__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_156).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_157, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_9, Lit_67); A_arbace_g2a_read__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_159, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_160); A_arbace_g2a_read__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_59).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_162, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_9, Lit_60); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_read__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_165, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_9, Lit_85); A_arbace_g2a_read__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_166, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_9, Lit_88); A_arbace_g2a_read__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_167, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_9, Lit_96); A_arbace_g2a_read__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_168).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_169, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(79).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_9, Lit_99); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_read__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)); A_arbace_g2a_read__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_170); A_arbace_g2a_read__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_150).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_171).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), Lit_155)) }

func A_arbace_g2a_read__init_A_New() *A_arbace_g2a_read__init_A { A_arbace_g2a_read__init_A_Init(); t := &A_arbace_g2a_read__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_read__init_A) Ctor() {}

func (t *A_arbace_g2a_read__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_read__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_read__init_A_class }

func (t *A_arbace_g2a_read__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_read__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_read__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_read__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_read__init_A); return ok }

func A_arbace_g2a_read__init_A_Cast(x any) *A_arbace_g2a_read__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_read__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_read__init_A_class)) }; return v }
