//line j2g_strings.ae:1
package aot_arbace_c2j_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn10,arbace.setyn14,arbace.java.ioyn2,ioyn15,arbace.c2j.emityn1,ekn3,docks3,c2j4,linekn4,linekn6,columnys3,c2j4,linkkn4,elseks3,c2j5,partskn3,srckn6,loaderkn5,errorkn6,errorskn3,usekn7,requireyn5,in-nsyn2,nskn2,nsyn4,loadyn15,arbace.c2j.mainyn21,arbace.classes.nativeyn8,compiledkn5,namesyn5,quotekn7,importsyn6,importyn8,defclasskn5,formskn6,holderkn4,kindkn4,rootkn4,argskn10,param-tagskn3,tagkn2,idkn3,keykn6,callerkn10,interfaceskn8,variadickn6,linkedkn7,generickn4,namekn4,formyn6,arbacekn8,compiledkn6,failedkn7,classeskn5,linkskn18,java-forms-classesv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V1,R4,V3,R5,R2,R6,V3,R7,R2,R8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.mainm2,R9,s784,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to Java forms (arbace.c2j.emit), a tree j2g reads as one more input\n  (bin/j2g --input DIR). The back end runs as the program's compiled code when the program holds\n  it for the sources on ARBACE_PATH (compiled-back-end, SA164).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), a large Java form continued in more (aot_HOLDER.1.ae ..., form-texts,\n  SA220), and OUT/aot.edn (the sources compiled, those that failed and why).v11,arbace.core7,ex-infov11,arbace.core8,distinctv11,arbace.core3,mapv11,arbace.core8,group-byv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core4,mapvv11,arbace.core3,vecv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,concatv11,arbace.core3,setv11,arbace.core7,string?v15,arbace.c2j.emit6,destubv15,arbace.c2j.main6,eventsv11,arbace.core6,filterv11,arbace.core4,intov15,arbace.c2j.emit16,interface-recordR10,v11,arbace.core6,dissocR11,R12,v11,arbace.core5,assocv11,arbace.core9,not-emptyv11,arbace.core4,seq?R13,v15,arbace.c2j.main12,forms->listsv11,arbace.core9,vary-metav15,arbace.c2j.main6,*link*v11,arbace.core5,mergev15,arbace.c2j.main10,clean-metav11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core3,notv11,arbace.core7,vector?v11,arbace.core7,symbol?R14,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core11,*print-dup*v11,arbace.core22,*print-namespace-maps*v11,arbace.core2,prl262144,v11,arbace.core6,pr-strv15,arbace.c2j.main10,file-charsv11,arbace.core4,nextv11,arbace.core6,reducev11,arbace.core1,+l0,v11,arbace.core5,countv11,arbace.core6,vectorR15,v11,arbace.core6,symbolv11,arbace.core3,strv13,arbace.string4,joinv11,arbace.core6,secondv11,arbace.core5,rangel1,v13,arbace.string7,replacev10,arbace.set5,unionv11,arbace.core4,compv15,arbace.c2j.main14,source-classesv11,arbace.core6,removev11,arbace.core4,atomv10,arbace.set10,differencev15,arbace.c2j.main10,interfacesv11,arbace.core5,doallR16,R17,v15,arbace.c2j.emit11,emit-sourceR18,v11,arbace.core7,ex-datav11,arbace.core6,reset!v15,arbace.c2j.emit6,*link*v11,arbace.core6,empty?v11,arbace.core6,get-inR19,v11,arbace.core4,somev13,arbace.string12,starts-with?v11,arbace.core4,subsl6,v14,arbace.java.io4,filev11,arbace.core10,take-whilev11,arbace.core10,repeatedlyv11,arbace.core4,readv11,arbace.core4,takev11,arbace.core11,*read-eval*v15,arbace.c2j.main5,formsS2,R20,R21,v11,arbace.core11,sequential?v11,arbace.core4,dropl2,R22,R23,R23,v11,arbace.core6,ffirstR24,v15,arbace.c2j.main4,libsR25,v15,arbace.c2j.main11,path-sourcev15,arbace.c2j.main9,source-nsv11,arbace.core7,memoizev11,arbace.core4,keysV2,R26,R0,v15,arbace.c2j.main11,source-depsv11,arbace.core6,every?v15,arbace.c2j.main16,back-end-sourcesC16,java.util.ArraysC21,arbace.lang.Reflectorv11,arbace.core20,*warn-on-reflection*v11,arbace.core14,*data-readers*v11,arbace.core16,*unchecked-math*v11,arbace.core4,*ns*v11,arbace.core7,find-nsR27,v11,arbace.core10,ns-resolveR28,v15,arbace.c2j.main18,java-forms-recordsR29,v11,arbace.core8,not-any?v11,arbace.core9,contains?R22,R30,R31,R32,v11,arbace.core4,valsR33,R34,v13,arbace.string10,ends-with?R35,R36,v11,arbace.core6,re-seqp11,L([^;\\[]+);v11,arbace.core4,namev11,arbace.core9,namespaceR13,v11,arbace.core8,to-arrayR37,R38,v11,arbace.core4,run!R39,R40,v11,arbace.core4,peekv11,arbace.core3,popR41,R42,R43,v15,arbace.c2j.emit11,link-targetR44,v15,arbace.c2j.main8,reaches?v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core4,fnilR45,v11,arbace.core4,not=v15,arbace.c2j.main9,form-refsv15,arbace.c2j.emit9,link-formR46,R47,v11,arbace.core3,incv15,arbace.c2j.main5,unitsv15,arbace.c2j.main11,compile-allv15,arbace.c2j.emit11,class-formsv15,arbace.c2j.main18,java-forms-classesv15,arbace.c2j.main9,file-nameR48,R49,v11,arbace.core4,sortv15,arbace.c2j.emit15,unnamed-packageML2,R22,L2,R30,R50,m4,R11,i446,R12,i25,R32,v15,arbace.c2j.main12,package-namev15,arbace.c2j.main8,class-nsv15,arbace.c2j.main6,top-ofv15,arbace.c2j.main9,link-planv15,arbace.c2j.main15,java-forms-fileR51,R52,v11,arbace.core10,sorted-mapR53,R54,R55,v11,arbace.core6,mapcatv15,arbace.c2j.emit14,*late-classes*C16,java.lang.Threadv11,arbace.core9,bound-fn*v11,arbace.core8,take-nthv15,arbace.c2j.main10,form-textsv11,arbace.core11,map-indexedv14,arbace.java.io6,writerv15,arbace.c2j.main10,write-formML2,R23,R50,m4,R11,i460,R12,i24,R25,v11,arbace.core7,partialv11,arbace.core4,spitv11,arbace.core3,prnv15,arbace.c2j.main6,linkerv15,arbace.c2j.main10,*compiled*v15,arbace.c2j.main17,compiled-back-endv11,arbace.core7,var-getv15,arbace.c2j.main3,runv15,arbace.c2j.main4,run*")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000269__329000273")

var Lit_2 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000279__329000283")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000295")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000322")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000324__329000328")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298$iter__329000299__329000305")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298$iter__329000299__329000305$fn__329000306")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298$iter__329000299__329000305$fn__329000306$iter__329000301__329000307")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298$iter__329000299__329000305$fn__329000306$iter__329000301__329000307$fn__329000308")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$fn__329000298$iter__329000299__329000305$fn__329000306$iter__329000301__329000307$fn__329000308$fn__329000309")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000269__329000273$fn__329000274")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000269__329000273$fn__329000274$fn__329000275")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000279__329000283$fn__329000284")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000279__329000283$fn__329000284$fn__329000285")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000324__329000328$fn__329000329")

var Lit_17 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources$iter__329000324__329000328$fn__329000329$fn__329000330")

var Lit_18 *jrt.String = jrt.Intern("__init")

var Lit_19 *jrt.String = jrt.Intern(".")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000137__329000143")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$fn__329000157")

var Lit_22 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$fn__329000162")

var Lit_23 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000164__329000168")

var Lit_24 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000184__329000188")

var Lit_25 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000194__329000198")

var Lit_26 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000137__329000143$fn__329000144")

var Lit_27 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000137__329000143$fn__329000144$iter__329000139__329000148")

var Lit_28 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000137__329000143$fn__329000144$iter__329000139__329000148$fn__329000149")

var Lit_29 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000137__329000143$fn__329000144$iter__329000139__329000148$fn__329000149$fn__329000150")

var Lit_30 *jrt.String = jrt.Intern("proxy")

var Lit_31 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000164__329000168$fn__329000169")

var Lit_32 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000164__329000168$fn__329000169$fn__329000170")

var Lit_33 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000164__329000168$fn__329000169$fn__329000180")

var Lit_34 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000164__329000168$fn__329000169$fn__329000170$fn__329000174")

var Lit_35 *jrt.String = jrt.Intern(" ")

var Lit_36 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000184__329000188$fn__329000189")

var Lit_37 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000184__329000188$fn__329000189$fn__329000190")

var Lit_38 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000194__329000198$fn__329000199")

var Lit_39 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all$iter__329000194__329000198$fn__329000199$fn__329000200")

var Lit_40 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$fn__329000336")

var Lit_41 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$loader__329000338")

var Lit_42 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$fn__329000341")

var Lit_43 *jrt.String = jrt.Intern("/")

var Lit_44 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$fn__329000355")

var Lit_45 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$fn__329000360")

var Lit_46 *jrt.String = jrt.Intern("equals")

var Lit_47 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end$fn__329000341$fn__329000345")

var Lit_48 *jrt.String = jrt.Intern("invokeStaticMethod")

var Lit_49 *jrt.String = jrt.Intern("load")

var Lit_50 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_51 *jrt.String = jrt.Intern("arbace.c2j.main$events$iter__329000033__329000039")

var Lit_52 *jrt.String = jrt.Intern("arbace.c2j.main$events$iter__329000033__329000039$fn__329000040")

var Lit_53 *jrt.String = jrt.Intern("arbace.c2j.main$events$iter__329000033__329000039$fn__329000040$iter__329000035__329000044")

var Lit_54 *jrt.String = jrt.Intern("arbace.c2j.main$events$iter__329000033__329000039$fn__329000040$iter__329000035__329000044$fn__329000045")

var Lit_55 *jrt.String = jrt.Intern("arbace.c2j.main$events$iter__329000033__329000039$fn__329000040$iter__329000035__329000044$fn__329000045$fn__329000046")

var Lit_56 *jrt.String = jrt.Intern("aot_")

var Lit_57 *jrt.String = jrt.Intern(".ae")

var Lit_58 *jrt.String = jrt.Intern("_")

var Lit_59 *jrt.String = jrt.Intern("ARBACE_AOT_FILE_CHARS")

var Lit_60 *jrt.String = jrt.Intern("arbace.c2j.main$form_refs$sym_BANG___329000405")

var Lit_61 *jrt.String = jrt.Intern("arbace.c2j.main$form_refs$walk__329000417")

var Lit_62 *jrt.String = jrt.Intern("arbace.c2j.main$form_texts$fn__329000116")

var Lit_63 *jrt.String = jrt.Intern("arbace.c2j.main$form_texts$iter__329000124__329000128")

var Lit_64 *jrt.String = jrt.Intern("arbace.c2j.main$form_texts$iter__329000124__329000128$fn__329000129")

var Lit_65 *jrt.String = jrt.Intern("arbace.c2j.main$form_texts$iter__329000124__329000128$fn__329000129$fn__329000130")

var Lit_66 *jrt.String = jrt.Intern("UTF-8")

var Lit_67 *jrt.String = jrt.Intern("arbace.c2j.main$forms$fn__329000209")

var Lit_68 *jrt.String = jrt.Intern("arbace.c2j.main$forms$fn__329000211")

var Lit_69 *jrt.String = jrt.Intern("arbace.c2j.main$forms__GT_lists$fn__329000104")

var Lit_70 *jrt.String = jrt.Intern("arbace.c2j.main$forms__GT_lists$fn__329000106")

var Lit_71 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$fn__329000066")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$fn__329000068")

var Lit_73 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074")

var Lit_74 *jrt.String = jrt.Intern("imethod")

var Lit_75 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075")

var Lit_76 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$fn__329000076")

var Lit_77 *jrt.String = jrt.Intern("iface")

var Lit_78 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$iter__329000088__329000092")

var Lit_79 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$fn__329000076$iter__329000077__329000081")

var Lit_80 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$fn__329000076$iter__329000077__329000081$fn__329000082")

var Lit_81 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$fn__329000076$iter__329000077__329000081$fn__329000082$fn__329000083")

var Lit_82 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$iter__329000088__329000092$fn__329000093")

var Lit_83 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces$iter__329000070__329000074$fn__329000075$iter__329000088__329000092$fn__329000093$fn__329000094")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000366__329000370")

var Lit_85 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000376__329000380")

var Lit_86 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000366__329000370$fn__329000371")

var Lit_87 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000366__329000370$fn__329000371$fn__329000372")

var Lit_88 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000376__329000380$fn__329000381")

var Lit_89 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000376__329000380$fn__329000381$fn__329000382")

var Lit_90 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000376__329000380$fn__329000381$fn__329000386")

var Lit_91 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes$iter__329000376__329000380$fn__329000381$fn__329000382$fn__329000383")

var Lit_92 *jrt.String = jrt.Intern("aot_jf_")

var Lit_93 *jrt.String = jrt.Intern("$")

var Lit_94 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_file$iter__329000391__329000395")

var Lit_95 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_file$iter__329000391__329000395$fn__329000396")

var Lit_96 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_file$iter__329000391__329000395$fn__329000396$fn__329000397")

var Lit_97 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222")

var Lit_98 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223")

var Lit_99 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225")

var Lit_101 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000218__329000226")

var Lit_102 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000232__329000236")

var Lit_103 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000218__329000226$fn__329000227")

var Lit_104 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000218__329000226$fn__329000227$fn__329000228")

var Lit_105 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000232__329000236$fn__329000237")

var Lit_106 *jrt.String = jrt.Intern("arbace.c2j.main$libs$iter__329000214__329000222$fn__329000223$iter__329000216__329000224$fn__329000225$iter__329000232__329000236$fn__329000237$fn__329000238")

var Lit_107 *jrt.String = jrt.Intern("arbace.c2j.main$link_plan$iter__329000441__329000445")

var Lit_108 *jrt.String = jrt.Intern("arbace.c2j.main$link_plan$iter__329000441__329000445$fn__329000446")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.main$link_plan$iter__329000441__329000445$fn__329000446$fn__329000447")

var Lit_110 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_111 *jrt.String = jrt.Intern("arbace.c2j.main$linker$fn__329000462")

var Lit_112 *jrt.String = jrt.Intern("-")

var Lit_113 *jrt.String = jrt.Intern("ARBACE_PATH")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2j.main$path_source$fn__329000205")

var Lit_115 *jrt.String = jrt.Intern("store:")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000476")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000478__329000482")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000488__329000492")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000498__329000502")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000514__329000518")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000524")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000526__329000532")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$pkg_of_class__329000542")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000544__329000548")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000560__329000564")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000576__329000580")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000762")

var Lit_129 *jrt.String = jrt.Intern("packages.edn")

var Lit_130 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000793__329000797")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000803")

var Lit_133 *jrt.String = jrt.Intern("aot.edn")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000805")

var Lit_135 *jrt.String = jrt.Intern("arbace")

var Lit_136 *jrt.String = jrt.Intern("arbace.ae")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$fn__329000587")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$fn__329000600")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$fn__329000609")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$fn__329000757")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$fn__329000759")

var Lit_143 *jrt.String = jrt.Intern("arbace/")

var Lit_144 *jrt.String = jrt.Intern(";; Compiled by arbace.classes.native (the Java forms compiler) in ")

var Lit_145 *jrt.String = jrt.Intern(" while the program prepared it; kept by arbace.c2j. Regenerated by the build.\n\n")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000641")

var Lit_151 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000646")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000655")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000667")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000672")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000621$fn__329000622$fn__329000681")

var Lit_156 *jrt.String = jrt.Intern(";; Compiled by arbace.c2j (standalone S6)")

var Lit_157 *jrt.String = jrt.Intern(". Regenerated by the build.\n\n")

var Lit_158 *jrt.String = jrt.Intern(" from ")

var Lit_159 *jrt.String = jrt.Intern(": its loader")

var Lit_160 *jrt.String = jrt.Intern(": the classes of a namespace")

var Lit_161 *jrt.String = jrt.Intern("\n\n")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000708")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000713")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000722")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000734")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000739")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000586$iter__329000615__329000619$fn__329000620$fn__329000689$fn__329000748")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000765__329000769")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000775__329000781")

var Lit_170 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000765__329000769$fn__329000770")

var Lit_171 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000765__329000769$fn__329000770$fn__329000771")

var Lit_172 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000775__329000781$fn__329000782")

var Lit_173 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000775__329000781$fn__329000782$iter__329000777__329000783")

var Lit_174 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000775__329000781$fn__329000782$iter__329000777__329000783$fn__329000784")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$fn__329000764$iter__329000775__329000781$fn__329000782$iter__329000777__329000783$fn__329000784$fn__329000785")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000478__329000482$fn__329000483")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000478__329000482$fn__329000483$fn__329000484")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000488__329000492$fn__329000493")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000488__329000492$fn__329000493$fn__329000494")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000498__329000502$fn__329000503")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000498__329000502$fn__329000503$fn__329000504")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000514__329000518$fn__329000519")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000514__329000518$fn__329000519$fn__329000520")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000526__329000532$fn__329000533")

var Lit_185 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000526__329000532$fn__329000533$iter__329000528__329000534")

var Lit_186 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000526__329000532$fn__329000533$iter__329000528__329000534$fn__329000535")

var Lit_187 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000526__329000532$fn__329000533$iter__329000528__329000534$fn__329000535$fn__329000536")

var Lit_188 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000544__329000548$fn__329000549")

var Lit_189 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000544__329000548$fn__329000549$fn__329000550")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000560__329000564$fn__329000565")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000560__329000564$fn__329000565$fn__329000566")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000576__329000580$fn__329000581")

var Lit_193 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000576__329000580$fn__329000581$fn__329000582")

var Lit_194 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000793__329000797$fn__329000798")

var Lit_195 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_$iter__329000793__329000797$fn__329000798$fn__329000799")

var Lit_196 *jrt.String = jrt.Intern("arbace.c2j.main$source_classes$iter__329000053__329000057")

var Lit_197 *jrt.String = jrt.Intern("arbace.c2j.main$source_classes$iter__329000053__329000057$fn__329000058")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.main$source_classes$iter__329000053__329000057$fn__329000058$fn__329000059")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$fn__329000249")

var Lit_200 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$iter__329000251__329000257")

var Lit_201 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$iter__329000251__329000257$fn__329000258")

var Lit_202 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$iter__329000251__329000257$fn__329000258$iter__329000253__329000259")

var Lit_203 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$iter__329000251__329000257$fn__329000258$iter__329000253__329000259$fn__329000260")

var Lit_204 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps$iter__329000251__329000257$fn__329000258$iter__329000253__329000259$fn__329000260$fn__329000261")

var Lit_205 *jrt.String = jrt.Intern("aot: no units recorded (ARBACE_COMPILE not set)")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.main$units$fn__329000014")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.main$units$fn__329000016")

var Lit_208 *jrt.String = jrt.Intern("arbace.c2j.main$units$iter__329000018__329000022")

var Lit_209 *jrt.String = jrt.Intern("arbace.c2j.main$units$iter__329000018__329000022$fn__329000023")

var Lit_210 *jrt.String = jrt.Intern("arbace.c2j.main$units$iter__329000018__329000022$fn__329000023$fn__329000024")

var Lit_211 *jrt.String = jrt.Intern("arbace.c2j.main$units$iter__329000018__329000022$fn__329000023$fn__329000028")

var Lit_212 *jrt.String = jrt.Intern("arbace.c2j.main$units$iter__329000018__329000022$fn__329000023$fn__329000024$fn__329000025")

var Lit_213 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn4,linekn6,columnkn4,filekn7,privateyn2,ssyn1,mkn7,dynamicyn1,fyn4,linekn3,tagyn14,java.io.Writeryn6,Stringyn2,usyn4,wantyn5,bytesyn1,byn1,nyn4,formyn2,fsyn4,srcsyn5,namesyn1,ryn7,classesyn17,java.util.HashSetyn1,gyn1,ayn5,sitesyn8,fn-namesyn4,topsyn12,pkg-of-classyn4,planyn5,linksyn3,outyn7,sourcesv11,arbace.core5,in-nsMyn15,arbace.c2j.mainm2,R0,s784,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to Java forms (arbace.c2j.emit), a tree j2g reads as one more input\n  (bin/j2g --input DIR). The back end runs as the program's compiled code when the program holds\n  it for the sources on ARBACE_PATH (compiled-back-end, SA164).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), a large Java form continued in more (aot_HOLDER.1.ae ..., form-texts,\n  SA220), and OUT/aot.edn (the sources compiled, those that failed and why).m2,R0,s784,Standalone S6: compiles the namespaces the program prepared (Compiler$AST/units, recorded\n  with ARBACE_COMPILE set) to Java forms (arbace.c2j.emit), a tree j2g reads as one more input\n  (bin/j2g --input DIR). The back end runs as the program's compiled code when the program holds\n  it for the sources on ARBACE_PATH (compiled-back-end, SA164).\n\n  (run OUT SOURCES): SOURCES the source paths to compile (arbace/walk.ae ...), or nil for every\n  source recorded. Writes OUT/arbace.ae (the namespace of the classes' package, loading the\n  others), one file per loader class (aot_SCRIPTBASE__init.ae) and per holder class\n  (aot_HOLDER.ae), a large Java form continued in more (aot_HOLDER.1.ae ..., form-texts,\n  SA220), and OUT/aot.edn (the sources compiled, those that failed and why).R1,v15,arbace.c2j.main5,unitsm10,R2,L1,V0,R0,s92,The recorded units by source, in the order of their first unit: [[src [[unit um] ...]] ...].R3,i18,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main6,eventsm10,R6,TR2,L1,V1,R7,R3,i27,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main14,source-classesm12,R6,TR2,L1,V1,R7,R0,s107,The names of the classes the events of a source's units make at run time (deftypes,\n  interfaces, proxies).R3,i30,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main10,interfacesm12,R6,TR2,L1,V1,R7,R0,s95,The interfaces gen-interface made in a source's units (events iface, imethod): name →\n  record.R3,i39,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main10,clean-metam12,R6,TR2,L1,V1,R8,R0,s152,The metadata m of an emitted form for printing: the back end's line (:c2j/line) as :line;\n  the reader's positions of the back end's own source dropped.R3,i51,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main6,*link*m12,R9,TR6,TR3,i60,R4,i1,R5,s18,arbace/c2j/main.aeR0,s136,The resolution of a call site's link marker (arbace.c2j.emit's emit-link-site) into its code,\n  once every class is made (run*), or nil.v15,arbace.c2j.main12,forms->listsm12,R6,TR2,L2,V1,R10,V2,R10,R11,R0,s390,Form f with every seq a list, for printing; metadata as clean-meta leaves it, a list without\n  a line of its own given the enclosing form's (line): the Java forms' analysis gives a form\n  without one the reader's line in the printed file, and j2g lays the Go text out on the lines\n  (J2G-SPEC §4.3), so lines that went back and forth would pad it. A link marker becomes its\n  code (*link*).R3,i65,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main10,write-formm10,R6,TR2,L1,V2,Myn1,wm2,R12,R13,R10,R3,i83,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main10,file-charsm10,R6,TR3,i89,R4,i1,R5,s18,arbace/c2j/main.aeR0,s378,A top-level Java form printed longer than this many characters is written across several\n  files (SA220): j2g reads a tree's files in parallel, one reader a file, at about 2 MB/s, so\n  one large file (arbace.core's holder, 2.6 MB on one line) bounds the whole read.\n  ARBACE_AOT_FILE_CHARS sets another bound (measurements: a large one writes each Java form\n  whole, as before).v15,arbace.c2j.main10,form-textsm12,R6,TR2,L1,V1,R10,R0,s656,The texts of top-level Java form f as the tree holds it: [text], its printed form; or, past\n  file-chars, its elements in about equal parts cut before a seq element (a field, a method, a\n  member class), [main continuation...]: main the Java form with the first part and :c2j/parts\n  n in its metadata, a continuation (c2j/continue NAME k element...) for part k (1 to n), which\n  j2g appends to the Java form in that order (arbace.j2g.world/join-continued), restoring the\n  form printed whole. Each part is printed as the whole form would print it, element by element\n  (the lines are the forms' own, forms->lists's: a file's text starts on the same line).R3,i97,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main9,file-namem10,R6,TR2,L1,V1,Myn5,cnamem2,R12,R14,R3,i132,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main11,compile-allm12,R6,TR2,L1,V2,R15,R16,R0,s373,Compiles the sources of us (each [src units]) whose names are in want: their results, and the\n  classes made (name → record). A class a source's events make is a class of the program when\n  that source compiles, else made at run time (named only by reflection); a source that fails\n  makes its classes run-time ones, and the others are compiled again until none fails anew.R3,i135,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main10,*compiled*m12,R9,TR6,TR3,i168,R4,i1,R5,s18,arbace/c2j/main.aeR0,s65,True while run is the program's compiled one (compiled-back-end).v15,arbace.c2j.main11,path-sourcem12,R6,TR2,L1,MV1,Myn1,pm2,R12,R14,m2,R12,R17,R0,s169,The bytes of source path p (arbace/c2j/main.ae) as ARBACE_PATH finds it (a directory, or a\n  store's entry store:PREFIX, as RT.pathResource looks), nil when it does not.R3,i172,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main5,formsm12,R6,TR2,L2,V1,R18,V2,Myn1,bm2,R12,R17,R19,R0,s113,The top-level forms of source text (only the first n when n), read with *read-eval* false;\n  nil when unreadable.R3,i184,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main4,libsm12,R6,TR2,L1,V1,R20,R0,s84,The namespaces an ns form requires or uses (:require, :use; libspecs, prefix lists).R3,i197,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main9,source-nsm12,R6,TR2,L1,V1,R21,R0,s160,The namespace of a source's top-level forms: an ns form's name, or an in-ns form's (a source\n  of a namespace another source declares, as core_print is core's).R3,i211,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main11,source-depsm12,R6,TR2,L1,V2,R19,R21,R0,s183,The namespaces source forms fs (of namespace n) need: its ns form's libs and the sources its\n  top-level load forms load (a path relative to n's directory, as load takes it), by path.R3,i222,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main16,back-end-sourcesm12,R6,TR2,L1,V1,R22,R0,s280,The recorded sources (srcs, in the order they were loaded) of the namespaces the back end\n  needs: the closure of arbace.c2j.main and arbace.core under :require, :use and top-level load,\n  each [src text-on-ARBACE_PATH]; nil when one of them is not on ARBACE_PATH or not readable.R3,i236,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main17,compiled-back-endm12,R6,TR2,L1,V0,R0,s674,Whether the back end now runs as the program's compiled code (SA164). The namespaces the\n  program prepares to compile them (ARBACE_NO_AOT) are evaluated, and the back end and the\n  namespaces it calls with them (arbace.core, arbace.string ...), most of its time. When\n  the program holds the compiled loaders of those namespaces' sources (S6) and the sources on\n  ARBACE_PATH are the program's embedded ones, the loaders run in the order the sources were\n  loaded, in the bindings Compiler$AOT/load makes, so that their vars' roots are the compiled\n  fns: the units the back end reads are the analysis' either way, and the code is the same\n  sources'. Else nothing changes.R3,i261,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main18,java-forms-recordsm12,R6,TR2,L1,V0,R0,s125,What the Java forms compiler compiled while the program prepared its namespaces\n  (arbace.classes.native/compiled), in order.R3,i304,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main18,java-forms-classesm12,R6,TR2,L1,V1,R23,R0,s295,The classes the Java forms compiler made while the program prepared its namespaces (a\n  deftype, a fn or a defclass using the Java forms), but those of the back end's classes\n  (names): [{:ns :imports :forms :names} ...], a compilation made again (an analysis tried\n  twice) kept once, its last.R3,i310,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main15,java-forms-filem12,R6,TR2,L1,V1,R24,R0,s87,The file of the Java forms compiler's classes r: its namespace, its imports, its forms.R3,i322,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main8,class-nsm12,R6,TR2,L1,V2,R25,Myn1,cm2,R12,R14,R0,s246,The namespace (a holder, a loader's source) or package (a deftype, an interface) whose Go\n  package holds top-level class c, given the classes made (name → record): the package is aot_\n  and its munged name (j2g's names/compiled-packages, SA142).R3,i331,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main12,package-namem12,R6,TR2,L1,V1,R19,R0,s76,The Go package of the compiled classes of namespace or package n (class-ns).R3,i343,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main6,top-ofm10,R6,TR2,L1,V1,Myn1,nm2,R12,R14,R3,i348,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main9,form-refsm12,R6,TR2,L1,V2,R10,Myn3,accm2,R12,R26,R0,s261,The names of the classes form f names (its symbols, as a class, a class's member or a\n  constructor, their tags and param-tags, and the classes of array tags), into the\n  java.util.HashSet acc; a link marker's root and arguments (the code of both its outcomes).R3,i350,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main8,reaches?m12,R6,TR2,L1,V3,R27,R28,R18,R0,s58,Does node a reach node b in graph g (node → set of nodes)?R3,i373,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main9,link-planm12,R6,TR2,L1,V5,R29,R25,R30,R31,R32,R0,s680,Which link sites (by :id) are linked (Futamura F5): a site whose var's root at the end of the\n  prepare run was a fn whose code class was made (link-target), with a fixed arity of the\n  call's argument count. A direct call names the code's Go type, so it imports the code's Go\n  package, and the compiled namespaces' packages must not import each other in a cycle: a site\n  in another package than its code's is linked only when the packages' graph, the classes the\n  tree's top-level forms (tops: [package form]) name and the links taken so far, does not reach\n  the caller's package from the code's; the sites are taken in the order emitted. The result:\n  id → [cname variadic].R3,i384,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main6,linkerm12,R6,TR2,L1,V2,R33,R34,R0,s173,The resolution of link markers (arbace.c2j.emit/link-form) by plan (link-plan): the guarded\n  direct call, or the generic one. Counts the sites in links (:linked, :generic).R3,i416,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main4,run*m12,R6,TR2,L1,V2,R35,R36,R0,s74,Compiles sources (or all recorded) into directory out; returns the report.R3,i425,R4,i1,R5,s18,arbace/c2j/main.aev15,arbace.c2j.main3,runm10,R2,L1,V2,R35,R36,R0,s156,Compiles sources (or all recorded) into directory out; returns the report. The back end's\n  own code compiled when the program holds it (compiled-back-end).R3,i524,R4,i1,R5,s18,arbace/c2j/main.ae")

var Lit_214 *jrt.String = jrt.Intern("arbace.c2j.main$eval329000004$loading__1927001464__auto____329000005")

var Lit_215 *jrt.String = jrt.Intern("arbace.c2j.main$eval329000008$fn__329000009")

var Lit_216 *jrt.String = jrt.Intern("arbace.c2j.main$units")

var Lit_217 *jrt.String = jrt.Intern("arbace.c2j.main$events")

var Lit_218 *jrt.String = jrt.Intern("arbace.c2j.main$source_classes")

var Lit_219 *jrt.String = jrt.Intern("arbace.c2j.main$interfaces")

var Lit_220 *jrt.String = jrt.Intern("arbace.c2j.main$clean_meta")

var Lit_221 *jrt.String = jrt.Intern("arbace.c2j.main$forms__GT_lists")

var Lit_222 *jrt.String = jrt.Intern("arbace.c2j.main$write_form")

var Lit_223 *jrt.String = jrt.Intern("arbace.c2j.main$fn__329000110")

var Lit_224 *jrt.String = jrt.Intern("arbace.c2j.main$form_texts")

var Lit_225 *jrt.String = jrt.Intern("arbace.c2j.main$file_name")

var Lit_226 *jrt.String = jrt.Intern("arbace.c2j.main$compile_all")

var Lit_227 *jrt.String = jrt.Intern("arbace.c2j.main$path_source")

var Lit_228 *jrt.String = jrt.Intern("arbace.c2j.main$forms")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.main$libs")

var Lit_230 *jrt.String = jrt.Intern("arbace.c2j.main$source_ns")

var Lit_231 *jrt.String = jrt.Intern("arbace.c2j.main$source_deps")

var Lit_232 *jrt.String = jrt.Intern("arbace.c2j.main$back_end_sources")

var Lit_233 *jrt.String = jrt.Intern("arbace.c2j.main$compiled_back_end")

var Lit_234 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_records")

var Lit_235 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_classes")

var Lit_236 *jrt.String = jrt.Intern("arbace.c2j.main$java_forms_file")

var Lit_237 *jrt.String = jrt.Intern("arbace.c2j.main$class_ns")

var Lit_238 *jrt.String = jrt.Intern("arbace.c2j.main$package_name")

var Lit_239 *jrt.String = jrt.Intern("arbace.c2j.main$top_of")

var Lit_240 *jrt.String = jrt.Intern("arbace.c2j.main$form_refs")

var Lit_241 *jrt.String = jrt.Intern("arbace.c2j.main$reaches_QMARK_")

var Lit_242 *jrt.String = jrt.Intern("arbace.c2j.main$link_plan")

var Lit_243 *jrt.String = jrt.Intern("arbace.c2j.main$linker")

var Lit_244 *jrt.String = jrt.Intern("arbace.c2j.main$run_STAR_")

var Lit_245 *jrt.String = jrt.Intern("arbace.c2j.main$run")
