//line aot_arbace_c2j_main__init.ae:1
package aot_arbace_c2j_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_main__init_A_Unit0__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c2j_main__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_main__init_A_const_1) }
//line :1:1
func A_arbace_c2j_main__init_A_Unit1__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c2j_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_2)) }
//line :1:1
func A_arbace_c2j_main__init_A_Unit2__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_c2j_main_eval329000004_loading__1927001464__auto____329000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_main_eval329000004_loading__1927001464__auto____329000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_233, false); A_arbace_c2j_main_eval329000004_loading__1927001464__auto____329000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2j_main__init_A_Unit3__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2j_main__init_A_const_1)).Equals_O__Z(A_arbace_c2j_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2j_main_eval329000008_fn__329000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2j_main_eval329000008_fn__329000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_234, false); A_arbace_c2j_main_eval329000008_fn__329000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2j_main__init_A_Load__O() any { A_arbace_c2j_main__init_A_Init(); jrt.StartCheck(); A_arbace_c2j_main__init_A_Unit0__O(); A_arbace_c2j_main__init_A_Unit1__O(); A_arbace_c2j_main__init_A_Unit2__O(); A_arbace_c2j_main__init_A_Unit3__O(); A_arbace_c2j_main__init_A_Unit4__O(); A_arbace_c2j_main__init_A_Unit5__O(); A_arbace_c2j_main__init_A_Unit6__O(); A_arbace_c2j_main__init_A_Unit7__O(); A_arbace_c2j_main__init_A_Unit8__O(); A_arbace_c2j_main__init_A_Unit9__O(); A_arbace_c2j_main__init_A_Unit10__O(); A_arbace_c2j_main__init_A_Unit11__O(); A_arbace_c2j_main__init_A_Unit12__O(); A_arbace_c2j_main__init_A_Unit13__O(); A_arbace_c2j_main__init_A_Unit14__O(); A_arbace_c2j_main__init_A_Unit15__O(); A_arbace_c2j_main__init_A_Unit16__O(); A_arbace_c2j_main__init_A_Unit17__O(); A_arbace_c2j_main__init_A_Unit18__O(); A_arbace_c2j_main__init_A_Unit19__O(); A_arbace_c2j_main__init_A_Unit20__O(); A_arbace_c2j_main__init_A_Unit21__O(); A_arbace_c2j_main__init_A_Unit22__O(); A_arbace_c2j_main__init_A_Unit23__O(); A_arbace_c2j_main__init_A_Unit24__O(); A_arbace_c2j_main__init_A_Unit25__O(); A_arbace_c2j_main__init_A_Unit26__O(); A_arbace_c2j_main__init_A_Unit27__O(); A_arbace_c2j_main__init_A_Unit28__O(); A_arbace_c2j_main__init_A_Unit29__O(); A_arbace_c2j_main__init_A_Unit30__O(); A_arbace_c2j_main__init_A_Unit31__O(); A_arbace_c2j_main__init_A_Unit32__O(); A_arbace_c2j_main__init_A_Unit33__O(); A_arbace_c2j_main__init_A_Unit34__O(); A_arbace_c2j_main__init_A_Unit35__O(); A_arbace_c2j_main__init_A_Unit36__O(); A_arbace_c2j_main__init_A_Unit37__O(); return nil }












func A_arbace_c2j_main__init_A_Unit4__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_4; var tmp2 any = A_arbace_c2j_main_units_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2j_main_units_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_235, false); A_arbace_c2j_main_units_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_5)); return A_arbace_c2j_main__init_A_const_4 }








func A_arbace_c2j_main__init_A_Unit5__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_6; var tmp2 any = A_arbace_c2j_main_events_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_c2j_main_events_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_236, false); A_arbace_c2j_main_events_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_7)); return A_arbace_c2j_main__init_A_const_6 }


func A_arbace_c2j_main__init_A_Unit6__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_8; var tmp2 any = A_arbace_c2j_main_source_classes_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2j_main_source_classes_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_237, false); A_arbace_c2j_main_source_classes_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_9)); return A_arbace_c2j_main__init_A_const_8 }








func A_arbace_c2j_main__init_A_Unit7__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_10; var tmp2 any = A_arbace_c2j_main_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_c2j_main_interfaces_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_238, false); A_arbace_c2j_main_interfaces_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_11)); return A_arbace_c2j_main__init_A_const_10 }











func A_arbace_c2j_main__init_A_Unit8__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_12; var tmp2 any = A_arbace_c2j_main_clean_meta_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c2j_main_clean_meta_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_239, false); A_arbace_c2j_main_clean_meta_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_13)); return A_arbace_c2j_main__init_A_const_12 }








func A_arbace_c2j_main__init_A_Unit9__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); A_arbace_c2j_main__init_A_const_14.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_15)); return A_arbace_c2j_main__init_A_const_14.SetDynamic_Z__Var(true).Ref() }




func A_arbace_c2j_main__init_A_Unit10__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_16; var tmp2 any = A_arbace_c2j_main_forms__GT_lists_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_c2j_main_forms__GT_lists_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_240, false); A_arbace_c2j_main_forms__GT_lists_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_17)); return A_arbace_c2j_main__init_A_const_16 }

















func A_arbace_c2j_main__init_A_Unit11__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_18; var tmp2 any = A_arbace_c2j_main_write_form_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_main_write_form_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_241, false); A_arbace_c2j_main_write_form_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_19)); return A_arbace_c2j_main__init_A_const_18 }





func A_arbace_c2j_main__init_A_Unit12__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_20; var tmp2 any = A_arbace_c2j_main_fn__329000110_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_c2j_main_fn__329000110_A_fn_class; if





	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_242, false); A_arbace_c2j_main_fn__329000110_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; /*line :89:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_21)); return A_arbace_c2j_main__init_A_const_20 }







func A_arbace_c2j_main__init_A_Unit13__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_22; var tmp2 any = A_arbace_c2j_main_form_texts_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_main_form_texts_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_243, false); A_arbace_c2j_main_form_texts_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_23)); return A_arbace_c2j_main__init_A_const_22 }


































func A_arbace_c2j_main__init_A_Unit14__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_24; var tmp2 any = A_arbace_c2j_main_file_name_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_c2j_main_file_name_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_244, false); A_arbace_c2j_main_file_name_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_25)); return A_arbace_c2j_main__init_A_const_24 }


func A_arbace_c2j_main__init_A_Unit15__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_26; var tmp2 any = A_arbace_c2j_main_compile_all_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_main_compile_all_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_245, false); A_arbace_c2j_main_compile_all_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_27)); return A_arbace_c2j_main__init_A_const_26 }

































func A_arbace_c2j_main__init_A_Unit16__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); A_arbace_c2j_main__init_A_const_28.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_29)); return A_arbace_c2j_main__init_A_const_28.SetDynamic_Z__Var(true).Ref() }



func A_arbace_c2j_main__init_A_Unit17__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_30; var tmp2 any = A_arbace_c2j_main_path_source_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_c2j_main_path_source_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_246, false); A_arbace_c2j_main_path_source_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_31)); return A_arbace_c2j_main__init_A_const_30 }











func A_arbace_c2j_main__init_A_Unit18__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_32; var tmp2 any = A_arbace_c2j_main_forms_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_main_forms_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_c2j_main_forms_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_33)); return A_arbace_c2j_main__init_A_const_32 }












func A_arbace_c2j_main__init_A_Unit19__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_34; var tmp2 any = A_arbace_c2j_main_libs_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_c2j_main_libs_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_c2j_main_libs_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_35)); return A_arbace_c2j_main__init_A_const_34 }













func A_arbace_c2j_main__init_A_Unit20__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_36; var tmp2 any = A_arbace_c2j_main_source_ns_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c2j_main_source_ns_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_c2j_main_source_ns_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_37)); return A_arbace_c2j_main__init_A_const_36 }










func A_arbace_c2j_main__init_A_Unit21__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_38; var tmp2 any = A_arbace_c2j_main_source_deps_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_c2j_main_source_deps_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_c2j_main_source_deps_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_39)); return A_arbace_c2j_main__init_A_const_38 }













func A_arbace_c2j_main__init_A_Unit22__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(237, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_40; var tmp2 any = A_arbace_c2j_main_back_end_sources_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c2j_main_back_end_sources_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_c2j_main_back_end_sources_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_41)); return A_arbace_c2j_main__init_A_const_40 }
























func A_arbace_c2j_main__init_A_Unit23__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_42; var tmp2 any = A_arbace_c2j_main_compiled_back_end_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_c2j_main_compiled_back_end_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_c2j_main_compiled_back_end_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_43)); return A_arbace_c2j_main__init_A_const_42 }










































func A_arbace_c2j_main__init_A_Unit24__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_44; var tmp2 any = A_arbace_c2j_main_java_forms_records_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_main_java_forms_records_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_c2j_main_java_forms_records_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_45)); return A_arbace_c2j_main__init_A_const_44 }





func A_arbace_c2j_main__init_A_Unit25__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_46; var tmp2 any = A_arbace_c2j_main_java_forms_classes_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_c2j_main_java_forms_classes_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_c2j_main_java_forms_classes_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_47)); return A_arbace_c2j_main__init_A_const_46 }











func A_arbace_c2j_main__init_A_Unit26__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_48; var tmp2 any = A_arbace_c2j_main_java_forms_file_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c2j_main_java_forms_file_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_c2j_main_java_forms_file_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_49)); return A_arbace_c2j_main__init_A_const_48 }











func A_arbace_c2j_main__init_A_Unit27__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_50; var tmp2 any = A_arbace_c2j_main_class_ns_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_c2j_main_class_ns_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_c2j_main_class_ns_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_51)); return A_arbace_c2j_main__init_A_const_50 }















func A_arbace_c2j_main__init_A_Unit28__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_52; var tmp2 any = A_arbace_c2j_main_package_name_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c2j_main_package_name_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_c2j_main_package_name_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_53)); return A_arbace_c2j_main__init_A_const_52 }




func A_arbace_c2j_main__init_A_Unit29__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_54; var tmp2 any = A_arbace_c2j_main_top_of_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_c2j_main_top_of_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_c2j_main_top_of_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_55)); return A_arbace_c2j_main__init_A_const_54 }

func A_arbace_c2j_main__init_A_Unit30__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_56; var tmp2 any = A_arbace_c2j_main_form_refs_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c2j_main_form_refs_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_c2j_main_form_refs_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_57)); return A_arbace_c2j_main__init_A_const_56 }






















func A_arbace_c2j_main__init_A_Unit31__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_58; var tmp2 any = A_arbace_c2j_main_reaches_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_c2j_main_reaches_QMARK__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_c2j_main_reaches_QMARK__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_59)); return A_arbace_c2j_main__init_A_const_58 }










func A_arbace_c2j_main__init_A_Unit32__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(392, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_60; var tmp2 any = A_arbace_c2j_main_link_plan_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c2j_main_link_plan_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_c2j_main_link_plan_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_61)); return A_arbace_c2j_main__init_A_const_60 }































func A_arbace_c2j_main__init_A_Unit33__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_62; var tmp2 any = A_arbace_c2j_main_package_graph_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_c2j_main_package_graph_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_c2j_main_package_graph_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_63)); return A_arbace_c2j_main__init_A_const_62 }













func A_arbace_c2j_main__init_A_Unit34__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(438, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_64; var tmp2 any = A_arbace_c2j_main_cycle_merge_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c2j_main_cycle_merge_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_c2j_main_cycle_merge_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_65)); return A_arbace_c2j_main__init_A_const_64 }














func A_arbace_c2j_main__init_A_Unit35__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(453, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_66; var tmp2 any = A_arbace_c2j_main_linker_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_c2j_main_linker_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_c2j_main_linker_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_67)); return A_arbace_c2j_main__init_A_const_66 }













func A_arbace_c2j_main__init_A_Unit36__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_68; var tmp2 any = A_arbace_c2j_main_run_STAR__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_main_run_STAR__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_265, false); A_arbace_c2j_main_run_STAR__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_69)); return A_arbace_c2j_main__init_A_const_68 }


















































































































func A_arbace_c2j_main__init_A_Unit37__O() any { A_arbace_c2j_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_c2j_main__init_A_const_70; var tmp2 any = A_arbace_c2j_main_run_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_c2j_main_run_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_c2j_main_run_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_main__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_main__init_A_const_71)); return A_arbace_c2j_main__init_A_const_70 }



type A_arbace_c2j_main__init_A struct{ jrt.Object }

var A_arbace_c2j_main__init_A_const_pool *jrt.RefArray

var A_arbace_c2j_main__init_A_const_0 *lang.Var

var A_arbace_c2j_main__init_A_const_1 any

var A_arbace_c2j_main__init_A_const_2 any

var A_arbace_c2j_main__init_A_const_3 any

var A_arbace_c2j_main__init_A_const_4 *lang.Var

var A_arbace_c2j_main__init_A_const_5 any

var A_arbace_c2j_main__init_A_const_6 *lang.Var

var A_arbace_c2j_main__init_A_const_7 any

var A_arbace_c2j_main__init_A_const_8 *lang.Var

var A_arbace_c2j_main__init_A_const_9 any

var A_arbace_c2j_main__init_A_const_10 *lang.Var

var A_arbace_c2j_main__init_A_const_11 any

var A_arbace_c2j_main__init_A_const_12 *lang.Var

var A_arbace_c2j_main__init_A_const_13 any

var A_arbace_c2j_main__init_A_const_14 *lang.Var

var A_arbace_c2j_main__init_A_const_15 any

var A_arbace_c2j_main__init_A_const_16 *lang.Var

var A_arbace_c2j_main__init_A_const_17 any

var A_arbace_c2j_main__init_A_const_18 *lang.Var

var A_arbace_c2j_main__init_A_const_19 any

var A_arbace_c2j_main__init_A_const_20 *lang.Var

var A_arbace_c2j_main__init_A_const_21 any

var A_arbace_c2j_main__init_A_const_22 *lang.Var

var A_arbace_c2j_main__init_A_const_23 any

var A_arbace_c2j_main__init_A_const_24 *lang.Var

var A_arbace_c2j_main__init_A_const_25 any

var A_arbace_c2j_main__init_A_const_26 *lang.Var

var A_arbace_c2j_main__init_A_const_27 any

var A_arbace_c2j_main__init_A_const_28 *lang.Var

var A_arbace_c2j_main__init_A_const_29 any

var A_arbace_c2j_main__init_A_const_30 *lang.Var

var A_arbace_c2j_main__init_A_const_31 any

var A_arbace_c2j_main__init_A_const_32 *lang.Var

var A_arbace_c2j_main__init_A_const_33 any

var A_arbace_c2j_main__init_A_const_34 *lang.Var

var A_arbace_c2j_main__init_A_const_35 any

var A_arbace_c2j_main__init_A_const_36 *lang.Var

var A_arbace_c2j_main__init_A_const_37 any

var A_arbace_c2j_main__init_A_const_38 *lang.Var

var A_arbace_c2j_main__init_A_const_39 any

var A_arbace_c2j_main__init_A_const_40 *lang.Var

var A_arbace_c2j_main__init_A_const_41 any

var A_arbace_c2j_main__init_A_const_42 *lang.Var

var A_arbace_c2j_main__init_A_const_43 any

var A_arbace_c2j_main__init_A_const_44 *lang.Var

var A_arbace_c2j_main__init_A_const_45 any

var A_arbace_c2j_main__init_A_const_46 *lang.Var

var A_arbace_c2j_main__init_A_const_47 any

var A_arbace_c2j_main__init_A_const_48 *lang.Var

var A_arbace_c2j_main__init_A_const_49 any

var A_arbace_c2j_main__init_A_const_50 *lang.Var

var A_arbace_c2j_main__init_A_const_51 any

var A_arbace_c2j_main__init_A_const_52 *lang.Var

var A_arbace_c2j_main__init_A_const_53 any

var A_arbace_c2j_main__init_A_const_54 *lang.Var

var A_arbace_c2j_main__init_A_const_55 any

var A_arbace_c2j_main__init_A_const_56 *lang.Var

var A_arbace_c2j_main__init_A_const_57 any

var A_arbace_c2j_main__init_A_const_58 *lang.Var

var A_arbace_c2j_main__init_A_const_59 any

var A_arbace_c2j_main__init_A_const_60 *lang.Var

var A_arbace_c2j_main__init_A_const_61 any

var A_arbace_c2j_main__init_A_const_62 *lang.Var

var A_arbace_c2j_main__init_A_const_63 any

var A_arbace_c2j_main__init_A_const_64 *lang.Var

var A_arbace_c2j_main__init_A_const_65 any

var A_arbace_c2j_main__init_A_const_66 *lang.Var

var A_arbace_c2j_main__init_A_const_67 any

var A_arbace_c2j_main__init_A_const_68 *lang.Var

var A_arbace_c2j_main__init_A_const_69 any

var A_arbace_c2j_main__init_A_const_70 *lang.Var

var A_arbace_c2j_main__init_A_const_71 any

var A_arbace_c2j_main__init_A_init jrt.ClassInit

func A_arbace_c2j_main__init_A_Init() { if !A_arbace_c2j_main__init_A_init.Done() { A_arbace_c2j_main__init_A_init.Run(A_arbace_c2j_main__init_A_clinit) } }

func A_arbace_c2j_main__init_A_clinit() { A_arbace_c2j_main__init_A_clinit_p0(); A_arbace_c2j_main__init_A_clinit_p1(); A_arbace_c2j_main__init_A_clinit_p2(); A_arbace_c2j_main__init_A_clinit_p3(); A_arbace_c2j_main__init_A_clinit_p4(); A_arbace_c2j_main__init_A_clinit_p5() }

func A_arbace_c2j_main__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_main__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_232, 109); A_arbace_c2j_main__init_A_const_0 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[37]); A_arbace_c2j_main__init_A_const_1 = A_arbace_c2j_main__init_A_const_pool.A[38]; A_arbace_c2j_main__init_A_const_2 = A_arbace_c2j_main__init_A_const_pool.A[39]; A_arbace_c2j_main__init_A_const_3 = A_arbace_c2j_main__init_A_const_pool.A[40]; A_arbace_c2j_main__init_A_const_4 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[41]); A_arbace_c2j_main__init_A_const_5 = A_arbace_c2j_main__init_A_const_pool.A[42]; A_arbace_c2j_main__init_A_const_6 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[43]); A_arbace_c2j_main__init_A_const_7 = A_arbace_c2j_main__init_A_const_pool.A[44]; A_arbace_c2j_main__init_A_const_8 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[45]); A_arbace_c2j_main__init_A_const_9 = A_arbace_c2j_main__init_A_const_pool.A[46]; A_arbace_c2j_main__init_A_const_10 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[47]); A_arbace_c2j_main__init_A_const_11 = A_arbace_c2j_main__init_A_const_pool.A[48]; A_arbace_c2j_main__init_A_const_12 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[49]) }

func A_arbace_c2j_main__init_A_clinit_p1() { A_arbace_c2j_main__init_A_const_13 = A_arbace_c2j_main__init_A_const_pool.A[50]; A_arbace_c2j_main__init_A_const_14 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[51]); A_arbace_c2j_main__init_A_const_15 = A_arbace_c2j_main__init_A_const_pool.A[52]; A_arbace_c2j_main__init_A_const_16 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[53]); A_arbace_c2j_main__init_A_const_17 = A_arbace_c2j_main__init_A_const_pool.A[54]; A_arbace_c2j_main__init_A_const_18 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[55]); A_arbace_c2j_main__init_A_const_19 = A_arbace_c2j_main__init_A_const_pool.A[56]; A_arbace_c2j_main__init_A_const_20 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[57]); A_arbace_c2j_main__init_A_const_21 = A_arbace_c2j_main__init_A_const_pool.A[58]; A_arbace_c2j_main__init_A_const_22 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[59]); A_arbace_c2j_main__init_A_const_23 = A_arbace_c2j_main__init_A_const_pool.A[60]; A_arbace_c2j_main__init_A_const_24 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[61]); A_arbace_c2j_main__init_A_const_25 = A_arbace_c2j_main__init_A_const_pool.A[62] }

func A_arbace_c2j_main__init_A_clinit_p2() { A_arbace_c2j_main__init_A_const_26 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[63]); A_arbace_c2j_main__init_A_const_27 = A_arbace_c2j_main__init_A_const_pool.A[64]; A_arbace_c2j_main__init_A_const_28 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[65]); A_arbace_c2j_main__init_A_const_29 = A_arbace_c2j_main__init_A_const_pool.A[66]; A_arbace_c2j_main__init_A_const_30 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[67]); A_arbace_c2j_main__init_A_const_31 = A_arbace_c2j_main__init_A_const_pool.A[68]; A_arbace_c2j_main__init_A_const_32 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[69]); A_arbace_c2j_main__init_A_const_33 = A_arbace_c2j_main__init_A_const_pool.A[70]; A_arbace_c2j_main__init_A_const_34 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[71]); A_arbace_c2j_main__init_A_const_35 = A_arbace_c2j_main__init_A_const_pool.A[72]; A_arbace_c2j_main__init_A_const_36 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[73]); A_arbace_c2j_main__init_A_const_37 = A_arbace_c2j_main__init_A_const_pool.A[74]; A_arbace_c2j_main__init_A_const_38 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[75]) }

func A_arbace_c2j_main__init_A_clinit_p3() { A_arbace_c2j_main__init_A_const_39 = A_arbace_c2j_main__init_A_const_pool.A[76]; A_arbace_c2j_main__init_A_const_40 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[77]); A_arbace_c2j_main__init_A_const_41 = A_arbace_c2j_main__init_A_const_pool.A[78]; A_arbace_c2j_main__init_A_const_42 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[79]); A_arbace_c2j_main__init_A_const_43 = A_arbace_c2j_main__init_A_const_pool.A[80]; A_arbace_c2j_main__init_A_const_44 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[81]); A_arbace_c2j_main__init_A_const_45 = A_arbace_c2j_main__init_A_const_pool.A[82]; A_arbace_c2j_main__init_A_const_46 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[83]); A_arbace_c2j_main__init_A_const_47 = A_arbace_c2j_main__init_A_const_pool.A[84]; A_arbace_c2j_main__init_A_const_48 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[85]); A_arbace_c2j_main__init_A_const_49 = A_arbace_c2j_main__init_A_const_pool.A[86]; A_arbace_c2j_main__init_A_const_50 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[87]); A_arbace_c2j_main__init_A_const_51 = A_arbace_c2j_main__init_A_const_pool.A[88] }

func A_arbace_c2j_main__init_A_clinit_p4() { A_arbace_c2j_main__init_A_const_52 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[89]); A_arbace_c2j_main__init_A_const_53 = A_arbace_c2j_main__init_A_const_pool.A[90]; A_arbace_c2j_main__init_A_const_54 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[91]); A_arbace_c2j_main__init_A_const_55 = A_arbace_c2j_main__init_A_const_pool.A[92]; A_arbace_c2j_main__init_A_const_56 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[93]); A_arbace_c2j_main__init_A_const_57 = A_arbace_c2j_main__init_A_const_pool.A[94]; A_arbace_c2j_main__init_A_const_58 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[95]); A_arbace_c2j_main__init_A_const_59 = A_arbace_c2j_main__init_A_const_pool.A[96]; A_arbace_c2j_main__init_A_const_60 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[97]); A_arbace_c2j_main__init_A_const_61 = A_arbace_c2j_main__init_A_const_pool.A[98]; A_arbace_c2j_main__init_A_const_62 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[99]); A_arbace_c2j_main__init_A_const_63 = A_arbace_c2j_main__init_A_const_pool.A[100]; A_arbace_c2j_main__init_A_const_64 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[101]) }

func A_arbace_c2j_main__init_A_clinit_p5() { A_arbace_c2j_main__init_A_const_65 = A_arbace_c2j_main__init_A_const_pool.A[102]; A_arbace_c2j_main__init_A_const_66 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[103]); A_arbace_c2j_main__init_A_const_67 = A_arbace_c2j_main__init_A_const_pool.A[104]; A_arbace_c2j_main__init_A_const_68 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[105]); A_arbace_c2j_main__init_A_const_69 = A_arbace_c2j_main__init_A_const_pool.A[106]; A_arbace_c2j_main__init_A_const_70 = lang.Var_Cast(A_arbace_c2j_main__init_A_const_pool.A[107]); A_arbace_c2j_main__init_A_const_71 = A_arbace_c2j_main__init_A_const_pool.A[108] }

func A_arbace_c2j_main__init_A_New() *A_arbace_c2j_main__init_A { A_arbace_c2j_main__init_A_Init(); t := &A_arbace_c2j_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_main__init_A) Ctor() {}

func (t *A_arbace_c2j_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_main__init_A_class }

func (t *A_arbace_c2j_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_main__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_main__init_A); return ok }

func A_arbace_c2j_main__init_A_Cast(x any) *A_arbace_c2j_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_main__init_A_class)) }; return v }
