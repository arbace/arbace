//line a2g_strings.ae:1
package aot_arbace_a2g_checks

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_7 *jrt.String = jrt.Intern("a")

var Lit_8 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_9 *jrt.String = jrt.Intern("m")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_11 *jrt.String = jrt.Intern("jrt")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_13 *jrt.String = jrt.Intern("Opcodes")

var Lit_14 *jrt.String = jrt.Intern("commute")

var Lit_15 *jrt.String = jrt.Intern("deref")

var Lit_16 *jrt.String = jrt.Intern("conj")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.checks")

var Lit_18 *jrt.String = jrt.Intern("doc")

var Lit_19 *jrt.String = jrt.Intern("a2g's checks of its output (A2G-SPEC §4.4, §8.3): duplicate Go names in a package or a\n  method set, package-private methods that Go would let a subclass in another Java package\n  override, and the report of candidate two-word races.")

var Lit_20 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_21 *jrt.String = jrt.Intern("symbol?")

var Lit_22 *jrt.String = jrt.Intern("name")

var Lit_23 *jrt.String = jrt.Intern("first")

var Lit_24 *jrt.String = jrt.Intern("tag")

var Lit_25 *jrt.String = jrt.Intern("seq?")

var Lit_26 *jrt.String = jrt.Intern("*")

var Lit_27 *jrt.String = jrt.Intern("sym-name")

var Lit_28 *jrt.String = jrt.Intern("else")

var Lit_29 *jrt.String = jrt.Intern("filter")

var Lit_30 *jrt.String = jrt.Intern("vector?")

var Lit_31 *jrt.String = jrt.Intern("drop")

var Lit_32 *jrt.String = jrt.Intern("second")

var Lit_33 *jrt.String = jrt.Intern("seq")

var Lit_34 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_35 *jrt.String = jrt.Intern("chunk-first")

var Lit_36 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_37 *jrt.String = jrt.Intern("not")

var Lit_38 *jrt.String = jrt.Intern("_")

var Lit_39 *jrt.String = jrt.Intern("init")

var Lit_40 *jrt.String = jrt.Intern("chunk-append")

var Lit_41 *jrt.String = jrt.Intern("chunk-cons")

var Lit_42 *jrt.String = jrt.Intern("cons")

var Lit_43 *jrt.String = jrt.Intern("chunk")

var Lit_44 *jrt.String = jrt.Intern("chunk-rest")

var Lit_45 *jrt.String = jrt.Intern("rest")

var Lit_46 *jrt.String = jrt.Intern("concat")

var Lit_47 *jrt.String = jrt.Intern("recv-type")

var Lit_48 *jrt.String = jrt.Intern("pkg")

var Lit_49 *jrt.String = jrt.Intern("declared-names")

var Lit_50 *jrt.String = jrt.Intern("starts-with?")

var Lit_51 *jrt.String = jrt.Intern("funcs")

var Lit_52 *jrt.String = jrt.Intern("vars")

var Lit_53 *jrt.String = jrt.Intern("consts")

var Lit_54 *jrt.String = jrt.Intern("keys")

var Lit_55 *jrt.String = jrt.Intern("types")

var Lit_56 *jrt.String = jrt.Intern("methods")

var Lit_57 *jrt.String = jrt.Intern("group-by")

var Lit_58 *jrt.String = jrt.Intern("vec")

var Lit_59 *jrt.String = jrt.Intern("files")

var Lit_60 *jrt.String = jrt.Intern("sources")

var Lit_61 *jrt.String = jrt.Intern("sort")

var Lit_62 *jrt.String = jrt.Intern("map")

var Lit_63 *jrt.String = jrt.Intern("sort-by")

var Lit_64 *jrt.String = jrt.Intern("comp")

var Lit_65 *jrt.String = jrt.Intern("key")

var Lit_66 *jrt.String = jrt.Intern("val")

var Lit_67 *jrt.String = jrt.Intern("subs")

var Lit_68 *jrt.String = jrt.Intern("reduce")

var Lit_69 *jrt.String = jrt.Intern("update")

var Lit_70 *jrt.String = jrt.Intern("fnil")

var Lit_71 *jrt.String = jrt.Intern("superclass-chain")

var Lit_72 *jrt.String = jrt.Intern("decl")

var Lit_73 *jrt.String = jrt.Intern("not=")

var Lit_74 *jrt.String = jrt.Intern("flags")

var Lit_75 *jrt.String = jrt.Intern("desc")

var Lit_76 *jrt.String = jrt.Intern("static?")

var Lit_77 *jrt.String = jrt.Intern("method")

var Lit_78 *jrt.String = jrt.Intern("hidden-by")

var Lit_79 *jrt.String = jrt.Intern("jpkg")

var Lit_80 *jrt.String = jrt.Intern("private?")

var Lit_81 *jrt.String = jrt.Intern("interface?")

var Lit_82 *jrt.String = jrt.Intern("into")

var Lit_83 *jrt.String = jrt.Intern("sorted-map")

var Lit_84 *jrt.String = jrt.Intern("join")

var Lit_85 *jrt.String = jrt.Intern("distinct")

var Lit_86 *jrt.String = jrt.Intern("peek")

var Lit_87 *jrt.String = jrt.Intern("subvec")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$fn__1090000171")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000073__1090000079")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000073__1090000079$fn__1090000080")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000073__1090000079$fn__1090000080$iter__1090000075__1090000087")

var Lit_93 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000073__1090000079$fn__1090000080$iter__1090000075__1090000087$fn__1090000088")

var Lit_94 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000073__1090000079$fn__1090000080$iter__1090000075__1090000087$fn__1090000088$fn__1090000089")

var Lit_95 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102")

var Lit_97 *jrt.String = jrt.Intern("standin_")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000097__1090000106")

var Lit_99 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000097__1090000106$fn__1090000107")

var Lit_100 *jrt.String = jrt.Intern("jrt/")

var Lit_101 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000097__1090000106$fn__1090000107$fn__1090000108")

var Lit_102 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000112__1090000116")

var Lit_103 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000112__1090000116$fn__1090000117")

var Lit_104 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000112__1090000116$fn__1090000117$fn__1090000118")

var Lit_105 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000122__1090000128")

var Lit_106 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000122__1090000128$fn__1090000129")

var Lit_107 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000122__1090000128$fn__1090000129$iter__1090000124__1090000133")

var Lit_108 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000122__1090000128$fn__1090000129$iter__1090000124__1090000133$fn__1090000134")

var Lit_109 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000095__1090000101$fn__1090000102$iter__1090000122__1090000128$fn__1090000129$iter__1090000124__1090000133$fn__1090000134$fn__1090000135")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000143__1090000147")

var Lit_111 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000143__1090000147$fn__1090000148")

var Lit_112 *jrt.String = jrt.Intern("(")

var Lit_113 *jrt.String = jrt.Intern(").")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.checks$collisions$iter__1090000143__1090000147$fn__1090000148$fn__1090000149")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021")

var Lit_118 *jrt.String = jrt.Intern("type")

var Lit_119 *jrt.String = jrt.Intern("const")

var Lit_120 *jrt.String = jrt.Intern("func")

var Lit_121 *jrt.String = jrt.Intern("var")

var Lit_122 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000016__1090000022")

var Lit_123 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000016__1090000022$fn__1090000023")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000016__1090000022$fn__1090000023$fn__1090000024")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000029__1090000033")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000029__1090000033$fn__1090000034")

var Lit_127 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000029__1090000033$fn__1090000034$fn__1090000035")

var Lit_128 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000039__1090000043")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000039__1090000043$fn__1090000044")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000039__1090000043$fn__1090000044$fn__1090000045")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000049__1090000053")

var Lit_132 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000049__1090000053$fn__1090000054")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000049__1090000053$fn__1090000054$fn__1090000055")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000059__1090000063")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000059__1090000063$fn__1090000064")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.checks$declared_names$iter__1090000014__1090000020$fn__1090000021$iter__1090000059__1090000063$fn__1090000064$fn__1090000065")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.checks$eval1090000004$loading__1927001464__auto____1090000005")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.checks$eval1090000008$fn__1090000009")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.checks$jpkg")

var Lit_140 *jrt.String = jrt.Intern("/")

var Lit_141 *jrt.String = jrt.Intern("")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$fn__1090000177")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$fn__1090000177$fn__1090000178")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194")

var Lit_149 *jrt.String = jrt.Intern("<init>")

var Lit_150 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194$iter__1090000185__1090000195")

var Lit_151 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194$iter__1090000185__1090000195$fn__1090000196")

var Lit_152 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194$iter__1090000185__1090000195$fn__1090000196$iter__1090000187__1090000197")

var Lit_153 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194$iter__1090000185__1090000195$fn__1090000196$iter__1090000187__1090000197$fn__1090000198")

var Lit_154 *jrt.String = jrt.Intern(".")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.checks$package_private_overrides$iter__1090000181__1090000191$fn__1090000192$iter__1090000183__1090000193$fn__1090000194$iter__1090000185__1090000195$fn__1090000196$iter__1090000187__1090000197$fn__1090000198$fn__1090000199")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000217")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000217$fn__1090000243")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000217$iter__1090000221__1090000225")

var Lit_162 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000217$iter__1090000221__1090000225$fn__1090000226")

var Lit_163 *jrt.String = jrt.Intern(" ")

var Lit_164 *jrt.String = jrt.Intern(" written in ")

var Lit_165 *jrt.String = jrt.Intern("static ")

var Lit_166 *jrt.String = jrt.Intern(", ")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000217$iter__1090000221__1090000225$fn__1090000226$fn__1090000227")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$fn__1090000271")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$iter__1090000249__1090000253")

var Lit_170 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$iter__1090000249__1090000253$fn__1090000254")

var Lit_171 *jrt.String = jrt.Intern("arbace.a2g.checks$race_report$iter__1090000211__1090000215$fn__1090000216$iter__1090000249__1090000253$fn__1090000254$fn__1090000255")

var Lit_172 *jrt.String = jrt.Intern("arbace.a2g.checks$recv_type")

var Lit_173 *jrt.String = jrt.Intern("arbace.a2g.checks$sym_name")

var Lit_174 *jrt.String = jrt.Intern("in-ns")

var Lit_175 *jrt.String = jrt.Intern("private")

var Lit_176 *jrt.String = jrt.Intern("arglists")

var Lit_177 *jrt.String = jrt.Intern("x")

var Lit_178 *jrt.String = jrt.Intern("line")

var Lit_179 *jrt.String = jrt.Intern("column")

var Lit_180 *jrt.String = jrt.Intern("file")

var Lit_181 *jrt.String = jrt.Intern("arbace/a2g/checks.ae")

var Lit_182 *jrt.String = jrt.Intern("f")

var Lit_183 *jrt.String = jrt.Intern("The receiver's type name of a go/method form: T for (* T) or T.")

var Lit_184 *jrt.String = jrt.Intern("forms")

var Lit_185 *jrt.String = jrt.Intern("[kind name] of the Go declarations of forms: [:pkg n] for package-level names, [T m] for\n  a method m of type T. init functions and blank names are left out.")

var Lit_186 *jrt.String = jrt.Intern("collisions")

var Lit_187 *jrt.String = jrt.Intern("scan")

var Lit_188 *jrt.String = jrt.Intern("Duplicate Go names among the generated files (files: {[pkg file] forms}) and jrt's\n  hand-written declarations (scan; the stand-in files left out, as translated classes replace\n  them): [{:pkg :name :sources [...]}].")

var Lit_189 *jrt.String = jrt.Intern("n")

var Lit_190 *jrt.String = jrt.Intern("package-private-overrides")

var Lit_191 *jrt.String = jrt.Intern("T")

var Lit_192 *jrt.String = jrt.Intern("Package-private instance methods of translated classes that a translated subclass in\n  another Java package declares again with the same name and descriptor: Java does not\n  override them (JVMS 5.4.5), Go's method sets would (A2G-SPEC §4.4). [{:method :hidden-by}].")

var Lit_193 *jrt.String = jrt.Intern("race-report")

var Lit_194 *jrt.String = jrt.Intern("races")

var Lit_195 *jrt.String = jrt.Intern("The candidate two-word races (§8.3) as {class [\"field (writers...)\"]}.")
