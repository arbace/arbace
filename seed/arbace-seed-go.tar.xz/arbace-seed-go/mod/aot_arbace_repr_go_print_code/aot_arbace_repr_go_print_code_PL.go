//line aot_arbace_repr_go_print_code_PL.ae:1
package aot_arbace_repr_go_print_code

import (
	"arbace/jrt"
	"arbace/lang"
)














































func A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5 any, p6, p7 int32) *A_arbace_repr_go_print_code_PL_A { A_arbace_repr_go_print_code_PL_A_Init(); t := &A_arbace_repr_go_print_code_PL_A{}; t.Ctor_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Ctor_O_O_O_O_O_O_I_I(v, pos, text, parens, __meta, __extmap any, __hash, __hasheq int32) { t.F_v = v; t.F_pos = pos; t.F_text = text; t.F_parens = parens; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :53:1
func A_arbace_repr_go_print_code_PL_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_print_code_PL_A { A_arbace_repr_go_print_code_PL_A_Init(); t := &A_arbace_repr_go_print_code_PL_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Ctor_O_O_O_O(v, pos, text, parens any) { t.Ctor_O_O_O_O_O_O_I_I(v, pos, text, parens, nil, nil, 0, 0) }
//line :53:1
func A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_print_code_PL_A { A_arbace_repr_go_print_code_PL_A_Init(); t := &A_arbace_repr_go_print_code_PL_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Ctor_O_O_O_O_O_O(v, pos, text, parens, __meta, __extmap any) { t.Ctor_O_O_O_O_O_O_I_I(v, pos, text, parens, __meta, __extmap, 0, 0) }
//line :53:1
func A_arbace_repr_go_print_code_PL_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_repr_go_print_code_PL_A_Init(); return lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_225).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_226).Ref()) }
//line :53:1
func A_arbace_repr_go_print_code_PL_A_Create_IPersistentMap__A_arbace_repr_go_print_code_PL_A(m__ lang.IPersistentMap) *A_arbace_repr_go_print_code_PL_A { A_arbace_repr_go_print_code_PL_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_223).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_224).Ref(), nil); var v__2 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_225).Ref(), nil); var v__3 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword(Lit_226).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_223).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_224).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_225).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword(Lit_226).Ref()); return A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O_I_I(v__0, v__1, v__2, v__3, nil, lang.RT_SeqOrElse_O__O(m___2), 0, 0) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I(lang.Numbers_Xor_J_J__J(465197094, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Equals_O__Z(G__74000016__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z(t, G__74000016__1_) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) WithMeta_IPersistentMap__IObj(G__74000016__1_ lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O_I_I(t.F_v, t.F_pos, t.F_text, t.F_parens, G__74000016__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__74000029__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I(G__74000029__3_) >> 14 & 3 { case 0: if any(G__74000029__3_) == any(A_arbace_repr_go_print_code_PL_A_const_0) { return t.F_v }; case 1: if any(G__74000029__3_) == any(A_arbace_repr_go_print_code_PL_A_const_1) { return t.F_pos }; case 2: if any(G__74000029__3_) == any(A_arbace_repr_go_print_code_PL_A_const_2) { return t.F_text }; case 3: if any(G__74000029__3_) == any(A_arbace_repr_go_print_code_PL_A_const_3) { return t.F_parens }; default:}; return lang.RT_Get_O_O_O__O(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_4.GetRawRoot__O()).Invoke_O__O(t); var G__74000020__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I(G__74000020__3_) >> 14 & 3 { case 0: if any(G__74000020__3_) == any(A_arbace_repr_go_print_code_PL_A_const_0) { tmp1 = A_arbace_repr_go_print_code_PL_reify__74000021_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__74000020__3_) == any(A_arbace_repr_go_print_code_PL_A_const_1) { tmp1 = A_arbace_repr_go_print_code_PL_reify__74000023_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 2: if any(G__74000020__3_) == any(A_arbace_repr_go_print_code_PL_A_const_2) { tmp1 = A_arbace_repr_go_print_code_PL_reify__74000025_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 3: if any(G__74000020__3_) == any(A_arbace_repr_go_print_code_PL_A_const_3) { tmp1 = A_arbace_repr_go_print_code_PL_reify__74000027_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Count__I() int32 { return lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(4, int64(lang.RT_Count_O__I(t.F___extmap)))) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_227, Lit_228), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_repr_go_print_code_PL_A_const_5.Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Equiv_O__Z(G__74000016__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z(t, G__74000016__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2) } else { if lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_4.GetRawRoot__O()).Invoke_O__O(t), lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_4.GetRawRoot__O()).Invoke_O__O(G__74000016__1_)) { var G__74000016__3_ any = G__74000016__1_; var tmp2 any = t.F_v; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_repr_go_print_code_PL_A_Cast(G__74000016__3_).F_v); if and__1927000168__auto____4 { var tmp3 any = t.F_pos; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_repr_go_print_code_PL_A_Cast(G__74000016__3_).F_pos); if and__1927000168__auto____5 { var tmp4 any = t.F_text; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(tmp4, A_arbace_repr_go_print_code_PL_A_Cast(G__74000016__3_).F_text); if and__1927000168__auto____6 { var tmp5 any = t.F_parens; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp5, A_arbace_repr_go_print_code_PL_A_Cast(G__74000016__3_).F_parens); if and__1927000168__auto____7 { var tmp6 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, A_arbace_repr_go_print_code_PL_A_Cast(G__74000016__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z(tmp1.Ref()) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { return jrt.NN(jrt.Boolean_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_6.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref()))).BooleanValue__Z() }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Seq__ISeq() lang.ISeq { return lang.ISeq_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_print_code_PL_A_const_0, t.F_v).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_print_code_PL_A_const_1, t.F_pos).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_print_code_PL_A_const_2, t.F_text).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_print_code_PL_A_const_3, t.F_parens).Ref()), t.F___extmap))) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_repr_go_print_code_PL_A_const_9); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator(t.F___extmap)) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__74000016__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_repr_go_print_code_PL_A; var pred__74000018__3 any = A_arbace_repr_go_print_code_PL_A_const_10.GetRawRoot__O(); var expr__74000019__4 any = k__231000086__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__74000018__3).Invoke_O_O__O(A_arbace_repr_go_print_code_PL_A_const_0, expr__74000019__4)) { tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(G__74000016__2_, t.F_pos, t.F_text, t.F_parens, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__74000018__3).Invoke_O_O__O(A_arbace_repr_go_print_code_PL_A_const_1, expr__74000019__4)) { tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(t.F_v, G__74000016__2_, t.F_text, t.F_parens, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__74000018__3).Invoke_O_O__O(A_arbace_repr_go_print_code_PL_A_const_2, expr__74000019__4)) { tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(t.F_v, t.F_pos, G__74000016__2_, t.F_parens, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__74000018__3).Invoke_O_O__O(A_arbace_repr_go_print_code_PL_A_const_3, expr__74000019__4)) { tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(t.F_v, t.F_pos, t.F_text, G__74000016__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_v; var tmp3 any = t.F_pos; var tmp4 any = t.F_text; var tmp5 any = t.F_parens; var tmp6 any = t.F___meta; tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(t.F___extmap, k__231000086__auto____1, G__74000016__2_)) } } } }; return Up_A_arbace_repr_go_print_code_PL_A_IPersistentMap(tmp1) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_PL_A_const_15, k__231000088__auto____1)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_13.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_16.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_17.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), t), t.F___meta), k__231000088__auto____1) } else { var tmp6 any = t.F_v; var tmp7 any = t.F_pos; var tmp8 any = t.F_text; var tmp9 any = t.F_parens; var tmp10 any = t.F___meta; tmp1 = A_arbace_repr_go_print_code_PL_A_New_O_O_O_O_O_O(tmp6, tmp7, tmp8, tmp9, tmp10, lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_14.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t.F___extmap, k__231000088__auto____1))) }; return lang.IPersistentMap_Cast(tmp1) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Size__I() int32 { return t.Count__I() }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z(0, int64(t.Count__I())) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { return lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)), lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_19.GetRawRoot__O()).Invoke_O__O(t))) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) KeySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_21.GetRawRoot__O()).Invoke_O__O(t))) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) Values__Collection() jrt.Collection { return jrt.Collection_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_19.GetRawRoot__O()).Invoke_O__O(t)) }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_A) EntrySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_PL_A_const_20.GetRawRoot__O()).Invoke_O__O(t)) }
//line :53:1
func A_arbace_repr_go_print_code_PL_reify__74000021_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_print_code_PL_reify__74000021_A { t := &A_arbace_repr_go_print_code_PL_reify__74000021_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_print_code_PL_A_Init(); tmp1 = A_arbace_repr_go_print_code_PL_A_const_4; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_print_code_PL_A_Cast(gtarget__1).F_v } else { return t } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_print_code_PL_reify__74000021_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :53:1
func A_arbace_repr_go_print_code_PL_reify__74000023_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_print_code_PL_reify__74000023_A { t := &A_arbace_repr_go_print_code_PL_reify__74000023_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_print_code_PL_A_Init(); tmp1 = A_arbace_repr_go_print_code_PL_A_const_4; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_print_code_PL_A_Cast(gtarget__1).F_pos } else { return t } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_print_code_PL_reify__74000023_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :53:1
func A_arbace_repr_go_print_code_PL_reify__74000025_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_print_code_PL_reify__74000025_A { t := &A_arbace_repr_go_print_code_PL_reify__74000025_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_print_code_PL_A_Init(); tmp1 = A_arbace_repr_go_print_code_PL_A_const_4; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_print_code_PL_A_Cast(gtarget__1).F_text } else { return t } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_print_code_PL_reify__74000025_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :53:1
func A_arbace_repr_go_print_code_PL_reify__74000027_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_print_code_PL_reify__74000027_A { t := &A_arbace_repr_go_print_code_PL_reify__74000027_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_print_code_PL_A_Init(); tmp1 = A_arbace_repr_go_print_code_PL_A_const_4; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_print_code_PL_A_Cast(gtarget__1).F_parens } else { return t } }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :53:1
func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_print_code_PL_reify__74000027_A_New_IPersistentMap_O(m, t.F_gclass) }



















































































































type A_arbace_repr_go_print_code_PL_A struct{ jrt.Object; F_v, F_pos, F_text, F_parens, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_repr_go_print_code_PL_A) Is_IRecord() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IHashEq() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IObj() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_ILookup() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IKeywordLookup() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IPersistentMap() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Map() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Serializable() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IMeta() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Iterable() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Associative() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Counted() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_IPersistentCollection() {}

func (t *A_arbace_repr_go_print_code_PL_A) Is_Seqable() {}

var A_arbace_repr_go_print_code_PL_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_code_PL_A_const_0 *lang.Keyword

var A_arbace_repr_go_print_code_PL_A_const_1 *lang.Keyword

var A_arbace_repr_go_print_code_PL_A_const_2 *lang.Keyword

var A_arbace_repr_go_print_code_PL_A_const_3 *lang.Keyword

var A_arbace_repr_go_print_code_PL_A_const_4 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_5 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_6 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_7 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_8 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_9 any

var A_arbace_repr_go_print_code_PL_A_const_10 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_11 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_12 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_13 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_14 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_15 any

var A_arbace_repr_go_print_code_PL_A_const_16 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_17 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_18 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_19 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_20 *lang.Var

var A_arbace_repr_go_print_code_PL_A_const_21 *lang.Var

var A_arbace_repr_go_print_code_PL_A_init jrt.ClassInit

func A_arbace_repr_go_print_code_PL_A_Init() { if !A_arbace_repr_go_print_code_PL_A_init.Done() { A_arbace_repr_go_print_code_PL_A_init.Run(A_arbace_repr_go_print_code_PL_A_clinit) } }

func A_arbace_repr_go_print_code_PL_A_clinit() { A_arbace_repr_go_print_code_PL_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_222, 26); A_arbace_repr_go_print_code_PL_A_const_0 = lang.Keyword_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[4]); A_arbace_repr_go_print_code_PL_A_const_1 = lang.Keyword_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[5]); A_arbace_repr_go_print_code_PL_A_const_2 = lang.Keyword_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[6]); A_arbace_repr_go_print_code_PL_A_const_3 = lang.Keyword_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[7]); A_arbace_repr_go_print_code_PL_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[8]); A_arbace_repr_go_print_code_PL_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[9]); A_arbace_repr_go_print_code_PL_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[10]); A_arbace_repr_go_print_code_PL_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[11]); A_arbace_repr_go_print_code_PL_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[12]); A_arbace_repr_go_print_code_PL_A_const_9 = A_arbace_repr_go_print_code_PL_A_const_pool.A[13]; A_arbace_repr_go_print_code_PL_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[14]); A_arbace_repr_go_print_code_PL_A_const_11 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[15]); A_arbace_repr_go_print_code_PL_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[16]); A_arbace_repr_go_print_code_PL_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[17]); A_arbace_repr_go_print_code_PL_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[18]); A_arbace_repr_go_print_code_PL_A_const_15 = A_arbace_repr_go_print_code_PL_A_const_pool.A[19]; A_arbace_repr_go_print_code_PL_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[20]); A_arbace_repr_go_print_code_PL_A_const_17 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[21]); A_arbace_repr_go_print_code_PL_A_const_18 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[22]); A_arbace_repr_go_print_code_PL_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[23]); A_arbace_repr_go_print_code_PL_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[24]); A_arbace_repr_go_print_code_PL_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_code_PL_A_const_pool.A[25]) }

func (t *A_arbace_repr_go_print_code_PL_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_repr_go_print_code_PL_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.J2g_NotTranslated("abstract arbace.repr.go.print_code.PL.assocEx(Ljava/lang/Object;Ljava/lang/Object;)Larbace/lang/IPersistentMap;")) }

func (t *A_arbace_repr_go_print_code_PL_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_repr_go_print_code_PL_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_repr_go_print_code_PL_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_repr_go_print_code_PL_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_repr_go_print_code_PL_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_repr_go_print_code_PL_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_repr_go_print_code_PL_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_PL_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_PL_A_class }

func (t *A_arbace_repr_go_print_code_PL_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_PL_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_PL_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_PL_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_PL_A); return ok }

func A_arbace_repr_go_print_code_PL_A_Cast(x any) *A_arbace_repr_go_print_code_PL_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_PL_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_PL_A_class)) }; return v }



type A_arbace_repr_go_print_code_PL_reify__74000021_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Is_IObj() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Is_IMeta() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_PL_reify__74000021_A_class }

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_PL_reify__74000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000021_A); return ok }

func A_arbace_repr_go_print_code_PL_reify__74000021_A_Cast(x any) *A_arbace_repr_go_print_code_PL_reify__74000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_PL_reify__74000021_A_class)) }; return v }



type A_arbace_repr_go_print_code_PL_reify__74000023_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Is_IObj() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Is_IMeta() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_PL_reify__74000023_A_class }

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_PL_reify__74000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000023_A); return ok }

func A_arbace_repr_go_print_code_PL_reify__74000023_A_Cast(x any) *A_arbace_repr_go_print_code_PL_reify__74000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_PL_reify__74000023_A_class)) }; return v }



type A_arbace_repr_go_print_code_PL_reify__74000025_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Is_IObj() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Is_IMeta() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_PL_reify__74000025_A_class }

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_PL_reify__74000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000025_A); return ok }

func A_arbace_repr_go_print_code_PL_reify__74000025_A_Cast(x any) *A_arbace_repr_go_print_code_PL_reify__74000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_PL_reify__74000025_A_class)) }; return v }



type A_arbace_repr_go_print_code_PL_reify__74000027_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Is_IObj() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Is_IMeta() {}

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_PL_reify__74000027_A_class }

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_PL_reify__74000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_PL_reify__74000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000027_A); return ok }

func A_arbace_repr_go_print_code_PL_reify__74000027_A_Cast(x any) *A_arbace_repr_go_print_code_PL_reify__74000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_PL_reify__74000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_PL_reify__74000027_A_class)) }; return v }
