//line aot_arbace_repr_go_print_code.ae:1
package aot_arbace_repr_go_print_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A_New() *A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_code_A_const_3, A_arbace_repr_go_print_code_A_const_4, A_arbace_repr_go_print_code_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_code_eval74000008_fn__74000009_A_New() *A_arbace_repr_go_print_code_eval74000008_fn__74000009_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_eval74000008_fn__74000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_code_eval74000008_fn__74000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_code_eval74000008_fn__74000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_10), A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_9) }




























func A_arbace_repr_go_print_code_uses_grouped_QMARK__A_New() *A_arbace_repr_go_print_code_uses_grouped_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_uses_grouped_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_repr_go_print_code_uses_grouped_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_repr_go_print_code_uses_grouped_QMARK__A) Invoke_O_O__O(self, forms__0 any) any { var body_walk__2 *A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A = A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_212, false); A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A_fn_class = fncls__1d; tmp1 = fncls__1d } else { tmp1 = fncls__1 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :37:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(walk__2, forms__0))).Ref() }
//line :33:1
func A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A_New() *A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A) Invoke_O_O__O(self, x__1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1), A_arbace_repr_go_print_code_A_const_14); if
														jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1), A_arbace_repr_go_print_code_A_const_17, A_arbace_repr_go_print_code_A_const_18))); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)

		if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_19.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1) } else { tmp2 = x__1 }; return tmp1.Invoke_O_O__O(self, tmp2) } else { return and__1927000168__auto____4 } } } }










func A_arbace_repr_go_print_code_fail_A_New() *A_arbace_repr_go_print_code_fail_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_fail_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_repr_go_print_code_fail_A) Ctor() {}
//line :47:1
func (t *A_arbace_repr_go_print_code_fail_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_A_const_22; var tmp2 any = A_arbace_repr_go_print_code_A_const_17; var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_20.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, msg__0, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_21.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, form__1, tmp2, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__1)))))))) }





func A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A_New() *A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A) Ctor() {}
//line :53:1
func (t *A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A) Invoke_O_O_O_O_O__O(self, v__1, pos__2, text__3, parens__4 any) any { return A_arbace_repr_go_print_code_PL_A_New_O_O_O_O(v__1, pos__2, text__3, parens__4) }
//line :53:1
func A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A_New() *A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A) Ctor() {}
//line :53:1
func (t *A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), m__231000174__auto____1) }; return A_arbace_repr_go_print_code_PL_A_Create_IPersistentMap__A_arbace_repr_go_print_code_PL_A(lang.IPersistentMap_Cast(tmp1)).Ref() }

func A_arbace_repr_go_print_code_pl_QMARK__A_New() *A_arbace_repr_go_print_code_pl_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_pl_QMARK__A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_code_pl_QMARK__A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_code_pl_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(A_arbace_repr_go_print_code_PL_A_InstanceOf(x__0)).Ref() }




func A_arbace_repr_go_print_code_fp_A_New() *A_arbace_repr_go_print_code_fp_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_fp_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_repr_go_print_code_fp_A) Ctor() {}
//line :60:1
func (t *A_arbace_repr_go_print_code_fp_A) Invoke_O_O_O__O(self, f__0, k__1 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)), k__1) } else { return nil
	} }
func A_arbace_repr_go_print_code_ptok_A_New() *A_arbace_repr_go_print_code_ptok_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_ptok_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_repr_go_print_code_ptok_A) Ctor() {}
//line :65:1
func (t *A_arbace_repr_go_print_code_ptok_A) Invoke_O_O_O__O(self, s__0, pos__1 any) any {


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_28.GetRawRoot__O()).Invoke_O__O(pos__1)
	return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(s__0)
}
func A_arbace_repr_go_print_code_ptok_STAR__A_New() *A_arbace_repr_go_print_code_ptok_STAR__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_ptok_STAR__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_repr_go_print_code_ptok_STAR__A) Ctor() {}
//line :71:1
func (t *A_arbace_repr_go_print_code_ptok_STAR__A) Invoke_O_O_O__O(self, s__0, pos__1 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(s__0, pos__1)
}
func A_arbace_repr_go_print_code_child_pos_A_New() *A_arbace_repr_go_print_code_child_pos_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_child_pos_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_repr_go_print_code_child_pos_A) Ctor() {}
//line :76:1
func (t *A_arbace_repr_go_print_code_child_pos_A) Invoke_O_O_O__O(self, f__0, i__1 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_30; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)), i__1) } else { return nil
	} }
func A_arbace_repr_go_print_code_wrap_full_A_New() *A_arbace_repr_go_print_code_wrap_full_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_wrap_full_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_repr_go_print_code_wrap_full_A) Ctor() {}
//line :81:1
func (t *A_arbace_repr_go_print_code_wrap_full_A) Invoke_O_O__O(self, x__0 any) any { var wrap_meta__2 any; var tmp1 any = A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A_fn_class; if




	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_217, false); A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; wrap_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any; var or__1927000174__auto____3 any =


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0); if
	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(x__0) }; if /*line :89:1*/ jrt.J2g_Truth(tmp3) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var apos__4 any = A_arbace_repr_go_print_code_A_const_30.Invoke_O__O(m__3); var atext__5 any = A_arbace_repr_go_print_code_A_const_37.Invoke_O__O(m__3); var apar__6 any = A_arbace_repr_go_print_code_A_const_38.Invoke_O__O(m__3); var kids__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_code_wrap_full_fn__74000044_A_New_O_O_O(atext__5, apos__4, apar__6); var tmp6 *jrt.Class
		var fncls__3 /*line :89:1*/*jrt.Class = A_arbace_repr_go_print_code_wrap_full_fn__74000044_A_fn_class



		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_repr_go_print_code_wrap_full_fn__74000044_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; kids__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), x__0)






		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_40.GetRawRoot__O()); var tmp8 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0)) { tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_48.GetRawRoot__O(), kids__7) } else { tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(kids__7) }; return tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(wrap_meta__2).Invoke_O__O(m__3)) } else {
//line :89:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(x__0)) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var tmp9 any; var or__1927000174__auto____4 any = A_arbace_repr_go_print_code_A_const_31.Invoke_O__O(m__3_2)












				if jrt.J2g_Truth(or__1927000174__auto____4) { tmp9 = or__1927000174__auto____4 } else { tmp9 = A_arbace_repr_go_print_code_A_const_33.Invoke_O__O(m__3_2) }; if jrt.J2g_Truth(tmp9) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_40.GetRawRoot__O()).Invoke_O_O__O(x__0, lang.IFn_Cast(wrap_meta__2).Invoke_O__O(m__3_2)) } else { return x__0 } } else {
//line :89:1
					if A_arbace_repr_go_print_code_A_const_42 != nil { return x__0 } else { return nil } } } }
//line :86:1
func A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A_New() *A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A) Ctor() {}
//line :86:1
func (t *A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A) Invoke_O_O__O(self, m__1 any) any { var G__74000042__2_ any = m__1; var G__74000042__3_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_31.Invoke_O__O(m__1)) {
													var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_31; G__74000042__3_ = tmp1.Invoke_O_O_O__O(G__74000042__2_, tmp2, A_arbace_repr_go_print_code_A_const_34.GetRawRoot__O()) } else {
//line :86:1
		G__74000042__3_ = G__74000042__2_ }; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_33.Invoke_O__O(m__1)) {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_32.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_A_const_33; return tmp3.Invoke_O_O_O__O(G__74000042__3_, tmp4, A_arbace_repr_go_print_code_A_const_34.GetRawRoot__O()) } else {
//line :86:1
				return G__74000042__3_ } }






func A_arbace_repr_go_print_code_wrap_full_fn__74000044_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_wrap_full_fn__74000044_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_wrap_full_fn__74000044_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :93:1
func (t *A_arbace_repr_go_print_code_wrap_full_fn__74000044_A) Ctor_O_O_O(c__atext, c__apos, c__apar any) { t.F_atext = c__atext; t.F_apos = c__apos; t.F_apar = c__apar }
//line :93:1
func (t *A_arbace_repr_go_print_code_wrap_full_fn__74000044_A) Invoke_O_O_O__O(self, i__1, c__2 any) any { var c__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_34.GetRawRoot__O()).Invoke_O__O(c__2); var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(t.F_apos, i__1); if

	jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(c__3)); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(c__3)); if jrt.J2g_Truth(and__1927000168__auto____6) {
		tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_13.GetRawRoot__O()).Invoke_O__O(c__3)) } else {
//line :95:1
			tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(c__3, lang.RT_Get_O_O__O_NoInit(t.F_apos, i__1), lang.RT_Get_O_O__O_NoInit(t.F_atext, i__1), lang.RT_Get_O_O__O_NoInit(t.F_apar, i__1)) } else {
//line :95:1
					return c__3 } }









func A_arbace_repr_go_print_code_with_parens_A_New() *A_arbace_repr_go_print_code_with_parens_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_with_parens_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_repr_go_print_code_with_parens_A) Ctor() {}
//line :105:1
func (t *A_arbace_repr_go_print_code_with_parens_A) Invoke_O_O_O__O(self, ps__0, body__1 any) any { { var seq_74000047__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(ps__0); var chunk_74000048__4 any; var count_74000049__5 int64 = 0; var i_74000050__6 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z_NoInit(i_74000050__6, count_74000049__5) { var vec__74000051__7 any = lang.Indexed_Cast(chunk_74000048__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000050__6)); var lp__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000051__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000051__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lp__8); seq_74000047__3, chunk_74000048__4, count_74000049__5, i_74000050__6 = seq_74000047__3, chunk_74000048__4, count_74000049__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000050__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000047__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_74000047__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000047__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000047__8); seq_74000047__3, chunk_74000048__4, count_74000049__5, i_74000050__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000047__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000054__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000047__8); var lp__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000054__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000054__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lp__10); seq_74000047__3, chunk_74000048__4, count_74000049__5, i_74000050__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000047__8), nil, 0, 0; continue L1 } } }
//line :105:1
	break L1
}


	lang.IFn_Cast(body__1).Invoke__O()
//line :105:1
	var seq_74000057__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_55.GetRawRoot__O()).Invoke_O__O(ps__0)); var chunk_74000058__4 any; var count_74000059__5 int64 = 0; var i_74000060__6 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_74000060__6, count_74000059__5) { var vec__74000061__7 any = lang.Indexed_Cast(chunk_74000058__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000060__6)); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000061__7, lang.RT_IntCast_J__I_NoInit(0), nil); var rp__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000061__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, rp__9); seq_74000057__3, chunk_74000058__4, count_74000059__5, i_74000060__6 = seq_74000057__3, chunk_74000058__4, count_74000059__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000060__6); continue L2 } else { var temp__1927000414__auto____7_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000057__3); if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_74000057__8 any = temp__1927000414__auto____7_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000057__8)) { var c__1927000678__auto____9_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000057__8); seq_74000057__3, chunk_74000058__4, count_74000059__5, i_74000060__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000057__8), c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__74000064__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000057__8); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000064__9, lang.RT_IntCast_J__I_NoInit(0), nil); var rp__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000064__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___10; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, rp__11); seq_74000057__3, chunk_74000058__4, count_74000059__5, i_74000060__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000057__8), nil, 0, 0; continue L2 } } else { return nil } } } }; /*line :105:1*/panic("j2g: unreachable") }









func A_arbace_repr_go_print_code_op_A_New() *A_arbace_repr_go_print_code_op_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_op_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_go_print_code_op_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_go_print_code_op_A) Invoke_O_O__O(self, f__0 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)) { var h__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(h__2)) { var n__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(h__2)

			if lang.Util_Identical_O_O__Z_NoInit(n__3, nil) {
				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(h__2) } else {
//line :124:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_58.Get__O()).Invoke_O__O(n__3)) {

						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_155, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(h__2))).Ref() } else {
//line :124:1
							var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(h__2), Lit_156)


							if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_59).Invoke_O__O(n__3) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }
//line :124:1
							if jrt.J2g_Truth(tmp1) { return Lit_156 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { return nil } else { return nil } } } } } else {
//line :122:1
								return nil } } else {
//line :120:1
									return nil
								}
}


























func A_arbace_repr_go_print_code_args_A_New() *A_arbace_repr_go_print_code_args_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_args_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_repr_go_print_code_args_A) Ctor() {}
//line :149:1
func (t *A_arbace_repr_go_print_code_args_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0) }

func A_arbace_repr_go_print_code_binary_QMARK__A_New() *A_arbace_repr_go_print_code_binary_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binary_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_repr_go_print_code_binary_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_repr_go_print_code_binary_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_61.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(f__0)), 3)).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_code_negative_literal_QMARK__A_New() *A_arbace_repr_go_print_code_negative_literal_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_negative_literal_QMARK__A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_repr_go_print_code_negative_literal_QMARK__A) Ctor() {}
//line :156:1
func (t *A_arbace_repr_go_print_code_negative_literal_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_63.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_64.GetRawRoot__O()).Invoke_O__O(f__0) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_code_unary_QMARK__A_New() *A_arbace_repr_go_print_code_unary_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_unary_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_repr_go_print_code_unary_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_repr_go_print_code_unary_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(f__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_66.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(and__1927000168__auto____4) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(f__0)), 2)).Ref() } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } }

func A_arbace_repr_go_print_code_unary_op_A_New() *A_arbace_repr_go_print_code_unary_op_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_unary_op_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_repr_go_print_code_unary_op_A) Ctor() {}
//line :164:1
func (t *A_arbace_repr_go_print_code_unary_op_A) Invoke_O_O__O(self, f__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(f__0)) { return Lit_160 } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)) } }

func A_arbace_repr_go_print_code_unary_operand_A_New() *A_arbace_repr_go_print_code_unary_operand_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_unary_operand_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_repr_go_print_code_unary_operand_A) Ctor() {}
//line :166:1
func (t *A_arbace_repr_go_print_code_unary_operand_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(f__0)) {
		if jrt.Double_InstanceOf(f__0) { return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D_NoInit(f__0))).Ref() } else { var na_4 any = f__0; if jrt.Long_InstanceOf(na_4) { var n0_5 int64 = jrt.NN(jrt.Long_Cast(na_4)).LongValue__J(); if n0_5 == -9223372036854775808 { return lang.Numbers_MinusP_O__Number_NoInit(na_4) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_5).Ref() } } else { if jrt.Double_InstanceOf(na_4) { var n0_5_2 float64 = jrt.NN(jrt.Double_Cast(na_4)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_5_2).Ref() } else { return lang.Numbers_MinusP_O__Number_NoInit(na_4) } } } } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)
		} }
func A_arbace_repr_go_print_code_bin_op_A_New() *A_arbace_repr_go_print_code_bin_op_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_bin_op_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_repr_go_print_code_bin_op_A) Ctor() {}
//line :171:1
func (t *A_arbace_repr_go_print_code_bin_op_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0))) }
func A_arbace_repr_go_print_code_bin_prec_A_New() *A_arbace_repr_go_print_code_bin_prec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_bin_prec_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_print_code_bin_prec_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_print_code_bin_prec_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0))) }

func A_arbace_repr_go_print_code_prec_of_A_New() *A_arbace_repr_go_print_code_prec_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_prec_of_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_repr_go_print_code_prec_of_A) Ctor() {}
//line :174:1
func (t *A_arbace_repr_go_print_code_prec_of_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O()).Invoke_O__O(f__0)) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(f__0) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_70.GetRawRoot__O()).Invoke_O__O(f__0)) { return A_arbace_repr_go_print_code_A_const_71 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { return A_arbace_repr_go_print_code_A_const_72 } else { return nil
	} } } }
func A_arbace_repr_go_print_code_go_sym_QMARK__A_New() *A_arbace_repr_go_print_code_go_sym_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_go_sym_QMARK__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_repr_go_print_code_go_sym_QMARK__A) Ctor() {}
//line :179:1
func (t *A_arbace_repr_go_print_code_go_sym_QMARK__A) Invoke_O_O__O(self, f__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_84)).Ref() }

func A_arbace_repr_go_print_code_statement_form_QMARK__A_New() *A_arbace_repr_go_print_code_statement_form_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_statement_form_QMARK__A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_repr_go_print_code_statement_form_QMARK__A) Ctor() {}
//line :181:1
func (t *A_arbace_repr_go_print_code_statement_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if
												jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_73.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_code_expression_form_QMARK__A_New() *A_arbace_repr_go_print_code_expression_form_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expression_form_QMARK__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_repr_go_print_code_expression_form_QMARK__A) Ctor() {}
//line :184:1
func (t *A_arbace_repr_go_print_code_expression_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_74.GetRawRoot__O()).Invoke_O__O(f__0)); if


	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_112)).Ref() } else { tmp2 = and__1927000168__auto____3_2 }; and__1927000168__auto____3 = tmp1.Invoke_O__O(tmp2)
//line :187:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(and__1927000168__auto____4) {

			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :187:1
				return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_code_line_of_A_New() *A_arbace_repr_go_print_code_line_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_line_of_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_repr_go_print_code_line_of_A) Ctor() {}
//line :191:1
func (t *A_arbace_repr_go_print_code_line_of_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____2)) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }

func A_arbace_repr_go_print_code_breaks_of_A_New() *A_arbace_repr_go_print_code_breaks_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_breaks_of_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_code_breaks_of_A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_code_breaks_of_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_77.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_breaks_of_fn__74000083_A_New(); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_print_code_breaks_of_fn__74000083_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_print_code_breaks_of_fn__74000083_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_79; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)))) }
//line :197:1
func A_arbace_repr_go_print_code_breaks_of_fn__74000083_A_New() *A_arbace_repr_go_print_code_breaks_of_fn__74000083_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_breaks_of_fn__74000083_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_code_breaks_of_fn__74000083_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_code_breaks_of_fn__74000083_A) Invoke_O_O__O(self, p1__74000082_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(p1__74000082_SHARP___1)) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(p1__74000082_SHARP___1) } else { return p1__74000082_SHARP___1 } }

func A_arbace_repr_go_print_code_break_line_A_New() *A_arbace_repr_go_print_code_break_line_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_break_line_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_go_print_code_break_line_A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_go_print_code_break_line_A) Invoke_O_O_O__O(self, parent__0, i__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_break_line_fn__74000087_A_New_O(i__1); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_print_code_break_line_fn__74000087_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_go_print_code_break_line_fn__74000087_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_79; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(parent__0))) }
//line :202:1
func A_arbace_repr_go_print_code_break_line_fn__74000087_A_New_O(p0 any) *A_arbace_repr_go_print_code_break_line_fn__74000087_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_break_line_fn__74000087_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_repr_go_print_code_break_line_fn__74000087_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :202:1
func (t *A_arbace_repr_go_print_code_break_line_fn__74000087_A) Invoke_O_O__O(self, p1__74000086_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(p1__74000086_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(p1__74000086_SHARP___1), t.F_i)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(p1__74000086_SHARP___1) } else { return nil } }

func A_arbace_repr_go_print_code_child_target_A_New() *A_arbace_repr_go_print_code_child_target_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_child_target_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_repr_go_print_code_child_target_A) Ctor() {}
//line :204:1
func (t *A_arbace_repr_go_print_code_child_target_A) Invoke_O_O_O_O_O__O(self, parent__0, i__1, child__2, brk__3 any) any { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(child__2); if




	jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {
		var tmp1 any; var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____6 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = parent__0; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()); var tmp4 any; var or__1927000174__auto____8 any = brk__3; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { tmp4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_83.GetRawRoot__O()).Invoke_O__O(parent__0) }; tmp1 = tmp3.Invoke_O_O__O(tmp4, i__1) } else { tmp1 = and__1927000168__auto____7 } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_81.GetRawRoot__O()).Invoke_O_O__O(parent__0, i__1)
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { return A_arbace_repr_go_print_code_A_const_82 } } else {
//line :210:1
				return nil } } }
//line :204:1
func (t *A_arbace_repr_go_print_code_child_target_A) Invoke_O_O_O_O__O(self, parent__0, i__1, child__2 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()).Invoke_O_O_O_O__O(parent__0, i__1, child__2, nil)
}




func A_arbace_repr_go_print_code_next_targets_A_New() *A_arbace_repr_go_print_code_next_targets_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_next_targets_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_repr_go_print_code_next_targets_A) Ctor() {}
//line :213:1
func (t *A_arbace_repr_go_print_code_next_targets_A) Invoke_O_O__O(self, ts__0 any) any { var ts__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(ts__0); var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var out__4 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = lang.Numbers_Dec_J__J_NoInit(int64(n__3)); var nxt__6 any; L1: for {






	if lang.Numbers_Gte_J_J__Z_NoInit(i__5, 0) {
		lang.RT_Aset_O1_I_O__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](out__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5), nxt__6)
		var tmp1 int64 = lang.Numbers_Dec_J__J_NoInit(i__5); var tmp2 any; var t__7 any = lang.RT_Nth_O_I__O_NoInit(ts__2, lang.RT_IntCast_J__I_NoInit(i__5)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t__7)) { tmp2 = t__7 } else { tmp2 = nxt__6 }; i__5, nxt__6 = tmp1, tmp2; continue L1 }
//line :213:1
	break L1 }; return /*line :223:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(out__4) }

func A_arbace_repr_go_print_code_room_QMARK__A_New() *A_arbace_repr_go_print_code_room_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_room_QMARK__A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_repr_go_print_code_room_QMARK__A) Ctor() {}
//line :225:1
func (t *A_arbace_repr_go_print_code_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_85.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_repr_go_print_code_body_offset_A_New() *A_arbace_repr_go_print_code_body_offset_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_body_offset_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repr_go_print_code_body_offset_A) Ctor() {}
//line :227:1
func (t *A_arbace_repr_go_print_code_body_offset_A) Invoke_O_O_O__O(self, f__0, body__1 any) any {

	return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(f__0)), int64(lang.RT_Count_O__I_NoInit(body__1)))).Ref()
}
func A_arbace_repr_go_print_code_next_line_A_New() *A_arbace_repr_go_print_code_next_line_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_next_line_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_repr_go_print_code_next_line_A) Ctor() {}
//line :231:1
func (t *A_arbace_repr_go_print_code_next_line_A) Invoke_O_O__O(self, forms__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O(), forms__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_repr_go_print_code_A_const_86.Get__O() } }

func A_arbace_repr_go_print_code_comma_list_A_New() *A_arbace_repr_go_print_code_comma_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_comma_list_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_repr_go_print_code_comma_list_A) Ctor() {}
//line :236:1
func (t *A_arbace_repr_go_print_code_comma_list_A) Invoke_O_O_O_O_O__O(self, parent__0, offset__1, xs__2, print_one__3 any) any { { var xs__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(xs__2); var ts__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_comma_list_fn__74000095_A_New_O_O(parent__0, offset__1); var tmp3 *jrt.Class
																var fncls__13 /*line :236:1*/*jrt.Class = A_arbace_repr_go_print_code_comma_list_fn__74000095_A_fn_class





	if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_go_print_code_comma_list_fn__74000095_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; ts__6 = tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__5)).Ref()), xs__5)
//line :236:1
	var n__1927000701__auto____7 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(xs__5)); var i__8 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i__8, n__1927000701__auto____7) {
			if lang.Numbers_IsPos_J__Z_NoInit(i__8) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ts__6, lang.RT_IntCast_J__I_NoInit(i__8))) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_code_A_const_86; var tmp7 any; var t__9 any = lang.RT_Get_O_O__O_NoInit(ts__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__8)).Ref()); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t__9)) { tmp7 = t__9 } else { tmp7 = A_arbace_repr_go_print_code_A_const_86.Get__O() }; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7)); var tmp8 any = A_arbace_repr_go_print_code_comma_list_fn__74000097_A_New_J_O_O(i__8, print_one__3, xs__5); var tmp9 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_print_code_comma_list_fn__74000097_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_go_print_code_comma_list_fn__74000097_A_fn_class = fncls__14d; tmp9 = fncls__14d } else { tmp9 = fncls__14 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :243:1
			i__8 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__8); continue L1 } else { return nil } } }; /*line :236:1*/panic("j2g: unreachable") }





func A_arbace_repr_go_print_code_comma_list_fn__74000095_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_comma_list_fn__74000095_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_comma_list_fn__74000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :242:1
func (t *A_arbace_repr_go_print_code_comma_list_fn__74000095_A) Ctor_O_O(c__parent, c__offset any) { t.F_parent = c__parent; t.F_offset = c__offset }
//line :242:1
func (t *A_arbace_repr_go_print_code_comma_list_fn__74000095_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()); var tmp2 any = t.F_parent; var tmp3 jrt.Number_I; var na_8 any = i__1; var na_9 any = t.F_offset; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_8); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_9) }; tmp4 = tmp5; if tmp4 { var n0_10 int64 = jrt.NN(jrt.Long_Cast(na_8)).LongValue__J(); var n1_11 int64 = jrt.NN(jrt.Long_Cast(na_9)).LongValue__J(); var nr_12 int64 = n0_10 + n1_11; if (n0_10^nr_12)&(n1_11^nr_12) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_12)) } else { tmp3 = lang.Numbers_Add_O_O__Number_NoInit(na_8, na_9) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_8); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_9) }; tmp6 = tmp7; if tmp6 { var n0_10_2 float64 = jrt.NN(jrt.Double_Cast(na_8)).DoubleValue__D(); var n1_11_2 float64 = jrt.NN(jrt.Double_Cast(na_9)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_10_2 + n1_11_2)) } else { tmp3 = lang.Numbers_Add_O_O__Number_NoInit(na_8, na_9) } }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, x__2) }


func A_arbace_repr_go_print_code_comma_list_fn__74000097_A_New_J_O_O(p0 int64, p1, p2 any) *A_arbace_repr_go_print_code_comma_list_fn__74000097_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_comma_list_fn__74000097_A{}; t.Ctor_J_O_O(p0, p1, p2); return t }
//line :245:1
func (t *A_arbace_repr_go_print_code_comma_list_fn__74000097_A) Ctor_J_O_O(c__i int64, c__print_one, c__xs any) { t.F_i = c__i; t.F_print_one = c__print_one; t.F_xs = c__xs }
//line :245:1
func (t *A_arbace_repr_go_print_code_comma_list_fn__74000097_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var t_ any = t.F_print_one; t.F_print_one = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(t.F_i))) }
//line :245:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }





func A_arbace_repr_go_print_code_ident_string_A_New() *A_arbace_repr_go_print_code_ident_string_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_ident_string_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_repr_go_print_code_ident_string_A) Ctor() {}
//line :251:1
func (t *A_arbace_repr_go_print_code_ident_string_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)) { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(f__0)
		if jrt.J2g_Truth(temp__1927000408__auto____2) { var n__3 any = temp__1927000408__auto____2; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_81, nil), jrt.RefArrayOf(jrt.Object_class, n__3, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(f__0))).Ref() } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(f__0) } } else {
//line :254:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(f__0)) {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :254:1
					if A_arbace_repr_go_print_code_A_const_42 != nil {


						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_136, f__0) } else {
//line :254:1
							return nil
						}
				}
		}
}
func A_arbace_repr_go_print_code_name_tok_A_New() *A_arbace_repr_go_print_code_name_tok_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_name_tok_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_repr_go_print_code_name_tok_A) Ctor() {}
//line :259:1
func (t *A_arbace_repr_go_print_code_name_tok_A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; var p__2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)

		if jrt.J2g_Truth(and__1927000168__auto____3) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(f__0) } else { tmp3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp3) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_97.Invoke_O__O(p__2)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, A_arbace_repr_go_print_code_A_const_98.Invoke_O__O(p__2)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_99.Invoke_O__O(p__2)) } else {
				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_100.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_99.Invoke_O__O(p__2)) } } else {
					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_100.GetRawRoot__O()).Invoke_O__O(f__0))
				} }
func A_arbace_repr_go_print_code_name_list_A_New() *A_arbace_repr_go_print_code_name_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_name_list_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_print_code_name_list_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_print_code_name_list_A) Invoke_O_O__O(self, nms__0 any) any { { var seq_74000102__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), nms__0)); var chunk_74000103__3 any; var count_74000104__4 int64 = 0; var i_74000105__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i_74000105__5, count_74000104__4) { var vec__74000106__6 any = lang.Indexed_Cast(chunk_74000103__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000105__5)); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000106__6, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000106__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_15 any = i__7
		if jrt.Long_InstanceOf(na_15) { var n0_16 int64 = jrt.NN(jrt.Long_Cast(na_15)).LongValue__J(); tmp1 = n0_16 > 0 } else { if jrt.Double_InstanceOf(na_15) { var n0_16_2 float64 = jrt.NN(jrt.Double_Cast(na_15)).DoubleValue__D(); tmp1 = n0_16_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_15) } }; if tmp1 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(nm__8)) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(nm__8)
//line :274:1
		seq_74000102__2, chunk_74000103__3, count_74000104__4, i_74000105__5 = seq_74000102__2, chunk_74000103__3, count_74000104__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000105__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000102__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_74000102__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000102__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000102__7); seq_74000102__2, chunk_74000103__3, count_74000104__4, i_74000105__5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000102__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000109__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000102__7); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000109__8, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000109__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 bool; var na_17 any = i__9
			if jrt.Long_InstanceOf(na_17) { var n0_18 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); tmp2 = n0_18 > 0 } else { if jrt.Double_InstanceOf(na_17) { var n0_18_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); tmp2 = n0_18_2 > 0.0 } else { tmp2 = lang.Numbers_IsPos_O__Z_NoInit(na_17) } }; if tmp2 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(nm__10)) }
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(nm__10)
//line :274:1
			seq_74000102__2, chunk_74000103__3, count_74000104__4, i_74000105__5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000102__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :269:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_code_group_line_A_New() *A_arbace_repr_go_print_code_group_line_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_line_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_repr_go_print_code_group_line_A) Ctor() {}
//line :278:1
func (t *A_arbace_repr_go_print_code_group_line_A) Invoke_O_O__O(self, g__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__0)); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(g__0) }; return tmp1.Invoke_O__O(tmp2)
}
func A_arbace_repr_go_print_code_label_name_A_New() *A_arbace_repr_go_print_code_label_name_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_label_name_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_repr_go_print_code_label_name_A) Ctor() {}
//line :283:1
func (t *A_arbace_repr_go_print_code_label_name_A) Invoke_O_O__O(self, k__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(k__0)) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(k__0) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_145, k__0)
	} }
func A_arbace_repr_go_print_code_literal_A_New() *A_arbace_repr_go_print_code_literal_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_literal_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_repr_go_print_code_literal_A) Ctor() {}
//line :286:1
func (t *A_arbace_repr_go_print_code_literal_A) DoInvoke_O_O_O__O(self, f__0, p__74000115__1 any) any { var vec__74000116__3 any = p__74000115__1; var spelling__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000116__3, lang.RT_IntCast_J__I_NoInit(0), nil); if
													jrt.J2g_Truth(spelling__4) {
														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(spelling__4) } else {
//line :287:1
			if lang.Util_Identical_O_O__Z_NoInit(f__0, nil) {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_30) } else {
//line :287:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_105.GetRawRoot__O()).Invoke_O__O(f__0)) {


						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_149) } else {
//line :287:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_106.GetRawRoot__O()).Invoke_O__O(f__0)) {



								return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_150) } else {
//line :287:1
									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(f__0)) { var nl_QMARK___5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_108.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_151); var tmp1 any
										var and__1927000168__auto____6 any = nl_QMARK___5







										if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(f__0) } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) {
											return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_152), jrt.RefArrayOf(jrt.Object_class, nil, f__0, nil)).Ref()) } else {
												return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_112.GetRawRoot__O()).Invoke_O__O(f__0)) } } else {
//line :287:1
													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_111.GetRawRoot__O()).Invoke_O__O(f__0)) {











														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_113.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(f__0))).Ref())) } else {
//line :287:1
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_63.GetRawRoot__O()).Invoke_O__O(f__0)) {












																return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_114.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :287:1
																	if A_arbace_repr_go_print_code_A_const_42 != nil {













																		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_153, f__0) } else {
//line :287:1
																			return nil } } } } } } } } }


















func A_arbace_repr_go_print_code_element_list_A_New() *A_arbace_repr_go_print_code_element_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_element_list_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_repr_go_print_code_element_list_A) Ctor() {}
//line :306:1
func (t *A_arbace_repr_go_print_code_element_list_A) Invoke_O_O_O_O_O_O__O(self, open__0, close__1, xs__2, print_one__3, p__74000120__4 any) any { var default__74000123__6 int64 = 1; var map__74000121__7 any = p__74000120__4; var map__74000121__8 any; if lang.ISeq_InstanceOf(map__74000121__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(map__74000121__7)) { map__74000121__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_115.GetRawRoot__O()).Invoke_O__O(map__74000121__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(map__74000121__7)) { map__74000121__8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(map__74000121__7) } else { map__74000121__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__74000121__8 = map__74000121__7 }; var parent__9 any = lang.RT_Get_O_O__O_NoInit(map__74000121__8, A_arbace_repr_go_print_code_A_const_116); var tmp1 any = A_arbace_repr_go_print_code_A_const_117; var offset__10 any = lang.RT_Get_O_O_O__O_NoInit(map__74000121__8, tmp1, jrt.Long_ValueOf_J__Long_NoInit(default__74000123__6).Ref()); var end__11 any = lang.RT_Get_O_O__O_NoInit(map__74000121__8, A_arbace_repr_go_print_code_A_const_118); var target__12 any = lang.RT_Get_O_O__O_NoInit(map__74000121__8, A_arbace_repr_go_print_code_A_const_119); var open_pos__13 any = lang.RT_Get_O_O__O_NoInit(map__74000121__8, A_arbace_repr_go_print_code_A_const_120); var close_pos__14 any = lang.RT_Get_O_O__O_NoInit(map__74000121__8, A_arbace_repr_go_print_code_A_const_121);







	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(open__0, open_pos__13);
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke__O(); var tmp2 /*line :306:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var start__15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var xs__16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(xs__2); var n__17 int32 = lang.RT_Count_O__I_NoInit(xs__16); var brk__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_83.GetRawRoot__O()).Invoke_O__O(parent__9); var ts__19 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_element_list_fn__74000125_A_New_O_O_O_O(parent__9, target__12, brk__18, offset__10); var tmp5 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_print_code_element_list_fn__74000125_A_fn_class; if













	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_repr_go_print_code_element_list_fn__74000125_A_fn_class = fncls__29d; tmp5 = fncls__29d } else { tmp5 = fncls__29 }; ts__19 = tmp3.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__17).Ref()), xs__16); var nxt__20 any = /*line :306:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_122.GetRawRoot__O()).Invoke_O__O(ts__19); var n__1927000701__auto____21 int64 = lang.RT_LongCast_I__J_NoInit(n__17); var i__22 int64 = 0; L1: for {


















		if lang.Numbers_Lt_J_J__Z_NoInit(i__22, n__1927000701__auto____21) { var x__23 any = lang.RT_Nth_O_I__O_NoInit(xs__16, lang.RT_IntCast_J__I_NoInit(i__22)); var t__24 any = lang.RT_Nth_O_I__O_NoInit(ts__19, lang.RT_IntCast_J__I_NoInit(i__22))


			if lang.Numbers_IsPos_J__Z_NoInit(i__22) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(t__24)
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_print_code_A_const_86; var tmp9 any; var or__1927000174__auto____25 any = lang.RT_Nth_O_I__O_NoInit(nxt__20, lang.RT_IntCast_J__I_NoInit(i__22)); if jrt.J2g_Truth(or__1927000174__auto____25) { tmp9 = or__1927000174__auto____25 } else { tmp9 = A_arbace_repr_go_print_code_A_const_86.Get__O() }; tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9)); var tmp10 any = A_arbace_repr_go_print_code_element_list_fn__74000127_A_New_O_O_J(x__23, print_one__3, i__22); var tmp11 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_print_code_element_list_fn__74000127_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_go_print_code_element_list_fn__74000127_A_fn_class = fncls__30d; tmp11 = fncls__30d } else { tmp11 = fncls__30 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :325:1
			i__22 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__22); continue L1 }
//line :306:1
		break L1 }; var indent__21 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O(); var multi_QMARK___22 bool; var tmp12 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var na_20 any = start__15; var tmp13 bool; var tmp14 bool; tmp14 =


























	jrt.Long_InstanceOf(na_19); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_20) }; tmp13 = tmp14; if tmp13 { var n0_21 int64 = jrt.NN(jrt.Long_Cast(na_19)).LongValue__J(); var n1_22 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); multi_QMARK___22 = n0_21 > n1_22 } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_19); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_20) }; tmp15 = tmp16; if tmp15 { var n0_21_2 float64 = jrt.NN(jrt.Double_Cast(na_19)).DoubleValue__D(); var n1_22_2 float64 = jrt.NN(jrt.Double_Cast(na_20)).DoubleValue__D(); multi_QMARK___22 = n1_22_2 < n0_21_2 } else { multi_QMARK___22 = lang.Numbers_Gt_O_O__Z_NoInit(na_19, na_20) } }; var end__23 any; var tmp17 any; var or__1927000174__auto____23 bool = /*line :306:1*/lang.Util_Equiv_O_O__Z_NoInit(end__11, A_arbace_repr_go_print_code_A_const_124); if or__1927000174__auto____23 {





























		tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____23).Ref() } else { var and__1927000168__auto____24 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(n__17)); if and__1927000168__auto____24 { var and__1927000168__auto____25 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(xs__16)), Lit_72); if and__1927000168__auto____25 { var tmp18 *lang.Keyword = A_arbace_repr_go_print_code_A_const_125; tmp17 = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(xs__16))) } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____25).Ref() } } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() } }; if jrt.J2g_Truth(tmp17) {
			var tmp19 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; end__23 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else {
//line :336:1
				end__23 = end__11 }; var tmp20 any; var tmp21 /*line :339:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____24_2 any = tmp21.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____24_2) { var and__1927000168__auto____25_2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(n__17)); if and__1927000168__auto____25_2 { var or__1927000174__auto____26 any; var and__1927000168__auto____26 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(end__23)
					if jrt.J2g_Truth(and__1927000168__auto____26) { var tmp22 bool; var na_31 int64 = lang.RT_LongCast_O__J_NoInit(end__23); var tmp23 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_32 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_32) { var n0_33 int64 = na_31; var n1_34 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); tmp22 = n0_33 > n1_34 } else { tmp22 = lang.Numbers_Gt_J_O__Z_NoInit(na_31, na_32) }; or__1927000174__auto____26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp22).Ref() } else { or__1927000174__auto____26 = and__1927000168__auto____26 }; if jrt.J2g_Truth(or__1927000174__auto____26) { tmp20 = or__1927000174__auto____26 } else { var and__1927000168__auto____27 bool = lang.Util_Identical_O_O__Z_NoInit(end__23, nil)
						if and__1927000168__auto____27 { var and__1927000168__auto____28 bool = multi_QMARK___22; if and__1927000168__auto____28 { tmp20 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_85.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_130) } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() } } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____27).Ref() } } } else {
//line :339:1
							tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____25_2).Ref() } } else { tmp20 = and__1927000168__auto____24_2 }; if jrt.J2g_Truth(tmp20) {


								lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41) }; if
	lang.Numbers_IsPos_J__Z_NoInit(int64(n__17)) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_131, Lit_41) };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()).Invoke_O_O_O_O__O(end__23, jrt.Boolean_ValueOf_Z__Boolean_NoInit(multi_QMARK___22).Ref(), jrt.Boolean_FALSE.Ref(), indent__21); return /*line :345:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(close__1, close_pos__14) }
//line :320:1
func A_arbace_repr_go_print_code_element_list_fn__74000125_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_print_code_element_list_fn__74000125_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_element_list_fn__74000125_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :320:1
func (t *A_arbace_repr_go_print_code_element_list_fn__74000125_A) Ctor_O_O_O_O(c__parent, c__target, c__brk, c__offset any) { t.F_parent = c__parent; t.F_target = c__target; t.F_brk = c__brk; t.F_offset = c__offset }
//line :320:1
func (t *A_arbace_repr_go_print_code_element_list_fn__74000125_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if jrt.J2g_Truth(t.F_parent) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()); var tmp2 any = t.F_parent; var tmp3 jrt.Number_I; var na_24 any = i__1; var na_25 any = t.F_offset; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_24); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_25) }; tmp4 = tmp5; if tmp4 { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); var n1_27 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); var nr_28 int64 = n0_26 + n1_27; if (n0_26^nr_28)&(n1_27^nr_28) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_28)) } else { tmp3 = lang.Numbers_Add_O_O__Number_NoInit(na_24, na_25) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_24); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_25) }; tmp6 = tmp7; if tmp6 { var n0_26_2 float64 = jrt.NN(jrt.Double_Cast(na_24)).DoubleValue__D(); var n1_27_2 float64 = jrt.NN(jrt.Double_Cast(na_25)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_26_2 + n1_27_2)) } else { tmp3 = lang.Numbers_Add_O_O__Number_NoInit(na_24, na_25) } }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, x__2, t.F_brk) } else { if jrt.J2g_Truth(t.F_target) {
														return lang.IFn_Cast(t.F_target).Invoke_O__O(x__2) } else {
//line :320:1
		if A_arbace_repr_go_print_code_A_const_42 != nil {

			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(x__2) } else {
//line :320:1
				return nil } } } }









func A_arbace_repr_go_print_code_element_list_fn__74000127_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_repr_go_print_code_element_list_fn__74000127_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_element_list_fn__74000127_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :330:1
func (t *A_arbace_repr_go_print_code_element_list_fn__74000127_A) Ctor_O_O_J(c__x, c__print_one any, c__i int64) { t.F_x = c__x; t.F_print_one = c__print_one; t.F_i = c__i }
//line :330:1
func (t *A_arbace_repr_go_print_code_element_list_fn__74000127_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var t_ any = t.F_print_one; t.F_print_one = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_x; t.F_x = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O_O__O(tmp4, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref()) }
//line :330:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }



















func A_arbace_repr_go_print_code_tagged_QMARK__A_New() *A_arbace_repr_go_print_code_tagged_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_tagged_QMARK__A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_repr_go_print_code_tagged_QMARK__A) Ctor() {}
//line :350:1
func (t *A_arbace_repr_go_print_code_tagged_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(x__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { and__1927000168__auto____2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(x__0) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0), A_arbace_repr_go_print_code_A_const_31) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_code_param_entries_A_New() *A_arbace_repr_go_print_code_param_entries_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_param_entries_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_repr_go_print_code_param_entries_A) Ctor() {}
//line :355:1
func (t *A_arbace_repr_go_print_code_param_entries_A) Invoke_O_O__O(self, v__0 any) any { { var xs__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(v__0); var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var variadic__4 any = jrt.Boolean_FALSE.Ref(); L1: for {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__2)) { return acc__3 } else { var x__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__2)


		if lang.Util_Equiv_O_O__Z_NoInit(x__5, A_arbace_repr_go_print_code_A_const_132) {
			xs__2, acc__3, variadic__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(xs__2), acc__3, jrt.Boolean_TRUE.Ref(); continue L1 } else {
				var tmp1 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()); var tmp3 lang.IPersistentMap
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_133.GetRawRoot__O()).Invoke_O__O(x__5)) { var tmp4 any = A_arbace_repr_go_print_code_A_const_134; var tmp5 any = A_arbace_repr_go_print_code_A_const_135; var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; var tmp7 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__5)); var tmp8 any = A_arbace_repr_go_print_code_A_const_136; var tmp9 any = A_arbace_repr_go_print_code_A_const_137; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, x__5, tmp5, tmp7, tmp8, variadic__4, tmp9, lang.RT_Meta_O__IPersistentMap_NoInit(x__5), A_arbace_repr_go_print_code_A_const_103, x__5)) } else { var tmp10 any = A_arbace_repr_go_print_code_A_const_134; var tmp11 any = A_arbace_repr_go_print_code_A_const_135; var tmp12 any = A_arbace_repr_go_print_code_A_const_136; var tmp13 any = A_arbace_repr_go_print_code_A_const_137; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, x__5, tmp12, variadic__4, tmp13, lang.RT_Meta_O__IPersistentMap_NoInit(x__5), A_arbace_repr_go_print_code_A_const_103, x__5)) }
//line :365:1
				xs__2, acc__3, variadic__4 = tmp1, tmp2.Invoke_O_O__O(acc__3, tmp3), variadic__4; continue L1 } } } }; /*line :355:1*/panic("j2g: unreachable") }















func A_arbace_repr_go_print_code_groupable_QMARK__A_New() *A_arbace_repr_go_print_code_groupable_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_groupable_QMARK__A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_repr_go_print_code_groupable_QMARK__A) Ctor() {}
//line :371:1
func (t *A_arbace_repr_go_print_code_groupable_QMARK__A) Invoke_O_O_O__O(self, prev__0, cur__1 any) any { var and__1927000168__auto____3 any = prev__0; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(prev__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(cur__1); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_136.Invoke_O__O(prev__0)); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_136.Invoke_O__O(cur__1)); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(prev__0), A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(cur__1)); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))


		if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____9 = or__1927000174__auto____9 } else { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(prev__0))), tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(cur__1))))).Ref() }
//line :376:1
		if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(prev__0)), tmp5.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(cur__1))); if and__1927000168__auto____10 { var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_139; var tmp7 *lang.Keyword = A_arbace_repr_go_print_code_A_const_139; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(prev__0)), tmp7.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(cur__1))); if and__1927000168__auto____11 { var t__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(cur__1)); var or__1927000174__auto____13 bool = lang.Util_Identical_O_O__Z_NoInit(t__12, nil)





			if or__1927000174__auto____13 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__12, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(prev__0)))).Ref() } } else {
//line :376:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }







func A_arbace_repr_go_print_code_group_entries_A_New() *A_arbace_repr_go_print_code_group_entries_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_entries_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_repr_go_print_code_group_entries_A) Ctor() {}
//line :384:1
func (t *A_arbace_repr_go_print_code_group_entries_A) Invoke_O_O__O(self, entries__0 any) any { var explicit_QMARK___2 any; var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = A_arbace_repr_go_print_code_A_const_140.Get__O(); if








	jrt.J2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = A_arbace_repr_go_print_code_A_const_141.Get__O() } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { explicit_QMARK___2 = or__1927000174__auto____2 } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_group_entries_fn__74000134_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_go_print_code_group_entries_fn__74000134_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_repr_go_print_code_group_entries_fn__74000134_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; explicit_QMARK___2 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), entries__0) }; var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_142.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_code_group_entries_fn__74000136_A_New_O(explicit_QMARK___2); var tmp6 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_print_code_group_entries_fn__74000136_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_repr_go_print_code_group_entries_fn__74000136_A_fn_class = fncls__37d; tmp6 = fncls__37d } else { tmp6 = fncls__37 }; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.PersistentVector_EMPTY.Ref(), entries__0) }
//line :394:1
func A_arbace_repr_go_print_code_group_entries_fn__74000134_A_New() *A_arbace_repr_go_print_code_group_entries_fn__74000134_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_entries_fn__74000134_A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_repr_go_print_code_group_entries_fn__74000134_A) Ctor() {}
//line :394:1
func (t *A_arbace_repr_go_print_code_group_entries_fn__74000134_A) Invoke_O_O__O(self, p1__74000133_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(p1__74000133_SHARP___1), A_arbace_repr_go_print_code_A_const_14) }
func A_arbace_repr_go_print_code_group_entries_fn__74000136_A_New_O(p0 any) *A_arbace_repr_go_print_code_group_entries_fn__74000136_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_entries_fn__74000136_A{}; t.Ctor_O(p0); return t }
//line :395:1
func (t *A_arbace_repr_go_print_code_group_entries_fn__74000136_A) Ctor_O(c__explicit_QMARK_ any) { t.F_explicit_QMARK_ = c__explicit_QMARK_ }
//line :395:1
func (t *A_arbace_repr_go_print_code_group_entries_fn__74000136_A) Invoke_O_O_O__O(self, groups__1, cur__2 any) any { var prev__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(groups__1); var tmp1 any; var and__1927000168__auto____4 any = prev__3; if

	jrt.J2g_Truth(and__1927000168__auto____4) {
		if jrt.J2g_Truth(t.F_explicit_QMARK_) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_14; var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(cur__2))
			if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(cur__2); if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_134; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_144.Invoke_O__O(prev__3))) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else {
				tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_143.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_144.Invoke_O__O(prev__3)), cur__2) } } else {
//line :397:1
					tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {



						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_32.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_32.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_code_A_const_104; var tmp7 any = tmp5.Invoke_O_O_O_O__O(prev__3, tmp6, A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(cur__2)); var tmp8 any = A_arbace_repr_go_print_code_A_const_144; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_145.GetRawRoot__O()).Invoke_O__O(groups__1), tmp4.Invoke_O_O_O_O__O(tmp7, tmp8, A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O(), cur__2)) } else {


							var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_146.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_print_code_A_const_104; var tmp12 lang.IPersistentVector; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(cur__2)) { tmp12 = lang.Tuple_Create_O__IPersistentVector(A_arbace_repr_go_print_code_A_const_134.Invoke_O__O(cur__2)) } else { tmp12 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY) }; var tmp13 any = tmp12; var tmp14 any = A_arbace_repr_go_print_code_A_const_144; return tmp9.Invoke_O_O__O(groups__1, tmp10.Invoke_O_O_O_O_O__O(cur__2, tmp11, tmp13, tmp14, lang.Tuple_Create_O__IPersistentVector(cur__2))) } }


func A_arbace_repr_go_print_code_variadic_elem_A_New() *A_arbace_repr_go_print_code_variadic_elem_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_variadic_elem_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_repr_go_print_code_variadic_elem_A) Ctor() {}
//line :407:1
func (t *A_arbace_repr_go_print_code_variadic_elem_A) Invoke_O_O__O(self, t__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0), Lit_199)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(t__0) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_214, t__0)
	} }
func A_arbace_repr_go_print_code_param_list_A_New() *A_arbace_repr_go_print_code_param_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_param_list_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_repr_go_print_code_param_list_A) Ctor() {}
//line :410:1
func (t *A_arbace_repr_go_print_code_param_list_A) DoInvoke_O_O_O__O(self, v__0, p__74000140__1 any) any { var vec__74000141__3 any = p__74000140__1; var end__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000141__3, lang.RT_IntCast_J__I_NoInit(0), nil); var open_pos__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000141__3, lang.RT_IntCast_J__I_NoInit(1), nil); var close_pos__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000141__3, lang.RT_IntCast_J__I_NoInit(2), nil); var groups__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_147.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_149.GetRawRoot__O()).Invoke_O__O(v__0));





	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(v__0)); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_param_list_fn__74000144_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_go_print_code_param_list_fn__74000144_A_fn_class; if
	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_repr_go_print_code_param_list_fn__74000144_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; var tmp4 any = /*line :417:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_repr_go_print_code_A_const_119; var tmp6 any = A_arbace_repr_go_print_code_A_const_155.GetRawRoot__O(); var tmp7 any = A_arbace_repr_go_print_code_A_const_118; var tmp8 any = A_arbace_repr_go_print_code_A_const_120; var tmp9 any; var or__1927000174__auto____8 any = open_pos__5; if








	jrt.J2g_Truth(or__1927000174__auto____8) { tmp9 = or__1927000174__auto____8 } else { tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(v__0, A_arbace_repr_go_print_code_A_const_156) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_repr_go_print_code_A_const_121; var tmp12 any; var or__1927000174__auto____8_2 any = close_pos__6; if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp12 = or__1927000174__auto____8_2 } else { tmp12 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(v__0, A_arbace_repr_go_print_code_A_const_157) }; return /*line :417:1*/ tmp1.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, groups__7, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, end__4, tmp8, tmp10, tmp11, tmp12))) }
func A_arbace_repr_go_print_code_param_list_fn__74000144_A_New() *A_arbace_repr_go_print_code_param_list_fn__74000144_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_param_list_fn__74000144_A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_repr_go_print_code_param_list_fn__74000144_A) Ctor() {}
//line :418:1
func (t *A_arbace_repr_go_print_code_param_list_fn__74000144_A) Invoke_O_O_O__O(self, g__1, ___2 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__1))) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__1))
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
	if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_136.Invoke_O__O(g__1)) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_25, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__1), A_arbace_repr_go_print_code_A_const_153)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_154.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__1))) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__1))
		}
}

func A_arbace_repr_go_print_code_results_entries_A_New() *A_arbace_repr_go_print_code_results_entries_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_results_entries_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_repr_go_print_code_results_entries_A) Ctor() {}
//line :428:1
func (t *A_arbace_repr_go_print_code_results_entries_A) Invoke_O_O_O__O(self, params__0, results__1 any) any {


	if jrt.J2g_Truth(results__1) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_149.GetRawRoot__O()).Invoke_O__O(results__1) } else {
//line :431:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(params__0), A_arbace_repr_go_print_code_A_const_31)) { var tmp1 any = A_arbace_repr_go_print_code_A_const_134; var tmp2 any = A_arbace_repr_go_print_code_A_const_135; var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, nil, tmp2, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(params__0))))) } else { if A_arbace_repr_go_print_code_A_const_42 != nil { return lang.PersistentVector_EMPTY.Ref() } else { return nil
			}
			}
		}
}
func A_arbace_repr_go_print_code_print_results_A_New() *A_arbace_repr_go_print_code_print_results_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_results_A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_repr_go_print_code_print_results_A) Ctor() {}
//line :436:1
func (t *A_arbace_repr_go_print_code_print_results_A) Invoke_O_O_O_O__O(self, entries__0, rv__1, params__2 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(entries__0)) { return nil } else { var tmp1 bool; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(entries__0)))

		if and__1927000168__auto____4 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_134; tmp1 = lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(entries__0)), nil) } else { tmp1 = and__1927000168__auto____4 }
//line :440:1
		if tmp1 {


			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
//line :440:1
			var temp__1927000408__auto____4 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(params__2, A_arbace_repr_go_print_code_A_const_160)



			if jrt.J2g_Truth(or__1927000174__auto____4) { temp__1927000408__auto____4 = or__1927000174__auto____4 } else { temp__1927000408__auto____4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(rv__1, A_arbace_repr_go_print_code_A_const_156) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, o__5); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_135; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(entries__0))); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(params__2, A_arbace_repr_go_print_code_A_const_161); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(rv__1, A_arbace_repr_go_print_code_A_const_157) }; return tmp4.Invoke_O_O__O(Lit_8, tmp5) } else {
					var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_135; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(entries__0))) } } else {
//line :440:1
						if A_arbace_repr_go_print_code_A_const_42 != nil {






							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_159.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_print_code_print_results_fn__74000148_A_New(); var tmp11 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_go_print_code_print_results_fn__74000148_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_repr_go_print_code_print_results_fn__74000148_A_fn_class = fncls__39d; tmp11 = fncls__39d } else { tmp11 = fncls__39 }; return tmp7.Invoke_O_O_O_O__O(tmp8.Invoke_O__O(tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), entries__0)), nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(rv__1, A_arbace_repr_go_print_code_A_const_156), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(rv__1, A_arbace_repr_go_print_code_A_const_157)) } else {
//line :440:1
								return nil
							}
					}
	}
}


func A_arbace_repr_go_print_code_print_results_fn__74000148_A_New() *A_arbace_repr_go_print_code_print_results_fn__74000148_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_results_fn__74000148_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_repr_go_print_code_print_results_fn__74000148_A) Ctor() {}
//line :447:1
func (t *A_arbace_repr_go_print_code_print_results_fn__74000148_A) Invoke_O_O__O(self, en__1 any) any { var or__1927000174__auto____2 any = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(en__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(en__1) } }


func A_arbace_repr_go_print_code_line_indent_A_New() *A_arbace_repr_go_print_code_line_indent_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_line_indent_A{}; t.Ctor(); return t }
//line :450:1
func (t *A_arbace_repr_go_print_code_line_indent_A) Ctor() {}
//line :450:1
func (t *A_arbace_repr_go_print_code_line_indent_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_162; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_163; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_164; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))
	} }
func A_arbace_repr_go_print_code_signature_A_New() *A_arbace_repr_go_print_code_signature_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_signature_A{}; t.Ctor(); return t }
//line :455:1
func (t *A_arbace_repr_go_print_code_signature_A) Ctor() {}
//line :455:1
func (t *A_arbace_repr_go_print_code_signature_A) DoInvoke_O_O_O_O_O__O(self, params__0, res__1, body__2, p__74000152__3 any) any { var vec__74000153__5 any = p__74000152__3; var rv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000153__5, lang.RT_IntCast_J__I_NoInit(0), nil); var r__7 any; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(res__1)) { var en__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(res__1); var or__1927000174__auto____8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____8_2 any = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(en__7); if jrt.J2g_Truth(or__1927000174__auto____8_2) { tmp2 = or__1927000174__auto____8_2 } else { tmp2 = A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(en__7) }; or__1927000174__auto____8 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____8) { r__7 = or__1927000174__auto____8 } else { r__7 = A_arbace_repr_go_print_code_A_const_124 } } else { r__7 = nil }; var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_A_const_86; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(body__2))); var tmp5 any; tmp6 := /*line :455:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_159.GetRawRoot__O()).Invoke_O_O__O(params__0, r__7)
		tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_165.GetRawRoot__O()).Invoke_O_O_O__O(res__1, rv__6, params__0)
//line :455:1
		return nil }();






	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :455:1*/ tmp6 != nil { panic(tmp6) }; return tmp5 }










func A_arbace_repr_go_print_code_func_type_sig_A_New() *A_arbace_repr_go_print_code_func_type_sig_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_func_type_sig_A{}; t.Ctor(); return t }
//line :466:1
func (t *A_arbace_repr_go_print_code_func_type_sig_A) Ctor() {}
//line :466:1
func (t *A_arbace_repr_go_print_code_func_type_sig_A) Invoke_O_O_O__O(self, params__0, results__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_167.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(results__1) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_149.GetRawRoot__O()).Invoke_O__O(results__1) } else { tmp2 = lang.PersistentVector_EMPTY.Ref() }; return tmp1.Invoke_O_O_O_O__O(params__0, tmp2, nil, results__1)
}
func A_arbace_repr_go_print_code_struct_tag_A_New() *A_arbace_repr_go_print_code_struct_tag_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_struct_tag_A{}; t.Ctor(); return t }
//line :471:1
func (t *A_arbace_repr_go_print_code_struct_tag_A) Ctor() {}
//line :471:1
func (t *A_arbace_repr_go_print_code_struct_tag_A) DoInvoke_O_O_O__O(self, s__0, p__74000158__1 any) any { var vec__74000159__3 any = p__74000158__1; var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000159__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if

	jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = A_arbace_repr_go_print_code_A_const_168.Invoke_O__O(m__4) } else { tmp1 = and__1927000168__auto____5 }; if /*line :472:1*/ jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_168.Invoke_O__O(m__4), A_arbace_repr_go_print_code_A_const_169.Invoke_O__O(m__4)) } else {
//line :472:1
			var tmp3 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(s__0)

			if jrt.J2g_Truth(and__1927000168__auto____5_2) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_108.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_151)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_109.GetRawRoot__O()).Invoke_O__O(s__0) } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5_2 }
//line :472:1
			if jrt.J2g_Truth(tmp3) {


				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_152), jrt.RefArrayOf(jrt.Object_class, nil, s__0, nil)).Ref(); var tmp6 any; var tmp7 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { tmp6 = A_arbace_repr_go_print_code_A_const_169.Invoke_O__O(m__4) } else { tmp6 = nil }; return tmp4.Invoke_O_O__O(tmp5, tmp6) } else {
//line :472:1
					if A_arbace_repr_go_print_code_A_const_42 != nil {



						var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_112.GetRawRoot__O()).Invoke_O__O(s__0); var tmp10 any; var tmp11 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp11.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { tmp10 = A_arbace_repr_go_print_code_A_const_169.Invoke_O__O(m__4) } else { tmp10 = nil }; return tmp8.Invoke_O_O__O(tmp9, tmp10) } else {
//line :472:1
							return nil } } } }





func A_arbace_repr_go_print_code_doc_lines_A_New() *A_arbace_repr_go_print_code_doc_lines_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_doc_lines_A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_repr_go_print_code_doc_lines_A) Ctor() {}
//line :478:1
func (t *A_arbace_repr_go_print_code_doc_lines_A) Invoke_O_O__O(self, doc__0 any) any { var ls__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_170.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_95.GetRawRoot__O()).Invoke_O__O(doc__0), A_arbace_repr_go_print_code_A_const_171, A_arbace_repr_go_print_code_A_const_172); var ls__3 any; if

	lang.Util_Equiv_O_O__Z_NoInit(Lit_69, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(ls__2)) { ls__3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_145.GetRawRoot__O()).Invoke_O__O(ls__2) } else { ls__3 = ls__2 }; return ls__3 }


func A_arbace_repr_go_print_code_write_doc_A_New() *A_arbace_repr_go_print_code_write_doc_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_write_doc_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_repr_go_print_code_write_doc_A) Ctor() {}
//line :483:1
func (t *A_arbace_repr_go_print_code_write_doc_A) Invoke_O_O_O__O(self, doc__0, indent__1 any) any {


	{ var tmp1 any; var and__1927000168__auto____3 any = doc__0; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var seq_74000164__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_174.GetRawRoot__O()).Invoke_O__O(doc__0)); var chunk_74000165__4 any; var count_74000166__5 int64 = 0; var i_74000167__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_74000167__6, count_74000166__5) { var l__7 any = lang.Indexed_Cast(chunk_74000165__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000167__6)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()); var tmp3 *jrt.String
			if lang.Util_Equiv_O_O__Z_NoInit(l__7, Lit_69) { tmp3 = Lit_219 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_176.GetRawRoot__O()).Invoke_O_O__O(l__7, Lit_220)) { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_219, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__7)) } else { if A_arbace_repr_go_print_code_A_const_42 != nil { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_221, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__7)) } else { tmp3 = nil } } }; tmp2.Invoke_O_O__O(tmp3.Ref(), indent__1)
//line :487:1
			seq_74000164__3, chunk_74000165__4, count_74000166__5, i_74000167__6 = seq_74000164__3, chunk_74000165__4, count_74000166__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000167__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000164__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_74000164__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000164__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000164__8); seq_74000164__3, chunk_74000165__4, count_74000166__5, i_74000167__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000164__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000164__8); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()); var tmp5 *jrt.String
				if lang.Util_Equiv_O_O__Z_NoInit(l__9, Lit_69) { tmp5 = Lit_219 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_176.GetRawRoot__O()).Invoke_O_O__O(l__9, Lit_220)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_219, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__9)) } else { if A_arbace_repr_go_print_code_A_const_42 != nil { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_221, nil), jrt.RefArrayOf(jrt.Object_class, nil, l__9)) } else { tmp5 = nil } } }; tmp4.Invoke_O_O__O(tmp5.Ref(), indent__1)
//line :487:1
				seq_74000164__3, chunk_74000165__4, count_74000166__5, i_74000167__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000164__8), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :486:1
					return nil } }
//line :483:1
	panic("j2g: unreachable")
}













func A_arbace_repr_go_print_code_directives_of_A_New() *A_arbace_repr_go_print_code_directives_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_A{}; t.Ctor(); return t }
//line :498:1
func (t *A_arbace_repr_go_print_code_directives_of_A) Ctor() {}
//line :498:1
func (t *A_arbace_repr_go_print_code_directives_of_A) Invoke_O_O__O(self, m__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A_New(); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A_fn_class; if




	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_183.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_184.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_186.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_185.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_code_directives_of_fn__74000189_A_New(); var tmp8 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_print_code_directives_of_fn__74000189_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_repr_go_print_code_directives_of_fn__74000189_A_fn_class = fncls__45d; tmp8 = fncls__45d } else { tmp8 = fncls__45 }; return tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), m__0))) }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_fn__74000189_A_New() *A_arbace_repr_go_print_code_directives_of_fn__74000189_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_fn__74000189_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_fn__74000189_A) Ctor() {}
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_fn__74000189_A) Invoke_O_O__O(self, p__74000188__1 any) any { var vec__74000190__2 any = p__74000188__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000190__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000190__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3); _ = ___4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3), Lit_62); if and__1927000168__auto____6 {
														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_187.GetRawRoot__O()).Invoke_O__O(k__3)) } else {
//line :503:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A_New() *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A) Ctor() {}
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A) Invoke_O_O__O(self, s__74000170__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A_New_O_O(s__74000170__1, self); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A) Ctor_O_O(c__s__74000170, c__iter__74000169 any) { t.F_s__74000170 = c__s__74000170; t.F_iter__74000169 = c__iter__74000169 }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A) Invoke_O__O(self any) any { { var s__74000170__1 any; var t_ any = t.F_s__74000170; t.F_s__74000170 = nil; s__74000170__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(s__74000170__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__74000177__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000177__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000177__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A_New_O(k__5); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp5 any


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(v__6)) { tmp5 = v__6 } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(v__6) }
//line :503:1
	fs__1927001036__auto____8 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.J2g_Truth(fs__1927001036__auto____8) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__74000169); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_182.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(s__74000170__1))) } else { s__74000170__1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(s__74000170__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A_New_O(p0 any) *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A{}; t.Ctor_O(p0); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A) Invoke_O_O__O(self, s__74000172__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A_New_O_O_O(t.F_k, s__74000172__1, self); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A) Ctor_O_O_O(c__k, c__s__74000172, c__iter__74000171 any) { t.F_k = c__k; t.F_s__74000172 = c__s__74000172; t.F_iter__74000171 = c__iter__74000171 }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A) Invoke_O__O(self any) any { { var s__74000172__1 any; var t_ any = t.F_s__74000172; t.F_s__74000172 = nil; s__74000172__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(s__74000172__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__74000172__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(s__74000172__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(s__74000172__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__74000174__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_177.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A_New_O_O_I_O(t.F_k, b__74000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__74000171); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000174__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(s__74000172__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000174__6), nil) } } else { var v__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(s__74000172__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_180.GetRawRoot__O()); var tmp5 *jrt.String



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_105.GetRawRoot__O()).Invoke_O__O(v__4)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(t.F_k))) } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(t.F_k), nil, v__4)) }
//line :503:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__74000171); return tmp4.Invoke_O_O__O(tmp5.Ref(), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(s__74000172__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :503:1
func A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A) Ctor_O_O_I_O(c__k, c__b__74000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__74000174 = c__b__74000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :503:1
func (t *A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A) Invoke_O__O(self any) any { { var i__74000173__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__74000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var v__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__74000173__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_178.GetRawRoot__O()); var tmp3 any = t.F_b__74000174; var tmp4 *jrt.String



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_105.GetRawRoot__O()).Invoke_O__O(v__2)) { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(t.F_k))) } else { tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(t.F_k), nil, v__2)) }
//line :503:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()); i__74000173__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__74000173__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_repr_go_print_code_pre_lines_A_New() *A_arbace_repr_go_print_code_pre_lines_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_pre_lines_A{}; t.Ctor(); return t }
//line :509:1
func (t *A_arbace_repr_go_print_code_pre_lines_A) Ctor() {}
//line :509:1
func (t *A_arbace_repr_go_print_code_pre_lines_A) Invoke_O_O_O__O(self, doc__0, dirs__1 any) any { var d__3 any; var tmp1 any; var and__1927000168__auto____3 any = doc__0; if



	jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { d__3 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_174.GetRawRoot__O()).Invoke_O__O(doc__0))).Ref() } else { d__3 = A_arbace_repr_go_print_code_A_const_188 }; var na_46 any; var na_48 any = d__3; var na_49 int64; var tmp2 any; var and__1927000168__auto____4 bool; var na_50 any = d__3; if
	jrt.Long_InstanceOf(na_50) { var n0_51 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); and__1927000168__auto____4 = n0_51 > 0 } else { if jrt.Double_InstanceOf(na_50) { var n0_51_2 float64 = jrt.NN(jrt.Double_Cast(na_50)).DoubleValue__D(); and__1927000168__auto____4 = n0_51_2 > 0.0 } else { and__1927000168__auto____4 = lang.Numbers_IsPos_O__Z_NoInit(na_50) } }; if and__1927000168__auto____4 { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(dirs__1) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp2) { na_49 = 1 } else { na_49 = 0 }; if jrt.Long_InstanceOf(na_48) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_48)).LongValue__J(); var n1_53 int64 = na_49; var nr_54 int64 = n0_52 + n1_53; if (n0_52^nr_54)&(n1_53^nr_54) >= 0 { na_46 = jrt.Long_ValueOf_J__Long_NoInit(nr_54).Ref() } else { na_46 = lang.Numbers_Add_O_J__Number_NoInit(na_48, na_49) } } else { na_46 = lang.Numbers_Add_O_J__Number_NoInit(na_48, na_49) }; var na_47 int64 = int64(lang.RT_Count_O__I_NoInit(dirs__1)); if jrt.Long_InstanceOf(na_46) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_56 int64 = na_47; var nr_57 int64 = n0_55 + n1_56; if (n0_55^nr_57)&(n1_56^nr_57) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_57).Ref() } else { return lang.Numbers_Add_O_J__Number_NoInit(na_46, na_47) } } else { return lang.Numbers_Add_O_J__Number_NoInit(na_46, na_47) } }

func A_arbace_repr_go_print_code_write_pre_A_New() *A_arbace_repr_go_print_code_write_pre_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_write_pre_A{}; t.Ctor(); return t }
//line :516:1
func (t *A_arbace_repr_go_print_code_write_pre_A) Ctor() {}
//line :516:1
func (t *A_arbace_repr_go_print_code_write_pre_A) Invoke_O_O_O_O__O(self, doc__0, dirs__1, indent__2 any) any {
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_189.GetRawRoot__O()).Invoke_O_O__O(doc__0, indent__2)
	{ var tmp1 any; var and__1927000168__auto____4 any = doc__0; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(doc__0, Lit_69); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(dirs__1) } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(Lit_219, indent__2) }
//line :516:1
		var seq_74000196__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(dirs__1); var chunk_74000197__5 any; var count_74000198__6 int64 = 0; var i_74000199__7 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_74000199__7, count_74000198__6) { var d__8 any = lang.Indexed_Cast(chunk_74000197__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000199__7)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(d__8, indent__2); seq_74000196__4, chunk_74000197__5, count_74000198__6, i_74000199__7 = seq_74000196__4, chunk_74000197__5, count_74000198__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000199__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000196__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_74000196__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000196__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000196__9); seq_74000196__4, chunk_74000197__5, count_74000198__6, i_74000199__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000196__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var d__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000196__9); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()).Invoke_O_O__O(d__10, indent__2); seq_74000196__4, chunk_74000197__5, count_74000198__6, i_74000199__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000196__9), nil, 0, 0; continue L1 } } else { return nil } } } }
//line :516:1
	panic("j2g: unreachable")
}



func A_arbace_repr_go_print_code_interface_method_QMARK__A_New() *A_arbace_repr_go_print_code_interface_method_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_interface_method_QMARK__A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_repr_go_print_code_interface_method_QMARK__A) Ctor() {}
//line :521:1
func (t *A_arbace_repr_go_print_code_interface_method_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0); if
													jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__0)), nil); if and__1927000168__auto____4 { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____5) {
														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(x__0), Lit_26) } else {
//line :522:1
			return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_repr_go_print_code_iface_method_sig_A_New() *A_arbace_repr_go_print_code_iface_method_sig_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_iface_method_sig_A{}; t.Ctor(); return t }
//line :525:1
func (t *A_arbace_repr_go_print_code_iface_method_sig_A) Ctor() {}
//line :525:1
func (t *A_arbace_repr_go_print_code_iface_method_sig_A) Invoke_O_O_O__O(self, params__0, more__1 any) any { var results__3 any; if



	lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(more__1), A_arbace_repr_go_print_code_A_const_190) { results__3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(more__1) } else { results__3 = nil }; return /*line :530:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_167.GetRawRoot__O()).Invoke_O_O_O_O__O(params__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_191.GetRawRoot__O()).Invoke_O_O__O(params__0, results__3), nil, results__3) }



func A_arbace_repr_go_print_code_one_line_fields_QMARK__A_New() *A_arbace_repr_go_print_code_one_line_fields_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_one_line_fields_QMARK__A{}; t.Ctor(); return t }
//line :534:1
func (t *A_arbace_repr_go_print_code_one_line_fields_QMARK__A) Ctor() {}
//line :534:1
func (t *A_arbace_repr_go_print_code_one_line_fields_QMARK__A) Invoke_O_O_O__O(self, groups__0, struct_QMARK___1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(groups__0))); if and__1927000168__auto____3 {



	var g__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(groups__0); var m__5 any = A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(g__4); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_139.Invoke_O__O(m__5))


	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_138.Invoke_O__O(m__5)); if jrt.J2g_Truth(and__1927000168__auto____7) { var x__8 any = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(g__4); var method_QMARK___9 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(struct_QMARK___1)

		if jrt.J2g_Truth(and__1927000168__auto____9) { method_QMARK___9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_192.GetRawRoot__O()).Invoke_O__O(x__8) } else { method_QMARK___9 = and__1927000168__auto____9 }
//line :541:1
		var names_QMARK___10 any


		if jrt.J2g_Truth(struct_QMARK___1) { names_QMARK___10 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__4)) } else { names_QMARK___10 = method_QMARK___9 }
//line :541:1
		var text__11 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_193.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A_New_O_O_O(g__4, x__8, method_QMARK___9); var tmp3 *jrt.Class
		var fncls__58 /*line :541:1*/*jrt.Class = A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A_fn_class




		if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }
//line :545:1
		text__11 = tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))
//line :541:1
		var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_108.GetRawRoot__O()).Invoke_O_O__O(text__11, Lit_151))







		if jrt.J2g_Truth(and__1927000168__auto____12) {
			var tmp4 int64; if jrt.J2g_Truth(names_QMARK___10) { tmp4 = 1 } else { tmp4 = 0 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Lte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp4, int64(lang.RT_Count_O__I_NoInit(text__11))), 30)).Ref() } else {
//line :549:1
				return and__1927000168__auto____12 } } else {
//line :541:1
					return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else {
//line :538:1
						return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }







func A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :546:1
func (t *A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A) Ctor_O_O_O(c__g, c__x, c__method_QMARK_ any) { t.F_g = c__g; t.F_x = c__x; t.F_method_QMARK_ = c__method_QMARK_ }
//line :546:1
func (t *A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A) Invoke_O__O(self any) any { if jrt.J2g_Truth(t.F_method_QMARK_) {
													lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_26); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(t.F_x), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(t.F_x)) } else {
														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O_O__O(t.F_g, t.F_x)) } }



func A_arbace_repr_go_print_code_struct_fields_A_New() *A_arbace_repr_go_print_code_struct_fields_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_struct_fields_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_repr_go_print_code_struct_fields_A) Ctor() {}
//line :552:1
func (t *A_arbace_repr_go_print_code_struct_fields_A) Invoke_O_O__O(self, fs__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_147.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(fs__0); return tmp1.Invoke_O__O(tmp2) }
//line :553:1
func A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A_New() *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A{}; t.Ctor(); return t }
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A) Ctor() {}
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A) Invoke_O_O__O(self, s__74000207__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A_New_O_O(s__74000207__1, self); var tmp2 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A_fn_class = fncls__60d; tmp2 = fncls__60d } else { tmp2 = fncls__60 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :553:1
func A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A{}; t.Ctor_O_O(p0, p1); return t }
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A) Ctor_O_O(c__s__74000207, c__iter__74000206 any) { t.F_s__74000207 = c__s__74000207; t.F_iter__74000206 = c__iter__74000206 }
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A) Invoke_O__O(self any) any { { var s__74000207__1 any; var t_ any = t.F_s__74000207; t.F_s__74000207 = nil; s__74000207__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(s__74000207__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__74000207__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(s__74000207__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(s__74000207__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__74000209__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_177.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A_New_O_I_O(b__74000209__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A_fn_class = fncls__59d; tmp2 = fncls__59d } else { tmp2 = fncls__59 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__74000206); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000209__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(s__74000207__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000209__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(s__74000207__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_180.GetRawRoot__O()); var tmp5 lang.IPersistentMap
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_133.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp6 any = A_arbace_repr_go_print_code_A_const_134; var tmp7 any = A_arbace_repr_go_print_code_A_const_135; var tmp8 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; var tmp9 any = tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4)); var tmp10 any = A_arbace_repr_go_print_code_A_const_137; tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, f__4, tmp7, tmp9, tmp10, lang.RT_Meta_O__IPersistentMap_NoInit(f__4), A_arbace_repr_go_print_code_A_const_103, f__4)) } else { var tmp11 any = A_arbace_repr_go_print_code_A_const_134; var tmp12 any = A_arbace_repr_go_print_code_A_const_135; var tmp13 any = A_arbace_repr_go_print_code_A_const_137; tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, nil, tmp12, f__4, tmp13, lang.RT_Meta_O__IPersistentMap_NoInit(f__4), A_arbace_repr_go_print_code_A_const_103, f__4)) }
//line :553:1
	var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__74000206); return tmp4.Invoke_O_O__O(tmp5, tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(s__74000207__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :553:1
func A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A) Ctor_O_I_O(c__b__74000209 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__74000209 = c__b__74000209; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :553:1
func (t *A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A) Invoke_O__O(self any) any { { var i__74000208__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__74000208__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__74000208__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_178.GetRawRoot__O()); var tmp3 any = t.F_b__74000209; var tmp4 lang.IPersistentMap
																	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_133.GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp5 any = A_arbace_repr_go_print_code_A_const_134; var tmp6 any = A_arbace_repr_go_print_code_A_const_135; var tmp7 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; var tmp8 any = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)); var tmp9 any = A_arbace_repr_go_print_code_A_const_137; tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, f__2, tmp6, tmp8, tmp9, lang.RT_Meta_O__IPersistentMap_NoInit(f__2), A_arbace_repr_go_print_code_A_const_103, f__2)) } else { var tmp10 any = A_arbace_repr_go_print_code_A_const_134; var tmp11 any = A_arbace_repr_go_print_code_A_const_135; var tmp12 any = A_arbace_repr_go_print_code_A_const_137; tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, f__2, tmp12, lang.RT_Meta_O__IPersistentMap_NoInit(f__2), A_arbace_repr_go_print_code_A_const_103, f__2)) }
//line :553:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__74000208__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__74000208__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_print_code_field_body_A_New() *A_arbace_repr_go_print_code_field_body_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_body_A{}; t.Ctor(); return t }
//line :558:1
func (t *A_arbace_repr_go_print_code_field_body_A) Ctor() {}
//line :558:1
func (t *A_arbace_repr_go_print_code_field_body_A) Invoke_O_O_O_O__O(self, g__0, struct_QMARK___1, sep__2 any) any {


	if jrt.J2g_Truth(struct_QMARK___1) {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__0))) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__0))
			lang.IFn_Cast(sep__2).Invoke__O()
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__0)) } else {
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__0)) }
//line :561:1
		var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_139; var temp__1927000414__auto____4 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(g__0))






		if jrt.J2g_Truth(temp__1927000414__auto____4) { var t__5 any = temp__1927000414__auto____4; var tmp2 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__0))
			if jrt.J2g_Truth(and__1927000168__auto____6) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sep__2, A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O())).Ref() } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(sep__2).Invoke__O() }
			lang.IFn_Cast(sep__2).Invoke__O()
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_196.GetRawRoot__O()).Invoke_O_O__O(t__5, A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(g__0)) } else {
//line :568:1
				return nil } } else {
//line :561:1
					var x__4 any = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(g__0)











					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_192.GetRawRoot__O()).Invoke_O__O(x__4)) {
						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__4)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_194.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(x__4), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(x__4)) } else {
							return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(x__4)
						} } }
func A_arbace_repr_go_print_code_field_list_A_New() *A_arbace_repr_go_print_code_field_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_A{}; t.Ctor(); return t }
//line :577:1
func (t *A_arbace_repr_go_print_code_field_list_A) Ctor() {}
//line :577:1
func (t *A_arbace_repr_go_print_code_field_list_A) DoInvoke_O_O_O_O_O__O(self, kw__0, fs__1, struct_QMARK___2, p__74000219__3 any) any { var vec__74000220__5 any = p__74000219__3; var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000220__5, lang.RT_IntCast_J__I_NoInit(0), nil); var groups__7 any; if


	jrt.J2g_Truth(struct_QMARK___2) {
		groups__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_198.GetRawRoot__O()).Invoke_O__O(fs__1) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____7 any; var tmp3 any = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A_New(); var tmp4 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A_fn_class = fncls__64d; tmp4 = fncls__64d } else { tmp4 = fncls__64 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(fs__1); groups__7 = tmp1.Invoke_O__O(tmp2) }; var tmp5 /*line :577:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var start__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var ts__9 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_code_field_list_fn__74000233_A_New(); var tmp8 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_repr_go_print_code_field_list_fn__74000233_A_fn_class; if






	fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_repr_go_print_code_field_list_fn__74000233_A_fn_class = fncls__65d; tmp8 = fncls__65d } else { tmp8 = fncls__65 }; ts__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), groups__7); var breaks_QMARK___10 any; var tmp9 /*line :577:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____10 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if







	jrt.J2g_Truth(and__1927000168__auto____10) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_print_code_field_list_fn__74000235_A_New_O(start__8); var tmp12 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_repr_go_print_code_field_list_fn__74000235_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_repr_go_print_code_field_list_fn__74000235_A_fn_class = fncls__71d; tmp12 = fncls__71d } else { tmp12 = fncls__71 }; breaks_QMARK___10 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), ts__9) } else { breaks_QMARK___10 = and__1927000168__auto____10 }; var docs_QMARK___11 any; var tmp13 lang.IFn = /*line :577:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_code_field_list_fn__74000237_A_New(); var tmp15 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_repr_go_print_code_field_list_fn__74000237_A_fn_class; if








	fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_repr_go_print_code_field_list_fn__74000237_A_fn_class = fncls__72d; tmp15 = fncls__72d } else { tmp15 = fncls__72 }; docs_QMARK___11 = tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), groups__7); var tmp16 any; var tmp17 /*line :587:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____12 any = tmp17.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if
	jrt.J2g_Truth(and__1927000168__auto____12) { tmp16 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(groups__7) } else { tmp16 = and__1927000168__auto____12 }; if /*line :587:1*/ jrt.J2g_Truth(tmp16) {

		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(kw__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_201.GetRawRoot__O()).Invoke_O__O(kw__0))); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, A_arbace_repr_go_print_code_A_const_202)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_19, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, A_arbace_repr_go_print_code_A_const_203)) } else {
//line :587:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(groups__7)) {


				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_118), jrt.RefArrayOf(jrt.Object_class, kw__0, nil)).Ref()) } else {
//line :587:1
					var tmp18 any; var and__1927000168__auto____12_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(breaks_QMARK___10)



					if jrt.J2g_Truth(and__1927000168__auto____12_2) { var and__1927000168__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(docs_QMARK___11); if jrt.J2g_Truth(and__1927000168__auto____13) { var tmp19 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____14) { var tmp20 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var or__1927000174__auto____15 any = tmp20.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp18 = or__1927000174__auto____15 } else { tmp18 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_199.GetRawRoot__O()).Invoke_O_O__O(groups__7, struct_QMARK___2) } } else { tmp18 = and__1927000168__auto____14 } } else { tmp18 = and__1927000168__auto____13 } } else { tmp18 = and__1927000168__auto____12_2 }
//line :587:1
					if jrt.J2g_Truth(tmp18) {




						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, kw__0, nil)).Ref()); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
//line :587:1
						var seq_74000239__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), groups__7)); var chunk_74000240__13 any; var count_74000241__14 int64 = 0; var i_74000242__15 int64 = 0; L1: for {





							if lang.Numbers_Lt_J_J__Z_NoInit(i_74000242__15, count_74000241__14) { var vec__74000243__16 any = lang.Indexed_Cast(chunk_74000240__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000242__15)); var i__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000243__16, lang.RT_IntCast_J__I_NoInit(0), nil); var g__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000243__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp21 bool; var na_73 any = i__17
								if jrt.Long_InstanceOf(na_73) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); tmp21 = n0_74 > 0 } else { if jrt.Double_InstanceOf(na_73) { var n0_74_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); tmp21 = n0_74_2 > 0.0 } else { tmp21 = lang.Numbers_IsPos_O__Z_NoInit(na_73) } }; if tmp21 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
								lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_204.GetRawRoot__O()).Invoke_O_O_O__O(g__18, struct_QMARK___2, A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O())
//line :593:1
								seq_74000239__12, chunk_74000240__13, count_74000241__14, i_74000242__15 = seq_74000239__12, chunk_74000240__13, count_74000241__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000242__15); continue L1 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000239__12); if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_74000239__17 any = temp__1927000414__auto____16; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000239__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000239__17); seq_74000239__12, chunk_74000240__13, count_74000241__14, i_74000242__15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000239__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000246__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000239__17); var i__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000246__18, lang.RT_IntCast_J__I_NoInit(0), nil); var g__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000246__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp22 bool; var na_75 any = i__19
									if jrt.Long_InstanceOf(na_75) { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); tmp22 = n0_76 > 0 } else { if jrt.Double_InstanceOf(na_75) { var n0_76_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); tmp22 = n0_76_2 > 0.0 } else { tmp22 = lang.Numbers_IsPos_O__Z_NoInit(na_75) } }; if tmp22 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_204.GetRawRoot__O()).Invoke_O_O_O__O(g__20, struct_QMARK___2, A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O())
//line :593:1
									seq_74000239__12, chunk_74000240__13, count_74000241__14, i_74000242__15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000239__17), nil, 0, 0; continue L1 } } }
//line :587:1
							break L1
						}







						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
//line :587:1
							if A_arbace_repr_go_print_code_A_const_42 != nil { var indent__12 any
								var tmp23 /*line :587:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_162










								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) { var tmp24 *lang.Keyword = A_arbace_repr_go_print_code_A_const_163; indent__12 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp24.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { var tmp25 *lang.Keyword = A_arbace_repr_go_print_code_A_const_164; indent__12 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) }
//line :587:1
								var sep__13 any; var tmp26 any
								var and__1927000168__auto____13_2 any = struct_QMARK___2










								if jrt.J2g_Truth(and__1927000168__auto____13_2) { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(groups__7)))).Ref() } else { tmp26 = and__1927000168__auto____13_2 }; if jrt.J2g_Truth(tmp26) { sep__13 = A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O() } else { sep__13 = A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O() }
//line :587:1
								var tmp27 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var last_start__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_200.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp27.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())))













								lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(kw__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_201.GetRawRoot__O()).Invoke_O__O(kw__0))); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, A_arbace_repr_go_print_code_A_const_202))
								lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(indent__12)
//line :587:1
								var n__1927000701__auto____15 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(groups__7)); var i__16 int64 = 0; L2: for {















									if lang.Numbers_Lt_J_J__Z_NoInit(i__16, n__1927000701__auto____15) { var g__17 any = lang.RT_Nth_O_I__O_NoInit(groups__7, lang.RT_IntCast_J__I_NoInit(i__16)); var tmp28 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; var doc__18 any = tmp28.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(g__17)); var pre__19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_206.GetRawRoot__O()).Invoke_O_O__O(doc__18, lang.PersistentVector_EMPTY.Ref()); var t__20 any = lang.RT_Nth_O_I__O_NoInit(ts__9, lang.RT_IntCast_J__I_NoInit(i__16)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp30 any = A_arbace_repr_go_print_code_A_const_86; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O())
										var tmp32 any = A_arbace_repr_go_print_code_A_const_103



										lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O_O__O(tmp30, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(tmp31.Invoke_O_O__O(tmp32, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_209.GetRawRoot__O()).Invoke_O_O__O(groups__7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__16)).Ref()))))); var tmp33 any = A_arbace_repr_go_print_code_field_list_fn__74000249_A_New_O_O_O_O_O_O_O_O_J(indent__12, t__20, doc__18, struct_QMARK___2, last_start__14, pre__19, sep__13, g__17, i__16); var tmp34 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_repr_go_print_code_field_list_fn__74000249_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_repr_go_print_code_field_list_fn__74000249_A_fn_class = fncls__107d; tmp34 = fncls__107d } else { tmp34 = fncls__107 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O()
//line :603:1
										i__16 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__16); continue L2 }
//line :587:1
									break L2
								}






























								lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O()
								var tmp35 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp35.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()).Invoke_O_O_O_O__O(nil, jrt.Boolean_TRUE.Ref(), jrt.Boolean_TRUE.Ref(), indent__12)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } } else {
										lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O__O(indent__12, jrt.Boolean_TRUE.Ref()) }
								var tmp36 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp36.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
								return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_19, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__6, A_arbace_repr_go_print_code_A_const_203)) } else {
//line :587:1
									return nil } } } } }
//line :582:1
func A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A_New() *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A) Ctor() {}
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A) Invoke_O_O__O(self, s__74000224__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A_New_O_O(s__74000224__1, self); var tmp2 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A_fn_class = fncls__63d; tmp2 = fncls__63d } else { tmp2 = fncls__63 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :582:1
func A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A) Ctor_O_O(c__s__74000224, c__iter__74000223 any) { t.F_s__74000224 = c__s__74000224; t.F_iter__74000223 = c__iter__74000223 }
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A) Invoke_O__O(self any) any { { var s__74000224__1 any; var t_ any = t.F_s__74000224; t.F_s__74000224 = nil; s__74000224__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(s__74000224__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__74000224__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(s__74000224__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(s__74000224__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__74000226__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_177.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__74000226__6); var tmp2 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A_fn_class = fncls__62d; tmp2 = fncls__62d } else { tmp2 = fncls__62 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__74000223); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000226__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(s__74000224__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_179.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_181.GetRawRoot__O()).Invoke_O__O(b__74000226__6), nil) } } else { var x__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(s__74000224__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_180.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_code_A_const_103; var tmp6 any = A_arbace_repr_go_print_code_A_const_137; var tmp7 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_192.GetRawRoot__O()).Invoke_O__O(x__4)) { tmp7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__4) } else { tmp7 = x__4 }; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__74000223); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, x__4, tmp6, lang.RT_Meta_O__IPersistentMap_NoInit(tmp7))), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(s__74000224__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :582:1
func A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__74000226 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__74000226 = c__b__74000226 }
//line :582:1
func (t *A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A) Invoke_O__O(self any) any { { var i__74000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__74000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__74000225__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_178.GetRawRoot__O()); var tmp3 any = t.F_b__74000226; var tmp4 any = A_arbace_repr_go_print_code_A_const_103; var tmp5 any = A_arbace_repr_go_print_code_A_const_137; var tmp6 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_192.GetRawRoot__O()).Invoke_O__O(x__2)) { tmp6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__2) } else { tmp6 = x__2 }; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, x__2, tmp5, lang.RT_Meta_O__IPersistentMap_NoInit(tmp6)))); i__74000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__74000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_print_code_field_list_fn__74000233_A_New() *A_arbace_repr_go_print_code_field_list_fn__74000233_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_fn__74000233_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000233_A) Ctor() {}
//line :584:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000233_A) Invoke_O_O__O(self, g__1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(g__1)); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__1))) } }
func A_arbace_repr_go_print_code_field_list_fn__74000235_A_New_O(p0 any) *A_arbace_repr_go_print_code_field_list_fn__74000235_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_fn__74000235_A{}; t.Ctor_O(p0); return t }
//line :585:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000235_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :585:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000235_A) Invoke_O_O__O(self, p1__74000218_SHARP___1 any) any { var and__1927000168__auto____2 any = p1__74000218_SHARP___1; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 bool; var na_66 int64 = lang.RT_LongCast_O__J_NoInit(p1__74000218_SHARP___1); var na_67 any = t.F_start; if jrt.Long_InstanceOf(na_67) { var n0_68 int64 = na_66; var n1_69 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); tmp1 = n0_68 > n1_69 } else { tmp1 = lang.Numbers_Gt_J_O__Z_NoInit(na_66, na_67) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_print_code_field_list_fn__74000237_A_New() *A_arbace_repr_go_print_code_field_list_fn__74000237_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_fn__74000237_A{}; t.Ctor(); return t }
//line :586:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000237_A) Ctor() {}
//line :586:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000237_A) Invoke_O_O__O(self, g__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; return tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_137.Invoke_O__O(g__1)) }





















func A_arbace_repr_go_print_code_field_list_fn__74000249_A_New_O_O_O_O_O_O_O_O_J(p0, p1, p2, p3, p4, p5, p6, p7 any, p8 int64) *A_arbace_repr_go_print_code_field_list_fn__74000249_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_field_list_fn__74000249_A{}; t.Ctor_O_O_O_O_O_O_O_O_J(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :608:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000249_A) Ctor_O_O_O_O_O_O_O_O_J(c__indent, c__t, c__doc, c__struct_QMARK_, c__last_start, c__pre, c__sep, c__g any, c__i int64) { t.F_indent = c__indent; t.F_t = c__t; t.F_doc = c__doc; t.F_struct_QMARK_ = c__struct_QMARK_; t.F_last_start = c__last_start; t.F_pre = c__pre; t.F_sep = c__sep; t.F_g = c__g; t.F_i = c__i }
//line :608:1
func (t *A_arbace_repr_go_print_code_field_list_fn__74000249_A) Invoke_O__O(self any) any { var tmp1 any; tmp55 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) {
													var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()); var tmp4 jrt.Number_I; var na_83 any = t.F_indent; if jrt.Long_InstanceOf(na_83) { var n0_84 int64 = jrt.NN(jrt.Long_Cast(na_83)).LongValue__J(); if n0_84 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_83) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_84 + 1)) } } else { if jrt.Double_InstanceOf(na_83) { var n0_84_2 float64 = jrt.NN(jrt.Double_Cast(na_83)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_84_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_83) } }; var tmp5 any = tmp4; var tmp6 *jrt.Boolean; var or__1927000174__auto____3 bool = lang.Numbers_IsZero_J__Z_NoInit(t.F_i); if or__1927000174__auto____3 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3) } else { var tmp7 bool; var tmp8 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_85 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var na_86 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_last_start); var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_85); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_86) }; tmp9 = tmp10; if tmp9 { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); var n1_88 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); tmp7 = n0_87 > n1_88 } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_85); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_86) }; tmp11 = tmp12; if tmp11 { var n0_87_2 float64 = jrt.NN(jrt.Double_Cast(na_85)).DoubleValue__D(); var n1_88_2 float64 = jrt.NN(jrt.Double_Cast(na_86)).DoubleValue__D(); tmp7 = n1_88_2 < n0_87_2 } else { tmp7 = lang.Numbers_Gt_O_O__Z_NoInit(na_85, na_86) } }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7) }; tmp3.Invoke_O_O__O(tmp5, tmp6.Ref()) } else {
//line :609:1
			var tmp13 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t.F_t)

			if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp14 bool; var na_77 any = t.F_pre; if jrt.Long_InstanceOf(na_77) { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); tmp14 = n0_78 > 0 } else { if jrt.Double_InstanceOf(na_77) { var n0_78_2 float64 = jrt.NN(jrt.Double_Cast(na_77)).DoubleValue__D(); tmp14 = n0_78_2 > 0.0 } else { tmp14 = lang.Numbers_IsPos_O__Z_NoInit(na_77) } }; tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp14).Ref() } else { tmp13 = and__1927000168__auto____3 }
//line :609:1
			if jrt.J2g_Truth(tmp13) {

				var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp16 jrt.Number_I; var na_90 int64 = lang.RT_LongCast_O__J_NoInit(t.F_t); var na_91 any = t.F_pre; if jrt.Long_InstanceOf(na_91) { var n0_92 int64 = na_90; var n1_93 int64 = jrt.NN(jrt.Long_Cast(na_91)).LongValue__J(); var nr_94 int64 = n0_92 - n1_93; var tmp17 bool; var tmp18 bool; tmp18 = !(n1_93 == -9223372036854775808); if tmp18 { tmp18 = (n0_92^n1_93)&(n0_92^nr_94) >= 0 }; tmp17 = tmp18; if tmp17 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_94)) } else { tmp16 = lang.Numbers_Minus_J_O__Number_NoInit(na_90, na_91) } } else { tmp16 = lang.Numbers_Minus_J_O__Number_NoInit(na_90, na_91) }; var tmp19 any = tmp16; var tmp20 jrt.Number_I; var tmp21 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_95 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp21.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_95) { var n0_96 int64 = jrt.NN(jrt.Long_Cast(na_95)).LongValue__J(); if n0_96 == 9223372036854775807 { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_95) } else { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_96 + 1)) } } else { if jrt.Double_InstanceOf(na_95) { var n0_96_2 float64 = jrt.NN(jrt.Double_Cast(na_95)).DoubleValue__D(); tmp20 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_96_2 + 1.0)) } else { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_95) } }; var tmp22 any = lang.Numbers_Max_O_O__O_NoInit(tmp19, tmp20); var tmp23 any = jrt.Boolean_FALSE.Ref(); var tmp24 jrt.Number_I; var na_97 any = t.F_indent; if jrt.Long_InstanceOf(na_97) { var n0_98 int64 = jrt.NN(jrt.Long_Cast(na_97)).LongValue__J(); if n0_98 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_97) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_98 + 1)) } } else { if jrt.Double_InstanceOf(na_97) { var n0_98_2 float64 = jrt.NN(jrt.Double_Cast(na_97)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_98_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_97) } }; tmp15.Invoke_O_O_O_O__O(tmp22, tmp23, Lit_36, tmp24) } else {
//line :609:1
					var tmp25 bool; var na_79 any = t.F_pre


					if jrt.Long_InstanceOf(na_79) { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); tmp25 = n0_80 > 0 } else { if jrt.Double_InstanceOf(na_79) { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); tmp25 = n0_80_2 > 0.0 } else { tmp25 = lang.Numbers_IsPos_O__Z_NoInit(na_79) } }
//line :609:1
					if tmp25 {


						var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp27 any = A_arbace_repr_go_print_code_A_const_82; var tmp28 any = jrt.Boolean_FALSE.Ref(); var tmp29 jrt.Number_I; var na_99 any = t.F_indent; if jrt.Long_InstanceOf(na_99) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); if n0_100 == 9223372036854775807 { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_99) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_100 + 1)) } } else { if jrt.Double_InstanceOf(na_99) { var n0_100_2 float64 = jrt.NN(jrt.Double_Cast(na_99)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_100_2 + 1.0)) } else { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_99) } }; tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, Lit_36, tmp29) } else {
//line :609:1
							if A_arbace_repr_go_print_code_A_const_42 != nil {



								var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp31 any = t.F_t; var tmp32 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_i)).Ref(); var tmp33 jrt.Number_I; var na_101 any = t.F_indent; if jrt.Long_InstanceOf(na_101) { var n0_102 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); if n0_102 == 9223372036854775807 { tmp33 = lang.Numbers_Inc_O__Number_NoInit(na_101) } else { tmp33 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_102 + 1)) } } else { if jrt.Double_InstanceOf(na_101) { var n0_102_2 float64 = jrt.NN(jrt.Double_Cast(na_101)).DoubleValue__D(); tmp33 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_102_2 + 1.0)) } else { tmp33 = lang.Numbers_Inc_O__Number_NoInit(na_101) } }; tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, Lit_36, tmp33) } } } }
		var tmp34 bool; var na_81 any; var t_ any = t.F_pre; t.F_pre = nil; na_81 = t_; if jrt.Long_InstanceOf(na_81) { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); tmp34 = n0_82 > 0 } else { if jrt.Double_InstanceOf(na_81) { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); tmp34 = n0_82_2 > 0.0 } else { tmp34 = lang.Numbers_IsPos_O__Z_NoInit(na_81) } }; if tmp34 {
			var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_189.GetRawRoot__O()); var tmp36 any; var t__2 any = t.F_doc; t.F_doc = nil; tmp36 = t__2; var tmp37 any = tmp36; var tmp38 jrt.Number_I; var na_103 any = t.F_indent; if jrt.Long_InstanceOf(na_103) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_103)).LongValue__J(); if n0_104 == 9223372036854775807 { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_103) } else { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_104 + 1)) } } else { if jrt.Double_InstanceOf(na_103) { var n0_104_2 float64 = jrt.NN(jrt.Double_Cast(na_103)).DoubleValue__D(); tmp38 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_104_2 + 1.0)) } else { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_103) } }; tmp35.Invoke_O_O__O(tmp37, tmp38)
			var tmp39 any; var tmp40 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____3_2 any = tmp40.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp39 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t.F_t) } else { tmp39 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp39) { var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp42 any; var t__3 any = t.F_t; t.F_t = nil; tmp42 = t__3; var tmp43 any = tmp42; var tmp44 any = jrt.Boolean_TRUE.Ref(); var tmp45 jrt.Number_I; var na_105 any; var t__4 any = t.F_indent; t.F_indent = nil; na_105 = t__4; if jrt.Long_InstanceOf(na_105) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_105)).LongValue__J(); if n0_106 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_105) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_106 + 1)) } } else { if jrt.Double_InstanceOf(na_105) { var n0_106_2 float64 = jrt.NN(jrt.Double_Cast(na_105)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_106_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_105) } }; tmp41.Invoke_O_O_O_O__O(tmp43, tmp44, nil, tmp45) } }
		var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_208.GetRawRoot__O()); var tmp47 any; var t__5 any = t.F_last_start; t.F_last_start = nil; tmp47 = t__5; var tmp48 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; tmp46.Invoke_O_O__O(tmp47, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp48.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())))
		var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_204.GetRawRoot__O()); var tmp50 any; var t__6 any = t.F_g; t.F_g = nil; tmp50 = t__6; var tmp51 any = tmp50; var tmp52 any; var t__7 any = t.F_struct_QMARK_; t.F_struct_QMARK_ = nil; tmp52 = t__7; var tmp53 any = tmp52; var tmp54 any; var t__8 any = t.F_sep; t.F_sep = nil; tmp54 = t__8; tmp1 = tmp49.Invoke_O_O_O__O(tmp51, tmp53, tmp54) }
//line :608:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp55 != nil { panic(tmp55) }; return tmp1 }

















func A_arbace_repr_go_print_code_chan_type_A_New() *A_arbace_repr_go_print_code_chan_type_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_chan_type_A{}; t.Ctor(); return t }
//line :626:1
func (t *A_arbace_repr_go_print_code_chan_type_A) Ctor() {}
//line :626:1
func (t *A_arbace_repr_go_print_code_chan_type_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000252__2 any = f__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000252__2, lang.RT_IntCast_J__I_NoInit(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000252__2, lang.RT_IntCast_J__I_NoInit(1), nil); var b__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000252__2, lang.RT_IntCast_J__I_NoInit(2), nil); var dir__6 any; _ = ___3; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(a__4)) { dir__6 = a__4 } else { dir__6 = nil }; var elem__7 any; if
	jrt.J2g_Truth(dir__6) { elem__7 = b__5 } else { elem__7 = a__4 }; var G__74000255__8_ any = dir__6; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__74000255__8_) >> 8 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__74000255__8_, nil) {


		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_31, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_212))
//line :630:1
		break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__74000255__8_, A_arbace_repr_go_print_code_A_const_211) {

			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_31, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_212)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_32, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_213))
//line :630:1
			break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__74000255__8_, A_arbace_repr_go_print_code_A_const_210) {
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_32, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_212)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_31, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_214))
//line :630:1
				break L1 }; default:
	}


		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_33, f__0)};
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp1 any; var and__1927000168__auto____8 any =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(dir__6, A_arbace_repr_go_print_code_A_const_210); if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(elem__7); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(elem__7), Lit_31); if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(elem__7), A_arbace_repr_go_print_code_A_const_210); if and__1927000168__auto____11 { var and__1927000168__auto____12 bool = lang.Util_Identical_O_O__Z_NoInit(dir__6, nil); if and__1927000168__auto____12 {
		var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else {
//line :636:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {

				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(elem__7); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(elem__7) } }

func A_arbace_repr_go_print_code_type_list_A_New() *A_arbace_repr_go_print_code_type_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_list_A{}; t.Ctor(); return t }
//line :641:1
func (t *A_arbace_repr_go_print_code_type_list_A) Ctor() {}
//line :641:1
func (t *A_arbace_repr_go_print_code_type_list_A) DoInvoke_O_O_O__O(self, ts__0, p__74000257__1 any) any { var vec__74000258__3 any = p__74000257__1; var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000258__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_type_list_fn__74000261_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_repr_go_print_code_type_list_fn__74000261_A_fn_class; if


	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_208, false); A_arbace_repr_go_print_code_type_list_fn__74000261_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; var tmp4 any = A_arbace_repr_go_print_code_A_const_120; var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__4, A_arbace_repr_go_print_code_A_const_215); var tmp6 any = A_arbace_repr_go_print_code_A_const_121; return tmp1.Invoke_O_O_O_O_O__O(Lit_99, Lit_101, ts__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__4, A_arbace_repr_go_print_code_A_const_216)))) }
//line :644:1
func A_arbace_repr_go_print_code_type_list_fn__74000261_A_New() *A_arbace_repr_go_print_code_type_list_fn__74000261_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_list_fn__74000261_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_repr_go_print_code_type_list_fn__74000261_A) Ctor() {}
//line :644:1
func (t *A_arbace_repr_go_print_code_type_list_fn__74000261_A) Invoke_O_O_O__O(self, t__1, ___2 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__1) }



func A_arbace_repr_go_print_code_op_pos_A_New() *A_arbace_repr_go_print_code_op_pos_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_op_pos_A{}; t.Ctor(); return t }
//line :648:1
func (t *A_arbace_repr_go_print_code_op_pos_A) Ctor() {}
//line :648:1
func (t *A_arbace_repr_go_print_code_op_pos_A) Invoke_O_O_O__O(self, f__0, i__1 any) any {


	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_217; var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var ops__4 any = temp__1927000408__auto____3; return lang.RT_Get_O_O__O_NoInit(ops__4, i__1) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_218) } } else {
//line :651:1
			return nil
		}
}
func A_arbace_repr_go_print_code_type_expr_A_New() *A_arbace_repr_go_print_code_type_expr_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_expr_A{}; t.Ctor(); return t }
//line :654:1
func (t *A_arbace_repr_go_print_code_type_expr_A) Ctor() {}
//line :654:1
func (t *A_arbace_repr_go_print_code_type_expr_A) Invoke_O_O__O(self, f__0 any) any {


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(f__0))
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_219.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_220.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :658:1
			var tmp1 any; var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____2 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())

			if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { tmp1 = and__1927000168__auto____2 }
//line :658:1
			if jrt.J2g_Truth(tmp1) {


				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_222.GetRawRoot__O()); var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; var tmp6 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp7 any = A_arbace_repr_go_print_code_type_expr_fn__74000265_A_New_O(f__0); var tmp8 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_repr_go_print_code_type_expr_fn__74000265_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_198, false); A_arbace_repr_go_print_code_type_expr_fn__74000265_A_fn_class = fncls__111d; tmp8 = fncls__111d } else { tmp8 = fncls__111 }; return tmp4.Invoke_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :658:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)) {



						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :658:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)) { var o__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)
								var G__74000267__3_ any = o__2





								switch lang.Util_Hash_O__I_NoInit(G__74000267__3_) >> 0 & 127 { case 18: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_199) {

									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_215)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_101); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :665:1
								case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_84) {



















									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :665:1
								case 42: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_4) {
									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_4, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_226)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :665:1
								case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_200) {













									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_200, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_228.GetRawRoot__O()).Invoke_O__O(f__0), jrt.Boolean_FALSE.Ref(), f__0) }
//line :665:1
								case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_26) { var vec__74000268__4 any = f__0; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000268__4, lang.RT_IntCast_J__I_NoInit(0), nil); var params__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000268__4, lang.RT_IntCast_J__I_NoInit(1), nil); var results__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000268__4, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5











									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_26, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_229)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_227.GetRawRoot__O()).Invoke_O_O__O(params__6, results__7) }
//line :665:1
								case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_93) {


















									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_224.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(f__0), f__0) }
//line :665:1
								case 82: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_31) {









									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_230.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :665:1
								case 85: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_201) {












									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_201, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_228.GetRawRoot__O()).Invoke_O__O(f__0), jrt.Boolean_TRUE.Ref(), f__0) }
//line :665:1
								case 88: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_202) {

















									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_203, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_218)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :665:1
								case 89: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_204) { var vec__74000271__4 any = f__0; var ___5_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000271__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000271__4, lang.RT_IntCast_J__I_NoInit(1), nil); var t__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000271__4, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5_2



									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_215))
									if lang.Util_Equiv_O_O__Z_NoInit(n__6, A_arbace_repr_go_print_code_A_const_231) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_25, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(n__6, A_arbace_repr_go_print_code_A_const_153)) } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp9 any = A_arbace_repr_go_print_code_type_expr_fn__74000274_A_New_O(n__6); var tmp10 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_repr_go_print_code_type_expr_fn__74000274_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_205, false); A_arbace_repr_go_print_code_type_expr_fn__74000274_A_fn_class = fncls__112d; tmp10 = fncls__112d } else { tmp10 = fncls__112 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() }
									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_101)
									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__7) }
//line :665:1
								case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_206) { var vec__74000276__4 any = f__0; var ___5_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000276__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000276__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000276__4, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5_3








									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_206, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_234)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_99); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(k__6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_101); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(v__7) }
//line :665:1
								case 124: if lang.Util_Equiv_O_O__Z_NoInit(G__74000267__3_, Lit_5) { var seq_74000279__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_228.GetRawRoot__O()).Invoke_O__O(f__0))); var chunk_74000280__5 any; var count_74000281__6 int64 = 0; var i_74000282__7 int64 = 0; L2: for {














									if lang.Numbers_Lt_J_J__Z_NoInit(i_74000282__7, count_74000281__6) { var vec__74000283__8 any = lang.Indexed_Cast(chunk_74000280__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000282__7)); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000283__8, lang.RT_IntCast_J__I_NoInit(0), nil); var t__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000283__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 bool; var na_113 any = i__9
										if jrt.Long_InstanceOf(na_113) { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); tmp11 = n0_114 > 0 } else { if jrt.Double_InstanceOf(na_113) { var n0_114_2 float64 = jrt.NN(jrt.Double_Cast(na_113)).DoubleValue__D(); tmp11 = n0_114_2 > 0.0 } else { tmp11 = lang.Numbers_IsPos_O__Z_NoInit(na_113) } }; if tmp11 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_235.GetRawRoot__O()); var tmp14 jrt.Number_I; var na_115 any = i__9; if jrt.Long_InstanceOf(na_115) { var n0_116 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); if n0_116 == -9223372036854775808 { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_115) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_116 - 1)) } } else { if jrt.Double_InstanceOf(na_115) { var n0_116_2 float64 = jrt.NN(jrt.Double_Cast(na_115)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_116_2 - 1.0)) } else { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_115) } }; tmp12.Invoke_O_O__O(Lit_5, tmp13.Invoke_O_O__O(f__0, tmp14)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
										lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__10)
//line :680:1
										seq_74000279__4, chunk_74000280__5, count_74000281__6, i_74000282__7 = seq_74000279__4, chunk_74000280__5, count_74000281__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000282__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000279__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_74000279__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000279__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000279__9); seq_74000279__4, chunk_74000280__5, count_74000281__6, i_74000282__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000279__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__74000286__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000279__9); var i__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000286__10, lang.RT_IntCast_J__I_NoInit(0), nil); var t__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000286__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 bool; var na_117 any = i__11
											if jrt.Long_InstanceOf(na_117) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); tmp15 = n0_118 > 0 } else { if jrt.Double_InstanceOf(na_117) { var n0_118_2 float64 = jrt.NN(jrt.Double_Cast(na_117)).DoubleValue__D(); tmp15 = n0_118_2 > 0.0 } else { tmp15 = lang.Numbers_IsPos_O__Z_NoInit(na_117) } }; if tmp15 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_235.GetRawRoot__O()); var tmp18 jrt.Number_I; var na_119 any = i__11; if jrt.Long_InstanceOf(na_119) { var n0_120 int64 = jrt.NN(jrt.Long_Cast(na_119)).LongValue__J(); if n0_120 == -9223372036854775808 { tmp18 = lang.Numbers_Dec_O__Number_NoInit(na_119) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_120 - 1)) } } else { if jrt.Double_InstanceOf(na_119) { var n0_120_2 float64 = jrt.NN(jrt.Double_Cast(na_119)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_120_2 - 1.0)) } else { tmp18 = lang.Numbers_Dec_O__Number_NoInit(na_119) } }; tmp16.Invoke_O_O__O(Lit_5, tmp17.Invoke_O_O__O(f__0, tmp18)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
											lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__12)
//line :680:1
											seq_74000279__4, chunk_74000280__5, count_74000281__6, i_74000282__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000279__9), nil, 0, 0; continue L2 } } else { return nil } } } }
//line :665:1
								default:
								}




















								var tmp19 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp19 = or__1927000174__auto____4 } else { tmp19 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0)) }; if jrt.J2g_Truth(tmp19) {
									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_224.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0), f__0) } else {
										return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_207, f__0) } } else {
//line :658:1
											if A_arbace_repr_go_print_code_A_const_42 != nil {































												return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_207, f__0) } else {
//line :658:1
													return nil
												}
										} } } } }
func A_arbace_repr_go_print_code_type_expr_fn__74000265_A_New_O(p0 any) *A_arbace_repr_go_print_code_type_expr_fn__74000265_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_expr_fn__74000265_A{}; t.Ctor_O(p0); return t }
//line :661:1
func (t *A_arbace_repr_go_print_code_type_expr_fn__74000265_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :661:1
func (t *A_arbace_repr_go_print_code_type_expr_fn__74000265_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_225.GetRawRoot__O()); var tmp2 any = t.F_f; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_code_A_const_16.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_221)) }








func A_arbace_repr_go_print_code_type_expr_fn__74000274_A_New_O(p0 any) *A_arbace_repr_go_print_code_type_expr_fn__74000274_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_expr_fn__74000274_A{}; t.Ctor_O(p0); return t }
//line :670:1
func (t *A_arbace_repr_go_print_code_type_expr_fn__74000274_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :670:1
func (t *A_arbace_repr_go_print_code_type_expr_fn__74000274_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_repr_go_print_code_type_form_QMARK__A_New() *A_arbace_repr_go_print_code_type_form_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_form_QMARK__A{}; t.Ctor(); return t }
//line :692:1
func (t *A_arbace_repr_go_print_code_type_form_QMARK__A) Ctor() {}
//line :692:1
func (t *A_arbace_repr_go_print_code_type_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.J2g_Truth(and__1927000168__auto____2) { var o__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_236.GetRawRoot__O(), o__3)

		if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(o__3, Lit_4)
			if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(f__0)))).Ref() } } else {
//line :698:1
				return and__1927000168__auto____4 } } else {
//line :696:1
					return and__1927000168__auto____2 } }




func A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A_New() *A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A) Ctor() {}
//line :701:1
func (t *A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if
														jrt.J2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_4)).Ref() } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)
															if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_5); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_237.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } }

func A_arbace_repr_go_print_code_type_params_A_New() *A_arbace_repr_go_print_code_type_params_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_params_A{}; t.Ctor(); return t }
//line :705:1
func (t *A_arbace_repr_go_print_code_type_params_A) Ctor() {}
//line :705:1
func (t *A_arbace_repr_go_print_code_type_params_A) Invoke_O_O__O(self, tps__0 any) any { var entries__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_type_params_fn__74000292_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_repr_go_print_code_type_params_fn__74000292_A_fn_class; if



	fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_209, false); A_arbace_repr_go_print_code_type_params_fn__74000292_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; entries__2 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tps__0); var groups__3 any = /*line :705:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_147.GetRawRoot__O()).Invoke_O__O(entries__2);








	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(tps__0, A_arbace_repr_go_print_code_A_const_156)); var seq_74000294__4 any = /*line :705:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), groups__3)); var chunk_74000295__5 any; var count_74000296__6 int64 = 0; var i_74000297__7 int64 = 0; L1: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(i_74000297__7, count_74000296__6) { var vec__74000298__8 any = lang.Indexed_Cast(chunk_74000295__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000297__7)); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000298__8, lang.RT_IntCast_J__I_NoInit(0), nil); var g__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000298__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 bool; var na_122 any = i__9
			if jrt.Long_InstanceOf(na_122) { var n0_123 int64 = jrt.NN(jrt.Long_Cast(na_122)).LongValue__J(); tmp4 = n0_123 > 0 } else { if jrt.Double_InstanceOf(na_122) { var n0_123_2 float64 = jrt.NN(jrt.Double_Cast(na_122)).DoubleValue__D(); tmp4 = n0_123_2 > 0.0 } else { tmp4 = lang.Numbers_IsPos_O__Z_NoInit(na_122) } }; if tmp4 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_155.GetRawRoot__O()).Invoke_O__O(g__10)) }
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__10))
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__10))
//line :715:1
			seq_74000294__4, chunk_74000295__5, count_74000296__6, i_74000297__7 = seq_74000294__4, chunk_74000295__5, count_74000296__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000297__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000294__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_74000294__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000294__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000294__9); seq_74000294__4, chunk_74000295__5, count_74000296__6, i_74000297__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000294__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000301__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000294__9); var i__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000301__10, lang.RT_IntCast_J__I_NoInit(0), nil); var g__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000301__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 bool; var na_124 any = i__11
				if jrt.Long_InstanceOf(na_124) { var n0_125 int64 = jrt.NN(jrt.Long_Cast(na_124)).LongValue__J(); tmp5 = n0_125 > 0 } else { if jrt.Double_InstanceOf(na_124) { var n0_125_2 float64 = jrt.NN(jrt.Double_Cast(na_124)).DoubleValue__D(); tmp5 = n0_125_2 > 0.0 } else { tmp5 = lang.Numbers_IsPos_O__Z_NoInit(na_124) } }; if tmp5 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_155.GetRawRoot__O()).Invoke_O__O(g__12)) }
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_104.Invoke_O__O(g__12))
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_135.Invoke_O__O(g__12))
//line :715:1
				seq_74000294__4, chunk_74000295__5, count_74000296__6, i_74000297__7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000294__9), nil, 0, 0; continue L1 } } }
//line :705:1
		break L1 }; var tmp6 any; var and__1927000168__auto____4 bool =














	lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(groups__3))); if and__1927000168__auto____4 { var tmp7 *lang.Keyword = A_arbace_repr_go_print_code_A_const_104; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(groups__3))))); if and__1927000168__auto____5 {
		var tmp8 *lang.Keyword = A_arbace_repr_go_print_code_A_const_135; tmp6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_237.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(groups__3))) } else {
//line :720:1
			tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp6) {

				var tmp9 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp9.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_131, Lit_41) } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41) } };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_131, Lit_41); return /*line :724:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_101, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(tps__0, A_arbace_repr_go_print_code_A_const_157)) }
//line :709:1
func A_arbace_repr_go_print_code_type_params_fn__74000292_A_New() *A_arbace_repr_go_print_code_type_params_fn__74000292_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_params_fn__74000292_A{}; t.Ctor(); return t }
//line :709:1
func (t *A_arbace_repr_go_print_code_type_params_fn__74000292_A) Ctor() {}
//line :709:1
func (t *A_arbace_repr_go_print_code_type_params_fn__74000292_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any = A_arbace_repr_go_print_code_A_const_134; var tmp2 any = A_arbace_repr_go_print_code_A_const_135; var tmp3 any; if
													jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p__1), A_arbace_repr_go_print_code_A_const_31)) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; tmp3 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p__1)) } else { tmp3 = A_arbace_repr_go_print_code_A_const_238 }; var tmp5 any = tmp3; var tmp6 any = A_arbace_repr_go_print_code_A_const_137; return /*line :709:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, p__1, tmp2, tmp5, tmp6, lang.RT_Meta_O__IPersistentMap_NoInit(p__1), A_arbace_repr_go_print_code_A_const_103, p__1)) }





















func A_arbace_repr_go_print_code_walk_right_A_New() *A_arbace_repr_go_print_code_walk_right_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_walk_right_A{}; t.Ctor(); return t }
//line :731:1
func (t *A_arbace_repr_go_print_code_walk_right_A) Ctor() {}
//line :731:1
func (t *A_arbace_repr_go_print_code_walk_right_A) Invoke_O_O_O_O__O(self, o__0, prec__1, r__2 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O()).Invoke_O__O(r__2)) {
		if lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(r__2)), lang.RT_LongCast_O__J_NoInit(prec__1)) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_239.GetRawRoot__O()).Invoke_O__O(r__2) } else { return A_arbace_repr_go_print_code_A_const_240 } } else {
//line :735:1
			var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(r__2)

			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(r__2), Lit_156); if and__1927000168__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(r__2)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp1 = and__1927000168__auto____4 }
//line :735:1
			if jrt.J2g_Truth(tmp1) { var tmp2 any = jrt.Boolean_FALSE.Ref(); var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any


				if lang.Util_Equiv_O_O__Z_NoInit(o__0, Lit_215) { tmp4 = A_arbace_repr_go_print_code_A_const_243 } else { tmp4 = A_arbace_repr_go_print_code_A_const_188 }
//line :735:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, tmp4) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_70.GetRawRoot__O()).Invoke_O__O(r__2)) { var s__4 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, o__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_241.GetRawRoot__O()).Invoke_O__O(r__2))).Ref(); var tmp5 any = jrt.Boolean_FALSE.Ref(); var tmp6 any = jrt.Boolean_FALSE.Ref(); var tmp7 any





					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_244).Invoke_O__O(s__4)) { tmp7 = A_arbace_repr_go_print_code_A_const_243 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_245).Invoke_O__O(s__4)) { tmp7 = A_arbace_repr_go_print_code_A_const_246 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { tmp7 = A_arbace_repr_go_print_code_A_const_188 } else { tmp7 = nil } } }
//line :735:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_repr_go_print_code_A_const_42 != nil { return A_arbace_repr_go_print_code_A_const_242 } else { return nil
					}
					}
				}
		}
}



func A_arbace_repr_go_print_code_walk_prefixes_A_New() *A_arbace_repr_go_print_code_walk_prefixes_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_walk_prefixes_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_repr_go_print_code_walk_prefixes_A) Ctor() {}
//line :744:1
func (t *A_arbace_repr_go_print_code_walk_prefixes_A) Invoke_O_O__O(self, f__0 any) any { { var prec__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(f__0); var o__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_247.GetRawRoot__O()).Invoke_O__O(f__0); var xs__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0)); var x1__5 any = lang.RT_Nth_O_I__O_NoInit(xs__4, lang.RT_IntCast_J__I_NoInit(0)); var vec__74000306__6 any; var tmp1 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O()).Invoke_O__O(x1__5)








	if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(x1__5)), lang.RT_LongCast_O__J_NoInit(prec__2))).Ref() } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { vec__74000306__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_239.GetRawRoot__O()).Invoke_O__O(x1__5) } else { vec__74000306__6 = A_arbace_repr_go_print_code_A_const_248 }
//line :744:1
	var h4__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000306__6, lang.RT_IntCast_J__I_NoInit(0), nil); var h5__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000306__6, lang.RT_IntCast_J__I_NoInit(1), nil); var mp__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000306__6, lang.RT_IntCast_J__I_NoInit(2), nil); var i__10 int64 = 1; var acc__11 any; var tmp2 any; var or__1927000174__auto____11 bool = lang.Util_Equiv_O_J__Z_NoInit(prec__2, 4)









	if or__1927000174__auto____11 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { tmp2 = h4__7 }
//line :744:1
	var tmp3 any = tmp2; var tmp4 any; var or__1927000174__auto____11_2 bool = lang.Util_Equiv_O_J__Z_NoInit(prec__2, 5)









	if or__1927000174__auto____11_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11_2).Ref() } else { tmp4 = h5__8 }
//line :744:1
	acc__11 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp4, mp__9); var out__12 any = lang.PersistentVector_EMPTY.Ref(); L1: for {










		if lang.Numbers_Lt_J_J__Z_NoInit(i__10, int64(lang.RT_Count_O__I_NoInit(xs__4))) { var vec__74000309__13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_249.GetRawRoot__O()).Invoke_O_O_O__O(o__3, prec__2, lang.RT_Nth_O_I__O_NoInit(xs__4, lang.RT_IntCast_J__I_NoInit(i__10))); var rh4__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000309__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rh5__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000309__13, lang.RT_IntCast_J__I_NoInit(1), nil); var rmp__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000309__13, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__74000312__17 any = acc__11; var a4__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000312__17, lang.RT_IntCast_J__I_NoInit(0), nil); var a5__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000312__17, lang.RT_IntCast_J__I_NoInit(1), nil); var amp__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000312__17, lang.RT_IntCast_J__I_NoInit(2), nil); var w__21 any; var tmp5 any
			var or__1927000174__auto____21 any = a4__18

			if jrt.J2g_Truth(or__1927000174__auto____21) { tmp5 = or__1927000174__auto____21 } else { tmp5 = rh4__14 }
//line :755:1
			var tmp6 any = tmp5; var tmp7 any
			var or__1927000174__auto____21_2 any = a5__19

			if jrt.J2g_Truth(or__1927000174__auto____21_2) { tmp7 = or__1927000174__auto____21_2 } else { tmp7 = rh5__15 }
//line :755:1
			w__21 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(amp__20), lang.RT_LongCast_O__J_NoInit(rmp__16))).Ref())



			i__10, acc__11, out__12 = lang.Numbers_Inc_J__J_NoInit(i__10), w__21, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(out__12, w__21); continue L1 } else {
//line :755:1
				return out__12 } } }; /*line :744:1*/panic("j2g: unreachable") }

















func A_arbace_repr_go_print_code_walk_binary_A_New() *A_arbace_repr_go_print_code_walk_binary_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_walk_binary_A{}; t.Ctor(); return t }
//line :762:1
func (t *A_arbace_repr_go_print_code_walk_binary_A) Ctor() {}
//line :762:1
func (t *A_arbace_repr_go_print_code_walk_binary_A) Invoke_O_O__O(self, f__0 any) any {


	return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_250.GetRawRoot__O()).Invoke_O__O(f__0))
}
func A_arbace_repr_go_print_code_cutoff_of_A_New() *A_arbace_repr_go_print_code_cutoff_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_cutoff_of_A{}; t.Ctor(); return t }
//line :767:1
func (t *A_arbace_repr_go_print_code_cutoff_of_A) Ctor() {}
//line :767:1
func (t *A_arbace_repr_go_print_code_cutoff_of_A) Invoke_O_O_O__O(self, p__74000317__0, depth__1 any) any { var vec__74000318__3 any = p__74000317__0; var has4__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000318__3, lang.RT_IntCast_J__I_NoInit(0), nil); var has5__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000318__3, lang.RT_IntCast_J__I_NoInit(1), nil); var mp__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000318__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 bool; var na_126 any = mp__6; if

	jrt.Long_InstanceOf(na_126) { var n0_127 int64 = jrt.NN(jrt.Long_Cast(na_126)).LongValue__J(); tmp1 = n0_127 > 0 } else { if jrt.Double_InstanceOf(na_126) { var n0_127_2 float64 = jrt.NN(jrt.Double_Cast(na_126)).DoubleValue__D(); tmp1 = n0_127_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_126) } }; if tmp1 { var na_128 any = mp__6; if jrt.Long_InstanceOf(na_128) { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_128)).LongValue__J(); if n0_129 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_128) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_129 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_128) { var n0_129_2 float64 = jrt.NN(jrt.Double_Cast(na_128)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_129_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_128) } } } else {
//line :768:1
		var tmp2 any
		var and__1927000168__auto____7 any = has4__4
		if jrt.J2g_Truth(and__1927000168__auto____7) { tmp2 = has5__5 } else { tmp2 = and__1927000168__auto____7 }
//line :768:1
		if jrt.J2g_Truth(tmp2) {

			if lang.Util_Equiv_O_J__Z_NoInit(depth__1, 1) { return A_arbace_repr_go_print_code_A_const_243 } else { return A_arbace_repr_go_print_code_A_const_246 } } else {
//line :768:1
				if lang.Util_Equiv_O_J__Z_NoInit(depth__1, 1) { return A_arbace_repr_go_print_code_A_const_71 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { return A_arbace_repr_go_print_code_A_const_246 } else { return nil } } } } }





func A_arbace_repr_go_print_code_cutoff_A_New() *A_arbace_repr_go_print_code_cutoff_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_cutoff_A{}; t.Ctor(); return t }
//line :774:1
func (t *A_arbace_repr_go_print_code_cutoff_A) Ctor() {}
//line :774:1
func (t *A_arbace_repr_go_print_code_cutoff_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_251.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_239.GetRawRoot__O()).Invoke_O__O(f__0), depth__1) }

func A_arbace_repr_go_print_code_diff_prec_A_New() *A_arbace_repr_go_print_code_diff_prec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_diff_prec_A{}; t.Ctor(); return t }
//line :776:1
func (t *A_arbace_repr_go_print_code_diff_prec_A) Ctor() {}
//line :776:1
func (t *A_arbace_repr_go_print_code_diff_prec_A) Invoke_O_O_O__O(self, x__0, prec__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(prec__1, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return A_arbace_repr_go_print_code_A_const_188 } else { return A_arbace_repr_go_print_code_A_const_130
	} }
func A_arbace_repr_go_print_code_reduce_depth_A_New() *A_arbace_repr_go_print_code_reduce_depth_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_reduce_depth_A{}; t.Ctor(); return t }
//line :779:1
func (t *A_arbace_repr_go_print_code_reduce_depth_A) Ctor() {}
//line :779:1
func (t *A_arbace_repr_go_print_code_reduce_depth_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 jrt.Number_I; var na_130 any = d__0; if jrt.Long_InstanceOf(na_130) { var n0_131 int64 = jrt.NN(jrt.Long_Cast(na_130)).LongValue__J(); if n0_131 == -9223372036854775808 { tmp1 = lang.Numbers_Dec_O__Number_NoInit(na_130) } else { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_131 - 1)) } } else { if jrt.Double_InstanceOf(na_130) { var n0_131_2 float64 = jrt.NN(jrt.Double_Cast(na_130)).DoubleValue__D(); tmp1 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_131_2 - 1.0)) } else { tmp1 = lang.Numbers_Dec_O__Number_NoInit(na_130) } }; return lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }

func A_arbace_repr_go_print_code_paren_operand_A_New() *A_arbace_repr_go_print_code_paren_operand_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_paren_operand_A{}; t.Ctor(); return t }
//line :781:1
func (t *A_arbace_repr_go_print_code_paren_operand_A) Ctor() {}
//line :781:1
func (t *A_arbace_repr_go_print_code_paren_operand_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_repr_go_print_code_A_const_130) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(x__0))
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6)
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp2 any = A_arbace_repr_go_print_code_paren_operand_fn__74000325_A_New_O(x__0); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_repr_go_print_code_paren_operand_fn__74000325_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_repr_go_print_code_paren_operand_fn__74000325_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } }
//line :789:1
func A_arbace_repr_go_print_code_paren_operand_fn__74000325_A_New_O(p0 any) *A_arbace_repr_go_print_code_paren_operand_fn__74000325_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_paren_operand_fn__74000325_A{}; t.Ctor_O(p0); return t }
//line :789:1
func (t *A_arbace_repr_go_print_code_paren_operand_fn__74000325_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :789:1
func (t *A_arbace_repr_go_print_code_paren_operand_fn__74000325_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_repr_go_print_code_binary_expr_A_New() *A_arbace_repr_go_print_code_binary_expr_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binary_expr_A{}; t.Ctor(); return t }
//line :792:1
func (t *A_arbace_repr_go_print_code_binary_expr_A) Ctor() {}
//line :792:1
func (t *A_arbace_repr_go_print_code_binary_expr_A) Invoke_O_O_O_O_O__O(self, f__0, prec1__1, cut__2, depth__3 any) any { { var prec__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_69.GetRawRoot__O()).Invoke_O__O(f__0); var tmp1 any; var and__1927000168__auto____6 bool; var na_133 any = prec__5; var na_134 any = prec1__1; var tmp2 bool; var tmp3 bool






	tmp3 = jrt.Long_InstanceOf(na_133); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_134) }; tmp2 = tmp3; if tmp2 { var n0_135 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); var n1_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); and__1927000168__auto____6 = n0_135 < n1_136 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_133); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_134) }; tmp4 = tmp5; if tmp4 { var n0_135_2 float64 = jrt.NN(jrt.Double_Cast(na_133)).DoubleValue__D(); var n1_136_2 float64 = jrt.NN(jrt.Double_Cast(na_134)).DoubleValue__D(); and__1927000168__auto____6 = n0_135_2 < n1_136_2 } else { and__1927000168__auto____6 = lang.Numbers_Lt_O_O__Z_NoInit(na_133, na_134) } }; if and__1927000168__auto____6 { var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6)
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp7 any = A_arbace_repr_go_print_code_binary_expr_fn__74000329_A_New_O_O(f__0, depth__3); var tmp8 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_repr_go_print_code_binary_expr_fn__74000329_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_go_print_code_binary_expr_fn__74000329_A_fn_class = fncls__138d; tmp8 = fncls__138d } else { tmp8 = fncls__138 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :799:1
			var xs__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0)); var k__7 int32 = lang.RT_Count_O__I_NoInit(xs__6); var o__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_247.GetRawRoot__O()).Invoke_O__O(f__0); var cuts__9 any







			if lang.Numbers_Gt_J_J__Z_NoInit(int64(k__7), 2) {
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_print_code_binary_expr_fn__74000331_A_New_O(depth__3); var tmp12 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_repr_go_print_code_binary_expr_fn__74000331_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_print_code_binary_expr_fn__74000331_A_fn_class = fncls__139d; tmp12 = fncls__139d } else { tmp12 = fncls__139 }; cuts__9 = tmp9.Invoke_O_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_145.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_250.GetRawRoot__O()).Invoke_O__O(f__0))), cut__2) } else {
//line :807:1
					cuts__9 = lang.Tuple_Create_O__IPersistentVector(cut__2) }
//line :799:1
			var t__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(f__0); var x1__11 any = lang.RT_Nth_O_I__O_NoInit(xs__6, lang.RT_IntCast_J__I_NoInit(0)); var n__1927000701__auto____12 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(k__7), 2)); var ___13 int64 = 0; L1: for {












				if lang.Numbers_Lt_J_J__Z_NoInit(___13, n__1927000701__auto____12) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(t__10); ___13 = lang.Numbers_Unchecked_inc_J__J_NoInit(___13); continue L1 }
//line :799:1
				break L1
			}












			var tmp13 *lang.Keyword = A_arbace_repr_go_print_code_A_const_253; if jrt.J2g_Truth(tmp13.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x1__11))) {
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_254.GetRawRoot__O()).Invoke_O__O(x1__11) } else {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()); var tmp15 jrt.Number_I; var na_140 any = depth__3; var na_141 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_256.GetRawRoot__O()).Invoke_O_O__O(x1__11, prec__5); var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_140); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_141) }; tmp16 = tmp17; if tmp16 { var n0_142 int64 = jrt.NN(jrt.Long_Cast(na_140)).LongValue__J(); var n1_143 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var nr_144 int64 = n0_142 + n1_143; if (n0_142^nr_144)&(n1_143^nr_144) >= 0 { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_144)) } else { tmp15 = lang.Numbers_Add_O_O__Number_NoInit(na_140, na_141) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_140); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_141) }; tmp18 = tmp19; if tmp18 { var n0_142_2 float64 = jrt.NN(jrt.Double_Cast(na_140)).DoubleValue__D(); var n1_143_2 float64 = jrt.NN(jrt.Double_Cast(na_141)).DoubleValue__D(); tmp15 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_142_2 + n1_143_2)) } else { tmp15 = lang.Numbers_Add_O_O__Number_NoInit(na_140, na_141) } }; tmp14.Invoke_O_O_O__O(x1__11, prec__5, tmp15) }
//line :799:1
			var n__1927000701__auto____12_2 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(k__7))); var i__13 int64 = 0; L2: for {
















				if lang.Numbers_Lt_J_J__Z_NoInit(i__13, n__1927000701__auto____12_2) { var blank_QMARK___14 bool = lang.Numbers_Lt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(prec__5), lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(cuts__9, lang.RT_IntCast_J__I_NoInit(i__13)))); var y__15 any = lang.RT_Nth_O_I__O_NoInit(xs__6, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__13)))


					if blank_QMARK___14 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(o__8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_235.GetRawRoot__O()).Invoke_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(i__13).Ref()))
//line :816:1
					var yt__16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__13, 2)).Ref(), y__15); var tmp20 any
					var and__1927000168__auto____17 any = yt__16




					if jrt.J2g_Truth(and__1927000168__auto____17) { var or__1927000174__auto____18 bool = lang.Util_Equiv_O_O__Z_NoInit(yt__16, A_arbace_repr_go_print_code_A_const_82); if or__1927000174__auto____18 { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____18).Ref() } else { var tmp21 bool; var na_145 int64 = lang.RT_LongCast_O__J_NoInit(yt__16); var tmp22 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_146 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_146) { var n0_147 int64 = na_145; var n1_148 int64 = jrt.NN(jrt.Long_Cast(na_146)).LongValue__J(); tmp21 = n0_147 > n1_148 } else { tmp21 = lang.Numbers_Gt_J_O__Z_NoInit(na_145, na_146) }; tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp21).Ref() } } else { tmp20 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp20) {
						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(yt__16) } else {
							if blank_QMARK___14 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } }
					var tmp23 *lang.Keyword = A_arbace_repr_go_print_code_A_const_253; if jrt.J2g_Truth(tmp23.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(y__15))) {
						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_254.GetRawRoot__O()).Invoke_O__O(y__15) } else {
							var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()); var tmp25 jrt.Number_I; var na_150 any = prec__5; if jrt.Long_InstanceOf(na_150) { var n0_151 int64 = jrt.NN(jrt.Long_Cast(na_150)).LongValue__J(); if n0_151 == 9223372036854775807 { tmp25 = lang.Numbers_Inc_O__Number_NoInit(na_150) } else { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_151 + 1)) } } else { if jrt.Double_InstanceOf(na_150) { var n0_151_2 float64 = jrt.NN(jrt.Double_Cast(na_150)).DoubleValue__D(); tmp25 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_151_2 + 1.0)) } else { tmp25 = lang.Numbers_Inc_O__Number_NoInit(na_150) } }; var tmp26 any = tmp25; var tmp27 jrt.Number_I; var na_152 any = depth__3; if jrt.Long_InstanceOf(na_152) { var n0_153 int64 = jrt.NN(jrt.Long_Cast(na_152)).LongValue__J(); if n0_153 == 9223372036854775807 { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_152) } else { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_153 + 1)) } } else { if jrt.Double_InstanceOf(na_152) { var n0_153_2 float64 = jrt.NN(jrt.Double_Cast(na_152)).DoubleValue__D(); tmp27 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_153_2 + 1.0)) } else { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_152) } }; tmp24.Invoke_O_O_O__O(y__15, tmp26, tmp27) }
//line :816:1
					i__13 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__13); continue L2 } else { return nil } } } }; /*line :792:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_code_binary_expr_fn__74000329_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_binary_expr_fn__74000329_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binary_expr_fn__74000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :801:1
func (t *A_arbace_repr_go_print_code_binary_expr_fn__74000329_A) Ctor_O_O(c__f, c__depth any) { t.F_f = c__f; t.F_depth = c__depth }
//line :801:1
func (t *A_arbace_repr_go_print_code_binary_expr_fn__74000329_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_252.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_depth; t.F_depth = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5.Invoke_O__O(tmp6)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }






func A_arbace_repr_go_print_code_binary_expr_fn__74000331_A_New_O(p0 any) *A_arbace_repr_go_print_code_binary_expr_fn__74000331_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binary_expr_fn__74000331_A{}; t.Ctor_O(p0); return t }
//line :808:1
func (t *A_arbace_repr_go_print_code_binary_expr_fn__74000331_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :808:1
func (t *A_arbace_repr_go_print_code_binary_expr_fn__74000331_A) Invoke_O_O__O(self, p1__74000328_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_251.GetRawRoot__O()).Invoke_O_O__O(p1__74000328_SHARP___1, t.F_depth) }




















func A_arbace_repr_go_print_code_call_args_A_New() *A_arbace_repr_go_print_code_call_args_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_call_args_A{}; t.Ctor(); return t }
//line :829:1
func (t *A_arbace_repr_go_print_code_call_args_A) Ctor() {}
//line :829:1
func (t *A_arbace_repr_go_print_code_call_args_A) Invoke_O_O_O_O_O__O(self, f__0, xs__1, depth__2, offset__3 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_call_args_fn__74000334_A_New_O_O(depth__2, f__0); var tmp3 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_repr_go_print_code_call_args_fn__74000334_A_fn_class
	if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_print_code_call_args_fn__74000334_A_fn_class = fncls__154d; tmp3 = fncls__154d } else { tmp3 = fncls__154 }
//line :832:1
	var tmp4 any = A_arbace_repr_go_print_code_A_const_116; var tmp5 any = A_arbace_repr_go_print_code_A_const_117; var tmp6 any = A_arbace_repr_go_print_code_A_const_120; var tmp7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_257); var tmp8 any = A_arbace_repr_go_print_code_A_const_121; return tmp1.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, xs__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, f__0, tmp5, offset__3, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_258)))) }
func A_arbace_repr_go_print_code_call_args_fn__74000334_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_call_args_fn__74000334_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_call_args_fn__74000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :833:1
func (t *A_arbace_repr_go_print_code_call_args_fn__74000334_A) Ctor_O_O(c__depth, c__f any) { t.F_depth = c__depth; t.F_f = c__f }
//line :833:1
func (t *A_arbace_repr_go_print_code_call_args_fn__74000334_A) Invoke_O_O_O__O(self, x__1, ___2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(x__1), Lit_24)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(x__1), t.F_depth); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_25, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_153)) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth)
		}
}
func A_arbace_repr_go_print_code_callee_A_New() *A_arbace_repr_go_print_code_callee_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_callee_A{}; t.Ctor(); return t }
//line :839:1
func (t *A_arbace_repr_go_print_code_callee_A) Ctor() {}
//line :839:1
func (t *A_arbace_repr_go_print_code_callee_A) Invoke_O_O_O__O(self, h__0, depth__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(h__0)
	if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(h__0), Lit_26); if and__1927000168__auto____4 { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = and__1927000168__auto____3 }
//line :840:1
	if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(h__0); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :840:1
			if A_arbace_repr_go_print_code_A_const_42 != nil {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(h__0, A_arbace_repr_go_print_code_A_const_72, depth__1) } else {
//line :840:1
					return nil
				}
		}
}
func A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A_New() *A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A{}; t.Ctor(); return t }
//line :844:1
func (t *A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A) Ctor() {}
//line :844:1
func (t *A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(t__0); if
													jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0)
														if jrt.J2g_Truth(and__1927000168__auto____4) { or__1927000174__auto____4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_236.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0))) } else { or__1927000174__auto____4 = and__1927000168__auto____4 }
//line :845:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0)

			if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0), Lit_93)).Ref() } else { return and__1927000168__auto____5 } } } } }

func A_arbace_repr_go_print_code_lit_elements_A_New() *A_arbace_repr_go_print_code_lit_elements_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_lit_elements_A{}; t.Ctor(); return t }
//line :849:1
func (t *A_arbace_repr_go_print_code_lit_elements_A) Ctor() {}
//line :849:1
func (t *A_arbace_repr_go_print_code_lit_elements_A) Invoke_O_O__O(self, f__0 any) any { { var xs__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(f__0)); var i__3 int64 = 2; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__2)) { return acc__4 } else { var x__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__2)


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(x__5)) {
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(xs__2)) {
				var tmp1 any = A_arbace_repr_go_print_code_A_const_259; var tmp2 any = A_arbace_repr_go_print_code_A_const_260; var tmp3 any = A_arbace_repr_go_print_code_A_const_261; var tmp4 any = A_arbace_repr_go_print_code_A_const_262; var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp6 any = A_arbace_repr_go_print_code_A_const_263; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Add_J_J__J_NoInit(i__3, 2), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, x__5, tmp4, tmp5, tmp6, jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref()))); continue L1 } else {
					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_147, f__0) } } else {
//line :855:1
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(x__5)) {



							if lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(x__5))) {
								var tmp7 any = A_arbace_repr_go_print_code_A_const_259; var tmp8 any = A_arbace_repr_go_print_code_A_const_261; var tmp9 any = A_arbace_repr_go_print_code_A_const_261; var tmp10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(x__5); var tmp11 any = A_arbace_repr_go_print_code_A_const_262; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(x__5); var tmp13 any = A_arbace_repr_go_print_code_A_const_263; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Inc_J__J_NoInit(i__3), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref(), A_arbace_repr_go_print_code_A_const_103, x__5))); continue L1 } else {
									return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_148, x__5) } } else {
//line :855:1
										if A_arbace_repr_go_print_code_A_const_42 != nil {






											var tmp14 any = A_arbace_repr_go_print_code_A_const_259; var tmp15 any = A_arbace_repr_go_print_code_A_const_264; var tmp16 any = A_arbace_repr_go_print_code_A_const_262; var tmp17 any = A_arbace_repr_go_print_code_A_const_263; xs__2, i__3, acc__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(xs__2), lang.Numbers_Inc_J__J_NoInit(i__3), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, x__5, tmp17, jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref(), A_arbace_repr_go_print_code_A_const_103, x__5))); continue L1 } else {
//line :855:1
												return nil } } } } } }; /*line :849:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_print_code_key_size_A_New() *A_arbace_repr_go_print_code_key_size_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_key_size_A{}; t.Ctor(); return t }
//line :864:1
func (t *A_arbace_repr_go_print_code_key_size_A) Ctor() {}
//line :864:1
func (t *A_arbace_repr_go_print_code_key_size_A) Invoke_O_O__O(self, el__0 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(el__0), A_arbace_repr_go_print_code_A_const_260) {
		return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(el__0)))).Ref() } else {
//line :867:1
			var k__2 any = A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(el__0)


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(k__2)) {
				return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_100.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :870:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(k__2)) {

						return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_112.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :870:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_63.GetRawRoot__O()).Invoke_O__O(k__2)) {


								return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_95.GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else {
//line :870:1
									if A_arbace_repr_go_print_code_A_const_42 != nil { return A_arbace_repr_go_print_code_A_const_265 } else { return nil
									}
								}
						}
				}
		} }
func A_arbace_repr_go_print_code_composite_lit_A_New() *A_arbace_repr_go_print_code_composite_lit_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_A{}; t.Ctor(); return t }
//line :876:1
func (t *A_arbace_repr_go_print_code_composite_lit_A) Ctor() {}
//line :876:1
func (t *A_arbace_repr_go_print_code_composite_lit_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var t__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0); var wrap_QMARK___4 any; var and__1927000168__auto____4 any = A_arbace_repr_go_print_code_A_const_233.Get__O(); if

	jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(t__3, A_arbace_repr_go_print_code_A_const_267); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_266.GetRawRoot__O()).Invoke_O__O(t__3); if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; wrap_QMARK___4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { wrap_QMARK___4 = and__1927000168__auto____6 } } else { wrap_QMARK___4 = and__1927000168__auto____5 } } else { wrap_QMARK___4 = and__1927000168__auto____4 }; if
	jrt.J2g_Truth(wrap_QMARK___4) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6) };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp2 any = A_arbace_repr_go_print_code_composite_lit_fn__74000341_A_New_O_O(f__0, t__3); var tmp3 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_repr_go_print_code_composite_lit_fn__74000341_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_print_code_composite_lit_fn__74000341_A_fn_class = fncls__175d; tmp3 = fncls__175d } else { tmp3 = fncls__175 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); if































	jrt.J2g_Truth(wrap_QMARK___4) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else { return nil } }
//line :880:1
func A_arbace_repr_go_print_code_composite_lit_fn__74000341_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_composite_lit_fn__74000341_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_fn__74000341_A{}; t.Ctor_O_O(p0, p1); return t }
//line :880:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_A) Ctor_O_O(c__f, c__t any) { t.F_f = c__f; t.F_t = c__t }
//line :880:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_A) Invoke_O__O(self any) any { var tmp1 any; tmp35 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if lang.Util_Equiv_O_O__Z_NoInit(t.F_t, A_arbace_repr_go_print_code_A_const_269) { } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_t; t.F_t = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3) }
//line :880:1
	{ var els__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_268.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var start__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var brk__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_83.GetRawRoot__O()).Invoke_O__O(t.F_f); var ts__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A_New_O_O(t.F_f, brk__5); var tmp7 *jrt.Class
		var fncls__160 /*line :880:1*/*jrt.Class = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A_fn_class




		if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A_fn_class = fncls__160d; tmp7 = fncls__160d } else { tmp7 = fncls__160 }; ts__6 = tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), els__3)
//line :880:1
		var nxt__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_122.GetRawRoot__O()).Invoke_O__O(ts__6); var multi_QMARK___8 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A_New_O(start__4); var tmp10 *jrt.Class
		var fncls__166 /*line :880:1*/*jrt.Class = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A_fn_class






		if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A_fn_class = fncls__166d; tmp10 = fncls__166d } else { tmp10 = fncls__166 }; multi_QMARK___8 = tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), ts__6)
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_202))
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke__O()
//line :880:1
		var n__9 int32 = lang.RT_Count_O__I_NoInit(els__3); var seq_74000346__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), els__3)); var chunk_74000347__11 any; var count_74000348__12 int64 = 0; var i_74000349__13 int64 = 0; L1: for {










			if lang.Numbers_Lt_J_J__Z_NoInit(i_74000349__13, count_74000348__12) { var vec__74000350__14 any = lang.Indexed_Cast(chunk_74000347__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000349__13)); var i__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000350__14, lang.RT_IntCast_J__I_NoInit(0), nil); var el__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000350__14, lang.RT_IntCast_J__I_NoInit(1), nil); var tl__17 any = lang.RT_Nth_O_I__O_NoInit(ts__6, lang.RT_IntCast_O__I_NoInit(i__15)); var tmp11 bool
				var na_169 any = i__15
				if jrt.Long_InstanceOf(na_169) { var n0_170 int64 = jrt.NN(jrt.Long_Cast(na_169)).LongValue__J(); tmp11 = n0_170 > 0 } else { if jrt.Double_InstanceOf(na_169) { var n0_170_2 float64 = jrt.NN(jrt.Double_Cast(na_169)).DoubleValue__D(); tmp11 = n0_170_2 > 0.0 } else { tmp11 = lang.Numbers_IsPos_O__Z_NoInit(na_169) } }; if tmp11 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(tl__17)
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_code_A_const_86; var tmp15 any; var or__1927000174__auto____18 any = lang.RT_Nth_O_I__O_NoInit(nxt__7, lang.RT_IntCast_O__I_NoInit(i__15)); if jrt.J2g_Truth(or__1927000174__auto____18) { tmp15 = or__1927000174__auto____18 } else { tmp15 = A_arbace_repr_go_print_code_A_const_86.Get__O() }; tmp12.Invoke_O__O(tmp13.Invoke_O_O__O(tmp14, tmp15)); var tmp16 any = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A_New_O_I_O_O(t.F_f, n__9, el__16, multi_QMARK___8); var tmp17 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A_fn_class = fncls__168d; tmp17 = fncls__168d } else { tmp17 = fncls__168 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
//line :891:1
				seq_74000346__10, chunk_74000347__11, count_74000348__12, i_74000349__13 = seq_74000346__10, chunk_74000347__11, count_74000348__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000349__13); continue L1 } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000346__10); if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_74000346__15 any = temp__1927000414__auto____14; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000346__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000346__15); seq_74000346__10, chunk_74000347__11, count_74000348__12, i_74000349__13 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000346__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000356__16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000346__15); var i__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000356__16, lang.RT_IntCast_J__I_NoInit(0), nil); var el__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000356__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tl__19 any = lang.RT_Nth_O_I__O_NoInit(ts__6, lang.RT_IntCast_O__I_NoInit(i__17)); var tmp18 bool
					var na_173 any = i__17
					if jrt.Long_InstanceOf(na_173) { var n0_174 int64 = jrt.NN(jrt.Long_Cast(na_173)).LongValue__J(); tmp18 = n0_174 > 0 } else { if jrt.Double_InstanceOf(na_173) { var n0_174_2 float64 = jrt.NN(jrt.Double_Cast(na_173)).DoubleValue__D(); tmp18 = n0_174_2 > 0.0 } else { tmp18 = lang.Numbers_IsPos_O__Z_NoInit(na_173) } }; if tmp18 { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(tl__19)
					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_print_code_A_const_86; var tmp22 any; var or__1927000174__auto____20 any = lang.RT_Nth_O_I__O_NoInit(nxt__7, lang.RT_IntCast_O__I_NoInit(i__17)); if jrt.J2g_Truth(or__1927000174__auto____20) { tmp22 = or__1927000174__auto____20 } else { tmp22 = A_arbace_repr_go_print_code_A_const_86.Get__O() }; tmp19.Invoke_O__O(tmp20.Invoke_O_O__O(tmp21, tmp22)); var tmp23 any = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A_New_O_I_O_O(t.F_f, n__9, el__18, multi_QMARK___8); var tmp24 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A_fn_class = fncls__172d; tmp24 = fncls__172d } else { tmp24 = fncls__172 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()
//line :891:1
					seq_74000346__10, chunk_74000347__11, count_74000348__12, i_74000349__13 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000346__15), nil, 0, 0; continue L1 } } }
//line :880:1
			break L1 }; var indent__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O(); var multi__11 bool; var tmp25 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_155 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var na_156 any = start__4; var tmp26 bool; var tmp27 bool


























		tmp27 = jrt.Long_InstanceOf(na_155); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_156) }; tmp26 = tmp27; if tmp26 { var n0_157 int64 = jrt.NN(jrt.Long_Cast(na_155)).LongValue__J(); var n1_158 int64 = jrt.NN(jrt.Long_Cast(na_156)).LongValue__J(); multi__11 = n0_157 > n1_158 } else { var tmp28 bool; var tmp29 bool; tmp29 = jrt.Double_InstanceOf(na_155); if tmp29 { tmp29 = jrt.Double_InstanceOf(na_156) }; tmp28 = tmp29; if tmp28 { var n0_157_2 float64 = jrt.NN(jrt.Double_Cast(na_155)).DoubleValue__D(); var n1_158_2 float64 = jrt.NN(jrt.Double_Cast(na_156)).DoubleValue__D(); multi__11 = n1_158_2 < n0_157_2 } else { multi__11 = lang.Numbers_Gt_O_O__Z_NoInit(na_155, na_156) } }
		var tmp30 any; var tmp31 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____12 any = tmp31.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(n__9)); if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = multi__11; if and__1927000168__auto____14 { tmp30 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_85.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_130) } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() } } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() } } else { tmp30 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp30) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_41) }
		if lang.Numbers_IsPos_J__Z_NoInit(int64(n__9)) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_128.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_131, Lit_41) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()).Invoke_O_O_O_O__O(nil, jrt.Boolean_ValueOf_Z__Boolean_NoInit(multi__11).Ref(), jrt.Boolean_FALSE.Ref(), indent__10)
		var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()); var tmp34 any; var t__2 any = t.F_f; t.F_f = nil; tmp34 = t__2; tmp1 = tmp32.Invoke_O_O__O(Lit_19, tmp33.Invoke_O_O__O(tmp34, A_arbace_repr_go_print_code_A_const_203)) }
//line :880:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp35 != nil { panic(tmp35) }; return tmp1 }




func A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A{}; t.Ctor_O_O(p0, p1); return t }
//line :885:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A) Ctor_O_O(c__f, c__brk any) { t.F_f = c__f; t.F_brk = c__brk }
//line :885:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A) Invoke_O_O__O(self, el__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()); var tmp2 any = t.F_f; var tmp3 any = A_arbace_repr_go_print_code_A_const_263.Invoke_O__O(el__1); var tmp4 any; var or__1927000174__auto____2 any = A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(el__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = A_arbace_repr_go_print_code_A_const_262.Invoke_O__O(el__1) }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, t.F_brk) }

func A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A_New_O(p0 any) *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A{}; t.Ctor_O(p0); return t }
//line :887:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :887:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A) Invoke_O_O__O(self, tl__1 any) any { var and__1927000168__auto____2 any = tl__1; if jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tl__1, A_arbace_repr_go_print_code_A_const_82); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 bool; var na_161 int64 = lang.RT_LongCast_O__J_NoInit(tl__1); var na_162 any = t.F_start; if jrt.Long_InstanceOf(na_162) { var n0_163 int64 = na_161; var n1_164 int64 = jrt.NN(jrt.Long_Cast(na_162)).LongValue__J(); tmp1 = n0_163 > n1_164 } else { tmp1 = lang.Numbers_Gt_J_O__Z_NoInit(na_161, na_162) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } } else { return and__1927000168__auto____2 } }







func A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :895:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A) Ctor_O_I_O_O(c__f any, c__n int32, c__el, c__multi_QMARK_ any) { t.F_f = c__f; t.F_n = c__n; t.F_el = c__el; t.F_multi_QMARK_ = c__multi_QMARK_ }
//line :895:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var G__74000354__3_ any = A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el)
L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__74000354__3_) { case 1021133523: if any(G__74000354__3_) == any(A_arbace_repr_go_print_code_A_const_264) {
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_262; var tmp4 any; var t_ any = t.F_el; t.F_el = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O__O(tmp4), A_arbace_repr_go_print_code_A_const_130)
//line :896:1
	break L1 }; default:
}
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_260) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_270.GetRawRoot__O()); var tmp6 any = t.F_f; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(t.F_el)), tmp5.Invoke_O_O__O(tmp6, A_arbace_repr_go_print_code_A_const_263.Invoke_O__O(t.F_el))) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_130) }
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp8 any; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_260) {
		var tmp9 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp9.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_271; var tmp11 any; var t__2 any = t.F_f; t.F_f = nil; tmp11 = t__2; tmp8 = lang.RT_Get_O_O__O_NoInit(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp11)), A_arbace_repr_go_print_code_A_const_263.Invoke_O__O(t.F_el)) } else { tmp8 = nil } } else {
			tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_272) }
//line :901:1
	tmp7.Invoke_O_O__O(Lit_38, tmp8)


	var tmp12 any; var and__1927000168__auto____4 any; var t__3 any = t.F_multi_QMARK_; t.F_multi_QMARK_ = nil; and__1927000168__auto____4 = t__3; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(t.F_n), 1); if and__1927000168__auto____5 { var tmp13 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; tmp12 = tmp13.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()) } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp12 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp12) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
	var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp15 *lang.Keyword = A_arbace_repr_go_print_code_A_const_262; var tmp16 any; var t__4 any = t.F_el; t.F_el = nil; tmp16 = t__4; tmp1 = tmp14.Invoke_O_O__O(tmp15.Invoke_O__O(tmp16), A_arbace_repr_go_print_code_A_const_130)} }; return nil }(); /*line :895:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }
//line :895:1
func A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :895:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A) Ctor_O_I_O_O(c__f any, c__n int32, c__el, c__multi_QMARK_ any) { t.F_f = c__f; t.F_n = c__n; t.F_el = c__el; t.F_multi_QMARK_ = c__multi_QMARK_ }
//line :895:1
func (t *A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var G__74000360__3_ any = A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el)
L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__74000360__3_) { case 1021133523: if any(G__74000360__3_) == any(A_arbace_repr_go_print_code_A_const_264) {
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_262; var tmp4 any; var t_ any = t.F_el; t.F_el = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3.Invoke_O__O(tmp4), A_arbace_repr_go_print_code_A_const_130)
//line :896:1
	break L1 }; default:
}
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_260) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_270.GetRawRoot__O()); var tmp6 any = t.F_f; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(t.F_el)), tmp5.Invoke_O_O__O(tmp6, A_arbace_repr_go_print_code_A_const_263.Invoke_O__O(t.F_el))) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_261.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_130) }
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp8 any; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_print_code_A_const_259.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_260) {
		var tmp9 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp9.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_271; var tmp11 any; var t__2 any = t.F_f; t.F_f = nil; tmp11 = t__2; tmp8 = lang.RT_Get_O_O__O_NoInit(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp11)), A_arbace_repr_go_print_code_A_const_263.Invoke_O__O(t.F_el)) } else { tmp8 = nil } } else {
			tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_103.Invoke_O__O(t.F_el), A_arbace_repr_go_print_code_A_const_272) }
//line :901:1
	tmp7.Invoke_O_O__O(Lit_38, tmp8)


	var tmp12 any; var and__1927000168__auto____4 any; var t__3 any = t.F_multi_QMARK_; t.F_multi_QMARK_ = nil; and__1927000168__auto____4 = t__3; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(t.F_n), 1); if and__1927000168__auto____5 { var tmp13 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; tmp12 = tmp13.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()) } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp12 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp12) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
	var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp15 *lang.Keyword = A_arbace_repr_go_print_code_A_const_262; var tmp16 any; var t__4 any = t.F_el; t.F_el = nil; tmp16 = t__4; tmp1 = tmp14.Invoke_O_O__O(tmp15.Invoke_O__O(tmp16), A_arbace_repr_go_print_code_A_const_130)} }; return nil }(); /*line :895:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }


















func A_arbace_repr_go_print_code_slice_expr_A_New() *A_arbace_repr_go_print_code_slice_expr_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_slice_expr_A{}; t.Ctor(); return t }
//line :914:1
func (t *A_arbace_repr_go_print_code_slice_expr_A) Ctor() {}
//line :914:1
func (t *A_arbace_repr_go_print_code_slice_expr_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var vec__74000365__3 any = f__0; var seq__74000366__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000365__3); var first__74000367__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000366__4); var seq__74000366__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000366__4); var ___7 any = first__74000367__5; var first__74000367__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000366__6); var seq__74000366__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000366__6); var x__10 any = first__74000367__8; var idx__11 any = seq__74000366__9; var idx__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(idx__11); var idx__13 any; _ = ___7; if


	lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(idx__12)), 2) { idx__13 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_23.GetRawRoot__O()).Invoke_O_O__O(idx__12, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_273.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(idx__12)))).Ref(), A_arbace_repr_go_print_code_A_const_274)) } else { idx__13 = idx__12 }; var present__14 any; var tmp1 lang.IFn = /*line :914:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_185.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_slice_expr_fn__74000368_A_New(); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_repr_go_print_code_slice_expr_fn__74000368_A_fn_class; if



	fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_repr_go_print_code_slice_expr_fn__74000368_A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; present__14 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), idx__13); var blanks_QMARK___15 any; var and__1927000168__auto____15 bool; var na_176 any = depth__1; var na_177 int64 = 1; if
	jrt.Long_InstanceOf(na_176) { var n0_178 int64 = jrt.NN(jrt.Long_Cast(na_176)).LongValue__J(); var n1_179 int64 = na_177; and__1927000168__auto____15 = n0_178 <= n1_179 } else { and__1927000168__auto____15 = lang.Numbers_Lte_O_J__Z_NoInit(na_176, na_177) }; if and__1927000168__auto____15 { var and__1927000168__auto____16 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(present__14)), 1); if and__1927000168__auto____16 { blanks_QMARK___15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O(), present__14) } else { blanks_QMARK___15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() } } else { blanks_QMARK___15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(x__10, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130);
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_215));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp4 any = A_arbace_repr_go_print_code_slice_expr_fn__74000370_A_New_O_O_O(depth__1, idx__13, blanks_QMARK___15); var tmp5 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_repr_go_print_code_slice_expr_fn__74000370_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_repr_go_print_code_slice_expr_fn__74000370_A_fn_class = fncls__194d; tmp5 = fncls__194d } else { tmp5 = fncls__194 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O(); return /*line :929:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_101, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_216)) }
//line :918:1
func A_arbace_repr_go_print_code_slice_expr_fn__74000368_A_New() *A_arbace_repr_go_print_code_slice_expr_fn__74000368_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_slice_expr_fn__74000368_A{}; t.Ctor(); return t }
//line :918:1
func (t *A_arbace_repr_go_print_code_slice_expr_fn__74000368_A) Ctor() {}
//line :918:1
func (t *A_arbace_repr_go_print_code_slice_expr_fn__74000368_A) Invoke_O_O__O(self, p1__74000364_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(p1__74000364_SHARP___1, A_arbace_repr_go_print_code_A_const_275) }



func A_arbace_repr_go_print_code_slice_expr_fn__74000370_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_slice_expr_fn__74000370_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_slice_expr_fn__74000370_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :922:1
func (t *A_arbace_repr_go_print_code_slice_expr_fn__74000370_A) Ctor_O_O_O(c__depth, c__idx, c__blanks_QMARK_ any) { t.F_depth = c__depth; t.F_idx = c__idx; t.F_blanks_QMARK_ = c__blanks_QMARK_ }
//line :922:1
func (t *A_arbace_repr_go_print_code_slice_expr_fn__74000370_A) Invoke_O__O(self any) any { var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_74000371__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_101.GetRawRoot__O(), t.F_idx)); var chunk_74000372__4 any; var count_74000373__5 int64 = 0; var i_74000374__6 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z_NoInit(i_74000374__6, count_74000373__5) { var vec__74000375__7 any = lang.Indexed_Cast(chunk_74000372__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000374__6)); var i__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000375__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000375__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 bool; var na_182 any = i__8
													if jrt.Long_InstanceOf(na_182) { var n0_183 int64 = jrt.NN(jrt.Long_Cast(na_182)).LongValue__J(); tmp2 = n0_183 > 0 } else { if jrt.Double_InstanceOf(na_182) { var n0_183_2 float64 = jrt.NN(jrt.Double_Cast(na_182)).DoubleValue__D(); tmp2 = n0_183_2 > 0.0 } else { tmp2 = lang.Numbers_IsPos_O__Z_NoInit(na_182) } }; if tmp2 {
														var tmp3 any; var and__1927000168__auto____10 any = t.F_blanks_QMARK_; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()); var tmp5 any = t.F_idx; var tmp6 jrt.Number_I; var na_184 any = i__8; if jrt.Long_InstanceOf(na_184) { var n0_185 int64 = jrt.NN(jrt.Long_Cast(na_184)).LongValue__J(); if n0_185 == -9223372036854775808 { tmp6 = lang.Numbers_Dec_O__Number_NoInit(na_184) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_185 - 1)) } } else { if jrt.Double_InstanceOf(na_184) { var n0_185_2 float64 = jrt.NN(jrt.Double_Cast(na_184)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_185_2 - 1.0)) } else { tmp6 = lang.Numbers_Dec_O__Number_NoInit(na_184) } }; tmp3 = tmp4.Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(tmp6)), A_arbace_repr_go_print_code_A_const_276) } else { tmp3 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
														lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_38)
														var tmp7 any; var and__1927000168__auto____10_2 any = t.F_blanks_QMARK_; if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(ix__9, A_arbace_repr_go_print_code_A_const_277) } else { tmp7 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp7) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } }
													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(ix__9, A_arbace_repr_go_print_code_A_const_278)) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp9 jrt.Number_I; var na_186 any = t.F_depth; if jrt.Long_InstanceOf(na_186) { var n0_187 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); if n0_187 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_186) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_187 + 1)) } } else { if jrt.Double_InstanceOf(na_186) { var n0_187_2 float64 = jrt.NN(jrt.Double_Cast(na_186)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_187_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_186) } }; tmp8.Invoke_O_O__O(ix__9, tmp9) }
//line :923:1
		seq_74000371__3, chunk_74000372__4, count_74000373__5, i_74000374__6 = seq_74000371__3, chunk_74000372__4, count_74000373__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000374__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000371__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_74000371__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000371__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000371__8); seq_74000371__3, chunk_74000372__4, count_74000373__5, i_74000374__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000371__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__74000378__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000371__8); var i__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000378__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000378__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 bool; var na_188 any = i__10
			if jrt.Long_InstanceOf(na_188) { var n0_189 int64 = jrt.NN(jrt.Long_Cast(na_188)).LongValue__J(); tmp10 = n0_189 > 0 } else { if jrt.Double_InstanceOf(na_188) { var n0_189_2 float64 = jrt.NN(jrt.Double_Cast(na_188)).DoubleValue__D(); tmp10 = n0_189_2 > 0.0 } else { tmp10 = lang.Numbers_IsPos_O__Z_NoInit(na_188) } }; if tmp10 {
				var tmp11 any; var and__1927000168__auto____12 any = t.F_blanks_QMARK_; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()); var tmp13 any = t.F_idx; var tmp14 jrt.Number_I; var na_190 any = i__10; if jrt.Long_InstanceOf(na_190) { var n0_191 int64 = jrt.NN(jrt.Long_Cast(na_190)).LongValue__J(); if n0_191 == -9223372036854775808 { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_190) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_191 - 1)) } } else { if jrt.Double_InstanceOf(na_190) { var n0_191_2 float64 = jrt.NN(jrt.Double_Cast(na_190)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_191_2 - 1.0)) } else { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_190) } }; tmp11 = tmp12.Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp13, lang.RT_IntCast_O__I_NoInit(tmp14)), A_arbace_repr_go_print_code_A_const_276) } else { tmp11 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp11) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_38)
				var tmp15 any; var and__1927000168__auto____12_2 any = t.F_blanks_QMARK_; if jrt.J2g_Truth(and__1927000168__auto____12_2) { tmp15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(ix__11, A_arbace_repr_go_print_code_A_const_277) } else { tmp15 = and__1927000168__auto____12_2 }; if jrt.J2g_Truth(tmp15) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } }
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(ix__11, A_arbace_repr_go_print_code_A_const_278)) { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp17 jrt.Number_I; var na_192 any = t.F_depth; if jrt.Long_InstanceOf(na_192) { var n0_193 int64 = jrt.NN(jrt.Long_Cast(na_192)).LongValue__J(); if n0_193 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_192) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_193 + 1)) } } else { if jrt.Double_InstanceOf(na_192) { var n0_193_2 float64 = jrt.NN(jrt.Double_Cast(na_192)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_193_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_192) } }; tmp16.Invoke_O_O__O(ix__11, tmp17) }
//line :923:1
			seq_74000371__3, chunk_74000372__4, count_74000373__5, i_74000374__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000371__8), nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :922:1
	break L1 } }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp18 != nil { panic(tmp18) }; return tmp1 }








func A_arbace_repr_go_print_code_func_lit_A_New() *A_arbace_repr_go_print_code_func_lit_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_func_lit_A{}; t.Ctor(); return t }
//line :931:1
func (t *A_arbace_repr_go_print_code_func_lit_A) Ctor() {}
//line :931:1
func (t *A_arbace_repr_go_print_code_func_lit_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000383__2 any = f__0; var seq__74000384__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000383__2); var first__74000385__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000384__3); var seq__74000384__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000384__3); var ___6 any = first__74000385__4; var first__74000385__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000384__5); var seq__74000384__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000384__5); var params__9 any = first__74000385__7; var more__10 any = seq__74000384__8; var vec__74000386__11 any; _ = ___6; if



	lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(more__10), A_arbace_repr_go_print_code_A_const_190) { vec__74000386__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(more__10), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(more__10)) } else { vec__74000386__11 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__10) }; var results__12 any = /*line :931:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000386__11, lang.RT_IntCast_J__I_NoInit(0), nil); var body__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000386__11, lang.RT_IntCast_J__I_NoInit(1), nil); var res__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_191.GetRawRoot__O()).Invoke_O_O__O(params__9, results__12); if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(params__9)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_131, f__0) }; var indent__15 any = /*line :931:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_279.GetRawRoot__O()).Invoke__O();







	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_26, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_229)); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_233; var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any = A_arbace_repr_go_print_code_A_const_281; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_282))); var tmp5 any; tmp22 := /*line :931:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)










		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_167.GetRawRoot__O()).Invoke_O_O_O_O__O(params__9, res__14, body__13, results__12)
		{ var tmp6 any = A_arbace_repr_go_print_code_A_const_283; var tmp7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(res__14); var tmp8 any = A_arbace_repr_go_print_code_A_const_118; var tmp9 *lang.Keyword = A_arbace_repr_go_print_code_A_const_125; var tmp10 any = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp11 any = A_arbace_repr_go_print_code_A_const_284; var tmp12 any = jrt.Boolean_TRUE.Ref(); var tmp13 any = A_arbace_repr_go_print_code_A_const_285; var tmp14 any = A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O(); var tmp15 any = A_arbace_repr_go_print_code_A_const_116; var tmp16 any = A_arbace_repr_go_print_code_A_const_117; var tmp17 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_286.GetRawRoot__O()).Invoke_O_O__O(f__0, body__13); var tmp18 any = A_arbace_repr_go_print_code_A_const_163; var tmp19 any = A_arbace_repr_go_print_code_A_const_202; var tmp20 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_202); var tmp21 any = A_arbace_repr_go_print_code_A_const_203; tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(body__13, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, f__0, tmp16, tmp17, tmp18, indent__15, tmp19, tmp20, tmp21, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_203)))) }
//line :931:1
		return nil }();








	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :931:1*/ tmp22 != nil { panic(tmp22) }; return tmp5 }















func A_arbace_repr_go_print_code_new_arg_A_New() *A_arbace_repr_go_print_code_new_arg_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_new_arg_A{}; t.Ctor(); return t }
//line :947:1
func (t *A_arbace_repr_go_print_code_new_arg_A) Ctor() {}
//line :947:1
func (t *A_arbace_repr_go_print_code_new_arg_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_287.GetRawRoot__O()).Invoke_O__O(x__0) } }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(x__0) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_repr_go_print_code_A_const_130)
		} }
func A_arbace_repr_go_print_code_print_pl_A_New() *A_arbace_repr_go_print_code_print_pl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_pl_A{}; t.Ctor(); return t }
//line :955:1
func (t *A_arbace_repr_go_print_code_print_pl_A) Ctor() {}
//line :955:1
func (t *A_arbace_repr_go_print_code_print_pl_A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_222.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_288.Invoke_O__O(f__0); var tmp3 any = A_arbace_repr_go_print_code_print_pl_fn__74000391_A_New_O(f__0); var tmp4 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_repr_go_print_code_print_pl_fn__74000391_A_fn_class
	if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_repr_go_print_code_print_pl_fn__74000391_A_fn_class = fncls__195d; tmp4 = fncls__195d } else { tmp4 = fncls__195 }
//line :958:1
	return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
func A_arbace_repr_go_print_code_print_pl_fn__74000391_A_New_O(p0 any) *A_arbace_repr_go_print_code_print_pl_fn__74000391_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_pl_fn__74000391_A{}; t.Ctor_O(p0); return t }
//line :959:1
func (t *A_arbace_repr_go_print_code_print_pl_fn__74000391_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :959:1
func (t *A_arbace_repr_go_print_code_print_pl_fn__74000391_A) Invoke_O__O(self any) any { var v__1 any = A_arbace_repr_go_print_code_A_const_289.Invoke_O__O(t.F_f);

	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_264.Invoke_O__O(t.F_f)); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_65.GetRawRoot__O()).Invoke_O__O(v__1)) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_160); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_290.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_291.GetRawRoot__O()).Invoke_O__O(v__1), A_arbace_repr_go_print_code_A_const_292.Invoke_O__O(t.F_f)) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_290.GetRawRoot__O()).Invoke_O_O__O(v__1, A_arbace_repr_go_print_code_A_const_292.Invoke_O__O(t.F_f)) } }

func A_arbace_repr_go_print_code_lit_list_tok_A_New() *A_arbace_repr_go_print_code_lit_list_tok_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_lit_list_tok_A{}; t.Ctor(); return t }
//line :966:1
func (t *A_arbace_repr_go_print_code_lit_list_tok_A) Ctor() {}
//line :966:1
func (t *A_arbace_repr_go_print_code_lit_list_tok_A) Invoke_O_O_O__O(self, f__0, s__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____3 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_293; or__1927000174__auto____3 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = s__1 }; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_294))
}
func A_arbace_repr_go_print_code_expr1_A_New() *A_arbace_repr_go_print_code_expr1_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_A{}; t.Ctor(); return t }
//line :972:1
func (t *A_arbace_repr_go_print_code_expr1_A) Ctor() {}
//line :972:1
func (t *A_arbace_repr_go_print_code_expr1_A) Invoke_O_O_O_O__O(self, f__0, prec1__1, depth__2 any) any {


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(f__0))
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_219.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_220.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :976:1
			var tmp1 any; var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; var and__1927000168__auto____4 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())

			if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { tmp1 = and__1927000168__auto____4 }
//line :976:1
			if jrt.J2g_Truth(tmp1) {


				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_222.GetRawRoot__O()); var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; var tmp6 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp7 any = A_arbace_repr_go_print_code_expr1_fn__74000395_A_New_O_O(depth__2, f__0); var tmp8 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000395_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_repr_go_print_code_expr1_fn__74000395_A_fn_class = fncls__209d; tmp8 = fncls__209d } else { tmp8 = fncls__209 }; return tmp4.Invoke_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :976:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_68.GetRawRoot__O()).Invoke_O__O(f__0)) {



						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_295.GetRawRoot__O()).Invoke_O_O_O_O__O(f__0, prec1__1, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_301.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2), depth__2) } else {
//line :976:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_70.GetRawRoot__O()).Invoke_O__O(f__0)) {





								var tmp9 any; var and__1927000168__auto____4_2 bool; var na_196 int64 = 6; var na_197 any = prec1__1; if jrt.Long_InstanceOf(na_197) { var n0_198 int64 = na_196; var n1_199 int64 = jrt.NN(jrt.Long_Cast(na_197)).LongValue__J(); and__1927000168__auto____4_2 = n0_198 < n1_199 } else { and__1927000168__auto____4_2 = lang.Numbers_Lt_J_O__Z_NoInit(na_196, na_197) }; if and__1927000168__auto____4_2 { var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp9) {
									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp11 any = A_arbace_repr_go_print_code_expr1_fn__74000397_A_New_O(f__0); var tmp12 *jrt.Class; var fncls__210 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000397_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_go_print_code_expr1_fn__74000397_A_fn_class = fncls__210d; tmp12 = fncls__210d } else { tmp12 = fncls__210 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
//line :982:1
										var o__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_241.GetRawRoot__O()).Invoke_O__O(f__0); var x__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_291.GetRawRoot__O()).Invoke_O__O(f__0); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp14 any


										if lang.Util_Equiv_O_O__Z_NoInit(o__4, Lit_4) { tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_226) } else { tmp14 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_218) }; tmp13.Invoke_O_O__O(o__4, tmp14)
										if lang.Util_Equiv_O_O__Z_NoInit(o__4, Lit_4) {
											var tmp15 any; var and__1927000168__auto____6 bool; var na_201 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_296.GetRawRoot__O()).Invoke_O__O(x__5); var na_202 int64 = 6; if jrt.Long_InstanceOf(na_201) { var n0_203 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); var n1_204 int64 = na_202; and__1927000168__auto____6 = n0_203 < n1_204 } else { and__1927000168__auto____6 = lang.Numbers_Lt_O_J__Z_NoInit(na_201, na_202) }; if and__1927000168__auto____6 { var tmp16 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp16.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(tmp15) {
												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp17 any = A_arbace_repr_go_print_code_expr1_fn__74000399_A_New_O(x__5); var tmp18 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000399_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_go_print_code_expr1_fn__74000399_A_fn_class = fncls__211d; tmp18 = fncls__211d } else { tmp18 = fncls__211 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
													return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(x__5, A_arbace_repr_go_print_code_A_const_71, A_arbace_repr_go_print_code_A_const_130) } } else {
														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(x__5, A_arbace_repr_go_print_code_A_const_71, depth__2) } } } else {
//line :976:1
															var tmp19 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(f__0)














															if jrt.J2g_Truth(or__1927000174__auto____4) { tmp19 = or__1927000174__auto____4 } else { tmp19 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_94.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :976:1
															if jrt.J2g_Truth(tmp19) {














																return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :976:1
																	var tmp20 any; var or__1927000174__auto____4_2 bool = lang.Util_Identical_O_O__Z_NoInit(f__0, nil)















																	if or__1927000174__auto____4_2 { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4_2).Ref() } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_105.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp20 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_106.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp20 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp20 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_111.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____8) { tmp20 = or__1927000174__auto____8 } else { tmp20 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_63.GetRawRoot__O()).Invoke_O__O(f__0) } } } } }
//line :976:1
																	if jrt.J2g_Truth(tmp20) {















																		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_290.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :976:1
																			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)) { var o__4_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)
																				var G__74000401__5_ any = o__4_2

















																				switch lang.Util_Hash_O__I_NoInit(G__74000401__5_) >> 10 & 127 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_72) {






















																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_297.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :995:1
																				case 23: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_77) { var x__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)

























																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_298.GetRawRoot__O()).Invoke_O_O__O(f__0, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_78), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_114.GetRawRoot__O()).Invoke_O__O(x__6), nil)).Ref()) }
//line :995:1
																				case 25: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_79) {













																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_299.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2) }
//line :995:1
																				case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_80) { var vec__74000402__6 any = f__0; var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000402__6, lang.RT_IntCast_J__I_NoInit(0), nil); var t__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000402__6, lang.RT_IntCast_J__I_NoInit(1), nil); var m__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000402__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp21 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__8); _ = ___7


















																					if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_302); var and__1927000168__auto____11 any = tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__8)); if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp23 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp21 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp21 = and__1927000168__auto____11 } } else { tmp21 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp21) {
																						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__8); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
																							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__8) }
																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_98)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(m__9) }
//line :995:1
																				case 28: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_82) { var vec__74000405__6 any = f__0; var ___7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000405__6, lang.RT_IntCast_J__I_NoInit(0), nil); var t__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000405__6, lang.RT_IntCast_J__I_NoInit(1), nil); var x__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000405__6, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___7_2








																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(x__9, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_98)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_257)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__8_2)
																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_258)) }
//line :995:1
																				case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_83) { var vec__74000408__6 any = f__0; var seq__74000409__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000408__6); var first__74000410__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000409__7); var seq__74000409__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000409__7); var ___10 any = first__74000410__8; var first__74000410__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000409__9); var seq__74000409__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000409__9); var g__13 any = first__74000410__11; var xs__14 any = seq__74000409__12; _ = ___10




























																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(g__13)
																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :995:1
																					var tmp24 any; tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





























																						{ var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_300.GetRawRoot__O()); var tmp26 any; if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xs__14)), 1) { var na_212 any = depth__2; if jrt.Long_InstanceOf(na_212) { var n0_213 int64 = jrt.NN(jrt.Long_Cast(na_212)).LongValue__J(); if n0_213 == 9223372036854775807 { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_212) } else { tmp26 = jrt.Long_ValueOf_J__Long_NoInit(n0_213 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_212) { var n0_213_2 float64 = jrt.NN(jrt.Double_Cast(na_212)).DoubleValue__D(); tmp26 = jrt.Double_ValueOf_D__Double_NoInit(n0_213_2 + 1.0).Ref() } else { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_212) } } } else { tmp26 = depth__2 }; tmp24 = tmp25.Invoke_O_O_O_O__O(f__0, xs__14, tmp26, A_arbace_repr_go_print_code_A_const_303) }
//line :995:1
																						return nil
																					}()




























																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :995:1
																					if tmp27 != nil { panic(tmp27) }; return tmp24 }; case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_84) {






























																						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :995:1
																				case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_85) { var vec__74000411__6 any = f__0; var ___7_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000411__6, lang.RT_IntCast_J__I_NoInit(0), nil); var t__8_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000411__6, lang.RT_IntCast_J__I_NoInit(1), nil); var x__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000411__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp28 any; var and__1927000168__auto____10_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__8_3); _ = ___7_3


																					if jrt.J2g_Truth(and__1927000168__auto____10_2) { var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_304); var and__1927000168__auto____11_2 any = tmp29.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__8_3)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp30 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp28 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp30.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp28 = and__1927000168__auto____11_2 } } else { tmp28 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp28) {
																						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_6); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__8_3); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_8) } else {
																							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__8_3) }
																					var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp32 any = lang.Tuple_Create_O__IPersistentVector(x__9_2); var tmp33 any = A_arbace_repr_go_print_code_expr1_fn__74000414_A_New_O(depth__2); var tmp34 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000414_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_go_print_code_expr1_fn__74000414_A_fn_class = fncls__214d; tmp34 = fncls__214d } else { tmp34 = fncls__214 }; var tmp35 any = A_arbace_repr_go_print_code_A_const_116; var tmp36 any = A_arbace_repr_go_print_code_A_const_117; var tmp37 any = A_arbace_repr_go_print_code_A_const_303; var tmp38 any = A_arbace_repr_go_print_code_A_const_120; var tmp39 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_257); var tmp40 any = A_arbace_repr_go_print_code_A_const_121; return tmp31.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp32, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp35, f__0, tmp36, tmp37, tmp38, tmp39, tmp40, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_258)))) }
//line :995:1
																				case 60: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_24) {
































																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_87, f__0) }
//line :995:1
																				case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_88) {

































																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_89, f__0) }
//line :995:1
																				case 65: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_90) { var vec__74000416__6 any = f__0; var seq__74000417__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000416__6); var first__74000418__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000417__7); var seq__74000417__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000417__7); var ___10_2 any = first__74000418__8; var first__74000418__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000417__9); var seq__74000417__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000417__9); var t__13 any = first__74000418__11; var xs__14_2 any = seq__74000417__12; var depth__15 any; _ = ___10_2



































																					if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0))), 1) { var na_215 any = depth__2; if jrt.Long_InstanceOf(na_215) { var n0_216 int64 = jrt.NN(jrt.Long_Cast(na_215)).LongValue__J(); if n0_216 == 9223372036854775807 { depth__15 = lang.Numbers_Inc_O__Number_NoInit(na_215) } else { depth__15 = jrt.Long_ValueOf_J__Long_NoInit(n0_216 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_215) { var n0_216_2 float64 = jrt.NN(jrt.Double_Cast(na_215)).DoubleValue__D(); depth__15 = jrt.Double_ValueOf_D__Double_NoInit(n0_216_2 + 1.0).Ref() } else { depth__15 = lang.Numbers_Inc_O__Number_NoInit(na_215) } } } else { depth__15 = depth__2 }
																					var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_222.GetRawRoot__O()); var tmp42 any; var tmp43 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp43.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp44 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; tmp42 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0))) } else { tmp42 = nil }; var tmp45 any = tmp42; var tmp46 any = A_arbace_repr_go_print_code_expr1_fn__74000419_A_New_O(f__0); var tmp47 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000419_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_repr_go_print_code_expr1_fn__74000419_A_fn_class = fncls__217d; tmp47 = fncls__217d } else { tmp47 = fncls__217 }; tmp41.Invoke_O_O__O(tmp45, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil))
																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :995:1
																					var tmp48 any; tmp59 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






































																						{ var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp50 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_180.GetRawRoot__O()).Invoke_O_O__O(t__13, xs__14_2); var tmp51 any = A_arbace_repr_go_print_code_expr1_fn__74000421_A_New_O(depth__15); var tmp52 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000421_A_fn_class
																							if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_repr_go_print_code_expr1_fn__74000421_A_fn_class = fncls__220d; tmp52 = fncls__220d } else { tmp52 = fncls__220 }
//line :1034:1
																							var tmp53 any = A_arbace_repr_go_print_code_A_const_116; var tmp54 any = A_arbace_repr_go_print_code_A_const_117; var tmp55 any = A_arbace_repr_go_print_code_A_const_130; var tmp56 any = A_arbace_repr_go_print_code_A_const_120; var tmp57 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_257); var tmp58 any = A_arbace_repr_go_print_code_A_const_121; tmp48 = tmp49.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp50, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp53, f__0, tmp54, tmp55, tmp56, tmp57, tmp58, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_258)))) }
//line :995:1
																						return nil
																					}()




































																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :995:1
																					if tmp59 != nil { panic(tmp59) }; return tmp48 }; case 89: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_93) { var vec__74000423__6 any = f__0; var seq__74000424__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000423__6); var first__74000425__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000424__7); var seq__74000424__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000424__7); var ___10_3 any = first__74000425__8; var first__74000425__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000424__9); var seq__74000424__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000424__9); var g__13_2 any = first__74000425__11; var ts__14 any = seq__74000424__12; _ = ___10_3















																						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(g__13_2, A_arbace_repr_go_print_code_A_const_72, depth__2)
																						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :995:1
																						var tmp60 any; tmp61 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
















																							tmp60 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_224.GetRawRoot__O()).Invoke_O_O__O(ts__14, f__0)
//line :995:1
																							return nil
																						}()















																						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :995:1
																						if tmp61 != nil { panic(tmp61) }; return tmp60 }; case 101: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_94) {























																							return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_298.GetRawRoot__O()).Invoke_O_O__O(f__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_113.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0))).Ref())) }
//line :995:1
																				case 103: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_95) {































																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_96, f__0) }
//line :995:1
																				case 104: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_97) {
																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_305.GetRawRoot__O()).Invoke_O_O__O(f__0, depth__2) }
//line :995:1
																				case 105: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_98) { var vec__74000426__6 any = f__0; var ___7_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000426__6, lang.RT_IntCast_J__I_NoInit(0), nil); var x__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000426__6, lang.RT_IntCast_J__I_NoInit(1), nil); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000426__6, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___7_4











																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(x__8, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_215)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp62 any = A_arbace_repr_go_print_code_expr1_fn__74000429_A_New_O_O(i__9, depth__2); var tmp63 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000429_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_repr_go_print_code_expr1_fn__74000429_A_fn_class = fncls__223d; tmp63 = fncls__223d } else { tmp63 = fncls__223 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil).Invoke__O()
																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_101, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_216)) }
//line :995:1
																				case 106: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_102) { var vec__74000431__6 any = f__0; var ___7_5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000431__6, lang.RT_IntCast_J__I_NoInit(0), nil); var x__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000431__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_222.GetRawRoot__O()); var tmp65 any; var tmp66 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; _ = ___7_5










































																					if jrt.J2g_Truth(tmp66.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp67 *lang.Keyword = A_arbace_repr_go_print_code_A_const_221; tmp65 = tmp67.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0))) } else { tmp65 = nil }; var tmp68 any = tmp65; var tmp69 any = A_arbace_repr_go_print_code_expr1_fn__74000434_A_New_O(f__0); var tmp70 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000434_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_go_print_code_expr1_fn__74000434_A_fn_class = fncls__224d; tmp70 = fncls__224d } else { tmp70 = fncls__224 }; tmp64.Invoke_O_O__O(tmp68, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil))
																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :995:1
																					var tmp71 any; tmp82 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)












































																						{ var tmp72 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_148.GetRawRoot__O()); var tmp73 any = lang.Tuple_Create_O__IPersistentVector(x__8_2); var tmp74 any = A_arbace_repr_go_print_code_expr1_fn__74000436_A_New(); var tmp75 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_repr_go_print_code_expr1_fn__74000436_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_repr_go_print_code_expr1_fn__74000436_A_fn_class = fncls__225d; tmp75 = fncls__225d } else { tmp75 = fncls__225 }; var tmp76 any = A_arbace_repr_go_print_code_A_const_116; var tmp77 any = A_arbace_repr_go_print_code_A_const_117; var tmp78 any = A_arbace_repr_go_print_code_A_const_130; var tmp79 any = A_arbace_repr_go_print_code_A_const_120; var tmp80 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_257); var tmp81 any = A_arbace_repr_go_print_code_A_const_121; tmp71 = tmp72.Invoke_O_O_O_O_O__O(Lit_6, Lit_8, tmp73, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp74, tmp75, nil), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp76, f__0, tmp77, tmp78, tmp79, tmp80, tmp81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_258)))) }
//line :995:1
																						return nil
																					}()










































																					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :995:1
																					if tmp82 != nil { panic(tmp82) }; return tmp71 }; case 108: if lang.Util_Equiv_O_O__Z_NoInit(G__74000401__5_, Lit_105) {


























																						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_298.GetRawRoot__O()).Invoke_O_O__O(f__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_307.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :995:1
																				default:
																				}













































																				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_73.GetRawRoot__O(), o__4_2)) {
																					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_106, f__0) } else {
//line :1042:1
																						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_287.GetRawRoot__O()).Invoke_O__O(f__0)) {

																							return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :1042:1
																								var tmp83 any
																								var and__1927000168__auto____6_2 any = o__4_2

																								if jrt.J2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_176.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_107); if jrt.J2g_Truth(and__1927000168__auto____7) { tmp83 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(o__4_2)), 2)).Ref() } else { tmp83 = and__1927000168__auto____7 } } else { tmp83 = and__1927000168__auto____6_2 }
//line :1042:1
																								if jrt.J2g_Truth(tmp83) {



																									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_72, depth__2); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_98)); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_308.GetRawRoot__O()).Invoke_O_O__O(o__4_2, A_arbace_repr_go_print_code_A_const_303), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_99)) } else {
//line :1042:1
																										var tmp84 any
																										var and__1927000168__auto____6_3 any = o__4_2



																										if jrt.J2g_Truth(and__1927000168__auto____6_3) { var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_176.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_81); if jrt.J2g_Truth(and__1927000168__auto____7_2) { var and__1927000168__auto____8 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(o__4_2)), 1); if and__1927000168__auto____8 { tmp84 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(o__4_2, Lit_25) } else { tmp84 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp84 = and__1927000168__auto____7_2 } } else { tmp84 = and__1927000168__auto____6_3 }
//line :1042:1
																										if jrt.J2g_Truth(tmp84) { var vec__74000438__6 any = f__0; var seq__74000439__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000438__6); var first__74000440__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000439__7); var seq__74000439__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000439__7); var ___10_4 any = first__74000440__8; var first__74000440__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000439__9); var seq__74000439__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000439__9); var recv__13 any = first__74000440__11; var xs__14_3 any = seq__74000439__12; _ = ___10_4






																											lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(recv__13, A_arbace_repr_go_print_code_A_const_72, depth__2); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_98)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_308.GetRawRoot__O()).Invoke_O_O__O(o__4_2, A_arbace_repr_go_print_code_A_const_130), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_99))
																											lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :1042:1
																											var tmp85 any; tmp88 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







																												{ var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_300.GetRawRoot__O()); var tmp87 any; if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xs__14_3)), 1) { var na_226 any = depth__2; if jrt.Long_InstanceOf(na_226) { var n0_227 int64 = jrt.NN(jrt.Long_Cast(na_226)).LongValue__J(); if n0_227 == 9223372036854775807 { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_226) } else { tmp87 = jrt.Long_ValueOf_J__Long_NoInit(n0_227 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_226) { var n0_227_2 float64 = jrt.NN(jrt.Double_Cast(na_226)).DoubleValue__D(); tmp87 = jrt.Double_ValueOf_D__Double_NoInit(n0_227_2 + 1.0).Ref() } else { tmp87 = lang.Numbers_Inc_O__Number_NoInit(na_226) } } } else { tmp87 = depth__2 }; tmp85 = tmp86.Invoke_O_O_O_O__O(f__0, xs__14_3, tmp87, A_arbace_repr_go_print_code_A_const_303) }
//line :1042:1
																												return nil
																											}()






																											lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :1042:1
																											if tmp88 != nil { panic(tmp88) }; return tmp85 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { var vec__74000441__6 any = f__0; var seq__74000442__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000441__6); var first__74000443__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000442__7); var seq__74000442__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000442__7); var h__10 any = first__74000443__8; var xs__11 any = seq__74000442__9; var depth__12 any










																												if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xs__11)), 1) { var na_207 any = depth__2; if jrt.Long_InstanceOf(na_207) { var n0_208 int64 = jrt.NN(jrt.Long_Cast(na_207)).LongValue__J(); if n0_208 == 9223372036854775807 { depth__12 = lang.Numbers_Inc_O__Number_NoInit(na_207) } else { depth__12 = jrt.Long_ValueOf_J__Long_NoInit(n0_208 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_207) { var n0_208_2 float64 = jrt.NN(jrt.Double_Cast(na_207)).DoubleValue__D(); depth__12 = jrt.Double_ValueOf_D__Double_NoInit(n0_208_2 + 1.0).Ref() } else { depth__12 = lang.Numbers_Inc_O__Number_NoInit(na_207) } } } else { depth__12 = depth__2 }
																												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_309.GetRawRoot__O()).Invoke_O_O__O(h__10, depth__12)
																												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref()))
//line :1042:1
																												var tmp89 any; tmp90 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)












																													tmp89 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_300.GetRawRoot__O()).Invoke_O_O_O_O__O(f__0, xs__11, depth__12, A_arbace_repr_go_print_code_A_const_130)
//line :1042:1
																													return nil
																												}()











																												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :1042:1
																												if tmp90 != nil { panic(tmp90) }; return tmp89 } else { return nil } } } } } } else {
//line :976:1
																													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_45.GetRawRoot__O()).Invoke_O__O(f__0)) {















































































																														return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_108, f__0) } else {
//line :976:1
																															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0)) {
















































































																																return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_109, f__0) } else {
//line :976:1
																																	if A_arbace_repr_go_print_code_A_const_42 != nil {

















































































																																		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_110, f__0) } else {
//line :976:1
																																			return nil
																																		}
																																} } } } } } } } } }
func A_arbace_repr_go_print_code_expr1_fn__74000395_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_expr1_fn__74000395_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000395_A{}; t.Ctor_O_O(p0, p1); return t }
//line :979:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000395_A) Ctor_O_O(c__depth, c__f any) { t.F_depth = c__depth; t.F_f = c__f }
//line :979:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000395_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_225.GetRawRoot__O()); var tmp2 any = t.F_f; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_code_A_const_16.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_221), A_arbace_repr_go_print_code_A_const_188, t.F_depth) }



func A_arbace_repr_go_print_code_expr1_fn__74000397_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000397_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000397_A{}; t.Ctor_O(p0); return t }
//line :983:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000397_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :983:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000397_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }




func A_arbace_repr_go_print_code_expr1_fn__74000399_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000399_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000399_A{}; t.Ctor_O(p0); return t }
//line :988:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000399_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :988:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000399_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }












func A_arbace_repr_go_print_code_expr1_fn__74000414_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000414_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000414_A{}; t.Ctor_O(p0); return t }
//line :1001:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000414_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :1001:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000414_A) Invoke_O_O_O__O(self, x__1, ___2 any) any { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_FALSE.Ref())); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth); return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_repr_go_print_code_expr1_fn__74000429_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_expr1_fn__74000429_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000429_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1007:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000429_A) Ctor_O_O(c__i, c__depth any) { t.F_i = c__i; t.F_depth = c__depth }
//line :1007:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000429_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 jrt.Number_I; var na_221 any; var t__2 any = t.F_depth; t.F_depth = nil; na_221 = t__2; if jrt.Long_InstanceOf(na_221) { var n0_222 int64 = jrt.NN(jrt.Long_Cast(na_221)).LongValue__J(); if n0_222 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_221) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_222 + 1)) } } else { if jrt.Double_InstanceOf(na_221) { var n0_222_2 float64 = jrt.NN(jrt.Double_Cast(na_221)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_222_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_221) } }; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }
























func A_arbace_repr_go_print_code_expr1_fn__74000419_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000419_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000419_A{}; t.Ctor_O(p0); return t }
//line :1032:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000419_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1032:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000419_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(t.F_f)) }


func A_arbace_repr_go_print_code_expr1_fn__74000421_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000421_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000421_A{}; t.Ctor_O(p0); return t }
//line :1035:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000421_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :1035:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000421_A) Invoke_O_O_O__O(self, x__1, i__2 any) any { var tmp1 bool; var na_218 any = i__2; if jrt.Long_InstanceOf(na_218) { var n0_219 int64 = jrt.NN(jrt.Long_Cast(na_218)).LongValue__J(); tmp1 = n0_219 == 0 } else { if jrt.Double_InstanceOf(na_218) { var n0_219_2 float64 = jrt.NN(jrt.Double_Cast(na_218)).DoubleValue__D(); tmp1 = n0_219_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_218) } }; if tmp1 { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(x__1) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__1, t.F_depth) } }


func A_arbace_repr_go_print_code_expr1_fn__74000434_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr1_fn__74000434_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000434_A{}; t.Ctor_O(p0); return t }
//line :1038:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000434_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1038:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000434_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(t.F_f)) }

func A_arbace_repr_go_print_code_expr1_fn__74000436_A_New() *A_arbace_repr_go_print_code_expr1_fn__74000436_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr1_fn__74000436_A{}; t.Ctor(); return t }
//line :1040:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000436_A) Ctor() {}
//line :1040:1
func (t *A_arbace_repr_go_print_code_expr1_fn__74000436_A) Invoke_O_O_O__O(self, x__1, ___2 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_306.GetRawRoot__O()).Invoke_O__O(x__1) }



















func A_arbace_repr_go_print_code_expr0_A_New() *A_arbace_repr_go_print_code_expr0_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr0_A{}; t.Ctor(); return t }
//line :1060:1
func (t *A_arbace_repr_go_print_code_expr0_A) Ctor() {}
//line :1060:1
func (t *A_arbace_repr_go_print_code_expr0_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_188, depth__1) }

func A_arbace_repr_go_print_code_expr_list_A_New() *A_arbace_repr_go_print_code_expr_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr_list_A{}; t.Ctor(); return t }
//line :1062:1
func (t *A_arbace_repr_go_print_code_expr_list_A) Ctor() {}
//line :1062:1
func (t *A_arbace_repr_go_print_code_expr_list_A) Invoke_O_O_O__O(self, f__0, depth__1 any) any { var vs_QMARK___3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.J2g_Truth(and__1927000168__auto____3) { vs_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_95)).Ref() } else { vs_QMARK___3 = and__1927000168__auto____3 }; var xs__4 any; if
	jrt.J2g_Truth(vs_QMARK___3) { xs__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0) } else { xs__4 = lang.Tuple_Create_O__IPersistentVector(f__0) }; if
	jrt.J2g_Truth(vs_QMARK___3) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(f__0)) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_130; var tmp3 any = A_arbace_repr_go_print_code_expr_list_fn__74000447_A_New_O(depth__1); var tmp4 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_repr_go_print_code_expr_list_fn__74000447_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_repr_go_print_code_expr_list_fn__74000447_A_fn_class = fncls__228d; tmp4 = fncls__228d } else { tmp4 = fncls__228 }; return tmp1.Invoke_O_O_O_O__O(f__0, tmp2, xs__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :1069:1
func A_arbace_repr_go_print_code_expr_list_fn__74000447_A_New_O(p0 any) *A_arbace_repr_go_print_code_expr_list_fn__74000447_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_expr_list_fn__74000447_A{}; t.Ctor_O(p0); return t }
//line :1069:1
func (t *A_arbace_repr_go_print_code_expr_list_fn__74000447_A) Ctor_O(c__depth any) { t.F_depth = c__depth }
//line :1069:1
func (t *A_arbace_repr_go_print_code_expr_list_fn__74000447_A) Invoke_O_O__O(self, p1__74000446_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(p1__74000446_SHARP___1, t.F_depth) }

func A_arbace_repr_go_print_code_n_values_A_New() *A_arbace_repr_go_print_code_n_values_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_n_values_A{}; t.Ctor(); return t }
//line :1071:1
func (t *A_arbace_repr_go_print_code_n_values_A) Ctor() {}
//line :1071:1
func (t *A_arbace_repr_go_print_code_n_values_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_95)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0))).Ref() } else { return A_arbace_repr_go_print_code_A_const_130 } }




func A_arbace_repr_go_print_code_zero_form_QMARK__A_New() *A_arbace_repr_go_print_code_zero_form_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_zero_form_QMARK__A{}; t.Ctor(); return t }
//line :1076:1
func (t *A_arbace_repr_go_print_code_zero_form_QMARK__A) Ctor() {}
//line :1076:1
func (t *A_arbace_repr_go_print_code_zero_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0), Lit_88)).Ref() } else { return and__1927000168__auto____2 } }






func A_arbace_repr_go_print_code_targets_A_New() *A_arbace_repr_go_print_code_targets_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_targets_A{}; t.Ctor(); return t }
//line :1083:1
func (t *A_arbace_repr_go_print_code_targets_A) Ctor() {}
//line :1083:1
func (t *A_arbace_repr_go_print_code_targets_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0), Lit_95)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(t__0)) } else { return lang.Tuple_Create_O__IPersistentVector(t__0) } }

func A_arbace_repr_go_print_code_binding_stmt_A_New() *A_arbace_repr_go_print_code_binding_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binding_stmt_A{}; t.Ctor(); return t }
//line :1085:1
func (t *A_arbace_repr_go_print_code_binding_stmt_A) Ctor() {}
//line :1085:1
func (t *A_arbace_repr_go_print_code_binding_stmt_A) Invoke_O_O_O__O(self, target__0, init__1 any) any { var ts__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_311.GetRawRoot__O()).Invoke_O__O(target__0); var ms__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_317.GetRawRoot__O(), ts__3); var tm__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(target__0); var const_QMARK___6 any; var or__1927000174__auto____6 any = A_arbace_repr_go_print_code_A_const_312.Invoke_O__O(tm__5); if





	jrt.J2g_Truth(or__1927000174__auto____6) { const_QMARK___6 = or__1927000174__auto____6 } else { const_QMARK___6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_312, ms__4) }; var var_QMARK___7 any; var or__1927000174__auto____7 any = /*line :1085:1*/A_arbace_repr_go_print_code_A_const_313.Invoke_O__O(tm__5); if






	jrt.J2g_Truth(or__1927000174__auto____7) { var_QMARK___7 = or__1927000174__auto____7 } else { var_QMARK___7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_313, ms__4) }; var typ__8 any; var tmp1 lang.IFn = /*line :1085:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A_New(); var tmp3 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A_fn_class; if







	fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A_fn_class = fncls__235d; tmp3 = fncls__235d } else { tmp3 = fncls__235 }; typ__8 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ms__4); var names__9 any; var tmp4 any = /*line :1085:1*/A_arbace_repr_go_print_code_binding_stmt_names__74000457_A_New_O(ts__3); var tmp5 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_repr_go_print_code_binding_stmt_names__74000457_A_fn_class; if








	fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_print_code_binding_stmt_names__74000457_A_fn_class = fncls__229d; tmp5 = fncls__229d } else { tmp5 = fncls__229 }; names__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var kw_pos__10 any = /*line :1085:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(target__0, A_arbace_repr_go_print_code_A_const_318); if










	jrt.J2g_Truth(const_QMARK___6) {
		if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_319.Get__O()) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_12, kw_pos__10); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }; lang.IFn_Cast(names__9).Invoke__O()
		if jrt.J2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(typ__8) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1096:1
			var tmp6 any
			var or__1927000174__auto____11 any = var_QMARK___7


			if jrt.J2g_Truth(or__1927000174__auto____11) { tmp6 = or__1927000174__auto____11 } else { tmp6 = typ__8 }
//line :1096:1
			if jrt.J2g_Truth(tmp6) {



				if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_319.Get__O()) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_13, kw_pos__10); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }; lang.IFn_Cast(names__9).Invoke__O()
				if jrt.J2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(typ__8) }
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_315.GetRawRoot__O()).Invoke_O__O(init__1)) { return nil } else {
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_repr_go_print_code_A_const_130) } } else {
//line :1096:1
						if A_arbace_repr_go_print_code_A_const_42 != nil { var depth__11 int64; var tmp7 bool; var and__1927000168__auto____11 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ts__3)), 1)







							if and__1927000168__auto____11 { var na_230 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_316.GetRawRoot__O()).Invoke_O__O(init__1); var na_231 int64 = 1; if jrt.Long_InstanceOf(na_230) { var n0_232 int64 = jrt.NN(jrt.Long_Cast(na_230)).LongValue__J(); var n1_233 int64 = na_231; tmp7 = n0_232 > n1_233 } else { tmp7 = lang.Numbers_Gt_O_J__Z_NoInit(na_230, na_231) } } else { tmp7 = and__1927000168__auto____11 }; if tmp7 { depth__11 = 2 } else { depth__11 = 1 }
							var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_print_code_A_const_130; var tmp10 any = A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A_New_J(depth__11); var tmp11 *jrt.Class; var fncls__236 *jrt.Class = A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A_fn_class; if fncls__236 == nil { var fncls__236d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A_fn_class = fncls__236d; tmp11 = fncls__236d } else { tmp11 = fncls__236 }; tmp8.Invoke_O_O_O_O__O(target__0, tmp9, ts__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))
							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_15, kw_pos__10); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(init__1, jrt.Long_ValueOf_J__Long_NoInit(depth__11).Ref()) } else {
//line :1096:1
								return nil } } } }
//line :1093:1
func A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A_New() *A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A{}; t.Ctor(); return t }
//line :1093:1
func (t *A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A) Ctor() {}
//line :1093:1
func (t *A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A) Invoke_O_O__O(self, p1__74000453_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(p1__74000453_SHARP___1, A_arbace_repr_go_print_code_A_const_31)) { return A_arbace_repr_go_print_code_A_const_31.Invoke_O__O(p1__74000453_SHARP___1) } else { return nil } }
func A_arbace_repr_go_print_code_binding_stmt_names__74000457_A_New_O(p0 any) *A_arbace_repr_go_print_code_binding_stmt_names__74000457_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binding_stmt_names__74000457_A{}; t.Ctor_O(p0); return t }
//line :1094:1
func (t *A_arbace_repr_go_print_code_binding_stmt_names__74000457_A) Ctor_O(c__ts any) { t.F_ts = c__ts }
//line :1094:1
func (t *A_arbace_repr_go_print_code_binding_stmt_names__74000457_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(t.F_ts) }










func A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A_New_J(p0 int64) *A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A{}; t.Ctor_J(p0); return t }
//line :1105:1
func (t *A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A) Ctor_J(c__depth int64) { t.F_depth = c__depth }
//line :1105:1
func (t *A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A) Invoke_O_O__O(self, p1__74000454_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(p1__74000454_SHARP___1, jrt.Long_ValueOf_J__Long_NoInit(t.F_depth).Ref()) }


func A_arbace_repr_go_print_code_type_binding_stmt_A_New() *A_arbace_repr_go_print_code_type_binding_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_binding_stmt_A{}; t.Ctor(); return t }
//line :1108:1
func (t *A_arbace_repr_go_print_code_type_binding_stmt_A) Ctor() {}
//line :1108:1
func (t *A_arbace_repr_go_print_code_type_binding_stmt_A) Invoke_O_O_O__O(self, nm__0, t__1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_33; var tps__3 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__0)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_A_const_141;

	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tps__3)).Ref())); var tmp4 any; tmp6 := /*line :1108:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_319.Get__O()) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_129, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(nm__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(nm__0)
		if jrt.J2g_Truth(tps__3) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_320.GetRawRoot__O()).Invoke_O__O(tps__3) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
		{ var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_321; if jrt.J2g_Truth(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__0))) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
			tmp4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__1) }
//line :1108:1
		return nil }();

	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :1108:1*/ tmp6 != nil { panic(tmp6) }; return tmp4 }









func A_arbace_repr_go_print_code_assign_stmt_A_New() *A_arbace_repr_go_print_code_assign_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_assign_stmt_A{}; t.Ctor(); return t }
//line :1118:1
func (t *A_arbace_repr_go_print_code_assign_stmt_A) Ctor() {}
//line :1118:1
func (t *A_arbace_repr_go_print_code_assign_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000463__2 any = f__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000463__2, lang.RT_IntCast_J__I_NoInit(0), nil); var place__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000463__2, lang.RT_IntCast_J__I_NoInit(1), nil); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000463__2, lang.RT_IntCast_J__I_NoInit(2), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000463__2, lang.RT_IntCast_J__I_NoInit(3), nil); var G__74000466__7_ int32 = lang.RT_Count_O__I_NoInit(f__0); _ = ___3; switch G__74000466__7_ {

case 3: var depth__8 int64; var tmp1 bool; var and__1927000168__auto____8 bool; var na_238 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_316.GetRawRoot__O()).Invoke_O__O(place__4); var na_239 int64 = 1
	if jrt.Long_InstanceOf(na_238) { var n0_240 int64 = jrt.NN(jrt.Long_Cast(na_238)).LongValue__J(); var n1_241 int64 = na_239; and__1927000168__auto____8 = n0_240 > n1_241 } else { and__1927000168__auto____8 = lang.Numbers_Gt_O_J__Z_NoInit(na_238, na_239) }; if and__1927000168__auto____8 { var na_243 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_316.GetRawRoot__O()).Invoke_O__O(a__5); var na_244 int64 = 1; if jrt.Long_InstanceOf(na_243) { var n0_245 int64 = jrt.NN(jrt.Long_Cast(na_243)).LongValue__J(); var n1_246 int64 = na_244; tmp1 = n0_245 > n1_246 } else { tmp1 = lang.Numbers_Gt_O_J__Z_NoInit(na_243, na_244) } } else { tmp1 = and__1927000168__auto____8 }; if tmp1 { depth__8 = 2 } else { depth__8 = 1 }
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(place__4, jrt.Long_ValueOf_J__Long_NoInit(depth__8).Ref()); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_1, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(a__5, jrt.Long_ValueOf_J__Long_NoInit(depth__8).Ref())
//line :1120:1
case 4: var aop__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_322.GetRawRoot__O()); var tmp3 any


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_41.GetRawRoot__O()).Invoke_O__O(a__5)) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_57.GetRawRoot__O()).Invoke_O__O(a__5) } else { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_95.GetRawRoot__O()).Invoke_O__O(a__5) }; aop__8 = tmp2.Invoke_O__O(tmp3)
	if jrt.J2g_Truth(aop__8) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_2, a__5) }
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(place__4, A_arbace_repr_go_print_code_A_const_130); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(aop__8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(b__6, A_arbace_repr_go_print_code_A_const_130)
//line :1120:1
default:}; return /*line :1126:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_3, f__0) }

func A_arbace_repr_go_print_code_simple_stmt_A_New() *A_arbace_repr_go_print_code_simple_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_simple_stmt_A{}; t.Ctor(); return t }
//line :1128:1
func (t *A_arbace_repr_go_print_code_simple_stmt_A) Ctor() {}
//line :1128:1
func (t *A_arbace_repr_go_print_code_simple_stmt_A) Invoke_O_O__O(self, f__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(f__0)) { var G__74000468__2_ int32 = lang.RT_Count_O__I_NoInit(f__0)
		switch G__74000468__2_ { case 1:

			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0))
//line :1133:1
		case 2:
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_324.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(f__0), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0))
//line :1133:1
		default:
		}

		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_183, f__0) } else {
//line :1132:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0)) { var G__74000469__2_ any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)





				switch lang.Util_Hash_O__I_NoInit(G__74000469__2_) >> 4 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__74000469__2_, Lit_168) {




					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_303); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_184, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)) }
//line :1138:1
				case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__74000469__2_, Lit_177) { var vec__74000470__3 any = f__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000470__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ch__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000470__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000470__3, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4






					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(ch__5, A_arbace_repr_go_print_code_A_const_130); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_32, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_213)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(v__6, A_arbace_repr_go_print_code_A_const_130) }
//line :1138:1
				case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__74000469__2_, Lit_169) {





					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_303); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_185, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)) }
//line :1138:1
				case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__74000469__2_, Lit_170) { var vec__74000473__3 any = f__0; var ___4_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000473__3, lang.RT_IntCast_J__I_NoInit(0), nil); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000473__3, lang.RT_IntCast_J__I_NoInit(1), nil); var i__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000473__3, lang.RT_IntCast_J__I_NoInit(2), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000473__3, lang.RT_IntCast_J__I_NoInit(3), nil); _ = ___4_2


					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(a__5, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_99, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_215)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(i__6, A_arbace_repr_go_print_code_A_const_303); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_101, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_216))
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_1, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(v__7, A_arbace_repr_go_print_code_A_const_130) }
//line :1138:1
				case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__74000469__2_, Lit_179) {
					return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_325.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1138:1
				default:
				}






				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1132:1
					if A_arbace_repr_go_print_code_A_const_42 != nil {














						return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1132:1
							return nil
						}
				}
		}
}












func A_arbace_repr_go_print_code_clause_QMARK__A_New() *A_arbace_repr_go_print_code_clause_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_clause_QMARK__A{}; t.Ctor(); return t }
//line :1149:1
func (t *A_arbace_repr_go_print_code_clause_QMARK__A) Ctor() {}
//line :1149:1
func (t *A_arbace_repr_go_print_code_clause_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_326); return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_print_code_control_clause_A_New() *A_arbace_repr_go_print_code_control_clause_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_control_clause_A{}; t.Ctor(); return t }
//line :1151:1
func (t *A_arbace_repr_go_print_code_control_clause_A) Ctor() {}
//line :1151:1
func (t *A_arbace_repr_go_print_code_control_clause_A) Invoke_O_O_O_O_O__O(self, for_QMARK___0, init__1, cond__2, post__3 any) any {


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_TRUE.Ref()))
//line :1151:1
	var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
//line :1151:1
		{ var init__7 any; var tmp2 any
			var and__1927000168__auto____7 any = init__1



			if jrt.J2g_Truth(and__1927000168__auto____7) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(init__1, lang.PersistentVector_EMPTY.Ref()) } else { tmp2 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp2) { init__7 = init__1 } else { init__7 = nil }
//line :1151:1
			var post__8 any; var tmp3 any
			var and__1927000168__auto____8 any = post__3




			if jrt.J2g_Truth(and__1927000168__auto____8) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(post__3, A_arbace_repr_go_print_code_A_const_328) } else { tmp3 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp3) { post__8 = post__3 } else { post__8 = nil }
//line :1151:1
			var cond__9 any; var tmp4 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(cond__2)






			if jrt.J2g_Truth(and__1927000168__auto____9) { tmp4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(cond__2, A_arbace_repr_go_print_code_A_const_329) } else { tmp4 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp4) { cond__9 = cond__2 } else { cond__9 = nil }
			var tmp5 bool; var and__1927000168__auto____10 bool = lang.Util_Identical_O_O__Z_NoInit(init__7, nil); if and__1927000168__auto____10 { tmp5 = lang.Util_Identical_O_O__Z_NoInit(post__8, nil) } else { tmp5 = and__1927000168__auto____10 }; if tmp5 {
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(cond__9)) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(cond__9, A_arbace_repr_go_print_code_A_const_130); tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } else { tmp1 = nil } } else {
					if jrt.J2g_Truth(init__7) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(init__7) }
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(cond__9)) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(cond__9, A_arbace_repr_go_print_code_A_const_130) }
					if jrt.J2g_Truth(for_QMARK___0) {
						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
						if jrt.J2g_Truth(post__8) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(post__8); tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } else { tmp1 = nil } } else {
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(cond__9)) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() } else { tmp1 = nil } } } }
//line :1151:1
		return nil
	}()

	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :1151:1
	if tmp6 != nil { panic(tmp6) }; return tmp1
}
















func A_arbace_repr_go_print_code_branch_forms_A_New() *A_arbace_repr_go_print_code_branch_forms_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_branch_forms_A{}; t.Ctor(); return t }
//line :1169:1
func (t *A_arbace_repr_go_print_code_branch_forms_A) Ctor() {}
//line :1169:1
func (t *A_arbace_repr_go_print_code_branch_forms_A) Invoke_O_O__O(self, b__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(b__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(b__0), Lit_20)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(b__0)) } else { return lang.Tuple_Create_O__IPersistentVector(b__0)
	} }
func A_arbace_repr_go_print_code_branch_opts_A_New() *A_arbace_repr_go_print_code_branch_opts_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_branch_opts_A{}; t.Ctor(); return t }
//line :1174:1
func (t *A_arbace_repr_go_print_code_branch_opts_A) Ctor() {}
//line :1174:1
func (t *A_arbace_repr_go_print_code_branch_opts_A) Invoke_O_O_O_O__O(self, parent__0, i__1, b__2 any) any {


	var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(b__2); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(b__2), Lit_20)).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, b__2, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_130)) } else { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, parent__0, A_arbace_repr_go_print_code_A_const_117, i__1))
	} }
func A_arbace_repr_go_print_code_if_like_QMARK__A_New() *A_arbace_repr_go_print_code_if_like_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_if_like_QMARK__A{}; t.Ctor(); return t }
//line :1179:1
func (t *A_arbace_repr_go_print_code_if_like_QMARK__A) Ctor() {}
//line :1179:1
func (t *A_arbace_repr_go_print_code_if_like_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_330); return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_code_else_part_A_New() *A_arbace_repr_go_print_code_else_part_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_else_part_A{}; t.Ctor(); return t }
//line :1183:1
func (t *A_arbace_repr_go_print_code_else_part_A) Ctor() {}
//line :1183:1
func (t *A_arbace_repr_go_print_code_else_part_A) Invoke_O_O_O__O(self, els__0, opts__1 any) any {
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_73); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(els__0)) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(els__0) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(els__0), opts__1)
		} }
func A_arbace_repr_go_print_code_if_stmt_A_New() *A_arbace_repr_go_print_code_if_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_if_stmt_A{}; t.Ctor(); return t }
//line :1189:1
func (t *A_arbace_repr_go_print_code_if_stmt_A) Ctor() {}
//line :1189:1
func (t *A_arbace_repr_go_print_code_if_stmt_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); var G__74000483__3_ any = o__2; switch

	lang.Util_Hash_O__I_NoInit(G__74000483__3_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__74000483__3_, Lit_137) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_334.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_303; var pairs__4 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0)); var cps__5 any
		var tmp3 /*line :1191:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_24


























		if jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_335; cps__5 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { cps__5 = nil }
//line :1191:1
		var braces__6 any; var tmp5 any = A_arbace_repr_go_print_code_if_stmt_braces__74000484_A_New_O(cps__5); var tmp6 *jrt.Class
		var fncls__251 /*line :1191:1*/*jrt.Class = A_arbace_repr_go_print_code_if_stmt_braces__74000484_A_fn_class



























		if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_repr_go_print_code_if_stmt_braces__74000484_A_fn_class = fncls__251d; tmp6 = fncls__251d } else { tmp6 = fncls__251 }; braces__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_337.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0))).Ref())) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_139, f__0) }
//line :1191:1
		var G__74000495__7_ any = pairs__4; var vec__74000496__8 any = G__74000495__7_; var seq__74000497__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000496__8); var first__74000498__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000497__9); var seq__74000497__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000497__9); var vec__74000499__12 any = first__74000498__10; var t__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000499__12, lang.RT_IntCast_J__I_NoInit(0), nil); var b__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000499__12, lang.RT_IntCast_J__I_NoInit(1), nil); var more__15 any = seq__74000497__11; var bi__16 int64 = 2; var k__17 int64 = 0; var G__74000495__18_ any = G__74000495__7_; var bi__19 int64 = bi__16; var k__20 int64 = k__17; _ = t__13; _ = b__14; _ = more__15; L2: for { var vec__74000502__21 any = G__74000495__18_; var seq__74000503__22 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000502__21); var first__74000504__23 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000503__22); var seq__74000503__24 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000503__22); var vec__74000505__25 any = first__74000504__23; var t__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000505__25, lang.RT_IntCast_J__I_NoInit(0), nil); var b__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000505__25, lang.RT_IntCast_J__I_NoInit(1), nil)
			var more__28 any = seq__74000503__24
			var bi__29 int64 = bi__19
			var k__30 int64 = k__20



























			if lang.Util_Equiv_O_O__Z_NoInit(t__26, A_arbace_repr_go_print_code_A_const_42) {
				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(b__27), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(bi__29).Ref(), b__27), lang.IFn_Cast(braces__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(k__30).Ref()))) } else {
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_140, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(cps__5, jrt.Long_ValueOf_J__Long_NoInit(k__30).Ref()))); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_340.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.Boolean_FALSE.Ref(), nil, t__26, nil)
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(more__28)) { var vec__74000508__31 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(more__28); var nt__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000508__31, lang.RT_IntCast_J__I_NoInit(0), nil); var nb__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000508__31, lang.RT_IntCast_J__I_NoInit(1), nil); var nl__34 any

						if lang.Util_Equiv_O_O__Z_NoInit(nt__32, A_arbace_repr_go_print_code_A_const_42) { nl__34 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(nb__33)) } else { nl__34 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(nt__32) }
						var tmp7 any = A_arbace_repr_go_print_code_A_const_341; var tmp8 any = A_arbace_repr_go_print_code_A_const_342; var tmp9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(nt__32, A_arbace_repr_go_print_code_A_const_42); var tmp10 any = A_arbace_repr_go_print_code_A_const_343; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(b__27), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(bi__29).Ref(), b__27), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, nl__34, tmp8, tmp9, tmp10, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(nt__32, A_arbace_repr_go_print_code_A_const_42)).Ref())), lang.IFn_Cast(braces__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(k__30).Ref())))



						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_73); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
						G__74000495__18_, bi__19, k__20 = more__28, lang.Numbers_Add_J_J__J_NoInit(bi__29, 2), lang.Numbers_Inc_J__J_NoInit(k__30); continue L2 } else {
							return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(b__27), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(bi__29).Ref(), b__27), lang.IFn_Cast(braces__6).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(k__30).Ref()))) } } } }
//line :1191:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__74000483__3_, Lit_141) { var vec__74000511__4 any = f__0; var seq__74000512__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000511__4); var first__74000513__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000512__5); var seq__74000512__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000512__5); var ___8 any = first__74000513__6; var xs__9 any = seq__74000512__7; var vec__74000514__10 any; _ = ___8




















		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__9))) { vec__74000514__10 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__9), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__9)) } else { vec__74000514__10 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__9) }
//line :1191:1
		var init__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000514__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000514__10, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__74000517__13 any = xs__12; var seq__74000518__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000517__13); var first__74000519__15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000518__14); var seq__74000518__16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000518__14)
		var c__17 any = first__74000519__15
		var body__18 any = seq__74000518__16




















		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_140, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_344)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_340.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.Boolean_FALSE.Ref(), init__11, c__17, nil)
		var tmp11 any = A_arbace_repr_go_print_code_A_const_116; var tmp12 any = A_arbace_repr_go_print_code_A_const_117; var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_286.GetRawRoot__O()).Invoke_O_O__O(f__0, body__18); var tmp14 any = A_arbace_repr_go_print_code_A_const_202; var tmp15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_202); var tmp16 any = A_arbace_repr_go_print_code_A_const_203; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__18), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, f__0, tmp12, tmp13, tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_203)))) }
//line :1191:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__74000483__3_, Lit_140) { var vec__74000520__4 any = f__0; var seq__74000521__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000520__4); var first__74000522__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000521__5); var seq__74000521__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000521__5); var ___8_2 any = first__74000522__6; var xs__9_2 any = seq__74000521__7; var vec__74000523__10 any; _ = ___8_2

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__9_2))) { vec__74000523__10 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__9_2), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__9_2)) } else { vec__74000523__10 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__9_2) }
//line :1191:1
		var init__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000523__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000523__10, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__74000526__13 any = xs__12_2; var seq__74000527__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000526__13); var first__74000528__15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000527__14); var seq__74000527__16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000527__14); var c__17_2 any = first__74000528__15; var first__74000528__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000527__16); var seq__74000527__19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000527__16); var then__20 any = first__74000528__18; var more__21 any = seq__74000527__19; var tmp17 any = A_arbace_repr_go_print_code_A_const_202; var tmp18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_202); var tmp19 any = A_arbace_repr_go_print_code_A_const_203; var braces__22 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_203)))




		if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(more__21)), 1) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_142, f__0) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_140, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_344)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_340.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.Boolean_FALSE.Ref(), init__11_2, c__17_2, nil)
//line :1191:1
		var ti__23 int64






		if jrt.J2g_Truth(init__11_2) { ti__23 = 3 } else { ti__23 = 2 }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(more__21)) { var els__24 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(more__21); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(then__20); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(ti__23).Ref(), then__20); var tmp24 any = A_arbace_repr_go_print_code_A_const_341; var tmp25 any; var or__1927000174__auto____25 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(els__24)


			if jrt.J2g_Truth(or__1927000174__auto____25) { tmp25 = or__1927000174__auto____25 } else {
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(els__24)) { tmp25 = nil } else {
					tmp25 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(els__24)) } }
//line :1201:1
			var tmp26 any = tmp25; var tmp27 any = A_arbace_repr_go_print_code_A_const_342; var tmp28 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(els__24); var tmp29 any = A_arbace_repr_go_print_code_A_const_343; tmp20.Invoke_O_O__O(tmp21, tmp22.Invoke_O_O_O__O(tmp23, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp26, tmp27, tmp28, tmp29, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_331.GetRawRoot__O()).Invoke_O__O(els__24)))), braces__22))






			var tmp30 any = A_arbace_repr_go_print_code_A_const_202; var tmp31 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_345); var tmp32 any = A_arbace_repr_go_print_code_A_const_203; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_336.GetRawRoot__O()).Invoke_O_O__O(els__24, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(ti__23)).Ref(), els__24), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31, tmp32, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_346))))) } else {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_333.GetRawRoot__O()).Invoke_O__O(then__20), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_339.GetRawRoot__O()).Invoke_O_O_O__O(f__0, jrt.Long_ValueOf_J__Long_NoInit(ti__23).Ref(), then__20), braces__22)) } }
//line :1191:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__74000483__3_))))) }



























func A_arbace_repr_go_print_code_if_stmt_braces__74000484_A_New_O(p0 any) *A_arbace_repr_go_print_code_if_stmt_braces__74000484_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_if_stmt_braces__74000484_A{}; t.Ctor_O(p0); return t }
//line :1219:1
func (t *A_arbace_repr_go_print_code_if_stmt_braces__74000484_A) Ctor_O(c__cps any) { t.F_cps = c__cps }
//line :1219:1
func (t *A_arbace_repr_go_print_code_if_stmt_braces__74000484_A) Invoke_O_O__O(self, k__1 any) any { var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(t.F_cps, k__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__74000485__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000485__3, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000485__3, lang.RT_IntCast_J__I_NoInit(1), nil); var rb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000485__3, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_202, lb__5, A_arbace_repr_go_print_code_A_const_203, rb__6)) } else { return nil } }
















func A_arbace_repr_go_print_code_clause_list_A_New() *A_arbace_repr_go_print_code_clause_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_clause_list_A{}; t.Ctor(); return t }
//line :1236:1
func (t *A_arbace_repr_go_print_code_clause_list_A) Ctor() {}
//line :1236:1
func (t *A_arbace_repr_go_print_code_clause_list_A) DoInvoke_O_O_O_O__O(self, clauses__0, print_head__1, p__74000530__2 any) any { var vec__74000531__4 any = p__74000530__2; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000531__4, lang.RT_IntCast_J__I_NoInit(0), nil); var indent__6 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_162; if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_163; indent__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_164; indent__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__5, A_arbace_repr_go_print_code_A_const_202));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(indent__6); var clauses__7 any = /*line :1236:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(clauses__0); var n__1927000701__auto____8 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(clauses__7)); var i__9 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i__9, n__1927000701__auto____8) { var c__10 any = lang.RT_Nth_O_I__O_NoInit(clauses__7, lang.RT_IntCast_J__I_NoInit(i__9))

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_349.GetRawRoot__O()).Invoke_O__O(c__10)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_34, c__10) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_code_A_const_86; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_209.GetRawRoot__O()).Invoke_O_O__O(clauses__7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__9)).Ref())))); var tmp6 any = A_arbace_repr_go_print_code_clause_list_fn__74000534_A_New_J_O_O_O(i__9, indent__6, print_head__1, c__10); var tmp7 *jrt.Class; var fncls__256 *jrt.Class = A_arbace_repr_go_print_code_clause_list_fn__74000534_A_fn_class; if fncls__256 == nil { var fncls__256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_code_clause_list_fn__74000534_A_fn_class = fncls__256d; tmp7 = fncls__256d } else { tmp7 = fncls__256 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :1243:1
			i__9 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__9); continue L1 }
//line :1236:1
		break L1 };

















	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O();
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()).Invoke_O_O_O_O__O(nil, jrt.Boolean_TRUE.Ref(), jrt.Boolean_TRUE.Ref(), indent__6); var tmp8 /*line :1256:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp8.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }; return /*line :1257:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_19, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__5, A_arbace_repr_go_print_code_A_const_203)) }
//line :1246:1
func A_arbace_repr_go_print_code_clause_list_fn__74000534_A_New_J_O_O_O(p0 int64, p1, p2, p3 any) *A_arbace_repr_go_print_code_clause_list_fn__74000534_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_clause_list_fn__74000534_A{}; t.Ctor_J_O_O_O(p0, p1, p2, p3); return t }
//line :1246:1
func (t *A_arbace_repr_go_print_code_clause_list_fn__74000534_A) Ctor_J_O_O_O(c__i int64, c__indent, c__print_head, c__c any) { t.F_i = c__i; t.F_indent = c__indent; t.F_print_head = c__print_head; t.F_c = c__c }
//line :1246:1
func (t *A_arbace_repr_go_print_code_clause_list_fn__74000534_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(t.F_c), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_i)).Ref(), Lit_36, t.F_indent)
												if lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t.F_c), Lit_37) {
													lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_37, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_c, A_arbace_repr_go_print_code_A_const_348)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_38, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_c, A_arbace_repr_go_print_code_A_const_272))
													var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_347.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(t.F_c)); var tmp4 any = A_arbace_repr_go_print_code_A_const_163; var tmp5 jrt.Number_I; var na_252 any; var t_ any = t.F_indent; t.F_indent = nil; na_252 = t_; if jrt.Long_InstanceOf(na_252) { var n0_253 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); if n0_253 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_252) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_253 + 1)) } } else { if jrt.Double_InstanceOf(na_252) { var n0_253_2 float64 = jrt.NN(jrt.Double_Cast(na_252)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_253_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_252) } }; var tmp6 any = tmp5; var tmp7 any = A_arbace_repr_go_print_code_A_const_116; var tmp8 any; var t__2 any = t.F_c; t.F_c = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_130))) } else {
//line :1248:1
			var vec__74000535__3 any = t.F_c; var seq__74000536__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000535__3); var first__74000537__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000536__4); var seq__74000536__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000536__4); var ___7 any = first__74000537__5; var first__74000537__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000536__6); var seq__74000536__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000536__6); var head__10 any = first__74000537__8; var body__11 any = seq__74000536__9; _ = ___7



			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_39, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_c, A_arbace_repr_go_print_code_A_const_348)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp9 any; var t__3 any = t.F_print_head; t.F_print_head = nil; tmp9 = t__3; lang.IFn_Cast(tmp9).Invoke_O__O(head__10); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_38, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_c, A_arbace_repr_go_print_code_A_const_272))
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_347.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__11); var tmp12 any = A_arbace_repr_go_print_code_A_const_163; var tmp13 jrt.Number_I; var na_254 any; var t__4 any = t.F_indent; t.F_indent = nil; na_254 = t__4; if jrt.Long_InstanceOf(na_254) { var n0_255 int64 = jrt.NN(jrt.Long_Cast(na_254)).LongValue__J(); if n0_255 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_254) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_255 + 1)) } } else { if jrt.Double_InstanceOf(na_254) { var n0_255_2 float64 = jrt.NN(jrt.Double_Cast(na_254)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_255_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_254) } }; var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_print_code_A_const_116; var tmp16 any; var t__5 any = t.F_c; t.F_c = nil; tmp16 = t__5; tmp1 = tmp10.Invoke_O_O__O(tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp15, tmp16, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_303))) }
//line :1246:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }












func A_arbace_repr_go_print_code_case_exprs_A_New() *A_arbace_repr_go_print_code_case_exprs_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_case_exprs_A{}; t.Ctor(); return t }
//line :1259:1
func (t *A_arbace_repr_go_print_code_case_exprs_A) Ctor() {}
//line :1259:1
func (t *A_arbace_repr_go_print_code_case_exprs_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(v__0)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_27, v__0) }
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(v__0))
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_188; var tmp3 any = A_arbace_repr_go_print_code_case_exprs_fn__74000541_A_New(); var tmp4 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_repr_go_print_code_case_exprs_fn__74000541_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_go_print_code_case_exprs_fn__74000541_A_fn_class = fncls__257d; tmp4 = fncls__257d } else { tmp4 = fncls__257 }; return tmp1.Invoke_O_O_O_O__O(v__0, tmp2, v__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :1262:1
func A_arbace_repr_go_print_code_case_exprs_fn__74000541_A_New() *A_arbace_repr_go_print_code_case_exprs_fn__74000541_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_case_exprs_fn__74000541_A{}; t.Ctor(); return t }
//line :1262:1
func (t *A_arbace_repr_go_print_code_case_exprs_fn__74000541_A) Ctor() {}
//line :1262:1
func (t *A_arbace_repr_go_print_code_case_exprs_fn__74000541_A) Invoke_O_O__O(self, p1__74000540_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(p1__74000540_SHARP___1, A_arbace_repr_go_print_code_A_const_130) }

func A_arbace_repr_go_print_code_case_types_A_New() *A_arbace_repr_go_print_code_case_types_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_case_types_A{}; t.Ctor(); return t }
//line :1264:1
func (t *A_arbace_repr_go_print_code_case_types_A) Ctor() {}
//line :1264:1
func (t *A_arbace_repr_go_print_code_case_types_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(v__0)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_27, v__0) }
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(v__0))
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_188; var tmp3 any = A_arbace_repr_go_print_code_case_types_fn__74000545_A_New(); var tmp4 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_repr_go_print_code_case_types_fn__74000545_A_fn_class; if fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_repr_go_print_code_case_types_fn__74000545_A_fn_class = fncls__258d; tmp4 = fncls__258d } else { tmp4 = fncls__258 }; return tmp1.Invoke_O_O_O_O__O(v__0, tmp2, v__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :1267:1
func A_arbace_repr_go_print_code_case_types_fn__74000545_A_New() *A_arbace_repr_go_print_code_case_types_fn__74000545_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_case_types_fn__74000545_A{}; t.Ctor(); return t }
//line :1267:1
func (t *A_arbace_repr_go_print_code_case_types_fn__74000545_A) Ctor() {}
//line :1267:1
func (t *A_arbace_repr_go_print_code_case_types_fn__74000545_A) Invoke_O_O__O(self, p1__74000544_SHARP___1 any) any { if lang.Util_Identical_O_O__Z_NoInit(p1__74000544_SHARP___1, nil) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_30) } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(p1__74000544_SHARP___1) } }

func A_arbace_repr_go_print_code_switch_stmt_A_New() *A_arbace_repr_go_print_code_switch_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_switch_stmt_A{}; t.Ctor(); return t }
//line :1269:1
func (t *A_arbace_repr_go_print_code_switch_stmt_A) Ctor() {}
//line :1269:1
func (t *A_arbace_repr_go_print_code_switch_stmt_A) Invoke_O_O__O(self, f__0 any) any { var xs__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0); var vec__74000548__3 any; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__2))) { vec__74000548__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__2), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__2)) } else { vec__74000548__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__2) }; var init__4 any = /*line :1269:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000548__3, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000548__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__74000551__6 any; var tmp1 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(xs__5); if


	jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_349.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__5))) } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { vec__74000551__6 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__5), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__5)) } else { vec__74000551__6 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__5) }; var tag__7 any = /*line :1269:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000551__6, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000551__6, lang.RT_IntCast_J__I_NoInit(1), nil);



	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_176, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_351));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_TRUE.Ref())); var tmp2 any = A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A_New_O_O(init__4, tag__7); var tmp3 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A_fn_class; if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_194, false); A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A_fn_class = fncls__259d; tmp3 = fncls__259d } else { tmp3 = fncls__259 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); return /*line :1279:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_350.GetRawRoot__O()).Invoke_O_O_O__O(xs__8, A_arbace_repr_go_print_code_A_const_352.GetRawRoot__O(), f__0) }
//line :1274:1
func A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1274:1
func (t *A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A) Ctor_O_O(c__init, c__tag any) { t.F_init = c__init; t.F_tag = c__tag }
//line :1274:1
func (t *A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var and__1927000168__auto____3 any = t.F_init
													if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(t.F_tag) } else { tmp2 = and__1927000168__auto____3 }
//line :1275:1
		if jrt.J2g_Truth(tmp2) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_init; t.F_init = nil; tmp4 = t_; tmp3.Invoke_O__O(tmp4); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_tag; t.F_tag = nil; tmp6 = t__2; tmp1 = tmp5.Invoke_O_O__O(tmp6, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1275:1
				if jrt.J2g_Truth(t.F_init) {

					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_init; t.F_init = nil; tmp8 = t__3; tmp7.Invoke_O__O(tmp8); tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36) } else {
//line :1275:1
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(t.F_tag)) {


							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp10 any; var t__4 any = t.F_tag; t.F_tag = nil; tmp10 = t__4; tmp1 = tmp9.Invoke_O_O__O(tmp10, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1275:1
								tmp1 = nil } } } }
//line :1274:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }






func A_arbace_repr_go_print_code_type_switch_stmt_A_New() *A_arbace_repr_go_print_code_type_switch_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_switch_stmt_A{}; t.Ctor(); return t }
//line :1281:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_A) Ctor() {}
//line :1281:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000557__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0); var seq__74000558__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000557__2); var first__74000559__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000558__3); var seq__74000558__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000558__3); var a__6 any = first__74000559__4; var first__74000559__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000558__5); var seq__74000558__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000558__5); var b__9 any = first__74000559__7; var more__10 any = seq__74000558__8; var vec__74000560__11 any; var tmp1 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(a__6); if


	jrt.J2g_Truth(and__1927000168__auto____11) { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(b__9); if jrt.J2g_Truth(and__1927000168__auto____12) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_349.GetRawRoot__O()).Invoke_O__O(b__9)) } else { tmp1 = and__1927000168__auto____12 } } else { tmp1 = and__1927000168__auto____11 }; if /*line :1283:1*/ jrt.J2g_Truth(tmp1) { vec__74000560__11 = lang.Tuple_Create_O_O_O__IPersistentVector(a__6, b__9, more__10) } else { if A_arbace_repr_go_print_code_A_const_42 != nil { vec__74000560__11 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, a__6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_180.GetRawRoot__O()).Invoke_O_O__O(b__9, more__10)) } else { vec__74000560__11 = nil } }; var init__12 any = /*line :1281:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000560__11, lang.RT_IntCast_J__I_NoInit(0), nil); var guard__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000560__11, lang.RT_IntCast_J__I_NoInit(1), nil); var clauses__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000560__11, lang.RT_IntCast_J__I_NoInit(2), nil); var clauses__15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_353.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_354.GetRawRoot__O(), clauses__14);





	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_176, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_351));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_TRUE.Ref())); var tmp2 any = A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A_New_O_O_O(init__12, f__0, guard__13); var tmp3 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A_fn_class; if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_210, false); A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A_fn_class = fncls__261d; tmp3 = fncls__261d } else { tmp3 = fncls__261 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); return /*line :1298:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_350.GetRawRoot__O()).Invoke_O_O_O__O(clauses__15, A_arbace_repr_go_print_code_A_const_359.GetRawRoot__O(), f__0) }
//line :1288:1
func A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1288:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A) Ctor_O_O_O(c__init, c__f, c__guard any) { t.F_init = c__init; t.F_f = c__f; t.F_guard = c__guard }
//line :1288:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if jrt.J2g_Truth(t.F_init) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_init; t.F_init = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36) }
												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
//line :1288:1
	{ var assert_type__3 any; var tmp4 any = A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A_New_O(t.F_f); var tmp5 *jrt.Class
		var fncls__260 /*line :1288:1*/*jrt.Class = A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A_fn_class


		if fncls__260 == nil { var fncls__260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_211, false); A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A_fn_class = fncls__260d; tmp5 = fncls__260d } else { tmp5 = fncls__260 }; assert_type__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(t.F_guard)) { var vec__74000566__4 any; var t__2 any = t.F_guard; t.F_guard = nil; vec__74000566__4 = t__2; var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000566__4, lang.RT_IntCast_J__I_NoInit(0), nil); var g__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000566__4, lang.RT_IntCast_J__I_NoInit(1), nil)

			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(x__5); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_f; t.F_f = nil; tmp8 = t__3; tmp6.Invoke_O_O__O(Lit_15, tmp7.Invoke_O_O__O(tmp8, A_arbace_repr_go_print_code_A_const_358)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()).Invoke_O_O_O__O(g__6, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130); tmp1 = lang.IFn_Cast(assert_type__3).Invoke__O() } else {
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_255.GetRawRoot__O()); var tmp10 any; var t__4 any = t.F_guard; t.F_guard = nil; tmp10 = t__4; tmp9.Invoke_O_O_O__O(tmp10, A_arbace_repr_go_print_code_A_const_72, A_arbace_repr_go_print_code_A_const_130); tmp1 = lang.IFn_Cast(assert_type__3).Invoke__O() } }
//line :1288:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }


func A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A_New_O(p0 any) *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A{}; t.Ctor_O(p0); return t }
//line :1291:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1291:1
func (t *A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A) Invoke_O__O(self any) any { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_355)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_356)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_129)
	return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_357))
}






func A_arbace_repr_go_print_code_comm_A_New() *A_arbace_repr_go_print_code_comm_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_comm_A{}; t.Ctor(); return t }
//line :1300:1
func (t *A_arbace_repr_go_print_code_comm_A) Ctor() {}
//line :1300:1
func (t *A_arbace_repr_go_print_code_comm_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(c__0)) { var vec__74000571__2 any = c__0; var t__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000571__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000571__2, lang.RT_IntCast_J__I_NoInit(1), nil)
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_324.GetRawRoot__O()).Invoke_O_O__O(t__3, x__4) } else {
//line :1301:1
			if A_arbace_repr_go_print_code_A_const_42 != nil {

				return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(c__0) } else {
//line :1301:1
					return nil
				}
		}
}
func A_arbace_repr_go_print_code_select_stmt_A_New() *A_arbace_repr_go_print_code_select_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_select_stmt_A{}; t.Ctor(); return t }
//line :1305:1
func (t *A_arbace_repr_go_print_code_select_stmt_A) Ctor() {}
//line :1305:1
func (t *A_arbace_repr_go_print_code_select_stmt_A) Invoke_O_O__O(self, f__0 any) any {
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_172, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_360))
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_17); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_19) } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_350.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_361.GetRawRoot__O(), f__0)
		} }
func A_arbace_repr_go_print_code_braces_of_A_New() *A_arbace_repr_go_print_code_braces_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_braces_of_A{}; t.Ctor(); return t }
//line :1311:1
func (t *A_arbace_repr_go_print_code_braces_of_A) Ctor() {}
//line :1311:1
func (t *A_arbace_repr_go_print_code_braces_of_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_repr_go_print_code_A_const_202; var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_202); var tmp3 any = A_arbace_repr_go_print_code_A_const_203; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_203))) }

func A_arbace_repr_go_print_code_for_stmt_A_New() *A_arbace_repr_go_print_code_for_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_for_stmt_A{}; t.Ctor(); return t }
//line :1313:1
func (t *A_arbace_repr_go_print_code_for_stmt_A) Ctor() {}
//line :1313:1
func (t *A_arbace_repr_go_print_code_for_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000577__2 any = f__0; var seq__74000578__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000577__2); var first__74000579__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000578__3); var seq__74000578__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000578__3); var ___6 any = first__74000579__4; var first__74000579__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000578__5); var seq__74000578__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000578__5); var init__9 any = first__74000579__7; var first__74000579__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000578__8); var seq__74000578__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000578__8); var c__12 any = first__74000579__10; var first__74000579__13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000578__11); var seq__74000578__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000578__11); var post__15 any = first__74000579__13; var body__16 any = seq__74000578__14; _ = ___6; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(init__9)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_127, f__0) };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_128, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_362));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_340.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.Boolean_TRUE.Ref(), init__9, c__12, post__15); return /*line :1318:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__16), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, f__0, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_243)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_363.GetRawRoot__O()).Invoke_O__O(f__0))) }

func A_arbace_repr_go_print_code_while_stmt_A_New() *A_arbace_repr_go_print_code_while_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_while_stmt_A{}; t.Ctor(); return t }
//line :1320:1
func (t *A_arbace_repr_go_print_code_while_stmt_A) Ctor() {}
//line :1320:1
func (t *A_arbace_repr_go_print_code_while_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000581__2 any = f__0; var seq__74000582__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000581__2); var first__74000583__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000582__3); var seq__74000582__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000582__3); var ___6 any = first__74000583__4; var first__74000583__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000582__5); var seq__74000582__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000582__5); var c__9 any = first__74000583__7; var body__10 any = seq__74000582__8; _ = ___6;

	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_128, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_362)); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_105.GetRawRoot__O()).Invoke_O__O(c__9)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_TRUE.Ref())); var tmp1 any = A_arbace_repr_go_print_code_while_stmt_fn__74000584_A_New_O(c__9); var tmp2 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_repr_go_print_code_while_stmt_fn__74000584_A_fn_class; if fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_216, false); A_arbace_repr_go_print_code_while_stmt_fn__74000584_A_fn_class = fncls__262d; tmp2 = fncls__262d } else { tmp2 = fncls__262 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }; return /*line :1324:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__10), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, f__0, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_303)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_363.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :1323:1
func A_arbace_repr_go_print_code_while_stmt_fn__74000584_A_New_O(p0 any) *A_arbace_repr_go_print_code_while_stmt_fn__74000584_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_while_stmt_fn__74000584_A{}; t.Ctor_O(p0); return t }
//line :1323:1
func (t *A_arbace_repr_go_print_code_while_stmt_fn__74000584_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :1323:1
func (t *A_arbace_repr_go_print_code_while_stmt_fn__74000584_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_c; t.F_c = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O_O__O(tmp3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_repr_go_print_code_range_stmt_A_New() *A_arbace_repr_go_print_code_range_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_range_stmt_A{}; t.Ctor(); return t }
//line :1326:1
func (t *A_arbace_repr_go_print_code_range_stmt_A) Ctor() {}
//line :1326:1
func (t *A_arbace_repr_go_print_code_range_stmt_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000588__2 any = f__0; var seq__74000589__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000588__2); var first__74000590__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000589__3); var seq__74000589__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000589__3); var ___6 any = first__74000590__4; var first__74000590__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000589__5); var seq__74000589__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000589__5); var v__9 any = first__74000590__7; var body__10 any = seq__74000589__8; var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_364; var assign_QMARK___11 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); _ = ___6; if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(v__9)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_180, f__0) };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_128, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_362)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O();
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_233, jrt.Boolean_TRUE.Ref())); var tmp2 any = A_arbace_repr_go_print_code_range_stmt_fn__74000591_A_New_O_O_O(f__0, assign_QMARK___11, v__9); var tmp3 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_repr_go_print_code_range_stmt_fn__74000591_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_repr_go_print_code_range_stmt_fn__74000591_A_fn_class = fncls__264d; tmp3 = fncls__264d } else { tmp3 = fncls__264 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); return /*line :1337:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__10), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, f__0, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_303)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_363.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :1331:1
func A_arbace_repr_go_print_code_range_stmt_fn__74000591_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_range_stmt_fn__74000591_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_range_stmt_fn__74000591_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1331:1
func (t *A_arbace_repr_go_print_code_range_stmt_fn__74000591_A) Ctor_O_O_O(c__f, c__assign_QMARK_, c__v any) { t.F_f = c__f; t.F_assign_QMARK_ = c__assign_QMARK_; t.F_v = c__v }
//line :1331:1
func (t *A_arbace_repr_go_print_code_range_stmt_fn__74000591_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var x__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(t.F_v); var vars__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_145.GetRawRoot__O()).Invoke_O__O(t.F_v)

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vars__4)) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any = A_arbace_repr_go_print_code_A_const_188; var tmp6 any = A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A_New(); var tmp7 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A_fn_class = fncls__263d; tmp7 = fncls__263d } else { tmp7 = fncls__263 }; tmp2.Invoke_O_O_O_O__O(tmp4, tmp5, vars__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp9 *jrt.String; var tmp10 any; var t__2 any = t.F_assign_QMARK_; t.F_assign_QMARK_ = nil; tmp10 = t__2; if jrt.J2g_Truth(tmp10) { tmp9 = Lit_1 } else { tmp9 = Lit_15 }; tmp8.Invoke_O_O__O(tmp9.Ref(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t.F_f, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_f; t.F_f = nil; tmp13 = t__3; tmp11.Invoke_O_O__O(Lit_163, tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_go_print_code_A_const_365)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(x__3, A_arbace_repr_go_print_code_A_const_130) }; return nil }(); /*line :1331:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp14 != nil { panic(tmp14) }; return tmp1 }


func A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A_New() *A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A{}; t.Ctor(); return t }
//line :1334:1
func (t *A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A) Ctor() {}
//line :1334:1
func (t *A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A) Invoke_O_O__O(self, p1__74000587_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(p1__74000587_SHARP___1, A_arbace_repr_go_print_code_A_const_130) }






func A_arbace_repr_go_print_code_print_stmt_A_New() *A_arbace_repr_go_print_code_print_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_stmt_A{}; t.Ctor(); return t }
//line :1341:1
func (t *A_arbace_repr_go_print_code_print_stmt_A) Ctor() {}
//line :1341:1
func (t *A_arbace_repr_go_print_code_print_stmt_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); var G__74000597__3_ any = o__2; switch



	lang.Util_Hash_O__I_NoInit(G__74000597__3_) >> 3 & 255 { case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_162) {







		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_162, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318))
//line :1345:1
		var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)







		if jrt.J2g_Truth(temp__1927000414__auto____4) { var l__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(l__5), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_368)) } else { return nil } }
//line :1345:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_163) {


















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_366.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_164) {









		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_164, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_368)) }
//line :1345:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_126) {



















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(f__0), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :1345:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_165) {










		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_165, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)) }
//line :1345:1
	case 102: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_166) {

















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_369.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 103: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_141) {












		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_370.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 110: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_167) {


		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_167, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_371)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_130) }
//line :1345:1
	case 128: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_168) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 139: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_169) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 140: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_170) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 145: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_20) {











		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_338.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_code_A_const_116, f__0, A_arbace_repr_go_print_code_A_const_117, A_arbace_repr_go_print_code_A_const_130)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_363.GetRawRoot__O()).Invoke_O__O(f__0))) }
//line :1345:1
	case 148: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_171) {








		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_171, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318))
//line :1345:1
		var temp__1927000414__auto____4_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0)








		if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var l__5_2 any = temp__1927000414__auto____4_2; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(l__5_2), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_368)) } else { return nil } }
//line :1345:1
	case 153: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_128) {
















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_372.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 157: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_62) {

		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_62, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_374)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__0), A_arbace_repr_go_print_code_A_const_130) }
//line :1345:1
	case 159: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_172) {















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_373.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 163: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_140) {












		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_370.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 164: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_173) {














		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_375.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 166: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_174) {



		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_174, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_282))
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0))) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_310.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_130; var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0); var tmp4 any = A_arbace_repr_go_print_code_print_stmt_fn__74000598_A_New(); var tmp5 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_repr_go_print_code_print_stmt_fn__74000598_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_repr_go_print_code_print_stmt_fn__74000598_A_fn_class = fncls__266d; tmp5 = fncls__266d } else { tmp5 = fncls__266 }; return tmp1.Invoke_O_O_O_O__O(f__0, tmp2, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :1350:1
				return nil } }
//line :1345:1
	case 222: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_146) {




















		var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_164; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_376.GetRawRoot__O()).Invoke_O_O_O__O(f__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())), jrt.Boolean_FALSE.Ref()) }
//line :1345:1
	case 228: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_137) {












		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_370.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 230: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_176) {













		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_377.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 244: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_177) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	case 245: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_178) {



















		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(f__0), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :1345:1
	case 255: if lang.Util_Equiv_O_O__Z_NoInit(G__74000597__3_, Lit_179) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1345:1
	default:}; return /*line :1367:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_323.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1352:1
func A_arbace_repr_go_print_code_print_stmt_fn__74000598_A_New() *A_arbace_repr_go_print_code_print_stmt_fn__74000598_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_print_stmt_fn__74000598_A{}; t.Ctor(); return t }
//line :1352:1
func (t *A_arbace_repr_go_print_code_print_stmt_fn__74000598_A) Ctor() {}
//line :1352:1
func (t *A_arbace_repr_go_print_code_print_stmt_fn__74000598_A) Invoke_O_O__O(self, p1__74000596_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(p1__74000596_SHARP___1, A_arbace_repr_go_print_code_A_const_130) }


















func A_arbace_repr_go_print_code_flatten_stmts_A_New() *A_arbace_repr_go_print_code_flatten_stmts_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_flatten_stmts_A{}; t.Ctor(); return t }
//line :1371:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_A) Ctor() {}
//line :1371:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_A) Invoke_O_O_O_O__O(self, forms__0, parent__1, offset__2 any) any { var forms__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(forms__0); var n__5 int32 = lang.RT_Count_O__I_NoInit(forms__4); var brk__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_83.GetRawRoot__O()).Invoke_O__O(parent__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_23.GetRawRoot__O()); var tmp2 any = lang.PersistentVector_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_378.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A_New_O_I_O_O(parent__1, n__5, offset__2, brk__6); var tmp5 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A_fn_class; if










	fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A_fn_class = fncls__275d; tmp5 = fncls__275d } else { tmp5 = fncls__275 }; return /*line :1380:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__5).Ref()), forms__4)) }

func A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1382:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A) Ctor_O_I_O_O(c__parent any, c__n int32, c__offset, c__brk any) { t.F_parent = c__parent; t.F_n = c__n; t.F_offset = c__offset; t.F_brk = c__brk }
//line :1382:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A) Invoke_O_O_O__O(self, i__1, f__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__2)
	if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_379); var and__1927000168__auto____4 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :1383:1
	if jrt.J2g_Truth(tmp1) { var vec__74000602__3 any = f__2; var seq__74000603__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000602__3); var first__74000604__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000603__4); var seq__74000603__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000603__4); var ___7 any = first__74000604__5; var first__74000604__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000603__6); var seq__74000603__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000603__6); var bv__10 any = first__74000604__8; var body__11 any = seq__74000603__9; var ___12 any; _ = ___7; _ = ___12


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(bv__10)) { ___12 = nil } else { ___12 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_123, f__2) }
//line :1383:1
		var pairs__13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_334.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_303, bv__10); var items__14 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A_New_O(f__2); var tmp5 *jrt.Class
		var fncls__269 /*line :1383:1*/*jrt.Class = A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A_fn_class





		if fncls__269 == nil { var fncls__269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A_fn_class = fncls__269d; tmp5 = fncls__269d } else { tmp5 = fncls__269 }
//line :1388:1
		items__14 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), pairs__13)








		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_337.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(bv__10)).Ref())) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_125, f__2) }
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_182.GetRawRoot__O()).Invoke_O_O__O(items__14, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_383.GetRawRoot__O()).Invoke_O_O_O__O(body__11, f__2, A_arbace_repr_go_print_code_A_const_303)) } else {
//line :1383:1
			if A_arbace_repr_go_print_code_A_const_42 != nil { var tmp6 any = A_arbace_repr_go_print_code_A_const_22; var tmp7 any = A_arbace_repr_go_print_code_A_const_381; var tmp8 any















				if jrt.J2g_Truth(t.F_parent) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_84.GetRawRoot__O()); var tmp10 any = t.F_parent; var tmp11 jrt.Number_I; var na_270 any = t.F_offset; var na_271 any = i__1; var tmp12 bool; var tmp13 bool; tmp13 = jrt.Long_InstanceOf(na_270); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_271) }; tmp12 = tmp13; if tmp12 { var n0_272 int64 = jrt.NN(jrt.Long_Cast(na_270)).LongValue__J(); var n1_273 int64 = jrt.NN(jrt.Long_Cast(na_271)).LongValue__J(); var nr_274 int64 = n0_272 + n1_273; if (n0_272^nr_274)&(n1_273^nr_274) >= 0 { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_274)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_270, na_271) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_270); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_271) }; tmp14 = tmp15; if tmp14 { var n0_272_2 float64 = jrt.NN(jrt.Double_Cast(na_270)).DoubleValue__D(); var n1_273_2 float64 = jrt.NN(jrt.Double_Cast(na_271)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_272_2 + n1_273_2)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_270, na_271) } }; tmp8 = tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, f__2, t.F_brk) } else { tmp8 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(f__2) }
//line :1383:1
				return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, f__2, tmp7, tmp8))) } else { return nil
				}
		}
}


func A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A_New_O(p0 any) *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A{}; t.Ctor_O(p0); return t }
//line :1389:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1389:1
func (t *A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A) Invoke_O_O_O__O(self, j__1, p__74000605__2 any) any { var vec__74000607__3 any = p__74000605__2; var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000607__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000607__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tl__6 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(t__4); if
																	jrt.J2g_Truth(or__1927000174__auto____6) { tl__6 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 bool; var na_267 any = j__1
																		if jrt.Long_InstanceOf(na_267) { var n0_268 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); tmp1 = n0_268 == 0 } else { if jrt.Double_InstanceOf(na_267) { var n0_268_2 float64 = jrt.NN(jrt.Double_Cast(na_267)).DoubleValue__D(); tmp1 = n0_268_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_267) } }; if tmp1 { or__1927000174__auto____7 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(t.F_f) } else { or__1927000174__auto____7 = nil }
//line :1390:1
		if jrt.J2g_Truth(or__1927000174__auto____7) { tl__6 = or__1927000174__auto____7 } else {

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(x__5)) { tl__6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(x__5) } else { tl__6 = nil } } }; if
	lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t.F_f), Lit_126) { var tmp2 any = A_arbace_repr_go_print_code_A_const_380; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Tuple_Create_O_O__IPersistentVector(t__4, x__5), A_arbace_repr_go_print_code_A_const_381, tl__6)) } else { var tmp3 any = A_arbace_repr_go_print_code_A_const_382; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Tuple_Create_O_O__IPersistentVector(t__4, x__5), A_arbace_repr_go_print_code_A_const_381, tl__6)) } }








func A_arbace_repr_go_print_code_item_t_A_New() *A_arbace_repr_go_print_code_item_t_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_item_t_A{}; t.Ctor(); return t }
//line :1402:1
func (t *A_arbace_repr_go_print_code_item_t_A) Ctor() {}
//line :1402:1
func (t *A_arbace_repr_go_print_code_item_t_A) Invoke_O_O__O(self, it__0 any) any { return A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(it__0) }

func A_arbace_repr_go_print_code_label_stmt_A_New() *A_arbace_repr_go_print_code_label_stmt_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_label_stmt_A{}; t.Ctor(); return t }
//line :1404:1
func (t *A_arbace_repr_go_print_code_label_stmt_A) Ctor() {}
//line :1404:1
func (t *A_arbace_repr_go_print_code_label_stmt_A) Invoke_O_O_O_O__O(self, f__0, indent__1, more_QMARK___2 any) any { var vec__74000614__4 any = f__0; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000614__4, lang.RT_IntCast_J__I_NoInit(0), nil); var l__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000614__4, lang.RT_IntCast_J__I_NoInit(1), nil); var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000614__4, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5;




	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(l__6), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_368)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_38, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_272)); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_327.GetRawRoot__O()).Invoke_O__O(s__7)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(s__7); var tmp3 any = jrt.Boolean_FALSE.Ref(); var tmp4 any; var tmp5 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(s__7)
		if jrt.J2g_Truth(and__1927000168__auto____8) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(s__7), Lit_146)).Ref() } else { tmp5 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp5) { var tmp6 jrt.Number_I; var na_276 any = indent__1; if jrt.Long_InstanceOf(na_276) { var n0_277 int64 = jrt.NN(jrt.Long_Cast(na_276)).LongValue__J(); if n0_277 == -9223372036854775808 { tmp6 = lang.Numbers_Dec_O__Number_NoInit(na_276) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_277 - 1)) } } else { if jrt.Double_InstanceOf(na_276) { var n0_277_2 float64 = jrt.NN(jrt.Double_Cast(na_276)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_277_2 - 1.0)) } else { tmp6 = lang.Numbers_Dec_O__Number_NoInit(na_276) } }; tmp4 = lang.Numbers_Max_J_O__O_NoInit(0, tmp6) } else { tmp4 = indent__1 }
//line :1411:1
		tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, nil, tmp4)

		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(indent__1)
		var tmp7 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(s__7)
		if jrt.J2g_Truth(and__1927000168__auto____8_2) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_384); tmp7 = tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(s__7)) } else { tmp7 = and__1927000168__auto____8_2 }
//line :1414:1
		if jrt.J2g_Truth(tmp7) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(s__7), lang.PersistentArrayMap_EMPTY.Ref()) } else {
//line :1414:1
				var tmp9 any; var and__1927000168__auto____8_3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(s__7)

				if jrt.J2g_Truth(and__1927000168__auto____8_3) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(s__7), Lit_146)).Ref() } else { tmp9 = and__1927000168__auto____8_3 }
//line :1414:1
				if jrt.J2g_Truth(tmp9) {

					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_376.GetRawRoot__O()).Invoke_O_O_O__O(s__7, indent__1, more_QMARK___2) } else {
//line :1414:1
						if A_arbace_repr_go_print_code_A_const_42 != nil {


							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(s__7) } } }
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O() } else {
//line :1410:1
			if jrt.J2g_Truth(more_QMARK___2) {








				var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp10.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36) } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()).Invoke_O__O(indent__1); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36) } } else {
//line :1410:1
					return nil } } }










func A_arbace_repr_go_print_code_bind_target_A_New() *A_arbace_repr_go_print_code_bind_target_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_bind_target_A{}; t.Ctor(); return t }
//line :1421:1
func (t *A_arbace_repr_go_print_code_bind_target_A) Ctor() {}
//line :1421:1
func (t *A_arbace_repr_go_print_code_bind_target_A) Invoke_O_O__O(self, it__0 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0)) }

func A_arbace_repr_go_print_code_const_bind_QMARK__A_New() *A_arbace_repr_go_print_code_const_bind_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_bind_QMARK__A{}; t.Ctor(); return t }
//line :1423:1
func (t *A_arbace_repr_go_print_code_const_bind_QMARK__A) Ctor() {}
//line :1423:1
func (t *A_arbace_repr_go_print_code_const_bind_QMARK__A) Invoke_O_O__O(self, it__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_385.GetRawRoot__O()).Invoke_O__O(it__0); if
												jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var ts__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_311.GetRawRoot__O()).Invoke_O__O(t__3); var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_312; var or__1927000174__auto____5 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__3))

		if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A_New(); var tmp4 *jrt.Class; var fncls__278 *jrt.Class = A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A_fn_class; if fncls__278 == nil { var fncls__278d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A_fn_class = fncls__278d; tmp4 = fncls__278d } else { tmp4 = fncls__278 }; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ts__4) } } else {
//line :1424:1
			return nil } }

func A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A_New() *A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A{}; t.Ctor(); return t }
//line :1426:1
func (t *A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A) Ctor() {}
//line :1426:1
func (t *A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A) Invoke_O_O__O(self, p1__74000619_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_312; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000619_SHARP___1)) }

func A_arbace_repr_go_print_code_group_consts_A_New() *A_arbace_repr_go_print_code_group_consts_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_consts_A{}; t.Ctor(); return t }
//line :1428:1
func (t *A_arbace_repr_go_print_code_group_consts_A) Ctor() {}
//line :1428:1
func (t *A_arbace_repr_go_print_code_group_consts_A) Invoke_O_O__O(self, items__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_142.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_group_consts_fn__74000623_A_New(); var tmp3 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_repr_go_print_code_group_consts_fn__74000623_A_fn_class; if fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_repr_go_print_code_group_consts_fn__74000623_A_fn_class = fncls__279d; tmp3 = fncls__279d } else { tmp3 = fncls__279 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.PersistentVector_EMPTY.Ref(), items__0) }
//line :1432:1
func A_arbace_repr_go_print_code_group_consts_fn__74000623_A_New() *A_arbace_repr_go_print_code_group_consts_fn__74000623_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_consts_fn__74000623_A{}; t.Ctor(); return t }
//line :1432:1
func (t *A_arbace_repr_go_print_code_group_consts_fn__74000623_A) Ctor() {}
//line :1432:1
func (t *A_arbace_repr_go_print_code_group_consts_fn__74000623_A) Invoke_O_O_O__O(self, acc__1, it__2 any) any { var prev__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_126.GetRawRoot__O()).Invoke_O__O(acc__1); var tmp1 any; var and__1927000168__auto____4 any = prev__3; if

	jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_386.GetRawRoot__O()).Invoke_O__O(it__2); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_14; var and__1927000168__auto____6 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_385.GetRawRoot__O()).Invoke_O__O(it__2))); if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 any = A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(prev__3)
		if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_386.GetRawRoot__O()).Invoke_O__O(prev__3) } } else {
//line :1434:1
			tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_145.GetRawRoot__O()).Invoke_O__O(acc__1); var tmp5 any; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(prev__3)) {
					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_32.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_code_A_const_387; tmp5 = tmp6.Invoke_O_O_O_O__O(prev__3, tmp7, A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O(), it__2) } else {
//line :1436:1
						var tmp8 any = A_arbace_repr_go_print_code_A_const_387; var tmp9 any = lang.Tuple_Create_O_O__IPersistentVector(prev__3, it__2); var tmp10 any = A_arbace_repr_go_print_code_A_const_381; tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(prev__3))) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {


							return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__1, it__2) } }


func A_arbace_repr_go_print_code_label_target_A_New() *A_arbace_repr_go_print_code_label_target_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_label_target_A{}; t.Ctor(); return t }
//line :1442:1
func (t *A_arbace_repr_go_print_code_label_target_A) Ctor() {}
//line :1442:1
func (t *A_arbace_repr_go_print_code_label_target_A) Invoke_O_O__O(self, it__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_385.GetRawRoot__O()).Invoke_O__O(it__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0)); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_385.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(it__0))) } } }

func A_arbace_repr_go_print_code_label_of_A_New() *A_arbace_repr_go_print_code_label_of_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_label_of_A{}; t.Ctor(); return t }
//line :1447:1
func (t *A_arbace_repr_go_print_code_label_of_A) Ctor() {}
//line :1447:1
func (t *A_arbace_repr_go_print_code_label_of_A) Invoke_O_O__O(self, it__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_388.GetRawRoot__O()).Invoke_O__O(it__0); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_389
		return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__3)) } else {
//line :1450:1
			return nil } }


func A_arbace_repr_go_print_code_const_spec_A_New() *A_arbace_repr_go_print_code_const_spec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_spec_A{}; t.Ctor(); return t }
//line :1453:1
func (t *A_arbace_repr_go_print_code_const_spec_A) Ctor() {}
//line :1453:1
func (t *A_arbace_repr_go_print_code_const_spec_A) Invoke_O_O_O__O(self, p__74000629__0, keep_type__1 any) any { var vec__74000630__3 any = p__74000629__0; var target__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000630__3, lang.RT_IntCast_J__I_NoInit(0), nil); var init__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000630__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ts__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_311.GetRawRoot__O()).Invoke_O__O(target__4); var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_390; var implicit_QMARK___7 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(target__4)); var typ__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_const_spec_fn__74000633_A_New(); var tmp4 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_repr_go_print_code_const_spec_fn__74000633_A_fn_class; if




	fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_go_print_code_const_spec_fn__74000633_A_fn_class = fncls__280d; tmp4 = fncls__280d } else { tmp4 = fncls__280 }; typ__8 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ts__6);
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(ts__6); if
	jrt.J2g_Truth(implicit_QMARK___7) { return nil } else {
		var tmp5 any; var or__1927000174__auto____9 any = typ__8; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp5 = or__1927000174__auto____9 } else { tmp5 = keep_type__1 }; if jrt.J2g_Truth(tmp5) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O()).Invoke__O() }
		if jrt.J2g_Truth(typ__8) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(typ__8) }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(init__5, A_arbace_repr_go_print_code_A_const_130) } }
//line :1458:1
func A_arbace_repr_go_print_code_const_spec_fn__74000633_A_New() *A_arbace_repr_go_print_code_const_spec_fn__74000633_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_spec_fn__74000633_A{}; t.Ctor(); return t }
//line :1458:1
func (t *A_arbace_repr_go_print_code_const_spec_fn__74000633_A) Ctor() {}
//line :1458:1
func (t *A_arbace_repr_go_print_code_const_spec_fn__74000633_A) Invoke_O_O__O(self, p1__74000628_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000628_SHARP___1), A_arbace_repr_go_print_code_A_const_31)) { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000628_SHARP___1)) } else { return nil } }








func A_arbace_repr_go_print_code_const_group_A_New() *A_arbace_repr_go_print_code_const_group_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_group_A{}; t.Ctor(); return t }
//line :1467:1
func (t *A_arbace_repr_go_print_code_const_group_A) Ctor() {}
//line :1467:1
func (t *A_arbace_repr_go_print_code_const_group_A) Invoke_O_O_O__O(self, its__0, indent__1 any) any { var specs__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_380, its__0); var keep__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_391.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_const_group_fn__74000637_A_New(); var tmp4 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_repr_go_print_code_const_group_fn__74000637_A_fn_class; if



	fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_print_code_const_group_fn__74000637_A_fn_class = fncls__281d; tmp4 = fncls__281d } else { tmp4 = fncls__281 }; keep__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), specs__3)); var nxts__5 any = /*line :1467:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_122.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_381, its__0)); var t0__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(specs__3));






	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_12, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t0__6, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t0__6, A_arbace_repr_go_print_code_A_const_257));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(indent__1); var n__1927000701__auto____7 int64 = /*line :1467:1*/lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(its__0)); var j__8 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z_NoInit(j__8, n__1927000701__auto____7) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_code_A_const_86; var tmp8 any; var or__1927000174__auto____9 any = lang.RT_Nth_O_I__O_NoInit(nxts__5, lang.RT_IntCast_J__I_NoInit(j__8)); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp8 = or__1927000174__auto____9 } else { tmp8 = A_arbace_repr_go_print_code_A_const_86.Get__O() }; tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8)); var tmp9 any = A_arbace_repr_go_print_code_const_group_fn__74000642_A_New_O_J_O_O_O(keep__4, j__8, its__0, indent__1, specs__3); var tmp10 *jrt.Class; var fncls__284 *jrt.Class = A_arbace_repr_go_print_code_const_group_fn__74000642_A_fn_class; if fncls__284 == nil { var fncls__284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_print_code_const_group_fn__74000642_A_fn_class = fncls__284d; tmp10 = fncls__284d } else { tmp10 = fncls__284 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :1476:1
			j__8 = lang.Numbers_Unchecked_inc_J__J_NoInit(j__8); continue L1 }
//line :1467:1
		break L1 };












	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O(); var tmp11 /*line :1481:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp11.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()).Invoke_O_O_O_O__O(nil, jrt.Boolean_TRUE.Ref(), jrt.Boolean_TRUE.Ref(), indent__1) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O__O(indent__1, jrt.Boolean_TRUE.Ref()) }; return /*line :1484:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(t0__6, A_arbace_repr_go_print_code_A_const_258)) }
//line :1471:1
func A_arbace_repr_go_print_code_const_group_fn__74000637_A_New() *A_arbace_repr_go_print_code_const_group_fn__74000637_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_group_fn__74000637_A{}; t.Ctor(); return t }
//line :1471:1
func (t *A_arbace_repr_go_print_code_const_group_fn__74000637_A) Ctor() {}
//line :1471:1
func (t *A_arbace_repr_go_print_code_const_group_fn__74000637_A) Invoke_O_O__O(self, p__74000636__1 any) any { var vec__74000638__2 any = p__74000636__1; var t__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000638__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000638__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_390; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__3))) { tmp1 = A_arbace_repr_go_print_code_A_const_392 } else { tmp1 = x__4 }; return lang.Tuple_Create_O_O__IPersistentVector(t__3, tmp1) }





func A_arbace_repr_go_print_code_const_group_fn__74000642_A_New_O_J_O_O_O(p0 any, p1 int64, p2, p3, p4 any) *A_arbace_repr_go_print_code_const_group_fn__74000642_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_group_fn__74000642_A{}; t.Ctor_O_J_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1477:1
func (t *A_arbace_repr_go_print_code_const_group_fn__74000642_A) Ctor_O_J_O_O_O(c__keep any, c__j int64, c__its, c__indent, c__specs any) { t.F_keep = c__keep; t.F_j = c__j; t.F_its = c__its; t.F_indent = c__indent; t.F_specs = c__specs }
//line :1477:1
func (t *A_arbace_repr_go_print_code_const_group_fn__74000642_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_381; var tmp5 any; var t_ any = t.F_its; t.F_its = nil; tmp5 = t_; or__1927000174__auto____3 = tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(t.F_j))); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp6 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { tmp3 = nil } else { tmp3 = A_arbace_repr_go_print_code_A_const_82 } }; var tmp7 any = tmp3; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_j)).Ref(); var tmp9 jrt.Number_I; var na_282 any; var t__2 any = t.F_indent; t.F_indent = nil; na_282 = t__2; if jrt.Long_InstanceOf(na_282) { var n0_283 int64 = jrt.NN(jrt.Long_Cast(na_282)).LongValue__J(); if n0_283 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_282) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_283 + 1)) } } else { if jrt.Double_InstanceOf(na_282) { var n0_283_2 float64 = jrt.NN(jrt.Double_Cast(na_282)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_283_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_282) } }; tmp2.Invoke_O_O_O_O__O(tmp7, tmp8, Lit_36, tmp9)
													var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_393.GetRawRoot__O()); var tmp11 any; var t__3 any = t.F_specs; t.F_specs = nil; tmp11 = t__3; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(tmp11, lang.RT_IntCast_J__I_NoInit(t.F_j)); var tmp13 any; var t__4 any = t.F_keep; t.F_keep = nil; tmp13 = t__4; tmp1 = tmp10.Invoke_O_O__O(tmp12, lang.RT_Nth_O_I__O_NoInit(tmp13, lang.RT_IntCast_J__I_NoInit(t.F_j))) }
//line :1477:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp14 != nil { panic(tmp14) }; return tmp1 }








func A_arbace_repr_go_print_code_group_target_A_New() *A_arbace_repr_go_print_code_group_target_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_target_A{}; t.Ctor(); return t }
//line :1486:1
func (t *A_arbace_repr_go_print_code_group_target_A) Ctor() {}
//line :1486:1
func (t *A_arbace_repr_go_print_code_group_target_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 bool; var na_285 int64 = lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(t__0)); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_286 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_286) { var n0_287 int64 = na_285; var n1_288 int64 = jrt.NN(jrt.Long_Cast(na_286)).LongValue__J(); tmp2 = n0_287 > n1_288 } else { tmp2 = lang.Numbers_Gt_J_O__Z_NoInit(na_285, na_286) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(t__0))).Ref() } else { return t__0
	}
}




func A_arbace_repr_go_print_code_item_group_pos_A_New() *A_arbace_repr_go_print_code_item_group_pos_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_item_group_pos_A{}; t.Ctor(); return t }
//line :1496:1
func (t *A_arbace_repr_go_print_code_item_group_pos_A) Ctor() {}
//line :1496:1
func (t *A_arbace_repr_go_print_code_item_group_pos_A) Invoke_O_O__O(self, it__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
		if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0)) {
			var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; return tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0)))) } else {
//line :1501:1
				if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0)) {

					var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_26; return tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0)))) } else {
//line :1501:1
						return nil } } } else {
//line :1500:1
							return nil
						}
}


func A_arbace_repr_go_print_code_item_start_A_New() *A_arbace_repr_go_print_code_item_start_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_item_start_A{}; t.Ctor(); return t }
//line :1505:1
func (t *A_arbace_repr_go_print_code_item_start_A) Ctor() {}
//line :1505:1
func (t *A_arbace_repr_go_print_code_item_start_A) Invoke_O_O__O(self, it__0 any) any { var t__2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0)); if


	jrt.J2g_Truth(or__1927000174__auto____2) { t__2 = or__1927000174__auto____2 } else { t__2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0)) }; var t__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :1505:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__2); if



	jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__2), Lit_95)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { t__3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(t__2) } else { t__3 = t__2 }; var tmp2 /*line :1510:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_26; return lang.RT_Get_O_O__O_NoInit(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__3)), A_arbace_repr_go_print_code_A_const_99) }

func A_arbace_repr_go_print_code_full_in_group_QMARK__A_New() *A_arbace_repr_go_print_code_full_in_group_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_full_in_group_QMARK__A{}; t.Ctor(); return t }
//line :1512:1
func (t *A_arbace_repr_go_print_code_full_in_group_QMARK__A) Ctor() {}
//line :1512:1
func (t *A_arbace_repr_go_print_code_full_in_group_QMARK__A) Invoke_O_O__O(self, it__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_repr_go_print_code_A_const_394.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any = A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_repr_go_print_code_full_group_open_BANG__A_New() *A_arbace_repr_go_print_code_full_group_open_BANG__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_full_group_open_BANG__A{}; t.Ctor(); return t }
//line :1515:1
func (t *A_arbace_repr_go_print_code_full_group_open_BANG__A) Ctor() {}
//line :1515:1
func (t *A_arbace_repr_go_print_code_full_group_open_BANG__A) Invoke_O_O__O(self, it__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_repr_go_print_code_A_const_394.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any = A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__0); if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { and__1927000168__auto____3 = A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(it__0)) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var p__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_395.GetRawRoot__O()).Invoke_O__O(it__0); var tmp2 any; var and__1927000168__auto____3_2 any = A_arbace_repr_go_print_code_A_const_257.Invoke_O__O(p__2)

		if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O())) } else { tmp2 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp2) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()); var tmp4 *jrt.String; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__0)) { tmp4 = Lit_129 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_386.GetRawRoot__O()).Invoke_O__O(it__0)) { tmp4 = Lit_12 } else { if A_arbace_repr_go_print_code_A_const_42 != nil { tmp4 = Lit_13 } else { tmp4 = nil } } }; tmp3.Invoke_O_O__O(tmp4.Ref(), A_arbace_repr_go_print_code_A_const_318.Invoke_O__O(p__2))
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, A_arbace_repr_go_print_code_A_const_257.Invoke_O__O(p__2))
			var tmp5 any = A_arbace_repr_go_print_code_A_const_118; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_396.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, A_arbace_repr_go_print_code_A_const_258.Invoke_O__O(p__2)))) } else {
//line :1521:1
				return nil } } else {
//line :1519:1
					return nil
				}
}




func A_arbace_repr_go_print_code_full_group_close_BANG__A_New() *A_arbace_repr_go_print_code_full_group_close_BANG__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_full_group_close_BANG__A{}; t.Ctor(); return t }
//line :1526:1
func (t *A_arbace_repr_go_print_code_full_group_close_BANG__A) Ctor() {}
//line :1526:1
func (t *A_arbace_repr_go_print_code_full_group_close_BANG__A) Invoke_O_O_O__O(self, items__0, i__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any = A_arbace_repr_go_print_code_A_const_394.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O()) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_118; var end__3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O())); var nx__4 any; var tmp3 jrt.Number_I
		var na_290 any = i__1
		if jrt.Long_InstanceOf(na_290) { var n0_291 int64 = jrt.NN(jrt.Long_Cast(na_290)).LongValue__J(); if n0_291 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_290) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_291 + 1)) } } else { if jrt.Double_InstanceOf(na_290) { var n0_291_2 float64 = jrt.NN(jrt.Double_Cast(na_290)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_291_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_290) } }; nx__4 = lang.RT_Get_O_O__O_NoInit(items__0, tmp3)
//line :1529:1
		var st__5 any


		if jrt.J2g_Truth(nx__4) { st__5 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_397.GetRawRoot__O()).Invoke_O__O(nx__4) } else { st__5 = nil }
		var tmp4 any; var and__1927000168__auto____6 any = st__5; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = end__3; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(st__5, end__3)))).Ref() } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { return nil } else {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, end__3)
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_396.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_394.Get__O(), nil) } } else {
//line :1529:1
				return nil
			}
}





func A_arbace_repr_go_print_code_stmt_list_A_New() *A_arbace_repr_go_print_code_stmt_list_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_stmt_list_A{}; t.Ctor(); return t }
//line :1537:1
func (t *A_arbace_repr_go_print_code_stmt_list_A) Ctor() {}
//line :1537:1
func (t *A_arbace_repr_go_print_code_stmt_list_A) Invoke_O_O_O__O(self, forms__0, p__74000651__1 any) any { var map__74000652__3 any = p__74000651__1; var map__74000652__4 any; if lang.ISeq_InstanceOf(map__74000652__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(map__74000652__3)) { map__74000652__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_115.GetRawRoot__O()).Invoke_O__O(map__74000652__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(map__74000652__3)) { map__74000652__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(map__74000652__3) } else { map__74000652__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__74000652__4 = map__74000652__3 }; var opts__5 any = map__74000652__4; var indent__6 any = lang.RT_Get_O_O__O_NoInit(map__74000652__4, A_arbace_repr_go_print_code_A_const_163); var results_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__74000652__4, A_arbace_repr_go_print_code_A_const_283); var parent__8 any = lang.RT_Get_O_O__O_NoInit(map__74000652__4, A_arbace_repr_go_print_code_A_const_116); var offset__9 any = lang.RT_Get_O_O__O_NoInit(map__74000652__4, A_arbace_repr_go_print_code_A_const_117); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_A_const_394; var tmp4 any; var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_24; _ = opts__5; if




	jrt.J2g_Truth(tmp5.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { tmp4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_399.GetRawRoot__O()).Invoke_O__O(nil) } else { tmp4 = nil }; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4)); var tmp6 any; tmp12 := /*line :1537:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var items__12 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_398.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_383.GetRawRoot__O()); var tmp9 any
		var or__1927000174__auto____12 any = offset__9




		if jrt.J2g_Truth(or__1927000174__auto____12) { tmp9 = or__1927000174__auto____12 } else { tmp9 = A_arbace_repr_go_print_code_A_const_188 }; items__12 = tmp7.Invoke_O__O(tmp8.Invoke_O_O_O__O(forms__0, parent__8, tmp9))
//line :1537:1
		var n__13 int32 = lang.RT_Count_O__I_NoInit(items__12); var nxts__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_122.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_78.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_400.GetRawRoot__O(), items__12)); var n__1927000701__auto____15 int64 = lang.RT_LongCast_I__J_NoInit(n__13); var i__16 int64 = 0; L1: for {








			if lang.Numbers_Lt_J_J__Z_NoInit(i__16, n__1927000701__auto____15) { var it__17 any = lang.RT_Nth_O_I__O_NoInit(items__12, lang.RT_IntCast_J__I_NoInit(i__16)); var nxt__18 any; var or__1927000174__auto____18 any = lang.RT_Nth_O_I__O_NoInit(nxts__14, lang.RT_IntCast_J__I_NoInit(i__16))

				if jrt.J2g_Truth(or__1927000174__auto____18) { nxt__18 = or__1927000174__auto____18 } else { nxt__18 = A_arbace_repr_go_print_code_A_const_86.Get__O() }
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_86, nxt__18)); var tmp10 any = A_arbace_repr_go_print_code_stmt_list_fn__74000654_A_New_I_O_O_O_J_O(n__13, results_QMARK___7, indent__6, items__12, i__16, it__17); var tmp11 *jrt.Class; var fncls__295 *jrt.Class = A_arbace_repr_go_print_code_stmt_list_fn__74000654_A_fn_class; if fncls__295 == nil { var fncls__295d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_repr_go_print_code_stmt_list_fn__74000654_A_fn_class = fncls__295d; tmp11 = fncls__295d } else { tmp11 = fncls__295 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :1546:1
				i__16 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__16); continue L1 } else { tmp6 = nil }
//line :1537:1
			break L1 } }; return nil }();




	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :1537:1*/ tmp12 != nil { panic(tmp12) }; return tmp6 }











func A_arbace_repr_go_print_code_stmt_list_fn__74000654_A_New_I_O_O_O_J_O(p0 int32, p1, p2, p3 any, p4 int64, p5 any) *A_arbace_repr_go_print_code_stmt_list_fn__74000654_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_stmt_list_fn__74000654_A{}; t.Ctor_I_O_O_O_J_O(p0, p1, p2, p3, p4, p5); return t }
//line :1549:1
func (t *A_arbace_repr_go_print_code_stmt_list_fn__74000654_A) Ctor_I_O_O_O_J_O(c__n int32, c__results_QMARK_, c__indent, c__items any, c__i int64, c__it any) { t.F_n = c__n; t.F_results_QMARK_ = c__results_QMARK_; t.F_indent = c__indent; t.F_items = c__items; t.F_i = c__i; t.F_it = c__it }
//line :1549:1
func (t *A_arbace_repr_go_print_code_stmt_list_fn__74000654_A) Invoke_O__O(self any) any { var tmp1 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var f__3 any = A_arbace_repr_go_print_code_A_const_22.Invoke_O__O(t.F_it); var label_QMARK___4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__3)

	if jrt.J2g_Truth(and__1927000168__auto____4) { label_QMARK___4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__3), Lit_146)).Ref() } else { label_QMARK___4 = and__1927000168__auto____4 }
//line :1549:1
	var directive_QMARK___5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(f__3)


	if jrt.J2g_Truth(and__1927000168__auto____5) { directive_QMARK___5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__3), Lit_189)).Ref() } else { directive_QMARK___5 = and__1927000168__auto____5 }
//line :1549:1
	var decl_label__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_401.GetRawRoot__O()).Invoke_O__O(t.F_it)




	if jrt.J2g_Truth(directive_QMARK___5) {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_381; var tmp4 any; var t_ any = t.F_it; t.F_it = nil; tmp4 = t_; tmp2.Invoke_O_O_O_O__O(tmp3.Invoke_O__O(tmp4), jrt.Boolean_FALSE.Ref(), Lit_36, t.F_indent)
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_175.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(f__3); var tmp7 any; var t__2 any = t.F_indent; t.F_indent = nil; tmp7 = t__2; tmp1 = tmp5.Invoke_O_O__O(tmp6, tmp7) } else {
//line :1554:1
			if A_arbace_repr_go_print_code_A_const_42 != nil {





				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp9 any; if jrt.J2g_Truth(decl_label__6) { var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_407; var or__1927000174__auto____7 any = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_388.GetRawRoot__O()).Invoke_O__O(t.F_it)))
					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp9 = or__1927000174__auto____7 } else {
						tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_408.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(t.F_it)) } } else {
//line :1560:1
							if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(t.F_it)) {


								tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_408.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(t.F_it)) } else {
//line :1560:1
									if A_arbace_repr_go_print_code_A_const_42 != nil {



										tmp9 = A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(t.F_it) } else {
//line :1560:1
											tmp9 = nil } } }; var tmp11 any = tmp9; var tmp12 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_i)).Ref(); var tmp13 any; var tmp14 any
				var or__1927000174__auto____7_2 any = label_QMARK___4



				if jrt.J2g_Truth(or__1927000174__auto____7_2) { tmp14 = or__1927000174__auto____7_2 } else { tmp14 = decl_label__6 }; if jrt.J2g_Truth(tmp14) { var tmp15 jrt.Number_I; var na_293 any = t.F_indent; if jrt.Long_InstanceOf(na_293) { var n0_294 int64 = jrt.NN(jrt.Long_Cast(na_293)).LongValue__J(); if n0_294 == -9223372036854775808 { tmp15 = lang.Numbers_Dec_O__Number_NoInit(na_293) } else { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_294 - 1)) } } else { if jrt.Double_InstanceOf(na_293) { var n0_294_2 float64 = jrt.NN(jrt.Double_Cast(na_293)).DoubleValue__D(); tmp15 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_294_2 - 1.0)) } else { tmp15 = lang.Numbers_Dec_O__Number_NoInit(na_293) } }; tmp13 = lang.Numbers_Max_J_O__O_NoInit(0, tmp15) } else { tmp13 = t.F_indent }
//line :1560:1
				tmp8.Invoke_O_O_O_O__O(tmp11, tmp12, Lit_36, tmp13)





				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(t.F_indent)
				if jrt.J2g_Truth(decl_label__6) {

					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(decl_label__6), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_388.GetRawRoot__O()).Invoke_O__O(t.F_it), A_arbace_repr_go_print_code_A_const_368))
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_38, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_388.GetRawRoot__O()).Invoke_O__O(t.F_it), A_arbace_repr_go_print_code_A_const_409))
					var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp17 any; if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(t.F_it)) { tmp17 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_408.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(t.F_it)) } else { tmp17 = A_arbace_repr_go_print_code_A_const_381.Invoke_O__O(t.F_it) }; tmp16.Invoke_O_O_O_O__O(tmp17, jrt.Boolean_FALSE.Ref(), nil, t.F_indent) }
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_402.GetRawRoot__O()).Invoke_O__O(t.F_it)
				var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_print_code_A_const_319; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_410.GetRawRoot__O()).Invoke_O__O(t.F_it))); var tmp20 any = A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A_New_I_O_O_O_O_J_O(t.F_n, f__3, t.F_results_QMARK_, t.F_indent, label_QMARK___4, t.F_i, t.F_it); var tmp21 *jrt.Class; var fncls__292 *jrt.Class = A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A_fn_class; if fncls__292 == nil { var fncls__292d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A_fn_class = fncls__292d; tmp21 = fncls__292d } else { tmp21 = fncls__292 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O()








				var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_406.GetRawRoot__O()); var tmp23 any; var t__3 any = t.F_items; t.F_items = nil; tmp23 = t__3; tmp22.Invoke_O_O__O(tmp23, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref())
				tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O() } else {
//line :1554:1
					tmp1 = nil } } }; return nil }(); /*line :1549:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp24 != nil { panic(tmp24) }; return tmp1 }























func A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A_New_I_O_O_O_O_J_O(p0 int32, p1, p2, p3, p4 any, p5 int64, p6 any) *A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A{}; t.Ctor_I_O_O_O_O_J_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :1573:1
func (t *A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A) Ctor_I_O_O_O_O_J_O(c__n int32, c__f, c__results_QMARK_, c__indent, c__label_QMARK_ any, c__i int64, c__it any) { t.F_n = c__n; t.F_f = c__f; t.F_results_QMARK_ = c__results_QMARK_; t.F_indent = c__indent; t.F_label_QMARK_ = c__label_QMARK_; t.F_i = c__i; t.F_it = c__it }
//line :1573:1
func (t *A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A) Invoke_O__O(self any) any { var tmp1 any; tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(t.F_it)) {
														var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_403.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_387; var tmp4 any; var t_ any = t.F_it; t.F_it = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_indent; t.F_indent = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) } else {
//line :1574:1
			if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(t.F_it)) {

				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_46.GetRawRoot__O()); var tmp8 any = A_arbace_repr_go_print_code_A_const_324.GetRawRoot__O(); var tmp9 *lang.Keyword = A_arbace_repr_go_print_code_A_const_380; var tmp10 any; var t__3 any = t.F_it; t.F_it = nil; tmp10 = t__3; tmp1 = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10)) } else {
//line :1574:1
					if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(t.F_it)) {


						var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_46.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_print_code_A_const_405.GetRawRoot__O(); var tmp13 *lang.Keyword = A_arbace_repr_go_print_code_A_const_382; var tmp14 any; var t__4 any = t.F_it; t.F_it = nil; tmp14 = t__4; tmp1 = tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O__O(tmp14)) } else {
//line :1574:1
							var tmp15 any; var t__5 any = t.F_label_QMARK_; t.F_label_QMARK_ = nil; tmp15 = t__5; if jrt.J2g_Truth(tmp15) {



								var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_376.GetRawRoot__O()); var tmp17 any; var t__6 any = t.F_f; t.F_f = nil; tmp17 = t__6; var tmp18 any = tmp17; var tmp19 any; var t__7 any = t.F_indent; t.F_indent = nil; tmp19 = t__7; var tmp20 int64 = t.F_i; tmp1 = tmp16.Invoke_O_O_O__O(tmp18, tmp19, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Lt_J_J__Z_NoInit(tmp20, lang.Numbers_Dec_J__J_NoInit(int64(t.F_n)))).Ref()) } else {
//line :1574:1
									var tmp21 any; var and__1927000168__auto____3 any; var t__8 any = t.F_results_QMARK_; t.F_results_QMARK_ = nil; and__1927000168__auto____3 = t__8




									if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp22 int64 = t.F_i; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(tmp22, lang.Numbers_Dec_J__J_NoInit(int64(t.F_n))); if and__1927000168__auto____4 { tmp21 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_404.GetRawRoot__O()).Invoke_O__O(t.F_f) } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp21 = and__1927000168__auto____3 }
//line :1574:1
									if jrt.J2g_Truth(tmp21) {





										lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_174, A_arbace_repr_go_print_code_A_const_281.Get__O()); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()); var tmp24 any; var t__9 any = t.F_f; t.F_f = nil; tmp24 = t__9; tmp1 = tmp23.Invoke_O_O__O(tmp24, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1574:1
											if A_arbace_repr_go_print_code_A_const_42 != nil {






												var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_332.GetRawRoot__O()); var tmp26 any; var t__10 any = t.F_f; t.F_f = nil; tmp26 = t__10; tmp1 = tmp25.Invoke_O__O(tmp26) } else {
//line :1574:1
													tmp1 = nil } } } } } }
//line :1573:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp27 != nil { panic(tmp27) }; return tmp1 }











func A_arbace_repr_go_print_code_block_body_A_New() *A_arbace_repr_go_print_code_block_body_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_block_body_A{}; t.Ctor(); return t }
//line :1585:1
func (t *A_arbace_repr_go_print_code_block_body_A) Ctor() {}
//line :1585:1
func (t *A_arbace_repr_go_print_code_block_body_A) Invoke_O_O_O__O(self, forms__0, p__74000660__1 any) any { var map__74000661__3 any = p__74000660__1; var map__74000661__4 any; if lang.ISeq_InstanceOf(map__74000661__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(map__74000661__3)) { map__74000661__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_115.GetRawRoot__O()).Invoke_O__O(map__74000661__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(map__74000661__3)) { map__74000661__4 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(map__74000661__3) } else { map__74000661__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__74000661__4 = map__74000661__3 }; var opts__5 any = map__74000661__4; var results_QMARK___6 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_283); var end__7 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_118); var func_QMARK___8 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_284); var sep__9 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_285); var next__10 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_341); var parent__11 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_116); var offset__12 any = lang.RT_Get_O_O__O_NoInit(map__74000661__4, A_arbace_repr_go_print_code_A_const_117); var indent__13 any; var or__1927000174__auto____13 any = A_arbace_repr_go_print_code_A_const_163.Invoke_O__O(opts__5); if






	jrt.J2g_Truth(or__1927000174__auto____13) { indent__13 = or__1927000174__auto____13 } else { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_162; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_163; indent__13 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_164; indent__13 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } }; var tmp4 /*line :1585:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var start__14 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var forms__15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(forms__0); var one_line_QMARK___16 any; var tmp5 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if









	jrt.J2g_Truth(tmp5.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(end__7)) {
			one_line_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_O__Z_NoInit(lang.RT_LongCast_O__J_NoInit(end__7), start__14)).Ref() } else {
//line :1596:1
				var and__1927000168__auto____16 any = func_QMARK___8

				if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_code_block_body_fn__74000663_A_New_O(start__14); var tmp8 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_repr_go_print_code_block_body_fn__74000663_A_fn_class; if fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_print_code_block_body_fn__74000663_A_fn_class = fncls__306d; tmp8 = fncls__306d } else { tmp8 = fncls__306 }; and__1927000168__auto____17 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), forms__15); if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_83.GetRawRoot__O()).Invoke_O__O(parent__11); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()); var tmp13 any; var or__1927000174__auto____18 any = offset__12
					if jrt.J2g_Truth(or__1927000174__auto____18) { tmp13 = or__1927000174__auto____18 } else { tmp13 = A_arbace_repr_go_print_code_A_const_188 }; var tmp14 any = tmp13; var tmp15 jrt.Number_I; var na_307 any; var or__1927000174__auto____18_2 any = offset__12; if jrt.J2g_Truth(or__1927000174__auto____18_2) { na_307 = or__1927000174__auto____18_2 } else { na_307 = A_arbace_repr_go_print_code_A_const_188 }; var na_308 int64 = int64(lang.RT_Count_O__I_NoInit(forms__15)); if jrt.Long_InstanceOf(na_307) { var n0_309 int64 = jrt.NN(jrt.Long_Cast(na_307)).LongValue__J(); var n1_310 int64 = na_308; var nr_311 int64 = n0_309 + n1_310; if (n0_309^nr_311)&(n1_310^nr_311) >= 0 { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_311)) } else { tmp15 = lang.Numbers_Add_O_J__Number_NoInit(na_307, na_308) } } else { tmp15 = lang.Numbers_Add_O_J__Number_NoInit(na_307, na_308) }; and__1927000168__auto____18 = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp14, tmp15)))
//line :1598:1
					if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(forms__15)

						if jrt.J2g_Truth(or__1927000174__auto____19) { one_line_QMARK___16 = or__1927000174__auto____19 } else { var or__1927000174__auto____20 bool = lang.Util_Identical_O_O__Z_NoInit(next__10, nil); if or__1927000174__auto____20 { one_line_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20).Ref() } else { one_line_QMARK___16 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_412.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_188) } } } else {
//line :1598:1
							one_line_QMARK___16 = and__1927000168__auto____18 } } else { one_line_QMARK___16 = and__1927000168__auto____17 } } else { one_line_QMARK___16 = and__1927000168__auto____16 } } } else {
//line :1595:1
								var and__1927000168__auto____16_2 any = func_QMARK___8





								if jrt.J2g_Truth(and__1927000168__auto____16_2) { one_line_QMARK___16 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(forms__15) } else { one_line_QMARK___16 = and__1927000168__auto____16_2 } }; if
	jrt.J2g_Truth(one_line_QMARK___16) { var tmp16 any; var or__1927000174__auto____17 any = sep__9; if jrt.J2g_Truth(or__1927000174__auto____17) { tmp16 = or__1927000174__auto____17 } else { tmp16 = A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O() }; lang.IFn_Cast(tmp16).Invoke__O() } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_17, A_arbace_repr_go_print_code_A_const_202.Invoke_O__O(opts__5));
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(indent__13); var tmp17 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_print_code_A_const_86; var tmp20 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(end__7)) { tmp20 = end__7 } else { var or__1927000174__auto____17_2 any = next__10; if jrt.J2g_Truth(or__1927000174__auto____17_2) { tmp20 = or__1927000174__auto____17_2 } else { tmp20 = A_arbace_repr_go_print_code_A_const_86.Get__O() } }; tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20)); var tmp21 any; tmp46 := /*line :1585:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




















		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(forms__15)) {
			if jrt.J2g_Truth(one_line_QMARK___16) {

				var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp24 any = A_arbace_repr_go_print_code_A_const_86; var tmp25 any; var tmp26 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp26.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { var tmp27 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; tmp25 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp27.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) } else { tmp25 = nil }; tmp22.Invoke_O__O(tmp23.Invoke_O_O__O(tmp24, tmp25)); var tmp28 any = A_arbace_repr_go_print_code_block_body_fn__74000665_A_New_O_O_O(forms__15, results_QMARK___6, indent__13); var tmp29 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_repr_go_print_code_block_body_fn__74000665_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_print_code_block_body_fn__74000665_A_fn_class = fncls__314d; tmp29 = fncls__314d } else { tmp29 = fncls__314 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O() } else {


					var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_347.GetRawRoot__O()); var tmp31 any = A_arbace_repr_go_print_code_A_const_163; var tmp32 jrt.Number_I; var na_315 any = indent__13; if jrt.Long_InstanceOf(na_315) { var n0_316 int64 = jrt.NN(jrt.Long_Cast(na_315)).LongValue__J(); if n0_316 == 9223372036854775807 { tmp32 = lang.Numbers_Inc_O__Number_NoInit(na_315) } else { tmp32 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_316 + 1)) } } else { if jrt.Double_InstanceOf(na_315) { var n0_316_2 float64 = jrt.NN(jrt.Double_Cast(na_315)).DoubleValue__D(); tmp32 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_316_2 + 1.0)) } else { tmp32 = lang.Numbers_Inc_O__Number_NoInit(na_315) } }; tmp30.Invoke_O_O__O(forms__15, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, A_arbace_repr_go_print_code_A_const_283, results_QMARK___6, A_arbace_repr_go_print_code_A_const_116, parent__11, A_arbace_repr_go_print_code_A_const_117, offset__12))) } }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O()
		if jrt.J2g_Truth(one_line_QMARK___16) {
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(forms__15)) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }; tmp21 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_19, A_arbace_repr_go_print_code_A_const_203.Invoke_O__O(opts__5)) } else {
//line :1614:1
				var close_end__19 any
				var or__1927000174__auto____19_2 any = end__7


				if jrt.J2g_Truth(or__1927000174__auto____19_2) { close_end__19 = or__1927000174__auto____19_2 } else { var or__1927000174__auto____20_2 any; var tmp33 any; var and__1927000168__auto____20 any = A_arbace_repr_go_print_code_A_const_342.Invoke_O__O(opts__5)
					if jrt.J2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(next__10); if jrt.J2g_Truth(and__1927000168__auto____21) { var tmp34 bool; var na_296 int64 = lang.RT_LongCast_O__J_NoInit(next__10); var tmp35 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_297 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp35.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_297) { var n0_298 int64 = na_296; var n1_299 int64 = jrt.NN(jrt.Long_Cast(na_297)).LongValue__J(); tmp34 = n0_298 > n1_299 } else { tmp34 = lang.Numbers_Gt_J_O__Z_NoInit(na_296, na_297) }; tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp34).Ref() } else { tmp33 = and__1927000168__auto____21 } } else { tmp33 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp33) { or__1927000174__auto____20_2 = next__10 } else { or__1927000174__auto____20_2 = nil }
//line :1618:1
					if jrt.J2g_Truth(or__1927000174__auto____20_2) { close_end__19 = or__1927000174__auto____20_2 } else {


						var tmp36 any; var and__1927000168__auto____21_2 any = A_arbace_repr_go_print_code_A_const_343.Invoke_O__O(opts__5); if jrt.J2g_Truth(and__1927000168__auto____21_2) { var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(next__10); if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp37 bool; var na_301 int64 = lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(next__10)); var tmp38 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_302 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp38.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_302) { var n0_303 int64 = na_301; var n1_304 int64 = jrt.NN(jrt.Long_Cast(na_302)).LongValue__J(); tmp37 = n0_303 > n1_304 } else { tmp37 = lang.Numbers_Gt_J_O__Z_NoInit(na_301, na_302) }; tmp36 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp37).Ref() } else { tmp36 = and__1927000168__auto____22 } } else { tmp36 = and__1927000168__auto____21_2 }; if jrt.J2g_Truth(tmp36) {
							close_end__19 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(next__10))).Ref() } else {
//line :1621:1
								close_end__19 = nil
							} } }
				var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()); var tmp40 bool; var tmp41 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_317 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp41.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var na_318 any = start__14; var tmp42 bool; var tmp43 bool; tmp43 = jrt.Long_InstanceOf(na_317); if tmp43 { tmp43 = jrt.Long_InstanceOf(na_318) }; tmp42 = tmp43; if tmp42 { var n0_319 int64 = jrt.NN(jrt.Long_Cast(na_317)).LongValue__J(); var n1_320 int64 = jrt.NN(jrt.Long_Cast(na_318)).LongValue__J(); tmp40 = n0_319 > n1_320 } else { var tmp44 bool; var tmp45 bool; tmp45 = jrt.Double_InstanceOf(na_317); if tmp45 { tmp45 = jrt.Double_InstanceOf(na_318) }; tmp44 = tmp45; if tmp44 { var n0_319_2 float64 = jrt.NN(jrt.Double_Cast(na_317)).DoubleValue__D(); var n1_320_2 float64 = jrt.NN(jrt.Double_Cast(na_318)).DoubleValue__D(); tmp40 = n1_320_2 < n0_319_2 } else { tmp40 = lang.Numbers_Gt_O_O__Z_NoInit(na_317, na_318) } }; if jrt.J2g_Truth(tmp39.Invoke_O_O_O_O__O(close_end__19, jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp40).Ref(), jrt.Boolean_TRUE.Ref(), indent__13)) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
				tmp21 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_19, A_arbace_repr_go_print_code_A_const_203.Invoke_O__O(opts__5)) }
//line :1585:1
		return nil }();



















	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :1585:1*/ tmp46 != nil { panic(tmp46) }; return tmp21 }












func A_arbace_repr_go_print_code_block_body_fn__74000663_A_New_O(p0 any) *A_arbace_repr_go_print_code_block_body_fn__74000663_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_block_body_fn__74000663_A{}; t.Ctor_O(p0); return t }
//line :1598:1
func (t *A_arbace_repr_go_print_code_block_body_fn__74000663_A) Ctor_O(c__start any) { t.F_start = c__start }
//line :1598:1
func (t *A_arbace_repr_go_print_code_block_body_fn__74000663_A) Invoke_O_O__O(self, p1__74000659_SHARP___1 any) any { var t__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(p1__74000659_SHARP___1); var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(t__2, nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__2, t.F_start)).Ref() } }










func A_arbace_repr_go_print_code_block_body_fn__74000665_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_code_block_body_fn__74000665_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_block_body_fn__74000665_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1609:1
func (t *A_arbace_repr_go_print_code_block_body_fn__74000665_A) Ctor_O_O_O(c__forms, c__results_QMARK_, c__indent any) { t.F_forms = c__forms; t.F_results_QMARK_ = c__results_QMARK_; t.F_indent = c__indent }
//line :1609:1
func (t *A_arbace_repr_go_print_code_block_body_fn__74000665_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_413.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_forms; t.F_forms = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_results_QMARK_; t.F_results_QMARK_ = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 jrt.Number_I; var na_312 any; var t__3 any = t.F_indent; t.F_indent = nil; na_312 = t__3; if jrt.Long_InstanceOf(na_312) { var n0_313 int64 = jrt.NN(jrt.Long_Cast(na_312)).LongValue__J(); if n0_313 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_312) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_313 + 1)) } } else { if jrt.Double_InstanceOf(na_312) { var n0_313_2 float64 = jrt.NN(jrt.Double_Cast(na_312)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_313_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_312) } }; tmp1 = tmp2.Invoke_O_O_O__O(tmp4, tmp6, tmp7) }
//line :1609:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
















func A_arbace_repr_go_print_code_stmt_list_one_line_A_New() *A_arbace_repr_go_print_code_stmt_list_one_line_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_stmt_list_one_line_A{}; t.Ctor(); return t }
//line :1626:1
func (t *A_arbace_repr_go_print_code_stmt_list_one_line_A) Ctor() {}
//line :1626:1
func (t *A_arbace_repr_go_print_code_stmt_list_one_line_A) Invoke_O_O_O_O__O(self, forms__0, results_QMARK___1, indent__2 any) any { { var items__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_398.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_383.GetRawRoot__O()).Invoke_O_O_O__O(forms__0, nil, A_arbace_repr_go_print_code_A_const_188)); var n__5 int32 = lang.RT_Count_O__I_NoInit(items__4); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J_NoInit(n__5); var i__7 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__7, n__1927000701__auto____6) { var it__8 any = lang.RT_Nth_O_I__O_NoInit(items__4, lang.RT_IntCast_J__I_NoInit(i__7)); var f__9 any = A_arbace_repr_go_print_code_A_const_22.Invoke_O__O(it__8)

		if lang.Numbers_IsPos_J__Z_NoInit(i__7) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_36); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_322 any = indent__2; if jrt.Long_InstanceOf(na_322) { var n0_323 int64 = jrt.NN(jrt.Long_Cast(na_322)).LongValue__J(); if n0_323 == -9223372036854775808 { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_322) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_323 - 1)) } } else { if jrt.Double_InstanceOf(na_322) { var n0_323_2 float64 = jrt.NN(jrt.Double_Cast(na_322)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_323_2 - 1.0)) } else { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_322) } }; tmp1.Invoke_O__O(tmp2)
//line :1631:1
		var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_401.GetRawRoot__O()).Invoke_O__O(it__8)



		if jrt.J2g_Truth(temp__1927000414__auto____10) { var l__11 any = temp__1927000414__auto____10; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_367.GetRawRoot__O()).Invoke_O__O(l__11)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_38); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
		if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(it__8)) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_403.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_code_A_const_387.Invoke_O__O(it__8); var tmp5 jrt.Number_I; var na_324 any = indent__2; if jrt.Long_InstanceOf(na_324) { var n0_325 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); if n0_325 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_324) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_325 - 1)) } } else { if jrt.Double_InstanceOf(na_324) { var n0_325_2 float64 = jrt.NN(jrt.Double_Cast(na_324)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_325_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_324) } }; tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
//line :1636:1
				if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__8)) {

					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_324.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_380.Invoke_O__O(it__8)) } else {
//line :1636:1
						if jrt.J2g_Truth(A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__8)) {


							lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_405.GetRawRoot__O(), A_arbace_repr_go_print_code_A_const_382.Invoke_O__O(it__8)) } else {
//line :1636:1
								var tmp6 any
								var and__1927000168__auto____10 any = results_QMARK___1


								if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Equiv_J_J__Z_NoInit(i__7, lang.Numbers_Dec_J__J_NoInit(int64(n__5))); if and__1927000168__auto____11 { tmp6 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_404.GetRawRoot__O()).Invoke_O__O(f__9) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp6 = and__1927000168__auto____10 }
//line :1636:1
								if jrt.J2g_Truth(tmp6) {



									lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_174); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_232.GetRawRoot__O()).Invoke_O_O__O(f__9, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1636:1
										if A_arbace_repr_go_print_code_A_const_42 != nil {




											lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_332.GetRawRoot__O()).Invoke_O__O(f__9) } } } } }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O()
//line :1631:1
		i__7 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7); continue L1 } else { return nil } } }; /*line :1626:1*/panic("j2g: unreachable") }




















func A_arbace_repr_go_print_code_parse_decl_head_A_New() *A_arbace_repr_go_print_code_parse_decl_head_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_parse_decl_head_A{}; t.Ctor(); return t }
//line :1647:1
func (t *A_arbace_repr_go_print_code_parse_decl_head_A) Ctor() {}
//line :1647:1
func (t *A_arbace_repr_go_print_code_parse_decl_head_A) Invoke_O_O__O(self, xs__0 any) any { var vec__74000669__2 any; if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__0))) { vec__74000669__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__0), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__0)) } else { vec__74000669__2 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__0) }; var doc__3 any = /*line :1647:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000669__2, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000669__2, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__74000672__5 any; if




	lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__4), A_arbace_repr_go_print_code_A_const_33) { vec__74000672__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(xs__4), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(xs__4)) } else { vec__74000672__5 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__4) }; var tps__6 any = /*line :1647:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000672__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000672__5, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(doc__3, tps__6, xs__7) }







func A_arbace_repr_go_print_code_generic_type_QMARK__A_New() *A_arbace_repr_go_print_code_generic_type_QMARK__A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_generic_type_QMARK__A{}; t.Ctor(); return t }
//line :1655:1
func (t *A_arbace_repr_go_print_code_generic_type_QMARK__A) Ctor() {}
//line :1655:1
func (t *A_arbace_repr_go_print_code_generic_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0); if

	jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0), Lit_4)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { t__2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(t__0) } else { t__2 = t__0 }; var and__1927000168__auto____3 any = /*line :1655:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__2); if


	jrt.J2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_236.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__2))) } else { return and__1927000168__auto____3 } }

func A_arbace_repr_go_print_code_func_decl_A_New() *A_arbace_repr_go_print_code_func_decl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_func_decl_A{}; t.Ctor(); return t }
//line :1660:1
func (t *A_arbace_repr_go_print_code_func_decl_A) Ctor() {}
//line :1660:1
func (t *A_arbace_repr_go_print_code_func_decl_A) Invoke_O_O_O__O(self, f__0, method_QMARK___1 any) any { var vec__74000677__3 any = f__0; var seq__74000678__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000677__3); var first__74000679__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000678__4); var seq__74000678__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000678__4); var ___7 any = first__74000679__5; var first__74000679__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000678__6); var seq__74000678__9 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000678__6); var nm__10 any = first__74000679__8; var xs__11 any = seq__74000678__9; var vec__74000680__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_414.GetRawRoot__O()).Invoke_O__O(xs__11); var doc__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000680__12, lang.RT_IntCast_J__I_NoInit(0), nil); var tps__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000680__12, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000680__12, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__74000683__16 any = xs__15; var seq__74000684__17 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000683__16); var first__74000685__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000684__17); var seq__74000684__19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000684__17); var params__20 any = first__74000685__18; var more__21 any = seq__74000684__19; var ___22 any; _ = ___7; _ = doc__13; _ = ___22; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O()).Invoke_O__O(params__20)) { ___22 = nil } else { ___22 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_130, f__0) }; var vec__74000686__23 any; if
	lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(more__21), A_arbace_repr_go_print_code_A_const_190) { vec__74000686__23 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(more__21), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_195.GetRawRoot__O()).Invoke_O__O(more__21)) } else { vec__74000686__23 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__21) }; var results__24 any = /*line :1660:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000686__23, lang.RT_IntCast_J__I_NoInit(0), nil); var body__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000686__23, lang.RT_IntCast_J__I_NoInit(1), nil); var m__26 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__10); var extern_QMARK___27 any = A_arbace_repr_go_print_code_A_const_415.Invoke_O__O(m__26); var vec__74000689__28 any; if









	jrt.J2g_Truth(method_QMARK___1) { vec__74000689__28 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(params__20), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(params__20)), lang.RT_Meta_O__IPersistentMap_NoInit(params__20))) } else { vec__74000689__28 = lang.Tuple_Create_O_O__IPersistentVector(nil, params__20) }; var recv__29 any = /*line :1660:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000689__28, lang.RT_IntCast_J__I_NoInit(0), nil); var params__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000689__28, lang.RT_IntCast_J__I_NoInit(1), nil); var res__31 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_191.GetRawRoot__O()).Invoke_O_O__O(params__30, results__24); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_A_const_141; var tmp4 any; var or__1927000174__auto____32 any = tps__14; if











	jrt.J2g_Truth(or__1927000174__auto____32) { tmp4 = or__1927000174__auto____32 } else { var and__1927000168__auto____33 any = recv__29; if jrt.J2g_Truth(and__1927000168__auto____33) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_416.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_133.GetRawRoot__O()).Invoke_O__O(recv__29)) { var tmp7 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(recv__29)) } else { tmp6 = recv__29 }; tmp4 = tmp5.Invoke_O__O(tmp6) } else { tmp4 = and__1927000168__auto____33 } }; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref(); var tmp9 any = A_arbace_repr_go_print_code_A_const_281; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp8, tmp9, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_282))); var tmp10 any; tmp34 := /*line :1660:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var indent__34 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_279.GetRawRoot__O()).Invoke__O()














		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_26, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_229)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
		if jrt.J2g_Truth(method_QMARK___1) {
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(params__30, A_arbace_repr_go_print_code_A_const_417))
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_133.GetRawRoot__O()).Invoke_O__O(recv__29)) {
				lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(recv__29); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); var tmp11 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(recv__29))) } else {
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(recv__29) }
			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(params__30, A_arbace_repr_go_print_code_A_const_418)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
		lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(nm__10)
		if jrt.J2g_Truth(tps__14) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_320.GetRawRoot__O()).Invoke_O__O(tps__14) }
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_167.GetRawRoot__O()); var tmp13 any; if jrt.J2g_Truth(extern_QMARK___27) { tmp13 = nil } else { tmp13 = body__25 }; tmp12.Invoke_O_O_O_O__O(params__30, res__31, tmp13, results__24)
		if jrt.J2g_Truth(extern_QMARK___27) { tmp10 = nil } else {
			var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_280.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(body__25); var tmp16 any = A_arbace_repr_go_print_code_A_const_283; var tmp17 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(res__31); var tmp18 any = A_arbace_repr_go_print_code_A_const_118; var tmp19 *lang.Keyword = A_arbace_repr_go_print_code_A_const_125; var tmp20 any = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)); var tmp21 any = A_arbace_repr_go_print_code_A_const_284; var tmp22 any = jrt.Boolean_TRUE.Ref(); var tmp23 any = A_arbace_repr_go_print_code_A_const_116; var tmp24 any = A_arbace_repr_go_print_code_A_const_117; var tmp25 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_286.GetRawRoot__O()).Invoke_O_O__O(f__0, body__25); var tmp26 any = A_arbace_repr_go_print_code_A_const_163; var tmp27 any = A_arbace_repr_go_print_code_A_const_285; var tmp28 any
			var tmp29 /*line :1686:1*/*lang.Keyword = A_arbace_repr_go_print_code_A_const_75

			if jrt.J2g_Truth(tmp29.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) { tmp28 = A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O() } else { tmp28 = A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O() }
//line :1686:1
			var tmp30 any = tmp28; var tmp31 any = A_arbace_repr_go_print_code_A_const_202; var tmp32 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_202); var tmp33 any = A_arbace_repr_go_print_code_A_const_203; tmp10 = tmp14.Invoke_O_O__O(tmp15, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp20, tmp21, tmp22, tmp23, f__0, tmp24, tmp25, tmp26, indent__34, tmp27, tmp30, tmp31, tmp32, tmp33, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_203)))) } }; return nil }(); /*line :1672:1*/lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if /*line :1660:1*/ tmp34 != nil { panic(tmp34) }; return tmp10 }






























func A_arbace_repr_go_print_code_spec_name_A_New() *A_arbace_repr_go_print_code_spec_name_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_spec_name_A{}; t.Ctor(); return t }
//line :1691:1
func (t *A_arbace_repr_go_print_code_spec_name_A) Ctor() {}
//line :1691:1
func (t *A_arbace_repr_go_print_code_spec_name_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(t__0), Lit_95)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(t__0) } else { return t__0 } }

func A_arbace_repr_go_print_code_value_spec_A_New() *A_arbace_repr_go_print_code_value_spec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_value_spec_A{}; t.Ctor(); return t }
//line :1693:1
func (t *A_arbace_repr_go_print_code_value_spec_A) Ctor() {}
//line :1693:1
func (t *A_arbace_repr_go_print_code_value_spec_A) Invoke_O_O_O_O_O__O(self, target__0, init__1, group_QMARK___2, keep_type__3 any) any { var ts__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_311.GetRawRoot__O()).Invoke_O__O(target__0); var typ__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_value_spec_fn__74000695_A_New(); var tmp3 *jrt.Class; var fncls__326 *jrt.Class = A_arbace_repr_go_print_code_value_spec_fn__74000695_A_fn_class; if



	fncls__326 == nil { var fncls__326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_213, false); A_arbace_repr_go_print_code_value_spec_fn__74000695_A_fn_class = fncls__326d; tmp3 = fncls__326d } else { tmp3 = fncls__326 }; typ__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ts__5); var sep__7 any; if
	jrt.J2g_Truth(group_QMARK___2) { sep__7 = A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O() } else { sep__7 = A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O() };
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_151.GetRawRoot__O()).Invoke_O__O(ts__5); var tmp4 any; var or__1927000174__auto____8 any = typ__6; if
	jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var and__1927000168__auto____9 any = group_QMARK___2; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp4 = keep_type__3 } else { tmp4 = and__1927000168__auto____9 } }; if jrt.J2g_Truth(tmp4) { lang.IFn_Cast(sep__7).Invoke__O() }; if
	jrt.J2g_Truth(typ__6) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(typ__6) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_repr_go_print_code_A_const_392)) {
		lang.IFn_Cast(sep__7).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_314.GetRawRoot__O()).Invoke_O_O__O(init__1, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1702:1
			return nil } }
//line :1697:1
func A_arbace_repr_go_print_code_value_spec_fn__74000695_A_New() *A_arbace_repr_go_print_code_value_spec_fn__74000695_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_value_spec_fn__74000695_A{}; t.Ctor(); return t }
//line :1697:1
func (t *A_arbace_repr_go_print_code_value_spec_fn__74000695_A) Ctor() {}
//line :1697:1
func (t *A_arbace_repr_go_print_code_value_spec_fn__74000695_A) Invoke_O_O__O(self, p1__74000694_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000694_SHARP___1), A_arbace_repr_go_print_code_A_const_31)) { var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_31; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000694_SHARP___1)) } else { return nil } }







func A_arbace_repr_go_print_code_keep_type_column_A_New() *A_arbace_repr_go_print_code_keep_type_column_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_keep_type_column_A{}; t.Ctor(); return t }
//line :1705:1
func (t *A_arbace_repr_go_print_code_keep_type_column_A) Ctor() {}
//line :1705:1
func (t *A_arbace_repr_go_print_code_keep_type_column_A) Invoke_O_O__O(self, specs__0 any) any { { var n__2 int32 = lang.RT_Count_O__I_NoInit(specs__0); var m__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_419.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_273.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref(), jrt.Boolean_FALSE.Ref()))); var i__4 int64 = 0; var i0__5 any = lang.RT_Box_J__Number_NoInit(-1); var keep__6 any = jrt.Boolean_FALSE.Ref(); L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__2)) { var vec__74000715__7 any = lang.RT_Nth_O_I__O_NoInit(specs__0, lang.RT_IntCast_J__I_NoInit(i__4)); var t__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000715__7, lang.RT_IntCast_J__I_NoInit(0), nil); var init__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000715__7, lang.RT_IntCast_J__I_NoInit(1), nil); var has_values__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_173.GetRawRoot__O()).Invoke_O_O__O(init__9, A_arbace_repr_go_print_code_A_const_392); var typed__11 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A_New(); var tmp3 *jrt.Class
		var fncls__329 /*line :1711:1*/*jrt.Class = A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A_fn_class


		if fncls__329 == nil { var fncls__329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A_fn_class = fncls__329d; tmp3 = fncls__329d } else { tmp3 = fncls__329 }; typed__11 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_311.GetRawRoot__O()).Invoke_O__O(t__8))
//line :1711:1
		var vec__74000718__12 any



		if jrt.J2g_Truth(has_values__10) {
			var tmp4 bool; var na_327 any = i0__5; if jrt.Long_InstanceOf(na_327) { var n0_328 int64 = jrt.NN(jrt.Long_Cast(na_327)).LongValue__J(); tmp4 = n0_328 < 0 } else { if jrt.Double_InstanceOf(na_327) { var n0_328_2 float64 = jrt.NN(jrt.Double_Cast(na_327)).DoubleValue__D(); tmp4 = n0_328_2 < 0.0 } else { tmp4 = lang.Numbers_IsNeg_O__Z_NoInit(na_327) } }; if tmp4 { vec__74000718__12 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__4).Ref(), jrt.Boolean_FALSE.Ref()) } else { vec__74000718__12 = lang.Tuple_Create_O_O__IPersistentVector(i0__5, keep__6) } } else {
				var tmp5 bool; var na_330 any = i0__5; var na_331 int64 = 0; if jrt.Long_InstanceOf(na_330) { var n0_332 int64 = jrt.NN(jrt.Long_Cast(na_330)).LongValue__J(); var n1_333 int64 = na_331; tmp5 = n0_332 >= n1_333 } else { tmp5 = lang.Numbers_Gte_O_J__Z_NoInit(na_330, na_331) }; if tmp5 { var seq_74000723__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()).Invoke_O_O__O(i0__5, jrt.Long_ValueOf_J__Long_NoInit(i__4).Ref())); var chunk_74000724__13 any; var count_74000725__14 int64 = 0; var i_74000726__15 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_74000726__15, count_74000725__14) { var j__16 any = lang.Indexed_Cast(chunk_74000724__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000726__15)); if jrt.J2g_Truth(keep__6) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_421.GetRawRoot__O()).Invoke_O_O_O__O(m__3, j__16, jrt.Boolean_TRUE.Ref()) }; seq_74000723__12, chunk_74000724__13, count_74000725__14, i_74000726__15 = seq_74000723__12, chunk_74000724__13, count_74000725__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000726__15); continue L2 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000723__12); if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_74000723__17 any = temp__1927000414__auto____16; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000723__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000723__17); seq_74000723__12, chunk_74000724__13, count_74000725__14, i_74000726__15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000723__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var j__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000723__17); if jrt.J2g_Truth(keep__6) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_421.GetRawRoot__O()).Invoke_O_O_O__O(m__3, j__18, jrt.Boolean_TRUE.Ref()) }; seq_74000723__12, chunk_74000724__13, count_74000725__14, i_74000726__15 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000723__17), nil, 0, 0; continue L2 } } }; break L2 } }
//line :1715:1
				vec__74000718__12 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_print_code_A_const_172, keep__6) }
//line :1711:1
		var i0__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000718__12, lang.RT_IntCast_J__I_NoInit(0), nil); var keep__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000718__12, lang.RT_IntCast_J__I_NoInit(1), nil); var keep__15 any
		var or__1927000174__auto____15 any = keep__14






		if jrt.J2g_Truth(or__1927000174__auto____15) { keep__15 = or__1927000174__auto____15 } else { keep__15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(typed__11)).Ref() }
		i__4, i0__5, keep__6 = lang.Numbers_Inc_J__J_NoInit(i__4), i0__13, keep__15; continue L1 } else {
			var tmp6 bool; var na_335 any = i0__5; var na_336 int64 = 0; if jrt.Long_InstanceOf(na_335) { var n0_337 int64 = jrt.NN(jrt.Long_Cast(na_335)).LongValue__J(); var n1_338 int64 = na_336; tmp6 = n0_337 >= n1_338 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_335, na_336) }; if tmp6 { var seq_74000727__7 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_88.GetRawRoot__O()).Invoke_O_O__O(i0__5, jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref())); var chunk_74000728__8 any; var count_74000729__9 int64 = 0; var i_74000730__10 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_74000730__10, count_74000729__9) { var j__11 any = lang.Indexed_Cast(chunk_74000728__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_74000730__10)); if jrt.J2g_Truth(keep__6) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_421.GetRawRoot__O()).Invoke_O_O_O__O(m__3, j__11, jrt.Boolean_TRUE.Ref()) }; seq_74000727__7, chunk_74000728__8, count_74000729__9, i_74000730__10 = seq_74000727__7, chunk_74000728__8, count_74000729__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_74000730__10); continue L3 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(seq_74000727__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_74000727__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_50.GetRawRoot__O()).Invoke_O__O(seq_74000727__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_74000727__12); seq_74000727__7, chunk_74000728__8, count_74000729__9, i_74000730__10 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_74000727__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var j__13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_74000727__12); if jrt.J2g_Truth(keep__6) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_421.GetRawRoot__O()).Invoke_O_O_O__O(m__3, j__13, jrt.Boolean_TRUE.Ref()) }; seq_74000727__7, chunk_74000728__8, count_74000729__9, i_74000730__10 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq_74000727__12), nil, 0, 0; continue L3 } } }; break L3 } }
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_420.GetRawRoot__O()).Invoke_O__O(m__3) } } }; /*line :1705:1*/panic("j2g: unreachable") }








func A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A_New() *A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A{}; t.Ctor(); return t }
//line :1714:1
func (t *A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A) Ctor() {}
//line :1714:1
func (t *A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A) Invoke_O_O__O(self, p1__74000698_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__74000698_SHARP___1), A_arbace_repr_go_print_code_A_const_31) }









func A_arbace_repr_go_print_code_spec_t_A_New() *A_arbace_repr_go_print_code_spec_t_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_spec_t_A{}; t.Ctor(); return t }
//line :1724:1
func (t *A_arbace_repr_go_print_code_spec_t_A) Ctor() {}
//line :1724:1
func (t *A_arbace_repr_go_print_code_spec_t_A) Invoke_O_O__O(self, v__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(v__0); if
											jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_422.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(v__0))); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(v__0))) { return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_80.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(v__0)) } else { return nil } } } }

func A_arbace_repr_go_print_code_group_decl_A_New() *A_arbace_repr_go_print_code_group_decl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_decl_A{}; t.Ctor(); return t }
//line :1727:1
func (t *A_arbace_repr_go_print_code_group_decl_A) Ctor() {}
//line :1727:1
func (t *A_arbace_repr_go_print_code_group_decl_A) DoInvoke_O_O_O_O_O_O_O__O(self, kw__0, doc__1, specs__2, print_spec__3, meta_of__4, p__74000733__5 any) any { var vec__74000734__7 any = p__74000733__5; var f__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000734__7, lang.RT_IntCast_J__I_NoInit(0), nil);


	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(kw__0, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__8, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_6, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__8, A_arbace_repr_go_print_code_A_const_257)); var indent__9 int64 = 0; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(specs__2)) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__8, A_arbace_repr_go_print_code_A_const_258)) } else {
//line :1732:1
			var specs__10 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_47.GetRawRoot__O()).Invoke_O__O(specs__2); var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var last_start__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_200.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))); var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var first_line__12 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); _ = first_line__12




			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_188)
//line :1732:1
			var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(specs__10)); var i__14 int64 = 0; L1: for {





				if lang.Numbers_Lt_J_J__Z_NoInit(i__14, n__1927000701__auto____13) { var s__15 any = lang.RT_Nth_O_I__O_NoInit(specs__10, lang.RT_IntCast_J__I_NoInit(i__14)); var m__16 any = lang.IFn_Cast(meta_of__4).Invoke_O__O(s__15); var dirs__17 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(m__16); var pre__18 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_206.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_138.Invoke_O__O(m__16), dirs__17); var t__19 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_424.GetRawRoot__O()).Invoke_O__O(s__15); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O())
					var tmp4 any = A_arbace_repr_go_print_code_A_const_86




					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_166.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_209.GetRawRoot__O()).Invoke_O_O__O(specs__10, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__14)).Ref())))); var tmp5 any = A_arbace_repr_go_print_code_group_decl_fn__74000737_A_New_O_O_O_J(t__19, last_start__11, pre__18, i__14); var tmp6 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_repr_go_print_code_group_decl_fn__74000737_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_repr_go_print_code_group_decl_fn__74000737_A_fn_class = fncls__356d; tmp6 = fncls__356d } else { tmp6 = fncls__356 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()







					var tmp7 bool; var na_357 any = pre__18; if jrt.Long_InstanceOf(na_357) { var n0_358 int64 = jrt.NN(jrt.Long_Cast(na_357)).LongValue__J(); tmp7 = n0_358 > 0 } else { if jrt.Double_InstanceOf(na_357) { var n0_358_2 float64 = jrt.NN(jrt.Double_Cast(na_357)).DoubleValue__D(); tmp7 = n0_358_2 > 0.0 } else { tmp7 = lang.Numbers_IsPos_O__Z_NoInit(na_357) } }; if tmp7 {
						var tmp8 *lang.Keyword = A_arbace_repr_go_print_code_A_const_162; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_code_A_const_130) }
						lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_425.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_code_A_const_138.Invoke_O__O(m__16), dirs__17, A_arbace_repr_go_print_code_A_const_130)
						var tmp9 any; var tmp10 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____20 any = tmp10.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O()); if jrt.J2g_Truth(and__1927000168__auto____20) { tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t__19) } else { tmp9 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp9) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()).Invoke_O_O_O_O__O(t__19, jrt.Boolean_TRUE.Ref(), nil, A_arbace_repr_go_print_code_A_const_130) } }
					var tmp11 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_208.GetRawRoot__O()).Invoke_O_O__O(last_start__11, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())))
					lang.IFn_Cast(print_spec__3).Invoke_O_O__O(s__15, jrt.Long_ValueOf_J__Long_NoInit(i__14).Ref())
//line :1738:1
					i__14 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__14); continue L1 }
//line :1732:1
				break L1
			}
























			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_123.GetRawRoot__O()).Invoke__O()
			var tmp12 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp12.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {
				var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_129.GetRawRoot__O()); var tmp14 any = jrt.Boolean_TRUE.Ref(); var tmp15 any = jrt.Boolean_TRUE.Ref(); tmp13.Invoke_O_O_O_O__O(nil, tmp14, tmp15, jrt.Long_ValueOf_J__Long_NoInit(indent__9).Ref()) } else {
					lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_188, jrt.Boolean_TRUE.Ref()) }
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__8, A_arbace_repr_go_print_code_A_const_258)) } }
//line :1744:1
func A_arbace_repr_go_print_code_group_decl_fn__74000737_A_New_O_O_O_J(p0, p1, p2 any, p3 int64) *A_arbace_repr_go_print_code_group_decl_fn__74000737_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_group_decl_fn__74000737_A{}; t.Ctor_O_O_O_J(p0, p1, p2, p3); return t }
//line :1744:1
func (t *A_arbace_repr_go_print_code_group_decl_fn__74000737_A) Ctor_O_O_O_J(c__t, c__last_start, c__pre any, c__i int64) { t.F_t = c__t; t.F_last_start = c__last_start; t.F_pre = c__pre; t.F_i = c__i }
//line :1744:1
func (t *A_arbace_repr_go_print_code_group_decl_fn__74000737_A) Invoke_O__O(self any) any { var tmp1 any; tmp30 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 any; var tmp3 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; var and__1927000168__auto____3 any = tmp3.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())
													if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_76.GetRawRoot__O()).Invoke_O__O(t.F_t) } else { tmp2 = and__1927000168__auto____3 }
//line :1745:1
		if jrt.J2g_Truth(tmp2) {

			var tmp4 bool; var na_340 any = t.F_pre; if jrt.Long_InstanceOf(na_340) { var n0_341 int64 = jrt.NN(jrt.Long_Cast(na_340)).LongValue__J(); tmp4 = n0_341 > 0 } else { if jrt.Double_InstanceOf(na_340) { var n0_341_2 float64 = jrt.NN(jrt.Double_Cast(na_340)).DoubleValue__D(); tmp4 = n0_341_2 > 0.0 } else { tmp4 = lang.Numbers_IsPos_O__Z_NoInit(na_340) } }; if tmp4 {
				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp6 jrt.Number_I; var na_342 int64; var tmp7 any; var t_ any = t.F_t; t.F_t = nil; tmp7 = t_; na_342 = lang.RT_LongCast_O__J_NoInit(tmp7); var na_343 any; var t__2 any = t.F_pre; t.F_pre = nil; na_343 = t__2; if jrt.Long_InstanceOf(na_343) { var n0_344 int64 = na_342; var n1_345 int64 = jrt.NN(jrt.Long_Cast(na_343)).LongValue__J(); var nr_346 int64 = n0_344 - n1_345; var tmp8 bool; var tmp9 bool; tmp9 = !(n1_345 == -9223372036854775808); if tmp9 { tmp9 = (n0_344^n1_345)&(n0_344^nr_346) >= 0 }; tmp8 = tmp9; if tmp8 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_346)) } else { tmp6 = lang.Numbers_Minus_J_O__Number_NoInit(na_342, na_343) } } else { tmp6 = lang.Numbers_Minus_J_O__Number_NoInit(na_342, na_343) }; var tmp10 any = tmp6; var tmp11 jrt.Number_I; var tmp12 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_347 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); if jrt.Long_InstanceOf(na_347) { var n0_348 int64 = jrt.NN(jrt.Long_Cast(na_347)).LongValue__J(); if n0_348 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_347) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_348 + 1)) } } else { if jrt.Double_InstanceOf(na_347) { var n0_348_2 float64 = jrt.NN(jrt.Double_Cast(na_347)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_348_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_347) } }; tmp1 = tmp5.Invoke_O_O_O_O__O(lang.Numbers_Max_O_O__O_NoInit(tmp10, tmp11), jrt.Boolean_FALSE.Ref(), Lit_36, A_arbace_repr_go_print_code_A_const_130) } else {
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp14 any; var t__3 any = t.F_t; t.F_t = nil; tmp14 = t__3; tmp1 = tmp13.Invoke_O_O_O_O__O(tmp14, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_i)).Ref(), Lit_36, A_arbace_repr_go_print_code_A_const_130) } } else {
//line :1745:1
						var tmp15 *lang.Keyword = A_arbace_repr_go_print_code_A_const_75; if jrt.J2g_Truth(tmp15.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())) {




							var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_207.GetRawRoot__O()); var tmp17 *lang.Keyword; var tmp18 bool; var na_349 any; var t__4 any = t.F_pre; t.F_pre = nil; na_349 = t__4; if jrt.Long_InstanceOf(na_349) { var n0_350 int64 = jrt.NN(jrt.Long_Cast(na_349)).LongValue__J(); tmp18 = n0_350 > 0 } else { if jrt.Double_InstanceOf(na_349) { var n0_350_2 float64 = jrt.NN(jrt.Double_Cast(na_349)).DoubleValue__D(); tmp18 = n0_350_2 > 0.0 } else { tmp18 = lang.Numbers_IsPos_O__Z_NoInit(na_349) } }; if tmp18 { tmp17 = A_arbace_repr_go_print_code_A_const_82 } else { tmp17 = nil }; tmp1 = tmp16.Invoke_O_O_O_O__O(tmp17.Ref(), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(t.F_i)).Ref(), Lit_36, A_arbace_repr_go_print_code_A_const_130) } else {
//line :1745:1
								if A_arbace_repr_go_print_code_A_const_42 != nil {





									var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_205.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_print_code_A_const_130; var tmp21 *jrt.Boolean; var or__1927000174__auto____3 bool = lang.Numbers_IsZero_J__Z_NoInit(t.F_i); if or__1927000174__auto____3 { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3) } else { var tmp22 bool; var tmp23 *lang.Keyword = A_arbace_repr_go_print_code_A_const_17; var na_351 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_repr_go_print_code_A_const_25.Get__O())); var na_352 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_7.GetRawRoot__O()); var tmp25 any; var t__5 any = t.F_last_start; t.F_last_start = nil; tmp25 = t__5; na_352 = tmp24.Invoke_O__O(tmp25); var tmp26 bool; var tmp27 bool; tmp27 = jrt.Long_InstanceOf(na_351); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_352) }; tmp26 = tmp27; if tmp26 { var n0_353 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_354 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); tmp22 = n0_353 > n1_354 } else { var tmp28 bool; var tmp29 bool; tmp29 = jrt.Double_InstanceOf(na_351); if tmp29 { tmp29 = jrt.Double_InstanceOf(na_352) }; tmp28 = tmp29; if tmp28 { var n0_353_2 float64 = jrt.NN(jrt.Double_Cast(na_351)).DoubleValue__D(); var n1_354_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); tmp22 = n1_354_2 < n0_353_2 } else { tmp22 = lang.Numbers_Gt_O_O__Z_NoInit(na_351, na_352) } }; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp22) }; tmp1 = tmp19.Invoke_O_O__O(tmp20, tmp21.Ref()) } else {
//line :1745:1
										tmp1 = nil } } } }
//line :1744:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O(); if tmp30 != nil { panic(tmp30) }; return tmp1 }



















func A_arbace_repr_go_print_code_const_var_decl_A_New() *A_arbace_repr_go_print_code_const_var_decl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_var_decl_A{}; t.Ctor(); return t }
//line :1764:1
func (t *A_arbace_repr_go_print_code_const_var_decl_A) Ctor() {}
//line :1764:1
func (t *A_arbace_repr_go_print_code_const_var_decl_A) Invoke_O_O_O__O(self, f__0, kw__1 any) any { var vec__74000740__3 any = f__0; var seq__74000741__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000740__3); var first__74000742__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000741__4); var seq__74000741__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000741__4); var ___7 any = first__74000742__5; var xs__8 any = seq__74000741__6; var vec__74000743__9 any; _ = ___7; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__8))) { vec__74000743__9 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__8), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__8)) } else { vec__74000743__9 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__8) }; var doc__10 any = /*line :1764:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000743__9, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000743__9, lang.RT_IntCast_J__I_NoInit(1), nil); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O(), xs__11)) { var specs__12 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_87.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A_New(); var tmp3 *jrt.Class
		var fncls__359 /*line :1767:1*/*jrt.Class = A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A_fn_class

		if fncls__359 == nil { var fncls__359d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A_fn_class = fncls__359d; tmp3 = fncls__359d } else { tmp3 = fncls__359 }; specs__12 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), xs__11)
//line :1767:1
		var keep__13 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_391.GetRawRoot__O()).Invoke_O__O(specs__12); var group_QMARK___14 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(specs__12)), 1); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_426.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A_New_O_Z_O(specs__12, group_QMARK___14, keep__13); var tmp6 *jrt.Class
		var fncls__360 /*line :1767:1*/*jrt.Class = A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A_fn_class





		if fncls__360 == nil { var fncls__360d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A_fn_class = fncls__360d; tmp6 = fncls__360d } else { tmp6 = fncls__360 }
//line :1772:1
		var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A_New(); var tmp9 *jrt.Class
		var fncls__361 /*line :1772:1*/*jrt.Class = A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A_fn_class

		if fncls__361 == nil { var fncls__361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A_fn_class = fncls__361d; tmp9 = fncls__361d } else { tmp9 = fncls__361 }
//line :1772:1
		return tmp4.Invoke_O_O_O_O_O_O__O(kw__1, doc__10, xs__11, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), f__0) } else {
//line :1767:1
			var vec__74000755__12 any = xs__11; var t__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000755__12, lang.RT_IntCast_J__I_NoInit(0), nil); var init__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000755__12, lang.RT_IntCast_J__I_NoInit(1), nil)









			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(kw__1, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_427.GetRawRoot__O()); var tmp11 any; if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xs__11)), 1) { tmp11 = init__14 } else { tmp11 = A_arbace_repr_go_print_code_A_const_392 }; return tmp10.Invoke_O_O_O_O__O(t__13, tmp11, jrt.Boolean_FALSE.Ref(), jrt.Boolean_FALSE.Ref()) } }
//line :1769:1
func A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A_New() *A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A{}; t.Ctor(); return t }
//line :1769:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A) Ctor() {}
//line :1769:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(v__1); var tmp2 any; if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(v__1)), 1) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_67.GetRawRoot__O()).Invoke_O__O(v__1) } else { tmp2 = A_arbace_repr_go_print_code_A_const_392 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }



func A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A_New_O_Z_O(p0 any, p1 bool, p2 any) *A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A{}; t.Ctor_O_Z_O(p0, p1, p2); return t }
//line :1773:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A) Ctor_O_Z_O(c__specs any, c__group_QMARK_ bool, c__keep any) { t.F_specs = c__specs; t.F_group_QMARK_ = c__group_QMARK_; t.F_keep = c__keep }
//line :1773:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A) Invoke_O_O_O__O(self, v__1, i__2 any) any { var tmp1 any = t.F_specs; var vec__74000749__3 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__2)); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000749__3, lang.RT_IntCast_J__I_NoInit(0), nil); var init__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000749__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = t.F_keep; return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_427.GetRawRoot__O()).Invoke_O_O_O_O__O(t__4, init__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(t.F_group_QMARK_).Ref(), lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(i__2))) }
func A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A_New() *A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A{}; t.Ctor(); return t }
//line :1774:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A) Ctor() {}
//line :1774:1
func (t *A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A) Invoke_O_O__O(self, v__1 any) any { return lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_422.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(v__1))) }





func A_arbace_repr_go_print_code_type_spec_A_New() *A_arbace_repr_go_print_code_type_spec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_spec_A{}; t.Ctor(); return t }
//line :1780:1
func (t *A_arbace_repr_go_print_code_type_spec_A) Ctor() {}
//line :1780:1
func (t *A_arbace_repr_go_print_code_type_spec_A) Invoke_O_O_O_O_O__O(self, nm__0, tps__1, t__2, group_QMARK___3 any) any {
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_102.GetRawRoot__O()).Invoke_O__O(nm__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_93.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_code_A_const_141; lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tps__1)).Ref()))
//line :1780:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		if jrt.J2g_Truth(tps__1) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_320.GetRawRoot__O()).Invoke_O__O(tps__1) }
		if jrt.J2g_Truth(group_QMARK___3) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_197.GetRawRoot__O()).Invoke__O() } else { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
		{ var tmp4 *lang.Keyword = A_arbace_repr_go_print_code_A_const_321; if jrt.J2g_Truth(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__0))) { lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_27.GetRawRoot__O()).Invoke_O__O(Lit_1); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O() }
			tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_150.GetRawRoot__O()).Invoke_O__O(t__2) }
//line :1780:1
		return nil
	}()
	lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_90.GetRawRoot__O()).Invoke__O()
//line :1780:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}






func A_arbace_repr_go_print_code_parse_type_spec_A_New() *A_arbace_repr_go_print_code_parse_type_spec_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_parse_type_spec_A{}; t.Ctor(); return t }
//line :1788:1
func (t *A_arbace_repr_go_print_code_parse_type_spec_A) Ctor() {}
//line :1788:1
func (t *A_arbace_repr_go_print_code_parse_type_spec_A) Invoke_O_O__O(self, xs__0 any) any { var vec__74000760__2 any = xs__0; var seq__74000761__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000760__2); var first__74000762__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000761__3); var seq__74000761__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000761__3); var nm__6 any = first__74000762__4; var xs__7 any = seq__74000761__5; var vec__74000763__8 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_414.GetRawRoot__O()).Invoke_O__O(xs__7); var doc__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000763__8, lang.RT_IntCast_J__I_NoInit(0), nil); var tps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000763__8, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000763__8, lang.RT_IntCast_J__I_NoInit(2), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(nm__6, doc__9, tps__10, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__11)) }





func A_arbace_repr_go_print_code_type_decl_A_New() *A_arbace_repr_go_print_code_type_decl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_decl_A{}; t.Ctor(); return t }
//line :1794:1
func (t *A_arbace_repr_go_print_code_type_decl_A) Ctor() {}
//line :1794:1
func (t *A_arbace_repr_go_print_code_type_decl_A) Invoke_O_O__O(self, f__0 any) any { var vec__74000767__2 any = f__0; var seq__74000768__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(vec__74000767__2); var first__74000769__4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(seq__74000768__3); var seq__74000768__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_54.GetRawRoot__O()).Invoke_O__O(seq__74000768__3); var ___6 any = first__74000769__4; var xs__7 any = seq__74000768__5; var vec__74000770__8 any; _ = ___6; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__7))) { vec__74000770__8 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__7), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__7)) } else { vec__74000770__8 = lang.Tuple_Create_O_O__IPersistentVector(nil, xs__7) }; var gdoc__9 any = /*line :1794:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__74000770__8, lang.RT_IntCast_J__I_NoInit(0), nil); var gxs__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000770__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_158.GetRawRoot__O()).Invoke_O__O(gxs__10); if


	jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O(), gxs__10) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_426.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_code_type_decl_fn__74000773_A_New_O(gxs__10); var tmp4 *jrt.Class; var fncls__362 *jrt.Class = A_arbace_repr_go_print_code_type_decl_fn__74000773_A_fn_class
		if fncls__362 == nil { var fncls__362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_196, false); A_arbace_repr_go_print_code_type_decl_fn__74000773_A_fn_class = fncls__362d; tmp4 = fncls__362d } else { tmp4 = fncls__362 }
//line :1798:1
		var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_repr_go_print_code_type_decl_fn__74000778_A_New(); var tmp7 *jrt.Class
		var fncls__363 /*line :1798:1*/*jrt.Class = A_arbace_repr_go_print_code_type_decl_fn__74000778_A_fn_class


		if fncls__363 == nil { var fncls__363d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_197, false); A_arbace_repr_go_print_code_type_decl_fn__74000778_A_fn_class = fncls__363d; tmp7 = fncls__363d } else { tmp7 = fncls__363 }
//line :1798:1
		return tmp2.Invoke_O_O_O_O_O_O__O(Lit_129, gdoc__9, gxs__10, tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), f__0) } else {
//line :1797:1
			var vec__74000780__11 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_428.GetRawRoot__O()).Invoke_O__O(xs__7); var nm__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000780__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ___13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000780__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tps__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000780__11, lang.RT_IntCast_J__I_NoInit(2), nil); var t__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000780__11, lang.RT_IntCast_J__I_NoInit(3), nil); _ = ___13






			lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_129, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_152.GetRawRoot__O()).Invoke_O_O__O(f__0, A_arbace_repr_go_print_code_A_const_318)); lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_91.GetRawRoot__O()).Invoke__O()
			return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_429.GetRawRoot__O()).Invoke_O_O_O_O__O(nm__12, tps__14, t__15, jrt.Boolean_FALSE.Ref()) } }
//line :1799:1
func A_arbace_repr_go_print_code_type_decl_fn__74000773_A_New_O(p0 any) *A_arbace_repr_go_print_code_type_decl_fn__74000773_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_decl_fn__74000773_A{}; t.Ctor_O(p0); return t }
//line :1799:1
func (t *A_arbace_repr_go_print_code_type_decl_fn__74000773_A) Ctor_O(c__gxs any) { t.F_gxs = c__gxs }
//line :1799:1
func (t *A_arbace_repr_go_print_code_type_decl_fn__74000773_A) Invoke_O_O_O__O(self, v__1, ___2 any) any { var vec__74000774__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_428.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_49.GetRawRoot__O()).Invoke_O__O(v__1)); var nm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000774__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000774__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000774__3, lang.RT_IntCast_J__I_NoInit(2), nil); var t__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000774__3, lang.RT_IntCast_J__I_NoInit(3), nil); _ = ___5; return /*line :1800:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_429.GetRawRoot__O()).Invoke_O_O_O_O__O(nm__4, tps__6, t__7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_gxs)), 1)).Ref()) }
func A_arbace_repr_go_print_code_type_decl_fn__74000778_A_New() *A_arbace_repr_go_print_code_type_decl_fn__74000778_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_type_decl_fn__74000778_A{}; t.Ctor(); return t }
//line :1801:1
func (t *A_arbace_repr_go_print_code_type_decl_fn__74000778_A) Ctor() {}
//line :1801:1
func (t *A_arbace_repr_go_print_code_type_decl_fn__74000778_A) Invoke_O_O__O(self, v__1 any) any { return lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(v__1)) }





func A_arbace_repr_go_print_code_decl_doc_and_directives_A_New() *A_arbace_repr_go_print_code_decl_doc_and_directives_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_decl_doc_and_directives_A{}; t.Ctor(); return t }
//line :1807:1
func (t *A_arbace_repr_go_print_code_decl_doc_and_directives_A) Ctor() {}
//line :1807:1
func (t *A_arbace_repr_go_print_code_decl_doc_and_directives_A) Invoke_O_O__O(self, f__0 any) any { var o__2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); var xs__3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(f__0); var G__74000784__4_ any = o__2; switch




	lang.Util_Hash_O__I_NoInit(G__74000784__4_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__74000784__4_, Lit_55) {



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3))) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3), lang.PersistentVector_EMPTY.Ref()) } else {

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O(), xs__3)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) } else { var vec__74000785__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_428.GetRawRoot__O()).Invoke_O__O(xs__3); var nm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000785__5, lang.RT_IntCast_J__I_NoInit(0), nil); var doc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000785__5, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__6))) } } }
//line :1812:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__74000784__4_, Lit_56) { var nm__5 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3); var vec__74000788__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_414.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__3)); var doc__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000788__6, lang.RT_IntCast_J__I_NoInit(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7_2, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__74000784__4_, Lit_57) {








		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3))) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3), lang.PersistentVector_EMPTY.Ref()) } else {

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O(), xs__3)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) } else { var nm__5_2 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_422.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp1 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5_2)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5_2))) } } }
//line :1812:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__74000784__4_, Lit_58) {








		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_107.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3))) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3), lang.PersistentVector_EMPTY.Ref()) } else {

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_411.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_code_A_const_36.GetRawRoot__O(), xs__3)) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) } else { var nm__5_3 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_422.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp2 *lang.Keyword = A_arbace_repr_go_print_code_A_const_138; return lang.Tuple_Create_O_O__IPersistentVector(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5_3)), lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5_3))) } } }
//line :1812:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__74000784__4_, Lit_59) { var nm__5_4 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_52.GetRawRoot__O()).Invoke_O__O(xs__3); var vec__74000791__6 any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_414.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_60.GetRawRoot__O()).Invoke_O__O(xs__3)); var doc__7_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__74000791__6, lang.RT_IntCast_J__I_NoInit(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(doc__7_3, lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_423.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__5_4))) }; default:}; return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) }
















func A_arbace_repr_go_print_code_top_decl_A_New() *A_arbace_repr_go_print_code_top_decl_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_top_decl_A{}; t.Ctor(); return t }
//line :1829:1
func (t *A_arbace_repr_go_print_code_top_decl_A) Ctor() {}
//line :1829:1
func (t *A_arbace_repr_go_print_code_top_decl_A) Invoke_O_O__O(self, f__0 any) any { var G__74000795__2_ any = lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); switch


	lang.Util_Hash_O__I_NoInit(G__74000795__2_) >> 9 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__74000795__2_, Lit_55) {


		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_430.GetRawRoot__O()).Invoke_O__O(f__0) }
//line :1832:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__74000795__2_, Lit_56) {
		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_431.GetRawRoot__O()).Invoke_O_O__O(f__0, jrt.Boolean_FALSE.Ref()) }
//line :1832:1
	case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__74000795__2_, Lit_57) {



		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_432.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_12) }
//line :1832:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__74000795__2_, Lit_58) {




		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_432.GetRawRoot__O()).Invoke_O_O__O(f__0, Lit_13) }
//line :1832:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__74000795__2_, Lit_59) {

		return lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_431.GetRawRoot__O()).Invoke_O_O__O(f__0, jrt.Boolean_TRUE.Ref()) }
//line :1832:1
	default:}; return /*line :1838:1*/ lang.IFn_Cast(A_arbace_repr_go_print_code_A_const_96.GetRawRoot__O()).Invoke_O_O__O(Lit_195, f__0) }
//line :1837:1
type A_arbace_repr_go_print_code_A struct{ jrt.Object }

var A_arbace_repr_go_print_code_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_code_A_const_0 *lang.Var

var A_arbace_repr_go_print_code_A_const_1 *lang.Var

var A_arbace_repr_go_print_code_A_const_2 any

var A_arbace_repr_go_print_code_A_const_3 any

var A_arbace_repr_go_print_code_A_const_4 any

var A_arbace_repr_go_print_code_A_const_5 any

var A_arbace_repr_go_print_code_A_const_6 *lang.Var

var A_arbace_repr_go_print_code_A_const_7 *lang.Var

var A_arbace_repr_go_print_code_A_const_8 *lang.Var

var A_arbace_repr_go_print_code_A_const_9 any

var A_arbace_repr_go_print_code_A_const_10 *lang.Var

var A_arbace_repr_go_print_code_A_const_11 *lang.Var

var A_arbace_repr_go_print_code_A_const_12 *lang.Var

var A_arbace_repr_go_print_code_A_const_13 *lang.Var

var A_arbace_repr_go_print_code_A_const_14 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_15 *lang.Var

var A_arbace_repr_go_print_code_A_const_16 *lang.Var

var A_arbace_repr_go_print_code_A_const_17 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_18 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_19 *lang.Var

var A_arbace_repr_go_print_code_A_const_20 *lang.Var

var A_arbace_repr_go_print_code_A_const_21 *lang.Var

var A_arbace_repr_go_print_code_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_23 *lang.Var

var A_arbace_repr_go_print_code_A_const_24 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_25 *lang.Var

var A_arbace_repr_go_print_code_A_const_26 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_27 *lang.Var

var A_arbace_repr_go_print_code_A_const_28 *lang.Var

var A_arbace_repr_go_print_code_A_const_29 *lang.Var

var A_arbace_repr_go_print_code_A_const_30 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_31 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_32 *lang.Var

var A_arbace_repr_go_print_code_A_const_33 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_34 *lang.Var

var A_arbace_repr_go_print_code_A_const_35 *lang.Var

var A_arbace_repr_go_print_code_A_const_36 *lang.Var

var A_arbace_repr_go_print_code_A_const_37 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_38 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_39 *lang.Var

var A_arbace_repr_go_print_code_A_const_40 *lang.Var

var A_arbace_repr_go_print_code_A_const_41 *lang.Var

var A_arbace_repr_go_print_code_A_const_42 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_43 *lang.Var

var A_arbace_repr_go_print_code_A_const_44 *lang.Var

var A_arbace_repr_go_print_code_A_const_45 *lang.Var

var A_arbace_repr_go_print_code_A_const_46 *lang.Var

var A_arbace_repr_go_print_code_A_const_47 *lang.Var

var A_arbace_repr_go_print_code_A_const_48 *lang.Var

var A_arbace_repr_go_print_code_A_const_49 *lang.Var

var A_arbace_repr_go_print_code_A_const_50 *lang.Var

var A_arbace_repr_go_print_code_A_const_51 *lang.Var

var A_arbace_repr_go_print_code_A_const_52 *lang.Var

var A_arbace_repr_go_print_code_A_const_53 *lang.Var

var A_arbace_repr_go_print_code_A_const_54 *lang.Var

var A_arbace_repr_go_print_code_A_const_55 *lang.Var

var A_arbace_repr_go_print_code_A_const_56 *lang.Var

var A_arbace_repr_go_print_code_A_const_57 *lang.Var

var A_arbace_repr_go_print_code_A_const_58 *lang.Var

var A_arbace_repr_go_print_code_A_const_59 any

var A_arbace_repr_go_print_code_A_const_60 *lang.Var

var A_arbace_repr_go_print_code_A_const_61 *lang.Var

var A_arbace_repr_go_print_code_A_const_62 *lang.Var

var A_arbace_repr_go_print_code_A_const_63 *lang.Var

var A_arbace_repr_go_print_code_A_const_64 *lang.Var

var A_arbace_repr_go_print_code_A_const_65 *lang.Var

var A_arbace_repr_go_print_code_A_const_66 *lang.Var

var A_arbace_repr_go_print_code_A_const_67 *lang.Var

var A_arbace_repr_go_print_code_A_const_68 *lang.Var

var A_arbace_repr_go_print_code_A_const_69 *lang.Var

var A_arbace_repr_go_print_code_A_const_70 *lang.Var

var A_arbace_repr_go_print_code_A_const_71 any

var A_arbace_repr_go_print_code_A_const_72 any

var A_arbace_repr_go_print_code_A_const_73 *lang.Var

var A_arbace_repr_go_print_code_A_const_74 *lang.Var

var A_arbace_repr_go_print_code_A_const_75 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_76 *lang.Var

var A_arbace_repr_go_print_code_A_const_77 *lang.Var

var A_arbace_repr_go_print_code_A_const_78 *lang.Var

var A_arbace_repr_go_print_code_A_const_79 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_80 *lang.Var

var A_arbace_repr_go_print_code_A_const_81 *lang.Var

var A_arbace_repr_go_print_code_A_const_82 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_83 *lang.Var

var A_arbace_repr_go_print_code_A_const_84 *lang.Var

var A_arbace_repr_go_print_code_A_const_85 *lang.Var

var A_arbace_repr_go_print_code_A_const_86 *lang.Var

var A_arbace_repr_go_print_code_A_const_87 *lang.Var

var A_arbace_repr_go_print_code_A_const_88 *lang.Var

var A_arbace_repr_go_print_code_A_const_89 *lang.Var

var A_arbace_repr_go_print_code_A_const_90 *lang.Var

var A_arbace_repr_go_print_code_A_const_91 *lang.Var

var A_arbace_repr_go_print_code_A_const_92 *lang.Var

var A_arbace_repr_go_print_code_A_const_93 *lang.Var

var A_arbace_repr_go_print_code_A_const_94 *lang.Var

var A_arbace_repr_go_print_code_A_const_95 *lang.Var

var A_arbace_repr_go_print_code_A_const_96 *lang.Var

var A_arbace_repr_go_print_code_A_const_97 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_98 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_99 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_100 *lang.Var

var A_arbace_repr_go_print_code_A_const_101 *lang.Var

var A_arbace_repr_go_print_code_A_const_102 *lang.Var

var A_arbace_repr_go_print_code_A_const_103 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_104 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_105 *lang.Var

var A_arbace_repr_go_print_code_A_const_106 *lang.Var

var A_arbace_repr_go_print_code_A_const_107 *lang.Var

var A_arbace_repr_go_print_code_A_const_108 *lang.Var

var A_arbace_repr_go_print_code_A_const_109 *lang.Var

var A_arbace_repr_go_print_code_A_const_110 *lang.Var

var A_arbace_repr_go_print_code_A_const_111 *lang.Var

var A_arbace_repr_go_print_code_A_const_112 *lang.Var

var A_arbace_repr_go_print_code_A_const_113 *lang.Var

var A_arbace_repr_go_print_code_A_const_114 *lang.Var

var A_arbace_repr_go_print_code_A_const_115 *lang.Var

var A_arbace_repr_go_print_code_A_const_116 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_117 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_118 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_119 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_120 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_121 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_122 *lang.Var

var A_arbace_repr_go_print_code_A_const_123 *lang.Var

var A_arbace_repr_go_print_code_A_const_124 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_125 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_126 *lang.Var

var A_arbace_repr_go_print_code_A_const_127 *lang.Var

var A_arbace_repr_go_print_code_A_const_128 *lang.Var

var A_arbace_repr_go_print_code_A_const_129 *lang.Var

var A_arbace_repr_go_print_code_A_const_130 any

var A_arbace_repr_go_print_code_A_const_131 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_132 any

var A_arbace_repr_go_print_code_A_const_133 *lang.Var

var A_arbace_repr_go_print_code_A_const_134 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_135 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_136 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_137 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_138 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_139 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_140 *lang.Var

var A_arbace_repr_go_print_code_A_const_141 *lang.Var

var A_arbace_repr_go_print_code_A_const_142 *lang.Var

var A_arbace_repr_go_print_code_A_const_143 *lang.Var

var A_arbace_repr_go_print_code_A_const_144 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_145 *lang.Var

var A_arbace_repr_go_print_code_A_const_146 *lang.Var

var A_arbace_repr_go_print_code_A_const_147 *lang.Var

var A_arbace_repr_go_print_code_A_const_148 *lang.Var

var A_arbace_repr_go_print_code_A_const_149 *lang.Var

var A_arbace_repr_go_print_code_A_const_150 *lang.Var

var A_arbace_repr_go_print_code_A_const_151 *lang.Var

var A_arbace_repr_go_print_code_A_const_152 *lang.Var

var A_arbace_repr_go_print_code_A_const_153 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_154 *lang.Var

var A_arbace_repr_go_print_code_A_const_155 *lang.Var

var A_arbace_repr_go_print_code_A_const_156 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_157 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_158 *lang.Var

var A_arbace_repr_go_print_code_A_const_159 *lang.Var

var A_arbace_repr_go_print_code_A_const_160 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_161 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_162 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_163 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_164 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_165 *lang.Var

var A_arbace_repr_go_print_code_A_const_166 *lang.Var

var A_arbace_repr_go_print_code_A_const_167 *lang.Var

var A_arbace_repr_go_print_code_A_const_168 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_169 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_170 *lang.Var

var A_arbace_repr_go_print_code_A_const_171 any

var A_arbace_repr_go_print_code_A_const_172 any

var A_arbace_repr_go_print_code_A_const_173 *lang.Var

var A_arbace_repr_go_print_code_A_const_174 *lang.Var

var A_arbace_repr_go_print_code_A_const_175 *lang.Var

var A_arbace_repr_go_print_code_A_const_176 *lang.Var

var A_arbace_repr_go_print_code_A_const_177 *lang.Var

var A_arbace_repr_go_print_code_A_const_178 *lang.Var

var A_arbace_repr_go_print_code_A_const_179 *lang.Var

var A_arbace_repr_go_print_code_A_const_180 *lang.Var

var A_arbace_repr_go_print_code_A_const_181 *lang.Var

var A_arbace_repr_go_print_code_A_const_182 *lang.Var

var A_arbace_repr_go_print_code_A_const_183 *lang.Var

var A_arbace_repr_go_print_code_A_const_184 *lang.Var

var A_arbace_repr_go_print_code_A_const_185 *lang.Var

var A_arbace_repr_go_print_code_A_const_186 *lang.Var

var A_arbace_repr_go_print_code_A_const_187 *lang.Var

var A_arbace_repr_go_print_code_A_const_188 any

var A_arbace_repr_go_print_code_A_const_189 *lang.Var

var A_arbace_repr_go_print_code_A_const_190 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_191 *lang.Var

var A_arbace_repr_go_print_code_A_const_192 *lang.Var

var A_arbace_repr_go_print_code_A_const_193 *lang.Var

var A_arbace_repr_go_print_code_A_const_194 *lang.Var

var A_arbace_repr_go_print_code_A_const_195 *lang.Var

var A_arbace_repr_go_print_code_A_const_196 *lang.Var

var A_arbace_repr_go_print_code_A_const_197 *lang.Var

var A_arbace_repr_go_print_code_A_const_198 *lang.Var

var A_arbace_repr_go_print_code_A_const_199 *lang.Var

var A_arbace_repr_go_print_code_A_const_200 *lang.Var

var A_arbace_repr_go_print_code_A_const_201 *lang.Var

var A_arbace_repr_go_print_code_A_const_202 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_203 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_204 *lang.Var

var A_arbace_repr_go_print_code_A_const_205 *lang.Var

var A_arbace_repr_go_print_code_A_const_206 *lang.Var

var A_arbace_repr_go_print_code_A_const_207 *lang.Var

var A_arbace_repr_go_print_code_A_const_208 *lang.Var

var A_arbace_repr_go_print_code_A_const_209 *lang.Var

var A_arbace_repr_go_print_code_A_const_210 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_211 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_212 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_213 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_214 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_215 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_216 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_217 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_218 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_219 *lang.Var

var A_arbace_repr_go_print_code_A_const_220 *lang.Var

var A_arbace_repr_go_print_code_A_const_221 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_222 *lang.Var

var A_arbace_repr_go_print_code_A_const_223 *lang.Var

var A_arbace_repr_go_print_code_A_const_224 *lang.Var

var A_arbace_repr_go_print_code_A_const_225 *lang.Var

var A_arbace_repr_go_print_code_A_const_226 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_227 *lang.Var

var A_arbace_repr_go_print_code_A_const_228 *lang.Var

var A_arbace_repr_go_print_code_A_const_229 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_230 *lang.Var

var A_arbace_repr_go_print_code_A_const_231 any

var A_arbace_repr_go_print_code_A_const_232 *lang.Var

var A_arbace_repr_go_print_code_A_const_233 *lang.Var

var A_arbace_repr_go_print_code_A_const_234 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_235 *lang.Var

var A_arbace_repr_go_print_code_A_const_236 *lang.Var

var A_arbace_repr_go_print_code_A_const_237 *lang.Var

var A_arbace_repr_go_print_code_A_const_238 any

var A_arbace_repr_go_print_code_A_const_239 *lang.Var

var A_arbace_repr_go_print_code_A_const_240 any

var A_arbace_repr_go_print_code_A_const_241 *lang.Var

var A_arbace_repr_go_print_code_A_const_242 any

var A_arbace_repr_go_print_code_A_const_243 any

var A_arbace_repr_go_print_code_A_const_244 any

var A_arbace_repr_go_print_code_A_const_245 any

var A_arbace_repr_go_print_code_A_const_246 any

var A_arbace_repr_go_print_code_A_const_247 *lang.Var

var A_arbace_repr_go_print_code_A_const_248 any

var A_arbace_repr_go_print_code_A_const_249 *lang.Var

var A_arbace_repr_go_print_code_A_const_250 *lang.Var

var A_arbace_repr_go_print_code_A_const_251 *lang.Var

var A_arbace_repr_go_print_code_A_const_252 *lang.Var

var A_arbace_repr_go_print_code_A_const_253 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_254 *lang.Var

var A_arbace_repr_go_print_code_A_const_255 *lang.Var

var A_arbace_repr_go_print_code_A_const_256 *lang.Var

var A_arbace_repr_go_print_code_A_const_257 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_258 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_259 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_260 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_261 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_262 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_263 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_264 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_265 any

var A_arbace_repr_go_print_code_A_const_266 *lang.Var

var A_arbace_repr_go_print_code_A_const_267 any

var A_arbace_repr_go_print_code_A_const_268 *lang.Var

var A_arbace_repr_go_print_code_A_const_269 any

var A_arbace_repr_go_print_code_A_const_270 *lang.Var

var A_arbace_repr_go_print_code_A_const_271 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_272 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_273 *lang.Var

var A_arbace_repr_go_print_code_A_const_274 any

var A_arbace_repr_go_print_code_A_const_275 any

var A_arbace_repr_go_print_code_A_const_276 any

var A_arbace_repr_go_print_code_A_const_277 any

var A_arbace_repr_go_print_code_A_const_278 any

var A_arbace_repr_go_print_code_A_const_279 *lang.Var

var A_arbace_repr_go_print_code_A_const_280 *lang.Var

var A_arbace_repr_go_print_code_A_const_281 *lang.Var

var A_arbace_repr_go_print_code_A_const_282 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_283 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_284 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_285 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_286 *lang.Var

var A_arbace_repr_go_print_code_A_const_287 *lang.Var

var A_arbace_repr_go_print_code_A_const_288 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_289 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_290 *lang.Var

var A_arbace_repr_go_print_code_A_const_291 *lang.Var

var A_arbace_repr_go_print_code_A_const_292 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_293 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_294 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_295 *lang.Var

var A_arbace_repr_go_print_code_A_const_296 *lang.Var

var A_arbace_repr_go_print_code_A_const_297 *lang.Var

var A_arbace_repr_go_print_code_A_const_298 *lang.Var

var A_arbace_repr_go_print_code_A_const_299 *lang.Var

var A_arbace_repr_go_print_code_A_const_300 *lang.Var

var A_arbace_repr_go_print_code_A_const_301 *lang.Var

var A_arbace_repr_go_print_code_A_const_302 any

var A_arbace_repr_go_print_code_A_const_303 any

var A_arbace_repr_go_print_code_A_const_304 any

var A_arbace_repr_go_print_code_A_const_305 *lang.Var

var A_arbace_repr_go_print_code_A_const_306 *lang.Var

var A_arbace_repr_go_print_code_A_const_307 *lang.Var

var A_arbace_repr_go_print_code_A_const_308 *lang.Var

var A_arbace_repr_go_print_code_A_const_309 *lang.Var

var A_arbace_repr_go_print_code_A_const_310 *lang.Var

var A_arbace_repr_go_print_code_A_const_311 *lang.Var

var A_arbace_repr_go_print_code_A_const_312 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_313 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_314 *lang.Var

var A_arbace_repr_go_print_code_A_const_315 *lang.Var

var A_arbace_repr_go_print_code_A_const_316 *lang.Var

var A_arbace_repr_go_print_code_A_const_317 *lang.Var

var A_arbace_repr_go_print_code_A_const_318 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_319 *lang.Var

var A_arbace_repr_go_print_code_A_const_320 *lang.Var

var A_arbace_repr_go_print_code_A_const_321 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_322 *lang.Var

var A_arbace_repr_go_print_code_A_const_323 *lang.Var

var A_arbace_repr_go_print_code_A_const_324 *lang.Var

var A_arbace_repr_go_print_code_A_const_325 *lang.Var

var A_arbace_repr_go_print_code_A_const_326 any

var A_arbace_repr_go_print_code_A_const_327 *lang.Var

var A_arbace_repr_go_print_code_A_const_328 any

var A_arbace_repr_go_print_code_A_const_329 any

var A_arbace_repr_go_print_code_A_const_330 any

var A_arbace_repr_go_print_code_A_const_331 *lang.Var

var A_arbace_repr_go_print_code_A_const_332 *lang.Var

var A_arbace_repr_go_print_code_A_const_333 *lang.Var

var A_arbace_repr_go_print_code_A_const_334 *lang.Var

var A_arbace_repr_go_print_code_A_const_335 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_336 *lang.Var

var A_arbace_repr_go_print_code_A_const_337 *lang.Var

var A_arbace_repr_go_print_code_A_const_338 *lang.Var

var A_arbace_repr_go_print_code_A_const_339 *lang.Var

var A_arbace_repr_go_print_code_A_const_340 *lang.Var

var A_arbace_repr_go_print_code_A_const_341 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_342 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_343 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_344 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_345 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_346 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_347 *lang.Var

var A_arbace_repr_go_print_code_A_const_348 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_349 *lang.Var

var A_arbace_repr_go_print_code_A_const_350 *lang.Var

var A_arbace_repr_go_print_code_A_const_351 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_352 *lang.Var

var A_arbace_repr_go_print_code_A_const_353 *lang.Var

var A_arbace_repr_go_print_code_A_const_354 *lang.Var

var A_arbace_repr_go_print_code_A_const_355 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_356 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_357 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_358 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_359 *lang.Var

var A_arbace_repr_go_print_code_A_const_360 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_361 *lang.Var

var A_arbace_repr_go_print_code_A_const_362 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_363 *lang.Var

var A_arbace_repr_go_print_code_A_const_364 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_365 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_366 *lang.Var

var A_arbace_repr_go_print_code_A_const_367 *lang.Var

var A_arbace_repr_go_print_code_A_const_368 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_369 *lang.Var

var A_arbace_repr_go_print_code_A_const_370 *lang.Var

var A_arbace_repr_go_print_code_A_const_371 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_372 *lang.Var

var A_arbace_repr_go_print_code_A_const_373 *lang.Var

var A_arbace_repr_go_print_code_A_const_374 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_375 *lang.Var

var A_arbace_repr_go_print_code_A_const_376 *lang.Var

var A_arbace_repr_go_print_code_A_const_377 *lang.Var

var A_arbace_repr_go_print_code_A_const_378 *lang.Var

var A_arbace_repr_go_print_code_A_const_379 any

var A_arbace_repr_go_print_code_A_const_380 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_381 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_382 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_383 *lang.Var

var A_arbace_repr_go_print_code_A_const_384 any

var A_arbace_repr_go_print_code_A_const_385 *lang.Var

var A_arbace_repr_go_print_code_A_const_386 *lang.Var

var A_arbace_repr_go_print_code_A_const_387 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_388 *lang.Var

var A_arbace_repr_go_print_code_A_const_389 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_390 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_391 *lang.Var

var A_arbace_repr_go_print_code_A_const_392 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_393 *lang.Var

var A_arbace_repr_go_print_code_A_const_394 *lang.Var

var A_arbace_repr_go_print_code_A_const_395 *lang.Var

var A_arbace_repr_go_print_code_A_const_396 *lang.Var

var A_arbace_repr_go_print_code_A_const_397 *lang.Var

var A_arbace_repr_go_print_code_A_const_398 *lang.Var

var A_arbace_repr_go_print_code_A_const_399 *lang.Var

var A_arbace_repr_go_print_code_A_const_400 *lang.Var

var A_arbace_repr_go_print_code_A_const_401 *lang.Var

var A_arbace_repr_go_print_code_A_const_402 *lang.Var

var A_arbace_repr_go_print_code_A_const_403 *lang.Var

var A_arbace_repr_go_print_code_A_const_404 *lang.Var

var A_arbace_repr_go_print_code_A_const_405 *lang.Var

var A_arbace_repr_go_print_code_A_const_406 *lang.Var

var A_arbace_repr_go_print_code_A_const_407 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_408 *lang.Var

var A_arbace_repr_go_print_code_A_const_409 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_410 *lang.Var

var A_arbace_repr_go_print_code_A_const_411 *lang.Var

var A_arbace_repr_go_print_code_A_const_412 *lang.Var

var A_arbace_repr_go_print_code_A_const_413 *lang.Var

var A_arbace_repr_go_print_code_A_const_414 *lang.Var

var A_arbace_repr_go_print_code_A_const_415 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_416 *lang.Var

var A_arbace_repr_go_print_code_A_const_417 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_418 *lang.Keyword

var A_arbace_repr_go_print_code_A_const_419 *lang.Var

var A_arbace_repr_go_print_code_A_const_420 *lang.Var

var A_arbace_repr_go_print_code_A_const_421 *lang.Var

var A_arbace_repr_go_print_code_A_const_422 *lang.Var

var A_arbace_repr_go_print_code_A_const_423 *lang.Var

var A_arbace_repr_go_print_code_A_const_424 *lang.Var

var A_arbace_repr_go_print_code_A_const_425 *lang.Var

var A_arbace_repr_go_print_code_A_const_426 *lang.Var

var A_arbace_repr_go_print_code_A_const_427 *lang.Var

var A_arbace_repr_go_print_code_A_const_428 *lang.Var

var A_arbace_repr_go_print_code_A_const_429 *lang.Var

var A_arbace_repr_go_print_code_A_const_430 *lang.Var

var A_arbace_repr_go_print_code_A_const_431 *lang.Var

var A_arbace_repr_go_print_code_A_const_432 *lang.Var

var A_arbace_repr_go_print_code_A_init jrt.ClassInit

func A_arbace_repr_go_print_code_A_Init() { if !A_arbace_repr_go_print_code_A_init.Done() { A_arbace_repr_go_print_code_A_init.Run(A_arbace_repr_go_print_code_A_clinit) } }

func A_arbace_repr_go_print_code_A_clinit() { A_arbace_repr_go_print_code_A_clinit_p0(); A_arbace_repr_go_print_code_A_clinit_p1(); A_arbace_repr_go_print_code_A_clinit_p2(); A_arbace_repr_go_print_code_A_clinit_p3(); A_arbace_repr_go_print_code_A_clinit_p4(); A_arbace_repr_go_print_code_A_clinit_p5(); A_arbace_repr_go_print_code_A_clinit_p6(); A_arbace_repr_go_print_code_A_clinit_p7(); A_arbace_repr_go_print_code_A_clinit_p8(); A_arbace_repr_go_print_code_A_clinit_p9(); A_arbace_repr_go_print_code_A_clinit_p10(); A_arbace_repr_go_print_code_A_clinit_p11(); A_arbace_repr_go_print_code_A_clinit_p12(); A_arbace_repr_go_print_code_A_clinit_p13(); A_arbace_repr_go_print_code_A_clinit_p14(); A_arbace_repr_go_print_code_A_clinit_p15(); A_arbace_repr_go_print_code_A_clinit_p16(); A_arbace_repr_go_print_code_A_clinit_p17(); A_arbace_repr_go_print_code_A_clinit_p18(); A_arbace_repr_go_print_code_A_clinit_p19(); A_arbace_repr_go_print_code_A_clinit_p20(); A_arbace_repr_go_print_code_A_clinit_p21(); A_arbace_repr_go_print_code_A_clinit_p22(); A_arbace_repr_go_print_code_A_clinit_p23(); A_arbace_repr_go_print_code_A_clinit_p24(); A_arbace_repr_go_print_code_A_clinit_p25(); A_arbace_repr_go_print_code_A_clinit_p26(); A_arbace_repr_go_print_code_A_clinit_p27(); A_arbace_repr_go_print_code_A_clinit_p28(); A_arbace_repr_go_print_code_A_clinit_p29(); A_arbace_repr_go_print_code_A_clinit_p30(); A_arbace_repr_go_print_code_A_clinit_p31(); A_arbace_repr_go_print_code_A_clinit_p32(); A_arbace_repr_go_print_code_A_clinit_p33(); A_arbace_repr_go_print_code_A_clinit_p34(); A_arbace_repr_go_print_code_A_clinit_p35() }

func A_arbace_repr_go_print_code_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_code_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 567); A_arbace_repr_go_print_code_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[134]); A_arbace_repr_go_print_code_A_const_1 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[135]); A_arbace_repr_go_print_code_A_const_2 = A_arbace_repr_go_print_code_A_const_pool.A[136]; A_arbace_repr_go_print_code_A_const_3 = A_arbace_repr_go_print_code_A_const_pool.A[137]; A_arbace_repr_go_print_code_A_const_4 = A_arbace_repr_go_print_code_A_const_pool.A[138]; A_arbace_repr_go_print_code_A_const_5 = A_arbace_repr_go_print_code_A_const_pool.A[139]; A_arbace_repr_go_print_code_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[140]); A_arbace_repr_go_print_code_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[141]); A_arbace_repr_go_print_code_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[142]); A_arbace_repr_go_print_code_A_const_9 = A_arbace_repr_go_print_code_A_const_pool.A[143]; A_arbace_repr_go_print_code_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[144]); A_arbace_repr_go_print_code_A_const_11 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[145]) }

func A_arbace_repr_go_print_code_A_clinit_p1() { A_arbace_repr_go_print_code_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[146]); A_arbace_repr_go_print_code_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[147]); A_arbace_repr_go_print_code_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[148]); A_arbace_repr_go_print_code_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[149]); A_arbace_repr_go_print_code_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[150]); A_arbace_repr_go_print_code_A_const_17 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[151]); A_arbace_repr_go_print_code_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[152]); A_arbace_repr_go_print_code_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[153]); A_arbace_repr_go_print_code_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[154]); A_arbace_repr_go_print_code_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[155]); A_arbace_repr_go_print_code_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[156]); A_arbace_repr_go_print_code_A_const_23 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[157]) }

func A_arbace_repr_go_print_code_A_clinit_p2() { A_arbace_repr_go_print_code_A_const_24 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[158]); A_arbace_repr_go_print_code_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[159]); A_arbace_repr_go_print_code_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[160]); A_arbace_repr_go_print_code_A_const_27 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[161]); A_arbace_repr_go_print_code_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[162]); A_arbace_repr_go_print_code_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[163]); A_arbace_repr_go_print_code_A_const_30 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[164]); A_arbace_repr_go_print_code_A_const_31 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[165]); A_arbace_repr_go_print_code_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[166]); A_arbace_repr_go_print_code_A_const_33 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[167]); A_arbace_repr_go_print_code_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[168]); A_arbace_repr_go_print_code_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[169]) }

func A_arbace_repr_go_print_code_A_clinit_p3() { A_arbace_repr_go_print_code_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[170]); A_arbace_repr_go_print_code_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[171]); A_arbace_repr_go_print_code_A_const_38 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[172]); A_arbace_repr_go_print_code_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[173]); A_arbace_repr_go_print_code_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[174]); A_arbace_repr_go_print_code_A_const_41 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[175]); A_arbace_repr_go_print_code_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[176]); A_arbace_repr_go_print_code_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[177]); A_arbace_repr_go_print_code_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[178]); A_arbace_repr_go_print_code_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[179]); A_arbace_repr_go_print_code_A_const_46 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[180]); A_arbace_repr_go_print_code_A_const_47 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[181]) }

func A_arbace_repr_go_print_code_A_clinit_p4() { A_arbace_repr_go_print_code_A_const_48 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[182]); A_arbace_repr_go_print_code_A_const_49 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[183]); A_arbace_repr_go_print_code_A_const_50 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[184]); A_arbace_repr_go_print_code_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[185]); A_arbace_repr_go_print_code_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[186]); A_arbace_repr_go_print_code_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[187]); A_arbace_repr_go_print_code_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[188]); A_arbace_repr_go_print_code_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[189]); A_arbace_repr_go_print_code_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[190]); A_arbace_repr_go_print_code_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[191]); A_arbace_repr_go_print_code_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[192]); A_arbace_repr_go_print_code_A_const_59 = A_arbace_repr_go_print_code_A_const_pool.A[193] }

func A_arbace_repr_go_print_code_A_clinit_p5() { A_arbace_repr_go_print_code_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[194]); A_arbace_repr_go_print_code_A_const_61 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[195]); A_arbace_repr_go_print_code_A_const_62 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[196]); A_arbace_repr_go_print_code_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[197]); A_arbace_repr_go_print_code_A_const_64 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[198]); A_arbace_repr_go_print_code_A_const_65 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[199]); A_arbace_repr_go_print_code_A_const_66 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[200]); A_arbace_repr_go_print_code_A_const_67 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[201]); A_arbace_repr_go_print_code_A_const_68 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[202]); A_arbace_repr_go_print_code_A_const_69 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[203]); A_arbace_repr_go_print_code_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[204]); A_arbace_repr_go_print_code_A_const_71 = A_arbace_repr_go_print_code_A_const_pool.A[205] }

func A_arbace_repr_go_print_code_A_clinit_p6() { A_arbace_repr_go_print_code_A_const_72 = A_arbace_repr_go_print_code_A_const_pool.A[206]; A_arbace_repr_go_print_code_A_const_73 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[207]); A_arbace_repr_go_print_code_A_const_74 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[208]); A_arbace_repr_go_print_code_A_const_75 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[209]); A_arbace_repr_go_print_code_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[210]); A_arbace_repr_go_print_code_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[211]); A_arbace_repr_go_print_code_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[212]); A_arbace_repr_go_print_code_A_const_79 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[213]); A_arbace_repr_go_print_code_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[214]); A_arbace_repr_go_print_code_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[215]); A_arbace_repr_go_print_code_A_const_82 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[216]); A_arbace_repr_go_print_code_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[217]) }

func A_arbace_repr_go_print_code_A_clinit_p7() { A_arbace_repr_go_print_code_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[218]); A_arbace_repr_go_print_code_A_const_85 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[219]); A_arbace_repr_go_print_code_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[220]); A_arbace_repr_go_print_code_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[221]); A_arbace_repr_go_print_code_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[222]); A_arbace_repr_go_print_code_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[223]); A_arbace_repr_go_print_code_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[224]); A_arbace_repr_go_print_code_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[225]); A_arbace_repr_go_print_code_A_const_92 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[226]); A_arbace_repr_go_print_code_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[227]); A_arbace_repr_go_print_code_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[228]); A_arbace_repr_go_print_code_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[229]) }

func A_arbace_repr_go_print_code_A_clinit_p8() { A_arbace_repr_go_print_code_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[230]); A_arbace_repr_go_print_code_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[231]); A_arbace_repr_go_print_code_A_const_98 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[232]); A_arbace_repr_go_print_code_A_const_99 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[233]); A_arbace_repr_go_print_code_A_const_100 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[234]); A_arbace_repr_go_print_code_A_const_101 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[235]); A_arbace_repr_go_print_code_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[236]); A_arbace_repr_go_print_code_A_const_103 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[237]); A_arbace_repr_go_print_code_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[238]); A_arbace_repr_go_print_code_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[239]); A_arbace_repr_go_print_code_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[240]); A_arbace_repr_go_print_code_A_const_107 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[241]) }

func A_arbace_repr_go_print_code_A_clinit_p9() { A_arbace_repr_go_print_code_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[242]); A_arbace_repr_go_print_code_A_const_109 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[243]); A_arbace_repr_go_print_code_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[244]); A_arbace_repr_go_print_code_A_const_111 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[245]); A_arbace_repr_go_print_code_A_const_112 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[246]); A_arbace_repr_go_print_code_A_const_113 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[247]); A_arbace_repr_go_print_code_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[248]); A_arbace_repr_go_print_code_A_const_115 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[249]); A_arbace_repr_go_print_code_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[250]); A_arbace_repr_go_print_code_A_const_117 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[251]); A_arbace_repr_go_print_code_A_const_118 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[252]); A_arbace_repr_go_print_code_A_const_119 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[253]) }

func A_arbace_repr_go_print_code_A_clinit_p10() { A_arbace_repr_go_print_code_A_const_120 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[254]); A_arbace_repr_go_print_code_A_const_121 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[255]); A_arbace_repr_go_print_code_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[256]); A_arbace_repr_go_print_code_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[257]); A_arbace_repr_go_print_code_A_const_124 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[258]); A_arbace_repr_go_print_code_A_const_125 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[259]); A_arbace_repr_go_print_code_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[260]); A_arbace_repr_go_print_code_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[261]); A_arbace_repr_go_print_code_A_const_128 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[262]); A_arbace_repr_go_print_code_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[263]); A_arbace_repr_go_print_code_A_const_130 = A_arbace_repr_go_print_code_A_const_pool.A[264]; A_arbace_repr_go_print_code_A_const_131 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[265]) }

func A_arbace_repr_go_print_code_A_clinit_p11() { A_arbace_repr_go_print_code_A_const_132 = A_arbace_repr_go_print_code_A_const_pool.A[266]; A_arbace_repr_go_print_code_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[267]); A_arbace_repr_go_print_code_A_const_134 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[268]); A_arbace_repr_go_print_code_A_const_135 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[269]); A_arbace_repr_go_print_code_A_const_136 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[270]); A_arbace_repr_go_print_code_A_const_137 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[271]); A_arbace_repr_go_print_code_A_const_138 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[272]); A_arbace_repr_go_print_code_A_const_139 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[273]); A_arbace_repr_go_print_code_A_const_140 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[274]); A_arbace_repr_go_print_code_A_const_141 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[275]); A_arbace_repr_go_print_code_A_const_142 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[276]); A_arbace_repr_go_print_code_A_const_143 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[277]) }

func A_arbace_repr_go_print_code_A_clinit_p12() { A_arbace_repr_go_print_code_A_const_144 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[278]); A_arbace_repr_go_print_code_A_const_145 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[279]); A_arbace_repr_go_print_code_A_const_146 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[280]); A_arbace_repr_go_print_code_A_const_147 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[281]); A_arbace_repr_go_print_code_A_const_148 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[282]); A_arbace_repr_go_print_code_A_const_149 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[283]); A_arbace_repr_go_print_code_A_const_150 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[284]); A_arbace_repr_go_print_code_A_const_151 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[285]); A_arbace_repr_go_print_code_A_const_152 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[286]); A_arbace_repr_go_print_code_A_const_153 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[287]); A_arbace_repr_go_print_code_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[288]); A_arbace_repr_go_print_code_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[289]) }

func A_arbace_repr_go_print_code_A_clinit_p13() { A_arbace_repr_go_print_code_A_const_156 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[290]); A_arbace_repr_go_print_code_A_const_157 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[291]); A_arbace_repr_go_print_code_A_const_158 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[292]); A_arbace_repr_go_print_code_A_const_159 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[293]); A_arbace_repr_go_print_code_A_const_160 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[294]); A_arbace_repr_go_print_code_A_const_161 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[295]); A_arbace_repr_go_print_code_A_const_162 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[296]); A_arbace_repr_go_print_code_A_const_163 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[297]); A_arbace_repr_go_print_code_A_const_164 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[298]); A_arbace_repr_go_print_code_A_const_165 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[299]); A_arbace_repr_go_print_code_A_const_166 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[300]); A_arbace_repr_go_print_code_A_const_167 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[301]) }

func A_arbace_repr_go_print_code_A_clinit_p14() { A_arbace_repr_go_print_code_A_const_168 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[302]); A_arbace_repr_go_print_code_A_const_169 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[303]); A_arbace_repr_go_print_code_A_const_170 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[304]); A_arbace_repr_go_print_code_A_const_171 = A_arbace_repr_go_print_code_A_const_pool.A[305]; A_arbace_repr_go_print_code_A_const_172 = A_arbace_repr_go_print_code_A_const_pool.A[306]; A_arbace_repr_go_print_code_A_const_173 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[307]); A_arbace_repr_go_print_code_A_const_174 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[308]); A_arbace_repr_go_print_code_A_const_175 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[309]); A_arbace_repr_go_print_code_A_const_176 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[310]); A_arbace_repr_go_print_code_A_const_177 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[311]); A_arbace_repr_go_print_code_A_const_178 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[312]); A_arbace_repr_go_print_code_A_const_179 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[313]) }

func A_arbace_repr_go_print_code_A_clinit_p15() { A_arbace_repr_go_print_code_A_const_180 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[314]); A_arbace_repr_go_print_code_A_const_181 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[315]); A_arbace_repr_go_print_code_A_const_182 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[316]); A_arbace_repr_go_print_code_A_const_183 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[317]); A_arbace_repr_go_print_code_A_const_184 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[318]); A_arbace_repr_go_print_code_A_const_185 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[319]); A_arbace_repr_go_print_code_A_const_186 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[320]); A_arbace_repr_go_print_code_A_const_187 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[321]); A_arbace_repr_go_print_code_A_const_188 = A_arbace_repr_go_print_code_A_const_pool.A[322]; A_arbace_repr_go_print_code_A_const_189 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[323]); A_arbace_repr_go_print_code_A_const_190 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[324]); A_arbace_repr_go_print_code_A_const_191 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[325]) }

func A_arbace_repr_go_print_code_A_clinit_p16() { A_arbace_repr_go_print_code_A_const_192 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[326]); A_arbace_repr_go_print_code_A_const_193 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[327]); A_arbace_repr_go_print_code_A_const_194 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[328]); A_arbace_repr_go_print_code_A_const_195 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[329]); A_arbace_repr_go_print_code_A_const_196 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[330]); A_arbace_repr_go_print_code_A_const_197 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[331]); A_arbace_repr_go_print_code_A_const_198 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[332]); A_arbace_repr_go_print_code_A_const_199 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[333]); A_arbace_repr_go_print_code_A_const_200 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[334]); A_arbace_repr_go_print_code_A_const_201 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[335]); A_arbace_repr_go_print_code_A_const_202 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[336]); A_arbace_repr_go_print_code_A_const_203 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[337]) }

func A_arbace_repr_go_print_code_A_clinit_p17() { A_arbace_repr_go_print_code_A_const_204 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[338]); A_arbace_repr_go_print_code_A_const_205 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[339]); A_arbace_repr_go_print_code_A_const_206 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[340]); A_arbace_repr_go_print_code_A_const_207 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[341]); A_arbace_repr_go_print_code_A_const_208 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[342]); A_arbace_repr_go_print_code_A_const_209 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[343]); A_arbace_repr_go_print_code_A_const_210 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[344]); A_arbace_repr_go_print_code_A_const_211 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[345]); A_arbace_repr_go_print_code_A_const_212 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[346]); A_arbace_repr_go_print_code_A_const_213 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[347]); A_arbace_repr_go_print_code_A_const_214 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[348]); A_arbace_repr_go_print_code_A_const_215 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[349]) }

func A_arbace_repr_go_print_code_A_clinit_p18() { A_arbace_repr_go_print_code_A_const_216 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[350]); A_arbace_repr_go_print_code_A_const_217 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[351]); A_arbace_repr_go_print_code_A_const_218 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[352]); A_arbace_repr_go_print_code_A_const_219 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[353]); A_arbace_repr_go_print_code_A_const_220 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[354]); A_arbace_repr_go_print_code_A_const_221 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[355]); A_arbace_repr_go_print_code_A_const_222 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[356]); A_arbace_repr_go_print_code_A_const_223 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[357]); A_arbace_repr_go_print_code_A_const_224 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[358]); A_arbace_repr_go_print_code_A_const_225 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[359]); A_arbace_repr_go_print_code_A_const_226 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[360]); A_arbace_repr_go_print_code_A_const_227 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[361]) }

func A_arbace_repr_go_print_code_A_clinit_p19() { A_arbace_repr_go_print_code_A_const_228 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[362]); A_arbace_repr_go_print_code_A_const_229 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[363]); A_arbace_repr_go_print_code_A_const_230 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[364]); A_arbace_repr_go_print_code_A_const_231 = A_arbace_repr_go_print_code_A_const_pool.A[365]; A_arbace_repr_go_print_code_A_const_232 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[366]); A_arbace_repr_go_print_code_A_const_233 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[367]); A_arbace_repr_go_print_code_A_const_234 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[368]); A_arbace_repr_go_print_code_A_const_235 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[369]); A_arbace_repr_go_print_code_A_const_236 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[370]); A_arbace_repr_go_print_code_A_const_237 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[371]); A_arbace_repr_go_print_code_A_const_238 = A_arbace_repr_go_print_code_A_const_pool.A[372]; A_arbace_repr_go_print_code_A_const_239 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[373]) }

func A_arbace_repr_go_print_code_A_clinit_p20() { A_arbace_repr_go_print_code_A_const_240 = A_arbace_repr_go_print_code_A_const_pool.A[374]; A_arbace_repr_go_print_code_A_const_241 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[375]); A_arbace_repr_go_print_code_A_const_242 = A_arbace_repr_go_print_code_A_const_pool.A[376]; A_arbace_repr_go_print_code_A_const_243 = A_arbace_repr_go_print_code_A_const_pool.A[377]; A_arbace_repr_go_print_code_A_const_244 = A_arbace_repr_go_print_code_A_const_pool.A[378]; A_arbace_repr_go_print_code_A_const_245 = A_arbace_repr_go_print_code_A_const_pool.A[379]; A_arbace_repr_go_print_code_A_const_246 = A_arbace_repr_go_print_code_A_const_pool.A[380]; A_arbace_repr_go_print_code_A_const_247 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[381]); A_arbace_repr_go_print_code_A_const_248 = A_arbace_repr_go_print_code_A_const_pool.A[382]; A_arbace_repr_go_print_code_A_const_249 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[383]); A_arbace_repr_go_print_code_A_const_250 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[384]); A_arbace_repr_go_print_code_A_const_251 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[385]); A_arbace_repr_go_print_code_A_const_252 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[386]) }

func A_arbace_repr_go_print_code_A_clinit_p21() { A_arbace_repr_go_print_code_A_const_253 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[387]); A_arbace_repr_go_print_code_A_const_254 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[388]); A_arbace_repr_go_print_code_A_const_255 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[389]); A_arbace_repr_go_print_code_A_const_256 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[390]); A_arbace_repr_go_print_code_A_const_257 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[391]); A_arbace_repr_go_print_code_A_const_258 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[392]); A_arbace_repr_go_print_code_A_const_259 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[393]); A_arbace_repr_go_print_code_A_const_260 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[394]); A_arbace_repr_go_print_code_A_const_261 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[395]); A_arbace_repr_go_print_code_A_const_262 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[396]); A_arbace_repr_go_print_code_A_const_263 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[397]); A_arbace_repr_go_print_code_A_const_264 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[398]) }

func A_arbace_repr_go_print_code_A_clinit_p22() { A_arbace_repr_go_print_code_A_const_265 = A_arbace_repr_go_print_code_A_const_pool.A[399]; A_arbace_repr_go_print_code_A_const_266 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[400]); A_arbace_repr_go_print_code_A_const_267 = A_arbace_repr_go_print_code_A_const_pool.A[401]; A_arbace_repr_go_print_code_A_const_268 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[402]); A_arbace_repr_go_print_code_A_const_269 = A_arbace_repr_go_print_code_A_const_pool.A[403]; A_arbace_repr_go_print_code_A_const_270 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[404]); A_arbace_repr_go_print_code_A_const_271 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[405]); A_arbace_repr_go_print_code_A_const_272 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[406]); A_arbace_repr_go_print_code_A_const_273 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[407]); A_arbace_repr_go_print_code_A_const_274 = A_arbace_repr_go_print_code_A_const_pool.A[408]; A_arbace_repr_go_print_code_A_const_275 = A_arbace_repr_go_print_code_A_const_pool.A[409]; A_arbace_repr_go_print_code_A_const_276 = A_arbace_repr_go_print_code_A_const_pool.A[410]; A_arbace_repr_go_print_code_A_const_277 = A_arbace_repr_go_print_code_A_const_pool.A[411]; A_arbace_repr_go_print_code_A_const_278 = A_arbace_repr_go_print_code_A_const_pool.A[412] }

func A_arbace_repr_go_print_code_A_clinit_p23() { A_arbace_repr_go_print_code_A_const_279 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[413]); A_arbace_repr_go_print_code_A_const_280 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[414]); A_arbace_repr_go_print_code_A_const_281 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[415]); A_arbace_repr_go_print_code_A_const_282 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[416]); A_arbace_repr_go_print_code_A_const_283 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[417]); A_arbace_repr_go_print_code_A_const_284 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[418]); A_arbace_repr_go_print_code_A_const_285 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[419]); A_arbace_repr_go_print_code_A_const_286 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[420]); A_arbace_repr_go_print_code_A_const_287 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[421]); A_arbace_repr_go_print_code_A_const_288 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[422]); A_arbace_repr_go_print_code_A_const_289 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[423]); A_arbace_repr_go_print_code_A_const_290 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[424]) }

func A_arbace_repr_go_print_code_A_clinit_p24() { A_arbace_repr_go_print_code_A_const_291 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[425]); A_arbace_repr_go_print_code_A_const_292 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[426]); A_arbace_repr_go_print_code_A_const_293 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[427]); A_arbace_repr_go_print_code_A_const_294 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[428]); A_arbace_repr_go_print_code_A_const_295 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[429]); A_arbace_repr_go_print_code_A_const_296 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[430]); A_arbace_repr_go_print_code_A_const_297 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[431]); A_arbace_repr_go_print_code_A_const_298 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[432]); A_arbace_repr_go_print_code_A_const_299 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[433]); A_arbace_repr_go_print_code_A_const_300 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[434]); A_arbace_repr_go_print_code_A_const_301 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[435]); A_arbace_repr_go_print_code_A_const_302 = A_arbace_repr_go_print_code_A_const_pool.A[436] }

func A_arbace_repr_go_print_code_A_clinit_p25() { A_arbace_repr_go_print_code_A_const_303 = A_arbace_repr_go_print_code_A_const_pool.A[437]; A_arbace_repr_go_print_code_A_const_304 = A_arbace_repr_go_print_code_A_const_pool.A[438]; A_arbace_repr_go_print_code_A_const_305 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[439]); A_arbace_repr_go_print_code_A_const_306 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[440]); A_arbace_repr_go_print_code_A_const_307 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[441]); A_arbace_repr_go_print_code_A_const_308 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[442]); A_arbace_repr_go_print_code_A_const_309 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[443]); A_arbace_repr_go_print_code_A_const_310 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[444]); A_arbace_repr_go_print_code_A_const_311 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[445]); A_arbace_repr_go_print_code_A_const_312 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[446]); A_arbace_repr_go_print_code_A_const_313 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[447]); A_arbace_repr_go_print_code_A_const_314 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[448]) }

func A_arbace_repr_go_print_code_A_clinit_p26() { A_arbace_repr_go_print_code_A_const_315 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[449]); A_arbace_repr_go_print_code_A_const_316 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[450]); A_arbace_repr_go_print_code_A_const_317 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[451]); A_arbace_repr_go_print_code_A_const_318 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[452]); A_arbace_repr_go_print_code_A_const_319 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[453]); A_arbace_repr_go_print_code_A_const_320 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[454]); A_arbace_repr_go_print_code_A_const_321 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[455]); A_arbace_repr_go_print_code_A_const_322 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[456]); A_arbace_repr_go_print_code_A_const_323 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[457]); A_arbace_repr_go_print_code_A_const_324 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[458]); A_arbace_repr_go_print_code_A_const_325 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[459]); A_arbace_repr_go_print_code_A_const_326 = A_arbace_repr_go_print_code_A_const_pool.A[460] }

func A_arbace_repr_go_print_code_A_clinit_p27() { A_arbace_repr_go_print_code_A_const_327 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[461]); A_arbace_repr_go_print_code_A_const_328 = A_arbace_repr_go_print_code_A_const_pool.A[462]; A_arbace_repr_go_print_code_A_const_329 = A_arbace_repr_go_print_code_A_const_pool.A[463]; A_arbace_repr_go_print_code_A_const_330 = A_arbace_repr_go_print_code_A_const_pool.A[464]; A_arbace_repr_go_print_code_A_const_331 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[465]); A_arbace_repr_go_print_code_A_const_332 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[466]); A_arbace_repr_go_print_code_A_const_333 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[467]); A_arbace_repr_go_print_code_A_const_334 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[468]); A_arbace_repr_go_print_code_A_const_335 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[469]); A_arbace_repr_go_print_code_A_const_336 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[470]); A_arbace_repr_go_print_code_A_const_337 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[471]); A_arbace_repr_go_print_code_A_const_338 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[472]) }

func A_arbace_repr_go_print_code_A_clinit_p28() { A_arbace_repr_go_print_code_A_const_339 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[473]); A_arbace_repr_go_print_code_A_const_340 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[474]); A_arbace_repr_go_print_code_A_const_341 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[475]); A_arbace_repr_go_print_code_A_const_342 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[476]); A_arbace_repr_go_print_code_A_const_343 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[477]); A_arbace_repr_go_print_code_A_const_344 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[478]); A_arbace_repr_go_print_code_A_const_345 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[479]); A_arbace_repr_go_print_code_A_const_346 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[480]); A_arbace_repr_go_print_code_A_const_347 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[481]); A_arbace_repr_go_print_code_A_const_348 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[482]); A_arbace_repr_go_print_code_A_const_349 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[483]); A_arbace_repr_go_print_code_A_const_350 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[484]) }

func A_arbace_repr_go_print_code_A_clinit_p29() { A_arbace_repr_go_print_code_A_const_351 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[485]); A_arbace_repr_go_print_code_A_const_352 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[486]); A_arbace_repr_go_print_code_A_const_353 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[487]); A_arbace_repr_go_print_code_A_const_354 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[488]); A_arbace_repr_go_print_code_A_const_355 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[489]); A_arbace_repr_go_print_code_A_const_356 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[490]); A_arbace_repr_go_print_code_A_const_357 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[491]); A_arbace_repr_go_print_code_A_const_358 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[492]); A_arbace_repr_go_print_code_A_const_359 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[493]); A_arbace_repr_go_print_code_A_const_360 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[494]); A_arbace_repr_go_print_code_A_const_361 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[495]); A_arbace_repr_go_print_code_A_const_362 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[496]) }

func A_arbace_repr_go_print_code_A_clinit_p30() { A_arbace_repr_go_print_code_A_const_363 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[497]); A_arbace_repr_go_print_code_A_const_364 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[498]); A_arbace_repr_go_print_code_A_const_365 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[499]); A_arbace_repr_go_print_code_A_const_366 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[500]); A_arbace_repr_go_print_code_A_const_367 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[501]); A_arbace_repr_go_print_code_A_const_368 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[502]); A_arbace_repr_go_print_code_A_const_369 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[503]); A_arbace_repr_go_print_code_A_const_370 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[504]); A_arbace_repr_go_print_code_A_const_371 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[505]); A_arbace_repr_go_print_code_A_const_372 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[506]); A_arbace_repr_go_print_code_A_const_373 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[507]); A_arbace_repr_go_print_code_A_const_374 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[508]) }

func A_arbace_repr_go_print_code_A_clinit_p31() { A_arbace_repr_go_print_code_A_const_375 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[509]); A_arbace_repr_go_print_code_A_const_376 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[510]); A_arbace_repr_go_print_code_A_const_377 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[511]); A_arbace_repr_go_print_code_A_const_378 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[512]); A_arbace_repr_go_print_code_A_const_379 = A_arbace_repr_go_print_code_A_const_pool.A[513]; A_arbace_repr_go_print_code_A_const_380 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[514]); A_arbace_repr_go_print_code_A_const_381 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[515]); A_arbace_repr_go_print_code_A_const_382 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[516]); A_arbace_repr_go_print_code_A_const_383 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[517]); A_arbace_repr_go_print_code_A_const_384 = A_arbace_repr_go_print_code_A_const_pool.A[518]; A_arbace_repr_go_print_code_A_const_385 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[519]); A_arbace_repr_go_print_code_A_const_386 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[520]) }

func A_arbace_repr_go_print_code_A_clinit_p32() { A_arbace_repr_go_print_code_A_const_387 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[521]); A_arbace_repr_go_print_code_A_const_388 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[522]); A_arbace_repr_go_print_code_A_const_389 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[523]); A_arbace_repr_go_print_code_A_const_390 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[524]); A_arbace_repr_go_print_code_A_const_391 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[525]); A_arbace_repr_go_print_code_A_const_392 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[526]); A_arbace_repr_go_print_code_A_const_393 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[527]); A_arbace_repr_go_print_code_A_const_394 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[528]); A_arbace_repr_go_print_code_A_const_395 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[529]); A_arbace_repr_go_print_code_A_const_396 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[530]); A_arbace_repr_go_print_code_A_const_397 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[531]); A_arbace_repr_go_print_code_A_const_398 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[532]) }

func A_arbace_repr_go_print_code_A_clinit_p33() { A_arbace_repr_go_print_code_A_const_399 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[533]); A_arbace_repr_go_print_code_A_const_400 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[534]); A_arbace_repr_go_print_code_A_const_401 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[535]); A_arbace_repr_go_print_code_A_const_402 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[536]); A_arbace_repr_go_print_code_A_const_403 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[537]); A_arbace_repr_go_print_code_A_const_404 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[538]); A_arbace_repr_go_print_code_A_const_405 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[539]); A_arbace_repr_go_print_code_A_const_406 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[540]); A_arbace_repr_go_print_code_A_const_407 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[541]); A_arbace_repr_go_print_code_A_const_408 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[542]); A_arbace_repr_go_print_code_A_const_409 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[543]); A_arbace_repr_go_print_code_A_const_410 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[544]) }

func A_arbace_repr_go_print_code_A_clinit_p34() { A_arbace_repr_go_print_code_A_const_411 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[545]); A_arbace_repr_go_print_code_A_const_412 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[546]); A_arbace_repr_go_print_code_A_const_413 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[547]); A_arbace_repr_go_print_code_A_const_414 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[548]); A_arbace_repr_go_print_code_A_const_415 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[549]); A_arbace_repr_go_print_code_A_const_416 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[550]); A_arbace_repr_go_print_code_A_const_417 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[551]); A_arbace_repr_go_print_code_A_const_418 = lang.Keyword_Cast(A_arbace_repr_go_print_code_A_const_pool.A[552]); A_arbace_repr_go_print_code_A_const_419 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[553]); A_arbace_repr_go_print_code_A_const_420 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[554]); A_arbace_repr_go_print_code_A_const_421 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[555]); A_arbace_repr_go_print_code_A_const_422 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[556]) }

func A_arbace_repr_go_print_code_A_clinit_p35() { A_arbace_repr_go_print_code_A_const_423 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[557]); A_arbace_repr_go_print_code_A_const_424 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[558]); A_arbace_repr_go_print_code_A_const_425 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[559]); A_arbace_repr_go_print_code_A_const_426 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[560]); A_arbace_repr_go_print_code_A_const_427 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[561]); A_arbace_repr_go_print_code_A_const_428 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[562]); A_arbace_repr_go_print_code_A_const_429 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[563]); A_arbace_repr_go_print_code_A_const_430 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[564]); A_arbace_repr_go_print_code_A_const_431 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[565]); A_arbace_repr_go_print_code_A_const_432 = lang.Var_Cast(A_arbace_repr_go_print_code_A_const_pool.A[566]) }

func A_arbace_repr_go_print_code_A_New() *A_arbace_repr_go_print_code_A { A_arbace_repr_go_print_code_A_Init(); t := &A_arbace_repr_go_print_code_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_code_A) Ctor() {}

func (t *A_arbace_repr_go_print_code_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_A_class }

func (t *A_arbace_repr_go_print_code_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_A); return ok }

func A_arbace_repr_go_print_code_A_Cast(x any) *A_arbace_repr_go_print_code_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_A_class)) }; return v }



type A_arbace_repr_go_print_code_args_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_args_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_assign_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_assign_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_begins_with_star_or_paren_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_bin_op_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_bin_op_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_bin_prec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_bin_prec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binary_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_binary_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binary_expr_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_binary_expr_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binary_expr_fn__74000329_A struct{ j2g_header uint64; F_f, F_depth any }

var A_arbace_repr_go_print_code_binary_expr_fn__74000329_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binary_expr_fn__74000331_A struct{ j2g_header uint64; F_depth any }

var A_arbace_repr_go_print_code_binary_expr_fn__74000331_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_bind_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_bind_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binding_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_binding_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_binding_stmt_fn__74000455_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A struct{ j2g_header uint64; F_depth int64 }

var A_arbace_repr_go_print_code_binding_stmt_fn__74000459_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_binding_stmt_names__74000457_A struct{ j2g_header uint64; F_ts any }

var A_arbace_repr_go_print_code_binding_stmt_names__74000457_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_block_body_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_block_body_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_block_body_fn__74000663_A struct{ j2g_header uint64; F_start any }

var A_arbace_repr_go_print_code_block_body_fn__74000663_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_block_body_fn__74000665_A struct{ j2g_header uint64; F_forms, F_results_QMARK_, F_indent any }

var A_arbace_repr_go_print_code_block_body_fn__74000665_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_body_offset_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_body_offset_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_braces_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_braces_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_branch_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_branch_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_branch_opts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_branch_opts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_break_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_break_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_break_line_fn__74000087_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_go_print_code_break_line_fn__74000087_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_breaks_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_breaks_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_breaks_of_fn__74000083_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_breaks_of_fn__74000083_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_call_args_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_call_args_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_call_args_fn__74000334_A struct{ j2g_header uint64; F_depth, F_f any }

var A_arbace_repr_go_print_code_call_args_fn__74000334_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_callee_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_callee_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_case_exprs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_case_exprs_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_case_exprs_fn__74000541_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_case_exprs_fn__74000541_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_case_types_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_case_types_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_case_types_fn__74000545_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_case_types_fn__74000545_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_chan_type_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_chan_type_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_child_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_child_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_child_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_child_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_clause_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_clause_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_clause_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_clause_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_clause_list_fn__74000534_A struct{ j2g_header uint64; F_i int64; F_indent, F_print_head, F_c any }

var A_arbace_repr_go_print_code_clause_list_fn__74000534_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_comm_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_comm_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_comma_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_comma_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_comma_list_fn__74000095_A struct{ j2g_header uint64; F_parent, F_offset any }

var A_arbace_repr_go_print_code_comma_list_fn__74000095_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_comma_list_fn__74000097_A struct{ j2g_header uint64; F_i int64; F_print_one, F_xs any }

var A_arbace_repr_go_print_code_comma_list_fn__74000097_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_composite_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_fn__74000341_A struct{ j2g_header uint64; F_f, F_t any }

var A_arbace_repr_go_print_code_composite_lit_fn__74000341_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A struct{ j2g_header uint64; F_f, F_brk any }

var A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000342_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A struct{ j2g_header uint64; F_start any }

var A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000344_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A struct{ j2g_header uint64; F_f any; F_n int32; F_el, F_multi_QMARK_ any }

var A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000353_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A struct{ j2g_header uint64; F_f any; F_n int32; F_el, F_multi_QMARK_ any }

var A_arbace_repr_go_print_code_composite_lit_fn__74000341_fn__74000359_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_bind_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_bind_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_bind_QMARK__fn__74000620_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_group_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_group_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_group_fn__74000637_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_group_fn__74000637_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_group_fn__74000642_A struct{ j2g_header uint64; F_keep any; F_j int64; F_its, F_indent, F_specs any }

var A_arbace_repr_go_print_code_const_group_fn__74000642_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_spec_fn__74000633_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_spec_fn__74000633_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_var_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_var_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_var_decl_fn__74000746_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A struct{ j2g_header uint64; F_specs any; F_group_QMARK_ bool; F_keep any }

var A_arbace_repr_go_print_code_const_var_decl_fn__74000748_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_const_var_decl_fn__74000753_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_control_clause_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_control_clause_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_cutoff_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_cutoff_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_cutoff_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_cutoff_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_decl_doc_and_directives_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_decl_doc_and_directives_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_diff_prec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_diff_prec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_directives_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_fn__74000189_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_directives_of_fn__74000189_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A struct{ j2g_header uint64; F_s__74000170, F_iter__74000169 any }

var A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A struct{ j2g_header uint64; F_k, F_s__74000172, F_iter__74000171 any }

var A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A struct{ j2g_header uint64; F_k, F_b__74000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_code_directives_of_iter__74000169__74000175_fn__74000176_iter__74000171__74000180_fn__74000181_fn__74000182_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_doc_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_doc_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_element_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_element_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_element_list_fn__74000125_A struct{ j2g_header uint64; F_parent, F_target, F_brk, F_offset any }

var A_arbace_repr_go_print_code_element_list_fn__74000125_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_element_list_fn__74000127_A struct{ j2g_header uint64; F_x, F_print_one any; F_i int64 }

var A_arbace_repr_go_print_code_element_list_fn__74000127_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_else_part_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_else_part_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_eval74000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_code_eval74000004_A_New() *A_arbace_repr_go_print_code_eval74000004_A { t := &A_arbace_repr_go_print_code_eval74000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_code_eval74000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_code_eval74000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_eval74000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_eval74000004_A_class }

func (t *A_arbace_repr_go_print_code_eval74000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_eval74000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_eval74000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_eval74000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_eval74000004_A); return ok }

func A_arbace_repr_go_print_code_eval74000004_A_Cast(x any) *A_arbace_repr_go_print_code_eval74000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_eval74000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_eval74000004_A_class)) }; return v }



type A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_eval74000004_loading__1927001464__auto____74000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_eval74000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_code_eval74000008_A_New() *A_arbace_repr_go_print_code_eval74000008_A { t := &A_arbace_repr_go_print_code_eval74000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_code_eval74000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_code_eval74000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_eval74000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_eval74000008_A_class }

func (t *A_arbace_repr_go_print_code_eval74000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_eval74000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_eval74000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_eval74000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_eval74000008_A); return ok }

func A_arbace_repr_go_print_code_eval74000008_A_Cast(x any) *A_arbace_repr_go_print_code_eval74000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_eval74000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_eval74000008_A_class)) }; return v }



type A_arbace_repr_go_print_code_eval74000008_fn__74000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_eval74000008_fn__74000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_eval74000017_A struct{ jrt.Object }

func A_arbace_repr_go_print_code_eval74000017_A_New() *A_arbace_repr_go_print_code_eval74000017_A { t := &A_arbace_repr_go_print_code_eval74000017_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_code_eval74000017_A) Ctor() {}

func (t *A_arbace_repr_go_print_code_eval74000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_code_eval74000017_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_code_eval74000017_A_class }

func (t *A_arbace_repr_go_print_code_eval74000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_code_eval74000017_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_code_eval74000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_code_eval74000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_code_eval74000017_A); return ok }

func A_arbace_repr_go_print_code_eval74000017_A_Cast(x any) *A_arbace_repr_go_print_code_eval74000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_code_eval74000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_code_eval74000017_A_class)) }; return v }



type A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_eval74000017___GT_PL__74000031_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_eval74000017_map__GT_PL__74000033_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr0_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_expr0_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_expr1_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000395_A struct{ j2g_header uint64; F_depth, F_f any }

var A_arbace_repr_go_print_code_expr1_fn__74000395_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000397_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_expr1_fn__74000397_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000399_A struct{ j2g_header uint64; F_x any }

var A_arbace_repr_go_print_code_expr1_fn__74000399_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000414_A struct{ j2g_header uint64; F_depth any }

var A_arbace_repr_go_print_code_expr1_fn__74000414_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000419_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_expr1_fn__74000419_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000421_A struct{ j2g_header uint64; F_depth any }

var A_arbace_repr_go_print_code_expr1_fn__74000421_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000429_A struct{ j2g_header uint64; F_i, F_depth any }

var A_arbace_repr_go_print_code_expr1_fn__74000429_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000434_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_expr1_fn__74000434_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr1_fn__74000436_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_expr1_fn__74000436_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_expr_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expr_list_fn__74000447_A struct{ j2g_header uint64; F_depth any }

var A_arbace_repr_go_print_code_expr_list_fn__74000447_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_expression_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_expression_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_fail_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_body_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_field_body_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_field_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_fn__74000233_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_field_list_fn__74000233_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_fn__74000235_A struct{ j2g_header uint64; F_start any }

var A_arbace_repr_go_print_code_field_list_fn__74000235_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_fn__74000237_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_field_list_fn__74000237_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_fn__74000249_A struct{ j2g_header uint64; F_indent, F_t, F_doc, F_struct_QMARK_, F_last_start, F_pre, F_sep, F_g any; F_i int64 }

var A_arbace_repr_go_print_code_field_list_fn__74000249_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A struct{ j2g_header uint64; F_s__74000224, F_iter__74000223 any }

var A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__74000226 any }

var A_arbace_repr_go_print_code_field_list_iter__74000223__74000227_fn__74000228_fn__74000229_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_flatten_stmts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_flatten_stmts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A struct{ j2g_header uint64; F_parent any; F_n int32; F_offset, F_brk any }

var A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_flatten_stmts_fn__74000601_fn__74000606_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_for_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_for_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_fp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_fp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_full_group_close_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_full_group_close_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_full_group_open_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_full_group_open_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_full_in_group_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_full_in_group_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_func_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_func_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_func_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_func_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_func_type_sig_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_func_type_sig_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_generic_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_generic_type_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_go_sym_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_go_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_consts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_consts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_consts_fn__74000623_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_consts_fn__74000623_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_decl_fn__74000737_A struct{ j2g_header uint64; F_t, F_last_start, F_pre any; F_i int64 }

var A_arbace_repr_go_print_code_group_decl_fn__74000737_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_entries_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_entries_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_entries_fn__74000134_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_entries_fn__74000134_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_entries_fn__74000136_A struct{ j2g_header uint64; F_explicit_QMARK_ any }

var A_arbace_repr_go_print_code_group_entries_fn__74000136_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_group_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_group_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_groupable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_groupable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_ident_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_ident_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_if_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_if_like_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_if_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_if_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_if_stmt_braces__74000484_A struct{ j2g_header uint64; F_cps any }

var A_arbace_repr_go_print_code_if_stmt_braces__74000484_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_iface_method_sig_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_iface_method_sig_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_interface_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_interface_method_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_item_group_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_item_group_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_item_start_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_item_start_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_item_t_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_item_t_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_keep_type_column_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_keep_type_column_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_keep_type_column_fn__74000721_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_key_size_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_key_size_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_label_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_label_name_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_label_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_label_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_label_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_label_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_label_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_label_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_line_indent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_line_indent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_line_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_line_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_lit_elements_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_lit_elements_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_lit_list_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_lit_list_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_lit_type_needs_parens_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_literal_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_literal_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_n_values_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_n_values_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_name_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_name_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_name_tok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_name_tok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_negative_literal_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_negative_literal_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_new_arg_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_new_arg_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_next_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_next_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_next_targets_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_next_targets_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_one_line_fields_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_one_line_fields_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A struct{ j2g_header uint64; F_g, F_x, F_method_QMARK_ any }

var A_arbace_repr_go_print_code_one_line_fields_QMARK__fn__74000203_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_op_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_op_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_op_pos_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_op_pos_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_param_entries_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_param_entries_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_param_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_param_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_param_list_fn__74000144_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_param_list_fn__74000144_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_paren_operand_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_paren_operand_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_paren_operand_fn__74000325_A struct{ j2g_header uint64; F_x any }

var A_arbace_repr_go_print_code_paren_operand_fn__74000325_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_parse_decl_head_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_parse_decl_head_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_parse_type_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_parse_type_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_pl_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_pl_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_pre_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_pre_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_prec_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_prec_of_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_pl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_print_pl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_pl_fn__74000391_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_print_pl_fn__74000391_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_results_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_print_results_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_results_fn__74000148_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_print_results_fn__74000148_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_print_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_print_stmt_fn__74000598_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_print_stmt_fn__74000598_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_ptok_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_ptok_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_ptok_STAR__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_ptok_STAR__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_range_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_range_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_range_stmt_fn__74000591_A struct{ j2g_header uint64; F_f, F_assign_QMARK_, F_v any }

var A_arbace_repr_go_print_code_range_stmt_fn__74000591_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_range_stmt_fn__74000591_fn__74000592_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_reduce_depth_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_reduce_depth_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_results_entries_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_results_entries_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_room_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_room_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_select_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_select_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_signature_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_signature_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_simple_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_simple_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_slice_expr_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_slice_expr_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_slice_expr_fn__74000368_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_slice_expr_fn__74000368_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_slice_expr_fn__74000370_A struct{ j2g_header uint64; F_depth, F_idx, F_blanks_QMARK_ any }

var A_arbace_repr_go_print_code_slice_expr_fn__74000370_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_spec_name_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_spec_name_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_spec_t_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_spec_t_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_statement_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_statement_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_stmt_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_stmt_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_stmt_list_fn__74000654_A struct{ j2g_header uint64; F_n int32; F_results_QMARK_, F_indent, F_items any; F_i int64; F_it any }

var A_arbace_repr_go_print_code_stmt_list_fn__74000654_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A struct{ j2g_header uint64; F_n int32; F_f, F_results_QMARK_, F_indent, F_label_QMARK_ any; F_i int64; F_it any }

var A_arbace_repr_go_print_code_stmt_list_fn__74000654_fn__74000655_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_stmt_list_one_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_stmt_list_one_line_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_struct_fields_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_struct_fields_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A struct{ j2g_header uint64; F_s__74000207, F_iter__74000206 any }

var A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A struct{ j2g_header uint64; F_b__74000209 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_code_struct_fields_iter__74000206__74000210_fn__74000211_fn__74000212_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_struct_tag_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_struct_tag_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_switch_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_switch_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A struct{ j2g_header uint64; F_init, F_tag any }

var A_arbace_repr_go_print_code_switch_stmt_fn__74000554_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_tagged_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_tagged_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_targets_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_targets_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_top_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_top_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_binding_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_binding_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_decl_fn__74000773_A struct{ j2g_header uint64; F_gxs any }

var A_arbace_repr_go_print_code_type_decl_fn__74000773_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_decl_fn__74000778_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_decl_fn__74000778_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_expr_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_expr_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_expr_fn__74000265_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_type_expr_fn__74000265_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_expr_fn__74000274_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_go_print_code_type_expr_fn__74000274_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_list_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_list_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_list_fn__74000261_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_list_fn__74000261_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_params_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_params_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_params_fn__74000292_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_params_fn__74000292_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_switch_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_type_switch_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A struct{ j2g_header uint64; F_init, F_f, F_guard any }

var A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_code_type_switch_stmt_fn__74000563_assert_type__74000564_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_unary_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_unary_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_unary_op_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_unary_op_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_unary_operand_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_unary_operand_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_uses_grouped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_uses_grouped_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_uses_grouped_QMARK__walk__74000012_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_value_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_value_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_value_spec_fn__74000695_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_value_spec_fn__74000695_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_variadic_elem_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_variadic_elem_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_walk_binary_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_walk_binary_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_walk_prefixes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_walk_prefixes_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_walk_right_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_walk_right_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_while_stmt_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_while_stmt_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_while_stmt_fn__74000584_A struct{ j2g_header uint64; F_c any }

var A_arbace_repr_go_print_code_while_stmt_fn__74000584_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_with_parens_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_with_parens_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_wrap_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_wrap_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_wrap_full_fn__74000044_A struct{ j2g_header uint64; F_atext, F_apos, F_apar any }

var A_arbace_repr_go_print_code_wrap_full_fn__74000044_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_wrap_full_wrap_meta__74000041_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_write_doc_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_write_doc_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_write_pre_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_write_pre_A_fn_class *jrt.Class



type A_arbace_repr_go_print_code_zero_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_code_zero_form_QMARK__A_fn_class *jrt.Class
