//line j2g_strings.ae:1
package aot_arbace_repr_go_print_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn25,arbace.repr.go.print-emitkn2,asyn1,ekn5,referyn3,tokyn2,spyn4,vtabyn25,arbace.repr.go.print-textyn4,textyn13,arbace.stringyn3,strkn3,docks2,go7,groupedkn4,linekn6,columnkn4,formkn4,fullks2,go3,posks2,go4,aposkn3,tagkn11,type-paramsks2,go5,atextks2,go7,aparenskn4,elsekn6,lines?ks2,go6,breakskn5,breakkn5,x-poskn3,dotkn8,name-poskn3,srckn5,nameskn6,parentkn6,offsetkn3,endkn6,targetkn8,open-poskn9,close-poskn4,hereks2,go3,endkn5,trailyn1,&kn4,namekn4,typekn9,variadic?kn4,metaks2,go3,tagkn7,entrieskn8,ellipsiskn7,openingkn7,closingkn15,results-openingkn15,results-closingkn3,bolkn6,indentkn10,cur-indentks2,go8,tag-textks2,go7,tag-poskn7,resultskn6,lbracekn6,rbracekn4,recvkn4,sendkn5,beginkn5,arrowkn4,chankn6,lbrackkn6,rbrackks2,go3,opskn6,op-posks2,go6,parenskn4,starkn4,funcyn3,...kn3,mapyn3,anyks2,go5,parenkn6,lparenkn6,rparenkn4,kindkn5,fieldkn3,keykn5,valuekn1,ikn3,posyn1,_ks2,go6,acolonkn5,colonkn6,returnkn8,results?kn5,func?kn3,sepkn6,parenskn1,vkn4,textks2,go4,textkn9,value-poskn5,constkn3,varkn7,tok-poskn5,aliasks2,go4,condkn4,nextkn13,else-follows?kn11,else-block?kn2,ifkn11,else-lbracekn11,else-rbracekn4,casekn6,switchkn9,guard-dotkn12,guard-lparenkn12,guard-rparenkn9,guard-tokkn6,selectkn3,forkn6,assignkn5,rangekn5,labelkn5,deferkn2,gokn4,bindkn1,tkn9,type-bindkn11,const-groupks2,go5,labelks2,go8,implicitks25,arbace.repr.go.print-code4,noneks2,go10,label-linekn11,label-colonkn6,externkn12,recv-openingkn12,recv-closingv11,arbace.core7,requirev11,arbace.core5,referR0,V5,R1,R2,R3,R4,V3,R5,R6,R7,V3,R8,R2,R9,V3,R10,R2,R11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn25,arbace.repr.go.print-codem2,R12,s589,repr/go's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.repr.go.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.v11,arbace.core13,*loaded-libs*v11,arbace.core9,contains?v11,arbace.core4,somev11,arbace.core5,coll?R13,v11,arbace.core4,valsv11,arbace.core6,dissocR14,R15,v11,arbace.core4,map?v11,arbace.core7,ex-infov11,arbace.core6,pr-strR16,v11,arbace.core4,intoR17,v25,arbace.repr.go.print-emit3,*p*R18,v25,arbace.repr.go.print-emit3,tokv25,arbace.repr.go.print-emit3,at!v25,arbace.repr.go.print-code4,ptokR19,R20,v11,arbace.core6,updateR21,v25,arbace.repr.go.print-code9,wrap-fullv11,arbace.core4,seq?v11,arbace.core7,vector?R22,R23,v11,arbace.core11,map-indexedv11,arbace.core9,with-metav11,arbace.core7,symbol?R24,v11,arbace.core3,notv25,arbace.repr.go.print-code4,->PLv11,arbace.core8,keyword?v11,arbace.core5,applyv11,arbace.core3,vecv11,arbace.core4,listv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core7,reversev11,arbace.core9,namespacev11,arbace.core4,namev25,arbace.repr.go.print-code7,*go-ns*S2,s12,clojure.cores11,arbace.corev11,arbace.core4,restv25,arbace.repr.go.print-code10,binary-opsv25,arbace.repr.go.print-code2,opv11,arbace.core7,number?v25,arbace.repr.go.print-text16,negative-number?v25,arbace.repr.go.print-code17,negative-literal?v25,arbace.repr.go.print-code9,unary-opsv11,arbace.core6,secondv25,arbace.repr.go.print-code7,binary?v25,arbace.repr.go.print-code8,bin-precv25,arbace.repr.go.print-code6,unary?l6,l7,v25,arbace.repr.go.print-code10,stmt-headsv25,arbace.repr.go.print-code15,statement-form?R25,v11,arbace.core8,integer?v11,arbace.core3,setv11,arbace.core3,mapR26,v25,arbace.repr.go.print-code7,line-ofv25,arbace.repr.go.print-code10,break-lineR27,v25,arbace.repr.go.print-code9,breaks-ofv25,arbace.repr.go.print-code12,child-targetv25,arbace.repr.go.print-emit5,room?v25,arbace.repr.go.print-emit6,*next*v11,arbace.core4,mapvv11,arbace.core5,rangev25,arbace.repr.go.print-emit9,break-to!v11,arbace.core19,pop-thread-bindingsv25,arbace.repr.go.print-emit2,spv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv25,arbace.repr.go.print-code7,go-sym?v11,arbace.core3,strv25,arbace.repr.go.print-code4,failR28,R29,R30,v25,arbace.repr.go.print-code12,ident-stringv11,arbace.core6,vectorv25,arbace.repr.go.print-code8,name-tokR31,R32,v11,arbace.core5,true?v11,arbace.core6,false?v11,arbace.core7,string?v13,arbace.string9,includes?v25,arbace.repr.go.print-text14,raw-string-ok?v25,arbace.repr.go.print-emit7,raw-tokv11,arbace.core5,char?v25,arbace.repr.go.print-text9,go-stringv25,arbace.repr.go.print-text7,go-runev25,arbace.repr.go.print-text9,go-numberv11,arbace.core8,to-arrayR33,R34,R35,R36,R37,R38,v25,arbace.repr.go.print-code12,next-targetsv25,arbace.repr.go.print-emit9,pop-open!R39,R40,v11,arbace.core4,peekv25,arbace.repr.go.print-emit10,push-open!v25,arbace.repr.go.print-emit4,softv25,arbace.repr.go.print-emit12,close-break!l1,R41,R42,v25,arbace.repr.go.print-code7,tagged?R43,R44,R45,R46,R12,R47,v25,arbace.repr.go.print-code17,*explicit-groups*v25,arbace.repr.go.print-code9,*generic*v11,arbace.core6,reducev25,arbace.repr.go.print-code10,groupable?R48,v11,arbace.core3,popv11,arbace.core5,assocv25,arbace.repr.go.print-code13,group-entriesv25,arbace.repr.go.print-code12,element-listv25,arbace.repr.go.print-code13,param-entriesv25,arbace.repr.go.print-code9,type-exprv25,arbace.repr.go.print-code9,name-listv25,arbace.repr.go.print-code2,fpR49,v25,arbace.repr.go.print-code13,variadic-elemv25,arbace.repr.go.print-code10,group-lineR50,R51,v11,arbace.core6,empty?v25,arbace.repr.go.print-code10,param-listR52,R53,R54,R55,R56,v25,arbace.repr.go.print-code13,print-resultsv25,arbace.repr.go.print-code9,next-linev25,arbace.repr.go.print-code9,signatureR57,R58,v13,arbace.string5,splitp2,\\nl-1,v11,arbace.core4,not=v25,arbace.repr.go.print-code9,doc-linesv25,arbace.repr.go.print-emit12,comment-linev13,arbace.string12,starts-with?v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core6,concatv11,arbace.core7,sort-byv11,arbace.core4,compv11,arbace.core6,filterv11,arbace.core3,keyv25,arbace.repr.go.print-code18,non-directive-keysl0,v25,arbace.repr.go.print-code9,write-docR59,v25,arbace.repr.go.print-code15,results-entriesv25,arbace.repr.go.print-code17,interface-method?v25,arbace.repr.go.print-emit6,renderv25,arbace.repr.go.print-code16,iface-method-sigv11,arbace.core5,nnextv25,arbace.repr.go.print-code10,struct-tagv25,arbace.repr.go.print-emit4,vtabv25,arbace.repr.go.print-code13,struct-fieldsv25,arbace.repr.go.print-code16,one-line-fields?v11,arbace.core9,volatile!v11,arbace.core7,keywordR60,R61,v25,arbace.repr.go.print-code10,field-bodyv25,arbace.repr.go.print-emit2,nlv25,arbace.repr.go.print-code9,pre-linesv25,arbace.repr.go.print-emit11,stmt-break!v11,arbace.core7,vreset!v11,arbace.core6,subvecR62,R63,R64,R65,R66,R67,R68,R69,R70,v25,arbace.repr.go.print-code3,pl?v25,arbace.repr.go.print-code8,print-plR71,v25,arbace.repr.go.print-code11,with-parensv25,arbace.repr.go.print-code10,field-listv25,arbace.repr.go.print-code9,type-listv11,arbace.core9,vary-metaR72,v25,arbace.repr.go.print-code13,func-type-sigv25,arbace.repr.go.print-code4,argsR73,v25,arbace.repr.go.print-code9,chan-typeR74,v25,arbace.repr.go.print-code5,expr0v25,arbace.repr.go.print-code8,*header*R75,v25,arbace.repr.go.print-code6,op-posv25,arbace.repr.go.print-code10,type-headsv25,arbace.repr.go.print-code26,begins-with-star-or-paren?R76,v25,arbace.repr.go.print-code11,walk-binaryV3,FFl0,v25,arbace.repr.go.print-code8,unary-opV3,FFl0,l5,S3,s2,&&s2,/*s2,&^S2,s2,++s2,--l4,v25,arbace.repr.go.print-code6,bin-opV3,FFl0,v25,arbace.repr.go.print-code10,walk-rightv25,arbace.repr.go.print-code13,walk-prefixesv25,arbace.repr.go.print-code9,cutoff-ofv25,arbace.repr.go.print-code12,reduce-depthR77,v25,arbace.repr.go.print-code13,paren-operandv25,arbace.repr.go.print-code5,expr1v25,arbace.repr.go.print-code9,diff-precR78,R79,R80,R81,R82,R83,R84,R85,l10,v25,arbace.repr.go.print-code22,lit-type-needs-parens?R86,v25,arbace.repr.go.print-code12,lit-elementsR86,v25,arbace.repr.go.print-code9,child-posR87,R88,v11,arbace.core6,repeatR86,R86,R86,R86,R86,v25,arbace.repr.go.print-code11,line-indentv25,arbace.repr.go.print-code10,block-bodyv25,arbace.repr.go.print-code12,*return-pos*R89,R90,R91,R92,v25,arbace.repr.go.print-code11,body-offsetv25,arbace.repr.go.print-code10,type-form?R93,R94,v25,arbace.repr.go.print-code7,literalv25,arbace.repr.go.print-code13,unary-operandR95,R96,R97,v25,arbace.repr.go.print-code11,binary-exprv25,arbace.repr.go.print-code7,prec-ofv25,arbace.repr.go.print-code8,func-litv25,arbace.repr.go.print-code12,lit-list-tokv25,arbace.repr.go.print-code10,slice-exprv25,arbace.repr.go.print-code9,call-argsv25,arbace.repr.go.print-code6,cutoffS3,s4,funcs4,chans1,*l2,S3,s4,funcs4,chans1,*v25,arbace.repr.go.print-code13,composite-litv25,arbace.repr.go.print-code7,new-argv25,arbace.repr.go.print-text14,go-byte-stringv11,arbace.core4,subsv25,arbace.repr.go.print-code6,calleev25,arbace.repr.go.print-code10,comma-listv25,arbace.repr.go.print-code7,targetsR98,R99,v25,arbace.repr.go.print-code9,expr-listv25,arbace.repr.go.print-code10,zero-form?v25,arbace.repr.go.print-code8,n-valuesv11,arbace.core4,metaR100,v25,arbace.repr.go.print-code10,*in-group*v25,arbace.repr.go.print-code11,type-paramsR101,v25,arbace.repr.go.print-code10,assign-opsv25,arbace.repr.go.print-code11,simple-stmtv25,arbace.repr.go.print-code12,binding-stmtv25,arbace.repr.go.print-code11,assign-stmtS2,s4,cases7,defaultv11,arbace.core5,some?R86,R86,S3,s4,conds2,ifs4,whenv25,arbace.repr.go.print-code8,if-like?v25,arbace.repr.go.print-code10,print-stmtv25,arbace.repr.go.print-code12,branch-formsv11,arbace.core9,partitionR102,v25,arbace.repr.go.print-code9,else-partv11,arbace.core4,odd?v11,arbace.core5,mergev25,arbace.repr.go.print-code11,branch-optsv25,arbace.repr.go.print-code14,control-clauseR103,R104,R105,R106,R107,R108,v25,arbace.repr.go.print-code9,stmt-listR109,v25,arbace.repr.go.print-code7,clause?v25,arbace.repr.go.print-code11,clause-listR110,v25,arbace.repr.go.print-code10,case-exprsv11,arbace.core6,removev11,arbace.core4,nil?R111,R112,R113,R114,v25,arbace.repr.go.print-code10,case-typesR115,v25,arbace.repr.go.print-code4,commR116,v25,arbace.repr.go.print-code9,braces-ofR117,R118,v25,arbace.repr.go.print-code10,range-stmtv25,arbace.repr.go.print-code10,label-nameR119,v25,arbace.repr.go.print-code10,while-stmtv25,arbace.repr.go.print-code7,if-stmtR120,v25,arbace.repr.go.print-code8,for-stmtv25,arbace.repr.go.print-code11,select-stmtR121,v25,arbace.repr.go.print-code16,type-switch-stmtv25,arbace.repr.go.print-code10,label-stmtv25,arbace.repr.go.print-code11,switch-stmtv11,arbace.core6,mapcatS2,s3,lets8,let-typeR122,R123,R124,v25,arbace.repr.go.print-code13,flatten-stmtsS2,s3,lets8,let-typev25,arbace.repr.go.print-code11,bind-targetv25,arbace.repr.go.print-code11,const-bind?R125,v25,arbace.repr.go.print-code12,label-targetR126,R127,v25,arbace.repr.go.print-code16,keep-type-columnR128,v25,arbace.repr.go.print-code10,const-specv25,arbace.repr.go.print-code7,*group*v25,arbace.repr.go.print-code14,item-group-posv11,arbace.core6,reset!v25,arbace.repr.go.print-code10,item-startv25,arbace.repr.go.print-code12,group-constsv11,arbace.core4,atomv25,arbace.repr.go.print-code6,item-tv25,arbace.repr.go.print-code8,label-ofv25,arbace.repr.go.print-code16,full-group-open!v25,arbace.repr.go.print-code11,const-groupv25,arbace.repr.go.print-code16,expression-form?v25,arbace.repr.go.print-code17,type-binding-stmtv25,arbace.repr.go.print-code17,full-group-close!R129,v25,arbace.repr.go.print-code12,group-targetR130,v25,arbace.repr.go.print-code14,full-in-group?v11,arbace.core6,every?v25,arbace.repr.go.print-code5,room?v25,arbace.repr.go.print-code18,stmt-list-one-linev25,arbace.repr.go.print-code15,parse-decl-headR131,v25,arbace.repr.go.print-code13,generic-type?R132,R133,v11,arbace.core9,transientv11,arbace.core11,persistent!v11,arbace.core6,assoc!v25,arbace.repr.go.print-code9,spec-namev25,arbace.repr.go.print-code13,directives-ofv25,arbace.repr.go.print-code6,spec-tv25,arbace.repr.go.print-code9,write-prev25,arbace.repr.go.print-code10,group-declv25,arbace.repr.go.print-code10,value-specv25,arbace.repr.go.print-code15,parse-type-specv25,arbace.repr.go.print-code9,type-specv25,arbace.repr.go.print-code9,type-declv25,arbace.repr.go.print-code9,func-declv25,arbace.repr.go.print-code14,const-var-decl")

var Lit_1 *jrt.String = jrt.Intern("=")

var Lit_2 *jrt.String = jrt.Intern("not an assignment operator")

var Lit_3 *jrt.String = jrt.Intern("set! takes 2 or 3 arguments")

var Lit_4 *jrt.String = jrt.Intern("*")

var Lit_5 *jrt.String = jrt.Intern("|")

var Lit_6 *jrt.String = jrt.Intern("(")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binary_expr$fn__74000329")

var Lit_8 *jrt.String = jrt.Intern(")")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binary_expr$fn__74000331")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binding_stmt$fn__74000455")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binding_stmt$names__74000457")

var Lit_12 *jrt.String = jrt.Intern("const")

var Lit_13 *jrt.String = jrt.Intern("var")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binding_stmt$fn__74000459")

var Lit_15 *jrt.String = jrt.Intern(":=")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.print_code$block_body$fn__74000663")

var Lit_17 *jrt.String = jrt.Intern("{")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.print_code$block_body$fn__74000665")

var Lit_19 *jrt.String = jrt.Intern("}")

var Lit_20 *jrt.String = jrt.Intern("do")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.go.print_code$break_line$fn__74000087")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.print_code$breaks_of$fn__74000083")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.print_code$call_args$fn__74000334")

var Lit_24 *jrt.String = jrt.Intern("spread")

var Lit_25 *jrt.String = jrt.Intern("...")

var Lit_26 *jrt.String = jrt.Intern("func")

var Lit_27 *jrt.String = jrt.Intern("case needs a vector")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.print_code$case_exprs$fn__74000541")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.print_code$case_types$fn__74000545")

var Lit_30 *jrt.String = jrt.Intern("nil")

var Lit_31 *jrt.String = jrt.Intern("chan")

var Lit_32 *jrt.String = jrt.Intern("<-")

var Lit_33 *jrt.String = jrt.Intern("bad channel direction")

var Lit_34 *jrt.String = jrt.Intern("not a case or default clause")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.print_code$clause_list$fn__74000534")

var Lit_36 *jrt.String = jrt.Intern(";")

var Lit_37 *jrt.String = jrt.Intern("default")

var Lit_38 *jrt.String = jrt.Intern(":")

var Lit_39 *jrt.String = jrt.Intern("case")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.print_code$comma_list$fn__74000095")

var Lit_41 *jrt.String = jrt.Intern(",")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.print_code$comma_list$fn__74000097")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit$fn__74000341")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit$fn__74000341$fn__74000342")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit$fn__74000341$fn__74000344")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit$fn__74000341$fn__74000353")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit$fn__74000341$fn__74000359")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_bind_QMARK_$fn__74000620")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_group$fn__74000637")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_group$fn__74000642")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_spec$fn__74000633")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_var_decl$fn__74000746")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_var_decl$fn__74000748")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_var_decl$fn__74000753")

var Lit_55 *jrt.String = jrt.Intern("go/type")

var Lit_56 *jrt.String = jrt.Intern("go/func")

var Lit_57 *jrt.String = jrt.Intern("go/const")

var Lit_58 *jrt.String = jrt.Intern("go/var")

var Lit_59 *jrt.String = jrt.Intern("go/method")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$iter__74000169__74000175")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$fn__74000189")

var Lit_62 *jrt.String = jrt.Intern("go")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$iter__74000169__74000175$fn__74000176")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$iter__74000169__74000175$fn__74000176$iter__74000171__74000180")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$iter__74000169__74000175$fn__74000176$iter__74000171__74000180$fn__74000181")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of$iter__74000169__74000175$fn__74000176$iter__74000171__74000180$fn__74000181$fn__74000182")

var Lit_67 *jrt.String = jrt.Intern("//go:")

var Lit_68 *jrt.String = jrt.Intern(" ")

var Lit_69 *jrt.String = jrt.Intern("")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.print_code$element_list$fn__74000125")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.print_code$element_list$fn__74000127")

var Lit_72 *jrt.String = jrt.Intern("fn")

var Lit_73 *jrt.String = jrt.Intern("else")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000395")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000397")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000399")

var Lit_77 *jrt.String = jrt.Intern("imaginary")

var Lit_78 *jrt.String = jrt.Intern("i")

var Lit_79 *jrt.String = jrt.Intern("subslice")

var Lit_80 *jrt.String = jrt.Intern("method-expr")

var Lit_81 *jrt.String = jrt.Intern(".")

var Lit_82 *jrt.String = jrt.Intern("assert")

var Lit_83 *jrt.String = jrt.Intern("go/call")

var Lit_84 *jrt.String = jrt.Intern("go/id")

var Lit_85 *jrt.String = jrt.Intern("conv")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000414")

var Lit_87 *jrt.String = jrt.Intern("spread outside the arguments of a call")

var Lit_88 *jrt.String = jrt.Intern("zero")

var Lit_89 *jrt.String = jrt.Intern("zero outside a var binding")

var Lit_90 *jrt.String = jrt.Intern("make")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000419")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000421")

var Lit_93 *jrt.String = jrt.Intern("inst")

var Lit_94 *jrt.String = jrt.Intern("rune")

var Lit_95 *jrt.String = jrt.Intern("values")

var Lit_96 *jrt.String = jrt.Intern("values outside a return, an assignment or a binding")

var Lit_97 *jrt.String = jrt.Intern("lit")

var Lit_98 *jrt.String = jrt.Intern("aget")

var Lit_99 *jrt.String = jrt.Intern("[")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000429")

var Lit_101 *jrt.String = jrt.Intern("]")

var Lit_102 *jrt.String = jrt.Intern("new")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000434")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1$fn__74000436")

var Lit_105 *jrt.String = jrt.Intern("byte-string")

var Lit_106 *jrt.String = jrt.Intern("a statement in an expression position")

var Lit_107 *jrt.String = jrt.Intern(".-")

var Lit_108 *jrt.String = jrt.Intern("a keyword in an expression position")

var Lit_109 *jrt.String = jrt.Intern("a vector in an expression position")

var Lit_110 *jrt.String = jrt.Intern("not an expression")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr_list$fn__74000447")

var Lit_112 *jrt.String = jrt.Intern("panic")

var Lit_113 *jrt.String = jrt.Intern(": ")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$iter__74000223__74000227")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$fn__74000233")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$fn__74000235")

var Lit_117 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$fn__74000237")

var Lit_118 *jrt.String = jrt.Intern("{}")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$fn__74000249")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$iter__74000223__74000227$fn__74000228")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list$iter__74000223__74000227$fn__74000228$fn__74000229")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.print_code$flatten_stmts$fn__74000601")

var Lit_123 *jrt.String = jrt.Intern("let needs a binding vector")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go.print_code$flatten_stmts$fn__74000601$fn__74000606")

var Lit_125 *jrt.String = jrt.Intern("let needs pairs")

var Lit_126 *jrt.String = jrt.Intern("let")

var Lit_127 *jrt.String = jrt.Intern("for needs an init vector")

var Lit_128 *jrt.String = jrt.Intern("for")

var Lit_129 *jrt.String = jrt.Intern("type")

var Lit_130 *jrt.String = jrt.Intern("a function needs a parameter vector")

var Lit_131 *jrt.String = jrt.Intern("fn needs a parameter vector")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_consts$fn__74000623")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_decl$fn__74000737")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_entries$fn__74000134")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_entries$fn__74000136")

var Lit_136 *jrt.String = jrt.Intern("not a name")

var Lit_137 *jrt.String = jrt.Intern("cond")

var Lit_138 *jrt.String = jrt.Intern("arbace.repr.go.print_code$if_stmt$braces__74000484")

var Lit_139 *jrt.String = jrt.Intern("cond takes test-branch pairs")

var Lit_140 *jrt.String = jrt.Intern("if")

var Lit_141 *jrt.String = jrt.Intern("when")

var Lit_142 *jrt.String = jrt.Intern("if takes a condition, then and else")

var Lit_143 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.print_code$keep_type_column$fn__74000721")

var Lit_145 *jrt.String = jrt.Intern("not a label")

var Lit_146 *jrt.String = jrt.Intern("label")

var Lit_147 *jrt.String = jrt.Intern("a field key without a value")

var Lit_148 *jrt.String = jrt.Intern("a key-value element is [key value]")

var Lit_149 *jrt.String = jrt.Intern("true")

var Lit_150 *jrt.String = jrt.Intern("false")

var Lit_151 *jrt.String = jrt.Intern("\n")

var Lit_152 *jrt.String = jrt.Intern("`")

var Lit_153 *jrt.String = jrt.Intern("not a literal")

var Lit_154 *jrt.String = jrt.Intern("arbace.repr.go.print_code$one_line_fields_QMARK_$fn__74000203")

var Lit_155 *jrt.String = jrt.Intern("go/")

var Lit_156 *jrt.String = jrt.Intern("deref")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.print_code$param_list$fn__74000144")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.print_code$paren_operand$fn__74000325")

var Lit_159 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_pl$fn__74000391")

var Lit_160 *jrt.String = jrt.Intern("-")

var Lit_161 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_results$fn__74000148")

var Lit_162 *jrt.String = jrt.Intern("break")

var Lit_163 *jrt.String = jrt.Intern("range")

var Lit_164 *jrt.String = jrt.Intern("goto")

var Lit_165 *jrt.String = jrt.Intern("fallthrough")

var Lit_166 *jrt.String = jrt.Intern("while")

var Lit_167 *jrt.String = jrt.Intern("defer")

var Lit_168 *jrt.String = jrt.Intern("inc!")

var Lit_169 *jrt.String = jrt.Intern("dec!")

var Lit_170 *jrt.String = jrt.Intern("aset")

var Lit_171 *jrt.String = jrt.Intern("continue")

var Lit_172 *jrt.String = jrt.Intern("select")

var Lit_173 *jrt.String = jrt.Intern("type-switch")

var Lit_174 *jrt.String = jrt.Intern("return")

var Lit_175 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_stmt$fn__74000598")

var Lit_176 *jrt.String = jrt.Intern("switch")

var Lit_177 *jrt.String = jrt.Intern(">!")

var Lit_178 *jrt.String = jrt.Intern("let-type")

var Lit_179 *jrt.String = jrt.Intern("set!")

var Lit_180 *jrt.String = jrt.Intern("range needs a vector")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.print_code$range_stmt$fn__74000591")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.print_code$range_stmt$fn__74000591$fn__74000592")

var Lit_183 *jrt.String = jrt.Intern("an init vector holds one statement or one binding")

var Lit_184 *jrt.String = jrt.Intern("++")

var Lit_185 *jrt.String = jrt.Intern("--")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.print_code$slice_expr$fn__74000368")

var Lit_187 *jrt.String = jrt.Intern("arbace.repr.go.print_code$slice_expr$fn__74000370")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.print_code$stmt_list$fn__74000654")

var Lit_189 *jrt.String = jrt.Intern("go/directive")

var Lit_190 *jrt.String = jrt.Intern("arbace.repr.go.print_code$stmt_list$fn__74000654$fn__74000655")

var Lit_191 *jrt.String = jrt.Intern("arbace.repr.go.print_code$struct_fields$iter__74000206__74000210")

var Lit_192 *jrt.String = jrt.Intern("arbace.repr.go.print_code$struct_fields$iter__74000206__74000210$fn__74000211")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.print_code$struct_fields$iter__74000206__74000210$fn__74000211$fn__74000212")

var Lit_194 *jrt.String = jrt.Intern("arbace.repr.go.print_code$switch_stmt$fn__74000554")

var Lit_195 *jrt.String = jrt.Intern("not a declaration")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_decl$fn__74000773")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_decl$fn__74000778")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_expr$fn__74000265")

var Lit_199 *jrt.String = jrt.Intern("slice")

var Lit_200 *jrt.String = jrt.Intern("interface")

var Lit_201 *jrt.String = jrt.Intern("struct")

var Lit_202 *jrt.String = jrt.Intern("tilde")

var Lit_203 *jrt.String = jrt.Intern("~")

var Lit_204 *jrt.String = jrt.Intern("array")

var Lit_205 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_expr$fn__74000274")

var Lit_206 *jrt.String = jrt.Intern("map")

var Lit_207 *jrt.String = jrt.Intern("not a type")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_list$fn__74000261")

var Lit_209 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_params$fn__74000292")

var Lit_210 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_switch_stmt$fn__74000563")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_switch_stmt$fn__74000563$assert_type__74000564")

var Lit_212 *jrt.String = jrt.Intern("arbace.repr.go.print_code$uses_grouped_QMARK_$walk__74000012")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.print_code$value_spec$fn__74000695")

var Lit_214 *jrt.String = jrt.Intern("variadic parameter not a slice")

var Lit_215 *jrt.String = jrt.Intern("/")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.print_code$while_stmt$fn__74000584")

var Lit_217 *jrt.String = jrt.Intern("arbace.repr.go.print_code$wrap_full$wrap_meta__74000041")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.print_code$wrap_full$fn__74000044")

var Lit_219 *jrt.String = jrt.Intern("//")

var Lit_220 *jrt.String = jrt.Intern("\t")

var Lit_221 *jrt.String = jrt.Intern("// ")

var Lit_222 *jrt.String = jrt.Intern("kn1,vkn3,poskn4,textkn6,parensR0,R1,R2,R3,v11,arbace.core5,classv11,arbace.core9,imap-consv11,arbace.core3,notv11,arbace.core3,seqv11,arbace.core6,concatV4,R0,R1,R2,R3,v11,arbace.core10,identical?v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core6,dissocv11,arbace.core9,not-emptyS4,R0,R3,R1,R2,v11,arbace.core9,with-metav11,arbace.core4,intov11,arbace.core4,somev11,arbace.core4,valsv11,arbace.core3,setv11,arbace.core4,keys")

var Lit_223 *jrt.String = jrt.Intern("v")

var Lit_224 *jrt.String = jrt.Intern("pos")

var Lit_225 *jrt.String = jrt.Intern("text")

var Lit_226 *jrt.String = jrt.Intern("parens")

var Lit_227 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_228 *jrt.String = jrt.Intern("arbace.repr.go.print_code.PL")

var Lit_229 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn7,dynamickn8,arglistsyn5,formskn7,privateyn3,msgyn4,formyn1,vyn3,posyn4,textyn6,parensyn20,m__231000174__auto__yn1,xyn1,fyn1,kyn1,syn1,iyn2,psyn4,bodyyn6,parentyn5,childyn3,brkyn2,tsyn1,nyn6,offsetyn2,xsyn9,print-oneyn3,nmsyn1,gyn1,&yn8,spellingyn4,openyn5,closekn4,keysyn3,endyn6,targetyn8,open-posyn9,close-poskn2,oryn4,prevyn3,curyn7,entriesyn1,tyn6,paramsyn7,resultsyn2,rvyn3,resyn1,myn3,docyn6,indentks2,go8,commentsks2,go4,textks2,go7,groupedks2,go7,aparensks2,go6,acolonks2,go4,instks2,go6,parensks2,go8,implicitks2,go3,viaks2,go3,tagks2,go6,trailsks2,go3,endks2,go3,posks2,go4,aposks2,go3,opsks2,go4,condks2,go5,parenks2,go7,tag-posks2,go5,spaceks2,go5,labelks2,go4,tailks2,go8,tag-textks2,go6,breaksks2,go5,atextks2,go10,label-lineks2,go5,semisyn4,dirsyn4,moreyn6,groupsyn7,struct?yn2,fsyn3,sepyn2,kwyn3,tpsyn1,oyn4,precyn1,ryn4,has4yn4,has5yn2,mpyn5,depthv11,arbace.core5,in-nsMyn25,arbace.repr.go.print-codem2,R0,s589,repr/go's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.repr.go.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.m2,R0,s589,repr/go's printer, the forms level (doc/go/PRINTER-NOTES.md): Go forms (doc/go/SPEC.md) to Go\n  tokens through arbace.repr.go.print-emit. Types (§5), declarations (§6), statements and\n  expressions (§7), literals (§8), directives and doc comments (§9, §10.4), files (§4.3).\n\n  Every form is classified by its head and position (§4.4); nothing is resolved. Spacing\n  follows go/printer (go1.27.1 src/go/printer/nodes.go: binaryExpr, cutoff, walkBinary,\n  the depth rules of exprList, controlClause, funcBody, fieldList, valueSpec, keepTypeColumn)\n  so that gofmt leaves the output as it is.R1,v25,arbace.repr.go.print-code5,expr1m8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code5,expr0m8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,type-exprm8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,stmt-listm8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,simple-stmtm8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,block-bodym8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,print-stmtm8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code18,stmt-list-one-linem8,R2,TR3,i14,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,*go-ns*S2,s9,arbace.gos2,gom10,R6,TR3,i16,R4,i1,R5,s28,arbace/repr/go/print_code.aeR0,s83,The namespace qualifiers that name the Go forms' own heads (go/func, go/call, ...).v25,arbace.repr.go.print-code8,*header*m10,R6,TR3,i20,R4,i1,R5,s28,arbace/repr/go/print_code.aeR0,s142,True while printing the header of an if, for or switch outside brackets: a composite\n  literal of a type name needs parentheses there (§12.2).v25,arbace.repr.go.print-code17,*explicit-groups*m10,R6,TR3,i25,R4,i1,R5,s28,arbace/repr/go/print_code.aeR0,s131,True when the file's forms mark grouped names with :go/grouped: then only marked names are\n  grouped (PRINTER-NOTES, amendment A1).v25,arbace.repr.go.print-code13,uses-grouped?m10,R7,L1,V1,R8,R0,s52,Whether :go/grouped occurs in the metadata of forms.R3,i30,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,*generic*m10,R6,TR3,i39,R4,i1,R5,s28,arbace/repr/go/print_code.aeR0,s91,True inside a generic declaration: field groups are kept (doc/go/ROUNDTRIP.md, known gaps).v25,arbace.repr.go.print-code12,*return-pos*m10,R6,TR3,i43,R4,i1,R5,s28,arbace/repr/go/print_code.aeR0,s87,Mode :full: the position of the keyword of the implicit return of the function printed.v25,arbace.repr.go.print-code4,failm10,R9,TR7,L1,V2,R10,R11,R3,i47,R4,i1,R5,s28,arbace/repr/go/print_code.aeC28,arbace.repr.go.print_code.PLv25,arbace.repr.go.print-code4,->PLm8,R2,TR3,i53,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,map->PLm8,R2,TR3,i53,R4,i1,R5,s28,arbace/repr/go/print_code.aem10,R7,L1,V4,R12,R13,R14,R15,R0,s67,Positional factory function for class arbace.repr.go.print_code.PL.R3,i53,R4,i1,R5,s28,arbace/repr/go/print_code.aem10,R7,L1,V1,R16,R0,s98,Factory function for class arbace.repr.go.print_code.PL, taking a map of keywords to field values.R3,i53,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code3,pl?m10,R7,L1,V1,R17,R0,s89,A literal child of mode :full (wrap-full): its value, position, spelling and parentheses.R3,i55,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code2,fpm10,R7,L1,V2,R18,R19,R0,s73,Mode :full: the recorded position of f's token k (its :go/pos), else nil.R3,i60,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code4,ptokm12,R9,TR7,L1,V2,R20,R13,R0,s37,A token at position pos (mode :full).R3,i65,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code5,ptok*m10,R7,L1,V2,R20,R13,R0,s63,A token at position pos (mode :full), for arbace.repr.go.print.R3,i71,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,child-posm12,R9,TR7,L1,V2,R18,R21,R0,s77,Mode :full: the position of the literal child i of f (its parent's :go/apos).R3,i76,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,wrap-fullm10,R7,L1,V1,R17,R0,s245,Mode :full: the forms with each literal child that carries a position (its parent's\n  :go/apos) replaced by a PL with its spelling (:go/atext) and parentheses (:go/aparens), in\n  the forms and in the type forms of :tag and :type-params metadata.R3,i81,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,with-parensm12,R9,TR7,L1,V2,R22,R23,R0,s79,Prints (body) inside the parentheses ps, [[lparen rparen] ...] outermost first.R3,i105,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code2,opm10,R7,L1,V1,R18,R0,s196,The name of a list's head as the forms read it: an unqualified symbol's name,\n  \"go/name\" for the Go forms' qualified heads, \"deref\" for @; nil otherwise (a call of a\n  package member, of a list).R3,i115,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,stmt-headsS26,s5,ranges5,defers5,labels6,returns2,>!s4,set!s3,fors11,fallthroughs4,dec!s4,conds2,ifs3,lets2,gos6,switchs6,selects5,breaks4,whens8,let-types8,continues2,dos4,inc!s5,whiles4,asets12,go/directives4,gotos11,type-switchm6,R3,i130,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,binary-opsm38,s2,>>V2,s2,>>l5,s2,!=V2,s2,!=l3,s1,*V2,s1,*l5,s1,%V2,s1,%l5,s2,<=V2,s2,<=l3,s6,bit-orV2,s1,|l4,s1,/V2,s1,/l5,s1,-V2,s1,-l4,s7,bit-xorV2,s1,^l4,s7,bit-andV2,s1,&l5,s11,bit-and-notV2,s2,&^l5,s2,orV2,s2,||l1,s2,>=V2,s2,>=l3,s3,andV2,s2,&&l2,s1,<V2,s1,<l3,s2,<<V2,s2,<<l5,s2,==V2,s2,==l3,s1,+V2,s1,+l4,s1,>V2,s1,>l3,m6,R3,i135,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,unary-opsm14,s1,-s1,-s1,+s1,+s7,bit-nots1,^s3,nots1,!s4,addrs1,&s5,derefs1,*s2,<!s2,<-m6,R3,i141,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,assign-opsm22,s2,>>s3,>>=s1,*s2,*=s1,%s2,%=s6,bit-ors2,|=s1,/s2,/=s1,-s2,-=s7,bit-xors2,^=s7,bit-ands2,&=s11,bit-and-nots3,&^=s2,<<s3,<<=s1,+s2,+=m6,R3,i143,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,type-headsS11,s4,funcs3,maps4,insts4,chans1,*s9,interfaces1,|s5,tildes5,slices6,structs5,arraym6,R3,i147,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code4,argsm10,R9,TR7,L1,V1,R18,R3,i149,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,binary?m10,R7,L1,V1,R18,R0,s82,A binary operator form: two or more operands (n-ary forms are left-nested chains).R3,i151,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code17,negative-literal?m10,R9,TR7,L1,V1,R18,R3,i156,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,unary?m10,R7,L1,V1,R18,R0,s74,A unary operator form (Go's UnaryExpr or StarExpr), or a negative literal.R3,i158,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,unary-opm10,R9,TR7,L1,V1,R18,R3,i164,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,unary-operandm10,R9,TR7,L1,V1,R18,R3,i166,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,bin-opm10,R9,TR7,L1,V1,R18,R3,i171,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,bin-precm10,R9,TR7,L1,V1,R18,R3,i172,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,prec-ofm10,R7,L1,V1,R18,R0,s85,The precedence of the Go expression a form prints as: 1-5 binary, 6 unary, 7 primary.R3,i174,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,go-sym?m10,R9,TR7,L1,V1,R18,R3,i179,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code15,statement-form?m10,R9,TR7,L1,V1,R18,R3,i181,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,expression-form?m10,R7,L1,V1,R18,R0,s75,An expression form other than a call of panic: the implicit return of §6.4.R3,i184,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,line-ofm10,R9,TR7,L1,V1,R18,R3,i191,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,breaks-ofm12,R9,TR7,L1,V1,R18,R0,s178,The child indexes in f's :go/breaks, a set: an entry is an index, or [index line] for a\n  literal whose Go line is not the line after the last one written before it (SPEC §10.1).R3,i193,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,break-linem12,R9,TR7,L1,V2,R24,R21,R0,s71,The line :go/breaks records for child i of parent, when it records one.R3,i199,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,child-targetm12,R9,TR7,L2,V3,R24,R21,R25,V4,R24,R21,R25,R26,R0,s178,The recorded line of child i of a list: its own, or the line of the list's :go/breaks (a\n  new line, or the line it records; brk: the set of the indexes, when the caller has it).R3,i204,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,next-targetsm12,R9,TR7,L1,V1,R27,R0,s75,For targets ts (lines, :break or nil), the first line after each: a vector.R3,i213,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code5,room?m10,R9,TR7,L1,V1,R28,R3,i225,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,body-offsetm12,R9,TR7,L1,V2,R18,R23,R0,s55,The index in f of the first of its trailing body forms.R3,i227,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,next-linem12,R9,TR7,L1,V1,R8,R0,s49,The first recorded line among forms, else *next*.R3,i231,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,comma-listm12,R9,TR7,L1,V4,R24,R29,R30,R31,R0,s196,x1, x2, ...: the children of parent from index offset on, each by (print-one x), each after\n  the first on its recorded line (its own, or parent's :go/breaks: Go allows a break after the\n  comma).R3,i236,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,ident-stringm10,R7,L1,V1,R18,R0,s59,The Go spelling of a name: a symbol, pkg/Name, (go/id \"x\").R3,i251,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,name-tokm12,R9,TR7,L1,V1,R18,R0,s77,A name's tokens: in mode :full at their positions (pkg.Name is three tokens).R3,i259,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,name-listm12,R9,TR7,L1,V1,R32,R0,s259,Names separated by commas (a group of parameters, results, fields, type parameters, or a\n  spec's names), each on its recorded line: a name list may span lines (Go allows a break\n  after a comma), and gc declares each name at its own line (DWARF's decl_line).R3,i269,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,group-linem12,R9,TR7,L1,V1,R33,R0,s75,The recorded line of a group of entries: its first name's, else its type's.R3,i278,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,label-namem10,R9,TR7,L1,V1,R19,R3,i283,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,literalm10,R9,TR7,L1,V3,R18,R34,V1,R35,R3,i286,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,element-listm12,R9,TR7,L1,V5,R36,R37,R30,R31,m4,R38,V6,R24,R29,R39,R40,R41,R42,R43,m2,R29,l1,R0,s493,Prints xs between open and close, separated by commas, each by (print-one x i); keeps\n  the recorded lines of the elements, and puts close on a line of its own after a trailing\n  comma when the elements span lines and there is room. parent and offset give the\n  elements' indexes in their parent list (for :go/breaks); end, the line of close (:here:\n  the line of the last element); target, when given, the recorded line of an element (for\n  elements that are not forms: groups of parameters).R3,i306,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,tagged?m12,R9,TR7,L1,V1,R17,R0,s63,A name with a type: a symbol or (go/id \"x\") carrying :tag (C5).R3,i350,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,param-entriesm12,R9,TR7,L1,V1,R12,R0,s164,The entries of a parameter, result or field vector: {:name sym-or-nil :type T\n  :variadic? bool :meta m :src x}. A symbol with :tag is a name, anything else a type.R3,i355,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,groupable?m12,R9,TR7,L1,V2,R44,R45,R0,s246,Whether cur may join prev's group: names of one type, doc and struct tag (a field's doc and\n  tag are its every name's, so equal ones are one field's), cur not beginning a line of its\n  own (a name that does keeps its line: gc declares it there).R3,i371,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,group-entriesm10,R7,L1,V1,R46,R0,s611,Consecutive named entries of equal type, doc and tag (groupable?) as one group\n  {:names [...] ...}: Go's `a, b T`. Inside generic declarations the grouping must be the\n  source's: when a name of the list carries :go/grouped (the amendment proposed in\n  PRINTER-NOTES: each name declared together with the one before it), exactly those names\n  join the group before them (in a file that marks them, *explicit-groups*, a generic\n  declaration's list without marks has no groups); otherwise the source is assumed to group\n  what it can (outside generic declarations the converter marks nothing: grouping is N3's).R3,i384,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,variadic-elemm10,R9,TR7,L1,V1,R47,R3,i407,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,param-listm12,R9,TR7,L1,V3,R12,R34,V3,R39,R41,R42,R0,s217,(a, b int, c ...T): the parameters of a vector; end, the line of the closing bracket when\n  known. The vector's recorded line is its opening bracket's (a parameter list after type\n  parameters that span lines: SA200).R3,i410,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code15,results-entriesm12,R9,TR7,L1,V2,R48,R49,R0,s77,The results of a signature: a vector's :tag (one unnamed result) or :results.R3,i428,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,print-resultsm12,R9,TR7,L1,V3,R46,R50,R48,R0,s106,The results of a signature: entries, of the vector rv (:results) or of the parameter\n  vector params' tag.R3,i436,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,line-indentm12,R9,TR7,L1,V0,R0,s42,The indentation of the line being written.R3,i450,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,signaturem12,R9,TR7,L1,V5,R48,R51,R23,R34,V1,R50,R0,s319,(params) results. The parameters' closing bracket goes on the line of the results (their\n  first token follows it on its line: the line they record, else the last parameter's), and\n  without results, when the parameters span lines, on a line of its own only if there is room\n  before the body (its first recorded line).R3,i455,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,func-type-sigm12,R9,TR7,L1,V2,R48,R49,R0,s87,(params) results of (func [params] [results]): the results vector holds names or types.R3,i466,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,struct-tagm10,R9,TR7,L1,V3,R20,R34,V1,R52,R3,i471,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,doc-linesm10,R9,TR7,L1,V1,R53,R3,i478,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,write-docm10,R7,L1,V2,R53,R54,R0,s46,A doc comment (CommentGroup.Text) as // lines.R3,i483,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code18,non-directive-keysS26,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,m8,R9,TR3,i491,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,directives-ofm10,R7,L1,V1,R52,R0,s250,The directive lines of a declared name's metadata (§9.1): :go/<name> true or text (a\n  vector for several), sorted by name. Directives not spelled //go: are free-standing\n  (go/directive \"...\") forms (A6, in the converter's spelling), never metadata.R3,i498,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,pre-linesm10,R7,L1,V2,R53,R81,R0,s135,The number of comment lines before a declaration: doc, a // line between doc and\n  directives (gofmt's doc comment format), directives.R3,i509,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,write-prem8,R7,L1,V3,R53,R81,R54,R3,i516,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code17,interface-method?m10,R9,TR7,L1,V1,R17,R3,i521,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,iface-method-sigm12,R9,TR7,L1,V2,R48,R82,R0,s101,(params) results of an interface method or declaration: [params] then :results or the\n  vector's tag.R3,i525,R4,i1,R5,s28,arbace/repr/go/print_code.aem8,R2,TR3,i532,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,one-line-fields?m12,R9,TR7,L1,V2,R83,R84,R0,s165,go/printer's isOneLineFieldList: one field (group) without tag or doc, whose type prints\n  in at most 30 characters, 29 with names (a method's type is func(...)...).R3,i534,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,struct-fieldsm10,R9,TR7,L1,V1,R85,R3,i552,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,field-bodym12,R9,TR7,L1,V3,R33,R84,R86,R0,s67,One struct field (group) or interface element, with its separators.R3,i558,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,field-listm12,R9,TR7,L1,V5,R87,R85,R84,R34,V1,R18,R0,s55,struct{...} or interface{...} (go/printer's fieldList).R3,i577,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,chan-typem10,R9,TR7,L1,V1,R18,R3,i626,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,type-listm12,R9,TR7,L1,V3,R27,R34,V1,R18,R0,s73,Type arguments [A, B] (of f, whose brackets' positions mode :full takes).R3,i641,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,print-plm8,R2,TR3,i646,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,op-posm12,R9,TR7,L1,V2,R18,R21,R0,s88,Mode :full: the position of the i-th operator of an operator form f (a chain's :go/ops).R3,i648,R4,i1,R5,s28,arbace/repr/go/print_code.aem10,R7,L1,V1,R18,R0,s26,Prints a type form (§5.1).R3,i654,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,type-form?m12,R9,TR7,L1,V1,R18,R0,s116,A form that prints as a type in an operand position: reserved type heads (other than\n  * with two or more operands).R3,i692,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code26,begins-with-star-or-paren?m10,R9,TR7,L1,V1,R18,R3,i701,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,type-paramsm12,R9,TR7,L1,V1,R88,R0,s107,[P C, Q D] after a name; a single parameter whose constraint begins with * gets a trailing\n  comma (§12.2).R3,i705,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,walk-binarym8,R2,TR3,i729,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,walk-rightm12,R9,TR7,L1,V3,R89,R90,R91,R0,s118,go/printer's walkBinary, the part of a right operand r of the operator o (precedence\n  prec): [has4 has5 max-problem].R3,i731,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,walk-prefixesm12,R9,TR7,L1,V1,R18,R0,s246,go/printer's walkBinary of each left-nested prefix of f: (+ a b c d) is (+ (+ (+ a b) c) d),\n  whose prefixes (+ a b), (+ a b c) and f are walked in one pass (each prefix's walk is its\n  left prefix's and its right operand's): a vector, f's last.R3,i744,R4,i1,R5,s28,arbace/repr/go/print_code.aem12,R9,TR7,L1,V1,R18,R0,s49,go/printer's walkBinary: [has4 has5 max-problem].R3,i762,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,cutoff-ofm10,R9,TR7,L1,V2,V3,R92,R93,R94,R95,R3,i767,R4,i1,R5,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,cutoffm10,R9,TR7,L1,V2,R18,R95,R3,i774,R4,i1,R5,s28,arbace/repr/go/print_code.ae")

var Lit_230 *jrt.String = jrt.Intern("arbace.repr.go.print_code$eval74000004$loading__1927001464__auto____74000005")

var Lit_231 *jrt.String = jrt.Intern("arbace.repr.go.print_code$eval74000008$fn__74000009")

var Lit_232 *jrt.String = jrt.Intern("arbace.repr.go.print_code$uses_grouped_QMARK_")

var Lit_233 *jrt.String = jrt.Intern("arbace.repr.go.print_code$fail")

var Lit_234 *jrt.String = jrt.Intern("arbace.repr.go.print_code$eval74000017$__GT_PL__74000031")

var Lit_235 *jrt.String = jrt.Intern("arbace.repr.go.print_code$eval74000017$map__GT_PL__74000033")

var Lit_236 *jrt.String = jrt.Intern("arbace.repr.go.print_code$pl_QMARK_")

var Lit_237 *jrt.String = jrt.Intern("arbace.repr.go.print_code$fp")

var Lit_238 *jrt.String = jrt.Intern("arbace.repr.go.print_code$ptok")

var Lit_239 *jrt.String = jrt.Intern("arbace.repr.go.print_code$ptok_STAR_")

var Lit_240 *jrt.String = jrt.Intern("arbace.repr.go.print_code$child_pos")

var Lit_241 *jrt.String = jrt.Intern("arbace.repr.go.print_code$wrap_full")

var Lit_242 *jrt.String = jrt.Intern("arbace.repr.go.print_code$with_parens")

var Lit_243 *jrt.String = jrt.Intern("arbace.repr.go.print_code$op")

var Lit_244 *jrt.String = jrt.Intern("arbace.repr.go.print_code$args")

var Lit_245 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binary_QMARK_")

var Lit_246 *jrt.String = jrt.Intern("arbace.repr.go.print_code$negative_literal_QMARK_")

var Lit_247 *jrt.String = jrt.Intern("arbace.repr.go.print_code$unary_QMARK_")

var Lit_248 *jrt.String = jrt.Intern("arbace.repr.go.print_code$unary_op")

var Lit_249 *jrt.String = jrt.Intern("arbace.repr.go.print_code$unary_operand")

var Lit_250 *jrt.String = jrt.Intern("arbace.repr.go.print_code$bin_op")

var Lit_251 *jrt.String = jrt.Intern("arbace.repr.go.print_code$bin_prec")

var Lit_252 *jrt.String = jrt.Intern("arbace.repr.go.print_code$prec_of")

var Lit_253 *jrt.String = jrt.Intern("arbace.repr.go.print_code$go_sym_QMARK_")

var Lit_254 *jrt.String = jrt.Intern("arbace.repr.go.print_code$statement_form_QMARK_")

var Lit_255 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expression_form_QMARK_")

var Lit_256 *jrt.String = jrt.Intern("arbace.repr.go.print_code$line_of")

var Lit_257 *jrt.String = jrt.Intern("arbace.repr.go.print_code$breaks_of")

var Lit_258 *jrt.String = jrt.Intern("arbace.repr.go.print_code$break_line")

var Lit_259 *jrt.String = jrt.Intern("arbace.repr.go.print_code$child_target")

var Lit_260 *jrt.String = jrt.Intern("arbace.repr.go.print_code$next_targets")

var Lit_261 *jrt.String = jrt.Intern("arbace.repr.go.print_code$room_QMARK_")

var Lit_262 *jrt.String = jrt.Intern("arbace.repr.go.print_code$body_offset")

var Lit_263 *jrt.String = jrt.Intern("arbace.repr.go.print_code$next_line")

var Lit_264 *jrt.String = jrt.Intern("arbace.repr.go.print_code$comma_list")

var Lit_265 *jrt.String = jrt.Intern("arbace.repr.go.print_code$ident_string")

var Lit_266 *jrt.String = jrt.Intern("arbace.repr.go.print_code$name_tok")

var Lit_267 *jrt.String = jrt.Intern("arbace.repr.go.print_code$name_list")

var Lit_268 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_line")

var Lit_269 *jrt.String = jrt.Intern("arbace.repr.go.print_code$label_name")

var Lit_270 *jrt.String = jrt.Intern("arbace.repr.go.print_code$literal")

var Lit_271 *jrt.String = jrt.Intern("arbace.repr.go.print_code$element_list")

var Lit_272 *jrt.String = jrt.Intern("arbace.repr.go.print_code$tagged_QMARK_")

var Lit_273 *jrt.String = jrt.Intern("arbace.repr.go.print_code$param_entries")

var Lit_274 *jrt.String = jrt.Intern("arbace.repr.go.print_code$groupable_QMARK_")

var Lit_275 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_entries")

var Lit_276 *jrt.String = jrt.Intern("arbace.repr.go.print_code$variadic_elem")

var Lit_277 *jrt.String = jrt.Intern("arbace.repr.go.print_code$param_list")

var Lit_278 *jrt.String = jrt.Intern("arbace.repr.go.print_code$results_entries")

var Lit_279 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_results")

var Lit_280 *jrt.String = jrt.Intern("arbace.repr.go.print_code$line_indent")

var Lit_281 *jrt.String = jrt.Intern("arbace.repr.go.print_code$signature")

var Lit_282 *jrt.String = jrt.Intern("arbace.repr.go.print_code$func_type_sig")

var Lit_283 *jrt.String = jrt.Intern("arbace.repr.go.print_code$struct_tag")

var Lit_284 *jrt.String = jrt.Intern("arbace.repr.go.print_code$doc_lines")

var Lit_285 *jrt.String = jrt.Intern("arbace.repr.go.print_code$write_doc")

var Lit_286 *jrt.String = jrt.Intern("arbace.repr.go.print_code$directives_of")

var Lit_287 *jrt.String = jrt.Intern("arbace.repr.go.print_code$pre_lines")

var Lit_288 *jrt.String = jrt.Intern("arbace.repr.go.print_code$write_pre")

var Lit_289 *jrt.String = jrt.Intern("arbace.repr.go.print_code$interface_method_QMARK_")

var Lit_290 *jrt.String = jrt.Intern("arbace.repr.go.print_code$iface_method_sig")

var Lit_291 *jrt.String = jrt.Intern("arbace.repr.go.print_code$one_line_fields_QMARK_")

var Lit_292 *jrt.String = jrt.Intern("arbace.repr.go.print_code$struct_fields")

var Lit_293 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_body")

var Lit_294 *jrt.String = jrt.Intern("arbace.repr.go.print_code$field_list")

var Lit_295 *jrt.String = jrt.Intern("arbace.repr.go.print_code$chan_type")

var Lit_296 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_list")

var Lit_297 *jrt.String = jrt.Intern("arbace.repr.go.print_code$op_pos")

var Lit_298 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_expr")

var Lit_299 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_form_QMARK_")

var Lit_300 *jrt.String = jrt.Intern("arbace.repr.go.print_code$begins_with_star_or_paren_QMARK_")

var Lit_301 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_params")

var Lit_302 *jrt.String = jrt.Intern("arbace.repr.go.print_code$walk_right")

var Lit_303 *jrt.String = jrt.Intern("arbace.repr.go.print_code$walk_prefixes")

var Lit_304 *jrt.String = jrt.Intern("arbace.repr.go.print_code$walk_binary")

var Lit_305 *jrt.String = jrt.Intern("arbace.repr.go.print_code$cutoff_of")

var Lit_306 *jrt.String = jrt.Intern("arbace.repr.go.print_code$cutoff")

var Lit_307 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,xyn4,preckn4,linekn6,columnkn4,fileyn1,dkn3,docyn1,fyn5,prec1yn3,cutyn5,depthyn2,xsyn6,offsetyn1,hyn1,tyn2,elyn1,skn7,dynamicyn6,targetyn4,inityn2,nmyn4,for?yn4,condyn4,postyn1,byn6,parentyn1,ikn8,declaredyn3,elsyn4,optsyn7,clausesyn10,print-headyn1,&yn1,vyn1,cyn5,formsyn2,ityn6,indentyn5,more?yn5,itemsyn9,keep-typeyn3,itskn4,keysyn8,results?kn2,asyn3,endyn5,func?yn3,sepyn4,nextyn7,method?yn6,group?yn5,specsyn2,kwyn3,docyn10,print-specyn7,meta-ofyn3,tpsv25,arbace.repr.go.print-code9,diff-precm10,R0,TR1,L1,V2,R2,R3,R4,i776,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,reduce-depthm10,R0,TR1,L1,V1,R7,R4,i779,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,paren-operandm12,R0,TR1,L1,V1,R2,R8,s140,An operand of && or || the source parenthesized (:go/paren, C3): gc removes dead branches\n  by syntax and does not look through parentheses.R4,i781,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,binary-exprm12,R0,TR1,L1,V4,R9,R10,R11,R12,R8,s341,go/printer's binaryExpr. An n-ary form is a left-nested chain, (+ a b c) printed as\n  (+ (+ a b) c): its prefixes are printed in one pass, each with its own cutoff, as the\n  recursion through them would (each prefix's expr1 first moving to f's line, then its left\n  operand, then its operator and right operand), without making the prefixes.R4,i792,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,call-argsm12,R0,TR1,L1,V4,R9,R13,R12,R14,R8,s47,(args) of a call; a final (spread xs) is xs....R4,i829,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,calleem10,R0,TR1,L1,V2,R15,R12,R4,i839,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code22,lit-type-needs-parens?m10,R0,TR1,L1,V1,R16,R4,i844,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,lit-elementsm10,R0,TR1,L1,V1,R9,R4,i849,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,key-sizem12,R0,TR1,L1,V1,R17,R8,s59,The printed width of a key, for gofmt's alignment decision.R4,i864,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,composite-litm10,R0,TR1,L1,V2,R9,R12,R4,i876,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,slice-exprm10,R0,TR1,L1,V2,R9,R12,R4,i914,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,func-litm12,R0,TR1,L1,V1,R9,R8,s27,(fn params results? body*).R4,i931,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,new-argm10,R0,TR1,L1,V1,R2,R4,i947,R5,i1,R6,s28,arbace/repr/go/print_code.aem12,R0,TR1,L1,V1,R9,R8,s85,A literal of mode :full (wrap-full) at its position, in its spelling and parentheses.R4,i955,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,lit-list-tokm12,R0,TR1,L1,V2,R9,R18,R8,s122,The token of a literal list ((rune n), (imaginary x), (byte-string ...)): its spelling in\n  mode :full (:go/text), else s.R4,i966,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R1,L1,V3,R9,R10,R12,R8,s72,go/printer's expr1: prints f as an operand of precedence at least prec1.R4,i972,R5,i1,R6,s28,arbace/repr/go/print_code.aem8,R1,L1,V2,R9,R12,R4,i1060,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,expr-listm12,R0,TR1,L1,V2,R9,R12,R8,s169,e1, e2, ...: (values ...) or one expression; the values on the line of the values form,\n  each after the first on its recorded line (its own, or the values' :go/breaks).R4,i1062,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,n-valuesm10,R0,TR1,L1,V1,R9,R4,i1071,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,zero-form?m10,R0,TR1,L1,V1,R9,R4,i1076,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,*in-group*m10,R19,TR4,i1078,R5,i1,R6,s28,arbace/repr/go/print_code.aeR8,s96,Mode :full: true for a spec of a local var or type ( ... ) group (its keyword is the\n  group's).v25,arbace.repr.go.print-code7,targetsm10,R0,TR1,L1,V1,R16,R4,i1083,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,binding-stmtm10,R1,L1,V2,R20,R21,R8,s60,A let binding pair as a Go statement: :=, var, const (§7.3).R4,i1085,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code17,type-binding-stmtm10,R0,TR1,L1,V2,R22,R16,R4,i1108,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,assign-stmtm10,R0,TR1,L1,V1,R9,R4,i1118,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R1,L1,V1,R9,R8,s151,A simple statement: an init or post statement, a select communication, an expression\n  statement, an assignment, a := binding written as [target init].R4,i1128,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,clause?m10,R0,TR1,L1,V1,R9,R4,i1149,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code14,control-clausem12,R0,TR1,L1,V4,R23,R21,R24,R25,R8,s67,go/printer's controlClause: init; cond; post of if, switch and for.R4,i1151,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,branch-formsm12,R0,TR1,L1,V1,R26,R8,s83,The statement list of a branch: (do ...) is its forms, anything else one statement.R4,i1169,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,branch-optsm12,R0,TR1,L1,V3,R27,R28,R26,R8,s65,block-body's :parent and :offset for branch b, child i of parent.R4,i1174,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,if-like?m10,R0,TR1,L1,V1,R9,R4,i1179,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,if-stmtm8,R29,TR4,i1181,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,else-partm10,R0,TR1,L1,V2,R30,R31,R4,i1183,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R0,TR1,L1,V1,R9,R4,i1189,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,clause-listm12,R0,TR1,L1,V4,R32,R33,R34,V1,R9,R8,s67,The clauses of a switch, type switch or select (f), between braces.R4,i1236,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,case-exprsm10,R0,TR1,L1,V1,R35,R4,i1259,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,case-typesm10,R0,TR1,L1,V1,R35,R4,i1264,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,switch-stmtm10,R0,TR1,L1,V1,R9,R4,i1269,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,type-switch-stmtm10,R0,TR1,L1,V1,R9,R4,i1281,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code4,commm10,R0,TR1,L1,V1,R36,R4,i1300,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,select-stmtm10,R0,TR1,L1,V1,R9,R4,i1305,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,braces-ofm10,R0,TR1,L1,V1,R9,R4,i1311,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,for-stmtm10,R0,TR1,L1,V1,R9,R4,i1313,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,while-stmtm10,R0,TR1,L1,V1,R9,R4,i1320,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,range-stmtm10,R0,TR1,L1,V1,R9,R4,i1326,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,label-stmtm8,R29,TR4,i1339,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R1,L1,V1,R9,R8,s64,Prints one statement form (not a let: stmt-list flattens those).R4,i1341,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,flatten-stmtsm12,R0,TR1,L1,V3,R37,R27,R14,R8,s312,The items of a statement list: {:form f} or {:bind [target init] :t line} or\n  {:type-bind [name type]}; a let (or let-type) last in a list continues the list with its\n  body, one that is not last is a block of its own. parent and offset: the list holding the\n  forms and the index of the first (for :go/breaks).R4,i1371,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,item-tm10,R0,TR1,L1,V1,R38,R4,i1402,R5,i1,R6,s28,arbace/repr/go/print_code.aem12,R0,TR1,L1,V3,R9,R39,R40,R8,s146,(label :L s?): L: s. A label without a statement is followed by ; when more statements\n  follow (more?). Nested labels print in a row (L1: L2: s).R4,i1404,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,bind-targetm10,R0,TR1,L1,V1,R38,R4,i1421,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,const-bind?m10,R0,TR1,L1,V1,R38,R4,i1423,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,group-constsm12,R0,TR1,L1,V1,R41,R8,s152,Joins the bindings of a local const ( ... ) group (C2): a const binding whose target\n  carries :go/grouped continues the group of the binding before it.R4,i1428,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,label-targetm12,R0,TR1,L1,V1,R38,R8,s90,The first target of an item's declaration, which a labeled declaration's label is on (A9).R4,i1442,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,label-ofm12,R0,TR1,L1,V1,R38,R8,s71,The label of a labeled declaration (:go/label on its first target, A9).R4,i1447,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,const-specm12,R0,TR1,L1,V2,V2,R20,R21,R42,R8,s91,One spec of a local const group: names, type and values, or the names alone (:go/implicit).R4,i1453,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,keep-type-columnm8,R29,TR4,i1465,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code11,const-groupm12,R0,TR1,L1,V2,R43,R39,R8,s81,const ( specs ) in a function body, at indent: its specs on their recorded lines.R4,i1467,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code12,group-targetm12,R0,TR1,L1,V1,R16,R8,s78,The line of a const group's keyword: the line before its first spec when free.R4,i1486,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code7,*group*m10,R19,TR4,i1491,R5,i1,R6,s28,arbace/repr/go/print_code.aeR8,s103,Mode :full: an atom holding the local var or type ( ... ) group being printed: {:end\n  rparen}, or nil.v25,arbace.repr.go.print-code14,item-group-posm12,R0,TR1,L1,V1,R38,R8,s114,Mode :full: the :go/pos of the first target of a let item (its declaration's keyword and\n  parentheses are there).R4,i1496,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,item-startm12,R0,TR1,L1,V1,R38,R8,s57,Mode :full: the position of the first name of a let item.R4,i1505,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code14,full-in-group?m10,R0,TR1,L1,V1,R38,R4,i1512,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code16,full-group-open!m12,R0,TR1,L1,V1,R38,R8,s99,Mode :full: a local var or type declaration with parentheses starts its group: its keyword\n  and (.R4,i1515,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code17,full-group-close!m12,R0,TR1,L1,V2,R41,R28,R8,s77,Mode :full: after items' i-th, the group's ) when the next item is not in it.R4,i1526,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R1,L1,V2,R37,m4,R44,V4,R39,R45,R27,R14,R46,R31,R8,s224,Prints a statement list at indent (opts :indent), each statement on its recorded line.\n  :results? makes a final expression the function's return (§6.4). :parent and :offset\n  locate the forms in their list (for :go/breaks).R4,i1537,R5,i1,R6,s28,arbace/repr/go/print_code.aem10,R1,L1,V2,R37,m4,R44,V7,R45,R47,R48,R49,R50,R27,R14,R46,R31,R8,s433,{ statements } at one more indentation than the line of the brace. opts: :results?,\n  :end (the recorded line of the closing brace), :func? (a function body: gofmt keeps it on\n  one line when the source has it so), :sep (whitespace before the brace), :next (the line\n  of what follows the brace), :else-follows?, :indent (the indentation of the line the\n  construct began on, when its header may span lines: a function's parameters).R4,i1585,R5,i1,R6,s28,arbace/repr/go/print_code.aem12,R0,TR1,L1,V3,R37,R45,R39,R8,s88,A function body on one line: statements separated by semicolons (go/printer's funcBody).R4,i1626,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code15,parse-decl-headm10,R1,L1,V1,R13,R8,s105,[doc opts rest] of the arguments after a declaration's name: an optional doc string, then\n  :type-params.R4,i1647,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code13,generic-type?m10,R0,TR1,L1,V1,R16,R4,i1655,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,func-declm10,R1,L1,V2,R9,R51,R8,s29,go/func and go/method (§6.4).R4,i1660,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,spec-namem10,R0,TR1,L1,V1,R16,R4,i1691,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,value-specm12,R0,TR1,L1,V4,R20,R21,R52,R42,R8,s78,Names, type and values of a const or var spec. keep-type: gofmt's type column.R4,i1693,R5,i1,R6,s28,arbace/repr/go/print_code.aem12,R0,TR1,L1,V1,R53,R8,s57,go/printer's keepTypeColumn over the specs [target init].R4,i1705,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code6,spec-tm10,R0,TR1,L1,V1,R35,R4,i1724,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code10,group-declm12,R0,TR1,L1,V7,R54,R55,R53,R56,R57,R34,V1,R9,R8,s85,kw ( specs ): print-spec prints one spec vector given its index (f: the declaration).R4,i1727,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code14,const-var-declm10,R0,TR1,L1,V2,R9,R54,R4,i1764,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,type-specm10,R0,TR1,L1,V4,R22,R58,R16,R52,R4,i1780,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code15,parse-type-specm10,R0,TR1,L1,V1,R13,R4,i1788,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code9,type-declm10,R0,TR1,L1,V1,R9,R4,i1794,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code23,decl-doc-and-directivesm10,R1,L1,V1,R9,R8,s37,[doc directives] of a top-level form.R4,i1807,R5,i1,R6,s28,arbace/repr/go/print_code.aev25,arbace.repr.go.print-code8,top-declm10,R1,L1,V1,R9,R8,s74,Prints a top-level declaration form, after its doc comment and directives.R4,i1829,R5,i1,R6,s28,arbace/repr/go/print_code.ae")

var Lit_308 *jrt.String = jrt.Intern("arbace.repr.go.print_code$diff_prec")

var Lit_309 *jrt.String = jrt.Intern("arbace.repr.go.print_code$reduce_depth")

var Lit_310 *jrt.String = jrt.Intern("arbace.repr.go.print_code$paren_operand")

var Lit_311 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binary_expr")

var Lit_312 *jrt.String = jrt.Intern("arbace.repr.go.print_code$call_args")

var Lit_313 *jrt.String = jrt.Intern("arbace.repr.go.print_code$callee")

var Lit_314 *jrt.String = jrt.Intern("arbace.repr.go.print_code$lit_type_needs_parens_QMARK_")

var Lit_315 *jrt.String = jrt.Intern("arbace.repr.go.print_code$lit_elements")

var Lit_316 *jrt.String = jrt.Intern("arbace.repr.go.print_code$key_size")

var Lit_317 *jrt.String = jrt.Intern("arbace.repr.go.print_code$composite_lit")

var Lit_318 *jrt.String = jrt.Intern("arbace.repr.go.print_code$slice_expr")

var Lit_319 *jrt.String = jrt.Intern("arbace.repr.go.print_code$func_lit")

var Lit_320 *jrt.String = jrt.Intern("arbace.repr.go.print_code$new_arg")

var Lit_321 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_pl")

var Lit_322 *jrt.String = jrt.Intern("arbace.repr.go.print_code$lit_list_tok")

var Lit_323 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr1")

var Lit_324 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr0")

var Lit_325 *jrt.String = jrt.Intern("arbace.repr.go.print_code$expr_list")

var Lit_326 *jrt.String = jrt.Intern("arbace.repr.go.print_code$n_values")

var Lit_327 *jrt.String = jrt.Intern("arbace.repr.go.print_code$zero_form_QMARK_")

var Lit_328 *jrt.String = jrt.Intern("arbace.repr.go.print_code$targets")

var Lit_329 *jrt.String = jrt.Intern("arbace.repr.go.print_code$binding_stmt")

var Lit_330 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_binding_stmt")

var Lit_331 *jrt.String = jrt.Intern("arbace.repr.go.print_code$assign_stmt")

var Lit_332 *jrt.String = jrt.Intern("arbace.repr.go.print_code$simple_stmt")

var Lit_333 *jrt.String = jrt.Intern("arbace.repr.go.print_code$clause_QMARK_")

var Lit_334 *jrt.String = jrt.Intern("arbace.repr.go.print_code$control_clause")

var Lit_335 *jrt.String = jrt.Intern("arbace.repr.go.print_code$branch_forms")

var Lit_336 *jrt.String = jrt.Intern("arbace.repr.go.print_code$branch_opts")

var Lit_337 *jrt.String = jrt.Intern("arbace.repr.go.print_code$if_like_QMARK_")

var Lit_338 *jrt.String = jrt.Intern("arbace.repr.go.print_code$else_part")

var Lit_339 *jrt.String = jrt.Intern("arbace.repr.go.print_code$if_stmt")

var Lit_340 *jrt.String = jrt.Intern("arbace.repr.go.print_code$clause_list")

var Lit_341 *jrt.String = jrt.Intern("arbace.repr.go.print_code$case_exprs")

var Lit_342 *jrt.String = jrt.Intern("arbace.repr.go.print_code$case_types")

var Lit_343 *jrt.String = jrt.Intern("arbace.repr.go.print_code$switch_stmt")

var Lit_344 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_switch_stmt")

var Lit_345 *jrt.String = jrt.Intern("arbace.repr.go.print_code$comm")

var Lit_346 *jrt.String = jrt.Intern("arbace.repr.go.print_code$select_stmt")

var Lit_347 *jrt.String = jrt.Intern("arbace.repr.go.print_code$braces_of")

var Lit_348 *jrt.String = jrt.Intern("arbace.repr.go.print_code$for_stmt")

var Lit_349 *jrt.String = jrt.Intern("arbace.repr.go.print_code$while_stmt")

var Lit_350 *jrt.String = jrt.Intern("arbace.repr.go.print_code$range_stmt")

var Lit_351 *jrt.String = jrt.Intern("arbace.repr.go.print_code$print_stmt")

var Lit_352 *jrt.String = jrt.Intern("arbace.repr.go.print_code$flatten_stmts")

var Lit_353 *jrt.String = jrt.Intern("arbace.repr.go.print_code$item_t")

var Lit_354 *jrt.String = jrt.Intern("arbace.repr.go.print_code$label_stmt")

var Lit_355 *jrt.String = jrt.Intern("arbace.repr.go.print_code$bind_target")

var Lit_356 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_bind_QMARK_")

var Lit_357 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_consts")

var Lit_358 *jrt.String = jrt.Intern("arbace.repr.go.print_code$label_target")

var Lit_359 *jrt.String = jrt.Intern("arbace.repr.go.print_code$label_of")

var Lit_360 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_spec")

var Lit_361 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_group")

var Lit_362 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_target")

var Lit_363 *jrt.String = jrt.Intern("arbace.repr.go.print_code$item_group_pos")

var Lit_364 *jrt.String = jrt.Intern("arbace.repr.go.print_code$item_start")

var Lit_365 *jrt.String = jrt.Intern("arbace.repr.go.print_code$full_in_group_QMARK_")

var Lit_366 *jrt.String = jrt.Intern("arbace.repr.go.print_code$full_group_open_BANG_")

var Lit_367 *jrt.String = jrt.Intern("arbace.repr.go.print_code$full_group_close_BANG_")

var Lit_368 *jrt.String = jrt.Intern("arbace.repr.go.print_code$stmt_list")

var Lit_369 *jrt.String = jrt.Intern("arbace.repr.go.print_code$block_body")

var Lit_370 *jrt.String = jrt.Intern("arbace.repr.go.print_code$stmt_list_one_line")

var Lit_371 *jrt.String = jrt.Intern("arbace.repr.go.print_code$parse_decl_head")

var Lit_372 *jrt.String = jrt.Intern("arbace.repr.go.print_code$generic_type_QMARK_")

var Lit_373 *jrt.String = jrt.Intern("arbace.repr.go.print_code$func_decl")

var Lit_374 *jrt.String = jrt.Intern("arbace.repr.go.print_code$spec_name")

var Lit_375 *jrt.String = jrt.Intern("arbace.repr.go.print_code$value_spec")

var Lit_376 *jrt.String = jrt.Intern("arbace.repr.go.print_code$keep_type_column")

var Lit_377 *jrt.String = jrt.Intern("arbace.repr.go.print_code$spec_t")

var Lit_378 *jrt.String = jrt.Intern("arbace.repr.go.print_code$group_decl")

var Lit_379 *jrt.String = jrt.Intern("arbace.repr.go.print_code$const_var_decl")

var Lit_380 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_spec")

var Lit_381 *jrt.String = jrt.Intern("arbace.repr.go.print_code$parse_type_spec")

var Lit_382 *jrt.String = jrt.Intern("arbace.repr.go.print_code$type_decl")

var Lit_383 *jrt.String = jrt.Intern("arbace.repr.go.print_code$decl_doc_and_directives")

var Lit_384 *jrt.String = jrt.Intern("arbace.repr.go.print_code$top_decl")
