//line j2g_strings.ae:1
package aot_arbace_j2g_fromfn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn3,tagkn10,functionalkn4,typekn11,annotationskn4,elseys3,jrt3,Boxyn9,fromFnRefkn4,langkn4,castyn11,.ArrayClassyn10,fromFnCharkn4,descyn16,.ApplyTo_ISeq__Oyn1,fyn14,RT_Seq_O__ISeqys3,jrt10,RefArrayOfys3,jrt12,Object_classyn2,fnyn6,returnyn4,set!yn8,.-FromFnyn5,.Infoyn1,xyn3,anyyn3,letyn8,IFn_Castyn4,addryn3,litkn2,Fnys2,go4,funckn11,type-paramsyn1,Tyn1,*kn4,linekn6,columnyn4,whenyn2,==yn1,pyn6,uint16yn6,valuesyn1,vyn2,okys3,jrt5,Unboxys3,jrt9,Prim_charyn1,ryn3,notyn5,panicys3,jrt6,Thrownys3,jrt3,NPEys3,jrt9,ClassCastyn6,assertyn4,initys3,j2g7,commentv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,v11,arbace.core5,referR15,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn17,arbace.j2g.fromfnm2,R16,s660,J2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (j2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.v11,arbace.core9,with-metaR17,v11,arbace.core6,concatv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv17,arbace.j2g.fromfn5,castsV1,V3,s14,arbace/lang/RTs3,seqs38,(Ljava/lang/Object;)Larbace/lang/ISeq;v18,arbace.classes.env6,known?v18,arbace.classes.env9,reflectedR18,v22,arbace.classes.analyze4,declv11,arbace.core4,someR19,v11,arbace.core5,forceR20,v11,arbace.core9,contains?v11,arbace.core4,sortv11,arbace.core6,filterv18,arbace.classes.env10,interface?v11,arbace.core3,notv16,arbace.j2g.model10,reflected?v17,arbace.j2g.fromfn11,functional?v16,arbace.j2g.names13,compiled-pkg?v16,arbace.j2g.model3,pkgv22,arbace.classes.analyze8,find-samv20,arbace.classes.types5,prim?v11,arbace.core4,listv16,arbace.j2g.model13,pointer-desc?R21,R22,R23,v20,arbace.classes.types6,array?v16,arbace.j2g.model10,array-testR24,R25,v20,arbace.classes.types9,elem-typev11,arbace.core7,iterateR26,v11,arbace.core6,symbolv20,arbace.classes.types15,prim-desc->namev16,arbace.j2g.model9,class-symv20,arbace.classes.types14,desc->internalv16,arbace.j2g.names11,method-baseR27,v20,arbace.classes.types17,parse-method-descR28,v11,arbace.core3,vecv11,arbace.core5,rangeR29,R30,R31,v11,arbace.core5,applyR32,R33,v11,arbace.core3,mapv17,arbace.j2g.fromfn3,boxR34,v17,arbace.j2g.fromfn3,tagv16,arbace.j2g.model7,go-typev11,arbace.core4,not=v11,arbace.core9,vary-metav11,arbace.core5,assocR35,v17,arbace.j2g.fromfn6,resultR36,R37,R38,R34,R39,R40,m2,R17,R40,R41,R30,R42,R39,R43,R44,R45,ML7,R46,R23,R47,V1,R48,MV1,Myn1,pm2,R17,ML2,R49,R48,m4,R50,i92,R51,i56,m2,R17,R40,ML3,R52,ML3,R53,R54,nm4,R50,i93,R51,i15,ML2,R35,nm4,R50,i93,R51,i26,m4,R50,i93,R51,i9,R54,m4,R50,i92,R51,i7,ML4,R46,R27,MV1,Myn1,rm2,R17,R40,m2,R17,R55,ML4,R41,V2,ML3,R56,R57,R58,m4,R50,i96,R51,i15,ML3,R59,R60,R61,m4,R50,i96,R51,i29,ML4,R52,ML2,R62,R58,m4,R50,i97,R51,i17,ML3,R52,ML3,R53,R61,nm4,R50,i98,R51,i19,ML2,R63,ML2,R64,ML1,R65,m4,R50,i98,R51,i49,m4,R50,i98,R51,i37,m4,R50,i98,R51,i30,m4,R50,i98,R51,i13,ML2,R63,ML3,R66,R61,R60,m4,R50,i99,R51,i20,m4,R50,i99,R51,i13,m4,R50,i97,R51,i11,ML3,R67,R55,R57,m4,R50,i100,R51,i11,m4,R50,i96,R51,i9,m4,R50,i95,R51,i7,R46,R68,v17,arbace.j2g.fromfn8,set-formR69,")

var Lit_1 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_2 *jrt.String = jrt.Intern("arbace/lang/IFn")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.fromfn$fis$fn__564000037")

var Lit_4 *jrt.String = jrt.Intern("---- FromFn of ")

var Lit_5 *jrt.String = jrt.Intern(" functional interfaces (J2G-SPEC §7.11)")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.fromfn$functional_QMARK_$fn__564000031")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.fromfn$functional_QMARK_$fn__564000033")

var Lit_8 *jrt.String = jrt.Intern("java.lang.FunctionalInterface")

var Lit_9 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_10 *jrt.String = jrt.Intern("_")

var Lit_11 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_12 *jrt.String = jrt.Intern("C")

var Lit_13 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.fromfn$result$fn__564000042")

var Lit_15 *jrt.String = jrt.Intern("_Cast")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.fromfn$result$fn__564000042$fn__564000043")

var Lit_17 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_18 *jrt.String = jrt.Intern("_class")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.fromfn$roots$iter__564000013__564000017")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.fromfn$roots$iter__564000013__564000017$fn__564000018")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.fromfn$roots$iter__564000013__564000017$fn__564000018$fn__564000019")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.fromfn$set_form$iter__564000052__564000056")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.fromfn$set_form$fn__564000063")

var Lit_24 *jrt.String = jrt.Intern("V")

var Lit_25 *jrt.String = jrt.Intern("_Fn")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.fromfn$set_form$iter__564000052__564000056$fn__564000057")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.fromfn$set_form$iter__564000052__564000056$fn__564000057$fn__564000058")

var Lit_28 *jrt.String = jrt.Intern("p")

var Lit_29 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,symyn4,typekn4,linekn6,columnkn4,fileyn1,nyn1,Tyn1,pyn1,dyn1,ryn2,fiyn3,fisv11,arbace.core5,in-nsMyn17,arbace.j2g.fromfnm2,R0,s660,J2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (j2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.m2,R0,s660,J2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (j2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.R1,v17,arbace.j2g.fromfn3,tagm10,R2,TR3,L1,V2,R4,R5,R6,i18,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn5,castsm14,s1,Zs11,booleanCasts1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Ss9,shortCasts1,Bs8,byteCasts1,Fs9,floatCastm10,R2,TR6,i20,R7,i1,R8,s20,arbace/j2g/fromfn.aeR0,s83,Reflector.coerceAdapterReturn: a primitive result by RT's casts (boolean by truth).v17,arbace.j2g.fromfn5,rootsm10,R3,L1,V0,R0,s50,What the FromFn adapters call: reachability roots.R6,i25,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn11,functional?m10,R2,TR3,L1,V1,R9,R6,i32,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn3,fism10,R3,L1,V1,R10,R0,s175,The functional interfaces among the classes T that get FromFn: interfaces with\n  @FunctionalInterface and one abstract method (none when the program has no Clojure\n  runtime).R6,i38,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn3,boxm10,R2,TR3,L1,V2,R11,R12,R6,i49,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn6,resultm10,R2,TR3,L1,V2,R13,R12,R6,i54,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn8,set-formm10,R3,L1,V1,R14,R0,s79,The statement setting FromFn of functional interface fi (in the init function).R6,i72,R7,i1,R8,s20,arbace/j2g/fromfn.aev17,arbace.j2g.fromfn5,formsm10,R3,L1,V1,R15,R0,s83,The forms of j2g_fromfn.go (package arbace/lang) for the functional interfaces fis.R6,i87,R7,i1,R8,s20,arbace/j2g/fromfn.ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.fromfn$eval564000004$loading__1927001464__auto____564000005")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.fromfn$eval564000008$fn__564000009")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.fromfn$tag")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.fromfn$roots")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.fromfn$functional_QMARK_")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.fromfn$fis")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.fromfn$box")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.fromfn$result")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.fromfn$set_form")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.fromfn$forms")
