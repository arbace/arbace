//line aot_arbace_j2g_fromfn.ae:1
package aot_arbace_j2g_fromfn

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_New() *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(A_arbace_j2g_fromfn_A_const_3, A_arbace_j2g_fromfn_A_const_4, A_arbace_j2g_fromfn_A_const_5, A_arbace_j2g_fromfn_A_const_6, A_arbace_j2g_fromfn_A_const_7, A_arbace_j2g_fromfn_A_const_8, A_arbace_j2g_fromfn_A_const_9); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_New() *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000008_fn__564000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_14), A_arbace_j2g_fromfn_A_const_12.GetRawRoot__O(), A_arbace_j2g_fromfn_A_const_13) }
















func A_arbace_j2g_fromfn_tag_A_New() *A_arbace_j2g_fromfn_tag_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_tag_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Ctor() {}
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O()).Invoke_O_O__O(sym__0, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_fromfn_A_const_16, type__1))) }






func A_arbace_j2g_fromfn_roots_A_New() *A_arbace_j2g_fromfn_roots_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_17.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____1 any; var tmp3 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class
	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_fromfn_A_const_30.GetRawRoot__O())
//line :28:1
	return tmp1.Invoke_O_O__O(tmp2, A_arbace_j2g_fromfn_A_const_29) }
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New() *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Invoke_O_O__O(self, s__564000014__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(s__564000014__1, self); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Ctor_O_O(c__s__564000014, c__iter__564000013 any) { t.F_s__564000014 = c__s__564000014; t.F_iter__564000013 = c__iter__564000013 }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Invoke_O__O(self any) any { { var s__564000014__1 any; var t_ any = t.F_s__564000014; t.F_s__564000014 = nil; s__564000014__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O()).Invoke_O__O(s__564000014__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000014__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O()).Invoke_O__O(s__564000014__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O()).Invoke_O__O(s__564000014__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__564000016__6 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(b__564000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O()).Invoke_O__O(b__564000016__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O()).Invoke_O__O(s__564000014__3))) } else { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O()).Invoke_O__O(b__564000016__6), nil) } } else { var vec__564000024__4 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O()).Invoke_O__O(s__564000014__3); var r__5 any = lang.RT_Nth_O_I_O__O(vec__564000024__4, lang.RT_IntCast_J__I(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O(vec__564000024__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O()).Invoke_O__O(s__564000014__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Ctor_O_I_O(c__b__564000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000016 = c__b__564000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Invoke_O__O(self any) any { { var i__564000015__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__564000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__564000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__564000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O(vec__564000020__2, lang.RT_IntCast_J__I(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O(vec__564000020__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__564000016; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref())); i__564000015__1 = lang.Numbers_Unchecked_inc_J__J(i__564000015__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_fromfn_functional_QMARK__A_New() *A_arbace_j2g_fromfn_functional_QMARK__A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Invoke_O_O__O(self, n__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_31.GetRawRoot__O()).Invoke_O__O(n__0)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_fromfn_A_const_35; var tmp3 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return tmp1.Invoke_O_O_O__O(n__0, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else {
//line :33:1
			var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_33.GetRawRoot__O()).Invoke_O__O(n__0)

			if jrt.J2g_Truth(temp__1927000414__auto____2) { var d__3 any = temp__1927000414__auto____2; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_34.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New(); var tmp7 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class
				if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }; return tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_38.Invoke_O__O(d__3))) } else {
//line :35:1
					return nil } } }
//line :34:1
func A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Invoke_O_O__O(self, c__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__1)).IsAnnotationPresent_Class__Z(lang.RT_ClassForNameNonLoading_String__Class(Lit_8))).Ref() }

func A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Invoke_O_O__O(self, p1__564000030_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_9, A_arbace_j2g_fromfn_A_const_36.Invoke_O__O(p1__564000030_SHARP___1))).Ref() }

func A_arbace_j2g_fromfn_fis_A_New() *A_arbace_j2g_fromfn_fis_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_fromfn_fis_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_fromfn_fis_A) Invoke_O_O__O(self, T__0_ any) any {




	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O()).Invoke_O_O__O(T__0_, Lit_1); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O()).Invoke_O_O__O(T__0_, Lit_2) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_40.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_41.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_fromfn_fis_fn__564000037_A_New(); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; return tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), T__0_)) } else {
//line :43:1
			return nil } }
func A_arbace_j2g_fromfn_fis_fn__564000037_A_New() *A_arbace_j2g_fromfn_fis_fn__564000037_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_fn__564000037_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Ctor() {}
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Invoke_O_O__O(self, p1__564000036_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_42.GetRawRoot__O()).Invoke_O__O(p1__564000036_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_46.GetRawRoot__O()).Invoke_O__O(p1__564000036_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_44.GetRawRoot__O()).Invoke_O__O(p1__564000036_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O()).Invoke_O__O(p1__564000036_SHARP___1))); if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_45.GetRawRoot__O()).Invoke_O__O(p1__564000036_SHARP___1)
//line :44:1
	return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___8 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___8; tmp1 = nil } else { panic(tmp2) } }; return tmp1 } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_fromfn_box_A_New() *A_arbace_j2g_fromfn_box_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_box_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_fromfn_box_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_fromfn_box_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O()).Invoke_O__O(d__1)) { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_53, p__0) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_51.GetRawRoot__O()).Invoke_O__O(d__1)) {
		return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_54, p__0) } else {
//line :50:1
			if A_arbace_j2g_fromfn_A_const_52 != nil { return p__0 } else { return nil
			}
		}
	} }
func A_arbace_j2g_fromfn_result_A_New() *A_arbace_j2g_fromfn_result_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_fromfn_result_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_fromfn_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_30.GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_fromfn_A_const_57; return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O_O__O(tmp2, Lit_1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_30.GetRawRoot__O()).Invoke_O__O(d__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref()))).Ref()), r__0) } else {
//line :55:1
			if lang.Util_Equiv_O_O__Z(Lit_12, d__1) {

				return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_59, r__0) } else {
//line :55:1
					if lang.Util_Equiv_O_O__Z(Lit_13, d__1) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O()).Invoke_O__O(d__1)) {






						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_fromfn_A_const_66; var tmp6 any = A_arbace_j2g_fromfn_A_const_67; var tmp7 any = tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_57, d__1)); var tmp8 any = A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(d__1); var tmp9 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class
						if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class = fncls__8d; tmp9 = fncls__8d } else { tmp9 = fncls__8 }
//line :62:1
						return tmp3.Invoke_O_O_O__O(tmp7, r__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()) } else {
//line :55:1
							if A_arbace_j2g_fromfn_A_const_52 != nil {












								var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_fromfn_A_const_57; return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(tmp10.Invoke_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O()).Invoke_O__O(d__1), Lit_15), r__0) } else {
//line :55:1
									return nil
								}
						}
					}
				}
		}
}

func A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(p0 any) *A_arbace_j2g_fromfn_result_fn__564000042_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_A{}; t.Ctor_O(p0); return t }
//line :63:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :63:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; var n__2 int64 = 0; L1: for { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O()).Invoke_O__O(d__1)) { d__1, n__2 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_61.GetRawRoot__O()).Invoke_O__O(d__1), lang.Numbers_Inc_J__J(n__2); continue L1 } else {
										var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_60.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O()).Invoke_O__O(d__1)) {
											tmp5 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O()).Invoke_O__O(d__1))).Ref()) } else {
												var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_fromfn_A_const_57; tmp5 = tmp6.Invoke_O_O_O__O(tmp7, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O()).Invoke_O__O(d__1), Lit_18) }
//line :64:1
	return lang.RT_Nth_O_I__O(tmp1.Invoke_O_O__O(tmp4, tmp5), lang.RT_IntCast_J__I(n__2)) } } }; /*line :63:1*/panic("j2g: unreachable") }
func A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New() *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Ctor() {}
//line :64:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Invoke_O_O__O(self, p1__564000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_62, p1__564000041_SHARP___1) }





func A_arbace_j2g_fromfn_set_form_A_New() *A_arbace_j2g_fromfn_set_form_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_fromfn_set_form_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_fromfn_set_form_A) Invoke_O_O__O(self, fi__0 any) any { var sam__2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_45.GetRawRoot__O()).Invoke_O__O(fi__0); var vec__564000049__3 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_71.Invoke_O__O(sam__2)); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__564000049__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__564000049__3, lang.RT_IntCast_J__I(1), nil); var pn__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____6 any; var tmp3 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class; if




	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_72.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__4)).Ref())); pn__6 = tmp1.Invoke_O__O(tmp2); var tmp5 lang.IFn = /*line :70:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_fromfn_A_const_73; var tmp7 any = A_arbace_j2g_fromfn_A_const_74; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_fromfn_A_const_75; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_76.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var tmp12 any = A_arbace_j2g_fromfn_A_const_77; var tmp13 any = A_arbace_j2g_fromfn_A_const_78; var call__7 any = tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp12, tmp13, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_fromfn_A_const_80.GetRawRoot__O(), pn__6, ps__4)))); var fnf__8 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_fromfn_A_const_81; var tmp16 any; var G__564000062__8_ any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_fromfn_set_form_fn__564000063_A_New(); var tmp20 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class; if






	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class = fncls__12d; tmp20 = fncls__12d } else { tmp20 = fncls__12 }; G__564000062__8_ = tmp17.Invoke_O__O(tmp18.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), pn__6, ps__4)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(Lit_24, r__5)) {
		var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_83.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_fromfn_A_const_85.GetRawRoot__O(); var tmp23 any = A_arbace_j2g_fromfn_A_const_16; tmp16 = tmp21.Invoke_O_O_O_O__O(G__564000062__8_, tmp22, tmp23, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_57, r__5)) } else {
//line :77:1
			tmp16 = G__564000062__8_ }; var tmp24 any = tmp16; var tmp25 any; if

	lang.Util_Equiv_O_O__Z(Lit_24, r__5) { tmp25 = call__7 } else { var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_fromfn_A_const_86; tmp25 = tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_87.GetRawRoot__O()).Invoke_O_O__O(call__7, r__5)) }; fnf__8 = /*line :77:1*/tmp14.Invoke_O_O_O__O(tmp15, tmp24, tmp25); var tmp28 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_fromfn_A_const_88; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_fromfn_A_const_89; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_fromfn_A_const_90; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_fromfn_A_const_91; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp37 any = A_arbace_j2g_fromfn_A_const_95; var tmp38 any = A_arbace_j2g_fromfn_A_const_96; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_fromfn_A_const_99; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_fromfn_A_const_100; return tmp28.Invoke_O_O_O__O(tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32.Invoke_O_O__O(tmp33, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_fromfn_A_const_57, fi__0, Lit_18))), tmp34.Invoke_O_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_93, A_arbace_j2g_fromfn_A_const_94)), A_arbace_j2g_fromfn_A_const_92), tmp36.Invoke_O_O_O__O(tmp37, lang.Tuple_Create_O_O__IPersistentVector(tmp38, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_97, A_arbace_j2g_fromfn_A_const_98)), tmp39.Invoke_O_O__O(tmp40, tmp41.Invoke_O_O_O_O__O(tmp42, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_fromfn_A_const_57, fi__0, Lit_25), A_arbace_j2g_fromfn_A_const_101, fnf__8))))) }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New() *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Ctor() {}
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Invoke_O_O__O(self, s__564000053__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(self, s__564000053__1); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Ctor_O_O(c__iter__564000052, c__s__564000053 any) { t.F_iter__564000052 = c__iter__564000052; t.F_s__564000053 = c__s__564000053 }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Invoke_O__O(self any) any { { var s__564000053__1 any; var t_ any = t.F_s__564000053; t.F_s__564000053 = nil; s__564000053__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O()).Invoke_O__O(s__564000053__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000053__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O()).Invoke_O__O(s__564000053__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O()).Invoke_O__O(s__564000053__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__564000055__6 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(b__564000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O()).Invoke_O__O(b__564000055__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O()).Invoke_O__O(s__564000053__3))) } else { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O()).Invoke_O__O(b__564000055__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O()).Invoke_O__O(s__564000053__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O()).Invoke_O__O(s__564000053__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Ctor_O_I_O(c__b__564000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000055 = c__b__564000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Invoke_O__O(self any) any { { var i__564000054__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__564000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__564000054__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__564000055; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__564000054__1 = lang.Numbers_Unchecked_inc_J__J(i__564000054__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_fromfn_set_form_fn__564000063_A_New() *A_arbace_j2g_fromfn_set_form_fn__564000063_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_fn__564000063_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Invoke_O_O_O__O(self, p1__564000047_SHARP___1, p2__564000048_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_84.GetRawRoot__O()).Invoke_O_O__O(p1__564000047_SHARP___1, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_57, p2__564000048_SHARP___2)) }







func A_arbace_j2g_fromfn_forms_A_New() *A_arbace_j2g_fromfn_forms_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_forms_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_fromfn_forms_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_fromfn_forms_A) Invoke_O_O__O(self, fis__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O()).Invoke_O__O(fis__0)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_fromfn_A_const_104; var tmp3 any = tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(fis__0)).Ref(), nil)).Ref()); var tmp4 any = A_arbace_j2g_fromfn_A_const_102; var tmp5 any = A_arbace_j2g_fromfn_A_const_103; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_76.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var tmp8 any = A_arbace_j2g_fromfn_A_const_105; var tmp9 any = A_arbace_j2g_fromfn_A_const_106; var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; var tmp11 any = tmp10.Ref(); return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp3, tmp4, tmp5, tmp6.Invoke_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp11, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_107.GetRawRoot__O(), fis__0))) } else { return nil
	}
}


















































type A_arbace_j2g_fromfn_A struct{ jrt.Object }

var A_arbace_j2g_fromfn_A_const_pool *jrt.RefArray

var A_arbace_j2g_fromfn_A_const_0 *lang.Var

var A_arbace_j2g_fromfn_A_const_1 *lang.Var

var A_arbace_j2g_fromfn_A_const_2 any

var A_arbace_j2g_fromfn_A_const_3 any

var A_arbace_j2g_fromfn_A_const_4 any

var A_arbace_j2g_fromfn_A_const_5 any

var A_arbace_j2g_fromfn_A_const_6 any

var A_arbace_j2g_fromfn_A_const_7 any

var A_arbace_j2g_fromfn_A_const_8 any

var A_arbace_j2g_fromfn_A_const_9 any

var A_arbace_j2g_fromfn_A_const_10 *lang.Var

var A_arbace_j2g_fromfn_A_const_11 *lang.Var

var A_arbace_j2g_fromfn_A_const_12 *lang.Var

var A_arbace_j2g_fromfn_A_const_13 any

var A_arbace_j2g_fromfn_A_const_14 *lang.Var

var A_arbace_j2g_fromfn_A_const_15 *lang.Var

var A_arbace_j2g_fromfn_A_const_16 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_17 *lang.Var

var A_arbace_j2g_fromfn_A_const_18 *lang.Var

var A_arbace_j2g_fromfn_A_const_19 *lang.Var

var A_arbace_j2g_fromfn_A_const_20 *lang.Var

var A_arbace_j2g_fromfn_A_const_21 *lang.Var

var A_arbace_j2g_fromfn_A_const_22 *lang.Var

var A_arbace_j2g_fromfn_A_const_23 *lang.Var

var A_arbace_j2g_fromfn_A_const_24 *lang.Var

var A_arbace_j2g_fromfn_A_const_25 *lang.Var

var A_arbace_j2g_fromfn_A_const_26 *lang.Var

var A_arbace_j2g_fromfn_A_const_27 *lang.Var

var A_arbace_j2g_fromfn_A_const_28 *lang.Var

var A_arbace_j2g_fromfn_A_const_29 any

var A_arbace_j2g_fromfn_A_const_30 *lang.Var

var A_arbace_j2g_fromfn_A_const_31 *lang.Var

var A_arbace_j2g_fromfn_A_const_32 *lang.Var

var A_arbace_j2g_fromfn_A_const_33 *lang.Var

var A_arbace_j2g_fromfn_A_const_34 *lang.Var

var A_arbace_j2g_fromfn_A_const_35 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_36 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_37 *lang.Var

var A_arbace_j2g_fromfn_A_const_38 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_39 *lang.Var

var A_arbace_j2g_fromfn_A_const_40 *lang.Var

var A_arbace_j2g_fromfn_A_const_41 *lang.Var

var A_arbace_j2g_fromfn_A_const_42 *lang.Var

var A_arbace_j2g_fromfn_A_const_43 *lang.Var

var A_arbace_j2g_fromfn_A_const_44 *lang.Var

var A_arbace_j2g_fromfn_A_const_45 *lang.Var

var A_arbace_j2g_fromfn_A_const_46 *lang.Var

var A_arbace_j2g_fromfn_A_const_47 *lang.Var

var A_arbace_j2g_fromfn_A_const_48 *lang.Var

var A_arbace_j2g_fromfn_A_const_49 *lang.Var

var A_arbace_j2g_fromfn_A_const_50 *lang.Var

var A_arbace_j2g_fromfn_A_const_51 *lang.Var

var A_arbace_j2g_fromfn_A_const_52 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_53 any

var A_arbace_j2g_fromfn_A_const_54 any

var A_arbace_j2g_fromfn_A_const_55 *lang.Var

var A_arbace_j2g_fromfn_A_const_56 *lang.Var

var A_arbace_j2g_fromfn_A_const_57 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_58 *lang.Var

var A_arbace_j2g_fromfn_A_const_59 any

var A_arbace_j2g_fromfn_A_const_60 *lang.Var

var A_arbace_j2g_fromfn_A_const_61 *lang.Var

var A_arbace_j2g_fromfn_A_const_62 any

var A_arbace_j2g_fromfn_A_const_63 *lang.Var

var A_arbace_j2g_fromfn_A_const_64 *lang.Var

var A_arbace_j2g_fromfn_A_const_65 *lang.Var

var A_arbace_j2g_fromfn_A_const_66 any

var A_arbace_j2g_fromfn_A_const_67 any

var A_arbace_j2g_fromfn_A_const_68 *lang.Var

var A_arbace_j2g_fromfn_A_const_69 *lang.Var

var A_arbace_j2g_fromfn_A_const_70 *lang.Var

var A_arbace_j2g_fromfn_A_const_71 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_72 *lang.Var

var A_arbace_j2g_fromfn_A_const_73 any

var A_arbace_j2g_fromfn_A_const_74 any

var A_arbace_j2g_fromfn_A_const_75 any

var A_arbace_j2g_fromfn_A_const_76 *lang.Var

var A_arbace_j2g_fromfn_A_const_77 any

var A_arbace_j2g_fromfn_A_const_78 any

var A_arbace_j2g_fromfn_A_const_79 *lang.Var

var A_arbace_j2g_fromfn_A_const_80 *lang.Var

var A_arbace_j2g_fromfn_A_const_81 any

var A_arbace_j2g_fromfn_A_const_82 *lang.Var

var A_arbace_j2g_fromfn_A_const_83 *lang.Var

var A_arbace_j2g_fromfn_A_const_84 *lang.Var

var A_arbace_j2g_fromfn_A_const_85 *lang.Var

var A_arbace_j2g_fromfn_A_const_86 any

var A_arbace_j2g_fromfn_A_const_87 *lang.Var

var A_arbace_j2g_fromfn_A_const_88 any

var A_arbace_j2g_fromfn_A_const_89 any

var A_arbace_j2g_fromfn_A_const_90 any

var A_arbace_j2g_fromfn_A_const_91 any

var A_arbace_j2g_fromfn_A_const_92 any

var A_arbace_j2g_fromfn_A_const_93 any

var A_arbace_j2g_fromfn_A_const_94 any

var A_arbace_j2g_fromfn_A_const_95 any

var A_arbace_j2g_fromfn_A_const_96 any

var A_arbace_j2g_fromfn_A_const_97 any

var A_arbace_j2g_fromfn_A_const_98 any

var A_arbace_j2g_fromfn_A_const_99 any

var A_arbace_j2g_fromfn_A_const_100 any

var A_arbace_j2g_fromfn_A_const_101 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_102 any

var A_arbace_j2g_fromfn_A_const_103 any

var A_arbace_j2g_fromfn_A_const_104 any

var A_arbace_j2g_fromfn_A_const_105 any

var A_arbace_j2g_fromfn_A_const_106 any

var A_arbace_j2g_fromfn_A_const_107 *lang.Var

var A_arbace_j2g_fromfn_A_init jrt.ClassInit

func A_arbace_j2g_fromfn_A_Init() { if !A_arbace_j2g_fromfn_A_init.Done() { A_arbace_j2g_fromfn_A_init.Run(A_arbace_j2g_fromfn_A_clinit) } }

func A_arbace_j2g_fromfn_A_clinit() { A_arbace_j2g_fromfn_A_clinit_p0(); A_arbace_j2g_fromfn_A_clinit_p1(); A_arbace_j2g_fromfn_A_clinit_p2(); A_arbace_j2g_fromfn_A_clinit_p3(); A_arbace_j2g_fromfn_A_clinit_p4(); A_arbace_j2g_fromfn_A_clinit_p5(); A_arbace_j2g_fromfn_A_clinit_p6(); A_arbace_j2g_fromfn_A_clinit_p7(); A_arbace_j2g_fromfn_A_clinit_p8() }

func A_arbace_j2g_fromfn_A_clinit_p0() { A_arbace_j2g_fromfn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 179); A_arbace_j2g_fromfn_A_const_0 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[71]); A_arbace_j2g_fromfn_A_const_1 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[72]); A_arbace_j2g_fromfn_A_const_2 = A_arbace_j2g_fromfn_A_const_pool.A[73]; A_arbace_j2g_fromfn_A_const_3 = A_arbace_j2g_fromfn_A_const_pool.A[74]; A_arbace_j2g_fromfn_A_const_4 = A_arbace_j2g_fromfn_A_const_pool.A[75]; A_arbace_j2g_fromfn_A_const_5 = A_arbace_j2g_fromfn_A_const_pool.A[76]; A_arbace_j2g_fromfn_A_const_6 = A_arbace_j2g_fromfn_A_const_pool.A[77]; A_arbace_j2g_fromfn_A_const_7 = A_arbace_j2g_fromfn_A_const_pool.A[78]; A_arbace_j2g_fromfn_A_const_8 = A_arbace_j2g_fromfn_A_const_pool.A[79]; A_arbace_j2g_fromfn_A_const_9 = A_arbace_j2g_fromfn_A_const_pool.A[80]; A_arbace_j2g_fromfn_A_const_10 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[81]); A_arbace_j2g_fromfn_A_const_11 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[82]); A_arbace_j2g_fromfn_A_const_12 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[83]) }

func A_arbace_j2g_fromfn_A_clinit_p1() { A_arbace_j2g_fromfn_A_const_13 = A_arbace_j2g_fromfn_A_const_pool.A[84]; A_arbace_j2g_fromfn_A_const_14 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[85]); A_arbace_j2g_fromfn_A_const_15 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[86]); A_arbace_j2g_fromfn_A_const_16 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[87]); A_arbace_j2g_fromfn_A_const_17 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[88]); A_arbace_j2g_fromfn_A_const_18 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[89]); A_arbace_j2g_fromfn_A_const_19 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[90]); A_arbace_j2g_fromfn_A_const_20 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[91]); A_arbace_j2g_fromfn_A_const_21 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[92]); A_arbace_j2g_fromfn_A_const_22 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[93]); A_arbace_j2g_fromfn_A_const_23 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[94]); A_arbace_j2g_fromfn_A_const_24 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[95]) }

func A_arbace_j2g_fromfn_A_clinit_p2() { A_arbace_j2g_fromfn_A_const_25 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[96]); A_arbace_j2g_fromfn_A_const_26 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[97]); A_arbace_j2g_fromfn_A_const_27 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[98]); A_arbace_j2g_fromfn_A_const_28 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[99]); A_arbace_j2g_fromfn_A_const_29 = A_arbace_j2g_fromfn_A_const_pool.A[100]; A_arbace_j2g_fromfn_A_const_30 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[101]); A_arbace_j2g_fromfn_A_const_31 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[102]); A_arbace_j2g_fromfn_A_const_32 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[103]); A_arbace_j2g_fromfn_A_const_33 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[104]); A_arbace_j2g_fromfn_A_const_34 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[105]); A_arbace_j2g_fromfn_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[106]); A_arbace_j2g_fromfn_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[107]) }

func A_arbace_j2g_fromfn_A_clinit_p3() { A_arbace_j2g_fromfn_A_const_37 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[108]); A_arbace_j2g_fromfn_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[109]); A_arbace_j2g_fromfn_A_const_39 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[110]); A_arbace_j2g_fromfn_A_const_40 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[111]); A_arbace_j2g_fromfn_A_const_41 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[112]); A_arbace_j2g_fromfn_A_const_42 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[113]); A_arbace_j2g_fromfn_A_const_43 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[114]); A_arbace_j2g_fromfn_A_const_44 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[115]); A_arbace_j2g_fromfn_A_const_45 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[116]); A_arbace_j2g_fromfn_A_const_46 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[117]); A_arbace_j2g_fromfn_A_const_47 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[118]); A_arbace_j2g_fromfn_A_const_48 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[119]) }

func A_arbace_j2g_fromfn_A_clinit_p4() { A_arbace_j2g_fromfn_A_const_49 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[120]); A_arbace_j2g_fromfn_A_const_50 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[121]); A_arbace_j2g_fromfn_A_const_51 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[122]); A_arbace_j2g_fromfn_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[123]); A_arbace_j2g_fromfn_A_const_53 = A_arbace_j2g_fromfn_A_const_pool.A[124]; A_arbace_j2g_fromfn_A_const_54 = A_arbace_j2g_fromfn_A_const_pool.A[125]; A_arbace_j2g_fromfn_A_const_55 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[126]); A_arbace_j2g_fromfn_A_const_56 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[127]); A_arbace_j2g_fromfn_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[128]); A_arbace_j2g_fromfn_A_const_58 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[129]); A_arbace_j2g_fromfn_A_const_59 = A_arbace_j2g_fromfn_A_const_pool.A[130]; A_arbace_j2g_fromfn_A_const_60 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[131]) }

func A_arbace_j2g_fromfn_A_clinit_p5() { A_arbace_j2g_fromfn_A_const_61 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[132]); A_arbace_j2g_fromfn_A_const_62 = A_arbace_j2g_fromfn_A_const_pool.A[133]; A_arbace_j2g_fromfn_A_const_63 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[134]); A_arbace_j2g_fromfn_A_const_64 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[135]); A_arbace_j2g_fromfn_A_const_65 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[136]); A_arbace_j2g_fromfn_A_const_66 = A_arbace_j2g_fromfn_A_const_pool.A[137]; A_arbace_j2g_fromfn_A_const_67 = A_arbace_j2g_fromfn_A_const_pool.A[138]; A_arbace_j2g_fromfn_A_const_68 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[139]); A_arbace_j2g_fromfn_A_const_69 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[140]); A_arbace_j2g_fromfn_A_const_70 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[141]); A_arbace_j2g_fromfn_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[142]); A_arbace_j2g_fromfn_A_const_72 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[143]); A_arbace_j2g_fromfn_A_const_73 = A_arbace_j2g_fromfn_A_const_pool.A[144] }

func A_arbace_j2g_fromfn_A_clinit_p6() { A_arbace_j2g_fromfn_A_const_74 = A_arbace_j2g_fromfn_A_const_pool.A[145]; A_arbace_j2g_fromfn_A_const_75 = A_arbace_j2g_fromfn_A_const_pool.A[146]; A_arbace_j2g_fromfn_A_const_76 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[147]); A_arbace_j2g_fromfn_A_const_77 = A_arbace_j2g_fromfn_A_const_pool.A[148]; A_arbace_j2g_fromfn_A_const_78 = A_arbace_j2g_fromfn_A_const_pool.A[149]; A_arbace_j2g_fromfn_A_const_79 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[150]); A_arbace_j2g_fromfn_A_const_80 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[151]); A_arbace_j2g_fromfn_A_const_81 = A_arbace_j2g_fromfn_A_const_pool.A[152]; A_arbace_j2g_fromfn_A_const_82 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[153]); A_arbace_j2g_fromfn_A_const_83 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[154]); A_arbace_j2g_fromfn_A_const_84 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[155]); A_arbace_j2g_fromfn_A_const_85 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[156]); A_arbace_j2g_fromfn_A_const_86 = A_arbace_j2g_fromfn_A_const_pool.A[157] }

func A_arbace_j2g_fromfn_A_clinit_p7() { A_arbace_j2g_fromfn_A_const_87 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[158]); A_arbace_j2g_fromfn_A_const_88 = A_arbace_j2g_fromfn_A_const_pool.A[159]; A_arbace_j2g_fromfn_A_const_89 = A_arbace_j2g_fromfn_A_const_pool.A[160]; A_arbace_j2g_fromfn_A_const_90 = A_arbace_j2g_fromfn_A_const_pool.A[161]; A_arbace_j2g_fromfn_A_const_91 = A_arbace_j2g_fromfn_A_const_pool.A[162]; A_arbace_j2g_fromfn_A_const_92 = A_arbace_j2g_fromfn_A_const_pool.A[163]; A_arbace_j2g_fromfn_A_const_93 = A_arbace_j2g_fromfn_A_const_pool.A[164]; A_arbace_j2g_fromfn_A_const_94 = A_arbace_j2g_fromfn_A_const_pool.A[165]; A_arbace_j2g_fromfn_A_const_95 = A_arbace_j2g_fromfn_A_const_pool.A[166]; A_arbace_j2g_fromfn_A_const_96 = A_arbace_j2g_fromfn_A_const_pool.A[167]; A_arbace_j2g_fromfn_A_const_97 = A_arbace_j2g_fromfn_A_const_pool.A[168]; A_arbace_j2g_fromfn_A_const_98 = A_arbace_j2g_fromfn_A_const_pool.A[169]; A_arbace_j2g_fromfn_A_const_99 = A_arbace_j2g_fromfn_A_const_pool.A[170]; A_arbace_j2g_fromfn_A_const_100 = A_arbace_j2g_fromfn_A_const_pool.A[171]; A_arbace_j2g_fromfn_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[172]) }

func A_arbace_j2g_fromfn_A_clinit_p8() { A_arbace_j2g_fromfn_A_const_102 = A_arbace_j2g_fromfn_A_const_pool.A[173]; A_arbace_j2g_fromfn_A_const_103 = A_arbace_j2g_fromfn_A_const_pool.A[174]; A_arbace_j2g_fromfn_A_const_104 = A_arbace_j2g_fromfn_A_const_pool.A[175]; A_arbace_j2g_fromfn_A_const_105 = A_arbace_j2g_fromfn_A_const_pool.A[176]; A_arbace_j2g_fromfn_A_const_106 = A_arbace_j2g_fromfn_A_const_pool.A[177]; A_arbace_j2g_fromfn_A_const_107 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[178]) }

func A_arbace_j2g_fromfn_A_New() *A_arbace_j2g_fromfn_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_A_class }

func (t *A_arbace_j2g_fromfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_A); return ok }

func A_arbace_j2g_fromfn_A_Cast(x any) *A_arbace_j2g_fromfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_A_class)) }; return v }



type A_arbace_j2g_fromfn_box_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_box_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000004_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000004_A_New() *A_arbace_j2g_fromfn_eval564000004_A { t := &A_arbace_j2g_fromfn_eval564000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000004_A_class }

func (t *A_arbace_j2g_fromfn_eval564000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); return ok }

func A_arbace_j2g_fromfn_eval564000004_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000004_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000008_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000008_A_New() *A_arbace_j2g_fromfn_eval564000008_A { t := &A_arbace_j2g_fromfn_eval564000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000008_A_class }

func (t *A_arbace_j2g_fromfn_eval564000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); return ok }

func A_arbace_j2g_fromfn_eval564000008_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000008_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000008_fn__564000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_fn__564000037_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A struct{ j2g_header uint64; F_s__564000014, F_iter__564000013 any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A struct{ j2g_header uint64; F_b__564000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_fn__564000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A struct{ j2g_header uint64; F_iter__564000052, F_s__564000053 any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A struct{ j2g_header uint64; F_b__564000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_tag_A_fn_class *jrt.Class
