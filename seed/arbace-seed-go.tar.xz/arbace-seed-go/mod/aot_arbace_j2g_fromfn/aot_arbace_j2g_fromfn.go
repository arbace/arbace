//line aot_arbace_j2g_fromfn.ae:1
package aot_arbace_j2g_fromfn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_New() *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_9); tmp2 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(A_arbace_j2g_fromfn_A_const_1, A_arbace_j2g_fromfn_A_const_2, A_arbace_j2g_fromfn_A_const_3, A_arbace_j2g_fromfn_A_const_4, A_arbace_j2g_fromfn_A_const_5, A_arbace_j2g_fromfn_A_const_6, A_arbace_j2g_fromfn_A_const_7); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_New() *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000008_fn__564000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_10.GetRawRoot__O()); var tmp2 any; var root_21 any = A_arbace_j2g_fromfn_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_j2g_fromfn_A_const_12; if linked_22 == nil { tmp2 = ifn_23.Invoke_O__O(arg_24) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_21, arg_24) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_fromfn_A_const_13.GetRawRoot__O(), A_arbace_j2g_fromfn_A_const_14) }
















func A_arbace_j2g_fromfn_tag_A_New() *A_arbace_j2g_fromfn_tag_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_tag_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Ctor() {}
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_25 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = sym__0; var arg_29 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_fromfn_A_const_16, type__1)); if linked_26 == nil { return ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { return linked_26.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) } }






func A_arbace_j2g_fromfn_roots_A_New() *A_arbace_j2g_fromfn_roots_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Invoke_O__O(self any) any {


	var root_30 any = A_arbace_j2g_fromfn_A_const_17.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New(); var tmp2 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class
	if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class = fncls__93d; tmp2 = fncls__93d } else { tmp2 = fncls__93 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_33 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O())
//line :28:1
	var arg_34 any = A_arbace_j2g_fromfn_A_const_30; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New() *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Invoke_O_O__O(self, s__564000014__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(s__564000014__1, self); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Ctor_O_O(c__s__564000014, c__iter__564000013 any) { t.F_s__564000014 = c__s__564000014; t.F_iter__564000013 = c__iter__564000013 }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Invoke_O__O(self any) any { { var s__564000014__1 any; var t_ any = t.F_s__564000014; t.F_s__564000014 = nil; s__564000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_35 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__564000014__1; if linked_36 == nil { temp__1927000414__auto____2 = ifn_37.Invoke_O__O(arg_38) } else { temp__1927000414__auto____2 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_39 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__564000014__3; if linked_40 == nil { tmp1 = ifn_41.Invoke_O__O(arg_42) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_43 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = s__564000014__3; if linked_44 == nil { c__1927001037__auto____4 = ifn_45.Invoke_O__O(arg_46) } else { c__1927001037__auto____4 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_43, arg_46) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000016__6 any; var root_47 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_48 == nil { b__564000016__6 = ifn_49.Invoke_O__O(arg_50) } else { b__564000016__6 = linked_48.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_47, arg_50) }; var tmp2 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(b__564000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_57 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_62 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = b__564000016__6; if linked_63 == nil { arg_60 = ifn_64.Invoke_O__O(arg_65) } else { arg_60 = linked_63.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_62, arg_65) }; var arg_61 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp5 any; var root_66 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = s__564000014__3; if linked_67 == nil { tmp5 = ifn_68.Invoke_O__O(arg_69) } else { tmp5 = linked_67.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_66, arg_69) }; arg_61 = tmp4.Invoke_O__O(tmp5); if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } } else { var root_70 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_75 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = b__564000016__6; if linked_76 == nil { arg_73 = ifn_77.Invoke_O__O(arg_78) } else { arg_73 = linked_76.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_75, arg_78) }; var arg_74 any; if linked_71 == nil { return ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { return linked_71.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) } } } else { var vec__564000024__4 any; var root_79 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__564000014__3; if linked_80 == nil { vec__564000024__4 = ifn_81.Invoke_O__O(arg_82) } else { vec__564000024__4 = linked_80.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_79, arg_82) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_83 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_87 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp7 any; var root_88 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__564000014__3; if linked_89 == nil { tmp7 = ifn_90.Invoke_O__O(arg_91) } else { tmp7 = linked_89.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_88, arg_91) }; arg_87 = tmp6.Invoke_O__O(tmp7); if linked_84 == nil { return ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { return linked_84.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Ctor_O_I_O(c__b__564000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000016 = c__b__564000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Invoke_O__O(self any) any { { var i__564000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__564000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_51 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t.F_b__564000016; var arg_55 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_52 == nil { ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { linked_52.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; i__564000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_fromfn_functional_QMARK__A_New() *A_arbace_j2g_fromfn_functional_QMARK__A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 any; var root_94 any = A_arbace_j2g_fromfn_A_const_31.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = n__0; if linked_95 == nil { tmp1 = ifn_96.Invoke_O__O(arg_97) } else { tmp1 = linked_95.(*aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(tmp1) {
		var root_98 any = A_arbace_j2g_fromfn_A_const_32.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_classes_env.A_arbace_classes_env_reflected_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = n__0; var arg_102 any = A_arbace_j2g_fromfn_A_const_33; var arg_103 any; var tmp2 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; arg_103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_99 == nil { return ifn_100.Invoke_O_O_O__O(arg_101, arg_102, arg_103) } else { return linked_99.(*aot_arbace_classes_env.A_arbace_classes_env_reflected_A).Invoke_O_O_O_O__O(root_98, arg_101, arg_102, arg_103) } } else {
//line :33:1
			var temp__1927000414__auto____2 any; var root_105 any = A_arbace_j2g_fromfn_A_const_34.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_107 lang.IFn

			if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = n__0; if linked_106 == nil { temp__1927000414__auto____2 = ifn_107.Invoke_O__O(arg_108) } else { temp__1927000414__auto____2 = linked_106.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var d__3 any = temp__1927000414__auto____2; var root_109 any = A_arbace_j2g_fromfn_A_const_35.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_111 lang.IFn
				if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp4 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New(); var tmp5 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class = fncls__114d; tmp5 = fncls__114d } else { tmp5 = fncls__114 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_113 any; var root_115 any = A_arbace_j2g_fromfn_A_const_37.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_j2g_fromfn_A_const_38.Invoke_O__O(d__3); if linked_116 == nil { arg_113 = ifn_117.Invoke_O__O(arg_118) } else { arg_113 = linked_116.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_115, arg_118) }; if linked_110 == nil { return ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { return linked_110.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) } } else {
//line :35:1
					return nil } } }
//line :34:1
func A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Ctor() {}
//line :34:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Invoke_O_O__O(self, c__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__1)).IsAnnotationPresent_Class__Z(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8))).Ref() }

func A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Invoke_O_O__O(self, p1__564000030_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_9, A_arbace_j2g_fromfn_A_const_36.Invoke_O__O(p1__564000030_SHARP___1))).Ref() }

func A_arbace_j2g_fromfn_fis_A_New() *A_arbace_j2g_fromfn_fis_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_j2g_fromfn_fis_A) Ctor() {}
//line :38:1
func (t *A_arbace_j2g_fromfn_fis_A) Invoke_O_O__O(self, T__0_ any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var root_119 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = T__0_; var arg_123 any = Lit_1; if linked_120 == nil { and__1927000168__auto____2 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { and__1927000168__auto____2 = linked_120.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_124 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = T__0_; var arg_128 any = Lit_2; if linked_125 == nil { tmp1 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { tmp1 = linked_125.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_129 any = A_arbace_j2g_fromfn_A_const_40.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_133 any = A_arbace_j2g_fromfn_A_const_41.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var tmp2 any = A_arbace_j2g_fromfn_fis_fn__564000037_A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; arg_136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_137 any = T__0_; if linked_134 == nil { arg_132 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { arg_132 = linked_134.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }; if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_129, arg_132) } } else {
//line :43:1
			return nil } }
func A_arbace_j2g_fromfn_fis_fn__564000037_A_New() *A_arbace_j2g_fromfn_fis_fn__564000037_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_fn__564000037_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Ctor() {}
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Invoke_O_O__O(self, p1__564000036_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_138 any = A_arbace_j2g_fromfn_A_const_42.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = p1__564000036_SHARP___1; if linked_139 == nil { and__1927000168__auto____2 = ifn_140.Invoke_O__O(arg_141) } else { and__1927000168__auto____2 = linked_139.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_142 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_146 any = A_arbace_j2g_fromfn_A_const_44.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = p1__564000036_SHARP___1; if linked_147 == nil { arg_145 = ifn_148.Invoke_O__O(arg_149) } else { arg_145 = linked_147.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_146, arg_149) }; if linked_143 == nil { and__1927000168__auto____3 = ifn_144.Invoke_O__O(arg_145) } else { and__1927000168__auto____3 = linked_143.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_142, arg_145) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_150 any = A_arbace_j2g_fromfn_A_const_45.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_j2g_fromfn_functional_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = p1__564000036_SHARP___1; if linked_151 == nil { and__1927000168__auto____4 = ifn_152.Invoke_O__O(arg_153) } else { and__1927000168__auto____4 = linked_151.(*A_arbace_j2g_fromfn_functional_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_154 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_156 lang.IFn
													if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var root_158 any = A_arbace_j2g_fromfn_A_const_46.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_162 any = A_arbace_j2g_fromfn_A_const_47.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = p1__564000036_SHARP___1; if linked_163 == nil { arg_161 = ifn_164.Invoke_O__O(arg_165) } else { arg_161 = linked_163.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_162, arg_165) }; if linked_159 == nil { arg_157 = ifn_160.Invoke_O__O(arg_161) } else { arg_157 = linked_159.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_158, arg_161) }; if linked_155 == nil { and__1927000168__auto____5 = ifn_156.Invoke_O__O(arg_157) } else { and__1927000168__auto____5 = linked_155.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_154, arg_157) }
//line :44:1
	if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_166 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = p1__564000036_SHARP___1; if linked_167 == nil { tmp1 = ifn_168.Invoke_O__O(arg_169) } else { tmp1 = linked_167.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_166, arg_169) } }
//line :44:1
		return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___8 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___8; tmp1 = nil } else { panic(tmp2) } }; return tmp1 } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_fromfn_box_A_New() *A_arbace_j2g_fromfn_box_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_box_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_fromfn_box_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_fromfn_box_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {
	var tmp1 any; var root_171 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = d__1; if linked_172 == nil { tmp1 = ifn_173.Invoke_O__O(arg_174) } else { tmp1 = linked_172.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_171, arg_174) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_53, p__0) } else { var tmp2 any; var root_175 any = A_arbace_j2g_fromfn_A_const_51.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_177 lang.IFn
		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = d__1; if linked_176 == nil { tmp2 = ifn_177.Invoke_O__O(arg_178) } else { tmp2 = linked_176.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_175, arg_178) }
//line :50:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_54, p__0) } else {
//line :50:1
				if A_arbace_j2g_fromfn_A_const_52 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_fromfn_result_A_New() *A_arbace_j2g_fromfn_result_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_fromfn_result_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_fromfn_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp2 any; var root_183 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = A_arbace_j2g_fromfn_A_const_57; var arg_187 any = Lit_1; var arg_188 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp4 any; var root_189 any = A_arbace_j2g_fromfn_A_const_58.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_193 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_190 == nil { tmp4 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { tmp4 = linked_190.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; arg_188 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_184 == nil { tmp2 = ifn_185.Invoke_O_O_O__O(arg_186, arg_187, arg_188) } else { tmp2 = linked_184.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_183, arg_186, arg_187, arg_188) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :55:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_12, d__1) {

				return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_59, r__0) } else {
//line :55:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, d__1) { return r__0 } else { var tmp5 any; var root_179 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_181 lang.IFn






						if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = d__1; if linked_180 == nil { tmp5 = ifn_181.Invoke_O__O(arg_182) } else { tmp5 = linked_180.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_179, arg_182) }
//line :55:1
						if jrt.J2g_Truth(tmp5) {






							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_fromfn_A_const_66; var tmp9 any = A_arbace_j2g_fromfn_A_const_67; var tmp10 any; var root_227 any = A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_j2g_fromfn_A_const_57; var arg_231 any = d__1; if linked_228 == nil { tmp10 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { tmp10 = linked_228.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any = A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(d__1); var tmp13 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class
							if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class = fncls__226d; tmp13 = fncls__226d } else { tmp13 = fncls__226 }
//line :62:1
							return tmp6.Invoke_O_O_O__O(tmp11, r__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()) } else {
//line :55:1
								if A_arbace_j2g_fromfn_A_const_52 != nil {












									var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp15 any; var root_232 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_fromfn_A_const_57; var arg_236 any; var root_238 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = d__1; if linked_239 == nil { arg_236 = ifn_240.Invoke_O__O(arg_241) } else { arg_236 = linked_239.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_238, arg_241) }; var arg_237 any = Lit_15; if linked_233 == nil { tmp15 = ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { tmp15 = linked_233.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) }; return tmp14.Invoke_O_O__O(tmp15, r__0) } else {
//line :55:1
										return nil
									}
							}
					}
				}
		}
}

func A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(p0 any) *A_arbace_j2g_fromfn_result_fn__564000042_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_A{}; t.Ctor_O(p0); return t }
//line :63:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :63:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_194 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = d__1; if linked_195 == nil { tmp1 = ifn_196.Invoke_O__O(arg_197) } else { tmp1 = linked_195.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_194, arg_197) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_222 any = A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = d__1; if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_222, arg_225) }; d__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
										var tmp3 any; var root_198 any = A_arbace_j2g_fromfn_A_const_60.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any; var tmp4 any = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New(); var tmp5 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class = fncls__203d; tmp5 = fncls__203d } else { tmp5 = fncls__203 }; arg_201 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_202 any; var tmp6 any; var root_204 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = d__1; if linked_205 == nil { tmp6 = ifn_206.Invoke_O__O(arg_207) } else { tmp6 = linked_205.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(tmp6) {
											var root_208 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); if linked_209 == nil { arg_202 = ifn_210.Invoke_O__O(arg_211) } else { arg_202 = linked_209.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_208, arg_211) } } else {
												var root_212 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = A_arbace_j2g_fromfn_A_const_57; var arg_216 any; var root_218 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = d__1; if linked_219 == nil { arg_216 = ifn_220.Invoke_O__O(arg_221) } else { arg_216 = linked_219.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_218, arg_221) }; var arg_217 any = Lit_18; if linked_213 == nil { arg_202 = ifn_214.Invoke_O_O_O__O(arg_215, arg_216, arg_217) } else { arg_202 = linked_213.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_212, arg_215, arg_216, arg_217) } }
//line :64:1
	if linked_199 == nil { tmp3 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { tmp3 = linked_199.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :63:1*/panic("j2g: unreachable") }
func A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New() *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Ctor() {}
//line :64:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Invoke_O_O__O(self, p1__564000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_61, p1__564000041_SHARP___1) }





func A_arbace_j2g_fromfn_set_form_A_New() *A_arbace_j2g_fromfn_set_form_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_fromfn_set_form_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_fromfn_set_form_A) Invoke_O_O__O(self, fi__0 any) any { var sam__2 any; var root_242 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_244 lang.IFn; if


	linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = fi__0; if linked_243 == nil { sam__2 = ifn_244.Invoke_O__O(arg_245) } else { sam__2 = linked_243.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_242, arg_245) }; var vec__564000049__3 any; var root_246 any = /*line :70:1*/A_arbace_j2g_fromfn_A_const_69.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_248 lang.IFn; if



	linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = A_arbace_j2g_fromfn_A_const_70.Invoke_O__O(sam__2); if linked_247 == nil { vec__564000049__3 = ifn_248.Invoke_O__O(arg_249) } else { vec__564000049__3 = linked_247.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_246, arg_249) }; var ps__4 any = /*line :70:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__6 any; var root_250 any = A_arbace_j2g_fromfn_A_const_71.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_252 lang.IFn; if




	linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any; var iter__1927001039__auto____6 any; var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New(); var tmp2 *jrt.Class; var fncls__320 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class; if fncls__320 == nil { var fncls__320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class = fncls__320d; tmp2 = fncls__320d } else { tmp2 = fncls__320 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp4 any; var root_321 any = A_arbace_j2g_fromfn_A_const_72.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__4)).Ref(); if linked_322 == nil { tmp4 = ifn_323.Invoke_O__O(arg_324) } else { tmp4 = linked_322.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_321, arg_324) }; arg_253 = tmp3.Invoke_O__O(tmp4); if linked_251 == nil { pn__6 = ifn_252.Invoke_O__O(arg_253) } else { pn__6 = linked_251.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_250, arg_253) }; var call__7 any; var tmp5 lang.IFn = /*line :70:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_fromfn_A_const_73; var tmp7 any = A_arbace_j2g_fromfn_A_const_74; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_fromfn_A_const_75; var tmp10 any; var root_325 any = A_arbace_j2g_fromfn_A_const_76.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_327 lang.IFn; if





	linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_329 any = A_arbace_j2g_fromfn_A_const_77; var arg_330 any = A_arbace_j2g_fromfn_A_const_78; var arg_331 any; var root_332 any = A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_j2g_fromfn_A_const_80.GetRawRoot__O(); var arg_336 any = pn__6; var arg_337 any = ps__4; if linked_333 == nil { arg_331 = ifn_334.Invoke_O_O_O__O(arg_335, arg_336, arg_337) } else { arg_331 = linked_333.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_332, arg_335, arg_336, arg_337) }; if linked_326 == nil { tmp10 = ifn_327.Invoke_O_O_O_O__O(arg_328, arg_329, arg_330, arg_331) } else { tmp10 = linked_326.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_325, arg_328, arg_329, arg_330, arg_331) }; call__7 = tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10)); var fnf__8 any; var tmp11 lang.IFn = /*line :70:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_fromfn_A_const_81; var tmp13 any; var G__564000062__8_ any; var root_338 any = A_arbace_j2g_fromfn_A_const_71.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_340 lang.IFn; if






	linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any; var root_342 any = A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var tmp14 any = A_arbace_j2g_fromfn_set_form_fn__564000063_A_New(); var tmp15 *jrt.Class; var fncls__358 *jrt.Class = A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class; if fncls__358 == nil { var fncls__358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class = fncls__358d; tmp15 = fncls__358d } else { tmp15 = fncls__358 }; arg_345 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_346 any = pn__6; var arg_347 any = ps__4; if linked_343 == nil { arg_341 = ifn_344.Invoke_O_O_O__O(arg_345, arg_346, arg_347) } else { arg_341 = linked_343.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_342, arg_345, arg_346, arg_347) }; if linked_339 == nil { G__564000062__8_ = ifn_340.Invoke_O__O(arg_341) } else { G__564000062__8_ = linked_339.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_338, arg_341) }; var tmp16 any; var root_359 any = A_arbace_j2g_fromfn_A_const_83.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_361 lang.IFn; if
	linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = Lit_24; var arg_363 any = r__5; if linked_360 == nil { tmp16 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp16 = linked_360.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if /*line :77:1*/ jrt.J2g_Truth(tmp16) {
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_84.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_fromfn_A_const_85.GetRawRoot__O(); var tmp19 any = A_arbace_j2g_fromfn_A_const_16; var tmp20 any; var root_371 any = A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = A_arbace_j2g_fromfn_A_const_57; var arg_375 any = r__5; if linked_372 == nil { tmp20 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp20 = linked_372.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; tmp13 = tmp17.Invoke_O_O_O_O__O(G__564000062__8_, tmp18, tmp19, tmp20) } else {
//line :77:1
			tmp13 = G__564000062__8_ }; var tmp21 any = tmp13; var tmp22 any; if

	lang.Util_Equiv_O_O__Z_NoInit(Lit_24, r__5) { tmp22 = call__7 } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_fromfn_A_const_86; var tmp25 any; var root_376 any = A_arbace_j2g_fromfn_A_const_87.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_j2g_fromfn_result_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = call__7; var arg_380 any = r__5; if linked_377 == nil { tmp25 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { tmp25 = linked_377.(*A_arbace_j2g_fromfn_result_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }; tmp22 = tmp23.Invoke_O_O__O(tmp24, tmp25) }; fnf__8 = /*line :77:1*/tmp11.Invoke_O_O_O__O(tmp12, tmp21, tmp22); var tmp26 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_fromfn_A_const_88; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_fromfn_A_const_89; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_fromfn_A_const_90; var tmp32 any; var root_381 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_j2g_fromfn_A_const_57; var arg_385 any = fi__0; var arg_386 any = Lit_18; if linked_382 == nil { tmp32 = ifn_383.Invoke_O_O_O__O(arg_384, arg_385, arg_386) } else { tmp32 = linked_382.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_381, arg_384, arg_385, arg_386) }; var tmp33 any = tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32)); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_fromfn_A_const_91; var tmp36 any; var root_387 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_389 lang.IFn; if
	linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var tmp37 any; var root_392 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_j2g_fromfn_A_const_92; var arg_396 any = A_arbace_j2g_fromfn_A_const_93; if linked_393 == nil { tmp37 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { tmp37 = linked_393.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }; arg_390 = lang.Tuple_Create_O__IPersistentVector(tmp37); var arg_391 any = A_arbace_j2g_fromfn_A_const_94; if linked_388 == nil { tmp36 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { tmp36 = linked_388.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; var tmp38 any = tmp36; var tmp39 lang.IFn = /*line :80:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_fromfn_A_const_95; var tmp41 any = A_arbace_j2g_fromfn_A_const_96; var tmp42 any = lang.Tuple_Create_O_O__IPersistentVector(tmp41, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_97, A_arbace_j2g_fromfn_A_const_98)); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_fromfn_A_const_99; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_fromfn_A_const_100; var tmp47 any; var root_397 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_399 lang.IFn; if


	linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = A_arbace_j2g_fromfn_A_const_57; var arg_401 any = fi__0; var arg_402 any = Lit_25; if linked_398 == nil { tmp47 = ifn_399.Invoke_O_O_O__O(arg_400, arg_401, arg_402) } else { tmp47 = linked_398.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_397, arg_400, arg_401, arg_402) }; return /*line :80:1*/ tmp26.Invoke_O_O_O__O(tmp27, tmp33, tmp34.Invoke_O_O_O__O(tmp35, tmp38, tmp39.Invoke_O_O_O__O(tmp40, tmp42, tmp43.Invoke_O_O__O(tmp44, tmp45.Invoke_O_O_O_O__O(tmp46, tmp47, A_arbace_j2g_fromfn_A_const_101, fnf__8))))) }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New() *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Ctor() {}
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Invoke_O_O__O(self, s__564000053__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(self, s__564000053__1); var tmp2 *jrt.Class; var fncls__319 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class; if fncls__319 == nil { var fncls__319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class = fncls__319d; tmp2 = fncls__319d } else { tmp2 = fncls__319 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Ctor_O_O(c__iter__564000052, c__s__564000053 any) { t.F_iter__564000052 = c__iter__564000052; t.F_s__564000053 = c__s__564000053 }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Invoke_O__O(self any) any { { var s__564000053__1 any; var t_ any = t.F_s__564000053; t.F_s__564000053 = nil; s__564000053__1 = t_; for { var temp__1927000414__auto____2 any; var root_254 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = s__564000053__1; if linked_255 == nil { temp__1927000414__auto____2 = ifn_256.Invoke_O__O(arg_257) } else { temp__1927000414__auto____2 = linked_255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000053__3 any = temp__1927000414__auto____2; var tmp1 any; var root_258 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = s__564000053__3; if linked_259 == nil { tmp1 = ifn_260.Invoke_O__O(arg_261) } else { tmp1 = linked_259.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_262 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = s__564000053__3; if linked_263 == nil { c__1927001037__auto____4 = ifn_264.Invoke_O__O(arg_265) } else { c__1927001037__auto____4 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_262, arg_265) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000055__6 any; var root_266 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_267 == nil { b__564000055__6 = ifn_268.Invoke_O__O(arg_269) } else { b__564000055__6 = linked_267.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_266, arg_269) }; var tmp2 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(b__564000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class; if fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class = fncls__279d; tmp3 = fncls__279d } else { tmp3 = fncls__279 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_280 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any; var root_285 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = b__564000055__6; if linked_286 == nil { arg_283 = ifn_287.Invoke_O__O(arg_288) } else { arg_283 = linked_286.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_285, arg_288) }; var arg_284 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp5 any; var root_289 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = s__564000053__3; if linked_290 == nil { tmp5 = ifn_291.Invoke_O__O(arg_292) } else { tmp5 = linked_290.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_289, arg_292) }; arg_284 = tmp4.Invoke_O__O(tmp5); if linked_281 == nil { return ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { return linked_281.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) } } else { var root_293 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any; var root_298 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = b__564000055__6; if linked_299 == nil { arg_296 = ifn_300.Invoke_O__O(arg_301) } else { arg_296 = linked_299.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_298, arg_301) }; var arg_297 any; if linked_294 == nil { return ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { return linked_294.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_293, arg_296, arg_297) } } } else { var i__4 any; var root_302 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = s__564000053__3; if linked_303 == nil { i__4 = ifn_304.Invoke_O__O(arg_305) } else { i__4 = linked_303.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_302, arg_305) }; var root_306 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any; var root_311 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); if linked_312 == nil { arg_309 = ifn_313.Invoke_O__O(arg_314) } else { arg_309 = linked_312.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_311, arg_314) }; var arg_310 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp7 any; var root_315 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = s__564000053__3; if linked_316 == nil { tmp7 = ifn_317.Invoke_O__O(arg_318) } else { tmp7 = linked_316.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_315, arg_318) }; arg_310 = tmp6.Invoke_O__O(tmp7); if linked_307 == nil { return ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { return linked_307.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :75:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Ctor_O_I_O(c__b__564000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000055 = c__b__564000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Invoke_O__O(self any) any { { var i__564000054__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000054__1)); var root_270 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = t.F_b__564000055; var arg_274 any; var root_275 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_276 == nil { arg_274 = ifn_277.Invoke_O__O(arg_278) } else { arg_274 = linked_276.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_275, arg_278) }; if linked_271 == nil { ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { linked_271.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }; i__564000054__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000054__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_fromfn_set_form_fn__564000063_A_New() *A_arbace_j2g_fromfn_set_form_fn__564000063_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_fn__564000063_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Ctor() {}
//line :77:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Invoke_O_O_O__O(self, p1__564000047_SHARP___1, p2__564000048_SHARP___2 any) any { var root_348 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = p1__564000047_SHARP___1; var arg_352 any; var root_353 any = A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_j2g_fromfn_A_const_57; var arg_357 any = p2__564000048_SHARP___2; if linked_354 == nil { arg_352 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { arg_352 = linked_354.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }; if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }







func A_arbace_j2g_fromfn_forms_A_New() *A_arbace_j2g_fromfn_forms_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_forms_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_fromfn_forms_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_fromfn_forms_A) Invoke_O_O__O(self, fis__0 any) any {


	var tmp1 any; var root_403 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = fis__0; if linked_404 == nil { tmp1 = ifn_405.Invoke_O__O(arg_406) } else { tmp1 = linked_404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_403, arg_406) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_fromfn_A_const_107; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fis__0)).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_fromfn_A_const_102; var tmp6 any = A_arbace_j2g_fromfn_A_const_103; var tmp7 any; var root_407 any = A_arbace_j2g_fromfn_A_const_76.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_409 lang.IFn










		if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_411 any = A_arbace_j2g_fromfn_A_const_104; var arg_412 any = A_arbace_j2g_fromfn_A_const_105; var arg_413 any = lang.PersistentVector_EMPTY.Ref(); var arg_414 any; var root_415 any = A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_j2g_fromfn_A_const_106.GetRawRoot__O(); var arg_419 any = fis__0; if linked_416 == nil { arg_414 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { arg_414 = linked_416.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; if linked_408 == nil { tmp7 = ifn_409.Invoke_O_O_O_O_O__O(arg_410, arg_411, arg_412, arg_413, arg_414) } else { tmp7 = linked_408.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_407, arg_410, arg_411, arg_412, arg_413, arg_414) }
//line :88:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp5, tmp6, tmp7) } else { return nil
		}
}


















































type A_arbace_j2g_fromfn_A struct{ jrt.Object }

var A_arbace_j2g_fromfn_A_const_pool *jrt.RefArray

var A_arbace_j2g_fromfn_A_const_0 *lang.Var

var A_arbace_j2g_fromfn_A_const_1 any

var A_arbace_j2g_fromfn_A_const_2 any

var A_arbace_j2g_fromfn_A_const_3 any

var A_arbace_j2g_fromfn_A_const_4 any

var A_arbace_j2g_fromfn_A_const_5 any

var A_arbace_j2g_fromfn_A_const_6 any

var A_arbace_j2g_fromfn_A_const_7 any

var A_arbace_j2g_fromfn_A_const_8 *lang.Var

var A_arbace_j2g_fromfn_A_const_9 any

var A_arbace_j2g_fromfn_A_const_10 *lang.Var

var A_arbace_j2g_fromfn_A_const_11 *lang.Var

var A_arbace_j2g_fromfn_A_const_12 *lang.Var

var A_arbace_j2g_fromfn_A_const_13 *lang.Var

var A_arbace_j2g_fromfn_A_const_14 any

var A_arbace_j2g_fromfn_A_const_15 *lang.Var

var A_arbace_j2g_fromfn_A_const_16 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_17 *lang.Var

var A_arbace_j2g_fromfn_A_const_18 *lang.Var

var A_arbace_j2g_fromfn_A_const_19 *lang.Var

var A_arbace_j2g_fromfn_A_const_20 *lang.Var

var A_arbace_j2g_fromfn_A_const_21 *lang.Var

var A_arbace_j2g_fromfn_A_const_22 *lang.Var

var A_arbace_j2g_fromfn_A_const_23 *lang.Var

var A_arbace_j2g_fromfn_A_const_24 *lang.Var

var A_arbace_j2g_fromfn_A_const_25 *lang.Var

var A_arbace_j2g_fromfn_A_const_26 *lang.Var

var A_arbace_j2g_fromfn_A_const_27 *lang.Var

var A_arbace_j2g_fromfn_A_const_28 *lang.Var

var A_arbace_j2g_fromfn_A_const_29 *lang.Var

var A_arbace_j2g_fromfn_A_const_30 any

var A_arbace_j2g_fromfn_A_const_31 *lang.Var

var A_arbace_j2g_fromfn_A_const_32 *lang.Var

var A_arbace_j2g_fromfn_A_const_33 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_34 *lang.Var

var A_arbace_j2g_fromfn_A_const_35 *lang.Var

var A_arbace_j2g_fromfn_A_const_36 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_37 *lang.Var

var A_arbace_j2g_fromfn_A_const_38 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_39 *lang.Var

var A_arbace_j2g_fromfn_A_const_40 *lang.Var

var A_arbace_j2g_fromfn_A_const_41 *lang.Var

var A_arbace_j2g_fromfn_A_const_42 *lang.Var

var A_arbace_j2g_fromfn_A_const_43 *lang.Var

var A_arbace_j2g_fromfn_A_const_44 *lang.Var

var A_arbace_j2g_fromfn_A_const_45 *lang.Var

var A_arbace_j2g_fromfn_A_const_46 *lang.Var

var A_arbace_j2g_fromfn_A_const_47 *lang.Var

var A_arbace_j2g_fromfn_A_const_48 *lang.Var

var A_arbace_j2g_fromfn_A_const_49 *lang.Var

var A_arbace_j2g_fromfn_A_const_50 *lang.Var

var A_arbace_j2g_fromfn_A_const_51 *lang.Var

var A_arbace_j2g_fromfn_A_const_52 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_53 any

var A_arbace_j2g_fromfn_A_const_54 any

var A_arbace_j2g_fromfn_A_const_55 *lang.Var

var A_arbace_j2g_fromfn_A_const_56 *lang.Var

var A_arbace_j2g_fromfn_A_const_57 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_58 *lang.Var

var A_arbace_j2g_fromfn_A_const_59 any

var A_arbace_j2g_fromfn_A_const_60 *lang.Var

var A_arbace_j2g_fromfn_A_const_61 any

var A_arbace_j2g_fromfn_A_const_62 *lang.Var

var A_arbace_j2g_fromfn_A_const_63 *lang.Var

var A_arbace_j2g_fromfn_A_const_64 *lang.Var

var A_arbace_j2g_fromfn_A_const_65 *lang.Var

var A_arbace_j2g_fromfn_A_const_66 any

var A_arbace_j2g_fromfn_A_const_67 any

var A_arbace_j2g_fromfn_A_const_68 *lang.Var

var A_arbace_j2g_fromfn_A_const_69 *lang.Var

var A_arbace_j2g_fromfn_A_const_70 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_71 *lang.Var

var A_arbace_j2g_fromfn_A_const_72 *lang.Var

var A_arbace_j2g_fromfn_A_const_73 any

var A_arbace_j2g_fromfn_A_const_74 any

var A_arbace_j2g_fromfn_A_const_75 any

var A_arbace_j2g_fromfn_A_const_76 *lang.Var

var A_arbace_j2g_fromfn_A_const_77 any

var A_arbace_j2g_fromfn_A_const_78 any

var A_arbace_j2g_fromfn_A_const_79 *lang.Var

var A_arbace_j2g_fromfn_A_const_80 *lang.Var

var A_arbace_j2g_fromfn_A_const_81 any

var A_arbace_j2g_fromfn_A_const_82 *lang.Var

var A_arbace_j2g_fromfn_A_const_83 *lang.Var

var A_arbace_j2g_fromfn_A_const_84 *lang.Var

var A_arbace_j2g_fromfn_A_const_85 *lang.Var

var A_arbace_j2g_fromfn_A_const_86 any

var A_arbace_j2g_fromfn_A_const_87 *lang.Var

var A_arbace_j2g_fromfn_A_const_88 any

var A_arbace_j2g_fromfn_A_const_89 any

var A_arbace_j2g_fromfn_A_const_90 any

var A_arbace_j2g_fromfn_A_const_91 any

var A_arbace_j2g_fromfn_A_const_92 any

var A_arbace_j2g_fromfn_A_const_93 any

var A_arbace_j2g_fromfn_A_const_94 any

var A_arbace_j2g_fromfn_A_const_95 any

var A_arbace_j2g_fromfn_A_const_96 any

var A_arbace_j2g_fromfn_A_const_97 any

var A_arbace_j2g_fromfn_A_const_98 any

var A_arbace_j2g_fromfn_A_const_99 any

var A_arbace_j2g_fromfn_A_const_100 any

var A_arbace_j2g_fromfn_A_const_101 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_102 any

var A_arbace_j2g_fromfn_A_const_103 any

var A_arbace_j2g_fromfn_A_const_104 any

var A_arbace_j2g_fromfn_A_const_105 any

var A_arbace_j2g_fromfn_A_const_106 *lang.Var

var A_arbace_j2g_fromfn_A_const_107 any

var A_arbace_j2g_fromfn_A_init jrt.ClassInit

func A_arbace_j2g_fromfn_A_Init() { if !A_arbace_j2g_fromfn_A_init.Done() { A_arbace_j2g_fromfn_A_init.Run(A_arbace_j2g_fromfn_A_clinit) } }

func A_arbace_j2g_fromfn_A_clinit() { A_arbace_j2g_fromfn_A_clinit_p0(); A_arbace_j2g_fromfn_A_clinit_p1(); A_arbace_j2g_fromfn_A_clinit_p2(); A_arbace_j2g_fromfn_A_clinit_p3(); A_arbace_j2g_fromfn_A_clinit_p4(); A_arbace_j2g_fromfn_A_clinit_p5(); A_arbace_j2g_fromfn_A_clinit_p6(); A_arbace_j2g_fromfn_A_clinit_p7(); A_arbace_j2g_fromfn_A_clinit_p8() }

func A_arbace_j2g_fromfn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_fromfn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 179); A_arbace_j2g_fromfn_A_const_0 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[71]); A_arbace_j2g_fromfn_A_const_1 = A_arbace_j2g_fromfn_A_const_pool.A[72]; A_arbace_j2g_fromfn_A_const_2 = A_arbace_j2g_fromfn_A_const_pool.A[73]; A_arbace_j2g_fromfn_A_const_3 = A_arbace_j2g_fromfn_A_const_pool.A[74]; A_arbace_j2g_fromfn_A_const_4 = A_arbace_j2g_fromfn_A_const_pool.A[75]; A_arbace_j2g_fromfn_A_const_5 = A_arbace_j2g_fromfn_A_const_pool.A[76]; A_arbace_j2g_fromfn_A_const_6 = A_arbace_j2g_fromfn_A_const_pool.A[77]; A_arbace_j2g_fromfn_A_const_7 = A_arbace_j2g_fromfn_A_const_pool.A[78]; A_arbace_j2g_fromfn_A_const_8 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[79]); A_arbace_j2g_fromfn_A_const_9 = A_arbace_j2g_fromfn_A_const_pool.A[80]; A_arbace_j2g_fromfn_A_const_10 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[81]); A_arbace_j2g_fromfn_A_const_11 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[82]); A_arbace_j2g_fromfn_A_const_12 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[83]) }

func A_arbace_j2g_fromfn_A_clinit_p1() { A_arbace_j2g_fromfn_A_const_13 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[84]); A_arbace_j2g_fromfn_A_const_14 = A_arbace_j2g_fromfn_A_const_pool.A[85]; A_arbace_j2g_fromfn_A_const_15 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[86]); A_arbace_j2g_fromfn_A_const_16 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[87]); A_arbace_j2g_fromfn_A_const_17 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[88]); A_arbace_j2g_fromfn_A_const_18 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[89]); A_arbace_j2g_fromfn_A_const_19 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[90]); A_arbace_j2g_fromfn_A_const_20 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[91]); A_arbace_j2g_fromfn_A_const_21 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[92]); A_arbace_j2g_fromfn_A_const_22 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[93]); A_arbace_j2g_fromfn_A_const_23 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[94]); A_arbace_j2g_fromfn_A_const_24 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[95]) }

func A_arbace_j2g_fromfn_A_clinit_p2() { A_arbace_j2g_fromfn_A_const_25 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[96]); A_arbace_j2g_fromfn_A_const_26 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[97]); A_arbace_j2g_fromfn_A_const_27 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[98]); A_arbace_j2g_fromfn_A_const_28 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[99]); A_arbace_j2g_fromfn_A_const_29 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[100]); A_arbace_j2g_fromfn_A_const_30 = A_arbace_j2g_fromfn_A_const_pool.A[101]; A_arbace_j2g_fromfn_A_const_31 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[102]); A_arbace_j2g_fromfn_A_const_32 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[103]); A_arbace_j2g_fromfn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[104]); A_arbace_j2g_fromfn_A_const_34 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[105]); A_arbace_j2g_fromfn_A_const_35 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[106]); A_arbace_j2g_fromfn_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[107]) }

func A_arbace_j2g_fromfn_A_clinit_p3() { A_arbace_j2g_fromfn_A_const_37 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[108]); A_arbace_j2g_fromfn_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[109]); A_arbace_j2g_fromfn_A_const_39 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[110]); A_arbace_j2g_fromfn_A_const_40 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[111]); A_arbace_j2g_fromfn_A_const_41 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[112]); A_arbace_j2g_fromfn_A_const_42 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[113]); A_arbace_j2g_fromfn_A_const_43 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[114]); A_arbace_j2g_fromfn_A_const_44 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[115]); A_arbace_j2g_fromfn_A_const_45 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[116]); A_arbace_j2g_fromfn_A_const_46 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[117]); A_arbace_j2g_fromfn_A_const_47 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[118]); A_arbace_j2g_fromfn_A_const_48 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[119]) }

func A_arbace_j2g_fromfn_A_clinit_p4() { A_arbace_j2g_fromfn_A_const_49 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[120]); A_arbace_j2g_fromfn_A_const_50 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[121]); A_arbace_j2g_fromfn_A_const_51 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[122]); A_arbace_j2g_fromfn_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[123]); A_arbace_j2g_fromfn_A_const_53 = A_arbace_j2g_fromfn_A_const_pool.A[124]; A_arbace_j2g_fromfn_A_const_54 = A_arbace_j2g_fromfn_A_const_pool.A[125]; A_arbace_j2g_fromfn_A_const_55 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[126]); A_arbace_j2g_fromfn_A_const_56 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[127]); A_arbace_j2g_fromfn_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[128]); A_arbace_j2g_fromfn_A_const_58 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[129]); A_arbace_j2g_fromfn_A_const_59 = A_arbace_j2g_fromfn_A_const_pool.A[130]; A_arbace_j2g_fromfn_A_const_60 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[131]); A_arbace_j2g_fromfn_A_const_61 = A_arbace_j2g_fromfn_A_const_pool.A[132] }

func A_arbace_j2g_fromfn_A_clinit_p5() { A_arbace_j2g_fromfn_A_const_62 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[133]); A_arbace_j2g_fromfn_A_const_63 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[134]); A_arbace_j2g_fromfn_A_const_64 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[135]); A_arbace_j2g_fromfn_A_const_65 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[136]); A_arbace_j2g_fromfn_A_const_66 = A_arbace_j2g_fromfn_A_const_pool.A[137]; A_arbace_j2g_fromfn_A_const_67 = A_arbace_j2g_fromfn_A_const_pool.A[138]; A_arbace_j2g_fromfn_A_const_68 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[139]); A_arbace_j2g_fromfn_A_const_69 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[140]); A_arbace_j2g_fromfn_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[141]); A_arbace_j2g_fromfn_A_const_71 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[142]); A_arbace_j2g_fromfn_A_const_72 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[143]); A_arbace_j2g_fromfn_A_const_73 = A_arbace_j2g_fromfn_A_const_pool.A[144]; A_arbace_j2g_fromfn_A_const_74 = A_arbace_j2g_fromfn_A_const_pool.A[145] }

func A_arbace_j2g_fromfn_A_clinit_p6() { A_arbace_j2g_fromfn_A_const_75 = A_arbace_j2g_fromfn_A_const_pool.A[146]; A_arbace_j2g_fromfn_A_const_76 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[147]); A_arbace_j2g_fromfn_A_const_77 = A_arbace_j2g_fromfn_A_const_pool.A[148]; A_arbace_j2g_fromfn_A_const_78 = A_arbace_j2g_fromfn_A_const_pool.A[149]; A_arbace_j2g_fromfn_A_const_79 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[150]); A_arbace_j2g_fromfn_A_const_80 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[151]); A_arbace_j2g_fromfn_A_const_81 = A_arbace_j2g_fromfn_A_const_pool.A[152]; A_arbace_j2g_fromfn_A_const_82 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[153]); A_arbace_j2g_fromfn_A_const_83 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[154]); A_arbace_j2g_fromfn_A_const_84 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[155]); A_arbace_j2g_fromfn_A_const_85 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[156]); A_arbace_j2g_fromfn_A_const_86 = A_arbace_j2g_fromfn_A_const_pool.A[157]; A_arbace_j2g_fromfn_A_const_87 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[158]) }

func A_arbace_j2g_fromfn_A_clinit_p7() { A_arbace_j2g_fromfn_A_const_88 = A_arbace_j2g_fromfn_A_const_pool.A[159]; A_arbace_j2g_fromfn_A_const_89 = A_arbace_j2g_fromfn_A_const_pool.A[160]; A_arbace_j2g_fromfn_A_const_90 = A_arbace_j2g_fromfn_A_const_pool.A[161]; A_arbace_j2g_fromfn_A_const_91 = A_arbace_j2g_fromfn_A_const_pool.A[162]; A_arbace_j2g_fromfn_A_const_92 = A_arbace_j2g_fromfn_A_const_pool.A[163]; A_arbace_j2g_fromfn_A_const_93 = A_arbace_j2g_fromfn_A_const_pool.A[164]; A_arbace_j2g_fromfn_A_const_94 = A_arbace_j2g_fromfn_A_const_pool.A[165]; A_arbace_j2g_fromfn_A_const_95 = A_arbace_j2g_fromfn_A_const_pool.A[166]; A_arbace_j2g_fromfn_A_const_96 = A_arbace_j2g_fromfn_A_const_pool.A[167]; A_arbace_j2g_fromfn_A_const_97 = A_arbace_j2g_fromfn_A_const_pool.A[168]; A_arbace_j2g_fromfn_A_const_98 = A_arbace_j2g_fromfn_A_const_pool.A[169]; A_arbace_j2g_fromfn_A_const_99 = A_arbace_j2g_fromfn_A_const_pool.A[170]; A_arbace_j2g_fromfn_A_const_100 = A_arbace_j2g_fromfn_A_const_pool.A[171]; A_arbace_j2g_fromfn_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[172]); A_arbace_j2g_fromfn_A_const_102 = A_arbace_j2g_fromfn_A_const_pool.A[173] }

func A_arbace_j2g_fromfn_A_clinit_p8() { A_arbace_j2g_fromfn_A_const_103 = A_arbace_j2g_fromfn_A_const_pool.A[174]; A_arbace_j2g_fromfn_A_const_104 = A_arbace_j2g_fromfn_A_const_pool.A[175]; A_arbace_j2g_fromfn_A_const_105 = A_arbace_j2g_fromfn_A_const_pool.A[176]; A_arbace_j2g_fromfn_A_const_106 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[177]); A_arbace_j2g_fromfn_A_const_107 = A_arbace_j2g_fromfn_A_const_pool.A[178] }

func A_arbace_j2g_fromfn_A_New() *A_arbace_j2g_fromfn_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_A_class }

func (t *A_arbace_j2g_fromfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_A); return ok }

func A_arbace_j2g_fromfn_A_Cast(x any) *A_arbace_j2g_fromfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_A_class)) }; return v }



type A_arbace_j2g_fromfn_box_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_box_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000004_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000004_A_New() *A_arbace_j2g_fromfn_eval564000004_A { t := &A_arbace_j2g_fromfn_eval564000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000004_A_class }

func (t *A_arbace_j2g_fromfn_eval564000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); return ok }

func A_arbace_j2g_fromfn_eval564000004_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000004_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000008_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000008_A_New() *A_arbace_j2g_fromfn_eval564000008_A { t := &A_arbace_j2g_fromfn_eval564000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000008_A_class }

func (t *A_arbace_j2g_fromfn_eval564000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); return ok }

func A_arbace_j2g_fromfn_eval564000008_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000008_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000008_fn__564000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_fn__564000037_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A struct{ j2g_header uint64; F_s__564000014, F_iter__564000013 any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A struct{ j2g_header uint64; F_b__564000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_fn__564000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A struct{ j2g_header uint64; F_iter__564000052, F_s__564000053 any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A struct{ j2g_header uint64; F_b__564000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_tag_A_fn_class *jrt.Class
