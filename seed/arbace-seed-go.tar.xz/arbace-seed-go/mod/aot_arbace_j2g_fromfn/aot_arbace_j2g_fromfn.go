//line aot_arbace_j2g_fromfn.ae:1
package aot_arbace_j2g_fromfn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_New() *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_9); tmp2 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(A_arbace_j2g_fromfn_A_const_1, A_arbace_j2g_fromfn_A_const_2, A_arbace_j2g_fromfn_A_const_3, A_arbace_j2g_fromfn_A_const_4, A_arbace_j2g_fromfn_A_const_5, A_arbace_j2g_fromfn_A_const_6, A_arbace_j2g_fromfn_A_const_7); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_New() *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000008_fn__564000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_10.GetRawRoot__O()); var tmp2 any; var root_21 any = A_arbace_j2g_fromfn_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_j2g_fromfn_A_const_12; if linked_22 == nil { tmp2 = ifn_23.Invoke_O__O(arg_24) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_21, arg_24) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_fromfn_A_const_13.GetRawRoot__O(), A_arbace_j2g_fromfn_A_const_14) }
















func A_arbace_j2g_fromfn_tag_A_New() *A_arbace_j2g_fromfn_tag_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_tag_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Ctor() {}
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_25 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = sym__0; var arg_29 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_fromfn_A_const_16, type__1)); if linked_26 == nil { return ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { return linked_26.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) } }






func A_arbace_j2g_fromfn_roots_A_New() *A_arbace_j2g_fromfn_roots_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Invoke_O__O(self any) any {


	var root_30 any = A_arbace_j2g_fromfn_A_const_17.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New(); var tmp2 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class
	if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class = fncls__93d; tmp2 = fncls__93d } else { tmp2 = fncls__93 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_33 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O())
//line :28:1
	var arg_34 any = A_arbace_j2g_fromfn_A_const_30; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New() *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Invoke_O_O__O(self, s__564000014__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(s__564000014__1, self); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Ctor_O_O(c__s__564000014, c__iter__564000013 any) { t.F_s__564000014 = c__s__564000014; t.F_iter__564000013 = c__iter__564000013 }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Invoke_O__O(self any) any { { var s__564000014__1 any; var t_ any = t.F_s__564000014; t.F_s__564000014 = nil; s__564000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_35 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__564000014__1; if linked_36 == nil { temp__1927000414__auto____2 = ifn_37.Invoke_O__O(arg_38) } else { temp__1927000414__auto____2 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_39 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__564000014__3; if linked_40 == nil { tmp1 = ifn_41.Invoke_O__O(arg_42) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_43 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = s__564000014__3; if linked_44 == nil { c__1927001037__auto____4 = ifn_45.Invoke_O__O(arg_46) } else { c__1927001037__auto____4 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_43, arg_46) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000016__6 any; var root_47 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_48 == nil { b__564000016__6 = ifn_49.Invoke_O__O(arg_50) } else { b__564000016__6 = linked_48.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_47, arg_50) }; var tmp2 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(b__564000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_57 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_62 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = b__564000016__6; if linked_63 == nil { arg_60 = ifn_64.Invoke_O__O(arg_65) } else { arg_60 = linked_63.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_62, arg_65) }; var arg_61 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp5 any; var root_66 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = s__564000014__3; if linked_67 == nil { tmp5 = ifn_68.Invoke_O__O(arg_69) } else { tmp5 = linked_67.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_66, arg_69) }; arg_61 = tmp4.Invoke_O__O(tmp5); if linked_58 == nil { return ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { return linked_58.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } } else { var root_70 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_75 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = b__564000016__6; if linked_76 == nil { arg_73 = ifn_77.Invoke_O__O(arg_78) } else { arg_73 = linked_76.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_75, arg_78) }; var arg_74 any; if linked_71 == nil { return ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { return linked_71.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) } } } else { var vec__564000024__4 any; var root_79 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__564000014__3; if linked_80 == nil { vec__564000024__4 = ifn_81.Invoke_O__O(arg_82) } else { vec__564000024__4 = linked_80.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_79, arg_82) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_83 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_87 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp7 any; var root_88 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__564000014__3; if linked_89 == nil { tmp7 = ifn_90.Invoke_O__O(arg_91) } else { tmp7 = linked_89.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_88, arg_91) }; arg_87 = tmp6.Invoke_O__O(tmp7); if linked_84 == nil { return ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { return linked_84.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Ctor_O_I_O(c__b__564000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000016 = c__b__564000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Invoke_O__O(self any) any { { var i__564000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__564000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_51 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t.F_b__564000016; var arg_55 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_52 == nil { ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { linked_52.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; i__564000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_fromfn_functional_QMARK__A_New() *A_arbace_j2g_fromfn_functional_QMARK__A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Invoke_O_O__O(self, n__0 any) any {





	var tmp1 any; var root_94 any = A_arbace_j2g_fromfn_A_const_31.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = n__0; if linked_95 == nil { tmp1 = ifn_96.Invoke_O__O(arg_97) } else { tmp1 = linked_95.(*aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(tmp1) {
		var root_98 any = A_arbace_j2g_fromfn_A_const_32.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_classes_env.A_arbace_classes_env_reflected_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = n__0; var arg_102 any = A_arbace_j2g_fromfn_A_const_33; var arg_103 any; var tmp2 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; arg_103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_99 == nil { return ifn_100.Invoke_O_O_O__O(arg_101, arg_102, arg_103) } else { return linked_99.(*aot_arbace_classes_env.A_arbace_classes_env_reflected_A).Invoke_O_O_O_O__O(root_98, arg_101, arg_102, arg_103) } } else {
//line :38:1
			var temp__1927000414__auto____2 any; var root_105 any = A_arbace_j2g_fromfn_A_const_34.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_107 lang.IFn

			if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = n__0; if linked_106 == nil { temp__1927000414__auto____2 = ifn_107.Invoke_O__O(arg_108) } else { temp__1927000414__auto____2 = linked_106.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var d__3 any = temp__1927000414__auto____2; var tmp4 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
				{ var root_109 any = A_arbace_j2g_fromfn_A_const_35.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp5 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New(); var tmp6 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class = fncls__114d; tmp6 = fncls__114d } else { tmp6 = fncls__114 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_113 any; var root_115 any = A_arbace_j2g_fromfn_A_const_37.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_j2g_fromfn_A_const_38.Invoke_O__O(d__3); if linked_116 == nil { arg_113 = ifn_117.Invoke_O__O(arg_118) } else { arg_113 = linked_116.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_115, arg_118) }; if linked_110 == nil { tmp4 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { tmp4 = linked_110.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) } }
//line :40:1
				return nil }(); if tmp7 != nil { if jrt.Exception_InstanceOf(tmp7) { var ___6 jrt.Exception_I = jrt.Exception_Cast(tmp7); _ = ___6; tmp4 = jrt.Boolean_FALSE.Ref() } else { panic(tmp7) } }; return tmp4 } else { return nil } } }
//line :39:1
func A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Invoke_O_O__O(self, c__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__1)).IsAnnotationPresent_Class__Z(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8))).Ref() }

func A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Ctor() {}
//line :41:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Invoke_O_O__O(self, p1__564000030_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_9, A_arbace_j2g_fromfn_A_const_36.Invoke_O__O(p1__564000030_SHARP___1))).Ref() }


func A_arbace_j2g_fromfn_fis_A_New() *A_arbace_j2g_fromfn_fis_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_A) Ctor() {}
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_A) Invoke_O_O__O(self, T__0_ any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var root_119 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = T__0_; var arg_123 any = Lit_1; if linked_120 == nil { and__1927000168__auto____2 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { and__1927000168__auto____2 = linked_120.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_124 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = T__0_; var arg_128 any = Lit_2; if linked_125 == nil { tmp1 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { tmp1 = linked_125.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_129 any = A_arbace_j2g_fromfn_A_const_40.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_133 any = A_arbace_j2g_fromfn_A_const_41.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var tmp2 any = A_arbace_j2g_fromfn_fis_fn__564000037_A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; arg_136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_137 any = T__0_; if linked_134 == nil { arg_132 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { arg_132 = linked_134.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }; if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_129, arg_132) } } else {
//line :49:1
			return nil } }
func A_arbace_j2g_fromfn_fis_fn__564000037_A_New() *A_arbace_j2g_fromfn_fis_fn__564000037_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_fn__564000037_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Ctor() {}
//line :50:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Invoke_O_O__O(self, p1__564000036_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_138 any = A_arbace_j2g_fromfn_A_const_42.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = p1__564000036_SHARP___1; if linked_139 == nil { and__1927000168__auto____2 = ifn_140.Invoke_O__O(arg_141) } else { and__1927000168__auto____2 = linked_139.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_142 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_146 any = A_arbace_j2g_fromfn_A_const_44.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = p1__564000036_SHARP___1; if linked_147 == nil { arg_145 = ifn_148.Invoke_O__O(arg_149) } else { arg_145 = linked_147.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_146, arg_149) }; if linked_143 == nil { and__1927000168__auto____3 = ifn_144.Invoke_O__O(arg_145) } else { and__1927000168__auto____3 = linked_143.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_142, arg_145) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_150 any = A_arbace_j2g_fromfn_A_const_45.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_j2g_fromfn_functional_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = p1__564000036_SHARP___1; if linked_151 == nil { and__1927000168__auto____4 = ifn_152.Invoke_O__O(arg_153) } else { and__1927000168__auto____4 = linked_151.(*A_arbace_j2g_fromfn_functional_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_154 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_156 lang.IFn
													if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var root_158 any = A_arbace_j2g_fromfn_A_const_46.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_162 any = A_arbace_j2g_fromfn_A_const_47.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = p1__564000036_SHARP___1; if linked_163 == nil { arg_161 = ifn_164.Invoke_O__O(arg_165) } else { arg_161 = linked_163.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_162, arg_165) }; if linked_159 == nil { arg_157 = ifn_160.Invoke_O__O(arg_161) } else { arg_157 = linked_159.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_158, arg_161) }; if linked_155 == nil { and__1927000168__auto____5 = ifn_156.Invoke_O__O(arg_157) } else { and__1927000168__auto____5 = linked_155.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_154, arg_157) }
//line :50:1
	if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_166 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = p1__564000036_SHARP___1; if linked_167 == nil { tmp1 = ifn_168.Invoke_O__O(arg_169) } else { tmp1 = linked_167.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_166, arg_169) } }
//line :50:1
		return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___8 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___8; tmp1 = nil } else { panic(tmp2) } }; return tmp1 } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_fromfn_box_A_New() *A_arbace_j2g_fromfn_box_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_box_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_fromfn_box_A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_fromfn_box_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {
	var tmp1 any; var root_171 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = d__1; if linked_172 == nil { tmp1 = ifn_173.Invoke_O__O(arg_174) } else { tmp1 = linked_172.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_171, arg_174) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_53, p__0) } else { var tmp2 any; var root_175 any = A_arbace_j2g_fromfn_A_const_51.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_177 lang.IFn
		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = d__1; if linked_176 == nil { tmp2 = ifn_177.Invoke_O__O(arg_178) } else { tmp2 = linked_176.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_175, arg_178) }
//line :56:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_54, p__0) } else {
//line :56:1
				if A_arbace_j2g_fromfn_A_const_52 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_fromfn_result_A_New() *A_arbace_j2g_fromfn_result_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_fromfn_result_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_fromfn_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp2 any; var root_232 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_j2g_fromfn_A_const_57; var arg_236 any = Lit_1; var arg_237 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp4 any; var root_238 any = A_arbace_j2g_fromfn_A_const_66.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_242 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_239 == nil { tmp4 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp4 = linked_239.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) }; arg_237 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_233 == nil { tmp2 = ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { tmp2 = linked_233.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :61:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_12, d__1) {

				return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_67, r__0) } else {
//line :61:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, d__1) { return r__0 } else { var tmp5 any; var root_179 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_181 lang.IFn






						if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = d__1; if linked_180 == nil { tmp5 = ifn_181.Invoke_O__O(arg_182) } else { tmp5 = linked_180.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_179, arg_182) }
//line :61:1
						if jrt.J2g_Truth(tmp5) {






							var root_183 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = A_arbace_j2g_fromfn_A_const_57; var arg_187 any = A_arbace_j2g_fromfn_A_const_58; var arg_188 any = r__0; var arg_189 any = d__1; var arg_190 any; var e__3 any; var root_191 any = A_arbace_j2g_fromfn_A_const_59.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_193 lang.IFn
							if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = d__1; if linked_192 == nil { e__3 = ifn_193.Invoke_O__O(arg_194) } else { e__3 = linked_192.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_191, arg_194) }
							var tmp6 any; var root_195 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = e__3; if linked_196 == nil { tmp6 = ifn_197.Invoke_O__O(arg_198) } else { tmp6 = linked_196.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_195, arg_198) }; if jrt.J2g_Truth(tmp6) { arg_190 = nil } else {
								var tmp7 any = A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(e__3); var tmp8 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class = fncls__231d; tmp8 = fncls__231d } else { tmp8 = fncls__231 }; arg_190 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() }
//line :68:1
							if linked_184 == nil { return ifn_185.Invoke_O_O_O_O_O__O(arg_186, arg_187, arg_188, arg_189, arg_190) } else { return linked_184.(*aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A).Invoke_O_O_O_O_O_O__O(root_183, arg_186, arg_187, arg_188, arg_189, arg_190) } } else {
//line :61:1
								if A_arbace_j2g_fromfn_A_const_52 != nil {














									var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp10 any; var root_243 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = A_arbace_j2g_fromfn_A_const_57; var arg_247 any; var root_249 any = A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = d__1; if linked_250 == nil { arg_247 = ifn_251.Invoke_O__O(arg_252) } else { arg_247 = linked_250.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_249, arg_252) }; var arg_248 any = Lit_15; if linked_244 == nil { tmp10 = ifn_245.Invoke_O_O_O__O(arg_246, arg_247, arg_248) } else { tmp10 = linked_244.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_243, arg_246, arg_247, arg_248) }; return tmp9.Invoke_O_O__O(tmp10, r__0) } else {
//line :61:1
										return nil
									}
							}
					}
				}
		}
}



func A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(p0 any) *A_arbace_j2g_fromfn_result_fn__564000042_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :71:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Invoke_O__O(self any) any { { var e__1 any; var t_ any = t.F_e; t.F_e = nil; e__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_199 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = e__1; if linked_200 == nil { tmp1 = ifn_201.Invoke_O__O(arg_202) } else { tmp1 = linked_200.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_227 any = A_arbace_j2g_fromfn_A_const_59.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = e__1; if linked_228 == nil { tmp2 = ifn_229.Invoke_O__O(arg_230) } else { tmp2 = linked_228.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_227, arg_230) }; e__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
										var tmp3 any; var root_203 any = A_arbace_j2g_fromfn_A_const_60.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var tmp4 any = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New(); var tmp5 *jrt.Class; var fncls__208 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class; if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class = fncls__208d; tmp5 = fncls__208d } else { tmp5 = fncls__208 }; arg_206 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_207 any; var tmp6 any; var root_209 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = e__1; if linked_210 == nil { tmp6 = ifn_211.Invoke_O__O(arg_212) } else { tmp6 = linked_210.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_209, arg_212) }; if jrt.J2g_Truth(tmp6) {
											var root_213 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(e__1))).Ref(); if linked_214 == nil { arg_207 = ifn_215.Invoke_O__O(arg_216) } else { arg_207 = linked_214.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_213, arg_216) } } else {
												var root_217 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = A_arbace_j2g_fromfn_A_const_57; var arg_221 any; var root_223 any = A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = e__1; if linked_224 == nil { arg_221 = ifn_225.Invoke_O__O(arg_226) } else { arg_221 = linked_224.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_223, arg_226) }; var arg_222 any = Lit_18; if linked_218 == nil { arg_207 = ifn_219.Invoke_O_O_O__O(arg_220, arg_221, arg_222) } else { arg_207 = linked_218.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_217, arg_220, arg_221, arg_222) } }
//line :72:1
	if linked_204 == nil { tmp3 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { tmp3 = linked_204.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :71:1*/panic("j2g: unreachable") }
func A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New() *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Ctor() {}
//line :72:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Invoke_O_O__O(self, p1__564000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_61, p1__564000041_SHARP___1) }





func A_arbace_j2g_fromfn_set_form_A_New() *A_arbace_j2g_fromfn_set_form_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_fromfn_set_form_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_fromfn_set_form_A) Invoke_O_O__O(self, fi__0 any) any { var sam__2 any; var root_253 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_255 lang.IFn; if


	linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = fi__0; if linked_254 == nil { sam__2 = ifn_255.Invoke_O__O(arg_256) } else { sam__2 = linked_254.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_253, arg_256) }; var vec__564000049__3 any; var root_257 any = /*line :78:1*/A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_259 lang.IFn; if



	linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = A_arbace_j2g_fromfn_A_const_69.Invoke_O__O(sam__2); if linked_258 == nil { vec__564000049__3 = ifn_259.Invoke_O__O(arg_260) } else { vec__564000049__3 = linked_258.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_257, arg_260) }; var ps__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__6 any; var root_261 any = A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_263 lang.IFn; if




	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var iter__1927001039__auto____6 any; var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New(); var tmp2 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class = fncls__331d; tmp2 = fncls__331d } else { tmp2 = fncls__331 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp4 any; var root_332 any = A_arbace_j2g_fromfn_A_const_71.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__4)).Ref(); if linked_333 == nil { tmp4 = ifn_334.Invoke_O__O(arg_335) } else { tmp4 = linked_333.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_332, arg_335) }; arg_264 = tmp3.Invoke_O__O(tmp4); if linked_262 == nil { pn__6 = ifn_263.Invoke_O__O(arg_264) } else { pn__6 = linked_262.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_261, arg_264) }; var call__7 any; var tmp5 lang.IFn = /*line :78:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_fromfn_A_const_72; var tmp7 any = A_arbace_j2g_fromfn_A_const_73; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_fromfn_A_const_74; var tmp10 any; var root_336 any = A_arbace_j2g_fromfn_A_const_75.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_338 lang.IFn; if





	linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_340 any = A_arbace_j2g_fromfn_A_const_76; var arg_341 any = A_arbace_j2g_fromfn_A_const_77; var arg_342 any; var root_343 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O(); var arg_347 any = pn__6; var arg_348 any = ps__4; if linked_344 == nil { arg_342 = ifn_345.Invoke_O_O_O__O(arg_346, arg_347, arg_348) } else { arg_342 = linked_344.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_343, arg_346, arg_347, arg_348) }; if linked_337 == nil { tmp10 = ifn_338.Invoke_O_O_O_O__O(arg_339, arg_340, arg_341, arg_342) } else { tmp10 = linked_337.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_336, arg_339, arg_340, arg_341, arg_342) }; call__7 = tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10)); var fnf__8 any; var tmp11 lang.IFn = /*line :78:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_fromfn_A_const_80; var tmp13 any; var G__564000062__8_ any; var root_349 any = A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_351 lang.IFn; if






	linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var root_353 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var tmp14 any = A_arbace_j2g_fromfn_set_form_fn__564000063_A_New(); var tmp15 *jrt.Class; var fncls__369 *jrt.Class = A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class; if fncls__369 == nil { var fncls__369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class = fncls__369d; tmp15 = fncls__369d } else { tmp15 = fncls__369 }; arg_356 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_357 any = pn__6; var arg_358 any = ps__4; if linked_354 == nil { arg_352 = ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { arg_352 = linked_354.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) }; if linked_350 == nil { G__564000062__8_ = ifn_351.Invoke_O__O(arg_352) } else { G__564000062__8_ = linked_350.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_349, arg_352) }; var tmp16 any; var root_370 any = A_arbace_j2g_fromfn_A_const_83.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_372 lang.IFn; if
	linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = Lit_24; var arg_374 any = r__5; if linked_371 == nil { tmp16 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { tmp16 = linked_371.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if /*line :85:1*/ jrt.J2g_Truth(tmp16) {
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_84.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_fromfn_A_const_85.GetRawRoot__O(); var tmp19 any = A_arbace_j2g_fromfn_A_const_16; var tmp20 any; var root_382 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_j2g_fromfn_A_const_57; var arg_386 any = r__5; if linked_383 == nil { tmp20 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { tmp20 = linked_383.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }; tmp13 = tmp17.Invoke_O_O_O_O__O(G__564000062__8_, tmp18, tmp19, tmp20) } else {
//line :85:1
			tmp13 = G__564000062__8_ }; var tmp21 any = tmp13; var tmp22 any; if

	lang.Util_Equiv_O_O__Z_NoInit(Lit_24, r__5) { tmp22 = call__7 } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_fromfn_A_const_86; var tmp25 any; var root_387 any = A_arbace_j2g_fromfn_A_const_87.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, A_arbace_j2g_fromfn_result_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = call__7; var arg_391 any = r__5; if linked_388 == nil { tmp25 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { tmp25 = linked_388.(*A_arbace_j2g_fromfn_result_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; tmp22 = tmp23.Invoke_O_O__O(tmp24, tmp25) }; fnf__8 = /*line :85:1*/tmp11.Invoke_O_O_O__O(tmp12, tmp21, tmp22); var tmp26 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_fromfn_A_const_88; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_fromfn_A_const_89; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_fromfn_A_const_90; var tmp32 any; var root_392 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_j2g_fromfn_A_const_57; var arg_396 any = fi__0; var arg_397 any = Lit_18; if linked_393 == nil { tmp32 = ifn_394.Invoke_O_O_O__O(arg_395, arg_396, arg_397) } else { tmp32 = linked_393.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_392, arg_395, arg_396, arg_397) }; var tmp33 any = tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32)); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_fromfn_A_const_91; var tmp36 any; var root_398 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_400 lang.IFn; if
	linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var tmp37 any; var root_403 any = A_arbace_j2g_fromfn_A_const_81.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = A_arbace_j2g_fromfn_A_const_92; var arg_407 any = A_arbace_j2g_fromfn_A_const_93; if linked_404 == nil { tmp37 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { tmp37 = linked_404.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }; arg_401 = lang.Tuple_Create_O__IPersistentVector(tmp37); var arg_402 any = A_arbace_j2g_fromfn_A_const_94; if linked_399 == nil { tmp36 = ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { tmp36 = linked_399.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) }; var tmp38 any = tmp36; var tmp39 lang.IFn = /*line :88:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_fromfn_A_const_95; var tmp41 any = A_arbace_j2g_fromfn_A_const_96; var tmp42 any = lang.Tuple_Create_O_O__IPersistentVector(tmp41, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_97, A_arbace_j2g_fromfn_A_const_98)); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_fromfn_A_const_99; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_fromfn_A_const_100; var tmp47 any; var root_408 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_410 lang.IFn; if


	linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = A_arbace_j2g_fromfn_A_const_57; var arg_412 any = fi__0; var arg_413 any = Lit_25; if linked_409 == nil { tmp47 = ifn_410.Invoke_O_O_O__O(arg_411, arg_412, arg_413) } else { tmp47 = linked_409.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_408, arg_411, arg_412, arg_413) }; return /*line :88:1*/ tmp26.Invoke_O_O_O__O(tmp27, tmp33, tmp34.Invoke_O_O_O__O(tmp35, tmp38, tmp39.Invoke_O_O_O__O(tmp40, tmp42, tmp43.Invoke_O_O__O(tmp44, tmp45.Invoke_O_O_O_O__O(tmp46, tmp47, A_arbace_j2g_fromfn_A_const_101, fnf__8))))) }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New() *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Invoke_O_O__O(self, s__564000053__1 any) any { var tmp1 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(self, s__564000053__1); var tmp2 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class = fncls__330d; tmp2 = fncls__330d } else { tmp2 = fncls__330 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Ctor_O_O(c__iter__564000052, c__s__564000053 any) { t.F_iter__564000052 = c__iter__564000052; t.F_s__564000053 = c__s__564000053 }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Invoke_O__O(self any) any { { var s__564000053__1 any; var t_ any = t.F_s__564000053; t.F_s__564000053 = nil; s__564000053__1 = t_; for { var temp__1927000414__auto____2 any; var root_265 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = s__564000053__1; if linked_266 == nil { temp__1927000414__auto____2 = ifn_267.Invoke_O__O(arg_268) } else { temp__1927000414__auto____2 = linked_266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000053__3 any = temp__1927000414__auto____2; var tmp1 any; var root_269 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__564000053__3; if linked_270 == nil { tmp1 = ifn_271.Invoke_O__O(arg_272) } else { tmp1 = linked_270.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_269, arg_272) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_273 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__564000053__3; if linked_274 == nil { c__1927001037__auto____4 = ifn_275.Invoke_O__O(arg_276) } else { c__1927001037__auto____4 = linked_274.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_273, arg_276) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000055__6 any; var root_277 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_278 == nil { b__564000055__6 = ifn_279.Invoke_O__O(arg_280) } else { b__564000055__6 = linked_278.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_277, arg_280) }; var tmp2 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(b__564000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__290 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class; if fncls__290 == nil { var fncls__290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class = fncls__290d; tmp3 = fncls__290d } else { tmp3 = fncls__290 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_291 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var root_296 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = b__564000055__6; if linked_297 == nil { arg_294 = ifn_298.Invoke_O__O(arg_299) } else { arg_294 = linked_297.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_296, arg_299) }; var arg_295 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp5 any; var root_300 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = s__564000053__3; if linked_301 == nil { tmp5 = ifn_302.Invoke_O__O(arg_303) } else { tmp5 = linked_301.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_300, arg_303) }; arg_295 = tmp4.Invoke_O__O(tmp5); if linked_292 == nil { return ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { return linked_292.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) } } else { var root_304 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var root_309 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = b__564000055__6; if linked_310 == nil { arg_307 = ifn_311.Invoke_O__O(arg_312) } else { arg_307 = linked_310.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_309, arg_312) }; var arg_308 any; if linked_305 == nil { return ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { return linked_305.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) } } } else { var i__4 any; var root_313 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = s__564000053__3; if linked_314 == nil { i__4 = ifn_315.Invoke_O__O(arg_316) } else { i__4 = linked_314.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_313, arg_316) }; var root_317 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var root_322 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); if linked_323 == nil { arg_320 = ifn_324.Invoke_O__O(arg_325) } else { arg_320 = linked_323.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_322, arg_325) }; var arg_321 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp7 any; var root_326 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = s__564000053__3; if linked_327 == nil { tmp7 = ifn_328.Invoke_O__O(arg_329) } else { tmp7 = linked_327.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_326, arg_329) }; arg_321 = tmp6.Invoke_O__O(tmp7); if linked_318 == nil { return ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { return linked_318.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Ctor_O_I_O(c__b__564000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000055 = c__b__564000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Invoke_O__O(self any) any { { var i__564000054__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000054__1)); var root_281 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = t.F_b__564000055; var arg_285 any; var root_286 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_287 == nil { arg_285 = ifn_288.Invoke_O__O(arg_289) } else { arg_285 = linked_287.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_286, arg_289) }; if linked_282 == nil { ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { linked_282.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) }; i__564000054__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000054__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_fromfn_set_form_fn__564000063_A_New() *A_arbace_j2g_fromfn_set_form_fn__564000063_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_fn__564000063_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Invoke_O_O_O__O(self, p1__564000047_SHARP___1, p2__564000048_SHARP___2 any) any { var root_359 any = A_arbace_j2g_fromfn_A_const_81.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = p1__564000047_SHARP___1; var arg_363 any; var root_364 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = A_arbace_j2g_fromfn_A_const_57; var arg_368 any = p2__564000048_SHARP___2; if linked_365 == nil { arg_363 = ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { arg_363 = linked_365.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) }; if linked_360 == nil { return ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { return linked_360.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) } }







func A_arbace_j2g_fromfn_forms_A_New() *A_arbace_j2g_fromfn_forms_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_forms_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_fromfn_forms_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_fromfn_forms_A) Invoke_O_O__O(self, fis__0 any) any {


	var tmp1 any; var root_414 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = fis__0; if linked_415 == nil { tmp1 = ifn_416.Invoke_O__O(arg_417) } else { tmp1 = linked_415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_414, arg_417) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_fromfn_A_const_107; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fis__0)).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_fromfn_A_const_102; var tmp6 any = A_arbace_j2g_fromfn_A_const_103; var tmp7 any; var root_418 any = A_arbace_j2g_fromfn_A_const_75.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_420 lang.IFn










		if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_422 any = A_arbace_j2g_fromfn_A_const_104; var arg_423 any = A_arbace_j2g_fromfn_A_const_105; var arg_424 any = lang.PersistentVector_EMPTY.Ref(); var arg_425 any; var root_426 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = A_arbace_j2g_fromfn_A_const_106.GetRawRoot__O(); var arg_430 any = fis__0; if linked_427 == nil { arg_425 = ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { arg_425 = linked_427.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) }; if linked_419 == nil { tmp7 = ifn_420.Invoke_O_O_O_O_O__O(arg_421, arg_422, arg_423, arg_424, arg_425) } else { tmp7 = linked_419.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_418, arg_421, arg_422, arg_423, arg_424, arg_425) }
//line :96:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp5, tmp6, tmp7) } else { return nil
		}
}










































type A_arbace_j2g_fromfn_A struct{ jrt.Object }

var A_arbace_j2g_fromfn_A_const_pool *jrt.RefArray

var A_arbace_j2g_fromfn_A_const_0 *lang.Var

var A_arbace_j2g_fromfn_A_const_1 any

var A_arbace_j2g_fromfn_A_const_2 any

var A_arbace_j2g_fromfn_A_const_3 any

var A_arbace_j2g_fromfn_A_const_4 any

var A_arbace_j2g_fromfn_A_const_5 any

var A_arbace_j2g_fromfn_A_const_6 any

var A_arbace_j2g_fromfn_A_const_7 any

var A_arbace_j2g_fromfn_A_const_8 *lang.Var

var A_arbace_j2g_fromfn_A_const_9 any

var A_arbace_j2g_fromfn_A_const_10 *lang.Var

var A_arbace_j2g_fromfn_A_const_11 *lang.Var

var A_arbace_j2g_fromfn_A_const_12 *lang.Var

var A_arbace_j2g_fromfn_A_const_13 *lang.Var

var A_arbace_j2g_fromfn_A_const_14 any

var A_arbace_j2g_fromfn_A_const_15 *lang.Var

var A_arbace_j2g_fromfn_A_const_16 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_17 *lang.Var

var A_arbace_j2g_fromfn_A_const_18 *lang.Var

var A_arbace_j2g_fromfn_A_const_19 *lang.Var

var A_arbace_j2g_fromfn_A_const_20 *lang.Var

var A_arbace_j2g_fromfn_A_const_21 *lang.Var

var A_arbace_j2g_fromfn_A_const_22 *lang.Var

var A_arbace_j2g_fromfn_A_const_23 *lang.Var

var A_arbace_j2g_fromfn_A_const_24 *lang.Var

var A_arbace_j2g_fromfn_A_const_25 *lang.Var

var A_arbace_j2g_fromfn_A_const_26 *lang.Var

var A_arbace_j2g_fromfn_A_const_27 *lang.Var

var A_arbace_j2g_fromfn_A_const_28 *lang.Var

var A_arbace_j2g_fromfn_A_const_29 *lang.Var

var A_arbace_j2g_fromfn_A_const_30 any

var A_arbace_j2g_fromfn_A_const_31 *lang.Var

var A_arbace_j2g_fromfn_A_const_32 *lang.Var

var A_arbace_j2g_fromfn_A_const_33 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_34 *lang.Var

var A_arbace_j2g_fromfn_A_const_35 *lang.Var

var A_arbace_j2g_fromfn_A_const_36 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_37 *lang.Var

var A_arbace_j2g_fromfn_A_const_38 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_39 *lang.Var

var A_arbace_j2g_fromfn_A_const_40 *lang.Var

var A_arbace_j2g_fromfn_A_const_41 *lang.Var

var A_arbace_j2g_fromfn_A_const_42 *lang.Var

var A_arbace_j2g_fromfn_A_const_43 *lang.Var

var A_arbace_j2g_fromfn_A_const_44 *lang.Var

var A_arbace_j2g_fromfn_A_const_45 *lang.Var

var A_arbace_j2g_fromfn_A_const_46 *lang.Var

var A_arbace_j2g_fromfn_A_const_47 *lang.Var

var A_arbace_j2g_fromfn_A_const_48 *lang.Var

var A_arbace_j2g_fromfn_A_const_49 *lang.Var

var A_arbace_j2g_fromfn_A_const_50 *lang.Var

var A_arbace_j2g_fromfn_A_const_51 *lang.Var

var A_arbace_j2g_fromfn_A_const_52 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_53 any

var A_arbace_j2g_fromfn_A_const_54 any

var A_arbace_j2g_fromfn_A_const_55 *lang.Var

var A_arbace_j2g_fromfn_A_const_56 *lang.Var

var A_arbace_j2g_fromfn_A_const_57 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_58 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_59 *lang.Var

var A_arbace_j2g_fromfn_A_const_60 *lang.Var

var A_arbace_j2g_fromfn_A_const_61 any

var A_arbace_j2g_fromfn_A_const_62 *lang.Var

var A_arbace_j2g_fromfn_A_const_63 *lang.Var

var A_arbace_j2g_fromfn_A_const_64 *lang.Var

var A_arbace_j2g_fromfn_A_const_65 *lang.Var

var A_arbace_j2g_fromfn_A_const_66 *lang.Var

var A_arbace_j2g_fromfn_A_const_67 any

var A_arbace_j2g_fromfn_A_const_68 *lang.Var

var A_arbace_j2g_fromfn_A_const_69 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_70 *lang.Var

var A_arbace_j2g_fromfn_A_const_71 *lang.Var

var A_arbace_j2g_fromfn_A_const_72 any

var A_arbace_j2g_fromfn_A_const_73 any

var A_arbace_j2g_fromfn_A_const_74 any

var A_arbace_j2g_fromfn_A_const_75 *lang.Var

var A_arbace_j2g_fromfn_A_const_76 any

var A_arbace_j2g_fromfn_A_const_77 any

var A_arbace_j2g_fromfn_A_const_78 *lang.Var

var A_arbace_j2g_fromfn_A_const_79 *lang.Var

var A_arbace_j2g_fromfn_A_const_80 any

var A_arbace_j2g_fromfn_A_const_81 *lang.Var

var A_arbace_j2g_fromfn_A_const_82 *lang.Var

var A_arbace_j2g_fromfn_A_const_83 *lang.Var

var A_arbace_j2g_fromfn_A_const_84 *lang.Var

var A_arbace_j2g_fromfn_A_const_85 *lang.Var

var A_arbace_j2g_fromfn_A_const_86 any

var A_arbace_j2g_fromfn_A_const_87 *lang.Var

var A_arbace_j2g_fromfn_A_const_88 any

var A_arbace_j2g_fromfn_A_const_89 any

var A_arbace_j2g_fromfn_A_const_90 any

var A_arbace_j2g_fromfn_A_const_91 any

var A_arbace_j2g_fromfn_A_const_92 any

var A_arbace_j2g_fromfn_A_const_93 any

var A_arbace_j2g_fromfn_A_const_94 any

var A_arbace_j2g_fromfn_A_const_95 any

var A_arbace_j2g_fromfn_A_const_96 any

var A_arbace_j2g_fromfn_A_const_97 any

var A_arbace_j2g_fromfn_A_const_98 any

var A_arbace_j2g_fromfn_A_const_99 any

var A_arbace_j2g_fromfn_A_const_100 any

var A_arbace_j2g_fromfn_A_const_101 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_102 any

var A_arbace_j2g_fromfn_A_const_103 any

var A_arbace_j2g_fromfn_A_const_104 any

var A_arbace_j2g_fromfn_A_const_105 any

var A_arbace_j2g_fromfn_A_const_106 *lang.Var

var A_arbace_j2g_fromfn_A_const_107 any

var A_arbace_j2g_fromfn_A_init jrt.ClassInit

func A_arbace_j2g_fromfn_A_Init() { if !A_arbace_j2g_fromfn_A_init.Done() { A_arbace_j2g_fromfn_A_init.Run(A_arbace_j2g_fromfn_A_clinit) } }

func A_arbace_j2g_fromfn_A_clinit() { A_arbace_j2g_fromfn_A_clinit_p0(); A_arbace_j2g_fromfn_A_clinit_p1(); A_arbace_j2g_fromfn_A_clinit_p2(); A_arbace_j2g_fromfn_A_clinit_p3(); A_arbace_j2g_fromfn_A_clinit_p4(); A_arbace_j2g_fromfn_A_clinit_p5(); A_arbace_j2g_fromfn_A_clinit_p6(); A_arbace_j2g_fromfn_A_clinit_p7(); A_arbace_j2g_fromfn_A_clinit_p8() }

func A_arbace_j2g_fromfn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_fromfn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 178); A_arbace_j2g_fromfn_A_const_0 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[70]); A_arbace_j2g_fromfn_A_const_1 = A_arbace_j2g_fromfn_A_const_pool.A[71]; A_arbace_j2g_fromfn_A_const_2 = A_arbace_j2g_fromfn_A_const_pool.A[72]; A_arbace_j2g_fromfn_A_const_3 = A_arbace_j2g_fromfn_A_const_pool.A[73]; A_arbace_j2g_fromfn_A_const_4 = A_arbace_j2g_fromfn_A_const_pool.A[74]; A_arbace_j2g_fromfn_A_const_5 = A_arbace_j2g_fromfn_A_const_pool.A[75]; A_arbace_j2g_fromfn_A_const_6 = A_arbace_j2g_fromfn_A_const_pool.A[76]; A_arbace_j2g_fromfn_A_const_7 = A_arbace_j2g_fromfn_A_const_pool.A[77]; A_arbace_j2g_fromfn_A_const_8 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[78]); A_arbace_j2g_fromfn_A_const_9 = A_arbace_j2g_fromfn_A_const_pool.A[79]; A_arbace_j2g_fromfn_A_const_10 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[80]); A_arbace_j2g_fromfn_A_const_11 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[81]); A_arbace_j2g_fromfn_A_const_12 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[82]) }

func A_arbace_j2g_fromfn_A_clinit_p1() { A_arbace_j2g_fromfn_A_const_13 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[83]); A_arbace_j2g_fromfn_A_const_14 = A_arbace_j2g_fromfn_A_const_pool.A[84]; A_arbace_j2g_fromfn_A_const_15 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[85]); A_arbace_j2g_fromfn_A_const_16 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[86]); A_arbace_j2g_fromfn_A_const_17 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[87]); A_arbace_j2g_fromfn_A_const_18 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[88]); A_arbace_j2g_fromfn_A_const_19 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[89]); A_arbace_j2g_fromfn_A_const_20 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[90]); A_arbace_j2g_fromfn_A_const_21 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[91]); A_arbace_j2g_fromfn_A_const_22 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[92]); A_arbace_j2g_fromfn_A_const_23 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[93]); A_arbace_j2g_fromfn_A_const_24 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[94]) }

func A_arbace_j2g_fromfn_A_clinit_p2() { A_arbace_j2g_fromfn_A_const_25 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[95]); A_arbace_j2g_fromfn_A_const_26 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[96]); A_arbace_j2g_fromfn_A_const_27 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[97]); A_arbace_j2g_fromfn_A_const_28 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[98]); A_arbace_j2g_fromfn_A_const_29 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[99]); A_arbace_j2g_fromfn_A_const_30 = A_arbace_j2g_fromfn_A_const_pool.A[100]; A_arbace_j2g_fromfn_A_const_31 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[101]); A_arbace_j2g_fromfn_A_const_32 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[102]); A_arbace_j2g_fromfn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[103]); A_arbace_j2g_fromfn_A_const_34 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[104]); A_arbace_j2g_fromfn_A_const_35 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[105]); A_arbace_j2g_fromfn_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[106]) }

func A_arbace_j2g_fromfn_A_clinit_p3() { A_arbace_j2g_fromfn_A_const_37 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[107]); A_arbace_j2g_fromfn_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[108]); A_arbace_j2g_fromfn_A_const_39 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[109]); A_arbace_j2g_fromfn_A_const_40 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[110]); A_arbace_j2g_fromfn_A_const_41 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[111]); A_arbace_j2g_fromfn_A_const_42 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[112]); A_arbace_j2g_fromfn_A_const_43 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[113]); A_arbace_j2g_fromfn_A_const_44 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[114]); A_arbace_j2g_fromfn_A_const_45 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[115]); A_arbace_j2g_fromfn_A_const_46 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[116]); A_arbace_j2g_fromfn_A_const_47 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[117]); A_arbace_j2g_fromfn_A_const_48 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[118]) }

func A_arbace_j2g_fromfn_A_clinit_p4() { A_arbace_j2g_fromfn_A_const_49 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[119]); A_arbace_j2g_fromfn_A_const_50 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[120]); A_arbace_j2g_fromfn_A_const_51 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[121]); A_arbace_j2g_fromfn_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[122]); A_arbace_j2g_fromfn_A_const_53 = A_arbace_j2g_fromfn_A_const_pool.A[123]; A_arbace_j2g_fromfn_A_const_54 = A_arbace_j2g_fromfn_A_const_pool.A[124]; A_arbace_j2g_fromfn_A_const_55 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[125]); A_arbace_j2g_fromfn_A_const_56 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[126]); A_arbace_j2g_fromfn_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[127]); A_arbace_j2g_fromfn_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[128]); A_arbace_j2g_fromfn_A_const_59 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[129]); A_arbace_j2g_fromfn_A_const_60 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[130]) }

func A_arbace_j2g_fromfn_A_clinit_p5() { A_arbace_j2g_fromfn_A_const_61 = A_arbace_j2g_fromfn_A_const_pool.A[131]; A_arbace_j2g_fromfn_A_const_62 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[132]); A_arbace_j2g_fromfn_A_const_63 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[133]); A_arbace_j2g_fromfn_A_const_64 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[134]); A_arbace_j2g_fromfn_A_const_65 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[135]); A_arbace_j2g_fromfn_A_const_66 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[136]); A_arbace_j2g_fromfn_A_const_67 = A_arbace_j2g_fromfn_A_const_pool.A[137]; A_arbace_j2g_fromfn_A_const_68 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[138]); A_arbace_j2g_fromfn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[139]); A_arbace_j2g_fromfn_A_const_70 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[140]); A_arbace_j2g_fromfn_A_const_71 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[141]); A_arbace_j2g_fromfn_A_const_72 = A_arbace_j2g_fromfn_A_const_pool.A[142]; A_arbace_j2g_fromfn_A_const_73 = A_arbace_j2g_fromfn_A_const_pool.A[143] }

func A_arbace_j2g_fromfn_A_clinit_p6() { A_arbace_j2g_fromfn_A_const_74 = A_arbace_j2g_fromfn_A_const_pool.A[144]; A_arbace_j2g_fromfn_A_const_75 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[145]); A_arbace_j2g_fromfn_A_const_76 = A_arbace_j2g_fromfn_A_const_pool.A[146]; A_arbace_j2g_fromfn_A_const_77 = A_arbace_j2g_fromfn_A_const_pool.A[147]; A_arbace_j2g_fromfn_A_const_78 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[148]); A_arbace_j2g_fromfn_A_const_79 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[149]); A_arbace_j2g_fromfn_A_const_80 = A_arbace_j2g_fromfn_A_const_pool.A[150]; A_arbace_j2g_fromfn_A_const_81 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[151]); A_arbace_j2g_fromfn_A_const_82 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[152]); A_arbace_j2g_fromfn_A_const_83 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[153]); A_arbace_j2g_fromfn_A_const_84 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[154]); A_arbace_j2g_fromfn_A_const_85 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[155]); A_arbace_j2g_fromfn_A_const_86 = A_arbace_j2g_fromfn_A_const_pool.A[156] }

func A_arbace_j2g_fromfn_A_clinit_p7() { A_arbace_j2g_fromfn_A_const_87 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[157]); A_arbace_j2g_fromfn_A_const_88 = A_arbace_j2g_fromfn_A_const_pool.A[158]; A_arbace_j2g_fromfn_A_const_89 = A_arbace_j2g_fromfn_A_const_pool.A[159]; A_arbace_j2g_fromfn_A_const_90 = A_arbace_j2g_fromfn_A_const_pool.A[160]; A_arbace_j2g_fromfn_A_const_91 = A_arbace_j2g_fromfn_A_const_pool.A[161]; A_arbace_j2g_fromfn_A_const_92 = A_arbace_j2g_fromfn_A_const_pool.A[162]; A_arbace_j2g_fromfn_A_const_93 = A_arbace_j2g_fromfn_A_const_pool.A[163]; A_arbace_j2g_fromfn_A_const_94 = A_arbace_j2g_fromfn_A_const_pool.A[164]; A_arbace_j2g_fromfn_A_const_95 = A_arbace_j2g_fromfn_A_const_pool.A[165]; A_arbace_j2g_fromfn_A_const_96 = A_arbace_j2g_fromfn_A_const_pool.A[166]; A_arbace_j2g_fromfn_A_const_97 = A_arbace_j2g_fromfn_A_const_pool.A[167]; A_arbace_j2g_fromfn_A_const_98 = A_arbace_j2g_fromfn_A_const_pool.A[168]; A_arbace_j2g_fromfn_A_const_99 = A_arbace_j2g_fromfn_A_const_pool.A[169]; A_arbace_j2g_fromfn_A_const_100 = A_arbace_j2g_fromfn_A_const_pool.A[170]; A_arbace_j2g_fromfn_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[171]) }

func A_arbace_j2g_fromfn_A_clinit_p8() { A_arbace_j2g_fromfn_A_const_102 = A_arbace_j2g_fromfn_A_const_pool.A[172]; A_arbace_j2g_fromfn_A_const_103 = A_arbace_j2g_fromfn_A_const_pool.A[173]; A_arbace_j2g_fromfn_A_const_104 = A_arbace_j2g_fromfn_A_const_pool.A[174]; A_arbace_j2g_fromfn_A_const_105 = A_arbace_j2g_fromfn_A_const_pool.A[175]; A_arbace_j2g_fromfn_A_const_106 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[176]); A_arbace_j2g_fromfn_A_const_107 = A_arbace_j2g_fromfn_A_const_pool.A[177] }

func A_arbace_j2g_fromfn_A_New() *A_arbace_j2g_fromfn_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_A_class }

func (t *A_arbace_j2g_fromfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_A); return ok }

func A_arbace_j2g_fromfn_A_Cast(x any) *A_arbace_j2g_fromfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_A_class)) }; return v }



type A_arbace_j2g_fromfn_box_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_box_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000004_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000004_A_New() *A_arbace_j2g_fromfn_eval564000004_A { t := &A_arbace_j2g_fromfn_eval564000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000004_A_class }

func (t *A_arbace_j2g_fromfn_eval564000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); return ok }

func A_arbace_j2g_fromfn_eval564000004_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000004_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000008_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000008_A_New() *A_arbace_j2g_fromfn_eval564000008_A { t := &A_arbace_j2g_fromfn_eval564000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000008_A_class }

func (t *A_arbace_j2g_fromfn_eval564000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); return ok }

func A_arbace_j2g_fromfn_eval564000008_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000008_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000008_fn__564000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_fn__564000037_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A struct{ j2g_header uint64; F_s__564000014, F_iter__564000013 any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A struct{ j2g_header uint64; F_b__564000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_fn__564000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A struct{ j2g_header uint64; F_iter__564000052, F_s__564000053 any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A struct{ j2g_header uint64; F_b__564000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_tag_A_fn_class *jrt.Class
