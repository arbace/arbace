//line aot_arbace_j2g_fromfn.ae:1
package aot_arbace_j2g_fromfn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_New() *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_fromfn_A_const_9); tmp2 = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(A_arbace_j2g_fromfn_A_const_1, A_arbace_j2g_fromfn_A_const_2, A_arbace_j2g_fromfn_A_const_3, A_arbace_j2g_fromfn_A_const_4, A_arbace_j2g_fromfn_A_const_5, A_arbace_j2g_fromfn_A_const_6, A_arbace_j2g_fromfn_A_const_7); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_New() *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_eval564000008_fn__564000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_fromfn_eval564000008_fn__564000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_10.GetRawRoot__O()); var tmp2 any; var root_21 any = A_arbace_j2g_fromfn_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_j2g_fromfn_A_const_12; if linked_22 == nil { tmp2 = ifn_23.Invoke_O__O(arg_24) } else { tmp2 = linked_22.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_21, arg_24) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_fromfn_A_const_13.GetRawRoot__O(), A_arbace_j2g_fromfn_A_const_14) }
















func A_arbace_j2g_fromfn_tag_A_New() *A_arbace_j2g_fromfn_tag_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_tag_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Ctor() {}
//line :18:1
func (t *A_arbace_j2g_fromfn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_25 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = sym__0; var arg_29 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_fromfn_A_const_16, type__1)); if linked_26 == nil { return ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { return linked_26.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) } }






func A_arbace_j2g_fromfn_roots_A_New() *A_arbace_j2g_fromfn_roots_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_fromfn_roots_A) Invoke_O__O(self any) any {


	var root_30 any = A_arbace_j2g_fromfn_A_const_17.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var iter__1927001039__auto____1 any; var fnbody__96 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New(); var tmp1 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class
	if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class = fncls__95d; tmp1 = fncls__95d } else { tmp1 = fncls__95 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp1, nil); arg_33 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O())
//line :28:1
	var arg_34 any = A_arbace_j2g_fromfn_A_const_30; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_New() *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A) Invoke_O_O__O(self, s__564000014__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(s__564000014__1, self); var tmp2 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__94); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class = fncls__93d; tmp2 = fncls__93d } else { tmp2 = fncls__93 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Ctor_O_O(c__s__564000014, c__iter__564000013 any) { t.F_s__564000014 = c__s__564000014; t.F_iter__564000013 = c__iter__564000013 }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A) Invoke_O__O(self any) any { { var s__564000014__1 any; var t_ any = t.F_s__564000014; t.F_s__564000014 = nil; s__564000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_35 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__564000014__1; if linked_36 == nil { temp__1927000414__auto____2 = ifn_37.Invoke_O__O(arg_38) } else { temp__1927000414__auto____2 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_39 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__564000014__3; if linked_40 == nil { tmp1 = ifn_41.Invoke_O__O(arg_42) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_43 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = s__564000014__3; if linked_44 == nil { c__1927001037__auto____4 = ifn_45.Invoke_O__O(arg_46) } else { c__1927001037__auto____4 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_43, arg_46) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000016__6 any; var root_47 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_48 == nil { b__564000016__6 = ifn_49.Invoke_O__O(arg_50) } else { b__564000016__6 = linked_48.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_47, arg_50) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(b__564000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__57); A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_58 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var root_63 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = b__564000016__6; if linked_64 == nil { arg_61 = ifn_65.Invoke_O__O(arg_66) } else { arg_61 = linked_64.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_63, arg_66) }; var arg_62 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp5 any; var root_67 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = s__564000014__3; if linked_68 == nil { tmp5 = ifn_69.Invoke_O__O(arg_70) } else { tmp5 = linked_68.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_67, arg_70) }; arg_62 = tmp4.Invoke_O__O(tmp5); if linked_59 == nil { return ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { return linked_59.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) } } else { var root_71 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var root_76 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = b__564000016__6; if linked_77 == nil { arg_74 = ifn_78.Invoke_O__O(arg_79) } else { arg_74 = linked_77.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_76, arg_79) }; var arg_75 any; if linked_72 == nil { return ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { return linked_72.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) } } } else { var vec__564000024__4 any; var root_80 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = s__564000014__3; if linked_81 == nil { vec__564000024__4 = ifn_82.Invoke_O__O(arg_83) } else { vec__564000024__4 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_84 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_88 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000013); var tmp7 any; var root_89 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = s__564000014__3; if linked_90 == nil { tmp7 = ifn_91.Invoke_O__O(arg_92) } else { tmp7 = linked_90.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_89, arg_92) }; arg_88 = tmp6.Invoke_O__O(tmp7); if linked_85 == nil { return ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { return linked_85.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :29:1
func A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Ctor_O_I_O(c__b__564000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000016 = c__b__564000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :29:1
func (t *A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A) Invoke_O__O(self any) any { { var i__564000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__564000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_51 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t.F_b__564000016; var arg_55 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_1, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_52 == nil { ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { linked_52.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; i__564000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_fromfn_functional_QMARK__A_New() *A_arbace_j2g_fromfn_functional_QMARK__A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Ctor() {}
//line :32:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__A) Invoke_O_O__O(self, n__0 any) any {





	var tmp1 any; var root_97 any = A_arbace_j2g_fromfn_A_const_31.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = n__0; if linked_98 == nil { tmp1 = ifn_99.Invoke_O__O(arg_100) } else { tmp1 = linked_98.(*aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp1) {
		var root_101 any = A_arbace_j2g_fromfn_A_const_32.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_classes_env.A_arbace_classes_env_reflected_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = n__0; var arg_105 any = A_arbace_j2g_fromfn_A_const_33; var arg_106 any; var fnbody__108 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New(); var tmp2 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class = fncls__107d; tmp2 = fncls__107d } else { tmp2 = fncls__107 }; arg_106 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp2, nil); if linked_102 == nil { return ifn_103.Invoke_O_O_O__O(arg_104, arg_105, arg_106) } else { return linked_102.(*aot_arbace_classes_env.A_arbace_classes_env_reflected_A).Invoke_O_O_O_O__O(root_101, arg_104, arg_105, arg_106) } } else {
//line :38:1
			var temp__1927000414__auto____2 any; var root_109 any = A_arbace_j2g_fromfn_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_111 lang.IFn

			if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; if linked_110 == nil { temp__1927000414__auto____2 = ifn_111.Invoke_O__O(arg_112) } else { temp__1927000414__auto____2 = linked_110.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var d__3 any = temp__1927000414__auto____2; var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
				{ var root_113 any = A_arbace_j2g_fromfn_A_const_35.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var fnbody__119 any = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New(); var tmp4 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class = fncls__118d; tmp4 = fncls__118d } else { tmp4 = fncls__118 }; arg_116 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp4, nil); var arg_117 any; var root_120 any = A_arbace_j2g_fromfn_A_const_37.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_j2g_fromfn_A_const_38.Invoke_O__O(d__3); if linked_121 == nil { arg_117 = ifn_122.Invoke_O__O(arg_123) } else { arg_117 = linked_121.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_120, arg_123) }; if linked_114 == nil { tmp3 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) } }
//line :40:1
				return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ___6 jrt.Exception_I = jrt.Exception_Cast(tmp5); _ = ___6; tmp3 = jrt.Boolean_FALSE.Ref() } else { panic(tmp5) } }; return tmp3 } else { return nil } } }
//line :39:1
func A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A) Invoke_O_O__O(self, c__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__1)).IsAnnotationPresent_Class__Z(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8))).Ref() }

func A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_New() *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Ctor() {}
//line :41:1
func (t *A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A) Invoke_O_O__O(self, p1__564000030_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_9, A_arbace_j2g_fromfn_A_const_36.Invoke_O__O(p1__564000030_SHARP___1))).Ref() }


func A_arbace_j2g_fromfn_fis_A_New() *A_arbace_j2g_fromfn_fis_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_A) Ctor() {}
//line :44:1
func (t *A_arbace_j2g_fromfn_fis_A) Invoke_O_O__O(self, T__0_ any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var root_124 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = T__0_; var arg_128 any = Lit_1; if linked_125 == nil { and__1927000168__auto____2 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { and__1927000168__auto____2 = linked_125.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_129 any = A_arbace_j2g_fromfn_A_const_39.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = T__0_; var arg_133 any = Lit_2; if linked_130 == nil { tmp1 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { tmp1 = linked_130.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_134 any = A_arbace_j2g_fromfn_A_const_40.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any; var root_138 any = A_arbace_j2g_fromfn_A_const_41.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var fnbody__176 any = A_arbace_j2g_fromfn_fis_fn__564000037_A_New(); var tmp2 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class = fncls__175d; tmp2 = fncls__175d } else { tmp2 = fncls__175 }; arg_141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp2, nil); var arg_142 any = T__0_; if linked_139 == nil { arg_137 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { arg_137 = linked_139.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }; if linked_135 == nil { return ifn_136.Invoke_O__O(arg_137) } else { return linked_135.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_134, arg_137) } } else {
//line :49:1
			return nil } }
func A_arbace_j2g_fromfn_fis_fn__564000037_A_New() *A_arbace_j2g_fromfn_fis_fn__564000037_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_fis_fn__564000037_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Ctor() {}
//line :50:1
func (t *A_arbace_j2g_fromfn_fis_fn__564000037_A) Invoke_O_O__O(self, p1__564000036_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_143 any = A_arbace_j2g_fromfn_A_const_42.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = p1__564000036_SHARP___1; if linked_144 == nil { and__1927000168__auto____2 = ifn_145.Invoke_O__O(arg_146) } else { and__1927000168__auto____2 = linked_144.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_143, arg_146) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_147 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_151 any = A_arbace_j2g_fromfn_A_const_44.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = p1__564000036_SHARP___1; if linked_152 == nil { arg_150 = ifn_153.Invoke_O__O(arg_154) } else { arg_150 = linked_152.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if linked_148 == nil { and__1927000168__auto____3 = ifn_149.Invoke_O__O(arg_150) } else { and__1927000168__auto____3 = linked_148.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_147, arg_150) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_155 any = A_arbace_j2g_fromfn_A_const_45.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_j2g_fromfn_functional_QMARK__A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = p1__564000036_SHARP___1; if linked_156 == nil { and__1927000168__auto____4 = ifn_157.Invoke_O__O(arg_158) } else { and__1927000168__auto____4 = linked_156.(*A_arbace_j2g_fromfn_functional_QMARK__A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_159 any = A_arbace_j2g_fromfn_A_const_43.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_161 lang.IFn
													if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_163 any = A_arbace_j2g_fromfn_A_const_46.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var root_167 any = A_arbace_j2g_fromfn_A_const_47.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = p1__564000036_SHARP___1; if linked_168 == nil { arg_166 = ifn_169.Invoke_O__O(arg_170) } else { arg_166 = linked_168.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_167, arg_170) }; if linked_164 == nil { arg_162 = ifn_165.Invoke_O__O(arg_166) } else { arg_162 = linked_164.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_163, arg_166) }; if linked_160 == nil { and__1927000168__auto____5 = ifn_161.Invoke_O__O(arg_162) } else { and__1927000168__auto____5 = linked_160.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_159, arg_162) }
//line :50:1
	if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_171 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = p1__564000036_SHARP___1; if linked_172 == nil { tmp1 = ifn_173.Invoke_O__O(arg_174) } else { tmp1 = linked_172.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_171, arg_174) } }
//line :50:1
		return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___8 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___8; tmp1 = nil } else { panic(tmp2) } }; return tmp1 } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_fromfn_box_A_New() *A_arbace_j2g_fromfn_box_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_box_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_fromfn_box_A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_fromfn_box_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {
	var tmp1 any; var root_177 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = d__1; if linked_178 == nil { tmp1 = ifn_179.Invoke_O__O(arg_180) } else { tmp1 = linked_178.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_53, p__0) } else { var tmp2 any; var root_181 any = A_arbace_j2g_fromfn_A_const_51.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_183 lang.IFn
		if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = d__1; if linked_182 == nil { tmp2 = ifn_183.Invoke_O__O(arg_184) } else { tmp2 = linked_182.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_181, arg_184) }
//line :56:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_54, p__0) } else {
//line :56:1
				if A_arbace_j2g_fromfn_A_const_52 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_fromfn_result_A_New() *A_arbace_j2g_fromfn_result_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_fromfn_result_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_fromfn_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp2 any; var root_240 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_j2g_fromfn_A_const_57; var arg_244 any = Lit_1; var arg_245 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil); var tmp4 any; var root_246 any = A_arbace_j2g_fromfn_A_const_66.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_250 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_247 == nil { tmp4 = ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { tmp4 = linked_247.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_246, arg_249, arg_250) }; arg_245 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_241 == nil { tmp2 = ifn_242.Invoke_O_O_O__O(arg_243, arg_244, arg_245) } else { tmp2 = linked_241.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_240, arg_243, arg_244, arg_245) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :61:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_12, d__1) {

				return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_67, r__0) } else {
//line :61:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, d__1) { return r__0 } else { var tmp5 any; var root_185 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_187 lang.IFn






						if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = d__1; if linked_186 == nil { tmp5 = ifn_187.Invoke_O__O(arg_188) } else { tmp5 = linked_186.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_185, arg_188) }
//line :61:1
						if jrt.J2g_Truth(tmp5) {






							var root_189 any = A_arbace_j2g_fromfn_A_const_56.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = A_arbace_j2g_fromfn_A_const_57; var arg_193 any = A_arbace_j2g_fromfn_A_const_58; var arg_194 any = r__0; var arg_195 any = d__1; var arg_196 any; var e__3 any; var root_197 any = A_arbace_j2g_fromfn_A_const_59.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_199 lang.IFn
							if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = d__1; if linked_198 == nil { e__3 = ifn_199.Invoke_O__O(arg_200) } else { e__3 = linked_198.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_197, arg_200) }
							var tmp6 any; var root_201 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = e__3; if linked_202 == nil { tmp6 = ifn_203.Invoke_O__O(arg_204) } else { tmp6 = linked_202.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(tmp6) { arg_196 = nil } else {
								var tmp7 *lang.Compiler_AOTFn; var fnbody__239 any = A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(e__3); var tmp8 *jrt.Class; var fncls__238 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class; if fncls__238 == nil { var fncls__238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__239); A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class = fncls__238d; tmp8 = fncls__238d } else { tmp8 = fncls__238 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__239, tmp8, nil); arg_196 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O() }
//line :68:1
							if linked_190 == nil { return ifn_191.Invoke_O_O_O_O_O__O(arg_192, arg_193, arg_194, arg_195, arg_196) } else { return linked_190.(*aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A).Invoke_O_O_O_O_O_O__O(root_189, arg_192, arg_193, arg_194, arg_195, arg_196) } } else {
//line :61:1
								if A_arbace_j2g_fromfn_A_const_52 != nil {














									var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp10 any; var root_251 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = A_arbace_j2g_fromfn_A_const_57; var arg_255 any; var root_257 any = A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = d__1; if linked_258 == nil { arg_255 = ifn_259.Invoke_O__O(arg_260) } else { arg_255 = linked_258.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_257, arg_260) }; var arg_256 any = Lit_15; if linked_252 == nil { tmp10 = ifn_253.Invoke_O_O_O__O(arg_254, arg_255, arg_256) } else { tmp10 = linked_252.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_251, arg_254, arg_255, arg_256) }; return tmp9.Invoke_O_O__O(tmp10, r__0) } else {
//line :61:1
										return nil
									}
							}
					}
				}
		}
}



func A_arbace_j2g_fromfn_result_fn__564000042_A_New_O(p0 any) *A_arbace_j2g_fromfn_result_fn__564000042_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :71:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_A) Invoke_O__O(self any) any { { var e__1 any; var t_ any = t.F_e; t.F_e = nil; e__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_205 any = A_arbace_j2g_fromfn_A_const_55.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = e__1; if linked_206 == nil { tmp1 = ifn_207.Invoke_O__O(arg_208) } else { tmp1 = linked_206.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_234 any = A_arbace_j2g_fromfn_A_const_59.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = e__1; if linked_235 == nil { tmp2 = ifn_236.Invoke_O__O(arg_237) } else { tmp2 = linked_235.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_234, arg_237) }; e__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
										var tmp3 any; var root_209 any = A_arbace_j2g_fromfn_A_const_60.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var fnbody__215 any = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New(); var tmp4 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class = fncls__214d; tmp4 = fncls__214d } else { tmp4 = fncls__214 }; arg_212 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__215, tmp4, nil); var arg_213 any; var tmp5 any; var root_216 any = A_arbace_j2g_fromfn_A_const_49.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = e__1; if linked_217 == nil { tmp5 = ifn_218.Invoke_O__O(arg_219) } else { tmp5 = linked_217.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp5) {
											var root_220 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_63.GetRawRoot__O()).Invoke_O__O(e__1))).Ref(); if linked_221 == nil { arg_213 = ifn_222.Invoke_O__O(arg_223) } else { arg_213 = linked_221.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_220, arg_223) } } else {
												var root_224 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = A_arbace_j2g_fromfn_A_const_57; var arg_228 any; var root_230 any = A_arbace_j2g_fromfn_A_const_65.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = e__1; if linked_231 == nil { arg_228 = ifn_232.Invoke_O__O(arg_233) } else { arg_228 = linked_231.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_230, arg_233) }; var arg_229 any = Lit_18; if linked_225 == nil { arg_213 = ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { arg_213 = linked_225.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) } }
//line :72:1
	if linked_210 == nil { tmp3 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp3 = linked_210.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :71:1*/panic("j2g: unreachable") }
func A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_New() *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Ctor() {}
//line :72:1
func (t *A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A) Invoke_O_O__O(self, p1__564000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_61, p1__564000041_SHARP___1) }





func A_arbace_j2g_fromfn_set_form_A_New() *A_arbace_j2g_fromfn_set_form_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_fromfn_set_form_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_fromfn_set_form_A) Invoke_O_O__O(self, fi__0 any) any { var sam__2 any; var root_261 any = A_arbace_j2g_fromfn_A_const_48.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A_fn_class); var ifn_263 lang.IFn; if


	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = fi__0; if linked_262 == nil { sam__2 = ifn_263.Invoke_O__O(arg_264) } else { sam__2 = linked_262.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_find_sam_A).Invoke_O_O__O(root_261, arg_264) }; var vec__564000049__3 any; var root_265 any = /*line :78:1*/A_arbace_j2g_fromfn_A_const_68.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_267 lang.IFn; if



	linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_j2g_fromfn_A_const_69.Invoke_O__O(sam__2); if linked_266 == nil { vec__564000049__3 = ifn_267.Invoke_O__O(arg_268) } else { vec__564000049__3 = linked_266.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_265, arg_268) }; var ps__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__564000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__6 any; var root_269 any = A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_271 lang.IFn; if




	linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var iter__1927001039__auto____6 any; var fnbody__342 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New(); var tmp1 *jrt.Class; var fncls__341 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class; if fncls__341 == nil { var fncls__341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class = fncls__341d; tmp1 = fncls__341d } else { tmp1 = fncls__341 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__342, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp3 any; var root_343 any = A_arbace_j2g_fromfn_A_const_71.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__4)).Ref(); if linked_344 == nil { tmp3 = ifn_345.Invoke_O__O(arg_346) } else { tmp3 = linked_344.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_343, arg_346) }; arg_272 = tmp2.Invoke_O__O(tmp3); if linked_270 == nil { pn__6 = ifn_271.Invoke_O__O(arg_272) } else { pn__6 = linked_270.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_269, arg_272) }; var call__7 any; var tmp4 lang.IFn = /*line :78:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_fromfn_A_const_72; var tmp6 any = A_arbace_j2g_fromfn_A_const_73; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_fromfn_A_const_74; var tmp9 any; var root_347 any = A_arbace_j2g_fromfn_A_const_75.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_349 lang.IFn; if





	linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_351 any = A_arbace_j2g_fromfn_A_const_76; var arg_352 any = A_arbace_j2g_fromfn_A_const_77; var arg_353 any; var root_354 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_j2g_fromfn_A_const_79.GetRawRoot__O(); var arg_358 any = pn__6; var arg_359 any = ps__4; if linked_355 == nil { arg_353 = ifn_356.Invoke_O_O_O__O(arg_357, arg_358, arg_359) } else { arg_353 = linked_355.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_354, arg_357, arg_358, arg_359) }; if linked_348 == nil { tmp9 = ifn_349.Invoke_O_O_O_O__O(arg_350, arg_351, arg_352, arg_353) } else { tmp9 = linked_348.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_347, arg_350, arg_351, arg_352, arg_353) }; call__7 = tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9)); var fnf__8 any; var tmp10 lang.IFn = /*line :78:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_fromfn_A_const_80; var tmp12 any; var G__564000062__8_ any; var root_360 any = A_arbace_j2g_fromfn_A_const_70.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_362 lang.IFn; if






	linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; var root_364 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; var fnbody__381 any = A_arbace_j2g_fromfn_set_form_fn__564000063_A_New(); var tmp13 *jrt.Class; var fncls__380 *jrt.Class = A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class; if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class = fncls__380d; tmp13 = fncls__380d } else { tmp13 = fncls__380 }; arg_367 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__381, tmp13, nil); var arg_368 any = pn__6; var arg_369 any = ps__4; if linked_365 == nil { arg_363 = ifn_366.Invoke_O_O_O__O(arg_367, arg_368, arg_369) } else { arg_363 = linked_365.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_364, arg_367, arg_368, arg_369) }; if linked_361 == nil { G__564000062__8_ = ifn_362.Invoke_O__O(arg_363) } else { G__564000062__8_ = linked_361.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_360, arg_363) }; var tmp14 any; var root_382 any = A_arbace_j2g_fromfn_A_const_83.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_384 lang.IFn; if
	linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = Lit_24; var arg_386 any = r__5; if linked_383 == nil { tmp14 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { tmp14 = linked_383.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }; if /*line :85:1*/ jrt.J2g_Truth(tmp14) {
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_84.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_fromfn_A_const_85.GetRawRoot__O(); var tmp17 any = A_arbace_j2g_fromfn_A_const_16; var tmp18 any; var root_394 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = A_arbace_j2g_fromfn_A_const_57; var arg_398 any = r__5; if linked_395 == nil { tmp18 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { tmp18 = linked_395.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; tmp12 = tmp15.Invoke_O_O_O_O__O(G__564000062__8_, tmp16, tmp17, tmp18) } else {
//line :85:1
			tmp12 = G__564000062__8_ }; var tmp19 any = tmp12; var tmp20 any; if

	lang.Util_Equiv_O_O__Z_NoInit(Lit_24, r__5) { tmp20 = call__7 } else { var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_fromfn_A_const_86; var tmp23 any; var root_399 any = A_arbace_j2g_fromfn_A_const_87.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_j2g_fromfn_result_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = call__7; var arg_403 any = r__5; if linked_400 == nil { tmp23 = ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { tmp23 = linked_400.(*A_arbace_j2g_fromfn_result_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) }; tmp20 = tmp21.Invoke_O_O__O(tmp22, tmp23) }; fnf__8 = /*line :85:1*/tmp10.Invoke_O_O_O__O(tmp11, tmp19, tmp20); var tmp24 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_fromfn_A_const_88; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_fromfn_A_const_89; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_fromfn_A_const_90; var tmp30 any; var root_404 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = A_arbace_j2g_fromfn_A_const_57; var arg_408 any = fi__0; var arg_409 any = Lit_18; if linked_405 == nil { tmp30 = ifn_406.Invoke_O_O_O__O(arg_407, arg_408, arg_409) } else { tmp30 = linked_405.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_404, arg_407, arg_408, arg_409) }; var tmp31 any = tmp26.Invoke_O_O__O(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30)); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_fromfn_A_const_91; var tmp34 any; var root_410 any = A_arbace_j2g_fromfn_A_const_15.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_412 lang.IFn; if
	linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var tmp35 any; var root_415 any = A_arbace_j2g_fromfn_A_const_81.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_j2g_fromfn_A_const_92; var arg_419 any = A_arbace_j2g_fromfn_A_const_93; if linked_416 == nil { tmp35 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { tmp35 = linked_416.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; arg_413 = lang.Tuple_Create_O__IPersistentVector(tmp35); var arg_414 any = A_arbace_j2g_fromfn_A_const_94; if linked_411 == nil { tmp34 = ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { tmp34 = linked_411.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; var tmp36 any = tmp34; var tmp37 lang.IFn = /*line :88:1*/lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_fromfn_A_const_95; var tmp39 any = A_arbace_j2g_fromfn_A_const_96; var tmp40 any = lang.Tuple_Create_O_O__IPersistentVector(tmp39, lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_fromfn_A_const_97, A_arbace_j2g_fromfn_A_const_98)); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_fromfn_A_const_99; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_fromfn_A_const_100; var tmp45 any; var root_420 any = A_arbace_j2g_fromfn_A_const_64.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_422 lang.IFn; if


	linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_j2g_fromfn_A_const_57; var arg_424 any = fi__0; var arg_425 any = Lit_25; if linked_421 == nil { tmp45 = ifn_422.Invoke_O_O_O__O(arg_423, arg_424, arg_425) } else { tmp45 = linked_421.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_420, arg_423, arg_424, arg_425) }; return /*line :88:1*/ tmp24.Invoke_O_O_O__O(tmp25, tmp31, tmp32.Invoke_O_O_O__O(tmp33, tmp36, tmp37.Invoke_O_O_O__O(tmp38, tmp40, tmp41.Invoke_O_O__O(tmp42, tmp43.Invoke_O_O_O_O__O(tmp44, tmp45, A_arbace_j2g_fromfn_A_const_101, fnf__8))))) }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_New() *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A) Invoke_O_O__O(self, s__564000053__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__340 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(self, s__564000053__1); var tmp2 *jrt.Class; var fncls__339 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class; if fncls__339 == nil { var fncls__339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__340); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class = fncls__339d; tmp2 = fncls__339d } else { tmp2 = fncls__339 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__340, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_New_O_O(p0, p1 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Ctor_O_O(c__iter__564000052, c__s__564000053 any) { t.F_iter__564000052 = c__iter__564000052; t.F_s__564000053 = c__s__564000053 }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A) Invoke_O__O(self any) any { { var s__564000053__1 any; var t_ any = t.F_s__564000053; t.F_s__564000053 = nil; s__564000053__1 = t_; for { var temp__1927000414__auto____2 any; var root_273 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__564000053__1; if linked_274 == nil { temp__1927000414__auto____2 = ifn_275.Invoke_O__O(arg_276) } else { temp__1927000414__auto____2 = linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__564000053__3 any = temp__1927000414__auto____2; var tmp1 any; var root_277 any = A_arbace_j2g_fromfn_A_const_19.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = s__564000053__3; if linked_278 == nil { tmp1 = ifn_279.Invoke_O__O(arg_280) } else { tmp1 = linked_278.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_281 any = A_arbace_j2g_fromfn_A_const_20.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = s__564000053__3; if linked_282 == nil { c__1927001037__auto____4 = ifn_283.Invoke_O__O(arg_284) } else { c__1927001037__auto____4 = linked_282.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_281, arg_284) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__564000055__6 any; var root_285 any = A_arbace_j2g_fromfn_A_const_21.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_286 == nil { b__564000055__6 = ifn_287.Invoke_O__O(arg_288) } else { b__564000055__6 = linked_286.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_285, arg_288) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__299 any = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(b__564000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__298 *jrt.Class = A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class; if fncls__298 == nil { var fncls__298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__299); A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class = fncls__298d; tmp3 = fncls__298d } else { tmp3 = fncls__298 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__299, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_300 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_305 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = b__564000055__6; if linked_306 == nil { arg_303 = ifn_307.Invoke_O__O(arg_308) } else { arg_303 = linked_306.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_305, arg_308) }; var arg_304 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp5 any; var root_309 any = A_arbace_j2g_fromfn_A_const_25.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__564000053__3; if linked_310 == nil { tmp5 = ifn_311.Invoke_O__O(arg_312) } else { tmp5 = linked_310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_309, arg_312) }; arg_304 = tmp4.Invoke_O__O(tmp5); if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else { var root_313 any = A_arbace_j2g_fromfn_A_const_23.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any; var root_318 any = A_arbace_j2g_fromfn_A_const_24.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = b__564000055__6; if linked_319 == nil { arg_316 = ifn_320.Invoke_O__O(arg_321) } else { arg_316 = linked_319.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_318, arg_321) }; var arg_317 any; if linked_314 == nil { return ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { return linked_314.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) } } } else { var i__4 any; var root_322 any = A_arbace_j2g_fromfn_A_const_26.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__564000053__3; if linked_323 == nil { i__4 = ifn_324.Invoke_O__O(arg_325) } else { i__4 = linked_323.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_322, arg_325) }; var root_326 any = A_arbace_j2g_fromfn_A_const_27.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var root_331 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); if linked_332 == nil { arg_329 = ifn_333.Invoke_O__O(arg_334) } else { arg_329 = linked_332.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_331, arg_334) }; var arg_330 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__564000052); var tmp7 any; var root_335 any = A_arbace_j2g_fromfn_A_const_28.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = s__564000053__3; if linked_336 == nil { tmp7 = ifn_337.Invoke_O__O(arg_338) } else { tmp7 = linked_336.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_335, arg_338) }; arg_330 = tmp6.Invoke_O__O(tmp7); if linked_327 == nil { return ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { return linked_327.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :83:1
func A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Ctor_O_I_O(c__b__564000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__564000055 = c__b__564000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :83:1
func (t *A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A) Invoke_O__O(self any) any { { var i__564000054__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__564000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__564000054__1)); var root_289 any = A_arbace_j2g_fromfn_A_const_22.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = t.F_b__564000055; var arg_293 any; var root_294 any = A_arbace_j2g_fromfn_A_const_62.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_295 == nil { arg_293 = ifn_296.Invoke_O__O(arg_297) } else { arg_293 = linked_295.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_294, arg_297) }; if linked_290 == nil { ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { linked_290.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }; i__564000054__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__564000054__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_fromfn_set_form_fn__564000063_A_New() *A_arbace_j2g_fromfn_set_form_fn__564000063_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_set_form_fn__564000063_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_fromfn_set_form_fn__564000063_A) Invoke_O_O_O__O(self, p1__564000047_SHARP___1, p2__564000048_SHARP___2 any) any { var root_370 any = A_arbace_j2g_fromfn_A_const_81.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_j2g_fromfn_tag_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = p1__564000047_SHARP___1; var arg_374 any; var root_375 any = A_arbace_j2g_fromfn_A_const_82.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = A_arbace_j2g_fromfn_A_const_57; var arg_379 any = p2__564000048_SHARP___2; if linked_376 == nil { arg_374 = ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { arg_374 = linked_376.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) }; if linked_371 == nil { return ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { return linked_371.(*A_arbace_j2g_fromfn_tag_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) } }







func A_arbace_j2g_fromfn_forms_A_New() *A_arbace_j2g_fromfn_forms_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_forms_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_fromfn_forms_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_fromfn_forms_A) Invoke_O_O__O(self, fis__0 any) any {


	var tmp1 any; var root_426 any = A_arbace_j2g_fromfn_A_const_18.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = fis__0; if linked_427 == nil { tmp1 = ifn_428.Invoke_O__O(arg_429) } else { tmp1 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_fromfn_A_const_107; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fis__0)).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_fromfn_A_const_102; var tmp6 any = A_arbace_j2g_fromfn_A_const_103; var tmp7 any; var root_430 any = A_arbace_j2g_fromfn_A_const_75.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_432 lang.IFn










		if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = A_arbace_j2g_fromfn_A_const_50.GetRawRoot__O(); var arg_434 any = A_arbace_j2g_fromfn_A_const_104; var arg_435 any = A_arbace_j2g_fromfn_A_const_105; var arg_436 any = lang.PersistentVector_EMPTY.Ref(); var arg_437 any; var root_438 any = A_arbace_j2g_fromfn_A_const_78.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_fromfn_A_const_106.GetRawRoot__O(); var arg_442 any = fis__0; if linked_439 == nil { arg_437 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_437 = linked_439.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_431 == nil { tmp7 = ifn_432.Invoke_O_O_O_O_O__O(arg_433, arg_434, arg_435, arg_436, arg_437) } else { tmp7 = linked_431.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_430, arg_433, arg_434, arg_435, arg_436, arg_437) }
//line :96:1
		return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp5, tmp6, tmp7) } else { return nil
		}
}










































type A_arbace_j2g_fromfn_A struct{ jrt.Object }

var A_arbace_j2g_fromfn_A_const_pool *jrt.RefArray

var A_arbace_j2g_fromfn_A_const_0 *lang.Var

var A_arbace_j2g_fromfn_A_const_1 any

var A_arbace_j2g_fromfn_A_const_2 any

var A_arbace_j2g_fromfn_A_const_3 any

var A_arbace_j2g_fromfn_A_const_4 any

var A_arbace_j2g_fromfn_A_const_5 any

var A_arbace_j2g_fromfn_A_const_6 any

var A_arbace_j2g_fromfn_A_const_7 any

var A_arbace_j2g_fromfn_A_const_8 *lang.Var

var A_arbace_j2g_fromfn_A_const_9 any

var A_arbace_j2g_fromfn_A_const_10 *lang.Var

var A_arbace_j2g_fromfn_A_const_11 *lang.Var

var A_arbace_j2g_fromfn_A_const_12 *lang.Var

var A_arbace_j2g_fromfn_A_const_13 *lang.Var

var A_arbace_j2g_fromfn_A_const_14 any

var A_arbace_j2g_fromfn_A_const_15 *lang.Var

var A_arbace_j2g_fromfn_A_const_16 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_17 *lang.Var

var A_arbace_j2g_fromfn_A_const_18 *lang.Var

var A_arbace_j2g_fromfn_A_const_19 *lang.Var

var A_arbace_j2g_fromfn_A_const_20 *lang.Var

var A_arbace_j2g_fromfn_A_const_21 *lang.Var

var A_arbace_j2g_fromfn_A_const_22 *lang.Var

var A_arbace_j2g_fromfn_A_const_23 *lang.Var

var A_arbace_j2g_fromfn_A_const_24 *lang.Var

var A_arbace_j2g_fromfn_A_const_25 *lang.Var

var A_arbace_j2g_fromfn_A_const_26 *lang.Var

var A_arbace_j2g_fromfn_A_const_27 *lang.Var

var A_arbace_j2g_fromfn_A_const_28 *lang.Var

var A_arbace_j2g_fromfn_A_const_29 *lang.Var

var A_arbace_j2g_fromfn_A_const_30 any

var A_arbace_j2g_fromfn_A_const_31 *lang.Var

var A_arbace_j2g_fromfn_A_const_32 *lang.Var

var A_arbace_j2g_fromfn_A_const_33 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_34 *lang.Var

var A_arbace_j2g_fromfn_A_const_35 *lang.Var

var A_arbace_j2g_fromfn_A_const_36 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_37 *lang.Var

var A_arbace_j2g_fromfn_A_const_38 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_39 *lang.Var

var A_arbace_j2g_fromfn_A_const_40 *lang.Var

var A_arbace_j2g_fromfn_A_const_41 *lang.Var

var A_arbace_j2g_fromfn_A_const_42 *lang.Var

var A_arbace_j2g_fromfn_A_const_43 *lang.Var

var A_arbace_j2g_fromfn_A_const_44 *lang.Var

var A_arbace_j2g_fromfn_A_const_45 *lang.Var

var A_arbace_j2g_fromfn_A_const_46 *lang.Var

var A_arbace_j2g_fromfn_A_const_47 *lang.Var

var A_arbace_j2g_fromfn_A_const_48 *lang.Var

var A_arbace_j2g_fromfn_A_const_49 *lang.Var

var A_arbace_j2g_fromfn_A_const_50 *lang.Var

var A_arbace_j2g_fromfn_A_const_51 *lang.Var

var A_arbace_j2g_fromfn_A_const_52 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_53 any

var A_arbace_j2g_fromfn_A_const_54 any

var A_arbace_j2g_fromfn_A_const_55 *lang.Var

var A_arbace_j2g_fromfn_A_const_56 *lang.Var

var A_arbace_j2g_fromfn_A_const_57 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_58 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_59 *lang.Var

var A_arbace_j2g_fromfn_A_const_60 *lang.Var

var A_arbace_j2g_fromfn_A_const_61 any

var A_arbace_j2g_fromfn_A_const_62 *lang.Var

var A_arbace_j2g_fromfn_A_const_63 *lang.Var

var A_arbace_j2g_fromfn_A_const_64 *lang.Var

var A_arbace_j2g_fromfn_A_const_65 *lang.Var

var A_arbace_j2g_fromfn_A_const_66 *lang.Var

var A_arbace_j2g_fromfn_A_const_67 any

var A_arbace_j2g_fromfn_A_const_68 *lang.Var

var A_arbace_j2g_fromfn_A_const_69 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_70 *lang.Var

var A_arbace_j2g_fromfn_A_const_71 *lang.Var

var A_arbace_j2g_fromfn_A_const_72 any

var A_arbace_j2g_fromfn_A_const_73 any

var A_arbace_j2g_fromfn_A_const_74 any

var A_arbace_j2g_fromfn_A_const_75 *lang.Var

var A_arbace_j2g_fromfn_A_const_76 any

var A_arbace_j2g_fromfn_A_const_77 any

var A_arbace_j2g_fromfn_A_const_78 *lang.Var

var A_arbace_j2g_fromfn_A_const_79 *lang.Var

var A_arbace_j2g_fromfn_A_const_80 any

var A_arbace_j2g_fromfn_A_const_81 *lang.Var

var A_arbace_j2g_fromfn_A_const_82 *lang.Var

var A_arbace_j2g_fromfn_A_const_83 *lang.Var

var A_arbace_j2g_fromfn_A_const_84 *lang.Var

var A_arbace_j2g_fromfn_A_const_85 *lang.Var

var A_arbace_j2g_fromfn_A_const_86 any

var A_arbace_j2g_fromfn_A_const_87 *lang.Var

var A_arbace_j2g_fromfn_A_const_88 any

var A_arbace_j2g_fromfn_A_const_89 any

var A_arbace_j2g_fromfn_A_const_90 any

var A_arbace_j2g_fromfn_A_const_91 any

var A_arbace_j2g_fromfn_A_const_92 any

var A_arbace_j2g_fromfn_A_const_93 any

var A_arbace_j2g_fromfn_A_const_94 any

var A_arbace_j2g_fromfn_A_const_95 any

var A_arbace_j2g_fromfn_A_const_96 any

var A_arbace_j2g_fromfn_A_const_97 any

var A_arbace_j2g_fromfn_A_const_98 any

var A_arbace_j2g_fromfn_A_const_99 any

var A_arbace_j2g_fromfn_A_const_100 any

var A_arbace_j2g_fromfn_A_const_101 *lang.Keyword

var A_arbace_j2g_fromfn_A_const_102 any

var A_arbace_j2g_fromfn_A_const_103 any

var A_arbace_j2g_fromfn_A_const_104 any

var A_arbace_j2g_fromfn_A_const_105 any

var A_arbace_j2g_fromfn_A_const_106 *lang.Var

var A_arbace_j2g_fromfn_A_const_107 any

var A_arbace_j2g_fromfn_A_init jrt.ClassInit

func A_arbace_j2g_fromfn_A_Init() { if !A_arbace_j2g_fromfn_A_init.Done() { A_arbace_j2g_fromfn_A_init.Run(A_arbace_j2g_fromfn_A_clinit) } }

func A_arbace_j2g_fromfn_A_clinit() { A_arbace_j2g_fromfn_A_clinit_p0(); A_arbace_j2g_fromfn_A_clinit_p1(); A_arbace_j2g_fromfn_A_clinit_p2(); A_arbace_j2g_fromfn_A_clinit_p3(); A_arbace_j2g_fromfn_A_clinit_p4(); A_arbace_j2g_fromfn_A_clinit_p5(); A_arbace_j2g_fromfn_A_clinit_p6(); A_arbace_j2g_fromfn_A_clinit_p7(); A_arbace_j2g_fromfn_A_clinit_p8() }

func A_arbace_j2g_fromfn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_fromfn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 178); A_arbace_j2g_fromfn_A_const_0 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[70]); A_arbace_j2g_fromfn_A_const_1 = A_arbace_j2g_fromfn_A_const_pool.A[71]; A_arbace_j2g_fromfn_A_const_2 = A_arbace_j2g_fromfn_A_const_pool.A[72]; A_arbace_j2g_fromfn_A_const_3 = A_arbace_j2g_fromfn_A_const_pool.A[73]; A_arbace_j2g_fromfn_A_const_4 = A_arbace_j2g_fromfn_A_const_pool.A[74]; A_arbace_j2g_fromfn_A_const_5 = A_arbace_j2g_fromfn_A_const_pool.A[75]; A_arbace_j2g_fromfn_A_const_6 = A_arbace_j2g_fromfn_A_const_pool.A[76]; A_arbace_j2g_fromfn_A_const_7 = A_arbace_j2g_fromfn_A_const_pool.A[77]; A_arbace_j2g_fromfn_A_const_8 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[78]); A_arbace_j2g_fromfn_A_const_9 = A_arbace_j2g_fromfn_A_const_pool.A[79]; A_arbace_j2g_fromfn_A_const_10 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[80]); A_arbace_j2g_fromfn_A_const_11 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[81]); A_arbace_j2g_fromfn_A_const_12 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[82]) }

func A_arbace_j2g_fromfn_A_clinit_p1() { A_arbace_j2g_fromfn_A_const_13 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[83]); A_arbace_j2g_fromfn_A_const_14 = A_arbace_j2g_fromfn_A_const_pool.A[84]; A_arbace_j2g_fromfn_A_const_15 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[85]); A_arbace_j2g_fromfn_A_const_16 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[86]); A_arbace_j2g_fromfn_A_const_17 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[87]); A_arbace_j2g_fromfn_A_const_18 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[88]); A_arbace_j2g_fromfn_A_const_19 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[89]); A_arbace_j2g_fromfn_A_const_20 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[90]); A_arbace_j2g_fromfn_A_const_21 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[91]); A_arbace_j2g_fromfn_A_const_22 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[92]); A_arbace_j2g_fromfn_A_const_23 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[93]); A_arbace_j2g_fromfn_A_const_24 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[94]) }

func A_arbace_j2g_fromfn_A_clinit_p2() { A_arbace_j2g_fromfn_A_const_25 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[95]); A_arbace_j2g_fromfn_A_const_26 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[96]); A_arbace_j2g_fromfn_A_const_27 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[97]); A_arbace_j2g_fromfn_A_const_28 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[98]); A_arbace_j2g_fromfn_A_const_29 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[99]); A_arbace_j2g_fromfn_A_const_30 = A_arbace_j2g_fromfn_A_const_pool.A[100]; A_arbace_j2g_fromfn_A_const_31 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[101]); A_arbace_j2g_fromfn_A_const_32 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[102]); A_arbace_j2g_fromfn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[103]); A_arbace_j2g_fromfn_A_const_34 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[104]); A_arbace_j2g_fromfn_A_const_35 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[105]); A_arbace_j2g_fromfn_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[106]) }

func A_arbace_j2g_fromfn_A_clinit_p3() { A_arbace_j2g_fromfn_A_const_37 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[107]); A_arbace_j2g_fromfn_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[108]); A_arbace_j2g_fromfn_A_const_39 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[109]); A_arbace_j2g_fromfn_A_const_40 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[110]); A_arbace_j2g_fromfn_A_const_41 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[111]); A_arbace_j2g_fromfn_A_const_42 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[112]); A_arbace_j2g_fromfn_A_const_43 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[113]); A_arbace_j2g_fromfn_A_const_44 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[114]); A_arbace_j2g_fromfn_A_const_45 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[115]); A_arbace_j2g_fromfn_A_const_46 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[116]); A_arbace_j2g_fromfn_A_const_47 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[117]); A_arbace_j2g_fromfn_A_const_48 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[118]) }

func A_arbace_j2g_fromfn_A_clinit_p4() { A_arbace_j2g_fromfn_A_const_49 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[119]); A_arbace_j2g_fromfn_A_const_50 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[120]); A_arbace_j2g_fromfn_A_const_51 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[121]); A_arbace_j2g_fromfn_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[122]); A_arbace_j2g_fromfn_A_const_53 = A_arbace_j2g_fromfn_A_const_pool.A[123]; A_arbace_j2g_fromfn_A_const_54 = A_arbace_j2g_fromfn_A_const_pool.A[124]; A_arbace_j2g_fromfn_A_const_55 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[125]); A_arbace_j2g_fromfn_A_const_56 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[126]); A_arbace_j2g_fromfn_A_const_57 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[127]); A_arbace_j2g_fromfn_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[128]); A_arbace_j2g_fromfn_A_const_59 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[129]); A_arbace_j2g_fromfn_A_const_60 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[130]) }

func A_arbace_j2g_fromfn_A_clinit_p5() { A_arbace_j2g_fromfn_A_const_61 = A_arbace_j2g_fromfn_A_const_pool.A[131]; A_arbace_j2g_fromfn_A_const_62 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[132]); A_arbace_j2g_fromfn_A_const_63 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[133]); A_arbace_j2g_fromfn_A_const_64 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[134]); A_arbace_j2g_fromfn_A_const_65 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[135]); A_arbace_j2g_fromfn_A_const_66 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[136]); A_arbace_j2g_fromfn_A_const_67 = A_arbace_j2g_fromfn_A_const_pool.A[137]; A_arbace_j2g_fromfn_A_const_68 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[138]); A_arbace_j2g_fromfn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[139]); A_arbace_j2g_fromfn_A_const_70 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[140]); A_arbace_j2g_fromfn_A_const_71 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[141]); A_arbace_j2g_fromfn_A_const_72 = A_arbace_j2g_fromfn_A_const_pool.A[142]; A_arbace_j2g_fromfn_A_const_73 = A_arbace_j2g_fromfn_A_const_pool.A[143] }

func A_arbace_j2g_fromfn_A_clinit_p6() { A_arbace_j2g_fromfn_A_const_74 = A_arbace_j2g_fromfn_A_const_pool.A[144]; A_arbace_j2g_fromfn_A_const_75 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[145]); A_arbace_j2g_fromfn_A_const_76 = A_arbace_j2g_fromfn_A_const_pool.A[146]; A_arbace_j2g_fromfn_A_const_77 = A_arbace_j2g_fromfn_A_const_pool.A[147]; A_arbace_j2g_fromfn_A_const_78 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[148]); A_arbace_j2g_fromfn_A_const_79 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[149]); A_arbace_j2g_fromfn_A_const_80 = A_arbace_j2g_fromfn_A_const_pool.A[150]; A_arbace_j2g_fromfn_A_const_81 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[151]); A_arbace_j2g_fromfn_A_const_82 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[152]); A_arbace_j2g_fromfn_A_const_83 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[153]); A_arbace_j2g_fromfn_A_const_84 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[154]); A_arbace_j2g_fromfn_A_const_85 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[155]); A_arbace_j2g_fromfn_A_const_86 = A_arbace_j2g_fromfn_A_const_pool.A[156] }

func A_arbace_j2g_fromfn_A_clinit_p7() { A_arbace_j2g_fromfn_A_const_87 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[157]); A_arbace_j2g_fromfn_A_const_88 = A_arbace_j2g_fromfn_A_const_pool.A[158]; A_arbace_j2g_fromfn_A_const_89 = A_arbace_j2g_fromfn_A_const_pool.A[159]; A_arbace_j2g_fromfn_A_const_90 = A_arbace_j2g_fromfn_A_const_pool.A[160]; A_arbace_j2g_fromfn_A_const_91 = A_arbace_j2g_fromfn_A_const_pool.A[161]; A_arbace_j2g_fromfn_A_const_92 = A_arbace_j2g_fromfn_A_const_pool.A[162]; A_arbace_j2g_fromfn_A_const_93 = A_arbace_j2g_fromfn_A_const_pool.A[163]; A_arbace_j2g_fromfn_A_const_94 = A_arbace_j2g_fromfn_A_const_pool.A[164]; A_arbace_j2g_fromfn_A_const_95 = A_arbace_j2g_fromfn_A_const_pool.A[165]; A_arbace_j2g_fromfn_A_const_96 = A_arbace_j2g_fromfn_A_const_pool.A[166]; A_arbace_j2g_fromfn_A_const_97 = A_arbace_j2g_fromfn_A_const_pool.A[167]; A_arbace_j2g_fromfn_A_const_98 = A_arbace_j2g_fromfn_A_const_pool.A[168]; A_arbace_j2g_fromfn_A_const_99 = A_arbace_j2g_fromfn_A_const_pool.A[169]; A_arbace_j2g_fromfn_A_const_100 = A_arbace_j2g_fromfn_A_const_pool.A[170]; A_arbace_j2g_fromfn_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_fromfn_A_const_pool.A[171]) }

func A_arbace_j2g_fromfn_A_clinit_p8() { A_arbace_j2g_fromfn_A_const_102 = A_arbace_j2g_fromfn_A_const_pool.A[172]; A_arbace_j2g_fromfn_A_const_103 = A_arbace_j2g_fromfn_A_const_pool.A[173]; A_arbace_j2g_fromfn_A_const_104 = A_arbace_j2g_fromfn_A_const_pool.A[174]; A_arbace_j2g_fromfn_A_const_105 = A_arbace_j2g_fromfn_A_const_pool.A[175]; A_arbace_j2g_fromfn_A_const_106 = lang.Var_Cast(A_arbace_j2g_fromfn_A_const_pool.A[176]); A_arbace_j2g_fromfn_A_const_107 = A_arbace_j2g_fromfn_A_const_pool.A[177] }

func A_arbace_j2g_fromfn_A_New() *A_arbace_j2g_fromfn_A { A_arbace_j2g_fromfn_A_Init(); t := &A_arbace_j2g_fromfn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_A_class }

func (t *A_arbace_j2g_fromfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_A); return ok }

func A_arbace_j2g_fromfn_A_Cast(x any) *A_arbace_j2g_fromfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_A_class)) }; return v }



type A_arbace_j2g_fromfn_box_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_box_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000004_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000004_A_New() *A_arbace_j2g_fromfn_eval564000004_A { t := &A_arbace_j2g_fromfn_eval564000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000004_A_class }

func (t *A_arbace_j2g_fromfn_eval564000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); return ok }

func A_arbace_j2g_fromfn_eval564000004_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000004_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000004_loading__1927001464__auto____564000005_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_eval564000008_A struct{ jrt.Object }

func A_arbace_j2g_fromfn_eval564000008_A_New() *A_arbace_j2g_fromfn_eval564000008_A { t := &A_arbace_j2g_fromfn_eval564000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ctor() {}

func (t *A_arbace_j2g_fromfn_eval564000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_fromfn_eval564000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_fromfn_eval564000008_A_class }

func (t *A_arbace_j2g_fromfn_eval564000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_fromfn_eval564000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_fromfn_eval564000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); return ok }

func A_arbace_j2g_fromfn_eval564000008_A_Cast(x any) *A_arbace_j2g_fromfn_eval564000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_fromfn_eval564000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_fromfn_eval564000008_A_class)) }; return v }



type A_arbace_j2g_fromfn_eval564000008_fn__564000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_eval564000008_fn__564000009_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_fis_fn__564000037_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_fis_fn__564000037_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000031_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_functional_QMARK__fn__564000033_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_fromfn_result_fn__564000042_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_result_fn__564000042_fn__564000043_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A struct{ j2g_header uint64; F_s__564000014, F_iter__564000013 any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A struct{ j2g_header uint64; F_b__564000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_roots_iter__564000013__564000017_fn__564000018_fn__564000019_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_fn__564000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_fn__564000063_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A struct{ j2g_header uint64; F_iter__564000052, F_s__564000053 any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A struct{ j2g_header uint64; F_b__564000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_fromfn_set_form_iter__564000052__564000056_fn__564000057_fn__564000058_A_fn_class *jrt.Class



type A_arbace_j2g_fromfn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_fromfn_tag_A_fn_class *jrt.Class
