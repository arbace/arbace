//line j2g_strings.ae:1
package aot_arbace_repr_go_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn4,elseyn1,&kn1,tkn4,namekn7,resultskn6,paramskn8,variadickn3,tagkn4,kindkn3,mapkn4,chankn3,dirkn4,recvkn4,bothkn4,sendkn7,pointerkn5,unionyn3,mapkn3,keykn4,elemyn4,chanyn1,*kn6,structyn1,|kn5,tildeyn5,tildekn5,termskn10,type-paramyn6,structkn8,embeddedks2,go3,tagkn6,fieldskn5,arraykn5,basickn3,pkgyn5,arraykn3,lenkn4,funckn9,interfaceyn4,funckn5,tupleyn9,interfacekn7,methodskn9,embeddedskn5,aliaskn6,originyn6,valueskn4,varskn5,sliceyn4,instkn4,argskn5,namedyn5,slicekn2,idkn3,intkn6,actualv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn20,arbace.repr.go.typesm2,R1,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).v11,arbace.core13,*loaded-libs*v20,arbace.repr.go.types7,*table*v11,arbace.core6,symbolv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core9,interposev11,arbace.core3,mapC16,java.lang.Stringv20,arbace.repr.go.types5,*pkg*v11,arbace.core9,contains?R2,v20,arbace.repr.go.types9,*imports*v20,arbace.repr.go.types12,*namespaces*v20,arbace.repr.go.types10,ns-name-ofv11,arbace.core3,vecv11,arbace.core6,mapcatR3,v20,arbace.repr.go.types9,type-formR4,v11,arbace.core5,rangev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR5,v20,arbace.repr.go.types5,entryv20,arbace.repr.go.types10,params-vecR6,v11,arbace.core6,empty?v11,arbace.core4,listR7,R8,v11,arbace.core9,with-metaR9,v11,arbace.core4,mapvv11,arbace.core4,compR10,R11,R12,R13,R14,R15,R16,R17,R18,v11,arbace.core7,ex-infoR19,R20,R21,R22,R22,R22,R23,R24,R25,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR26,R27,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restR28,R29,R30,R31,v11,arbace.core9,vary-metav11,arbace.core5,assocR32,R33,R34,R35,R36,v20,arbace.repr.go.types7,qualifyR37,R38,R39,R40,R41,R41,R42,R43,v11,arbace.core6,concatv20,arbace.repr.go.types11,method-elemR44,R45,R46,R47,v11,arbace.core9,namespacev20,arbace.repr.go.types19,reserved-type-headsR48,R49,R50,R51,R52,R53,R54,v11,arbace.core6,pr-strR55,v20,arbace.repr.go.types10,const-kindv20,arbace.repr.go.types11,basic-kindsS13,s5,int16s3,ints4,runes4,uints5,int32s6,uint16s7,uintptrs6,uint32s5,int64s6,uint64s5,uint8s4,int8s4,byteR56,v20,arbace.repr.go.types12,*underlying*R57,")

var Lit_1 *jrt.String = jrt.Intern("go.")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.types$ns_name_of$fn__1140000014")

var Lit_4 *jrt.String = jrt.Intern("split")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("replaceAll")

var Lit_7 *jrt.String = jrt.Intern("[.-]")

var Lit_8 *jrt.String = jrt.Intern("_")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.types$params_vec$fn__1140000018")

var Lit_10 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000027__1140000031")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000037__1140000041")

var Lit_13 *jrt.String = jrt.Intern("type entry ")

var Lit_14 *jrt.String = jrt.Intern(": ")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000027__1140000031$fn__1140000032")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000027__1140000031$fn__1140000032$fn__1140000033")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000037__1140000041$fn__1140000042")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000037__1140000041$fn__1140000042$fn__1140000043")

var Lit_19 *jrt.String = jrt.Intern("untyped")

var Lit_20 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn2,idyn6,structyn3,mapyn4,chanyn1,*yn9,interfaceyn4,instyn4,funcyn1,|yn5,tildeyn5,arrayyn5,sliceyn4,pathyn4,namekn8,declaredkn7,privateyn4,varsyn8,variadickn4,keysyn1,tkn6,stringkn5,floatkn15,untyped-complexkn4,runekn7,complexkn4,boolkn3,intkn13,untyped-floatv11,arbace.core5,in-nsMyn20,arbace.repr.go.typesm2,R0,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).m2,R0,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).R1,v20,arbace.repr.go.types7,*table*m10,R2,TR3,i10,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s33,The dump's :type-table, a vector.v20,arbace.repr.go.types5,*pkg*m10,R2,TR3,i14,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s41,The import path of the package converted.v20,arbace.repr.go.types9,*imports*m10,R2,TR3,i18,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s80,The file's imports: {path name} for the imports with a usable name (not _ or .).v20,arbace.repr.go.types12,*namespaces*m10,R2,TR3,i22,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s143,{path ns-sym} of the packages whose namespace is not their path's (ns-name-of): the other\n  packages of a directory test (doc/go/SPEC.md §4.1).v20,arbace.repr.go.types12,*underlying*m10,R2,TR3,i27,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s87,{type-id underlying-id} of the named types declared in the package (the dump's :types).v20,arbace.repr.go.types5,entrym8,R6,L1,V1,R7,R3,i31,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types19,reserved-type-headsS11,R8,R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,m8,R3,i33,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s82,Type heads (§5.1): a generic type of one of these names is instantiated with inst.v20,arbace.repr.go.types10,ns-name-ofm10,R6,L1,V1,R19,R0,s106,The namespace of a Go import path (§4.1): go. plus the path, / as ., and . and - inside an\n  element as _.R3,i37,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types7,qualifym10,R6,L1,V2,R19,R20,R0,s77,The symbol naming name of package path, from the file of the current package.R3,i44,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types9,type-formm8,R21,TR3,i52,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types10,params-vecm10,R22,TR6,L1,V2,R23,R24,R3,i54,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types11,method-elemm10,R22,TR6,L1,V1,m2,R25,V2,R20,R26,R3,i62,R4,i1,R5,s23,arbace/repr/go/types.aem10,R6,L1,V1,R7,R0,s25,The type form of type id.R3,i71,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types8,untyped?m10,R6,L1,V1,R7,R0,s41,Whether type id is an untyped basic type.R3,i114,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types11,basic-kindsm24,s6,stringR27,s7,float32R28,s7,float64R28,s15,untyped complexR29,s12,untyped runeR30,s10,complex128R31,s4,boolR32,s11,untyped intR33,s14,untyped stringR27,s12,untyped boolR32,s13,untyped floatR34,s9,complex64R31,m8,R22,TR3,i120,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types10,const-kindm10,R6,L1,V1,R7,R0,s170,The kind of constant values of type id (lit/const-form), or nil when it is not known (a\n  named type of another package, whose underlying type is in that package's dump).R3,i127,R4,i1,R5,s23,arbace/repr/go/types.ae")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.go.types$eval1140000004$loading__1927001464__auto____1140000005")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.types$eval1140000008$fn__1140000009")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.types$entry")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.types$ns_name_of")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.types$qualify")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.types$params_vec")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.types$method_elem")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.types$untyped_QMARK_")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.types$const_kind")
