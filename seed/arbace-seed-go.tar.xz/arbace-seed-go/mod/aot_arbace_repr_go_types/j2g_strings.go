//line j2g_strings.ae:1
package aot_arbace_repr_go_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,docys2,go2,idkn4,elseyn1,&kn1,tkn4,namekn6,paramskn8,variadickn7,resultskn3,tagkn4,kindkn3,mapkn4,chankn3,dirkn4,recvkn4,bothkn4,sendkn7,pointerkn5,unionyn1,|kn5,tildeyn5,tildekn5,termskn2,idyn3,mapkn3,keykn4,elemyn4,chanyn1,*kn6,structyn6,structkn8,embeddedks2,go3,tagkn6,fieldskn10,type-paramkn5,arraykn5,basickn3,pkgyn5,arraykn3,lenkn4,funckn9,interfaceyn9,interfacekn7,methodskn9,embeddedsyn4,funckn5,tupleyn6,valueskn4,varskn5,aliaskn6,originyn4,instkn4,argskn5,slicekn5,namedyn5,slicekn6,actualkn3,intv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.repr.go.typesm2,R1,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).v20,arbace.repr.go.types7,*table*v11,arbace.core6,symbolv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core9,interposev11,arbace.core3,mapC16,java.lang.StringS3,s5,falses4,trues3,nilv11,arbace.core4,listR2,v20,arbace.repr.go.types5,*pkg*v20,arbace.repr.go.types9,name-formv11,arbace.core9,contains?v20,arbace.repr.go.types9,*imports*R3,v20,arbace.repr.go.types12,*namespaces*v20,arbace.repr.go.types10,ns-name-ofv11,arbace.core3,vecv11,arbace.core6,mapcatR4,v20,arbace.repr.go.types9,type-formR5,v11,arbace.core5,rangev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR6,v20,arbace.repr.go.types5,entryv20,arbace.repr.go.types10,params-vecR7,R8,R9,v11,arbace.core6,empty?v11,arbace.core9,with-metaR10,v11,arbace.core4,mapvv11,arbace.core4,compR11,R12,R13,R14,R15,R16,R17,R18,R19,R20,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR21,R22,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restR23,v11,arbace.core7,ex-infov11,arbace.core6,pr-strR24,R25,R26,R27,R28,R28,R28,R29,R30,R31,R32,v11,arbace.core9,vary-metav11,arbace.core5,assocR33,R34,R35,R36,R37,R38,v20,arbace.repr.go.types7,qualifyR39,R40,R41,R42,R43,v11,arbace.core6,concatv20,arbace.repr.go.types11,method-elemR44,R45,R46,R46,R47,R48,R49,R50,R51,v11,arbace.core9,namespacev20,arbace.repr.go.types19,reserved-type-headsR52,R53,R54,R55,R56,v20,arbace.repr.go.types10,const-kindR57,v20,arbace.repr.go.types11,basic-kindsS13,s5,int16s3,ints4,runes4,uints5,int32s6,uint16s7,uintptrs6,uint32s5,int64s6,uint64s5,uint8s4,int8s4,byteR58,v20,arbace.repr.go.types12,*underlying*")

var Lit_1 *jrt.String = jrt.Intern("go.")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.types$ns_name_of$fn__1140000014")

var Lit_4 *jrt.String = jrt.Intern("split")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("replaceAll")

var Lit_7 *jrt.String = jrt.Intern("[.-]")

var Lit_8 *jrt.String = jrt.Intern("_")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.types$params_vec$fn__1140000019")

var Lit_10 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000028__1140000032")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000038__1140000042")

var Lit_13 *jrt.String = jrt.Intern("type entry ")

var Lit_14 *jrt.String = jrt.Intern(": ")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000028__1140000032$fn__1140000033")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000028__1140000032$fn__1140000033$fn__1140000034")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000038__1140000042$fn__1140000043")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form$iter__1140000038__1140000042$fn__1140000043$fn__1140000044")

var Lit_19 *jrt.String = jrt.Intern("untyped")

var Lit_20 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn2,idyn6,structyn3,mapyn4,chanyn1,*yn9,interfaceyn4,instyn4,funcyn1,|yn5,tildeyn5,arrayyn5,sliceyn4,pathkn3,tagyn6,Stringyn4,namekn8,declaredkn7,privateyn4,varsyn8,variadickn4,keysyn1,tkn6,stringkn5,floatkn15,untyped-complexkn4,runekn7,complexkn4,boolkn3,intkn13,untyped-floatv11,arbace.core5,in-nsMyn20,arbace.repr.go.typesm2,R0,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).m2,R0,s449,Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).R1,v20,arbace.repr.go.types7,*table*m10,R2,TR3,i10,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s33,The dump's :type-table, a vector.v20,arbace.repr.go.types5,*pkg*m10,R2,TR3,i14,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s41,The import path of the package converted.v20,arbace.repr.go.types9,*imports*m10,R2,TR3,i18,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s80,The file's imports: {path name} for the imports with a usable name (not _ or .).v20,arbace.repr.go.types12,*namespaces*m10,R2,TR3,i22,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s143,{path ns-sym} of the packages whose namespace is not their path's (ns-name-of): the other\n  packages of a directory test (doc/go/SPEC.md §4.1).v20,arbace.repr.go.types12,*underlying*m10,R2,TR3,i27,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s87,{type-id underlying-id} of the named types declared in the package (the dump's :types).v20,arbace.repr.go.types5,entrym8,R6,L1,V1,R7,R3,i31,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types19,reserved-type-headsS11,R8,R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,m8,R3,i33,R4,i1,R5,s23,arbace/repr/go/types.aeR0,s82,Type heads (§5.1): a generic type of one of these names is instantiated with inst.v20,arbace.repr.go.types10,ns-name-ofm10,R6,L1,V1,R19,R0,s106,The namespace of a Go import path (§4.1): go. plus the path, / as ., and . and - inside an\n  element as _.R3,i37,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types9,name-formm10,R6,L1,V1,Myn4,namem2,R20,R21,R0,s150,A Go name written where the reader would read the bare symbol as a literal: true, false\n  and nil are (go/id \"true\") (SPEC §4.4), other names symbols.R3,i44,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types7,qualifym10,R6,L1,V2,R19,R22,R0,s77,The symbol naming name of package path, from the file of the current package.R3,i52,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types9,type-formm8,R23,TR3,i60,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types10,params-vecm10,R24,TR6,L1,V2,R25,R26,R3,i62,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types11,method-elemm10,R24,TR6,L1,V1,m2,R27,V2,R22,R28,R3,i70,R4,i1,R5,s23,arbace/repr/go/types.aem10,R6,L1,V1,R7,R0,s25,The type form of type id.R3,i79,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types8,untyped?m10,R6,L1,V1,R7,R0,s41,Whether type id is an untyped basic type.R3,i122,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types11,basic-kindsm24,s6,stringR29,s7,float32R30,s7,float64R30,s15,untyped complexR31,s12,untyped runeR32,s10,complex128R33,s4,boolR34,s11,untyped intR35,s14,untyped stringR29,s12,untyped boolR34,s13,untyped floatR36,s9,complex64R33,m8,R24,TR3,i128,R4,i1,R5,s23,arbace/repr/go/types.aev20,arbace.repr.go.types10,const-kindm10,R6,L1,V1,R7,R0,s170,The kind of constant values of type id (lit/const-form), or nil when it is not known (a\n  named type of another package, whose underlying type is in that package's dump).R3,i135,R4,i1,R5,s23,arbace/repr/go/types.ae")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.go.types$eval1140000004$loading__1927001464__auto____1140000005")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.types$eval1140000008$fn__1140000009")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.types$entry")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.types$ns_name_of")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.types$name_form")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.types$qualify")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.types$params_vec")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.types$method_elem")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.types$type_form")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.types$untyped_QMARK_")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.types$const_kind")
