//line j2g_classes.ae:1
package aot_arbace_repr_go_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_go_types_const_kind_A_class, Name: "arbace.repr.go.types$const_kind", Modifiers: 25, Simple: "const_kind", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_const_kind_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_entry_A_class, Name: "arbace.repr.go.types$entry", Modifiers: 25, Simple: "entry", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_entry_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_class, Name: "arbace.repr.go.types$eval1140000004$loading__1927001464__auto____1140000005", Modifiers: 25, Simple: "loading__1927001464__auto____1140000005", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_eval1140000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_class, Name: "arbace.repr.go.types$eval1140000008$fn__1140000009", Modifiers: 25, Simple: "fn__1140000009", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_eval1140000008_fn__1140000009_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_eval1140000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_method_elem_A_class, Name: "arbace.repr.go.types$method_elem", Modifiers: 25, Simple: "method_elem", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_method_elem_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_ns_name_of_A_class, Name: "arbace.repr.go.types$ns_name_of", Modifiers: 25, Simple: "ns_name_of", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_ns_name_of_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_class, Name: "arbace.repr.go.types$ns_name_of$fn__1140000014", Modifiers: 25, Simple: "fn__1140000014", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_ns_name_of_fn__1140000014_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_ns_name_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_params_vec_A_class, Name: "arbace.repr.go.types$params_vec", Modifiers: 25, Simple: "params_vec", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_params_vec_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_params_vec_fn__1140000018_A_class, Name: "arbace.repr.go.types$params_vec$fn__1140000018", Modifiers: 25, Simple: "fn__1140000018", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_params_vec_fn__1140000018_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_params_vec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_qualify_A_class, Name: "arbace.repr.go.types$qualify", Modifiers: 25, Simple: "qualify", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_qualify_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_A_class, Name: "arbace.repr.go.types$type_form", Modifiers: 25, Simple: "type_form", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000027__1140000031", Modifiers: 25, Simple: "iter__1140000027__1140000031", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000027__1140000031$fn__1140000032", Modifiers: 25, Simple: "fn__1140000032", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_fn__1140000033_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000027__1140000031$fn__1140000032$fn__1140000033", Modifiers: 25, Simple: "fn__1140000033", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_fn__1140000033_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000037__1140000041", Modifiers: 25, Simple: "iter__1140000037__1140000041", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000037__1140000041$fn__1140000042", Modifiers: 25, Simple: "fn__1140000042", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_fn__1140000043_A_class, Name: "arbace.repr.go.types$type_form$iter__1140000037__1140000041$fn__1140000042$fn__1140000043", Modifiers: 25, Simple: "fn__1140000043", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_fn__1140000043_A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_types_untyped_QMARK__A_class, Name: "arbace.repr.go.types$untyped_QMARK_", Modifiers: 25, Simple: "untyped_QMARK_", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_untyped_QMARK__A", Source: "types.ae", Declaring: &A_arbace_repr_go_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_go_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_types_A_New()}; return nil }

var A_arbace_repr_go_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_types_A_new}

var A_arbace_repr_go_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.types", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_A"})

func init() { i := A_arbace_repr_go_types_A_class.Info(); i.IsInstance = A_arbace_repr_go_types_A_InstanceOf; i.Init = A_arbace_repr_go_types_A_Init; i.Table = A_arbace_repr_go_types_A_members }

var A_arbace_repr_go_types_const_kind_A_class *jrt.Class

var A_arbace_repr_go_types_entry_A_class *jrt.Class

func A_arbace_repr_go_types_eval1140000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_types_eval1140000004_A_New()}; return nil }

var A_arbace_repr_go_types_eval1140000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_types_eval1140000004_A_new}

var A_arbace_repr_go_types_eval1140000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.types$eval1140000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_types_A_class, Simple: "eval1140000004", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_eval1140000004_A"})

func init() { i := A_arbace_repr_go_types_eval1140000004_A_class.Info(); i.IsInstance = A_arbace_repr_go_types_eval1140000004_A_InstanceOf; i.Table = A_arbace_repr_go_types_eval1140000004_A_members }

var A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_class *jrt.Class

func A_arbace_repr_go_types_eval1140000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_types_eval1140000008_A_New()}; return nil }

var A_arbace_repr_go_types_eval1140000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_types_eval1140000008_A_new}

var A_arbace_repr_go_types_eval1140000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.types$eval1140000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_types_A_class, Simple: "eval1140000008", Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types_eval1140000008_A"})

func init() { i := A_arbace_repr_go_types_eval1140000008_A_class.Info(); i.IsInstance = A_arbace_repr_go_types_eval1140000008_A_InstanceOf; i.Table = A_arbace_repr_go_types_eval1140000008_A_members }

var A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_class *jrt.Class

var A_arbace_repr_go_types_method_elem_A_class *jrt.Class

var A_arbace_repr_go_types_ns_name_of_A_class *jrt.Class

var A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_class *jrt.Class

var A_arbace_repr_go_types_params_vec_A_class *jrt.Class

var A_arbace_repr_go_types_params_vec_fn__1140000018_A_class *jrt.Class

var A_arbace_repr_go_types_qualify_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000027__1140000031_fn__1140000032_fn__1140000033_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_A_class *jrt.Class

var A_arbace_repr_go_types_type_form_iter__1140000037__1140000041_fn__1140000042_fn__1140000043_A_class *jrt.Class

var A_arbace_repr_go_types_untyped_QMARK__A_class *jrt.Class

func A_arbace_repr_go_types__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_go_types__init_A_Load__O()}; return nil }

func A_arbace_repr_go_types__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_types__init_A_New()}; return nil }

var A_arbace_repr_go_types__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_go_types__init_A_invoke, New: A_arbace_repr_go_types__init_A_new}

var A_arbace_repr_go_types__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.types__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_types.A_arbace_repr_go_types__init_A", Source: "types.ae"})

func init() { i := A_arbace_repr_go_types__init_A_class.Info(); i.IsInstance = A_arbace_repr_go_types__init_A_InstanceOf; i.Init = A_arbace_repr_go_types__init_A_Init; i.Table = A_arbace_repr_go_types__init_A_members }
