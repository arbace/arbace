//line aot_arbace_repr_go_types.ae:1
package aot_arbace_repr_go_types

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_New() *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_New() *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_eval1140000008_fn__1140000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_repr_go_types_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_repr_go_types_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_types_A_const_5.GetRawRoot__O(), A_arbace_repr_go_types_A_const_6) }





























func A_arbace_repr_go_types_entry_A_New() *A_arbace_repr_go_types_entry_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_entry_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_go_types_entry_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_go_types_entry_A) Invoke_O_O__O(self, id__0 any) any { return lang.RT_Nth_O_I__O_NoInit(A_arbace_repr_go_types_A_const_7.Get__O(), lang.RT_IntCast_O__I_NoInit(id__0)) }





func A_arbace_repr_go_types_ns_name_of_A_New() *A_arbace_repr_go_types_ns_name_of_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_ns_name_of_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_types_ns_name_of_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_types_ns_name_of_A) Invoke_O_O__O(self, path__0 any) any {



	var root_32 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_26 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_repr_go_types_A_const_10.GetRawRoot__O(); var arg_30 any = Lit_1; var arg_31 any; var root_21 any = A_arbace_repr_go_types_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = Lit_2; var arg_25 any; var root_16 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any; var tmp1 any = A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_New(); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; arg_19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *jrt.Class = A_arbace_repr_go_types_A_const_13; var arg_20 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(path__0, tmp3, Lit_4, jrt.RefArrayOf(jrt.Object_class, Lit_5)); if linked_17 == nil { arg_25 = ifn_18.Invoke_O_O__O(arg_19, arg_20) } else { arg_25 = linked_17.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_16, arg_19, arg_20) }; if linked_22 == nil { arg_31 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { arg_31 = linked_22.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; if linked_27 == nil { arg_35 = ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { arg_35 = linked_27.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) }; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_32, arg_35) } }
//line :41:1
func A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_New() *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_ns_name_of_fn__1140000014_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A) Invoke_O_O__O(self, p1__1140000013_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_repr_go_types_A_const_13; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1140000013_SHARP___1, tmp1, Lit_6, jrt.RefArrayOf(jrt.Object_class, Lit_7, Lit_8)) }


func A_arbace_repr_go_types_name_form_A_New() *A_arbace_repr_go_types_name_form_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_name_form_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_types_name_form_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_types_name_form_A) Invoke_O_O__O(self, name__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_types_A_const_14).Invoke_O__O(name__0)) {
		return lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_types_A_const_16, name__0) } else {
			var root_36 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = name__0; if linked_37 == nil { return ifn_38.Invoke_O__O(arg_39) } else { return linked_37.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_36, arg_39)
			} } }
func A_arbace_repr_go_types_qualify_A_New() *A_arbace_repr_go_types_qualify_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_qualify_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_repr_go_types_qualify_A) Ctor() {}
//line :52:1
func (t *A_arbace_repr_go_types_qualify_A) Invoke_O_O_O__O(self, path__0, name__1 any) any {


	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(path__0, nil)
	if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(path__0, A_arbace_repr_go_types_A_const_17.Get__O()) }
//line :55:1
	if tmp1 {
		var root_40 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = name__1; if linked_41 == nil { return ifn_42.Invoke_O__O(arg_43) } else { return linked_41.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_40, arg_43) } } else {
//line :55:1
			var tmp2 any; var root_44 any = A_arbace_repr_go_types_A_const_19.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_46 lang.IFn

			if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_repr_go_types_A_const_20.Get__O(); var arg_48 any = path__0; if linked_45 == nil { tmp2 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { tmp2 = linked_45.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }
//line :55:1
			if jrt.J2g_Truth(tmp2) {

				var root_49 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_20.Get__O(), path__0); var arg_53 any = name__1; if linked_50 == nil { return ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { return linked_50.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) } } else {
//line :55:1
					if A_arbace_repr_go_types_A_const_21 != nil {


						var root_62 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_58 any = A_arbace_repr_go_types_A_const_10.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var or__1927000174__auto____3_2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_22.Get__O(), path__0); if jrt.J2g_Truth(or__1927000174__auto____3_2) { arg_61 = or__1927000174__auto____3_2 } else { var root_54 any = A_arbace_repr_go_types_A_const_23.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_repr_go_types_ns_name_of_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = path__0; if linked_55 == nil { arg_61 = ifn_56.Invoke_O__O(arg_57) } else { arg_61 = linked_55.(*A_arbace_repr_go_types_ns_name_of_A).Invoke_O_O__O(root_54, arg_57) } }; if linked_59 == nil { arg_65 = ifn_60.Invoke_O__O(arg_61) } else { arg_65 = linked_59.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_58, arg_61) }; var arg_66 any = name__1; if linked_63 == nil { return ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { return linked_63.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) } } else {
//line :55:1
							return nil
						}
				}
		}
}


func A_arbace_repr_go_types_params_vec_A_New() *A_arbace_repr_go_types_params_vec_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_params_vec_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_repr_go_types_params_vec_A) Ctor() {}
//line :62:1
func (t *A_arbace_repr_go_types_params_vec_A) Invoke_O_O_O__O(self, vars__0, variadic__1 any) any { var n__3 int32 = lang.RT_Count_O__I_NoInit(vars__0); var root_85 any = A_arbace_repr_go_types_A_const_24.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_87 lang.IFn; if

	linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_types_params_vec_fn__1140000019_A_New_I_O(n__3, variadic__1); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; var root_76 any = A_arbace_repr_go_types_A_const_29.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_78 lang.IFn; if



	linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { tmp5 = ifn_78.Invoke__O() } else { tmp5 = linked_77.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O__O(root_76) }; arg_88 = /*line :64:1*/tmp1.Invoke_O_O_O__O(tmp4, tmp5, vars__0); if linked_86 == nil { return ifn_87.Invoke_O__O(arg_88) } else { return linked_86.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_85, arg_88) } }
//line :64:1
func A_arbace_repr_go_types_params_vec_fn__1140000019_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_types_params_vec_fn__1140000019_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_params_vec_fn__1140000019_A{}; t.Ctor_I_O(p0, p1); return t }
//line :64:1
func (t *A_arbace_repr_go_types_params_vec_fn__1140000019_A) Ctor_I_O(c__n int32, c__variadic any) { t.F_n = c__n; t.F_variadic = c__variadic }
//line :64:1
func (t *A_arbace_repr_go_types_params_vec_fn__1140000019_A) Invoke_O_O_O__O(self, i__1, v__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_repr_go_types_A_const_26; var tmp3 any; var root_67 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_69 lang.IFn
		if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(v__2); if linked_68 == nil { tmp3 = ifn_69.Invoke_O__O(arg_70) } else { tmp3 = linked_68.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_67, arg_70) }
//line :65:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { var tmp4 any; var root_71 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_73 lang.IFn

			if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(v__2); if linked_72 == nil { tmp4 = ifn_73.Invoke_O__O(arg_74) } else { tmp4 = linked_72.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_71, arg_74) }
//line :65:1
			return lang.Tuple_Create_O__IPersistentVector(tmp4)
		}
}


func A_arbace_repr_go_types_method_elem_A_New() *A_arbace_repr_go_types_method_elem_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_method_elem_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_repr_go_types_method_elem_A) Ctor() {}
//line :70:1
func (t *A_arbace_repr_go_types_method_elem_A) Invoke_O_O__O(self, p__1140000022__0 any) any { var map__1140000023__2 any = p__1140000022__0; var map__1140000023__3 any; if lang.ISeq_InstanceOf(map__1140000023__2) { var tmp1 any; var root_89 any = A_arbace_repr_go_types_A_const_30.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = map__1140000023__2; if linked_90 == nil { tmp1 = ifn_91.Invoke_O__O(arg_92) } else { tmp1 = linked_90.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_93 any = A_arbace_repr_go_types_A_const_31.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = map__1140000023__2; if linked_94 == nil { tmp2 = ifn_95.Invoke_O__O(arg_96) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_93, arg_96) }; map__1140000023__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_97 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = map__1140000023__2; if linked_98 == nil { tmp3 = ifn_99.Invoke_O__O(arg_100) } else { tmp3 = linked_98.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp3) { var root_101 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = map__1140000023__2; if linked_102 == nil { map__1140000023__3 = ifn_103.Invoke_O__O(arg_104) } else { map__1140000023__3 = linked_102.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_101, arg_104) } } else { map__1140000023__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1140000023__3 = map__1140000023__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__1140000023__3, A_arbace_repr_go_types_A_const_34); var t__5 any = lang.RT_Get_O_O__O_NoInit(map__1140000023__3, A_arbace_repr_go_types_A_const_28); var sig__6 any; var root_105 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_repr_go_types_entry_A_fn_class); var ifn_107 lang.IFn; if
												linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = t__5; if linked_106 == nil { sig__6 = ifn_107.Invoke_O__O(arg_108) } else { sig__6 = linked_106.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_105, arg_108) }; var ps__7 any; var root_109 any = /*line :70:1*/A_arbace_repr_go_types_A_const_36.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_repr_go_types_params_vec_A_fn_class); var ifn_111 lang.IFn; if

	linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = A_arbace_repr_go_types_A_const_37.Invoke_O__O(sig__6); var arg_113 any = A_arbace_repr_go_types_A_const_38.Invoke_O__O(sig__6); if linked_110 == nil { ps__7 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { ps__7 = linked_110.(*A_arbace_repr_go_types_params_vec_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; var rs__8 any = /*line :70:1*/A_arbace_repr_go_types_A_const_39.Invoke_O__O(sig__6); var tmp4 any; var root_114 any = A_arbace_repr_go_types_A_const_40.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_116 lang.IFn; if




	linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = rs__8; if linked_115 == nil { tmp4 = ifn_116.Invoke_O__O(arg_117) } else { tmp4 = linked_115.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if /*line :74:1*/ jrt.J2g_Truth(tmp4) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp6 any; var root_118 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = name__4; if linked_119 == nil { tmp6 = ifn_120.Invoke_O__O(arg_121) } else { tmp6 = linked_119.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_118, arg_121) }; return tmp5.Invoke_O_O__O(tmp6, ps__7) } else {
//line :74:1
			if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(rs__8))) {

				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp8 any; var root_122 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = name__4; if linked_123 == nil { tmp8 = ifn_124.Invoke_O__O(arg_125) } else { tmp8 = linked_123.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_122, arg_125) }; var tmp9 any = tmp8; var tmp10 any; var root_134 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = ps__7; var arg_138 any; var tmp11 any = A_arbace_repr_go_types_A_const_42; var tmp12 any; var root_130 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var tmp13 *lang.Keyword = A_arbace_repr_go_types_A_const_28; var tmp14 any; var root_126 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = rs__8; if linked_127 == nil { tmp14 = ifn_128.Invoke_O__O(arg_129) } else { tmp14 = linked_127.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_126, arg_129) }; arg_133 = tmp13.Invoke_O__O(tmp14); if linked_131 == nil { tmp12 = ifn_132.Invoke_O__O(arg_133) } else { tmp12 = linked_131.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_130, arg_133) }; arg_138 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12)); if linked_135 == nil { tmp10 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp10 = linked_135.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }; return tmp7.Invoke_O_O__O(tmp9, tmp10) } else {
//line :74:1
					if A_arbace_repr_go_types_A_const_21 != nil {


						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp16 any; var root_139 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = name__4; if linked_140 == nil { tmp16 = ifn_141.Invoke_O__O(arg_142) } else { tmp16 = linked_140.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_139, arg_142) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_repr_go_types_A_const_39; var tmp19 any; var root_148 any = A_arbace_repr_go_types_A_const_43.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_143 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_147 any = A_arbace_repr_go_types_A_const_28; if linked_144 == nil { arg_151 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { arg_151 = linked_144.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; var arg_152 any = rs__8; if linked_149 == nil { tmp19 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { tmp19 = linked_149.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }; return tmp15.Invoke_O_O_O_O__O(tmp17, ps__7, tmp18, tmp19) } else {
//line :74:1
							return nil } } } }




func A_arbace_repr_go_types_type_form_A_New() *A_arbace_repr_go_types_type_form_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_types_type_form_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_types_type_form_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_153 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_repr_go_types_entry_A_fn_class); var ifn_155 lang.IFn; if


	linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = id__0; if linked_154 == nil { e__2 = ifn_155.Invoke_O__O(arg_156) } else { e__2 = linked_154.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_153, arg_156) }; var G__1140000026__3_ any = /*line :79:1*/A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2); switch



	lang.Util_Hash_O__I_NoInit(G__1140000026__3_) >> 14 & 31 { case 0: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_46) {




		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_types_A_const_70; var tmp3 any; var root_249 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_repr_go_types_A_const_71.Invoke_O__O(e__2); if linked_250 == nil { tmp3 = ifn_251.Invoke_O__O(arg_252) } else { tmp3 = linked_250.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_249, arg_252) }; var tmp4 any = tmp3; var tmp5 any; var root_253 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_254 == nil { tmp5 = ifn_255.Invoke_O__O(arg_256) } else { tmp5 = linked_254.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_253, arg_256) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5) }
//line :83:1
	case 3: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_47) { var G__1140000027__4_ any = A_arbace_repr_go_types_A_const_48.Invoke_O__O(e__2)





		switch lang.Util_Hash_O__I_NoInit(G__1140000027__4_) >> 7 & 3 { case 0: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_49) {


			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_73; var tmp8 any = A_arbace_repr_go_types_A_const_49; var tmp9 any; var root_257 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_258 == nil { tmp9 = ifn_259.Invoke_O__O(arg_260) } else { tmp9 = linked_258.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_257, arg_260) }; return tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9) }
//line :89:1
		case 2: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_50) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_types_A_const_74; var tmp12 any; var root_261 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_262 == nil { tmp12 = ifn_263.Invoke_O__O(arg_264) } else { tmp12 = linked_262.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_261, arg_264) }; return tmp10.Invoke_O_O__O(tmp11, tmp12) }
//line :89:1
		case 3: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_51) {

			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_types_A_const_75; var tmp15 any = A_arbace_repr_go_types_A_const_51; var tmp16 any; var root_265 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_266 == nil { tmp16 = ifn_267.Invoke_O__O(arg_268) } else { tmp16 = linked_266.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_265, arg_268) }; return tmp13.Invoke_O_O_O__O(tmp14, tmp15, tmp16) }
//line :89:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1140000027__4_))))) }
//line :83:1
	case 5: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_52) {

		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_types_A_const_76; var tmp19 any; var root_269 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_270 == nil { tmp19 = ifn_271.Invoke_O__O(arg_272) } else { tmp19 = linked_270.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_269, arg_272) }; return tmp17.Invoke_O_O__O(tmp18, tmp19) }
//line :83:1
	case 6: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_53) {
























		var root_234 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_238 any = A_arbace_repr_go_types_A_const_54; var arg_239 any; var iter__1927001039__auto____4 any; var tmp20 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_New(); var tmp21 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class
		if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class = fncls__233d; tmp21 = fncls__233d } else { tmp21 = fncls__233 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); arg_239 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_repr_go_types_A_const_66.Invoke_O__O(e__2))
//line :108:1
		if linked_235 == nil { return ifn_236.Invoke_O_O_O__O(arg_237, arg_238, arg_239) } else { return linked_235.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_234, arg_237, arg_238, arg_239) } }
//line :83:1
	case 7: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_77) {













		var root_392 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_396 any = A_arbace_repr_go_types_A_const_78; var arg_397 any; var iter__1927001039__auto____4_2 any; var tmp22 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_New(); var tmp23 *jrt.Class; var fncls__391 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class
		if fncls__391 == nil { var fncls__391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class = fncls__391d; tmp23 = fncls__391d } else { tmp23 = fncls__391 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); arg_397 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(A_arbace_repr_go_types_A_const_83.Invoke_O__O(e__2))
//line :97:1
		if linked_393 == nil { return ifn_394.Invoke_O_O_O__O(arg_395, arg_396, arg_397) } else { return linked_393.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_392, arg_395, arg_396, arg_397) } }
//line :83:1
	case 8: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_84) {


































		var root_398 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_398, arg_401) } }
//line :83:1
	case 11: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_85) {



		var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_types_A_const_89; var tmp26 any = A_arbace_repr_go_types_A_const_90.Invoke_O__O(e__2); var tmp27 any; var root_411 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_412 == nil { tmp27 = ifn_413.Invoke_O__O(arg_414) } else { tmp27 = linked_412.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_411, arg_414) }; return tmp24.Invoke_O_O_O__O(tmp25, tmp26, tmp27) }
//line :83:1
	case 13: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_86) {
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2)) { var root_402 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_406 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { return linked_403.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } } else { var root_407 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_408 == nil { return ifn_409.Invoke_O__O(arg_410) } else { return linked_408.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_407, arg_410) } } }
//line :83:1
	case 14: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_91) { var ps__4 any; var root_415 any = A_arbace_repr_go_types_A_const_36.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, A_arbace_repr_go_types_params_vec_A_fn_class); var ifn_417 lang.IFn









		if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_repr_go_types_A_const_37.Invoke_O__O(e__2); var arg_419 any = A_arbace_repr_go_types_A_const_38.Invoke_O__O(e__2); if linked_416 == nil { ps__4 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { ps__4 = linked_416.(*A_arbace_repr_go_types_params_vec_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }
		var tmp28 any; var root_420 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_repr_go_types_A_const_39.Invoke_O__O(e__2); if linked_421 == nil { tmp28 = ifn_422.Invoke_O__O(arg_423) } else { tmp28 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(tmp28) {
			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp30 any = A_arbace_repr_go_types_A_const_98; var tmp31 any; var root_450 any = A_arbace_repr_go_types_A_const_43.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_445 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_449 any = A_arbace_repr_go_types_A_const_28; if linked_446 == nil { arg_453 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { arg_453 = linked_446.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; var arg_454 any = A_arbace_repr_go_types_A_const_39.Invoke_O__O(e__2); if linked_451 == nil { tmp31 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { tmp31 = linked_451.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; return tmp29.Invoke_O_O_O__O(tmp30, ps__4, tmp31) } else {
				return lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_types_A_const_99, ps__4) } }
//line :83:1
	case 19: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_92) {





















		var root_439 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_443 any = A_arbace_repr_go_types_A_const_93; var arg_444 any; var root_434 any = A_arbace_repr_go_types_A_const_94.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_436 lang.IFn
		if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_424 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = A_arbace_repr_go_types_A_const_95.GetRawRoot__O(); var arg_428 any = A_arbace_repr_go_types_A_const_96.Invoke_O__O(e__2); if linked_425 == nil { arg_437 = ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { arg_437 = linked_425.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) }; var arg_438 any; var root_429 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_431 lang.IFn
		if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_433 any = A_arbace_repr_go_types_A_const_97.Invoke_O__O(e__2); if linked_430 == nil { arg_438 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { arg_438 = linked_430.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }
//line :106:1
		if linked_435 == nil { arg_444 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { arg_444 = linked_435.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }
//line :105:1
		if linked_440 == nil { return ifn_441.Invoke_O_O_O__O(arg_442, arg_443, arg_444) } else { return linked_440.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_439, arg_442, arg_443, arg_444) } }
//line :83:1
	case 23: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_100) {



































		var root_465 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_469 any = A_arbace_repr_go_types_A_const_101; var arg_470 any; var root_460 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var root_455 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_459 any = A_arbace_repr_go_types_A_const_28; if linked_456 == nil { arg_463 = ifn_457.Invoke_O_O__O(arg_458, arg_459) } else { arg_463 = linked_456.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_455, arg_458, arg_459) }; var arg_464 any = A_arbace_repr_go_types_A_const_102.Invoke_O__O(e__2); if linked_461 == nil { arg_470 = ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { arg_470 = linked_461.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_460, arg_463, arg_464) }; if linked_466 == nil { return ifn_467.Invoke_O_O_O__O(arg_468, arg_469, arg_470) } else { return linked_466.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_465, arg_468, arg_469, arg_470) } }
//line :83:1
	case 25: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_103) { var base__4 any; var root_471 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_473 lang.IFn




























		if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_475 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_472 == nil { base__4 = ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { base__4 = linked_472.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_471, arg_474, arg_475) }
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_104.Invoke_O__O(e__2)) {
			var tmp32 any; var and__1927000168__auto____5 bool; var tmp33 any; var root_476 any = A_arbace_repr_go_types_A_const_105.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = base__4; if linked_477 == nil { tmp33 = ifn_478.Invoke_O__O(arg_479) } else { tmp33 = linked_477.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_476, arg_479) }; and__1927000168__auto____5 = lang.Util_Identical_O_O__Z_NoInit(tmp33, nil); if and__1927000168__auto____5 { tmp32 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_106.GetRawRoot__O()).Invoke_O__O(base__4) } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp32) {
				var root_485 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_489 any = A_arbace_repr_go_types_A_const_107; var arg_490 any = base__4; var arg_491 any; var root_480 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_484 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_481 == nil { arg_491 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { arg_491 = linked_481.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) }; if linked_486 == nil { return ifn_487.Invoke_O_O_O_O__O(arg_488, arg_489, arg_490, arg_491) } else { return linked_486.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_485, arg_488, arg_489, arg_490, arg_491) } } else {
					var root_497 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_501 any = base__4; var arg_502 any; var root_492 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_496 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_493 == nil { arg_502 = ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { arg_502 = linked_493.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_492, arg_495, arg_496) }; if linked_498 == nil { return ifn_499.Invoke_O_O_O__O(arg_500, arg_501, arg_502) } else { return linked_498.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_497, arg_500, arg_501, arg_502) } } } else {
//line :113:1
						return base__4 } }
//line :83:1
	case 28: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_109) {


		var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp35 any = A_arbace_repr_go_types_A_const_111; var tmp36 any; var root_535 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_536 == nil { tmp36 = ifn_537.Invoke_O__O(arg_538) } else { tmp36 = linked_536.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_535, arg_538) }; return tmp34.Invoke_O_O__O(tmp35, tmp36) }
//line :83:1
	case 29: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_110) { var base__4_2 any; var root_503 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_505 lang.IFn




























		if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_507 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_504 == nil { base__4_2 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { base__4_2 = linked_504.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_104.Invoke_O__O(e__2)) {
			var tmp37 any; var and__1927000168__auto____5_2 bool; var tmp38 any; var root_508 any = A_arbace_repr_go_types_A_const_105.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = base__4_2; if linked_509 == nil { tmp38 = ifn_510.Invoke_O__O(arg_511) } else { tmp38 = linked_509.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_508, arg_511) }; and__1927000168__auto____5_2 = lang.Util_Identical_O_O__Z_NoInit(tmp38, nil); if and__1927000168__auto____5_2 { tmp37 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_106.GetRawRoot__O()).Invoke_O__O(base__4_2) } else { tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp37) {
				var root_517 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_521 any = A_arbace_repr_go_types_A_const_107; var arg_522 any = base__4_2; var arg_523 any; var root_512 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_516 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_513 == nil { arg_523 = ifn_514.Invoke_O_O__O(arg_515, arg_516) } else { arg_523 = linked_513.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_512, arg_515, arg_516) }; if linked_518 == nil { return ifn_519.Invoke_O_O_O_O__O(arg_520, arg_521, arg_522, arg_523) } else { return linked_518.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_517, arg_520, arg_521, arg_522, arg_523) } } else {
					var root_529 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_533 any = base__4_2; var arg_534 any; var root_524 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_528 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_525 == nil { arg_534 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { arg_534 = linked_525.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }; if linked_530 == nil { return ifn_531.Invoke_O_O_O__O(arg_532, arg_533, arg_534) } else { return linked_530.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_529, arg_532, arg_533, arg_534) } } } else {
//line :113:1
						return base__4_2 } }
//line :83:1
	default:}; var tmp39 any; var root_244 any = A_arbace_repr_go_types_A_const_67.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_246 lang.IFn; if




































	linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, id__0, nil, lang.IFn_Cast(A_arbace_repr_go_types_A_const_68.GetRawRoot__O()).Invoke_O__O(e__2))).Ref(); var arg_248 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_types_A_const_69, id__0)); if linked_245 == nil { tmp39 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp39 = linked_245.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; /*line :83:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp39))) }














func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_New() *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A) Ctor() {}
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A) Invoke_O_O__O(self, s__1140000039__1 any) any { var tmp1 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_New_O_O(s__1140000039__1, self); var tmp2 *jrt.Class; var fncls__390 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class; if fncls__390 == nil { var fncls__390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class = fncls__390d; tmp2 = fncls__390d } else { tmp2 = fncls__390 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :98:1
func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_New_O_O(p0, p1 any) *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A) Ctor_O_O(c__s__1140000039, c__iter__1140000038 any) { t.F_s__1140000039 = c__s__1140000039; t.F_iter__1140000038 = c__iter__1140000038 }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A) Invoke_O__O(self any) any { { var s__1140000039__1 any; var t_ any = t.F_s__1140000039; t.F_s__1140000039 = nil; s__1140000039__1 = t_; for { var temp__1927000414__auto____2 any; var root_273 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__1140000039__1; if linked_274 == nil { temp__1927000414__auto____2 = ifn_275.Invoke_O__O(arg_276) } else { temp__1927000414__auto____2 = linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1140000039__3 any = temp__1927000414__auto____2; var tmp1 any; var root_277 any = A_arbace_repr_go_types_A_const_55.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = s__1140000039__3; if linked_278 == nil { tmp1 = ifn_279.Invoke_O__O(arg_280) } else { tmp1 = linked_278.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_281 any = A_arbace_repr_go_types_A_const_56.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = s__1140000039__3; if linked_282 == nil { c__1927001037__auto____4 = ifn_283.Invoke_O__O(arg_284) } else { c__1927001037__auto____4 = linked_282.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_281, arg_284) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1140000041__6 any; var root_285 any = A_arbace_repr_go_types_A_const_57.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_286 == nil { b__1140000041__6 = ifn_287.Invoke_O__O(arg_288) } else { b__1140000041__6 = linked_286.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_285, arg_288) }; var tmp2 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_New_O_I_O(b__1140000041__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class = fncls__324d; tmp3 = fncls__324d } else { tmp3 = fncls__324 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_333 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_325 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = b__1140000041__6; if linked_326 == nil { arg_336 = ifn_327.Invoke_O__O(arg_328) } else { arg_336 = linked_326.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_325, arg_328) }; var arg_337 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1140000038); var tmp5 any; var root_329 any = A_arbace_repr_go_types_A_const_63.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = s__1140000039__3; if linked_330 == nil { tmp5 = ifn_331.Invoke_O__O(arg_332) } else { tmp5 = linked_330.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_329, arg_332) }; arg_337 = tmp4.Invoke_O__O(tmp5); if linked_334 == nil { return ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { return linked_334.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } } else { var root_342 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var root_338 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = b__1140000041__6; if linked_339 == nil { arg_345 = ifn_340.Invoke_O__O(arg_341) } else { arg_345 = linked_339.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_338, arg_341) }; var arg_346 any; if linked_343 == nil { return ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { return linked_343.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) } } } else { var f__4 any; var root_347 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = s__1140000039__3; if linked_348 == nil { f__4 = ifn_349.Invoke_O__O(arg_350) } else { f__4 = linked_348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_347, arg_350) }; var root_385 any = A_arbace_repr_go_types_A_const_64.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any
															if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_79.Invoke_O__O(f__4)) { var t__5 any; var root_351 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_353 lang.IFn
																if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__4); if linked_352 == nil { t__5 = ifn_353.Invoke_O__O(arg_354) } else { t__5 = linked_352.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_351, arg_354) }
																if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_80.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var tmp8 any = A_arbace_repr_go_types_A_const_82; arg_388 = tmp6.Invoke_O_O_O_O__O(t__5, tmp7, tmp8, A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) } else { arg_388 = t__5 } } else {
																	var root_376 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var root_362 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(f__4); if linked_363 == nil { arg_379 = ifn_364.Invoke_O__O(arg_365) } else { arg_379 = linked_363.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_362, arg_365) }; var arg_380 any; var G__1140000047__5_ any; var tmp9 any = A_arbace_repr_go_types_A_const_42; var tmp10 any; var root_366 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_368 lang.IFn
																	if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__4); if linked_367 == nil { tmp10 = ifn_368.Invoke_O__O(arg_369) } else { tmp10 = linked_367.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_366, arg_369) }
//line :102:1
			G__1140000047__5_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10))
			if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) {
				var root_370 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = G__1140000047__5_; var arg_374 any = A_arbace_repr_go_types_A_const_82; var arg_375 any = A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4); if linked_371 == nil { arg_380 = ifn_372.Invoke_O_O_O__O(arg_373, arg_374, arg_375) } else { arg_380 = linked_371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_370, arg_373, arg_374, arg_375) } } else {
//line :103:1
					arg_380 = G__1140000047__5_ }
//line :102:1
			if linked_377 == nil { arg_388 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { arg_388 = linked_377.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } }
//line :98:1
	var arg_389 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1140000038); var tmp12 any; var root_381 any = A_arbace_repr_go_types_A_const_65.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = s__1140000039__3; if linked_382 == nil { tmp12 = ifn_383.Invoke_O__O(arg_384) } else { tmp12 = linked_382.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_381, arg_384) }; arg_389 = tmp11.Invoke_O__O(tmp12); if linked_386 == nil { return ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { return linked_386.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_385, arg_388, arg_389) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :98:1
func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A) Ctor_O_I_O(c__b__1140000041 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1140000041 = c__b__1140000041; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A) Invoke_O__O(self any) any { { var i__1140000040__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1140000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1140000040__1)); var root_319 any = A_arbace_repr_go_types_A_const_58.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = t.F_b__1140000041; var arg_323 any
																	if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_79.Invoke_O__O(f__2)) { var t__3 any; var root_289 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_291 lang.IFn
																		if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__2); if linked_290 == nil { t__3 = ifn_291.Invoke_O__O(arg_292) } else { t__3 = linked_290.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_289, arg_292) }
																		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_80.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_types_A_const_82; arg_323 = tmp2.Invoke_O_O_O_O__O(t__3, tmp3, tmp4, A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) } else { arg_323 = t__3 } } else {
																			var root_314 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any; var root_300 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(f__2); if linked_301 == nil { arg_317 = ifn_302.Invoke_O__O(arg_303) } else { arg_317 = linked_301.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_300, arg_303) }; var arg_318 any; var G__1140000045__3_ any; var tmp5 any = A_arbace_repr_go_types_A_const_42; var tmp6 any; var root_304 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_306 lang.IFn
																			if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__2); if linked_305 == nil { tmp6 = ifn_306.Invoke_O__O(arg_307) } else { tmp6 = linked_305.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_304, arg_307) }
//line :102:1
			G__1140000045__3_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6))
			if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) {
				var root_308 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = G__1140000045__3_; var arg_312 any = A_arbace_repr_go_types_A_const_82; var arg_313 any = A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2); if linked_309 == nil { arg_318 = ifn_310.Invoke_O_O_O__O(arg_311, arg_312, arg_313) } else { arg_318 = linked_309.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_308, arg_311, arg_312, arg_313) } } else {
//line :103:1
					arg_318 = G__1140000045__3_ }
//line :102:1
			if linked_315 == nil { arg_323 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { arg_323 = linked_315.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_314, arg_317, arg_318) } }
//line :98:1
	if linked_320 == nil { ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { linked_320.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }; i__1140000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1140000040__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_New() *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A) Invoke_O_O__O(self, s__1140000029__1 any) any { var tmp1 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_New_O_O(s__1140000029__1, self); var tmp2 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class; if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class = fncls__232d; tmp2 = fncls__232d } else { tmp2 = fncls__232 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_New_O_O(p0, p1 any) *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A) Ctor_O_O(c__s__1140000029, c__iter__1140000028 any) { t.F_s__1140000029 = c__s__1140000029; t.F_iter__1140000028 = c__iter__1140000028 }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A) Invoke_O__O(self any) any { { var s__1140000029__1 any; var t_ any = t.F_s__1140000029; t.F_s__1140000029 = nil; s__1140000029__1 = t_; for { var temp__1927000414__auto____2 any; var root_159 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = s__1140000029__1; if linked_160 == nil { temp__1927000414__auto____2 = ifn_161.Invoke_O__O(arg_162) } else { temp__1927000414__auto____2 = linked_160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_159, arg_162) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1140000029__3 any = temp__1927000414__auto____2; var tmp1 any; var root_163 any = A_arbace_repr_go_types_A_const_55.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__1140000029__3; if linked_164 == nil { tmp1 = ifn_165.Invoke_O__O(arg_166) } else { tmp1 = linked_164.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_163, arg_166) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_167 any = A_arbace_repr_go_types_A_const_56.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = s__1140000029__3; if linked_168 == nil { c__1927001037__auto____4 = ifn_169.Invoke_O__O(arg_170) } else { c__1927001037__auto____4 = linked_168.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_167, arg_170) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1140000031__6 any; var root_171 any = A_arbace_repr_go_types_A_const_57.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_172 == nil { b__1140000031__6 = ifn_173.Invoke_O__O(arg_174) } else { b__1140000031__6 = linked_172.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_171, arg_174) }; var tmp2 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_New_O_I_O(b__1140000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__188 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class = fncls__188d; tmp3 = fncls__188d } else { tmp3 = fncls__188 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_197 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var root_189 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = b__1140000031__6; if linked_190 == nil { arg_200 = ifn_191.Invoke_O__O(arg_192) } else { arg_200 = linked_190.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_189, arg_192) }; var arg_201 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1140000028); var tmp5 any; var root_193 any = A_arbace_repr_go_types_A_const_63.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = s__1140000029__3; if linked_194 == nil { tmp5 = ifn_195.Invoke_O__O(arg_196) } else { tmp5 = linked_194.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_193, arg_196) }; arg_201 = tmp4.Invoke_O__O(tmp5); if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } } else { var root_206 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var root_202 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = b__1140000031__6; if linked_203 == nil { arg_209 = ifn_204.Invoke_O__O(arg_205) } else { arg_209 = linked_203.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_202, arg_205) }; var arg_210 any; if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } } } else { var t__4 any; var root_211 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = s__1140000029__3; if linked_212 == nil { t__4 = ifn_213.Invoke_O__O(arg_214) } else { t__4 = linked_212.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_211, arg_214) }; var root_227 any = A_arbace_repr_go_types_A_const_64.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any
															if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_59.Invoke_O__O(t__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_60; var tmp8 any; var root_219 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__4); if linked_220 == nil { tmp8 = ifn_221.Invoke_O__O(arg_222) } else { tmp8 = linked_220.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_219, arg_222) }; arg_230 = tmp6.Invoke_O_O__O(tmp7, tmp8) } else { var root_215 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__4); if linked_216 == nil { arg_230 = ifn_217.Invoke_O__O(arg_218) } else { arg_230 = linked_216.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_215, arg_218) } }
//line :109:1
	var arg_231 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1140000028); var tmp10 any; var root_223 any = A_arbace_repr_go_types_A_const_65.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = s__1140000029__3; if linked_224 == nil { tmp10 = ifn_225.Invoke_O__O(arg_226) } else { tmp10 = linked_224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_223, arg_226) }; arg_231 = tmp9.Invoke_O__O(tmp10); if linked_228 == nil { return ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { return linked_228.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A) Ctor_O_I_O(c__b__1140000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1140000031 = c__b__1140000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A) Invoke_O__O(self any) any { { var i__1140000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1140000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1140000030__1)); var root_183 any = A_arbace_repr_go_types_A_const_58.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = t.F_b__1140000031; var arg_187 any
																	if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_59.Invoke_O__O(t__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_types_A_const_60; var tmp4 any; var root_179 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__2); if linked_180 == nil { tmp4 = ifn_181.Invoke_O__O(arg_182) } else { tmp4 = linked_180.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_179, arg_182) }; arg_187 = tmp2.Invoke_O_O__O(tmp3, tmp4) } else { var root_175 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__2); if linked_176 == nil { arg_187 = ifn_177.Invoke_O__O(arg_178) } else { arg_187 = linked_176.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_175, arg_178) } }
//line :109:1
	if linked_184 == nil { ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { linked_184.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) }; i__1140000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1140000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_repr_go_types_untyped_QMARK__A_New() *A_arbace_repr_go_types_untyped_QMARK__A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_repr_go_types_untyped_QMARK__A) Ctor() {}
//line :122:1
func (t *A_arbace_repr_go_types_untyped_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_539 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_repr_go_types_entry_A_fn_class); var ifn_541 lang.IFn; if


	linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = id__0; if linked_540 == nil { e__2 = ifn_541.Invoke_O__O(arg_542) } else { e__2 = linked_540.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_539, arg_542) }; var tmp1 any = A_arbace_repr_go_types_A_const_86; var and__1927000168__auto____3 bool = /*line :122:1*/lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2)); if and__1927000168__auto____3 {



		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))).StartsWith_String__Z(Lit_19)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }








func A_arbace_repr_go_types_const_kind_A_New() *A_arbace_repr_go_types_const_kind_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_const_kind_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_types_const_kind_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_types_const_kind_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_543 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_repr_go_types_entry_A_fn_class); var ifn_545 lang.IFn; if



	linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = id__0; if linked_544 == nil { e__2 = ifn_545.Invoke_O__O(arg_546) } else { e__2 = linked_544.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_543, arg_546) }; var G__1140000052__3_ any = /*line :135:1*/A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2); switch




	lang.Util_Hash_O__I_NoInit(G__1140000052__3_) >> 4 & 3 { case 1: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_103) {




		var root_548 any = A_arbace_repr_go_types_A_const_112.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_repr_go_types_const_kind_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = A_arbace_repr_go_types_A_const_113.Invoke_O__O(e__2); if linked_549 == nil { return ifn_550.Invoke_O__O(arg_551) } else { return linked_549.(*A_arbace_repr_go_types_const_kind_A).Invoke_O_O__O(root_548, arg_551) } }
//line :140:1
	case 2: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_86) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_types_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_115); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))) { return A_arbace_repr_go_types_A_const_116 } else { return nil } } }
//line :140:1
	case 3: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_110) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_117.Get__O(), id__0)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var u__5 any = temp__1927000414__auto____4; var root_552 any = A_arbace_repr_go_types_A_const_112.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_repr_go_types_const_kind_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = u__5; if linked_553 == nil { return ifn_554.Invoke_O__O(arg_555) } else { return linked_553.(*A_arbace_repr_go_types_const_kind_A).Invoke_O_O__O(root_552, arg_555) } } else { return nil } }
//line :140:1
	default:}; return nil }







type A_arbace_repr_go_types_A struct{ jrt.Object }

var A_arbace_repr_go_types_A_const_pool *jrt.RefArray

var A_arbace_repr_go_types_A_const_0 *lang.Var

var A_arbace_repr_go_types_A_const_1 any

var A_arbace_repr_go_types_A_const_2 *lang.Var

var A_arbace_repr_go_types_A_const_3 *lang.Var

var A_arbace_repr_go_types_A_const_4 *lang.Var

var A_arbace_repr_go_types_A_const_5 *lang.Var

var A_arbace_repr_go_types_A_const_6 any

var A_arbace_repr_go_types_A_const_7 *lang.Var

var A_arbace_repr_go_types_A_const_8 *lang.Var

var A_arbace_repr_go_types_A_const_9 *lang.Var

var A_arbace_repr_go_types_A_const_10 *lang.Var

var A_arbace_repr_go_types_A_const_11 *lang.Var

var A_arbace_repr_go_types_A_const_12 *lang.Var

var A_arbace_repr_go_types_A_const_13 *jrt.Class

var A_arbace_repr_go_types_A_const_14 any

var A_arbace_repr_go_types_A_const_15 *lang.Var

var A_arbace_repr_go_types_A_const_16 any

var A_arbace_repr_go_types_A_const_17 *lang.Var

var A_arbace_repr_go_types_A_const_18 *lang.Var

var A_arbace_repr_go_types_A_const_19 *lang.Var

var A_arbace_repr_go_types_A_const_20 *lang.Var

var A_arbace_repr_go_types_A_const_21 *lang.Keyword

var A_arbace_repr_go_types_A_const_22 *lang.Var

var A_arbace_repr_go_types_A_const_23 *lang.Var

var A_arbace_repr_go_types_A_const_24 *lang.Var

var A_arbace_repr_go_types_A_const_25 *lang.Var

var A_arbace_repr_go_types_A_const_26 any

var A_arbace_repr_go_types_A_const_27 *lang.Var

var A_arbace_repr_go_types_A_const_28 *lang.Keyword

var A_arbace_repr_go_types_A_const_29 *lang.Var

var A_arbace_repr_go_types_A_const_30 *lang.Var

var A_arbace_repr_go_types_A_const_31 *lang.Var

var A_arbace_repr_go_types_A_const_32 *lang.Var

var A_arbace_repr_go_types_A_const_33 *lang.Var

var A_arbace_repr_go_types_A_const_34 *lang.Keyword

var A_arbace_repr_go_types_A_const_35 *lang.Var

var A_arbace_repr_go_types_A_const_36 *lang.Var

var A_arbace_repr_go_types_A_const_37 *lang.Keyword

var A_arbace_repr_go_types_A_const_38 *lang.Keyword

var A_arbace_repr_go_types_A_const_39 *lang.Keyword

var A_arbace_repr_go_types_A_const_40 *lang.Var

var A_arbace_repr_go_types_A_const_41 *lang.Var

var A_arbace_repr_go_types_A_const_42 *lang.Keyword

var A_arbace_repr_go_types_A_const_43 *lang.Var

var A_arbace_repr_go_types_A_const_44 *lang.Var

var A_arbace_repr_go_types_A_const_45 *lang.Keyword

var A_arbace_repr_go_types_A_const_46 *lang.Keyword

var A_arbace_repr_go_types_A_const_47 *lang.Keyword

var A_arbace_repr_go_types_A_const_48 *lang.Keyword

var A_arbace_repr_go_types_A_const_49 *lang.Keyword

var A_arbace_repr_go_types_A_const_50 *lang.Keyword

var A_arbace_repr_go_types_A_const_51 *lang.Keyword

var A_arbace_repr_go_types_A_const_52 *lang.Keyword

var A_arbace_repr_go_types_A_const_53 *lang.Keyword

var A_arbace_repr_go_types_A_const_54 any

var A_arbace_repr_go_types_A_const_55 *lang.Var

var A_arbace_repr_go_types_A_const_56 *lang.Var

var A_arbace_repr_go_types_A_const_57 *lang.Var

var A_arbace_repr_go_types_A_const_58 *lang.Var

var A_arbace_repr_go_types_A_const_59 *lang.Keyword

var A_arbace_repr_go_types_A_const_60 any

var A_arbace_repr_go_types_A_const_61 *lang.Var

var A_arbace_repr_go_types_A_const_62 *lang.Var

var A_arbace_repr_go_types_A_const_63 *lang.Var

var A_arbace_repr_go_types_A_const_64 *lang.Var

var A_arbace_repr_go_types_A_const_65 *lang.Var

var A_arbace_repr_go_types_A_const_66 *lang.Keyword

var A_arbace_repr_go_types_A_const_67 *lang.Var

var A_arbace_repr_go_types_A_const_68 *lang.Var

var A_arbace_repr_go_types_A_const_69 *lang.Keyword

var A_arbace_repr_go_types_A_const_70 any

var A_arbace_repr_go_types_A_const_71 *lang.Keyword

var A_arbace_repr_go_types_A_const_72 *lang.Keyword

var A_arbace_repr_go_types_A_const_73 any

var A_arbace_repr_go_types_A_const_74 any

var A_arbace_repr_go_types_A_const_75 any

var A_arbace_repr_go_types_A_const_76 any

var A_arbace_repr_go_types_A_const_77 *lang.Keyword

var A_arbace_repr_go_types_A_const_78 any

var A_arbace_repr_go_types_A_const_79 *lang.Keyword

var A_arbace_repr_go_types_A_const_80 *lang.Var

var A_arbace_repr_go_types_A_const_81 *lang.Var

var A_arbace_repr_go_types_A_const_82 *lang.Keyword

var A_arbace_repr_go_types_A_const_83 *lang.Keyword

var A_arbace_repr_go_types_A_const_84 *lang.Keyword

var A_arbace_repr_go_types_A_const_85 *lang.Keyword

var A_arbace_repr_go_types_A_const_86 *lang.Keyword

var A_arbace_repr_go_types_A_const_87 *lang.Keyword

var A_arbace_repr_go_types_A_const_88 *lang.Var

var A_arbace_repr_go_types_A_const_89 any

var A_arbace_repr_go_types_A_const_90 *lang.Keyword

var A_arbace_repr_go_types_A_const_91 *lang.Keyword

var A_arbace_repr_go_types_A_const_92 *lang.Keyword

var A_arbace_repr_go_types_A_const_93 any

var A_arbace_repr_go_types_A_const_94 *lang.Var

var A_arbace_repr_go_types_A_const_95 *lang.Var

var A_arbace_repr_go_types_A_const_96 *lang.Keyword

var A_arbace_repr_go_types_A_const_97 *lang.Keyword

var A_arbace_repr_go_types_A_const_98 any

var A_arbace_repr_go_types_A_const_99 any

var A_arbace_repr_go_types_A_const_100 *lang.Keyword

var A_arbace_repr_go_types_A_const_101 any

var A_arbace_repr_go_types_A_const_102 *lang.Keyword

var A_arbace_repr_go_types_A_const_103 *lang.Keyword

var A_arbace_repr_go_types_A_const_104 *lang.Keyword

var A_arbace_repr_go_types_A_const_105 *lang.Var

var A_arbace_repr_go_types_A_const_106 *lang.Var

var A_arbace_repr_go_types_A_const_107 any

var A_arbace_repr_go_types_A_const_108 *lang.Keyword

var A_arbace_repr_go_types_A_const_109 *lang.Keyword

var A_arbace_repr_go_types_A_const_110 *lang.Keyword

var A_arbace_repr_go_types_A_const_111 any

var A_arbace_repr_go_types_A_const_112 *lang.Var

var A_arbace_repr_go_types_A_const_113 *lang.Keyword

var A_arbace_repr_go_types_A_const_114 *lang.Var

var A_arbace_repr_go_types_A_const_115 any

var A_arbace_repr_go_types_A_const_116 *lang.Keyword

var A_arbace_repr_go_types_A_const_117 *lang.Var

var A_arbace_repr_go_types_A_init jrt.ClassInit

func A_arbace_repr_go_types_A_Init() { if !A_arbace_repr_go_types_A_init.Done() { A_arbace_repr_go_types_A_init.Run(A_arbace_repr_go_types_A_clinit) } }

func A_arbace_repr_go_types_A_clinit() { A_arbace_repr_go_types_A_clinit_p0(); A_arbace_repr_go_types_A_clinit_p1(); A_arbace_repr_go_types_A_clinit_p2(); A_arbace_repr_go_types_A_clinit_p3(); A_arbace_repr_go_types_A_clinit_p4(); A_arbace_repr_go_types_A_clinit_p5(); A_arbace_repr_go_types_A_clinit_p6(); A_arbace_repr_go_types_A_clinit_p7(); A_arbace_repr_go_types_A_clinit_p8(); A_arbace_repr_go_types_A_clinit_p9() }

func A_arbace_repr_go_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 177); A_arbace_repr_go_types_A_const_0 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[59]); A_arbace_repr_go_types_A_const_1 = A_arbace_repr_go_types_A_const_pool.A[60]; A_arbace_repr_go_types_A_const_2 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[61]); A_arbace_repr_go_types_A_const_3 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[62]); A_arbace_repr_go_types_A_const_4 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[63]); A_arbace_repr_go_types_A_const_5 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[64]); A_arbace_repr_go_types_A_const_6 = A_arbace_repr_go_types_A_const_pool.A[65]; A_arbace_repr_go_types_A_const_7 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[66]); A_arbace_repr_go_types_A_const_8 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[67]); A_arbace_repr_go_types_A_const_9 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[68]); A_arbace_repr_go_types_A_const_10 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[69]) }

func A_arbace_repr_go_types_A_clinit_p1() { A_arbace_repr_go_types_A_const_11 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[70]); A_arbace_repr_go_types_A_const_12 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[71]); A_arbace_repr_go_types_A_const_13 = jrt.Class_Cast(A_arbace_repr_go_types_A_const_pool.A[72]); A_arbace_repr_go_types_A_const_14 = A_arbace_repr_go_types_A_const_pool.A[73]; A_arbace_repr_go_types_A_const_15 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[74]); A_arbace_repr_go_types_A_const_16 = A_arbace_repr_go_types_A_const_pool.A[75]; A_arbace_repr_go_types_A_const_17 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[76]); A_arbace_repr_go_types_A_const_18 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[77]); A_arbace_repr_go_types_A_const_19 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[78]); A_arbace_repr_go_types_A_const_20 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[79]); A_arbace_repr_go_types_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[80]); A_arbace_repr_go_types_A_const_22 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[81]) }

func A_arbace_repr_go_types_A_clinit_p2() { A_arbace_repr_go_types_A_const_23 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[82]); A_arbace_repr_go_types_A_const_24 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[83]); A_arbace_repr_go_types_A_const_25 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[84]); A_arbace_repr_go_types_A_const_26 = A_arbace_repr_go_types_A_const_pool.A[85]; A_arbace_repr_go_types_A_const_27 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[86]); A_arbace_repr_go_types_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[87]); A_arbace_repr_go_types_A_const_29 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[88]); A_arbace_repr_go_types_A_const_30 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[89]); A_arbace_repr_go_types_A_const_31 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[90]); A_arbace_repr_go_types_A_const_32 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[91]); A_arbace_repr_go_types_A_const_33 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[92]); A_arbace_repr_go_types_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[93]) }

func A_arbace_repr_go_types_A_clinit_p3() { A_arbace_repr_go_types_A_const_35 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[94]); A_arbace_repr_go_types_A_const_36 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[95]); A_arbace_repr_go_types_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[96]); A_arbace_repr_go_types_A_const_38 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[97]); A_arbace_repr_go_types_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[98]); A_arbace_repr_go_types_A_const_40 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[99]); A_arbace_repr_go_types_A_const_41 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[100]); A_arbace_repr_go_types_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[101]); A_arbace_repr_go_types_A_const_43 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[102]); A_arbace_repr_go_types_A_const_44 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[103]); A_arbace_repr_go_types_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[104]); A_arbace_repr_go_types_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[105]) }

func A_arbace_repr_go_types_A_clinit_p4() { A_arbace_repr_go_types_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[106]); A_arbace_repr_go_types_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[107]); A_arbace_repr_go_types_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[108]); A_arbace_repr_go_types_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[109]); A_arbace_repr_go_types_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[110]); A_arbace_repr_go_types_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[111]); A_arbace_repr_go_types_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[112]); A_arbace_repr_go_types_A_const_54 = A_arbace_repr_go_types_A_const_pool.A[113]; A_arbace_repr_go_types_A_const_55 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[114]); A_arbace_repr_go_types_A_const_56 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[115]); A_arbace_repr_go_types_A_const_57 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[116]); A_arbace_repr_go_types_A_const_58 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[117]) }

func A_arbace_repr_go_types_A_clinit_p5() { A_arbace_repr_go_types_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[118]); A_arbace_repr_go_types_A_const_60 = A_arbace_repr_go_types_A_const_pool.A[119]; A_arbace_repr_go_types_A_const_61 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[120]); A_arbace_repr_go_types_A_const_62 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[121]); A_arbace_repr_go_types_A_const_63 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[122]); A_arbace_repr_go_types_A_const_64 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[123]); A_arbace_repr_go_types_A_const_65 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[124]); A_arbace_repr_go_types_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[125]); A_arbace_repr_go_types_A_const_67 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[126]); A_arbace_repr_go_types_A_const_68 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[127]); A_arbace_repr_go_types_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[128]); A_arbace_repr_go_types_A_const_70 = A_arbace_repr_go_types_A_const_pool.A[129] }

func A_arbace_repr_go_types_A_clinit_p6() { A_arbace_repr_go_types_A_const_71 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[130]); A_arbace_repr_go_types_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[131]); A_arbace_repr_go_types_A_const_73 = A_arbace_repr_go_types_A_const_pool.A[132]; A_arbace_repr_go_types_A_const_74 = A_arbace_repr_go_types_A_const_pool.A[133]; A_arbace_repr_go_types_A_const_75 = A_arbace_repr_go_types_A_const_pool.A[134]; A_arbace_repr_go_types_A_const_76 = A_arbace_repr_go_types_A_const_pool.A[135]; A_arbace_repr_go_types_A_const_77 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[136]); A_arbace_repr_go_types_A_const_78 = A_arbace_repr_go_types_A_const_pool.A[137]; A_arbace_repr_go_types_A_const_79 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[138]); A_arbace_repr_go_types_A_const_80 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[139]); A_arbace_repr_go_types_A_const_81 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[140]); A_arbace_repr_go_types_A_const_82 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[141]); A_arbace_repr_go_types_A_const_83 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[142]) }

func A_arbace_repr_go_types_A_clinit_p7() { A_arbace_repr_go_types_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[143]); A_arbace_repr_go_types_A_const_85 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[144]); A_arbace_repr_go_types_A_const_86 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[145]); A_arbace_repr_go_types_A_const_87 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[146]); A_arbace_repr_go_types_A_const_88 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[147]); A_arbace_repr_go_types_A_const_89 = A_arbace_repr_go_types_A_const_pool.A[148]; A_arbace_repr_go_types_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[149]); A_arbace_repr_go_types_A_const_91 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[150]); A_arbace_repr_go_types_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[151]); A_arbace_repr_go_types_A_const_93 = A_arbace_repr_go_types_A_const_pool.A[152]; A_arbace_repr_go_types_A_const_94 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[153]); A_arbace_repr_go_types_A_const_95 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[154]) }

func A_arbace_repr_go_types_A_clinit_p8() { A_arbace_repr_go_types_A_const_96 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[155]); A_arbace_repr_go_types_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[156]); A_arbace_repr_go_types_A_const_98 = A_arbace_repr_go_types_A_const_pool.A[157]; A_arbace_repr_go_types_A_const_99 = A_arbace_repr_go_types_A_const_pool.A[158]; A_arbace_repr_go_types_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[159]); A_arbace_repr_go_types_A_const_101 = A_arbace_repr_go_types_A_const_pool.A[160]; A_arbace_repr_go_types_A_const_102 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[161]); A_arbace_repr_go_types_A_const_103 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[162]); A_arbace_repr_go_types_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[163]); A_arbace_repr_go_types_A_const_105 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[164]); A_arbace_repr_go_types_A_const_106 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[165]); A_arbace_repr_go_types_A_const_107 = A_arbace_repr_go_types_A_const_pool.A[166]; A_arbace_repr_go_types_A_const_108 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[167]) }

func A_arbace_repr_go_types_A_clinit_p9() { A_arbace_repr_go_types_A_const_109 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[168]); A_arbace_repr_go_types_A_const_110 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[169]); A_arbace_repr_go_types_A_const_111 = A_arbace_repr_go_types_A_const_pool.A[170]; A_arbace_repr_go_types_A_const_112 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[171]); A_arbace_repr_go_types_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[172]); A_arbace_repr_go_types_A_const_114 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[173]); A_arbace_repr_go_types_A_const_115 = A_arbace_repr_go_types_A_const_pool.A[174]; A_arbace_repr_go_types_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[175]); A_arbace_repr_go_types_A_const_117 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[176]) }

func A_arbace_repr_go_types_A_New() *A_arbace_repr_go_types_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_A) Ctor() {}

func (t *A_arbace_repr_go_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_A_class }

func (t *A_arbace_repr_go_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_A); return ok }

func A_arbace_repr_go_types_A_Cast(x any) *A_arbace_repr_go_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_A_class)) }; return v }



type A_arbace_repr_go_types_const_kind_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_const_kind_A_fn_class *jrt.Class



type A_arbace_repr_go_types_entry_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_entry_A_fn_class *jrt.Class



type A_arbace_repr_go_types_eval1140000004_A struct{ jrt.Object }

func A_arbace_repr_go_types_eval1140000004_A_New() *A_arbace_repr_go_types_eval1140000004_A { t := &A_arbace_repr_go_types_eval1140000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_eval1140000004_A) Ctor() {}

func (t *A_arbace_repr_go_types_eval1140000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_eval1140000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_eval1140000004_A_class }

func (t *A_arbace_repr_go_types_eval1140000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_eval1140000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_eval1140000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_eval1140000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_eval1140000004_A); return ok }

func A_arbace_repr_go_types_eval1140000004_A_Cast(x any) *A_arbace_repr_go_types_eval1140000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_eval1140000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_eval1140000004_A_class)) }; return v }



type A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_fn_class *jrt.Class



type A_arbace_repr_go_types_eval1140000008_A struct{ jrt.Object }

func A_arbace_repr_go_types_eval1140000008_A_New() *A_arbace_repr_go_types_eval1140000008_A { t := &A_arbace_repr_go_types_eval1140000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_eval1140000008_A) Ctor() {}

func (t *A_arbace_repr_go_types_eval1140000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_eval1140000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_eval1140000008_A_class }

func (t *A_arbace_repr_go_types_eval1140000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_eval1140000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_eval1140000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_eval1140000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_eval1140000008_A); return ok }

func A_arbace_repr_go_types_eval1140000008_A_Cast(x any) *A_arbace_repr_go_types_eval1140000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_eval1140000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_eval1140000008_A_class)) }; return v }



type A_arbace_repr_go_types_eval1140000008_fn__1140000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_fn_class *jrt.Class



type A_arbace_repr_go_types_method_elem_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_method_elem_A_fn_class *jrt.Class



type A_arbace_repr_go_types_name_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_name_form_A_fn_class *jrt.Class



type A_arbace_repr_go_types_ns_name_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_ns_name_of_A_fn_class *jrt.Class



type A_arbace_repr_go_types_ns_name_of_fn__1140000014_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class *jrt.Class



type A_arbace_repr_go_types_params_vec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_params_vec_A_fn_class *jrt.Class



type A_arbace_repr_go_types_params_vec_fn__1140000019_A struct{ j2g_header uint64; F_n int32; F_variadic any }

var A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class *jrt.Class



type A_arbace_repr_go_types_qualify_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_qualify_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A struct{ j2g_header uint64; F_s__1140000029, F_iter__1140000028 any }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A struct{ j2g_header uint64; F_b__1140000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A struct{ j2g_header uint64; F_s__1140000039, F_iter__1140000038 any }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A struct{ j2g_header uint64; F_b__1140000041 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class *jrt.Class



type A_arbace_repr_go_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_untyped_QMARK__A_fn_class *jrt.Class
