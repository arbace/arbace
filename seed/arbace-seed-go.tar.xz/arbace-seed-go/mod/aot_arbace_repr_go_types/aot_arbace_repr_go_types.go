//line aot_arbace_repr_go_types.ae:1
package aot_arbace_repr_go_types

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_New() *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_New() *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_eval1140000008_fn__1140000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_types_eval1140000008_fn__1140000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_repr_go_types_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_repr_go_types_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_types_A_const_5.GetRawRoot__O(), A_arbace_repr_go_types_A_const_6) }





























func A_arbace_repr_go_types_entry_A_New() *A_arbace_repr_go_types_entry_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_entry_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_go_types_entry_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_go_types_entry_A) Invoke_O_O__O(self, id__0 any) any { return lang.RT_Nth_O_I__O_NoInit(A_arbace_repr_go_types_A_const_7.Get__O(), lang.RT_IntCast_O__I_NoInit(id__0)) }





func A_arbace_repr_go_types_ns_name_of_A_New() *A_arbace_repr_go_types_ns_name_of_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_ns_name_of_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_types_ns_name_of_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_types_ns_name_of_A) Invoke_O_O__O(self, path__0 any) any {



	var root_15 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_repr_go_types_A_const_10.GetRawRoot__O(); var arg_23 any = Lit_1; var arg_24 any; var root_25 any = A_arbace_repr_go_types_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = Lit_2; var arg_29 any; var root_30 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var tmp1 any = A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_New(); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; arg_33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *jrt.Class = A_arbace_repr_go_types_A_const_13; var arg_34 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(path__0, tmp3, Lit_4, jrt.RefArrayOf(jrt.Object_class, Lit_5)); if linked_31 == nil { arg_29 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { arg_29 = linked_31.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_20 == nil { arg_18 = ifn_21.Invoke_O_O_O__O(arg_22, arg_23, arg_24) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_19, arg_22, arg_23, arg_24) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_15, arg_18) } }
//line :41:1
func A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_New() *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_ns_name_of_fn__1140000014_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_types_ns_name_of_fn__1140000014_A) Invoke_O_O__O(self, p1__1140000013_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_repr_go_types_A_const_13; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1140000013_SHARP___1, tmp1, Lit_6, jrt.RefArrayOf(jrt.Object_class, Lit_7, Lit_8)) }


func A_arbace_repr_go_types_name_form_A_New() *A_arbace_repr_go_types_name_form_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_name_form_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_repr_go_types_name_form_A) Ctor() {}
//line :44:1
func (t *A_arbace_repr_go_types_name_form_A) Invoke_O_O__O(self, name__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_types_A_const_14).Invoke_O__O(name__0)) {
		return lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_types_A_const_16, name__0) } else {
			var root_36 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = name__0; if linked_37 == nil { return ifn_38.Invoke_O__O(arg_39) } else { return linked_37.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_36, arg_39)
			} } }
func A_arbace_repr_go_types_qualify_A_New() *A_arbace_repr_go_types_qualify_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_qualify_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_repr_go_types_qualify_A) Ctor() {}
//line :52:1
func (t *A_arbace_repr_go_types_qualify_A) Invoke_O_O_O__O(self, path__0, name__1 any) any {


	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(path__0, nil)
	if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(path__0, A_arbace_repr_go_types_A_const_17.Get__O()) }
//line :55:1
	if tmp1 {
		var root_40 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = name__1; if linked_41 == nil { return ifn_42.Invoke_O__O(arg_43) } else { return linked_41.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_40, arg_43) } } else {
//line :55:1
			var tmp2 any; var root_44 any = A_arbace_repr_go_types_A_const_19.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_46 lang.IFn

			if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_repr_go_types_A_const_20.Get__O(); var arg_48 any = path__0; if linked_45 == nil { tmp2 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { tmp2 = linked_45.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }
//line :55:1
			if jrt.J2g_Truth(tmp2) {

				var root_49 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_20.Get__O(), path__0); var arg_53 any = name__1; if linked_50 == nil { return ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { return linked_50.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) } } else {
//line :55:1
					if A_arbace_repr_go_types_A_const_21 != nil {


						var root_54 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_59 any = A_arbace_repr_go_types_A_const_10.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var or__1927000174__auto____3_2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_22.Get__O(), path__0); if jrt.J2g_Truth(or__1927000174__auto____3_2) { arg_62 = or__1927000174__auto____3_2 } else { var root_63 any = A_arbace_repr_go_types_A_const_23.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, A_arbace_repr_go_types_ns_name_of_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = path__0; if linked_64 == nil { arg_62 = ifn_65.Invoke_O__O(arg_66) } else { arg_62 = linked_64.(*A_arbace_repr_go_types_ns_name_of_A).Invoke_O_O__O(root_63, arg_66) } }; if linked_60 == nil { arg_57 = ifn_61.Invoke_O__O(arg_62) } else { arg_57 = linked_60.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_59, arg_62) }; var arg_58 any = name__1; if linked_55 == nil { return ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { return linked_55.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) } } else {
//line :55:1
							return nil
						}
				}
		}
}


func A_arbace_repr_go_types_params_vec_A_New() *A_arbace_repr_go_types_params_vec_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_params_vec_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_repr_go_types_params_vec_A) Ctor() {}
//line :62:1
func (t *A_arbace_repr_go_types_params_vec_A) Invoke_O_O_O__O(self, vars__0, variadic__1 any) any { var n__3 int32 = lang.RT_Count_O__I_NoInit(vars__0); var root_67 any = A_arbace_repr_go_types_A_const_24.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_69 lang.IFn; if

	linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_25.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_types_params_vec_fn__1140000019_A_New_I_O(n__3, variadic__1); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; var root_86 any = A_arbace_repr_go_types_A_const_29.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_88 lang.IFn; if



	linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; if linked_87 == nil { tmp5 = ifn_88.Invoke__O() } else { tmp5 = linked_87.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O__O(root_86) }; arg_70 = /*line :64:1*/tmp1.Invoke_O_O_O__O(tmp4, tmp5, vars__0); if linked_68 == nil { return ifn_69.Invoke_O__O(arg_70) } else { return linked_68.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_67, arg_70) } }
//line :64:1
func A_arbace_repr_go_types_params_vec_fn__1140000019_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_types_params_vec_fn__1140000019_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_params_vec_fn__1140000019_A{}; t.Ctor_I_O(p0, p1); return t }
//line :64:1
func (t *A_arbace_repr_go_types_params_vec_fn__1140000019_A) Ctor_I_O(c__n int32, c__variadic any) { t.F_n = c__n; t.F_variadic = c__variadic }
//line :64:1
func (t *A_arbace_repr_go_types_params_vec_fn__1140000019_A) Invoke_O_O_O__O(self, i__1, v__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_repr_go_types_A_const_26; var tmp3 any; var root_77 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_79 lang.IFn
		if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(v__2); if linked_78 == nil { tmp3 = ifn_79.Invoke_O__O(arg_80) } else { tmp3 = linked_78.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_77, arg_80) }
//line :65:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { var tmp4 any; var root_81 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_83 lang.IFn

			if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(v__2); if linked_82 == nil { tmp4 = ifn_83.Invoke_O__O(arg_84) } else { tmp4 = linked_82.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_81, arg_84) }
//line :65:1
			return lang.Tuple_Create_O__IPersistentVector(tmp4)
		}
}


func A_arbace_repr_go_types_method_elem_A_New() *A_arbace_repr_go_types_method_elem_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_method_elem_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_repr_go_types_method_elem_A) Ctor() {}
//line :70:1
func (t *A_arbace_repr_go_types_method_elem_A) Invoke_O_O__O(self, p__1140000022__0 any) any { var map__1140000023__2 any = p__1140000022__0; var map__1140000023__3 any; if lang.ISeq_InstanceOf(map__1140000023__2) { var tmp1 any; var root_89 any = A_arbace_repr_go_types_A_const_30.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = map__1140000023__2; if linked_90 == nil { tmp1 = ifn_91.Invoke_O__O(arg_92) } else { tmp1 = linked_90.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_93 any = A_arbace_repr_go_types_A_const_31.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = map__1140000023__2; if linked_94 == nil { tmp2 = ifn_95.Invoke_O__O(arg_96) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_93, arg_96) }; map__1140000023__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_97 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = map__1140000023__2; if linked_98 == nil { tmp3 = ifn_99.Invoke_O__O(arg_100) } else { tmp3 = linked_98.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp3) { var root_101 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = map__1140000023__2; if linked_102 == nil { map__1140000023__3 = ifn_103.Invoke_O__O(arg_104) } else { map__1140000023__3 = linked_102.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_101, arg_104) } } else { map__1140000023__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1140000023__3 = map__1140000023__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__1140000023__3, A_arbace_repr_go_types_A_const_34); var t__5 any = lang.RT_Get_O_O__O_NoInit(map__1140000023__3, A_arbace_repr_go_types_A_const_28); var sig__6 any; var root_105 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_repr_go_types_entry_A_fn_class); var ifn_107 lang.IFn; if
												linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = t__5; if linked_106 == nil { sig__6 = ifn_107.Invoke_O__O(arg_108) } else { sig__6 = linked_106.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_105, arg_108) }; var ps__7 any; var root_109 any = /*line :70:1*/A_arbace_repr_go_types_A_const_36.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_repr_go_types_params_vec_A_fn_class); var ifn_111 lang.IFn; if

	linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = A_arbace_repr_go_types_A_const_37.Invoke_O__O(sig__6); var arg_113 any = A_arbace_repr_go_types_A_const_38.Invoke_O__O(sig__6); if linked_110 == nil { ps__7 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { ps__7 = linked_110.(*A_arbace_repr_go_types_params_vec_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; var rs__8 any = /*line :70:1*/A_arbace_repr_go_types_A_const_39.Invoke_O__O(sig__6); var tmp4 any; var root_114 any = A_arbace_repr_go_types_A_const_40.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_116 lang.IFn; if




	linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = rs__8; if linked_115 == nil { tmp4 = ifn_116.Invoke_O__O(arg_117) } else { tmp4 = linked_115.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if /*line :74:1*/ jrt.J2g_Truth(tmp4) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp6 any; var root_118 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = name__4; if linked_119 == nil { tmp6 = ifn_120.Invoke_O__O(arg_121) } else { tmp6 = linked_119.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_118, arg_121) }; return tmp5.Invoke_O_O__O(tmp6, ps__7) } else {
//line :74:1
			if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(rs__8))) {

				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp8 any; var root_122 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = name__4; if linked_123 == nil { tmp8 = ifn_124.Invoke_O__O(arg_125) } else { tmp8 = linked_123.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_122, arg_125) }; var tmp9 any = tmp8; var tmp10 any; var root_126 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = ps__7; var arg_130 any; var tmp11 any = A_arbace_repr_go_types_A_const_42; var tmp12 any; var root_131 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var tmp13 *lang.Keyword = A_arbace_repr_go_types_A_const_28; var tmp14 any; var root_135 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = rs__8; if linked_136 == nil { tmp14 = ifn_137.Invoke_O__O(arg_138) } else { tmp14 = linked_136.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_135, arg_138) }; arg_134 = tmp13.Invoke_O__O(tmp14); if linked_132 == nil { tmp12 = ifn_133.Invoke_O__O(arg_134) } else { tmp12 = linked_132.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_131, arg_134) }; arg_130 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12)); if linked_127 == nil { tmp10 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { tmp10 = linked_127.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_126, arg_129, arg_130) }; return tmp7.Invoke_O_O__O(tmp9, tmp10) } else {
//line :74:1
					if A_arbace_repr_go_types_A_const_21 != nil {


						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp16 any; var root_139 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = name__4; if linked_140 == nil { tmp16 = ifn_141.Invoke_O__O(arg_142) } else { tmp16 = linked_140.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_139, arg_142) }; var tmp17 any = tmp16; var tmp18 any = A_arbace_repr_go_types_A_const_39; var tmp19 any; var root_143 any = A_arbace_repr_go_types_A_const_43.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any; var root_148 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_152 any = A_arbace_repr_go_types_A_const_28; if linked_149 == nil { arg_146 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { arg_146 = linked_149.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }; var arg_147 any = rs__8; if linked_144 == nil { tmp19 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp19 = linked_144.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; return tmp15.Invoke_O_O_O_O__O(tmp17, ps__7, tmp18, tmp19) } else {
//line :74:1
							return nil } } } }




func A_arbace_repr_go_types_type_form_A_New() *A_arbace_repr_go_types_type_form_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_types_type_form_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_types_type_form_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_153 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_repr_go_types_entry_A_fn_class); var ifn_155 lang.IFn; if


	linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = id__0; if linked_154 == nil { e__2 = ifn_155.Invoke_O__O(arg_156) } else { e__2 = linked_154.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_153, arg_156) }; var G__1140000026__3_ any = /*line :79:1*/A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2); switch



	lang.Util_Hash_O__I_NoInit(G__1140000026__3_) >> 14 & 31 { case 0: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_46) {




		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_types_A_const_70; var tmp3 any; var root_249 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_repr_go_types_A_const_71.Invoke_O__O(e__2); if linked_250 == nil { tmp3 = ifn_251.Invoke_O__O(arg_252) } else { tmp3 = linked_250.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_249, arg_252) }; var tmp4 any = tmp3; var tmp5 any; var root_253 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_254 == nil { tmp5 = ifn_255.Invoke_O__O(arg_256) } else { tmp5 = linked_254.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_253, arg_256) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5) }
//line :83:1
	case 3: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_47) { var G__1140000027__4_ any = A_arbace_repr_go_types_A_const_48.Invoke_O__O(e__2)





		switch lang.Util_Hash_O__I_NoInit(G__1140000027__4_) >> 7 & 3 { case 0: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_49) {


			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_73; var tmp8 any = A_arbace_repr_go_types_A_const_49; var tmp9 any; var root_257 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_258 == nil { tmp9 = ifn_259.Invoke_O__O(arg_260) } else { tmp9 = linked_258.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_257, arg_260) }; return tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9) }
//line :89:1
		case 2: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_50) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_types_A_const_74; var tmp12 any; var root_261 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_262 == nil { tmp12 = ifn_263.Invoke_O__O(arg_264) } else { tmp12 = linked_262.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_261, arg_264) }; return tmp10.Invoke_O_O__O(tmp11, tmp12) }
//line :89:1
		case 3: if any(G__1140000027__4_) == any(A_arbace_repr_go_types_A_const_51) {

			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_types_A_const_75; var tmp15 any = A_arbace_repr_go_types_A_const_51; var tmp16 any; var root_265 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_266 == nil { tmp16 = ifn_267.Invoke_O__O(arg_268) } else { tmp16 = linked_266.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_265, arg_268) }; return tmp13.Invoke_O_O_O__O(tmp14, tmp15, tmp16) }
//line :89:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1140000027__4_))))) }
//line :83:1
	case 5: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_52) {

		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_types_A_const_76; var tmp19 any; var root_269 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_270 == nil { tmp19 = ifn_271.Invoke_O__O(arg_272) } else { tmp19 = linked_270.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_269, arg_272) }; return tmp17.Invoke_O_O__O(tmp18, tmp19) }
//line :83:1
	case 6: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_53) {
























		var root_159 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_163 any = A_arbace_repr_go_types_A_const_54; var arg_164 any; var iter__1927001039__auto____4 any; var tmp20 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_New(); var tmp21 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class
		if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class = fncls__239d; tmp21 = fncls__239d } else { tmp21 = fncls__239 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); arg_164 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_repr_go_types_A_const_66.Invoke_O__O(e__2))
//line :108:1
		if linked_160 == nil { return ifn_161.Invoke_O_O_O__O(arg_162, arg_163, arg_164) } else { return linked_160.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_159, arg_162, arg_163, arg_164) } }
//line :83:1
	case 7: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_77) {













		var root_273 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_277 any = A_arbace_repr_go_types_A_const_78; var arg_278 any; var iter__1927001039__auto____4_2 any; var tmp22 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_New(); var tmp23 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class
		if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class = fncls__397d; tmp23 = fncls__397d } else { tmp23 = fncls__397 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); arg_278 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(A_arbace_repr_go_types_A_const_83.Invoke_O__O(e__2))
//line :97:1
		if linked_274 == nil { return ifn_275.Invoke_O_O_O__O(arg_276, arg_277, arg_278) } else { return linked_274.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_273, arg_276, arg_277, arg_278) } }
//line :83:1
	case 8: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_84) {


































		var root_398 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_398, arg_401) } }
//line :83:1
	case 11: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_85) {



		var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_types_A_const_89; var tmp26 any = A_arbace_repr_go_types_A_const_90.Invoke_O__O(e__2); var tmp27 any; var root_411 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_412 == nil { tmp27 = ifn_413.Invoke_O__O(arg_414) } else { tmp27 = linked_412.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_411, arg_414) }; return tmp24.Invoke_O_O_O__O(tmp25, tmp26, tmp27) }
//line :83:1
	case 13: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_86) {
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2)) { var root_402 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_406 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { return linked_403.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } } else { var root_407 any = A_arbace_repr_go_types_A_const_8.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_408 == nil { return ifn_409.Invoke_O__O(arg_410) } else { return linked_408.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_407, arg_410) } } }
//line :83:1
	case 14: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_91) { var ps__4 any; var root_415 any = A_arbace_repr_go_types_A_const_36.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, A_arbace_repr_go_types_params_vec_A_fn_class); var ifn_417 lang.IFn









		if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_repr_go_types_A_const_37.Invoke_O__O(e__2); var arg_419 any = A_arbace_repr_go_types_A_const_38.Invoke_O__O(e__2); if linked_416 == nil { ps__4 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { ps__4 = linked_416.(*A_arbace_repr_go_types_params_vec_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }
		var tmp28 any; var root_420 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_repr_go_types_A_const_39.Invoke_O__O(e__2); if linked_421 == nil { tmp28 = ifn_422.Invoke_O__O(arg_423) } else { tmp28 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(tmp28) {
			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp30 any = A_arbace_repr_go_types_A_const_98; var tmp31 any; var root_445 any = A_arbace_repr_go_types_A_const_43.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_450 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_454 any = A_arbace_repr_go_types_A_const_28; if linked_451 == nil { arg_448 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { arg_448 = linked_451.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; var arg_449 any = A_arbace_repr_go_types_A_const_39.Invoke_O__O(e__2); if linked_446 == nil { tmp31 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { tmp31 = linked_446.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; return tmp29.Invoke_O_O_O__O(tmp30, ps__4, tmp31) } else {
				return lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_types_A_const_99, ps__4) } }
//line :83:1
	case 19: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_92) {





















		var root_424 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_428 any = A_arbace_repr_go_types_A_const_93; var arg_429 any; var root_430 any = A_arbace_repr_go_types_A_const_94.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_432 lang.IFn
		if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_435 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = A_arbace_repr_go_types_A_const_95.GetRawRoot__O(); var arg_439 any = A_arbace_repr_go_types_A_const_96.Invoke_O__O(e__2); if linked_436 == nil { arg_433 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { arg_433 = linked_436.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var arg_434 any; var root_440 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_442 lang.IFn
		if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_444 any = A_arbace_repr_go_types_A_const_97.Invoke_O__O(e__2); if linked_441 == nil { arg_434 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { arg_434 = linked_441.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }
//line :106:1
		if linked_431 == nil { arg_429 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { arg_429 = linked_431.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }
//line :105:1
		if linked_425 == nil { return ifn_426.Invoke_O_O_O__O(arg_427, arg_428, arg_429) } else { return linked_425.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_424, arg_427, arg_428, arg_429) } }
//line :83:1
	case 23: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_100) {



































		var root_455 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_459 any = A_arbace_repr_go_types_A_const_101; var arg_460 any; var root_461 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any; var root_466 any = A_arbace_repr_go_types_A_const_44.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_470 any = A_arbace_repr_go_types_A_const_28; if linked_467 == nil { arg_464 = ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { arg_464 = linked_467.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) }; var arg_465 any = A_arbace_repr_go_types_A_const_102.Invoke_O__O(e__2); if linked_462 == nil { arg_460 = ifn_463.Invoke_O_O__O(arg_464, arg_465) } else { arg_460 = linked_462.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_461, arg_464, arg_465) }; if linked_456 == nil { return ifn_457.Invoke_O_O_O__O(arg_458, arg_459, arg_460) } else { return linked_456.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_455, arg_458, arg_459, arg_460) } }
//line :83:1
	case 25: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_103) { var base__4 any; var root_471 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_473 lang.IFn




























		if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_475 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_472 == nil { base__4 = ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { base__4 = linked_472.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_471, arg_474, arg_475) }
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_104.Invoke_O__O(e__2)) {
			var tmp32 any; var and__1927000168__auto____5 bool; var tmp33 any; var root_476 any = A_arbace_repr_go_types_A_const_105.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = base__4; if linked_477 == nil { tmp33 = ifn_478.Invoke_O__O(arg_479) } else { tmp33 = linked_477.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_476, arg_479) }; and__1927000168__auto____5 = lang.Util_Identical_O_O__Z_NoInit(tmp33, nil); if and__1927000168__auto____5 { tmp32 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_106.GetRawRoot__O()).Invoke_O__O(base__4) } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp32) {
				var root_480 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_484 any = A_arbace_repr_go_types_A_const_107; var arg_485 any = base__4; var arg_486 any; var root_487 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_491 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_488 == nil { arg_486 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { arg_486 = linked_488.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; if linked_481 == nil { return ifn_482.Invoke_O_O_O_O__O(arg_483, arg_484, arg_485, arg_486) } else { return linked_481.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_480, arg_483, arg_484, arg_485, arg_486) } } else {
					var root_492 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_496 any = base__4; var arg_497 any; var root_498 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_502 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_499 == nil { arg_497 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { arg_497 = linked_499.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; if linked_493 == nil { return ifn_494.Invoke_O_O_O__O(arg_495, arg_496, arg_497) } else { return linked_493.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_492, arg_495, arg_496, arg_497) } } } else {
//line :113:1
						return base__4 } }
//line :83:1
	case 28: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_109) {


		var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp35 any = A_arbace_repr_go_types_A_const_111; var tmp36 any; var root_535 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = A_arbace_repr_go_types_A_const_72.Invoke_O__O(e__2); if linked_536 == nil { tmp36 = ifn_537.Invoke_O__O(arg_538) } else { tmp36 = linked_536.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_535, arg_538) }; return tmp34.Invoke_O_O__O(tmp35, tmp36) }
//line :83:1
	case 29: if any(G__1140000026__3_) == any(A_arbace_repr_go_types_A_const_110) { var base__4_2 any; var root_503 any = A_arbace_repr_go_types_A_const_88.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, A_arbace_repr_go_types_qualify_A_fn_class); var ifn_505 lang.IFn




























		if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = A_arbace_repr_go_types_A_const_87.Invoke_O__O(e__2); var arg_507 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2); if linked_504 == nil { base__4_2 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { base__4_2 = linked_504.(*A_arbace_repr_go_types_qualify_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }
		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_104.Invoke_O__O(e__2)) {
			var tmp37 any; var and__1927000168__auto____5_2 bool; var tmp38 any; var root_508 any = A_arbace_repr_go_types_A_const_105.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = base__4_2; if linked_509 == nil { tmp38 = ifn_510.Invoke_O__O(arg_511) } else { tmp38 = linked_509.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_508, arg_511) }; and__1927000168__auto____5_2 = lang.Util_Identical_O_O__Z_NoInit(tmp38, nil); if and__1927000168__auto____5_2 { tmp37 = lang.IFn_Cast(A_arbace_repr_go_types_A_const_106.GetRawRoot__O()).Invoke_O__O(base__4_2) } else { tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp37) {
				var root_512 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_516 any = A_arbace_repr_go_types_A_const_107; var arg_517 any = base__4_2; var arg_518 any; var root_519 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_523 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_520 == nil { arg_518 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { arg_518 = linked_520.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }; if linked_513 == nil { return ifn_514.Invoke_O_O_O_O__O(arg_515, arg_516, arg_517, arg_518) } else { return linked_513.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_512, arg_515, arg_516, arg_517, arg_518) } } else {
					var root_524 any = A_arbace_repr_go_types_A_const_9.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = A_arbace_repr_go_types_A_const_15.GetRawRoot__O(); var arg_528 any = base__4_2; var arg_529 any; var root_530 any = A_arbace_repr_go_types_A_const_12.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var arg_534 any = A_arbace_repr_go_types_A_const_108.Invoke_O__O(e__2); if linked_531 == nil { arg_529 = ifn_532.Invoke_O_O__O(arg_533, arg_534) } else { arg_529 = linked_531.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_530, arg_533, arg_534) }; if linked_525 == nil { return ifn_526.Invoke_O_O_O__O(arg_527, arg_528, arg_529) } else { return linked_525.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_524, arg_527, arg_528, arg_529) } } } else {
//line :113:1
						return base__4_2 } }
//line :83:1
	default:}; var tmp39 any; var root_240 any = A_arbace_repr_go_types_A_const_67.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_242 lang.IFn; if




































	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, id__0, nil, lang.IFn_Cast(A_arbace_repr_go_types_A_const_68.GetRawRoot__O()).Invoke_O__O(e__2))).Ref(); var arg_244 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_types_A_const_69, id__0)); if linked_241 == nil { tmp39 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { tmp39 = linked_241.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; /*line :83:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp39))) }














func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_New() *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A) Ctor() {}
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A) Invoke_O_O__O(self, s__1140000039__1 any) any { var tmp1 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_New_O_O(s__1140000039__1, self); var tmp2 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class = fncls__396d; tmp2 = fncls__396d } else { tmp2 = fncls__396 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :98:1
func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_New_O_O(p0, p1 any) *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A) Ctor_O_O(c__s__1140000039, c__iter__1140000038 any) { t.F_s__1140000039 = c__s__1140000039; t.F_iter__1140000038 = c__iter__1140000038 }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A) Invoke_O__O(self any) any { { var s__1140000039__1 any; var t_ any = t.F_s__1140000039; t.F_s__1140000039 = nil; s__1140000039__1 = t_; for { var temp__1927000414__auto____2 any; var root_279 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = s__1140000039__1; if linked_280 == nil { temp__1927000414__auto____2 = ifn_281.Invoke_O__O(arg_282) } else { temp__1927000414__auto____2 = linked_280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_279, arg_282) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1140000039__3 any = temp__1927000414__auto____2; var tmp1 any; var root_283 any = A_arbace_repr_go_types_A_const_55.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = s__1140000039__3; if linked_284 == nil { tmp1 = ifn_285.Invoke_O__O(arg_286) } else { tmp1 = linked_284.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_283, arg_286) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_287 any = A_arbace_repr_go_types_A_const_56.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = s__1140000039__3; if linked_288 == nil { c__1927001037__auto____4 = ifn_289.Invoke_O__O(arg_290) } else { c__1927001037__auto____4 = linked_288.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_287, arg_290) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1140000041__6 any; var root_291 any = A_arbace_repr_go_types_A_const_57.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_292 == nil { b__1140000041__6 = ifn_293.Invoke_O__O(arg_294) } else { b__1140000041__6 = linked_292.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_291, arg_294) }; var tmp2 any = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_New_O_I_O(b__1140000041__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class = fncls__330d; tmp3 = fncls__330d } else { tmp3 = fncls__330 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_331 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var root_336 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = b__1140000041__6; if linked_337 == nil { arg_334 = ifn_338.Invoke_O__O(arg_339) } else { arg_334 = linked_337.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_336, arg_339) }; var arg_335 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1140000038); var tmp5 any; var root_340 any = A_arbace_repr_go_types_A_const_63.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = s__1140000039__3; if linked_341 == nil { tmp5 = ifn_342.Invoke_O__O(arg_343) } else { tmp5 = linked_341.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_340, arg_343) }; arg_335 = tmp4.Invoke_O__O(tmp5); if linked_332 == nil { return ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { return linked_332.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) } } else { var root_344 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any; var root_349 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = b__1140000041__6; if linked_350 == nil { arg_347 = ifn_351.Invoke_O__O(arg_352) } else { arg_347 = linked_350.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_349, arg_352) }; var arg_348 any; if linked_345 == nil { return ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { return linked_345.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) } } } else { var f__4 any; var root_353 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = s__1140000039__3; if linked_354 == nil { f__4 = ifn_355.Invoke_O__O(arg_356) } else { f__4 = linked_354.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_353, arg_356) }; var root_357 any = A_arbace_repr_go_types_A_const_64.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any
															if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_79.Invoke_O__O(f__4)) { var t__5 any; var root_362 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_364 lang.IFn
																if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__4); if linked_363 == nil { t__5 = ifn_364.Invoke_O__O(arg_365) } else { t__5 = linked_363.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_362, arg_365) }
																if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_80.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var tmp8 any = A_arbace_repr_go_types_A_const_82; arg_360 = tmp6.Invoke_O_O_O_O__O(t__5, tmp7, tmp8, A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) } else { arg_360 = t__5 } } else {
																	var root_373 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; var root_378 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(f__4); if linked_379 == nil { arg_376 = ifn_380.Invoke_O__O(arg_381) } else { arg_376 = linked_379.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_378, arg_381) }; var arg_377 any; var G__1140000047__5_ any; var tmp9 any = A_arbace_repr_go_types_A_const_42; var tmp10 any; var root_382 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_384 lang.IFn
																	if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__4); if linked_383 == nil { tmp10 = ifn_384.Invoke_O__O(arg_385) } else { tmp10 = linked_383.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_382, arg_385) }
//line :102:1
			G__1140000047__5_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10))
			if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4)) {
				var root_386 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = G__1140000047__5_; var arg_390 any = A_arbace_repr_go_types_A_const_82; var arg_391 any = A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__4); if linked_387 == nil { arg_377 = ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { arg_377 = linked_387.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391) } } else {
//line :103:1
					arg_377 = G__1140000047__5_ }
//line :102:1
			if linked_374 == nil { arg_360 = ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { arg_360 = linked_374.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } }
//line :98:1
	var arg_361 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1140000038); var tmp12 any; var root_392 any = A_arbace_repr_go_types_A_const_65.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = s__1140000039__3; if linked_393 == nil { tmp12 = ifn_394.Invoke_O__O(arg_395) } else { tmp12 = linked_393.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_392, arg_395) }; arg_361 = tmp11.Invoke_O__O(tmp12); if linked_358 == nil { return ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { return linked_358.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :98:1
func A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A) Ctor_O_I_O(c__b__1140000041 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1140000041 = c__b__1140000041; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :98:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A) Invoke_O__O(self any) any { { var i__1140000040__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1140000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1140000040__1)); var root_295 any = A_arbace_repr_go_types_A_const_58.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = t.F_b__1140000041; var arg_299 any
																	if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_79.Invoke_O__O(f__2)) { var t__3 any; var root_300 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_302 lang.IFn
																		if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__2); if linked_301 == nil { t__3 = ifn_302.Invoke_O__O(arg_303) } else { t__3 = linked_301.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_300, arg_303) }
																		if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_80.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var tmp4 any = A_arbace_repr_go_types_A_const_82; arg_299 = tmp2.Invoke_O_O_O_O__O(t__3, tmp3, tmp4, A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) } else { arg_299 = t__3 } } else {
																			var root_311 any = A_arbace_repr_go_types_A_const_41.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var root_316 any = A_arbace_repr_go_types_A_const_18.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_repr_go_types_name_form_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_repr_go_types_A_const_34.Invoke_O__O(f__2); if linked_317 == nil { arg_314 = ifn_318.Invoke_O__O(arg_319) } else { arg_314 = linked_317.(*A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_316, arg_319) }; var arg_315 any; var G__1140000045__3_ any; var tmp5 any = A_arbace_repr_go_types_A_const_42; var tmp6 any; var root_320 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_322 lang.IFn
																			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(f__2); if linked_321 == nil { tmp6 = ifn_322.Invoke_O__O(arg_323) } else { tmp6 = linked_321.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_320, arg_323) }
//line :102:1
			G__1140000045__3_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6))
			if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2)) {
				var root_324 any = A_arbace_repr_go_types_A_const_81.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = G__1140000045__3_; var arg_328 any = A_arbace_repr_go_types_A_const_82; var arg_329 any = A_arbace_repr_go_types_A_const_42.Invoke_O__O(f__2); if linked_325 == nil { arg_315 = ifn_326.Invoke_O_O_O__O(arg_327, arg_328, arg_329) } else { arg_315 = linked_325.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_324, arg_327, arg_328, arg_329) } } else {
//line :103:1
					arg_315 = G__1140000045__3_ }
//line :102:1
			if linked_312 == nil { arg_299 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { arg_299 = linked_312.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } }
//line :98:1
	if linked_296 == nil { ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { linked_296.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_295, arg_298, arg_299) }; i__1140000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1140000040__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_New() *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A) Invoke_O_O__O(self, s__1140000029__1 any) any { var tmp1 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_New_O_O(s__1140000029__1, self); var tmp2 *jrt.Class; var fncls__238 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class; if fncls__238 == nil { var fncls__238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class = fncls__238d; tmp2 = fncls__238d } else { tmp2 = fncls__238 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_New_O_O(p0, p1 any) *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A) Ctor_O_O(c__s__1140000029, c__iter__1140000028 any) { t.F_s__1140000029 = c__s__1140000029; t.F_iter__1140000028 = c__iter__1140000028 }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A) Invoke_O__O(self any) any { { var s__1140000029__1 any; var t_ any = t.F_s__1140000029; t.F_s__1140000029 = nil; s__1140000029__1 = t_; for { var temp__1927000414__auto____2 any; var root_165 any = A_arbace_repr_go_types_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = s__1140000029__1; if linked_166 == nil { temp__1927000414__auto____2 = ifn_167.Invoke_O__O(arg_168) } else { temp__1927000414__auto____2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1140000029__3 any = temp__1927000414__auto____2; var tmp1 any; var root_169 any = A_arbace_repr_go_types_A_const_55.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1140000029__3; if linked_170 == nil { tmp1 = ifn_171.Invoke_O__O(arg_172) } else { tmp1 = linked_170.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_173 any = A_arbace_repr_go_types_A_const_56.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__1140000029__3; if linked_174 == nil { c__1927001037__auto____4 = ifn_175.Invoke_O__O(arg_176) } else { c__1927001037__auto____4 = linked_174.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_173, arg_176) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1140000031__6 any; var root_177 any = A_arbace_repr_go_types_A_const_57.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_178 == nil { b__1140000031__6 = ifn_179.Invoke_O__O(arg_180) } else { b__1140000031__6 = linked_178.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_177, arg_180) }; var tmp2 any = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_New_O_I_O(b__1140000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class = fncls__194d; tmp3 = fncls__194d } else { tmp3 = fncls__194 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_195 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_200 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = b__1140000031__6; if linked_201 == nil { arg_198 = ifn_202.Invoke_O__O(arg_203) } else { arg_198 = linked_201.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_200, arg_203) }; var arg_199 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1140000028); var tmp5 any; var root_204 any = A_arbace_repr_go_types_A_const_63.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__1140000029__3; if linked_205 == nil { tmp5 = ifn_206.Invoke_O__O(arg_207) } else { tmp5 = linked_205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_204, arg_207) }; arg_199 = tmp4.Invoke_O__O(tmp5); if linked_196 == nil { return ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { return linked_196.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) } } else { var root_208 any = A_arbace_repr_go_types_A_const_61.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_213 any = A_arbace_repr_go_types_A_const_62.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = b__1140000031__6; if linked_214 == nil { arg_211 = ifn_215.Invoke_O__O(arg_216) } else { arg_211 = linked_214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_213, arg_216) }; var arg_212 any; if linked_209 == nil { return ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { return linked_209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } } } else { var t__4 any; var root_217 any = A_arbace_repr_go_types_A_const_33.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = s__1140000029__3; if linked_218 == nil { t__4 = ifn_219.Invoke_O__O(arg_220) } else { t__4 = linked_218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_217, arg_220) }; var root_221 any = A_arbace_repr_go_types_A_const_64.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any
															if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_59.Invoke_O__O(t__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_types_A_const_60; var tmp8 any; var root_230 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__4); if linked_231 == nil { tmp8 = ifn_232.Invoke_O__O(arg_233) } else { tmp8 = linked_231.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_230, arg_233) }; arg_224 = tmp6.Invoke_O_O__O(tmp7, tmp8) } else { var root_226 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__4); if linked_227 == nil { arg_224 = ifn_228.Invoke_O__O(arg_229) } else { arg_224 = linked_227.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_226, arg_229) } }
//line :109:1
	var arg_225 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1140000028); var tmp10 any; var root_234 any = A_arbace_repr_go_types_A_const_65.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__1140000029__3; if linked_235 == nil { tmp10 = ifn_236.Invoke_O__O(arg_237) } else { tmp10 = linked_235.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_234, arg_237) }; arg_225 = tmp9.Invoke_O__O(tmp10); if linked_222 == nil { return ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { return linked_222.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :109:1
func A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A) Ctor_O_I_O(c__b__1140000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1140000031 = c__b__1140000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A) Invoke_O__O(self any) any { { var i__1140000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1140000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1140000030__1)); var root_181 any = A_arbace_repr_go_types_A_const_58.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = t.F_b__1140000031; var arg_185 any
																	if jrt.J2g_Truth(A_arbace_repr_go_types_A_const_59.Invoke_O__O(t__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_types_A_const_60; var tmp4 any; var root_190 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__2); if linked_191 == nil { tmp4 = ifn_192.Invoke_O__O(arg_193) } else { tmp4 = linked_191.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_190, arg_193) }; arg_185 = tmp2.Invoke_O_O__O(tmp3, tmp4) } else { var root_186 any = A_arbace_repr_go_types_A_const_27.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_repr_go_types_type_form_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = A_arbace_repr_go_types_A_const_28.Invoke_O__O(t__2); if linked_187 == nil { arg_185 = ifn_188.Invoke_O__O(arg_189) } else { arg_185 = linked_187.(*A_arbace_repr_go_types_type_form_A).Invoke_O_O__O(root_186, arg_189) } }
//line :109:1
	if linked_182 == nil { ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { linked_182.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; i__1140000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1140000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_repr_go_types_untyped_QMARK__A_New() *A_arbace_repr_go_types_untyped_QMARK__A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_repr_go_types_untyped_QMARK__A) Ctor() {}
//line :122:1
func (t *A_arbace_repr_go_types_untyped_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_539 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_repr_go_types_entry_A_fn_class); var ifn_541 lang.IFn; if


	linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = id__0; if linked_540 == nil { e__2 = ifn_541.Invoke_O__O(arg_542) } else { e__2 = linked_540.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_539, arg_542) }; var tmp1 any = A_arbace_repr_go_types_A_const_86; var and__1927000168__auto____3 bool = /*line :122:1*/lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2)); if and__1927000168__auto____3 {



		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))).StartsWith_String__Z(Lit_19)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }








func A_arbace_repr_go_types_const_kind_A_New() *A_arbace_repr_go_types_const_kind_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_const_kind_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_types_const_kind_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_types_const_kind_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var root_543 any = A_arbace_repr_go_types_A_const_35.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_repr_go_types_entry_A_fn_class); var ifn_545 lang.IFn; if



	linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = id__0; if linked_544 == nil { e__2 = ifn_545.Invoke_O__O(arg_546) } else { e__2 = linked_544.(*A_arbace_repr_go_types_entry_A).Invoke_O_O__O(root_543, arg_546) }; var G__1140000052__3_ any = /*line :135:1*/A_arbace_repr_go_types_A_const_45.Invoke_O__O(e__2); switch




	lang.Util_Hash_O__I_NoInit(G__1140000052__3_) >> 4 & 3 { case 1: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_103) {




		var root_548 any = A_arbace_repr_go_types_A_const_112.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_repr_go_types_const_kind_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = A_arbace_repr_go_types_A_const_113.Invoke_O__O(e__2); if linked_549 == nil { return ifn_550.Invoke_O__O(arg_551) } else { return linked_549.(*A_arbace_repr_go_types_const_kind_A).Invoke_O_O__O(root_548, arg_551) } }
//line :140:1
	case 2: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_86) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_types_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_types_A_const_115); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_types_A_const_34.Invoke_O__O(e__2))) { return A_arbace_repr_go_types_A_const_116 } else { return nil } } }
//line :140:1
	case 3: if any(G__1140000052__3_) == any(A_arbace_repr_go_types_A_const_110) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_repr_go_types_A_const_117.Get__O(), id__0)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var u__5 any = temp__1927000414__auto____4; var root_552 any = A_arbace_repr_go_types_A_const_112.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_repr_go_types_const_kind_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = u__5; if linked_553 == nil { return ifn_554.Invoke_O__O(arg_555) } else { return linked_553.(*A_arbace_repr_go_types_const_kind_A).Invoke_O_O__O(root_552, arg_555) } } else { return nil } }
//line :140:1
	default:}; return nil }







type A_arbace_repr_go_types_A struct{ jrt.Object }

var A_arbace_repr_go_types_A_const_pool *jrt.RefArray

var A_arbace_repr_go_types_A_const_0 *lang.Var

var A_arbace_repr_go_types_A_const_1 any

var A_arbace_repr_go_types_A_const_2 *lang.Var

var A_arbace_repr_go_types_A_const_3 *lang.Var

var A_arbace_repr_go_types_A_const_4 *lang.Var

var A_arbace_repr_go_types_A_const_5 *lang.Var

var A_arbace_repr_go_types_A_const_6 any

var A_arbace_repr_go_types_A_const_7 *lang.Var

var A_arbace_repr_go_types_A_const_8 *lang.Var

var A_arbace_repr_go_types_A_const_9 *lang.Var

var A_arbace_repr_go_types_A_const_10 *lang.Var

var A_arbace_repr_go_types_A_const_11 *lang.Var

var A_arbace_repr_go_types_A_const_12 *lang.Var

var A_arbace_repr_go_types_A_const_13 *jrt.Class

var A_arbace_repr_go_types_A_const_14 any

var A_arbace_repr_go_types_A_const_15 *lang.Var

var A_arbace_repr_go_types_A_const_16 any

var A_arbace_repr_go_types_A_const_17 *lang.Var

var A_arbace_repr_go_types_A_const_18 *lang.Var

var A_arbace_repr_go_types_A_const_19 *lang.Var

var A_arbace_repr_go_types_A_const_20 *lang.Var

var A_arbace_repr_go_types_A_const_21 *lang.Keyword

var A_arbace_repr_go_types_A_const_22 *lang.Var

var A_arbace_repr_go_types_A_const_23 *lang.Var

var A_arbace_repr_go_types_A_const_24 *lang.Var

var A_arbace_repr_go_types_A_const_25 *lang.Var

var A_arbace_repr_go_types_A_const_26 any

var A_arbace_repr_go_types_A_const_27 *lang.Var

var A_arbace_repr_go_types_A_const_28 *lang.Keyword

var A_arbace_repr_go_types_A_const_29 *lang.Var

var A_arbace_repr_go_types_A_const_30 *lang.Var

var A_arbace_repr_go_types_A_const_31 *lang.Var

var A_arbace_repr_go_types_A_const_32 *lang.Var

var A_arbace_repr_go_types_A_const_33 *lang.Var

var A_arbace_repr_go_types_A_const_34 *lang.Keyword

var A_arbace_repr_go_types_A_const_35 *lang.Var

var A_arbace_repr_go_types_A_const_36 *lang.Var

var A_arbace_repr_go_types_A_const_37 *lang.Keyword

var A_arbace_repr_go_types_A_const_38 *lang.Keyword

var A_arbace_repr_go_types_A_const_39 *lang.Keyword

var A_arbace_repr_go_types_A_const_40 *lang.Var

var A_arbace_repr_go_types_A_const_41 *lang.Var

var A_arbace_repr_go_types_A_const_42 *lang.Keyword

var A_arbace_repr_go_types_A_const_43 *lang.Var

var A_arbace_repr_go_types_A_const_44 *lang.Var

var A_arbace_repr_go_types_A_const_45 *lang.Keyword

var A_arbace_repr_go_types_A_const_46 *lang.Keyword

var A_arbace_repr_go_types_A_const_47 *lang.Keyword

var A_arbace_repr_go_types_A_const_48 *lang.Keyword

var A_arbace_repr_go_types_A_const_49 *lang.Keyword

var A_arbace_repr_go_types_A_const_50 *lang.Keyword

var A_arbace_repr_go_types_A_const_51 *lang.Keyword

var A_arbace_repr_go_types_A_const_52 *lang.Keyword

var A_arbace_repr_go_types_A_const_53 *lang.Keyword

var A_arbace_repr_go_types_A_const_54 any

var A_arbace_repr_go_types_A_const_55 *lang.Var

var A_arbace_repr_go_types_A_const_56 *lang.Var

var A_arbace_repr_go_types_A_const_57 *lang.Var

var A_arbace_repr_go_types_A_const_58 *lang.Var

var A_arbace_repr_go_types_A_const_59 *lang.Keyword

var A_arbace_repr_go_types_A_const_60 any

var A_arbace_repr_go_types_A_const_61 *lang.Var

var A_arbace_repr_go_types_A_const_62 *lang.Var

var A_arbace_repr_go_types_A_const_63 *lang.Var

var A_arbace_repr_go_types_A_const_64 *lang.Var

var A_arbace_repr_go_types_A_const_65 *lang.Var

var A_arbace_repr_go_types_A_const_66 *lang.Keyword

var A_arbace_repr_go_types_A_const_67 *lang.Var

var A_arbace_repr_go_types_A_const_68 *lang.Var

var A_arbace_repr_go_types_A_const_69 *lang.Keyword

var A_arbace_repr_go_types_A_const_70 any

var A_arbace_repr_go_types_A_const_71 *lang.Keyword

var A_arbace_repr_go_types_A_const_72 *lang.Keyword

var A_arbace_repr_go_types_A_const_73 any

var A_arbace_repr_go_types_A_const_74 any

var A_arbace_repr_go_types_A_const_75 any

var A_arbace_repr_go_types_A_const_76 any

var A_arbace_repr_go_types_A_const_77 *lang.Keyword

var A_arbace_repr_go_types_A_const_78 any

var A_arbace_repr_go_types_A_const_79 *lang.Keyword

var A_arbace_repr_go_types_A_const_80 *lang.Var

var A_arbace_repr_go_types_A_const_81 *lang.Var

var A_arbace_repr_go_types_A_const_82 *lang.Keyword

var A_arbace_repr_go_types_A_const_83 *lang.Keyword

var A_arbace_repr_go_types_A_const_84 *lang.Keyword

var A_arbace_repr_go_types_A_const_85 *lang.Keyword

var A_arbace_repr_go_types_A_const_86 *lang.Keyword

var A_arbace_repr_go_types_A_const_87 *lang.Keyword

var A_arbace_repr_go_types_A_const_88 *lang.Var

var A_arbace_repr_go_types_A_const_89 any

var A_arbace_repr_go_types_A_const_90 *lang.Keyword

var A_arbace_repr_go_types_A_const_91 *lang.Keyword

var A_arbace_repr_go_types_A_const_92 *lang.Keyword

var A_arbace_repr_go_types_A_const_93 any

var A_arbace_repr_go_types_A_const_94 *lang.Var

var A_arbace_repr_go_types_A_const_95 *lang.Var

var A_arbace_repr_go_types_A_const_96 *lang.Keyword

var A_arbace_repr_go_types_A_const_97 *lang.Keyword

var A_arbace_repr_go_types_A_const_98 any

var A_arbace_repr_go_types_A_const_99 any

var A_arbace_repr_go_types_A_const_100 *lang.Keyword

var A_arbace_repr_go_types_A_const_101 any

var A_arbace_repr_go_types_A_const_102 *lang.Keyword

var A_arbace_repr_go_types_A_const_103 *lang.Keyword

var A_arbace_repr_go_types_A_const_104 *lang.Keyword

var A_arbace_repr_go_types_A_const_105 *lang.Var

var A_arbace_repr_go_types_A_const_106 *lang.Var

var A_arbace_repr_go_types_A_const_107 any

var A_arbace_repr_go_types_A_const_108 *lang.Keyword

var A_arbace_repr_go_types_A_const_109 *lang.Keyword

var A_arbace_repr_go_types_A_const_110 *lang.Keyword

var A_arbace_repr_go_types_A_const_111 any

var A_arbace_repr_go_types_A_const_112 *lang.Var

var A_arbace_repr_go_types_A_const_113 *lang.Keyword

var A_arbace_repr_go_types_A_const_114 *lang.Var

var A_arbace_repr_go_types_A_const_115 any

var A_arbace_repr_go_types_A_const_116 *lang.Keyword

var A_arbace_repr_go_types_A_const_117 *lang.Var

var A_arbace_repr_go_types_A_init jrt.ClassInit

func A_arbace_repr_go_types_A_Init() { if !A_arbace_repr_go_types_A_init.Done() { A_arbace_repr_go_types_A_init.Run(A_arbace_repr_go_types_A_clinit) } }

func A_arbace_repr_go_types_A_clinit() { A_arbace_repr_go_types_A_clinit_p0(); A_arbace_repr_go_types_A_clinit_p1(); A_arbace_repr_go_types_A_clinit_p2(); A_arbace_repr_go_types_A_clinit_p3(); A_arbace_repr_go_types_A_clinit_p4(); A_arbace_repr_go_types_A_clinit_p5(); A_arbace_repr_go_types_A_clinit_p6(); A_arbace_repr_go_types_A_clinit_p7(); A_arbace_repr_go_types_A_clinit_p8(); A_arbace_repr_go_types_A_clinit_p9() }

func A_arbace_repr_go_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 177); A_arbace_repr_go_types_A_const_0 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[59]); A_arbace_repr_go_types_A_const_1 = A_arbace_repr_go_types_A_const_pool.A[60]; A_arbace_repr_go_types_A_const_2 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[61]); A_arbace_repr_go_types_A_const_3 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[62]); A_arbace_repr_go_types_A_const_4 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[63]); A_arbace_repr_go_types_A_const_5 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[64]); A_arbace_repr_go_types_A_const_6 = A_arbace_repr_go_types_A_const_pool.A[65]; A_arbace_repr_go_types_A_const_7 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[66]); A_arbace_repr_go_types_A_const_8 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[67]); A_arbace_repr_go_types_A_const_9 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[68]); A_arbace_repr_go_types_A_const_10 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[69]) }

func A_arbace_repr_go_types_A_clinit_p1() { A_arbace_repr_go_types_A_const_11 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[70]); A_arbace_repr_go_types_A_const_12 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[71]); A_arbace_repr_go_types_A_const_13 = jrt.Class_Cast(A_arbace_repr_go_types_A_const_pool.A[72]); A_arbace_repr_go_types_A_const_14 = A_arbace_repr_go_types_A_const_pool.A[73]; A_arbace_repr_go_types_A_const_15 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[74]); A_arbace_repr_go_types_A_const_16 = A_arbace_repr_go_types_A_const_pool.A[75]; A_arbace_repr_go_types_A_const_17 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[76]); A_arbace_repr_go_types_A_const_18 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[77]); A_arbace_repr_go_types_A_const_19 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[78]); A_arbace_repr_go_types_A_const_20 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[79]); A_arbace_repr_go_types_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[80]); A_arbace_repr_go_types_A_const_22 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[81]) }

func A_arbace_repr_go_types_A_clinit_p2() { A_arbace_repr_go_types_A_const_23 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[82]); A_arbace_repr_go_types_A_const_24 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[83]); A_arbace_repr_go_types_A_const_25 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[84]); A_arbace_repr_go_types_A_const_26 = A_arbace_repr_go_types_A_const_pool.A[85]; A_arbace_repr_go_types_A_const_27 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[86]); A_arbace_repr_go_types_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[87]); A_arbace_repr_go_types_A_const_29 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[88]); A_arbace_repr_go_types_A_const_30 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[89]); A_arbace_repr_go_types_A_const_31 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[90]); A_arbace_repr_go_types_A_const_32 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[91]); A_arbace_repr_go_types_A_const_33 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[92]); A_arbace_repr_go_types_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[93]) }

func A_arbace_repr_go_types_A_clinit_p3() { A_arbace_repr_go_types_A_const_35 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[94]); A_arbace_repr_go_types_A_const_36 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[95]); A_arbace_repr_go_types_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[96]); A_arbace_repr_go_types_A_const_38 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[97]); A_arbace_repr_go_types_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[98]); A_arbace_repr_go_types_A_const_40 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[99]); A_arbace_repr_go_types_A_const_41 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[100]); A_arbace_repr_go_types_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[101]); A_arbace_repr_go_types_A_const_43 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[102]); A_arbace_repr_go_types_A_const_44 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[103]); A_arbace_repr_go_types_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[104]); A_arbace_repr_go_types_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[105]) }

func A_arbace_repr_go_types_A_clinit_p4() { A_arbace_repr_go_types_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[106]); A_arbace_repr_go_types_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[107]); A_arbace_repr_go_types_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[108]); A_arbace_repr_go_types_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[109]); A_arbace_repr_go_types_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[110]); A_arbace_repr_go_types_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[111]); A_arbace_repr_go_types_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[112]); A_arbace_repr_go_types_A_const_54 = A_arbace_repr_go_types_A_const_pool.A[113]; A_arbace_repr_go_types_A_const_55 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[114]); A_arbace_repr_go_types_A_const_56 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[115]); A_arbace_repr_go_types_A_const_57 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[116]); A_arbace_repr_go_types_A_const_58 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[117]) }

func A_arbace_repr_go_types_A_clinit_p5() { A_arbace_repr_go_types_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[118]); A_arbace_repr_go_types_A_const_60 = A_arbace_repr_go_types_A_const_pool.A[119]; A_arbace_repr_go_types_A_const_61 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[120]); A_arbace_repr_go_types_A_const_62 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[121]); A_arbace_repr_go_types_A_const_63 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[122]); A_arbace_repr_go_types_A_const_64 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[123]); A_arbace_repr_go_types_A_const_65 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[124]); A_arbace_repr_go_types_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[125]); A_arbace_repr_go_types_A_const_67 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[126]); A_arbace_repr_go_types_A_const_68 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[127]); A_arbace_repr_go_types_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[128]); A_arbace_repr_go_types_A_const_70 = A_arbace_repr_go_types_A_const_pool.A[129] }

func A_arbace_repr_go_types_A_clinit_p6() { A_arbace_repr_go_types_A_const_71 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[130]); A_arbace_repr_go_types_A_const_72 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[131]); A_arbace_repr_go_types_A_const_73 = A_arbace_repr_go_types_A_const_pool.A[132]; A_arbace_repr_go_types_A_const_74 = A_arbace_repr_go_types_A_const_pool.A[133]; A_arbace_repr_go_types_A_const_75 = A_arbace_repr_go_types_A_const_pool.A[134]; A_arbace_repr_go_types_A_const_76 = A_arbace_repr_go_types_A_const_pool.A[135]; A_arbace_repr_go_types_A_const_77 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[136]); A_arbace_repr_go_types_A_const_78 = A_arbace_repr_go_types_A_const_pool.A[137]; A_arbace_repr_go_types_A_const_79 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[138]); A_arbace_repr_go_types_A_const_80 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[139]); A_arbace_repr_go_types_A_const_81 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[140]); A_arbace_repr_go_types_A_const_82 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[141]); A_arbace_repr_go_types_A_const_83 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[142]) }

func A_arbace_repr_go_types_A_clinit_p7() { A_arbace_repr_go_types_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[143]); A_arbace_repr_go_types_A_const_85 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[144]); A_arbace_repr_go_types_A_const_86 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[145]); A_arbace_repr_go_types_A_const_87 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[146]); A_arbace_repr_go_types_A_const_88 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[147]); A_arbace_repr_go_types_A_const_89 = A_arbace_repr_go_types_A_const_pool.A[148]; A_arbace_repr_go_types_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[149]); A_arbace_repr_go_types_A_const_91 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[150]); A_arbace_repr_go_types_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[151]); A_arbace_repr_go_types_A_const_93 = A_arbace_repr_go_types_A_const_pool.A[152]; A_arbace_repr_go_types_A_const_94 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[153]); A_arbace_repr_go_types_A_const_95 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[154]) }

func A_arbace_repr_go_types_A_clinit_p8() { A_arbace_repr_go_types_A_const_96 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[155]); A_arbace_repr_go_types_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[156]); A_arbace_repr_go_types_A_const_98 = A_arbace_repr_go_types_A_const_pool.A[157]; A_arbace_repr_go_types_A_const_99 = A_arbace_repr_go_types_A_const_pool.A[158]; A_arbace_repr_go_types_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[159]); A_arbace_repr_go_types_A_const_101 = A_arbace_repr_go_types_A_const_pool.A[160]; A_arbace_repr_go_types_A_const_102 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[161]); A_arbace_repr_go_types_A_const_103 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[162]); A_arbace_repr_go_types_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[163]); A_arbace_repr_go_types_A_const_105 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[164]); A_arbace_repr_go_types_A_const_106 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[165]); A_arbace_repr_go_types_A_const_107 = A_arbace_repr_go_types_A_const_pool.A[166]; A_arbace_repr_go_types_A_const_108 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[167]) }

func A_arbace_repr_go_types_A_clinit_p9() { A_arbace_repr_go_types_A_const_109 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[168]); A_arbace_repr_go_types_A_const_110 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[169]); A_arbace_repr_go_types_A_const_111 = A_arbace_repr_go_types_A_const_pool.A[170]; A_arbace_repr_go_types_A_const_112 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[171]); A_arbace_repr_go_types_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[172]); A_arbace_repr_go_types_A_const_114 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[173]); A_arbace_repr_go_types_A_const_115 = A_arbace_repr_go_types_A_const_pool.A[174]; A_arbace_repr_go_types_A_const_116 = lang.Keyword_Cast(A_arbace_repr_go_types_A_const_pool.A[175]); A_arbace_repr_go_types_A_const_117 = lang.Var_Cast(A_arbace_repr_go_types_A_const_pool.A[176]) }

func A_arbace_repr_go_types_A_New() *A_arbace_repr_go_types_A { A_arbace_repr_go_types_A_Init(); t := &A_arbace_repr_go_types_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_A) Ctor() {}

func (t *A_arbace_repr_go_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_A_class }

func (t *A_arbace_repr_go_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_A); return ok }

func A_arbace_repr_go_types_A_Cast(x any) *A_arbace_repr_go_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_A_class)) }; return v }



type A_arbace_repr_go_types_const_kind_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_const_kind_A_fn_class *jrt.Class



type A_arbace_repr_go_types_entry_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_entry_A_fn_class *jrt.Class



type A_arbace_repr_go_types_eval1140000004_A struct{ jrt.Object }

func A_arbace_repr_go_types_eval1140000004_A_New() *A_arbace_repr_go_types_eval1140000004_A { t := &A_arbace_repr_go_types_eval1140000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_eval1140000004_A) Ctor() {}

func (t *A_arbace_repr_go_types_eval1140000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_eval1140000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_eval1140000004_A_class }

func (t *A_arbace_repr_go_types_eval1140000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_eval1140000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_eval1140000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_eval1140000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_eval1140000004_A); return ok }

func A_arbace_repr_go_types_eval1140000004_A_Cast(x any) *A_arbace_repr_go_types_eval1140000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_eval1140000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_eval1140000004_A_class)) }; return v }



type A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_fn_class *jrt.Class



type A_arbace_repr_go_types_eval1140000008_A struct{ jrt.Object }

func A_arbace_repr_go_types_eval1140000008_A_New() *A_arbace_repr_go_types_eval1140000008_A { t := &A_arbace_repr_go_types_eval1140000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types_eval1140000008_A) Ctor() {}

func (t *A_arbace_repr_go_types_eval1140000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types_eval1140000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types_eval1140000008_A_class }

func (t *A_arbace_repr_go_types_eval1140000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types_eval1140000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types_eval1140000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types_eval1140000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types_eval1140000008_A); return ok }

func A_arbace_repr_go_types_eval1140000008_A_Cast(x any) *A_arbace_repr_go_types_eval1140000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types_eval1140000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types_eval1140000008_A_class)) }; return v }



type A_arbace_repr_go_types_eval1140000008_fn__1140000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_fn_class *jrt.Class



type A_arbace_repr_go_types_method_elem_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_method_elem_A_fn_class *jrt.Class



type A_arbace_repr_go_types_name_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_name_form_A_fn_class *jrt.Class



type A_arbace_repr_go_types_ns_name_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_ns_name_of_A_fn_class *jrt.Class



type A_arbace_repr_go_types_ns_name_of_fn__1140000014_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_ns_name_of_fn__1140000014_A_fn_class *jrt.Class



type A_arbace_repr_go_types_params_vec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_params_vec_A_fn_class *jrt.Class



type A_arbace_repr_go_types_params_vec_fn__1140000019_A struct{ j2g_header uint64; F_n int32; F_variadic any }

var A_arbace_repr_go_types_params_vec_fn__1140000019_A_fn_class *jrt.Class



type A_arbace_repr_go_types_qualify_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_qualify_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A struct{ j2g_header uint64; F_s__1140000029, F_iter__1140000028 any }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A struct{ j2g_header uint64; F_b__1140000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_types_type_form_iter__1140000028__1140000032_fn__1140000033_fn__1140000034_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A struct{ j2g_header uint64; F_s__1140000039, F_iter__1140000038 any }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_A_fn_class *jrt.Class



type A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A struct{ j2g_header uint64; F_b__1140000041 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_types_type_form_iter__1140000038__1140000042_fn__1140000043_fn__1140000044_A_fn_class *jrt.Class



type A_arbace_repr_go_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_types_untyped_QMARK__A_fn_class *jrt.Class
