//line aot_arbace_repr_go_types__init.ae:1
package aot_arbace_repr_go_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_types__init_A_Unit0__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_types__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_types__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_types__init_A_Unit1__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_types__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_types__init_A_Unit2__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_go_types_eval1140000004_loading__1927001464__auto____1140000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_types__init_A_Unit3__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_types__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_types__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_types_eval1140000008_fn__1140000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_types__init_A_Load__O() any { A_arbace_repr_go_types__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_types__init_A_Unit0__O(); A_arbace_repr_go_types__init_A_Unit1__O(); A_arbace_repr_go_types__init_A_Unit2__O(); A_arbace_repr_go_types__init_A_Unit3__O(); A_arbace_repr_go_types__init_A_Unit4__O(); A_arbace_repr_go_types__init_A_Unit5__O(); A_arbace_repr_go_types__init_A_Unit6__O(); A_arbace_repr_go_types__init_A_Unit7__O(); A_arbace_repr_go_types__init_A_Unit8__O(); A_arbace_repr_go_types__init_A_Unit9__O(); A_arbace_repr_go_types__init_A_Unit10__O(); A_arbace_repr_go_types__init_A_Unit11__O(); A_arbace_repr_go_types__init_A_Unit12__O(); A_arbace_repr_go_types__init_A_Unit13__O(); A_arbace_repr_go_types__init_A_Unit14__O(); A_arbace_repr_go_types__init_A_Unit15__O(); A_arbace_repr_go_types__init_A_Unit16__O(); A_arbace_repr_go_types__init_A_Unit17__O(); A_arbace_repr_go_types__init_A_Unit18__O(); A_arbace_repr_go_types__init_A_Unit19__O(); A_arbace_repr_go_types__init_A_Unit20__O(); return nil }




func A_arbace_repr_go_types__init_A_Unit4__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(10, 1); A_arbace_repr_go_types__init_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_5)); return A_arbace_repr_go_types__init_A_const_4.SetDynamic_Z__Var(true).Ref() }



func A_arbace_repr_go_types__init_A_Unit5__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); A_arbace_repr_go_types__init_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_7)); return A_arbace_repr_go_types__init_A_const_6.SetDynamic_Z__Var(true).Ref() }



func A_arbace_repr_go_types__init_A_Unit6__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); A_arbace_repr_go_types__init_A_const_8.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_9)); return A_arbace_repr_go_types__init_A_const_8.SetDynamic_Z__Var(true).Ref() }



func A_arbace_repr_go_types__init_A_Unit7__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); A_arbace_repr_go_types__init_A_const_10.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_11)); return A_arbace_repr_go_types__init_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_repr_go_types__init_A_Unit8__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_repr_go_types__init_A_const_12.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_13)); return A_arbace_repr_go_types__init_A_const_12.SetDynamic_Z__Var(true).Ref() }



func A_arbace_repr_go_types__init_A_Unit9__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_14; var tmp2 any = A_arbace_repr_go_types_entry_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_types_entry_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_types_entry_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_15)); return A_arbace_repr_go_types__init_A_const_14 }

func A_arbace_repr_go_types__init_A_Unit10__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_repr_go_types__init_A_const_16.BindRoot_O__V(A_arbace_repr_go_types__init_A_const_17); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_18)); return A_arbace_repr_go_types__init_A_const_16 }



func A_arbace_repr_go_types__init_A_Unit11__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_19; var tmp2 any = A_arbace_repr_go_types_ns_name_of_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_types_ns_name_of_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_go_types_ns_name_of_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_20)); return A_arbace_repr_go_types__init_A_const_19 }






func A_arbace_repr_go_types__init_A_Unit12__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_21; var tmp2 any = A_arbace_repr_go_types_name_form_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_types_name_form_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_go_types_name_form_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_22)); return A_arbace_repr_go_types__init_A_const_21 }







func A_arbace_repr_go_types__init_A_Unit13__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_23; var tmp2 any = A_arbace_repr_go_types_qualify_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_types_qualify_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_go_types_qualify_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_24)); return A_arbace_repr_go_types__init_A_const_23 }







func A_arbace_repr_go_types__init_A_Unit14__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_26)); return A_arbace_repr_go_types__init_A_const_25 }

func A_arbace_repr_go_types__init_A_Unit15__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_27; var tmp2 any = A_arbace_repr_go_types_params_vec_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_types_params_vec_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_go_types_params_vec_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_28)); return A_arbace_repr_go_types__init_A_const_27 }







func A_arbace_repr_go_types__init_A_Unit16__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_29; var tmp2 any = A_arbace_repr_go_types_method_elem_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_types_method_elem_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_go_types_method_elem_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_30)); return A_arbace_repr_go_types__init_A_const_29 }








func A_arbace_repr_go_types__init_A_Unit17__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_25; var tmp2 any = A_arbace_repr_go_types_type_form_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_types_type_form_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_repr_go_types_type_form_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_31)); return A_arbace_repr_go_types__init_A_const_25 }










































func A_arbace_repr_go_types__init_A_Unit18__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_32; var tmp2 any = A_arbace_repr_go_types_untyped_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_types_untyped_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_repr_go_types_untyped_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_33)); return A_arbace_repr_go_types__init_A_const_32 }





func A_arbace_repr_go_types__init_A_Unit19__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); A_arbace_repr_go_types__init_A_const_34.BindRoot_O__V(A_arbace_repr_go_types__init_A_const_35); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_36)); return A_arbace_repr_go_types__init_A_const_34 }






func A_arbace_repr_go_types__init_A_Unit20__O() any { A_arbace_repr_go_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_repr_go_types__init_A_const_37; var tmp2 any = A_arbace_repr_go_types_const_kind_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_types_const_kind_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_go_types_const_kind_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_types__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_types__init_A_const_38)); return A_arbace_repr_go_types__init_A_const_37 }



type A_arbace_repr_go_types__init_A struct{ jrt.Object }

var A_arbace_repr_go_types__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_types__init_A_const_0 *lang.Var

var A_arbace_repr_go_types__init_A_const_1 any

var A_arbace_repr_go_types__init_A_const_2 any

var A_arbace_repr_go_types__init_A_const_3 any

var A_arbace_repr_go_types__init_A_const_4 *lang.Var

var A_arbace_repr_go_types__init_A_const_5 any

var A_arbace_repr_go_types__init_A_const_6 *lang.Var

var A_arbace_repr_go_types__init_A_const_7 any

var A_arbace_repr_go_types__init_A_const_8 *lang.Var

var A_arbace_repr_go_types__init_A_const_9 any

var A_arbace_repr_go_types__init_A_const_10 *lang.Var

var A_arbace_repr_go_types__init_A_const_11 any

var A_arbace_repr_go_types__init_A_const_12 *lang.Var

var A_arbace_repr_go_types__init_A_const_13 any

var A_arbace_repr_go_types__init_A_const_14 *lang.Var

var A_arbace_repr_go_types__init_A_const_15 any

var A_arbace_repr_go_types__init_A_const_16 *lang.Var

var A_arbace_repr_go_types__init_A_const_17 any

var A_arbace_repr_go_types__init_A_const_18 any

var A_arbace_repr_go_types__init_A_const_19 *lang.Var

var A_arbace_repr_go_types__init_A_const_20 any

var A_arbace_repr_go_types__init_A_const_21 *lang.Var

var A_arbace_repr_go_types__init_A_const_22 any

var A_arbace_repr_go_types__init_A_const_23 *lang.Var

var A_arbace_repr_go_types__init_A_const_24 any

var A_arbace_repr_go_types__init_A_const_25 *lang.Var

var A_arbace_repr_go_types__init_A_const_26 any

var A_arbace_repr_go_types__init_A_const_27 *lang.Var

var A_arbace_repr_go_types__init_A_const_28 any

var A_arbace_repr_go_types__init_A_const_29 *lang.Var

var A_arbace_repr_go_types__init_A_const_30 any

var A_arbace_repr_go_types__init_A_const_31 any

var A_arbace_repr_go_types__init_A_const_32 *lang.Var

var A_arbace_repr_go_types__init_A_const_33 any

var A_arbace_repr_go_types__init_A_const_34 *lang.Var

var A_arbace_repr_go_types__init_A_const_35 any

var A_arbace_repr_go_types__init_A_const_36 any

var A_arbace_repr_go_types__init_A_const_37 *lang.Var

var A_arbace_repr_go_types__init_A_const_38 any

var A_arbace_repr_go_types__init_A_init jrt.ClassInit

func A_arbace_repr_go_types__init_A_Init() { if !A_arbace_repr_go_types__init_A_init.Done() { A_arbace_repr_go_types__init_A_init.Run(A_arbace_repr_go_types__init_A_clinit) } }

func A_arbace_repr_go_types__init_A_clinit() { A_arbace_repr_go_types__init_A_clinit_p0(); A_arbace_repr_go_types__init_A_clinit_p1(); A_arbace_repr_go_types__init_A_clinit_p2() }

func A_arbace_repr_go_types__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_types__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_20, 76); A_arbace_repr_go_types__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[37]); A_arbace_repr_go_types__init_A_const_1 = A_arbace_repr_go_types__init_A_const_pool.A[38]; A_arbace_repr_go_types__init_A_const_2 = A_arbace_repr_go_types__init_A_const_pool.A[39]; A_arbace_repr_go_types__init_A_const_3 = A_arbace_repr_go_types__init_A_const_pool.A[40]; A_arbace_repr_go_types__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[41]); A_arbace_repr_go_types__init_A_const_5 = A_arbace_repr_go_types__init_A_const_pool.A[42]; A_arbace_repr_go_types__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[43]); A_arbace_repr_go_types__init_A_const_7 = A_arbace_repr_go_types__init_A_const_pool.A[44]; A_arbace_repr_go_types__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[45]); A_arbace_repr_go_types__init_A_const_9 = A_arbace_repr_go_types__init_A_const_pool.A[46]; A_arbace_repr_go_types__init_A_const_10 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[47]); A_arbace_repr_go_types__init_A_const_11 = A_arbace_repr_go_types__init_A_const_pool.A[48]; A_arbace_repr_go_types__init_A_const_12 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[49]) }

func A_arbace_repr_go_types__init_A_clinit_p1() { A_arbace_repr_go_types__init_A_const_13 = A_arbace_repr_go_types__init_A_const_pool.A[50]; A_arbace_repr_go_types__init_A_const_14 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[51]); A_arbace_repr_go_types__init_A_const_15 = A_arbace_repr_go_types__init_A_const_pool.A[52]; A_arbace_repr_go_types__init_A_const_16 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[53]); A_arbace_repr_go_types__init_A_const_17 = A_arbace_repr_go_types__init_A_const_pool.A[54]; A_arbace_repr_go_types__init_A_const_18 = A_arbace_repr_go_types__init_A_const_pool.A[55]; A_arbace_repr_go_types__init_A_const_19 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[56]); A_arbace_repr_go_types__init_A_const_20 = A_arbace_repr_go_types__init_A_const_pool.A[57]; A_arbace_repr_go_types__init_A_const_21 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[58]); A_arbace_repr_go_types__init_A_const_22 = A_arbace_repr_go_types__init_A_const_pool.A[59]; A_arbace_repr_go_types__init_A_const_23 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[60]); A_arbace_repr_go_types__init_A_const_24 = A_arbace_repr_go_types__init_A_const_pool.A[61]; A_arbace_repr_go_types__init_A_const_25 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[62]); A_arbace_repr_go_types__init_A_const_26 = A_arbace_repr_go_types__init_A_const_pool.A[63] }

func A_arbace_repr_go_types__init_A_clinit_p2() { A_arbace_repr_go_types__init_A_const_27 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[64]); A_arbace_repr_go_types__init_A_const_28 = A_arbace_repr_go_types__init_A_const_pool.A[65]; A_arbace_repr_go_types__init_A_const_29 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[66]); A_arbace_repr_go_types__init_A_const_30 = A_arbace_repr_go_types__init_A_const_pool.A[67]; A_arbace_repr_go_types__init_A_const_31 = A_arbace_repr_go_types__init_A_const_pool.A[68]; A_arbace_repr_go_types__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[69]); A_arbace_repr_go_types__init_A_const_33 = A_arbace_repr_go_types__init_A_const_pool.A[70]; A_arbace_repr_go_types__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[71]); A_arbace_repr_go_types__init_A_const_35 = A_arbace_repr_go_types__init_A_const_pool.A[72]; A_arbace_repr_go_types__init_A_const_36 = A_arbace_repr_go_types__init_A_const_pool.A[73]; A_arbace_repr_go_types__init_A_const_37 = lang.Var_Cast(A_arbace_repr_go_types__init_A_const_pool.A[74]); A_arbace_repr_go_types__init_A_const_38 = A_arbace_repr_go_types__init_A_const_pool.A[75] }

func A_arbace_repr_go_types__init_A_New() *A_arbace_repr_go_types__init_A { A_arbace_repr_go_types__init_A_Init(); t := &A_arbace_repr_go_types__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_types__init_A) Ctor() {}

func (t *A_arbace_repr_go_types__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_types__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_types__init_A_class }

func (t *A_arbace_repr_go_types__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_types__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_types__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_types__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_types__init_A); return ok }

func A_arbace_repr_go_types__init_A_Cast(x any) *A_arbace_repr_go_types__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_types__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_types__init_A_class)) }; return v }
