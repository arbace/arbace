//line aot_arbace_g2a_convert.ae:1
package aot_arbace_g2a_convert

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A_New() *A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_convert_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_convert_A_const_3, A_arbace_g2a_convert_A_const_4, A_arbace_g2a_convert_A_const_5); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_g2a_convert_eval838000008_fn__838000009_A_New() *A_arbace_g2a_convert_eval838000008_fn__838000009_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_eval838000008_fn__838000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_convert_eval838000008_fn__838000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_convert_eval838000008_fn__838000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_10), A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), A_arbace_g2a_convert_A_const_9) }





















func A_arbace_g2a_convert_note_BANG__A_New() *A_arbace_g2a_convert_note_BANG__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_note_BANG__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_g2a_convert_note_BANG__A) Ctor() {}
//line :23:1
func (t *A_arbace_g2a_convert_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_11.Get__O()) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_g2a_convert_A_const_11.Get__O(), A_arbace_g2a_convert_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_convert_A_const_15, k__0), lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_16.GetRawRoot__O(), A_arbace_g2a_convert_A_const_17)) } else { return nil } }
func A_arbace_g2a_convert_count_node_BANG__A_New() *A_arbace_g2a_convert_count_node_BANG__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_count_node_BANG__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_g2a_convert_count_node_BANG__A) Ctor() {}
//line :24:1
func (t *A_arbace_g2a_convert_count_node_BANG__A) Invoke_O_O__O(self, n__0 any) any { if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_11.Get__O()) { var tmp1 any = A_arbace_g2a_convert_A_const_18; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_g2a_convert_A_const_11.Get__O(), A_arbace_g2a_convert_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(n__0)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_16.GetRawRoot__O(), A_arbace_g2a_convert_A_const_17)) } else { return nil } }

func A_arbace_g2a_convert_fail_A_New() *A_arbace_g2a_convert_fail_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fail_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_g2a_convert_fail_A) Ctor() {}
//line :26:1
func (t *A_arbace_g2a_convert_fail_A) Invoke_O_O_O__O(self, msg__0, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_20.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_21.GetRawRoot__O()); var tmp4 any; if
											jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(n__1) } else { tmp4 = n__1 }; var tmp5 any = /*line :26:1*/tmp3.Invoke_O__O(tmp4); var tmp6 *jrt.String; var temp__1927000414__auto____7 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(n__1); if

	jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(n__1)); if jrt.A2g_Truth(and__1927000168__auto____8) { var G__838000015__9_ any = n__1; var G__838000015__10_ any; if lang.Util_Identical_O_O__Z(G__838000015__9_, nil) { G__838000015__10_ = nil } else { G__838000015__10_ = lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(G__838000015__9_) }; if lang.Util_Identical_O_O__Z(G__838000015__10_, nil) { temp__1927000414__auto____7 = nil } else { temp__1927000414__auto____7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(G__838000015__10_) } } else { temp__1927000414__auto____7 = and__1927000168__auto____8 } } else { temp__1927000414__auto____7 = and__1927000168__auto____7 }; if jrt.A2g_Truth(temp__1927000414__auto____7) { var p__8 any = temp__1927000414__auto____7; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_114, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_27.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_fail_fn__838000016_A_New(); var tmp11 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_convert_fail_fn__838000016_A_fn_class
		if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_g2a_convert_fail_fn__838000016_A_fn_class = fncls__1d; tmp11 = fncls__1d } else { tmp11 = fncls__1 }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), p__8)))) } else {
//line :28:1
			tmp6 = nil }; var tmp12 any = /*line :26:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, msg__0, nil, tmp5, tmp6.Ref())).Ref(); var tmp13 any = A_arbace_g2a_convert_A_const_26; var tmp14 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp14 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(n__1) } else { tmp14 = n__1 }; /*line :26:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)))))) }


func A_arbace_g2a_convert_fail_fn__838000016_A_New() *A_arbace_g2a_convert_fail_fn__838000016_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fail_fn__838000016_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_g2a_convert_fail_fn__838000016_A) Ctor() {}
//line :29:1
func (t *A_arbace_g2a_convert_fail_fn__838000016_A) Invoke_O_O__O(self, p1__838000014_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_28.GetRawRoot__O()).Invoke_O__O(p1__838000014_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_30, p1__838000014_SHARP___1) } else { return and__1927000168__auto____2 } }




func A_arbace_g2a_convert_nt_A_New() *A_arbace_g2a_convert_nt_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_nt_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_g2a_convert_nt_A) Ctor() {}
//line :34:1
func (t *A_arbace_g2a_convert_nt_A) Invoke_O_O__O(self, n__0 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(n__0)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(n__0) } else { return nil } }
func A_arbace_g2a_convert_nf_A_New() *A_arbace_g2a_convert_nf_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_nf_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_g2a_convert_nf_A) Ctor() {}
//line :35:1
func (t *A_arbace_g2a_convert_nf_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(n__0) }
func A_arbace_g2a_convert_an_A_New() *A_arbace_g2a_convert_an_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_an_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_g2a_convert_an_A) Ctor() {}
//line :36:1
func (t *A_arbace_g2a_convert_an_A) Invoke_O_O__O(self, n__0 any) any { return lang.RT_Meta_O__IPersistentMap(n__0) }

func A_arbace_g2a_convert_unparen_A_New() *A_arbace_g2a_convert_unparen_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_unparen_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_g2a_convert_unparen_A) Ctor() {}
//line :38:1
func (t *A_arbace_g2a_convert_unparen_A) Invoke_O_O__O(self, n__0 any) any { { var n__0_2 any = n__0; L1: for { var tmp1 any = A_arbace_g2a_convert_A_const_31; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0_2)) { var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_33; n__0_2 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0_2)); continue L1 } else { return n__0_2 } } }; panic("a2g: unreachable") }

func A_arbace_g2a_convert_parse_pos_A_New() *A_arbace_g2a_convert_parse_pos_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_parse_pos_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_g2a_convert_parse_pos_A) Ctor() {}
//line :40:1
func (t *A_arbace_g2a_convert_parse_pos_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = s__0; if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_35, s__0) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_26); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_17; return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(tmp2.Invoke_O_O_O__O(s__0, tmp3, jrt.Integer_ValueOf_I__Integer(i__2).Ref())))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(s__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__2))).Ref())))).Ref()) } else { return nil
	}
}

func A_arbace_g2a_convert_pos_line_A_New() *A_arbace_g2a_convert_pos_line_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_pos_line_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_g2a_convert_pos_line_A) Ctor() {}
//line :45:1
func (t *A_arbace_g2a_convert_pos_line_A) Invoke_O_O__O(self, s__0 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(s__0)) }

func A_arbace_g2a_convert_start_A_New() *A_arbace_g2a_convert_start_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_start_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_g2a_convert_start_A) Ctor() {}
//line :47:1
func (t *A_arbace_g2a_convert_start_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var G__838000025__3_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0); switch



	lang.Util_Hash_O__I(G__838000025__3_) >> 2 & 511 { case 4: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_38) {























		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_46.Invoke_O__O(f__2)) }
//line :51:1
	case 40: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_40) {











		return A_arbace_g2a_convert_A_const_41.Invoke_O__O(f__2) }
//line :51:1
	case 45: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_42) {

















		return A_arbace_g2a_convert_A_const_42.Invoke_O__O(f__2) }
//line :51:1
	case 58: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_43) {































		return A_arbace_g2a_convert_A_const_44.Invoke_O__O(f__2) }
//line :51:1
	case 66: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_47) {







































		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_48.Invoke_O__O(f__2)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_48.Invoke_O__O(f__2)) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_50.Invoke_O__O(f__2)) } }
//line :51:1
	case 80: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_49) {








































		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_53.Invoke_O__O(f__2))) }
//line :51:1
	case 93: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_51) {









		return A_arbace_g2a_convert_A_const_52.Invoke_O__O(f__2) }
//line :51:1
	case 95: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_54) {
		return A_arbace_g2a_convert_A_const_55.Invoke_O__O(f__2) }
//line :51:1
	case 98: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_56) {




























		return A_arbace_g2a_convert_A_const_57.Invoke_O__O(f__2) }
//line :51:1
	case 101: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_58) {


		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__2)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__2)) } else { return A_arbace_g2a_convert_A_const_60.Invoke_O__O(f__2) } }
//line :51:1
	case 109: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_61) {
















		return A_arbace_g2a_convert_A_const_62.Invoke_O__O(f__2) }
//line :51:1
	case 145: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_63) {



















		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_53.Invoke_O__O(f__2))) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_53.Invoke_O__O(f__2))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__2)) } }
//line :51:1
	case 154: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_65) {















		return A_arbace_g2a_convert_A_const_66.Invoke_O__O(f__2) }
//line :51:1
	case 160: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_67) {
































		return A_arbace_g2a_convert_A_const_68.Invoke_O__O(f__2) }
//line :51:1
	case 161: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_69) { var or__1927000174__auto____4 any = A_arbace_g2a_convert_A_const_70.Invoke_O__O(f__2)


















		if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var G__838000026__5_ any = A_arbace_g2a_convert_A_const_71.Invoke_O__O(f__2); var G__838000026__6_ any; if lang.Util_Identical_O_O__Z(G__838000026__5_, nil) { G__838000026__6_ = nil } else { G__838000026__6_ = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(G__838000026__5_) }; if lang.Util_Identical_O_O__Z(G__838000026__6_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(G__838000026__6_) } } }
//line :51:1
	case 185: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_72) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 186: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_73) {




















		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_75.Invoke_O__O(f__2)) }
//line :51:1
	case 190: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_74) {






















		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 195: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_76) {

























		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_78.Invoke_O__O(f__2))) }
//line :51:1
	case 197: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_77) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 221: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_79) {







		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_82.Invoke_O__O(f__2)) }
//line :51:1
	case 254: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_80) {














		return A_arbace_g2a_convert_A_const_81.Invoke_O__O(f__2) }
//line :51:1
	case 256: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_83) {










		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_85.Invoke_O__O(f__2)) }
//line :51:1
	case 262: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_84) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 271: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_86) {




































		return A_arbace_g2a_convert_A_const_87.Invoke_O__O(f__2) }
//line :51:1
	case 284: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_88) {









































		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_48.Invoke_O__O(f__2)) }
//line :51:1
	case 285: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_89) {





































		return A_arbace_g2a_convert_A_const_90.Invoke_O__O(f__2) }
//line :51:1
	case 297: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_91) {
























		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 302: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_92) {



































		return A_arbace_g2a_convert_A_const_93.Invoke_O__O(f__2) }
//line :51:1
	case 313: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_94) {





















		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_96.Invoke_O__O(f__2)) }
//line :51:1
	case 314: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_95) {



		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__2)) }
//line :51:1
	case 321: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_97) {








		return A_arbace_g2a_convert_A_const_98.Invoke_O__O(f__2) }
//line :51:1
	case 366: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_99) { var or__1927000174__auto____4_2 any = A_arbace_g2a_convert_A_const_100.Invoke_O__O(f__2)













		if jrt.A2g_Truth(or__1927000174__auto____4_2) { return or__1927000174__auto____4_2 } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_102.Invoke_O__O(f__2)) } }
//line :51:1
	case 370: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_101) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 384: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_103) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 392: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_104) {

































		return A_arbace_g2a_convert_A_const_105.Invoke_O__O(f__2) }
//line :51:1
	case 400: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_106) {



























		return A_arbace_g2a_convert_A_const_107.Invoke_O__O(f__2) }
//line :51:1
	case 410: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_108) {

		return A_arbace_g2a_convert_A_const_109.Invoke_O__O(f__2) }
//line :51:1
	case 416: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_110) {

































		return A_arbace_g2a_convert_A_const_105.Invoke_O__O(f__2) }
//line :51:1
	case 428: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_111) {












		return A_arbace_g2a_convert_A_const_112.Invoke_O__O(f__2) }
//line :51:1
	case 436: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_113) {



































		return A_arbace_g2a_convert_A_const_93.Invoke_O__O(f__2) }
//line :51:1
	case 444: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_31) {




		return A_arbace_g2a_convert_A_const_114.Invoke_O__O(f__2) }
//line :51:1
	case 458: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_115) {






		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :51:1
	case 465: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_116) {


































		return A_arbace_g2a_convert_A_const_117.Invoke_O__O(f__2) }
//line :51:1
	case 473: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_118) {





























		return A_arbace_g2a_convert_A_const_90.Invoke_O__O(f__2) }
//line :51:1
	case 482: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_119) {


























		return A_arbace_g2a_convert_A_const_120.Invoke_O__O(f__2) }
//line :51:1
	case 485: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_121) {
































		return A_arbace_g2a_convert_A_const_68.Invoke_O__O(f__2) }
//line :51:1
	case 489: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_122) {






































		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__2)) }
//line :51:1
	case 491: if any(G__838000025__3_) == any(A_arbace_g2a_convert_A_const_123) {






























		return A_arbace_g2a_convert_A_const_60.Invoke_O__O(f__2) }
//line :51:1
	default:}; return /*line :94:1*/ lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_162, n__0) }

func A_arbace_g2a_convert_line_of_A_New() *A_arbace_g2a_convert_line_of_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_line_of_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_g2a_convert_line_of_A) Ctor() {}
//line :96:1
func (t *A_arbace_g2a_convert_line_of_A) Invoke_O_O__O(self, n__0 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_g2a_convert_positions_A_New() *A_arbace_g2a_convert_positions_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_positions_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_g2a_convert_positions_A) Ctor() {}
//line :98:1
func (t *A_arbace_g2a_convert_positions_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_126.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_127.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_positions_fn__838000030_A_New(); var tmp5 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_convert_positions_fn__838000030_A_fn_class
	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_g2a_convert_positions_fn__838000030_A_fn_class = fncls__3d; tmp5 = fncls__3d } else { tmp5 = fncls__3 }
//line :101:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0)) }
func A_arbace_g2a_convert_positions_fn__838000030_A_New() *A_arbace_g2a_convert_positions_fn__838000030_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_positions_fn__838000030_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_convert_positions_fn__838000030_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_convert_positions_fn__838000030_A) Invoke_O_O__O(self, p__838000029__1 any) any { var vec__838000031__2 any = p__838000029__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__838000031__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__838000031__2, lang.RT_IntCast_J__I(1), nil); var temp__1927000414__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_28.GetRawRoot__O()).Invoke_O__O(v__4); if jrt.A2g_Truth(and__1927000168__auto____5) { temp__1927000414__auto____5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(v__4) } else { temp__1927000414__auto____5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(temp__1927000414__auto____5) { var p__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(k__3, p__6) } else { return nil } }


func A_arbace_g2a_convert_max_pos_A_New() *A_arbace_g2a_convert_max_pos_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_max_pos_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_g2a_convert_max_pos_A) Ctor() {}
//line :105:1
func (t *A_arbace_g2a_convert_max_pos_A) Invoke_O_O__O(self, n__0 any) any { var best__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_128.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_136); var walk__3 any; var tmp1 any = A_arbace_g2a_convert_max_pos_walk__838000036_A_New_O(best__2); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_convert_max_pos_walk__838000036_A_fn_class; if



	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_g2a_convert_max_pos_walk__838000036_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);






	lang.IFn_Cast(walk__3).Invoke_O__O(n__0); return /*line :108:1*/ lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(best__2) }
func A_arbace_g2a_convert_max_pos_walk__838000036_A_New_O(p0 any) *A_arbace_g2a_convert_max_pos_walk__838000036_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_max_pos_walk__838000036_A{}; t.Ctor_O(p0); return t }
//line :109:1
func (t *A_arbace_g2a_convert_max_pos_walk__838000036_A) Ctor_O(c__best any) { t.F_best = c__best }
//line :109:1
func (t *A_arbace_g2a_convert_max_pos_walk__838000036_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(x__1)) {
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(x__1))) { var seq_838000037__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(x__1))); var chunk_838000038__3 any; var count_838000039__4 int64 = 0; var i_838000040__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_838000040__5, count_838000039__4) { var v__6 any = lang.Indexed_Cast(chunk_838000038__3).Nth_I__O(lang.RT_IntCast_J__I(i_838000040__5)); lang.IFn_Cast(self).Invoke_O__O(v__6); seq_838000037__2, chunk_838000038__3, count_838000039__4, i_838000040__5 = seq_838000037__2, chunk_838000038__3, count_838000039__4, lang.Numbers_Unchecked_inc_J__J(i_838000040__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(seq_838000037__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_838000037__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(seq_838000037__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_838000037__7); seq_838000037__2, chunk_838000038__3, count_838000039__4, i_838000040__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(seq_838000037__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_838000037__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_838000037__2, chunk_838000038__3, count_838000039__4, i_838000040__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000037__7), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :111:1
				return nil } } else {
//line :110:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(x__1)) {


						return lang.IFn_Cast(A_arbace_g2a_convert_A_const_132.GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :110:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_28.GetRawRoot__O()).Invoke_O__O(x__1)) { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(x__1)



								if jrt.A2g_Truth(temp__1927000414__auto____2) { var p__3 any = temp__1927000414__auto____2
									if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(p__3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_best)))) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_133.GetRawRoot__O()).Invoke_O_O__O(t.F_best, p__3) } else { return nil } } else {
//line :114:1
										return nil } } else {
//line :110:1
											return nil } } }
//line :109:1
	panic("a2g: unreachable")
}










func A_arbace_g2a_convert_form_A_New() *A_arbace_g2a_convert_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_form_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_g2a_convert_form_A) Ctor() {}
//line :121:1
func (t *A_arbace_g2a_convert_form_A) DoInvoke_O_O_O_O__O(self, n__0, l__1, xs__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_141.GetRawRoot__O(), xs__2); var tmp3 any; var G__838000043__4_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_139, l__1)); if jrt.A2g_Truth(n__0) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_142; tmp3 = tmp4.Invoke_O_O_O__O(G__838000043__4_, tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_143.GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp3 = G__838000043__4_ }; return tmp1.Invoke_O_O__O(tmp2, tmp3)
}
func A_arbace_g2a_convert_at_A_New() *A_arbace_g2a_convert_at_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_at_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_g2a_convert_at_A) Ctor() {}
//line :126:1
func (t *A_arbace_g2a_convert_at_A) Invoke_O_O_O_O__O(self, x__0, n__1, l__2 any) any {


	if lang.IObj_InstanceOf(x__0) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_at_fn__838000046_A_New_O_O(l__2, n__1); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_convert_at_fn__838000046_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_g2a_convert_at_fn__838000046_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return tmp1.Invoke_O_O__O(x__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
//line :129:1
			return x__0 } }
func A_arbace_g2a_convert_at_fn__838000046_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_at_fn__838000046_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_at_fn__838000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_g2a_convert_at_fn__838000046_A) Ctor_O_O(c__l, c__n any) { t.F_l = c__l; t.F_n = c__n }
//line :130:1
func (t *A_arbace_g2a_convert_at_fn__838000046_A) Invoke_O_O__O(self, m__1 any) any { var G__838000047__2_ any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = m__1; if jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp3 any = tmp2; var tmp4 any = A_arbace_g2a_convert_A_const_139; var tmp5 any; var or__1927000174__auto____2_2 any = A_arbace_g2a_convert_A_const_139.Invoke_O__O(m__1); if jrt.A2g_Truth(or__1927000174__auto____2_2) { tmp5 = or__1927000174__auto____2_2 } else { tmp5 = t.F_l }; G__838000047__2_ = tmp1.Invoke_O_O_O__O(tmp3, tmp4, tmp5); if jrt.A2g_Truth(t.F_n) {
											var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_142; var tmp8 any = A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A_New_O(t.F_n); var tmp9 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A_fn_class = fncls__5d; tmp9 = fncls__5d } else { tmp9 = fncls__5 }; return tmp6.Invoke_O_O_O__O(G__838000047__2_, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :130:1
		return G__838000047__2_ } }
func A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A_New_O(p0 any) *A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A{}; t.Ctor_O(p0); return t }
//line :131:1
func (t *A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :131:1
func (t *A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A) Invoke_O_O__O(self, p1__838000045_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_143.GetRawRoot__O()).Invoke_O__O(t.F_n), p1__838000045_SHARP___1) }


func A_arbace_g2a_convert_line_A_New() *A_arbace_g2a_convert_line_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_line_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_g2a_convert_line_A) Ctor() {}
//line :134:1
func (t *A_arbace_g2a_convert_line_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_139; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) }

func A_arbace_g2a_convert_with_pos_A_New() *A_arbace_g2a_convert_with_pos_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_with_pos_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_g2a_convert_with_pos_A) Ctor() {}
//line :136:1
func (t *A_arbace_g2a_convert_with_pos_A) Invoke_O_O_O__O(self, x__0, m__1 any) any { var ps__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;


	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_127.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_with_pos_fn__838000055_A_New(); var tmp6 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_convert_with_pos_fn__838000055_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_186, false); A_arbace_g2a_convert_with_pos_fn__838000055_A_fn_class = fncls__7d; tmp6 = fncls__7d } else { tmp6 = fncls__7 }; ps__3 = tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)), m__1); var tmp7 any; var and__1927000168__auto____4 any =
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(ps__3); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(x__0)).Ref() } else { tmp7 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_A_const_145.GetRawRoot__O(); var tmp10 any = A_arbace_g2a_convert_A_const_142; var tmp11 any = A_arbace_g2a_convert_with_pos_fn__838000060_A_New_O(ps__3); var tmp12 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_convert_with_pos_fn__838000060_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_187, false); A_arbace_g2a_convert_with_pos_fn__838000060_A_fn_class = fncls__8d; tmp12 = fncls__8d } else { tmp12 = fncls__8 }; return tmp8.Invoke_O_O_O_O__O(x__0, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)) } else {
//line :140:1
			return x__0 } }
//line :139:1
func A_arbace_g2a_convert_with_pos_fn__838000055_A_New() *A_arbace_g2a_convert_with_pos_fn__838000055_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_with_pos_fn__838000055_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_g2a_convert_with_pos_fn__838000055_A) Ctor() {}
//line :139:1
func (t *A_arbace_g2a_convert_with_pos_fn__838000055_A) Invoke_O_O__O(self, p__838000054__1 any) any { var vec__838000056__2 any = p__838000054__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__838000056__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__838000056__2, lang.RT_IntCast_J__I(1), nil); var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(v__4); if jrt.A2g_Truth(temp__1927000414__auto____5) { var p__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(k__3, p__6) } else { return nil } }

func A_arbace_g2a_convert_with_pos_fn__838000060_A_New_O(p0 any) *A_arbace_g2a_convert_with_pos_fn__838000060_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_with_pos_fn__838000060_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_g2a_convert_with_pos_fn__838000060_A) Ctor_O(c__ps any) { t.F_ps = c__ps }
//line :141:1
func (t *A_arbace_g2a_convert_with_pos_fn__838000060_A) Invoke_O_O__O(self, p1__838000053_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = p1__838000053_SHARP___1; if jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_126.GetRawRoot__O()).Invoke__O() }; return tmp1.Invoke_O_O__O(tmp2, t.F_ps) }


func A_arbace_g2a_convert_block_pos_A_New() *A_arbace_g2a_convert_block_pos_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_block_pos_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_g2a_convert_block_pos_A) Ctor() {}
//line :144:1
func (t *A_arbace_g2a_convert_block_pos_A) Invoke_O_O__O(self, b__0 any) any { if jrt.A2g_Truth(b__0) { var tmp1 any = A_arbace_g2a_convert_A_const_60; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_60; var tmp3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(b__0)); var tmp4 any = A_arbace_g2a_convert_A_const_147; var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_147; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(b__0)))) } else { return nil } }

func A_arbace_g2a_convert_with_line_A_New() *A_arbace_g2a_convert_with_line_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_with_line_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_g2a_convert_with_line_A) Ctor() {}
//line :146:1
func (t *A_arbace_g2a_convert_with_line_A) Invoke_O_O_O__O(self, l__0, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.IObj_InstanceOf(x__1); if and__1927000168__auto____3 { tmp1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_149.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()).Invoke_O_O_O_O__O(x__1, A_arbace_g2a_convert_A_const_140.GetRawRoot__O(), A_arbace_g2a_convert_A_const_139, l__0) } else { return x__1
	} }
func A_arbace_g2a_convert_vec_at_A_New() *A_arbace_g2a_convert_vec_at_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_vec_at_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_g2a_convert_vec_at_A) Ctor() {}
//line :149:1
func (t *A_arbace_g2a_convert_vec_at_A) Invoke_O_O_O__O(self, l__0, xs__1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(xs__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_139, l__0))) }

func A_arbace_g2a_convert_add_meta_A_New() *A_arbace_g2a_convert_add_meta_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_add_meta_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_g2a_convert_add_meta_A) Ctor() {}
//line :151:1
func (t *A_arbace_g2a_convert_add_meta_A) Invoke_O_O_O__O(self, x__0, m__1 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(m__1)) { return x__0 } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_g2a_convert_A_const_146.GetRawRoot__O(), m__1)
	} }
func A_arbace_g2a_convert_lit_at_A_New() *A_arbace_g2a_convert_lit_at_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_lit_at_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_g2a_convert_lit_at_A) Ctor() {}
//line :156:1
func (t *A_arbace_g2a_convert_lit_at_A) Invoke_O_O_O_O__O(self, l__0, x__1, pos__2 any) any {


	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O_O_O__O(x__1, A_arbace_g2a_convert_A_const_152, l__0, A_arbace_g2a_convert_A_const_153, pos__2)
}
func A_arbace_g2a_convert_relined_A_New() *A_arbace_g2a_convert_relined_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_relined_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_g2a_convert_relined_A) Ctor() {}
//line :161:1
func (t *A_arbace_g2a_convert_relined_A) Invoke_O_O_O__O(self, l__0, x__1 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_154.GetRawRoot__O()).Invoke_O__O(x__1)) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O_O_O__O(x__1, A_arbace_g2a_convert_A_const_152, l__0, A_arbace_g2a_convert_A_const_153, nil) } else {
//line :164:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(x__1)) {

				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_relined_fn__838000071_A_New_O(l__0); var tmp6 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_convert_relined_fn__838000071_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_158, false); A_arbace_g2a_convert_relined_fn__838000071_A_fn_class = fncls__9d; tmp6 = fncls__9d } else { tmp6 = fncls__9 }; return tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), x__1)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_g2a_convert_A_const_139, l__0), A_arbace_g2a_convert_A_const_142)) } else {
//line :164:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(x__1)) {



						var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_relined_fn__838000073_A_New_O(l__0); var tmp10 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_convert_relined_fn__838000073_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_g2a_convert_relined_fn__838000073_A_fn_class = fncls__10d; tmp10 = fncls__10d } else { tmp10 = fncls__10 }; return tmp7.Invoke_O_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), x__1), lang.IFn_Cast(A_arbace_g2a_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(x__1), A_arbace_g2a_convert_A_const_139, l__0), A_arbace_g2a_convert_A_const_142)) } else {
//line :164:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(x__1)) {




								var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_convert_relined_fn__838000075_A_New_O(l__0); var tmp13 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_convert_relined_fn__838000075_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_g2a_convert_relined_fn__838000075_A_fn_class = fncls__11d; tmp13 = fncls__11d } else { tmp13 = fncls__11 }; return tmp11.Invoke_O_O__O(x__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)) } else {
//line :164:1
									if A_arbace_g2a_convert_A_const_156 != nil { return x__1 } else { return nil
									} } } } } }
func A_arbace_g2a_convert_relined_fn__838000071_A_New_O(p0 any) *A_arbace_g2a_convert_relined_fn__838000071_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_relined_fn__838000071_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_g2a_convert_relined_fn__838000071_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :166:1
func (t *A_arbace_g2a_convert_relined_fn__838000071_A) Invoke_O_O__O(self, p1__838000068_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_159.GetRawRoot__O()).Invoke_O_O__O(t.F_l, p1__838000068_SHARP___1) }

func A_arbace_g2a_convert_relined_fn__838000073_A_New_O(p0 any) *A_arbace_g2a_convert_relined_fn__838000073_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_relined_fn__838000073_A{}; t.Ctor_O(p0); return t }
//line :168:1
func (t *A_arbace_g2a_convert_relined_fn__838000073_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :168:1
func (t *A_arbace_g2a_convert_relined_fn__838000073_A) Invoke_O_O__O(self, p1__838000069_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_159.GetRawRoot__O()).Invoke_O_O__O(t.F_l, p1__838000069_SHARP___1) }
func A_arbace_g2a_convert_relined_fn__838000075_A_New_O(p0 any) *A_arbace_g2a_convert_relined_fn__838000075_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_relined_fn__838000075_A{}; t.Ctor_O(p0); return t }
//line :169:1
func (t *A_arbace_g2a_convert_relined_fn__838000075_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :169:1
func (t *A_arbace_g2a_convert_relined_fn__838000075_A) Invoke_O_O__O(self, p1__838000070_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O__O(p1__838000070_SHARP___1, A_arbace_g2a_convert_A_const_139, t.F_l), A_arbace_g2a_convert_A_const_142) }




















func A_arbace_g2a_convert_ident_name_A_New() *A_arbace_g2a_convert_ident_name_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_ident_name_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_g2a_convert_ident_name_A) Ctor() {}
//line :190:1
func (t *A_arbace_g2a_convert_ident_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_48; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_g2a_convert_obj_A_New() *A_arbace_g2a_convert_obj_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_obj_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_g2a_convert_obj_A) Ctor() {}
//line :192:1
func (t *A_arbace_g2a_convert_obj_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_161; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_163; return tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)) } }

func A_arbace_g2a_convert_targs_A_New() *A_arbace_g2a_convert_targs_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_targs_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_g2a_convert_targs_A) Ctor() {}
//line :194:1
func (t *A_arbace_g2a_convert_targs_A) Invoke_O_O__O(self, inst__0 any) any {


	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_164.GetRawRoot__O(), A_arbace_g2a_convert_A_const_165.Invoke_O__O(inst__0))
}
func A_arbace_g2a_convert_inst_meta_A_New() *A_arbace_g2a_convert_inst_meta_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_inst_meta_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_g2a_convert_inst_meta_A) Ctor() {}
//line :199:1
func (t *A_arbace_g2a_convert_inst_meta_A) Invoke_O_O_O__O(self, n__0, explicit__1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_166; var inst__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)); var o__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_167.GetRawRoot__O()).Invoke_O__O(n__0); var tmp2 any; var and__1927000168__auto____5 any = inst__3; if





	jrt.A2g_Truth(and__1927000168__auto____5) { var tmp3 any = A_arbace_g2a_convert_A_const_100; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_g2a_convert_A_const_168.Invoke_O__O(o__4)); if and__1927000168__auto____6 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_J__Z(explicit__1, int64(lang.RT_Count_O__I(A_arbace_g2a_convert_A_const_165.Invoke_O__O(inst__3))))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp2 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp2) { var tmp4 any = A_arbace_g2a_convert_A_const_166; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_169.GetRawRoot__O()).Invoke_O__O(inst__3))) } else { return nil } }


func A_arbace_g2a_convert_ident_A_New() *A_arbace_g2a_convert_ident_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_ident_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_g2a_convert_ident_A) Ctor() {}
//line :208:1
func (t *A_arbace_g2a_convert_ident_A) Invoke_O_O_O__O(self, n__0, explicit__1 any) any {



	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :208:1
	var name__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var o__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_167.GetRawRoot__O()).Invoke_O__O(n__0)







	if lang.Util_Equiv_O_O__Z(name__3, Lit_22) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(Lit_22), n__0, l__4) } else {
//line :216:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_173).Invoke_O__O(name__3)) {


				var tmp1 any; var or__1927000174__auto____6 any = A_arbace_g2a_convert_A_const_174.Invoke_O__O(o__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var tmp2 any = A_arbace_g2a_convert_A_const_175; var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_176; var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0))); if or__1927000174__auto____7 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(o__5, nil); if and__1927000168__auto____8 { var tmp4 any = A_arbace_g2a_convert_A_const_177; var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_176; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } }; if jrt.A2g_Truth(tmp1) {
					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(l__4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(name__3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_184).Invoke_O__O(name__3)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(n__0))) } else {
						lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_186); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_187; return tmp6.Invoke_O_O_O_O__O(n__0, l__4, tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(name__3), name__3)) } } else {
//line :216:1
							if A_arbace_g2a_convert_A_const_156 != nil {





								return lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(name__3), n__0, l__4), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(n__0, explicit__1)) } else {
//line :216:1
									return nil } } } }
//line :208:1
func (t *A_arbace_g2a_convert_ident_A) Invoke_O_O__O(self, n__0 any) any {

	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(n__0, A_arbace_g2a_convert_A_const_17)
}












func A_arbace_g2a_convert_label_kw_A_New() *A_arbace_g2a_convert_label_kw_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_label_kw_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_g2a_convert_label_kw_A) Ctor() {}
//line :224:1
func (t *A_arbace_g2a_convert_label_kw_A) Invoke_O_O__O(self, n__0 any) any { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__0)) }

func A_arbace_g2a_convert_pkg_ident_QMARK__A_New() *A_arbace_g2a_convert_pkg_ident_QMARK__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_pkg_ident_QMARK__A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_g2a_convert_pkg_ident_QMARK__A) Ctor() {}
//line :226:1
func (t *A_arbace_g2a_convert_pkg_ident_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_g2a_convert_A_const_192; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_168; var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_161; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(n__0)))))).Ref() }



func A_arbace_g2a_convert_basic_lit_A_New() *A_arbace_g2a_convert_basic_lit_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_basic_lit_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_g2a_convert_basic_lit_A) Ctor() {}
//line :230:1
func (t *A_arbace_g2a_convert_basic_lit_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :230:1
	var map__838000085__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000085__3 any

	if lang.ISeq_InstanceOf(map__838000085__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000085__2)) { map__838000085__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000085__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000085__2)) { map__838000085__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000085__2) } else { lang.PersistentArrayMap_Init(); map__838000085__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000085__3 = map__838000085__2 }
//line :230:1
	var kind__4 any = lang.RT_Get_O_O__O(map__838000085__3, A_arbace_g2a_convert_A_const_168); var value__5 any = lang.RT_Get_O_O__O(map__838000085__3, A_arbace_g2a_convert_A_const_195); var l__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var p__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(n__0))
	var G__838000087__8_ any = kind__4



	switch lang.Util_Hash_O__I(G__838000087__8_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__838000087__8_, Lit_8) { var r__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_196.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(value__5))






		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_154.GetRawRoot__O()).Invoke_O__O(r__9)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(l__6, r__9, p__7) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(r__9, nil), n__0, l__6) } }
//line :235:1
	case 2: if lang.Util_Equiv_O_O__Z(G__838000087__8_, Lit_9) {


		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_199; return tmp1.Invoke_O_O_O_O__O(n__0, l__6, tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_200.GetRawRoot__O()).Invoke_O__O(value__5)) }
//line :235:1
	case 4: if lang.Util_Equiv_O_O__Z(G__838000087__8_, Lit_10) {

		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(l__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_201.GetRawRoot__O()).Invoke_O__O(value__5), p__7) }
//line :235:1
	case 6: if lang.Util_Equiv_O_O__Z(G__838000087__8_, Lit_11) { var r__9_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_197.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_202.GetRawRoot__O()).Invoke_O__O(value__5))




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_154.GetRawRoot__O()).Invoke_O__O(r__9_2)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(l__6, r__9_2, p__7) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(r__9_2, nil), n__0, l__6) } }
//line :235:1
	case 7: if lang.Util_Equiv_O_O__Z(G__838000087__8_, Lit_12) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(l__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_203.GetRawRoot__O()).Invoke_O__O(value__5), p__7) }
//line :235:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__838000087__8_)))))
}







func A_arbace_g2a_convert_string_value_A_New() *A_arbace_g2a_convert_string_value_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_string_value_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_g2a_convert_string_value_A) Ctor() {}
//line :244:1
func (t *A_arbace_g2a_convert_string_value_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_195; return jrt.String_New_B1_Charset(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_198.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0))), jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) }








func A_arbace_g2a_convert_tagged_A_New() *A_arbace_g2a_convert_tagged_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_tagged_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_g2a_convert_tagged_A) Ctor() {}
//line :253:1
func (t *A_arbace_g2a_convert_tagged_A) Invoke_O_O_O__O(self, sym__0, t__1 any) any {


	if jrt.A2g_Truth(t__1) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()).Invoke_O_O_O_O__O(sym__0, A_arbace_g2a_convert_A_const_140.GetRawRoot__O(), A_arbace_g2a_convert_A_const_204, t__1) } else { return sym__0
	} }
func A_arbace_g2a_convert_group_marks_A_New() *A_arbace_g2a_convert_group_marks_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_group_marks_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_g2a_convert_group_marks_A) Ctor() {}
//line :258:1
func (t *A_arbace_g2a_convert_group_marks_A) Invoke_O_O__O(self, syms__0 any) any {



	if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_205.Get__O()) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(syms__0); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_group_marks_fn__838000092_A_New(); var tmp5 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_convert_group_marks_fn__838000092_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_g2a_convert_group_marks_fn__838000092_A_fn_class = fncls__13d; tmp5 = fncls__13d } else { tmp5 = fncls__13 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(syms__0))) } else {
//line :262:1
			return syms__0 } }
func A_arbace_g2a_convert_group_marks_fn__838000092_A_New() *A_arbace_g2a_convert_group_marks_fn__838000092_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_group_marks_fn__838000092_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_g2a_convert_group_marks_fn__838000092_A) Ctor() {}
//line :263:1
func (t *A_arbace_g2a_convert_group_marks_fn__838000092_A) Invoke_O_O__O(self, p1__838000091_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp3 any = A_arbace_g2a_convert_A_const_207; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O_O_O__O(p1__838000091_SHARP___1, tmp2, tmp3, tmp4.Ref()) }


func A_arbace_g2a_convert_mark_ungrouped_A_New() *A_arbace_g2a_convert_mark_ungrouped_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_mark_ungrouped_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_g2a_convert_mark_ungrouped_A) Ctor() {}
//line :266:1
func (t *A_arbace_g2a_convert_mark_ungrouped_A) Invoke_O_O_O__O(self, elems__0, names_only__1 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_205.Get__O())) { return elems__0 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A_New_O_O(names_only__1, elems__0); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A_fn_class
		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }
//line :272:1
		return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), elems__0)) } }
func A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A) Ctor_O_O(c__names_only, c__elems any) { t.F_names_only = c__names_only; t.F_elems = c__elems }
//line :273:1
func (t *A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var prev__3 any; if
													lang.Numbers_IsPos_O__Z(i__1) { var tmp1 any = t.F_elems; prev__3 = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(lang.Numbers_Dec_O__Number(i__1))) } else { prev__3 = nil }; var tmp2 any; var and__1927000168__auto____4 any =
													lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(x__2); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(prev__3); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_210.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(x__2), A_arbace_g2a_convert_A_const_207)); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(t.F_names_only)
														if jrt.A2g_Truth(or__1927000174__auto____7) { and__1927000168__auto____7 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_204; var and__1927000168__auto____8 any = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__2)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_204; and__1927000168__auto____7 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(prev__3)) } else { and__1927000168__auto____7 = and__1927000168__auto____8 } }
//line :275:1
		if jrt.A2g_Truth(and__1927000168__auto____7) {

			var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_204; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_204; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__2)), tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(prev__3)))).Ref() } else {
//line :275:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp2) {


					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp9 any = A_arbace_g2a_convert_A_const_207; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; return tmp7.Invoke_O_O_O_O__O(x__2, tmp8, tmp9, tmp10.Ref()) } else {
//line :275:1
						return x__2 } }






func A_arbace_g2a_convert_doc_of_A_New() *A_arbace_g2a_convert_doc_of_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_doc_of_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_g2a_convert_doc_of_A) Ctor() {}
//line :282:1
func (t *A_arbace_g2a_convert_doc_of_A) Invoke_O_O_O__O(self, pos_str__0, groups__1 any) any {


	if jrt.A2g_Truth(pos_str__0) { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O(groups__1, pos_str__0)
		if jrt.A2g_Truth(temp__1927000414__auto____3) { var g__4 any = temp__1927000414__auto____3
			if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_213.Get__O()) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_convert_A_const_213.Get__O(), A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), pos_str__0) }
//line :286:1
			var t__5 any = A_arbace_g2a_convert_A_const_211.Invoke_O__O(g__4); var tmp1 any
			var and__1927000168__auto____6 any = t__5

			if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(t__5, Lit_7) } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { return t__5 } else { return nil } } else {
//line :286:1
				return nil } } else {
//line :285:1
					return nil
				}
}





func A_arbace_g2a_convert_fields_A_New() *A_arbace_g2a_convert_fields_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fields_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_g2a_convert_fields_A) Ctor() {}
//line :293:1
func (t *A_arbace_g2a_convert_fields_A) Invoke_O_O_O__O(self, field_list__0, p__838000099__1 any) any { var map__838000100__3 any = p__838000099__1; var map__838000100__4 any; if lang.ISeq_InstanceOf(map__838000100__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000100__3)) { map__838000100__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000100__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000100__3)) { map__838000100__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000100__3) } else { lang.PersistentArrayMap_Init(); map__838000100__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000100__4 = map__838000100__3 }; var struct_QMARK___5 any = lang.RT_Get_O_O__O(map__838000100__4, A_arbace_g2a_convert_A_const_214);




	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(field_list__0); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_215.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_fields_fn__838000102_A_New_O(struct_QMARK___5); var tmp5 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_convert_fields_fn__838000102_A_fn_class; if


	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_g2a_convert_fields_fn__838000102_A_fn_class = fncls__18d; tmp5 = fncls__18d } else { tmp5 = fncls__18 }; var tmp6 /*line :299:1*/*lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp7 any = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(field_list__0)))); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp7, tmp8.Ref()) }


func A_arbace_g2a_convert_fields_fn__838000102_A_New_O(p0 any) *A_arbace_g2a_convert_fields_fn__838000102_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fields_fn__838000102_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_A) Ctor_O(c__struct_QMARK_ any) { t.F_struct_QMARK_ = c__struct_QMARK_ }
//line :302:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_A) Invoke_O_O__O(self, fld__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__1)
//line :302:1
	var map__838000103__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fld__1); var map__838000103__3 any

	if lang.ISeq_InstanceOf(map__838000103__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000103__2)) { map__838000103__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000103__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000103__2)) { map__838000103__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000103__2) } else { lang.PersistentArrayMap_Init(); map__838000103__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000103__3 = map__838000103__2 }
//line :302:1
	var names__4 any = lang.RT_Get_O_O__O(map__838000103__3, A_arbace_g2a_convert_A_const_53); var type__5 any = lang.RT_Get_O_O__O(map__838000103__3, A_arbace_g2a_convert_A_const_59); var tag__6 any = lang.RT_Get_O_O__O(map__838000103__3, A_arbace_g2a_convert_A_const_204); var doc__7 any = lang.RT_Get_O_O__O(map__838000103__3, A_arbace_g2a_convert_A_const_217); var tmp1 any = A_arbace_g2a_convert_A_const_42; var variadic__8 bool = lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(type__5)); var ___9 any; _ = ___9



	if variadic__8 { ___9 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__5) } else { ___9 = nil }
//line :302:1
	var ___10 any; var tmp2 any; var and__1927000168__auto____10 any = t.F_struct_QMARK_; _ = ___10




	if jrt.A2g_Truth(and__1927000168__auto____10) { tmp2 = tag__6 } else { tmp2 = and__1927000168__auto____10 }; if jrt.A2g_Truth(tmp2) { ___10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tag__6) } else { ___10 = nil }
//line :302:1
	var t__11 any





	if variadic__8 {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(type__5); var tmp5 any = A_arbace_g2a_convert_A_const_221; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_222; t__11 = tmp3.Invoke_O_O_O_O__O(type__5, tmp4, tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__5)))) } else {
			t__11 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__5) }
//line :302:1
	var extra__12 any; var G__838000105__12_ any; lang.PersistentArrayMap_Init(); G__838000105__12_ = lang.PersistentArrayMap_EMPTY.Ref(); var G__838000105__13_ any; var tmp7 any; var and__1927000168__auto____13 any = t.F_struct_QMARK_









	if jrt.A2g_Truth(and__1927000168__auto____13) { tmp7 = tag__6 } else { tmp7 = and__1927000168__auto____13 }
//line :311:1
	if jrt.A2g_Truth(tmp7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_A_const_223; G__838000105__13_ = tmp8.Invoke_O_O_O__O(G__838000105__12_, tmp9, lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(tag__6)) } else {
//line :311:1
			G__838000105__13_ = G__838000105__12_ }; var tmp10 any; var and__1927000168__auto____14 any = t.F_struct_QMARK_

	if jrt.A2g_Truth(and__1927000168__auto____14) { tmp10 = doc__7 } else { tmp10 = and__1927000168__auto____14 }
//line :311:1
	if jrt.A2g_Truth(tmp10) { var m__14 any = G__838000105__13_; var temp__1927000408__auto____15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_g2a_convert_A_const_225.Get__O())

		if jrt.A2g_Truth(temp__1927000408__auto____15) { var d__16 any = temp__1927000408__auto____15; extra__12 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O__O(m__14, A_arbace_g2a_convert_A_const_217, d__16) } else { extra__12 = m__14 } } else {
//line :311:1
			extra__12 = G__838000105__13_
		}

	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp12 any
	if variadic__8 { tmp12 = A_arbace_g2a_convert_A_const_226 } else { tmp12 = nil }
//line :314:1
	var tmp13 any = tmp12; var tmp14 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(names__4)) {
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_227.GetRawRoot__O()); var tmp16 any; var iter__1927001039__auto____13 any; var tmp17 any = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A_New_O_O(extra__12, t__11); var tmp18 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A_fn_class
		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A_fn_class = fncls__17d; tmp18 = fncls__17d } else { tmp18 = fncls__17 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(names__4)
//line :317:1
		tmp14 = tmp15.Invoke_O__O(tmp16) } else {
//line :316:1
			tmp14 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(t__11, extra__12)) }
//line :314:1
	return tmp11.Invoke_O_O__O(tmp13, tmp14)
}


func A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A{}; t.Ctor_O_O(p0, p1); return t }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A) Ctor_O_O(c__extra, c__t any) { t.F_extra = c__extra; t.F_t = c__t }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A) Invoke_O_O__O(self, s__838000107__1 any) any { var tmp1 any = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A_New_O_O_O_O(t.F_extra, t.F_t, self, s__838000107__1); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :318:1
func A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A) Ctor_O_O_O_O(c__extra, c__t, c__iter__838000106, c__s__838000107 any) { t.F_extra = c__extra; t.F_t = c__t; t.F_iter__838000106 = c__iter__838000106; t.F_s__838000107 = c__s__838000107 }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A) Invoke_O__O(self any) any { { var s__838000107__1 any; var t_ any = t.F_s__838000107; t.F_s__838000107 = nil; s__838000107__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000107__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000107__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000107__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000107__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000109__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A_New_O_O_I_O_O(t.F_extra, t.F_t, size__1927001038__auto____5, c__1927001037__auto____4, b__838000109__6); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000106); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000109__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000107__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000109__6), nil) } } else { var nm__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000107__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__838000106); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__4), t.F_t), t.F_extra), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000107__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :318:1
func A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A) Ctor_O_O_I_O_O(c__extra, c__t any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__838000109 any) { t.F_extra = c__extra; t.F_t = c__t; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__838000109 = c__b__838000109 }
//line :318:1
func (t *A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A) Invoke_O__O(self any) any { { var i__838000108__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000108__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000108__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000109; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_t), t.F_extra)); i__838000108__1 = lang.Numbers_Unchecked_inc_J__J(i__838000108__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_g2a_convert_interface_elems_A_New() *A_arbace_g2a_convert_interface_elems_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_interface_elems_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_g2a_convert_interface_elems_A) Ctor() {}
//line :324:1
func (t *A_arbace_g2a_convert_interface_elems_A) Invoke_O_O__O(self, field_list__0 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(field_list__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A_fn_class
	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_71; tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(field_list__0)))
//line :326:1
	return tmp1.Invoke_O__O(tmp2) }
func A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A_New() *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A) Ctor() {}
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A) Invoke_O_O__O(self, s__838000119__1 any) any { var tmp1 any = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A_New_O_O(self, s__838000119__1); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_151, false); A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :327:1
func A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A{}; t.Ctor_O_O(p0, p1); return t }
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A) Ctor_O_O(c__iter__838000118, c__s__838000119 any) { t.F_iter__838000118 = c__iter__838000118; t.F_s__838000119 = c__s__838000119 }
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A) Invoke_O__O(self any) any { { var s__838000119__1 any; var t_ any = t.F_s__838000119; t.F_s__838000119 = nil; s__838000119__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000119__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000119__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000119__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000119__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000121__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A_New_O_I_O(b__838000121__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000118); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000121__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000119__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000121__6), nil) } } else { var fld__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000119__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()); var tmp5 any; var map__838000131__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fld__4); var map__838000131__6 any
															if lang.ISeq_InstanceOf(map__838000131__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000131__5)) { map__838000131__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000131__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000131__5)) { map__838000131__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000131__5) } else { lang.PersistentArrayMap_Init(); map__838000131__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000131__6 = map__838000131__5 }
//line :327:1
	var names__7 any = lang.RT_Get_O_O__O(map__838000131__6, A_arbace_g2a_convert_A_const_53); var type__8 any = lang.RT_Get_O_O__O(map__838000131__6, A_arbace_g2a_convert_A_const_59); var doc__9 any = lang.RT_Get_O_O__O(map__838000131__6, A_arbace_g2a_convert_A_const_217); var d__10 any

	if jrt.A2g_Truth(doc__9) { d__10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__9, A_arbace_g2a_convert_A_const_225.Get__O()) } else { d__10 = nil }
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__4)
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(names__7)) { var nm__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(names__7); var ___12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__8); var vec__838000133__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_233.GetRawRoot__O()).Invoke_O__O(type__8); var seq__838000134__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(vec__838000133__13); var first__838000135__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq__838000134__14); var seq__838000134__16 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq__838000134__14); var ps__17 any = first__838000135__15; var rs__18 any = seq__838000134__16; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__11); var tmp11 lang.IPersistentMap; _ = ___12



		if jrt.A2g_Truth(d__10) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d__10)) } else { tmp11 = nil }; tmp5 = tmp6.Invoke_O_O_O__O(tmp7.Invoke_O_O_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11), ps__17, rs__18), fld__4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(fld__4)) } else {
			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__8); var tmp14 lang.IPersistentMap; if jrt.A2g_Truth(d__10) { tmp14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d__10)) } else { tmp14 = nil }; tmp5 = tmp12.Invoke_O_O__O(tmp13, tmp14) }
//line :327:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__838000118); return tmp4.Invoke_O_O__O(tmp5, tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000119__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :327:1
func A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A) Ctor_O_I_O(c__b__838000121 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__838000121 = c__b__838000121; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :327:1
func (t *A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A) Invoke_O__O(self any) any { { var i__838000120__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000120__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fld__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000120__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000121; var tmp4 any; var map__838000125__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fld__2); var map__838000125__4 any
																	if lang.ISeq_InstanceOf(map__838000125__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000125__3)) { map__838000125__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000125__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000125__3)) { map__838000125__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000125__3) } else { lang.PersistentArrayMap_Init(); map__838000125__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000125__4 = map__838000125__3 }
//line :327:1
	var names__5 any = lang.RT_Get_O_O__O(map__838000125__4, A_arbace_g2a_convert_A_const_53); var type__6 any = lang.RT_Get_O_O__O(map__838000125__4, A_arbace_g2a_convert_A_const_59); var doc__7 any = lang.RT_Get_O_O__O(map__838000125__4, A_arbace_g2a_convert_A_const_217); var d__8 any

	if jrt.A2g_Truth(doc__7) { d__8 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_g2a_convert_A_const_225.Get__O()) } else { d__8 = nil }
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__2)
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(names__5)) { var nm__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(names__5); var ___10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__6); var vec__838000127__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_233.GetRawRoot__O()).Invoke_O__O(type__6); var seq__838000128__12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(vec__838000127__11); var first__838000129__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq__838000128__12); var seq__838000128__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq__838000128__12); var ps__15 any = first__838000129__13; var rs__16 any = seq__838000128__14; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__9); var tmp10 lang.IPersistentMap; _ = ___10



		if jrt.A2g_Truth(d__8) { tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d__8)) } else { tmp10 = nil }; tmp4 = tmp5.Invoke_O_O_O__O(tmp6.Invoke_O_O_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10), ps__15, rs__16), fld__2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(fld__2)) } else {
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__6); var tmp13 lang.IPersistentMap; if jrt.A2g_Truth(d__8) { tmp13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d__8)) } else { tmp13 = nil }; tmp4 = tmp11.Invoke_O_O__O(tmp12, tmp13) }
//line :327:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__838000120__1 = lang.Numbers_Unchecked_inc_J__J(i__838000120__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_g2a_convert_type_form_A_New() *A_arbace_g2a_convert_type_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_form_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_g2a_convert_type_form_A) Ctor() {}
//line :338:1
func (t *A_arbace_g2a_convert_type_form_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any = A_arbace_g2a_convert_A_const_54; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)) { } else { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :338:1
	var f__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var l__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var G__838000139__4_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)





	switch lang.Util_Hash_O__I(G__838000139__4_) >> 7 & 63 { case 1: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_42) {










































		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_240; return tmp2.Invoke_O_O_O_O__O(n__0, l__3, tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_222.Invoke_O__O(f__2))) }
//line :344:1
	case 3: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_61) { var G__838000140__5_ any = A_arbace_g2a_convert_A_const_234.Invoke_O__O(f__2)













		switch lang.Util_Hash_O__I(G__838000140__5_) >> 7 & 3 { case 0: if any(G__838000140__5_) == any(A_arbace_g2a_convert_A_const_235) {


			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_241; var tmp6 any = A_arbace_g2a_convert_A_const_235; return tmp4.Invoke_O_O_O_O_O__O(n__0, l__3, tmp5, tmp6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_195.Invoke_O__O(f__2))) }
//line :358:1
		case 2: if any(G__838000140__5_) == any(A_arbace_g2a_convert_A_const_236) {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_A_const_242; return tmp7.Invoke_O_O_O_O__O(n__0, l__3, tmp8, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_195.Invoke_O__O(f__2))) }
//line :358:1
		case 3: if any(G__838000140__5_) == any(A_arbace_g2a_convert_A_const_237) {

			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_A_const_243; var tmp11 any = A_arbace_g2a_convert_A_const_237; return tmp9.Invoke_O_O_O_O_O__O(n__0, l__3, tmp10, tmp11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_195.Invoke_O__O(f__2))) }
//line :358:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__838000140__5_))))) }
//line :344:1
	case 7: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_80) {























		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp14 any = A_arbace_g2a_convert_A_const_244; return tmp12.Invoke_O_O_O_O_O__O(tmp13, n__0, l__3, tmp14, lang.IFn_Cast(A_arbace_g2a_convert_A_const_245.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_246.Invoke_O__O(f__2))) }
//line :344:1
	case 21: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_72) { var g__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)); var args__6 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp16 any = A_arbace_g2a_convert_A_const_218.GetRawRoot__O(); var tmp17 any
		var tmp18 any = A_arbace_g2a_convert_A_const_72

























		if lang.Util_Equiv_O_O__Z(tmp18, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp17 = lang.Tuple_Create_O__IPersistentVector(A_arbace_g2a_convert_A_const_248.Invoke_O__O(f__2)) } else { tmp17 = A_arbace_g2a_convert_A_const_247.Invoke_O__O(f__2) }; args__6 = tmp15.Invoke_O_O__O(tmp16, tmp17)
		var tmp19 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(g__5); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_238.GetRawRoot__O()).Invoke_O__O(g__5), nil); if and__1927000168__auto____8 { tmp19 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(g__5) } else { tmp19 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp19 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp19) {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__3, A_arbace_g2a_convert_A_const_249, g__5, args__6) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__3, g__5, args__6) } }
//line :344:1
	case 27: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_101) { var g__5_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)); var args__6_2 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp21 any = A_arbace_g2a_convert_A_const_218.GetRawRoot__O(); var tmp22 any
		var tmp23 any = A_arbace_g2a_convert_A_const_72

























		if lang.Util_Equiv_O_O__Z(tmp23, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp22 = lang.Tuple_Create_O__IPersistentVector(A_arbace_g2a_convert_A_const_248.Invoke_O__O(f__2)) } else { tmp22 = A_arbace_g2a_convert_A_const_247.Invoke_O__O(f__2) }; args__6_2 = tmp20.Invoke_O_O__O(tmp21, tmp22)
		var tmp24 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(g__5_2); if jrt.A2g_Truth(and__1927000168__auto____7_2) { var and__1927000168__auto____8_2 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_238.GetRawRoot__O()).Invoke_O__O(g__5_2), nil); if and__1927000168__auto____8_2 { tmp24 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(g__5_2) } else { tmp24 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_2).Ref() } } else { tmp24 = and__1927000168__auto____7_2 }; if jrt.A2g_Truth(tmp24) {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__3, A_arbace_g2a_convert_A_const_249, g__5_2, args__6_2) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__3, g__5_2, args__6_2) } }
//line :344:1
	case 29: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_111) {






















		var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp26 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp27 any = A_arbace_g2a_convert_A_const_251; return tmp25.Invoke_O_O_O_O_O__O(tmp26, n__0, l__3, tmp27, lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_253.Invoke_O__O(f__2), A_arbace_g2a_convert_A_const_254)) }
//line :344:1
	case 33: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_40) {







		if lang.Util_Identical_O_O__Z(A_arbace_g2a_convert_A_const_250.Invoke_O__O(f__2), nil) {
			var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp29 any = A_arbace_g2a_convert_A_const_256; return tmp28.Invoke_O_O_O_O__O(n__0, l__3, tmp29, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_222.Invoke_O__O(f__2))) } else {
//line :352:1
				var tmp30 any = A_arbace_g2a_convert_A_const_42; if lang.Util_Equiv_O_O__Z(tmp30, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_250.Invoke_O__O(f__2))) {

					lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_250.Invoke_O__O(f__2))
					var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp32 any = A_arbace_g2a_convert_A_const_257; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_convert_A_const_258; return tmp31.Invoke_O_O_O_O_O__O(n__0, l__3, tmp32, tmp33.Invoke_O_O_O__O(tmp34, A_arbace_g2a_convert_A_const_250.Invoke_O__O(f__2), l__3), lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_222.Invoke_O__O(f__2))) } else {
//line :352:1
						if A_arbace_g2a_convert_A_const_156 != nil {



							var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp36 any = A_arbace_g2a_convert_A_const_259; return tmp35.Invoke_O_O_O_O_O__O(n__0, l__3, tmp36, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_250.Invoke_O__O(f__2)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_222.Invoke_O__O(f__2))) } else {
//line :352:1
								return nil } } } }
//line :344:1
	case 34: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_51) {







































		if lang.Util_Equiv_O_O__Z(Lit_104, A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__2)) {
			var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp38 any = A_arbace_g2a_convert_A_const_261; return tmp37.Invoke_O_O_O_O__O(n__0, l__3, tmp38, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2))) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_175, n__0) } }
//line :344:1
	case 36: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_65) {












		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp40 any = A_arbace_g2a_convert_A_const_263; return tmp39.Invoke_O_O_O_O_O__O(n__0, l__3, tmp40, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_85.Invoke_O__O(f__2)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_195.Invoke_O__O(f__2))) }
//line :344:1
	case 40: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_84) {


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2))) {
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2))); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(f__2))
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(f__2))), n__0, l__3) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_176, n__0) } }
//line :344:1
	case 44: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_103) {






























		if lang.Util_Equiv_O_O__Z(Lit_177, A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__2)) { var terms__5 any; var tmp41 any = A_arbace_g2a_convert_type_form_fn__838000141_A_New_O(f__2); var tmp42 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_convert_type_form_fn__838000141_A_fn_class
			if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_178, false); A_arbace_g2a_convert_type_form_fn__838000141_A_fn_class = fncls__24d; tmp42 = fncls__24d } else { tmp42 = fncls__24 }; terms__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil).Invoke__O()





			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__3, A_arbace_g2a_convert_A_const_266, terms__5) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_179, n__0) } }
//line :344:1
	case 45: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_31) {

		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)) }
//line :344:1
	case 50: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_54) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :344:1
	case 58: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_97) {






		var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp44 any = A_arbace_g2a_convert_A_const_268; return tmp43.Invoke_O_O_O_O__O(n__0, l__3, tmp44, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2))) }
//line :344:1
	case 59: if any(G__838000139__4_) == any(A_arbace_g2a_convert_A_const_99) { var ps__5 any; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()); var tmp46 any = A_arbace_g2a_convert_A_const_102.Invoke_O__O(f__2); var tmp47 *lang.PersistentArrayMap

















		lang.PersistentArrayMap_Init(); tmp47 = lang.PersistentArrayMap_EMPTY; ps__5 = tmp45.Invoke_O_O__O(tmp46, tmp47.Ref())
//line :344:1
		var rs__6 any


















		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2)) { var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()); var tmp49 any = A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2); var tmp50 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp50 = lang.PersistentArrayMap_EMPTY; rs__6 = tmp48.Invoke_O_O__O(tmp49, tmp50.Ref()) } else { rs__6 = nil }
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(rs__6)) {
			var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp52 any = A_arbace_g2a_convert_A_const_269; return tmp51.Invoke_O_O_O_O_O__O(n__0, l__3, tmp52, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__3, ps__5), lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__3, rs__6)) } else {
				var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp54 any = A_arbace_g2a_convert_A_const_271; return tmp53.Invoke_O_O_O_O__O(n__0, l__3, tmp54, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__3, ps__5)) } }
//line :344:1
	default:
	}










































	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_89, n__0) }
//line :376:1
func A_arbace_g2a_convert_type_form_fn__838000141_A_New_O(p0 any) *A_arbace_g2a_convert_type_form_fn__838000141_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_form_fn__838000141_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_g2a_convert_type_form_fn__838000141_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :376:1
func (t *A_arbace_g2a_convert_type_form_fn__838000141_A) Invoke_O__O(self any) any { { var x__1 any = A_arbace_g2a_convert_A_const_33.Invoke_O__O(t.F_f); var acc__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_264; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; acc__2 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))); L1: for {
											var tmp5 any = A_arbace_g2a_convert_A_const_31; if lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__1)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :376:1
	var x__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(x__1); var tmp6 bool; var tmp7 any = A_arbace_g2a_convert_A_const_103; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__3))


	if and__1927000168__auto____4 { var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_255; tmp6 = lang.Util_Equiv_O_O__Z(Lit_177, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__3))) } else { tmp6 = and__1927000168__auto____4 }; if tmp6 {
		var tmp9 any; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__3); var tmp10 *lang.Keyword = A_arbace_g2a_convert_A_const_33; tmp9 = tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__3)); var tmp11 *lang.Keyword = A_arbace_g2a_convert_A_const_264; x__1, acc__2 = tmp9, lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__3))), acc__2); continue L1 } else {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(x__3), acc__2) } } }; /*line :376:1*/panic("a2g: unreachable") }















func A_arbace_g2a_convert_signature_A_New() *A_arbace_g2a_convert_signature_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_signature_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_g2a_convert_signature_A) Ctor() {}
//line :392:1
func (t *A_arbace_g2a_convert_signature_A) Invoke_O_O__O(self, ft__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(ft__0); var l__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(ft__0); var ps__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_70; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_124.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_102.Invoke_O__O(f__2)))); if





	jrt.A2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = l__3 }; var tmp5 any = tmp3; var tmp6 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_102.Invoke_O__O(f__2); var tmp8 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; ps__4 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8.Ref())), lang.IFn_Cast(A_arbace_g2a_convert_A_const_273.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_102.Invoke_O__O(f__2)), A_arbace_g2a_convert_A_const_274)); var rlist__5 any; if
	jrt.A2g_Truth(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2)) { var tmp9 *lang.Keyword = A_arbace_g2a_convert_A_const_71; rlist__5 = tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2))) } else { rlist__5 = nil }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(rlist__5)) {
		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2)) }
//line :401:1
		return lang.Tuple_Create_O__IPersistentVector(ps__4) } else { var tmp10 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rlist__5)))

			if and__1927000168__auto____6 { var tmp11 *lang.Keyword = A_arbace_g2a_convert_A_const_53; tmp10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rlist__5)))) } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }
//line :401:1
			if jrt.A2g_Truth(tmp10) {


				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rlist__5)); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2))
//line :401:1
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp14 any = A_arbace_g2a_convert_A_const_204; var tmp15 *lang.Keyword = A_arbace_g2a_convert_A_const_59; return lang.Tuple_Create_O__IPersistentVector(tmp12.Invoke_O_O_O_O__O(ps__4, tmp13, tmp14, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rlist__5)))))) } else { if A_arbace_g2a_convert_A_const_156 != nil { var tmp16 any = A_arbace_g2a_convert_A_const_267; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2); var tmp21 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp21 = lang.PersistentArrayMap_EMPTY; return lang.Tuple_Create_O_O_O__IPersistentVector(ps__4, tmp16, tmp17.Invoke_O_O__O(tmp18.Invoke_O_O__O(l__3, tmp19.Invoke_O_O__O(tmp20, tmp21.Ref())), lang.IFn_Cast(A_arbace_g2a_convert_A_const_273.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__2)), A_arbace_g2a_convert_A_const_275))) } else { return nil } } } }







func A_arbace_g2a_convert_type_params_A_New() *A_arbace_g2a_convert_type_params_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_params_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_g2a_convert_type_params_A) Ctor() {}
//line :409:1
func (t *A_arbace_g2a_convert_type_params_A) Invoke_O_O__O(self, field_list__0 any) any {
	if jrt.A2g_Truth(field_list__0) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(field_list__0) }
	var tmp1 any; var and__1927000168__auto____2 any = field_list__0; if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_71; tmp1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(field_list__0))) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_205; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6.Ref()))
//line :411:1
		var tmp7 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_215.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_convert_type_params_fn__838000145_A_New(); var tmp12 *jrt.Class
				var fncls__28 /*line :413:1*/*jrt.Class = A_arbace_g2a_convert_type_params_fn__838000145_A_fn_class

				if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, false); A_arbace_g2a_convert_type_params_fn__838000145_A_fn_class = fncls__28d; tmp12 = fncls__28d } else { tmp12 = fncls__28 }
//line :413:1
				var tmp13 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp14 any = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(field_list__0)))); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; tmp7 = tmp8.Invoke_O_O__O(tmp14, tmp15.Ref()) }
//line :411:1
			return nil }()
		lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O()
//line :411:1
		if tmp16 != nil { panic(tmp16) }; return tmp7 } else { return nil
		}
}

func A_arbace_g2a_convert_type_params_fn__838000145_A_New() *A_arbace_g2a_convert_type_params_fn__838000145_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_params_fn__838000145_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_A) Ctor() {}
//line :415:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_A) Invoke_O_O__O(self, fld__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(fld__1)
//line :415:1
	var map__838000146__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fld__1); var map__838000146__3 any

	if lang.ISeq_InstanceOf(map__838000146__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000146__2)) { map__838000146__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000146__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000146__2)) { map__838000146__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000146__2) } else { lang.PersistentArrayMap_Init(); map__838000146__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000146__3 = map__838000146__2 }
//line :415:1
	var names__4 any = lang.RT_Get_O_O__O(map__838000146__3, A_arbace_g2a_convert_A_const_53); var type__5 any = lang.RT_Get_O_O__O(map__838000146__3, A_arbace_g2a_convert_A_const_59); var c__6 any; var u__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(type__5); var tmp1 any; var tmp2 any = A_arbace_g2a_convert_A_const_54; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(u__6))



	if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(Lit_181, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(u__6)); if and__1927000168__auto____8 {
		var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_174; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_167.GetRawRoot__O()).Invoke_O__O(u__6)) } else {
//line :419:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(tmp1) {

				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__5)
//line :419:1
				c__6 = nil } else {


					c__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__5) }
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_convert_A_const_205; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()))
//line :415:1
	var tmp8 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








		{ var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_227.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A_New_O(c__6); var tmp12 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A_fn_class = fncls__27d; tmp12 = fncls__27d } else { tmp12 = fncls__27 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(names__4); tmp8 = tmp9.Invoke_O__O(tmp10) }
//line :415:1
		return nil
	}()






	lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O()
//line :415:1
	if tmp13 != nil { panic(tmp13) }; return tmp8
}







func A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A_New_O(p0 any) *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A{}; t.Ctor_O(p0); return t }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A) Invoke_O_O__O(self, s__838000149__1 any) any { var tmp1 any = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A_New_O_O_O(self, s__838000149__1, t.F_c); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_183, false); A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :424:1
func A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A) Ctor_O_O_O(c__iter__838000148, c__s__838000149, c__c any) { t.F_iter__838000148 = c__iter__838000148; t.F_s__838000149 = c__s__838000149; t.F_c = c__c }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A) Invoke_O__O(self any) any { { var s__838000149__1 any; var t_ any = t.F_s__838000149; t.F_s__838000149 = nil; s__838000149__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000149__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000149__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000149__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000149__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000151__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A_New_O_I_O_O(b__838000151__6, size__1927001038__auto____5, t.F_c, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_184, false); A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000148); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000151__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000149__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000151__6), nil) } } else { var nm__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000149__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__838000148); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__4), t.F_c), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000149__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :424:1
func A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A) Ctor_O_I_O_O(c__b__838000151 any, c__size__1927001038__auto__ int32, c__c, c__c__1927001037__auto__ any) { t.F_b__838000151 = c__b__838000151; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c = c__c; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :424:1
func (t *A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A) Invoke_O__O(self any) any { { var i__838000150__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000150__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000150__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000151; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_c)); i__838000150__1 = lang.Numbers_Unchecked_inc_J__J(i__838000150__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

















func A_arbace_g2a_convert_untyped_const_QMARK__A_New() *A_arbace_g2a_convert_untyped_const_QMARK__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_untyped_const_QMARK__A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_g2a_convert_untyped_const_QMARK__A) Ctor() {}
//line :442:1
func (t *A_arbace_g2a_convert_untyped_const_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(n__0); var f__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__2); var a__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__2); var tmp1 any = A_arbace_g2a_convert_A_const_177; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_g2a_convert_A_const_176.Invoke_O__O(a__4)); if and__1927000168__auto____5 {





	var G__838000160__6_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__2)
	switch lang.Util_Hash_O__I(G__838000160__6_) >> 9 & 7 { case 0: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_51) {




		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_279.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)) }
//line :449:1
	case 1: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_79) { var tmp2 any = A_arbace_g2a_convert_A_const_280; var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_176; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_82.Invoke_O__O(f__3)))))








		if and__1927000168__auto____7 { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_281); var and__1927000168__auto____8 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_82.Invoke_O__O(f__3)))); if jrt.A2g_Truth(and__1927000168__auto____8) {

			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_282.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_279.GetRawRoot__O(), A_arbace_g2a_convert_A_const_286.Invoke_O__O(f__3)) } else {
//line :458:1
				return and__1927000168__auto____8 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } }
//line :449:1
	case 2: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_84) { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_161; var o__7 any = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(f__3))); var tmp6 any = A_arbace_g2a_convert_A_const_177; var and__1927000168__auto____8_2 bool = lang.Util_Equiv_O_O__Z(tmp6, A_arbace_g2a_convert_A_const_168.Invoke_O__O(o__7))



		if and__1927000168__auto____8_2 { var and__1927000168__auto____9 any = A_arbace_g2a_convert_A_const_283.Invoke_O__O(o__7); if jrt.A2g_Truth(and__1927000168__auto____9) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_284.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_283.Invoke_O__O(o__7)) } else { return and__1927000168__auto____9 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_2).Ref() } }
//line :449:1
	case 3: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_103) {





		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_285); if jrt.A2g_Truth(tmp7.Invoke_O__O(A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__3))) {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_279.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)) } else {
//line :455:1
				var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_279.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))

				if jrt.A2g_Truth(and__1927000168__auto____7_2) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_279.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_264.Invoke_O__O(f__3)) } else { return and__1927000168__auto____7_2 } } }
//line :449:1
	case 4: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_54) { var o__7_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_167.GetRawRoot__O()).Invoke_O__O(n__2); var tmp8 any = A_arbace_g2a_convert_A_const_177; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z(tmp8, A_arbace_g2a_convert_A_const_168.Invoke_O__O(o__7_2))

		if and__1927000168__auto____8_3 { var and__1927000168__auto____9_2 any = A_arbace_g2a_convert_A_const_283.Invoke_O__O(o__7_2); if jrt.A2g_Truth(and__1927000168__auto____9_2) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_284.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_283.Invoke_O__O(o__7_2)) } else { return and__1927000168__auto____9_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8_3).Ref() } }
//line :449:1
	case 7: if any(G__838000160__6_) == any(A_arbace_g2a_convert_A_const_108) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {
//line :448:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }














func A_arbace_g2a_convert_as_inst_A_New() *A_arbace_g2a_convert_as_inst_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_as_inst_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_g2a_convert_as_inst_A) Ctor() {}
//line :463:1
func (t *A_arbace_g2a_convert_as_inst_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(t__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_287); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(t__0))); if jrt.A2g_Truth(and__1927000168__auto____4) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp4 any; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_238.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(t__0)), nil); if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_239.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(t__0)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; tmp1 = tmp3.Invoke_O__O(tmp4) } else {
//line :467:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {

				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_convert_A_const_141.GetRawRoot__O(), A_arbace_g2a_convert_A_const_288, t__0), lang.RT_Meta_O__IPersistentMap(t__0)) } else {
//line :467:1
					return t__0
				}
}


func A_arbace_g2a_convert_selection_via_A_New() *A_arbace_g2a_convert_selection_via_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_selection_via_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_g2a_convert_selection_via_A) Ctor() {}
//line :472:1
func (t *A_arbace_g2a_convert_selection_via_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_289; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(a__0)); if
											jrt.A2g_Truth(temp__1927000414__auto____2) { var via__3 any = temp__1927000414__auto____2; var tmp2 any = A_arbace_g2a_convert_A_const_290; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_182.GetRawRoot__O(), via__3))) } else { return nil } }


func A_arbace_g2a_convert_selector_form_A_New() *A_arbace_g2a_convert_selector_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_selector_form_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_g2a_convert_selector_form_A) Ctor() {}
//line :476:1
func (t *A_arbace_g2a_convert_selector_form_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var a__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var x__5 any = A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2); var sel__6 any = A_arbace_g2a_convert_A_const_265.Invoke_O__O(f__2); var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_168; var k__7 any = tmp1.Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(a__3));








	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0);
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sel__6); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(x__5)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(x__5)) }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(x__5)) {


		var tmp2 any = A_arbace_g2a_convert_A_const_293; var tmp3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(x__5); var tmp4 any = A_arbace_g2a_convert_A_const_55; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(sel__6)), n__0, l__4), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(sel__6, A_arbace_g2a_convert_A_const_17)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(sel__6)))) } else {
//line :488:1
			if lang.Util_Equiv_O_O__Z(k__7, A_arbace_g2a_convert_A_const_291) {



				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_convert_A_const_294; return tmp5.Invoke_O_O_O_O_O__O(n__0, l__4, tmp6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_295.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(sel__6))) } else {
//line :488:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_292).Invoke_O__O(k__7)) {







						var tmp7 any = A_arbace_g2a_convert_A_const_55; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_149, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(sel__6))).Ref()), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(sel__6, A_arbace_g2a_convert_A_const_17)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__5)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_296.GetRawRoot__O()).Invoke_O__O(a__3)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(sel__6)))) } else {
//line :488:1
							if A_arbace_g2a_convert_A_const_156 != nil {








								return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_161, n__0) } else {
//line :488:1
									return nil } } } } }










func A_arbace_g2a_convert_call_args_A_New() *A_arbace_g2a_convert_call_args_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_call_args_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_g2a_convert_call_args_A) Ctor() {}
//line :499:1
func (t *A_arbace_g2a_convert_call_args_A) Invoke_O_O_O__O(self, args__0, ellipsis__1 any) any { var xs__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_260.GetRawRoot__O(), args__0); if

	jrt.A2g_Truth(ellipsis__1) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_149.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_299.GetRawRoot__O()).Invoke_O__O(xs__3)); var tmp3 any = A_arbace_g2a_convert_A_const_298; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_297.GetRawRoot__O()).Invoke_O__O(xs__3), tmp1.Invoke_O_O_O_O__O(nil, tmp2, tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_299.GetRawRoot__O()).Invoke_O__O(xs__3))) } else {
//line :501:1
			return xs__3 } }



func A_arbace_g2a_convert_builtin_name_A_New() *A_arbace_g2a_convert_builtin_name_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_builtin_name_A{}; t.Ctor(); return t }
//line :505:1
func (t *A_arbace_g2a_convert_builtin_name_A) Ctor() {}
//line :505:1
func (t *A_arbace_g2a_convert_builtin_name_A) Invoke_O_O__O(self, fun__0 any) any { var fun__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(fun__0); var G__838000166__3_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(fun__2); switch



	lang.Util_Hash_O__I(G__838000166__3_) >> 0 & 1 { case 0: if any(G__838000166__3_) == any(A_arbace_g2a_convert_A_const_54) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(fun__2)) }
//line :509:1
	case 1: if any(G__838000166__3_) == any(A_arbace_g2a_convert_A_const_84) {

		var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_265; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fun__2)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(fun__2)))) }
//line :509:1
	default:}; return /*line :512:1*/ lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_14, fun__2) }

func A_arbace_g2a_convert_call_A_New() *A_arbace_g2a_convert_call_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_call_A{}; t.Ctor(); return t }
//line :514:1
func (t *A_arbace_g2a_convert_call_A) Ctor() {}
//line :514:1
func (t *A_arbace_g2a_convert_call_A) Invoke_O_O__O(self, n__0 any) any { var map__838000168__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000168__3 any; if
									lang.ISeq_InstanceOf(map__838000168__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000168__2)) { map__838000168__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000168__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000168__2)) { map__838000168__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000168__2) } else { lang.PersistentArrayMap_Init(); map__838000168__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000168__3 = map__838000168__2 }; var fun__4 any = /*line :514:1*/lang.RT_Get_O_O__O(map__838000168__3, A_arbace_g2a_convert_A_const_82); var args__5 any = lang.RT_Get_O_O__O(map__838000168__3, A_arbace_g2a_convert_A_const_286); var ellipsis__6 any = lang.RT_Get_O_O__O(map__838000168__3, A_arbace_g2a_convert_A_const_42); var l__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var u__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(fun__4); var fa__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(u__8); var ua__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__8);





	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any = A_arbace_g2a_convert_A_const_59; if
	lang.Util_Equiv_O_O__Z(tmp1, A_arbace_g2a_convert_A_const_176.Invoke_O__O(fa__9)) {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_304; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp3, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(args__5)).Ref())) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_15, n__0) }
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_305; return tmp4.Invoke_O_O_O_O_O__O(n__0, l__7, tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(fun__4), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(args__5))) } else {
//line :521:1
			var tmp6 any = A_arbace_g2a_convert_A_const_280; if lang.Util_Equiv_O_O__Z(tmp6, A_arbace_g2a_convert_A_const_176.Invoke_O__O(fa__9)) { var ___11 any; var tmp7 any = A_arbace_g2a_convert_call_fn__838000173_A_New_O(fun__4); var tmp8 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_g2a_convert_call_fn__838000173_A_fn_class; _ = ___11





				if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_g2a_convert_call_fn__838000173_A_fn_class = fncls__31d; tmp8 = fncls__31d } else { tmp8 = fncls__31 }; ___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :521:1
				var head__12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_300.GetRawRoot__O()).Invoke_O__O(fun__4); var vec__838000170__13 any = args__5; var seq__838000171__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(vec__838000170__13); var first__838000172__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq__838000171__14); var seq__838000171__16 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq__838000171__14); var a0__17 any = first__838000172__15; var more__18 any = seq__838000171__16; var a0f__19 any








				if jrt.A2g_Truth(a0__17) { var tmp9 any = A_arbace_g2a_convert_A_const_59; var tmp10 *lang.Keyword = A_arbace_g2a_convert_A_const_176; if lang.Util_Equiv_O_O__Z(tmp9, tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(a0__17)))) { var G__838000175__19_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(a0__17)
					if lang.Util_Equiv_O_O__Z(A_arbace_g2a_convert_A_const_301, head__12) { a0f__19 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_295.GetRawRoot__O()).Invoke_O__O(G__838000175__19_) } else { a0f__19 = G__838000175__19_ } } else {
						a0f__19 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(a0__17) } } else {
//line :530:1
							a0f__19 = nil
						}

				var tmp11 any = A_arbace_g2a_convert_A_const_84; if lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(u__8)) {
					lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(u__8); var tmp12 *lang.Keyword = A_arbace_g2a_convert_A_const_265; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__8))); var tmp13 *lang.Keyword = A_arbace_g2a_convert_A_const_33; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__8)))) } else {
						lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(u__8) }
				if jrt.A2g_Truth(a0__17) { var xs__20 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(a0f__19), lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_260.GetRawRoot__O(), more__18)); var xs__21 any

					if jrt.A2g_Truth(ellipsis__6) { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_149.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_299.GetRawRoot__O()).Invoke_O__O(xs__20)); var tmp16 any = A_arbace_g2a_convert_A_const_306; xs__21 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_297.GetRawRoot__O()).Invoke_O__O(xs__20), tmp14.Invoke_O_O_O_O__O(nil, tmp15, tmp16, lang.IFn_Cast(A_arbace_g2a_convert_A_const_299.GetRawRoot__O()).Invoke_O__O(xs__20))) } else { xs__21 = xs__20 }
					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(head__12, u__8, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(u__8)), xs__21) } else {
						return lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(n__0, l__7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(head__12, u__8, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(u__8))) } } else {
//line :521:1
							var tmp17 any; var tmp18 any = A_arbace_g2a_convert_A_const_84; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z(tmp18, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(u__8))




















							if and__1927000168__auto____11 { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(ua__10))); if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp19 any = A_arbace_g2a_convert_A_const_302; var tmp20 *lang.Keyword = A_arbace_g2a_convert_A_const_168; tmp17 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp19, tmp20.Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(fa__9)))).Ref() } else { tmp17 = and__1927000168__auto____12 } } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }
//line :521:1
							if jrt.A2g_Truth(tmp17) {





















								lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(u__8); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(ua__10))





								var tmp21 any = A_arbace_g2a_convert_A_const_307; var tmp22 any = A_arbace_g2a_convert_A_const_307.Invoke_O__O(ua__10); var tmp23 any = A_arbace_g2a_convert_A_const_55; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(ua__10)))).Ref()), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(ua__10), A_arbace_g2a_convert_A_const_17)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(ua__10)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_308.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_296.GetRawRoot__O()).Invoke_O__O(fa__9)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp22, tmp23, lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_265.Invoke_O__O(ua__10))))) } else {
//line :521:1
									var tmp24 any = A_arbace_g2a_convert_A_const_54; if lang.Util_Equiv_O_O__Z(tmp24, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(u__8)) { var callee__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(u__8); var tmp25 any; var and__1927000168__auto____12_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(callee__11)































										if jrt.A2g_Truth(and__1927000168__auto____12_2) { tmp25 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_303.GetRawRoot__O()).Invoke_O__O(callee__11) } else { tmp25 = and__1927000168__auto____12_2 }; if jrt.A2g_Truth(tmp25) {
											lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_309)
											var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp27 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp28 any = A_arbace_g2a_convert_A_const_310; return tmp26.Invoke_O_O_O_O_O_O__O(tmp27, n__0, l__7, tmp28, callee__11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_308.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } else {
												return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__7, callee__11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_308.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } } else {
//line :521:1
													if A_arbace_g2a_convert_A_const_156 != nil {




































														return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(fun__4), lang.IFn_Cast(A_arbace_g2a_convert_A_const_308.GetRawRoot__O()).Invoke_O_O__O(args__5, ellipsis__6)) } else {
//line :521:1
															return nil } } } } } }





func A_arbace_g2a_convert_call_fn__838000173_A_New_O(p0 any) *A_arbace_g2a_convert_call_fn__838000173_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_call_fn__838000173_A{}; t.Ctor_O(p0); return t }
//line :527:1
func (t *A_arbace_g2a_convert_call_fn__838000173_A) Ctor_O(c__fun any) { t.F_fun = c__fun }
//line :527:1
func (t *A_arbace_g2a_convert_call_fn__838000173_A) Invoke_O__O(self any) any { { var x__1 any; var t_ any = t.F_fun; t.F_fun = nil; x__1 = t_; L1: for { var tmp1 any = A_arbace_g2a_convert_A_const_31; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__1)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__1); var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_33; x__1 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__1)); continue L1 } else { return nil } } }; panic("a2g: unreachable") }
































func A_arbace_g2a_convert_instantiation_A_New() *A_arbace_g2a_convert_instantiation_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_instantiation_A{}; t.Ctor(); return t }
//line :560:1
func (t *A_arbace_g2a_convert_instantiation_A) Ctor() {}
//line :560:1
func (t *A_arbace_g2a_convert_instantiation_A) Invoke_O_O__O(self, n__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var idx__3 any; var tmp1 any = A_arbace_g2a_convert_A_const_72; if



	lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)) { idx__3 = lang.Tuple_Create_O__IPersistentVector(A_arbace_g2a_convert_A_const_248.Invoke_O__O(f__2)) } else { idx__3 = A_arbace_g2a_convert_A_const_247.Invoke_O__O(f__2) }; var x__4 any = /*line :560:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__2)); var fx__5 any; var G__838000177__5_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__4); L1:





	switch { default: switch lang.Util_Hash_O__I(G__838000177__5_) >> 0 & 1 { case 0: if any(G__838000177__5_) == any(A_arbace_g2a_convert_A_const_54) {
		fx__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O_O__O(x__4, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())
//line :566:1
		break L1 }; case 1: if any(G__838000177__5_) == any(A_arbace_g2a_convert_A_const_84) {

			var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_262.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))) {



				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()); var tmp5 any
//line :569:1
				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4); var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_265; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))
				var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_33; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4))))
				var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var tmp9 *lang.Keyword = A_arbace_g2a_convert_A_const_265; tmp5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4))))
				var tmp10 *lang.Keyword = A_arbace_g2a_convert_A_const_265; fx__5 = tmp3.Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, x__4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(x__4)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())) } else {
					var tmp11 any = A_arbace_g2a_convert_A_const_291; var tmp12 *lang.Keyword = A_arbace_g2a_convert_A_const_168; var tmp13 *lang.Keyword = A_arbace_g2a_convert_A_const_265; if lang.Util_Equiv_O_O__Z(tmp11, tmp12.Invoke_O__O(tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(x__4)))) {
						lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4); var tmp14 *lang.Keyword = A_arbace_g2a_convert_A_const_265; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))
						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp16 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(x__4); var tmp17 any = A_arbace_g2a_convert_A_const_311; var tmp18 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var tmp19 *lang.Keyword = A_arbace_g2a_convert_A_const_265; var tmp20 *lang.Keyword = A_arbace_g2a_convert_A_const_265; fx__5 = tmp15.Invoke_O_O_O_O_O__O(x__4, tmp16, tmp17, lang.IFn_Cast(A_arbace_g2a_convert_A_const_295.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref()))) } else {







							var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(x__4); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp25 any
//line :579:1
							lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__4); var tmp26 *lang.Keyword = A_arbace_g2a_convert_A_const_265; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))
							var tmp27 *lang.Keyword = A_arbace_g2a_convert_A_const_265; tmp25 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_149, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp27.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4))))).Ref())


							var tmp28 *lang.Keyword = A_arbace_g2a_convert_A_const_265; var tmp29 *lang.Keyword = A_arbace_g2a_convert_A_const_33; fx__5 = tmp21.Invoke_O_O__O(tmp22.Invoke_O_O_O_O__O(x__4, tmp23, tmp24.Invoke_O_O__O(tmp25, lang.IFn_Cast(A_arbace_g2a_convert_A_const_189.GetRawRoot__O()).Invoke_O_O__O(tmp28.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(idx__3)).Ref())), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__4)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_296.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(x__4))) } }
//line :566:1
			break L1 }; default:
	}
















		fx__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__4)}; var tmp30 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp31 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp32 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var tmp33 any = A_arbace_g2a_convert_A_const_312; return tmp30.Invoke_O_O_O_O_O_O__O(tmp31, n__0, tmp32, tmp33, fx__5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_218.GetRawRoot__O(), idx__3)) }

func A_arbace_g2a_convert_composite_A_New() *A_arbace_g2a_convert_composite_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_composite_A{}; t.Ctor(); return t }
//line :587:1
func (t *A_arbace_g2a_convert_composite_A) Ctor() {}
//line :587:1
func (t *A_arbace_g2a_convert_composite_A) Invoke_O_O__O(self, n__0 any) any { var map__838000179__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000179__3 any; if
										lang.ISeq_InstanceOf(map__838000179__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000179__2)) { map__838000179__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000179__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000179__2)) { map__838000179__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000179__2) } else { lang.PersistentArrayMap_Init(); map__838000179__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000179__3 = map__838000179__2 }; var type__4 any = /*line :587:1*/lang.RT_Get_O_O__O(map__838000179__3, A_arbace_g2a_convert_A_const_59); var elts__5 any = lang.RT_Get_O_O__O(map__838000179__3, A_arbace_g2a_convert_A_const_313); var l__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var t__7 any; if


	jrt.A2g_Truth(type__4) { t__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__4) } else { t__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(Lit_22), nil, l__6) }; var via__8 any; var tmp1 lang.IFn = /*line :587:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_126.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_127.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_composite_fn__838000181_A_New(); var tmp5 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_convert_composite_fn__838000181_A_fn_class; if




	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_g2a_convert_composite_fn__838000181_A_fn_class = fncls__33d; tmp5 = fncls__33d } else { tmp5 = fncls__33 }; via__8 = /*line :591:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), elts__5); var els__9 any; var tmp6 lang.IFn = /*line :587:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_composite_fn__838000183_A_New(); var tmp8 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_convert_composite_fn__838000183_A_fn_class; if








	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_g2a_convert_composite_fn__838000183_A_fn_class = fncls__34d; tmp8 = fncls__34d } else { tmp8 = fncls__34 }; els__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), elts__5);













	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp9 lang.IFn =

	lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__6, A_arbace_g2a_convert_A_const_314, t__7, els__9); var tmp11 lang.IPersistentMap; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(via__8)) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_290, via__8)) } else { tmp11 = nil }; return tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :592:1
func A_arbace_g2a_convert_composite_fn__838000181_A_New() *A_arbace_g2a_convert_composite_fn__838000181_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_composite_fn__838000181_A{}; t.Ctor(); return t }
//line :592:1
func (t *A_arbace_g2a_convert_composite_fn__838000181_A) Ctor() {}
//line :592:1
func (t *A_arbace_g2a_convert_composite_fn__838000181_A) Invoke_O_O__O(self, e__1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_289; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_63; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(e__1))); if
												jrt.A2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_85; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__1))))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_182.GetRawRoot__O(), v__3)) } else { return nil } }


func A_arbace_g2a_convert_composite_fn__838000183_A_New() *A_arbace_g2a_convert_composite_fn__838000183_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_composite_fn__838000183_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_g2a_convert_composite_fn__838000183_A) Ctor() {}
//line :596:1
func (t *A_arbace_g2a_convert_composite_fn__838000183_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 any = A_arbace_g2a_convert_A_const_83; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(e__1)) { var map__838000184__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__1); var map__838000184__3 any
		if lang.ISeq_InstanceOf(map__838000184__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000184__2)) { map__838000184__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000184__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000184__2)) { map__838000184__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000184__2) } else { lang.PersistentArrayMap_Init(); map__838000184__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000184__3 = map__838000184__2 }
//line :597:1
		var key__4 any = lang.RT_Get_O_O__O(map__838000184__3, A_arbace_g2a_convert_A_const_85); var value__5 any = lang.RT_Get_O_O__O(map__838000184__3, A_arbace_g2a_convert_A_const_195)

		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(e__1)
		var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_63; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(e__1))) { var k__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(key__4)
			var tmp3 any = A_arbace_g2a_convert_A_const_54
			if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(k__6)) { } else { lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_25, k__6) }
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(k__6)
//line :600:1
			return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_178.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(k__6), lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(k__6))).Ref(), lang.IFn_Cast(A_arbace_g2a_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(k__6))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(k__6))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(value__5)) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(e__1), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(key__4), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(value__5)))) } } else {
//line :597:1
				return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(e__1))
			}
}
















func A_arbace_g2a_convert_func_lit_A_New() *A_arbace_g2a_convert_func_lit_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_func_lit_A{}; t.Ctor(); return t }
//line :616:1
func (t *A_arbace_g2a_convert_func_lit_A) Ctor() {}
//line :616:1
func (t *A_arbace_g2a_convert_func_lit_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :616:1
	var map__838000188__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000188__3 any

	if lang.ISeq_InstanceOf(map__838000188__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000188__2)) { map__838000188__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000188__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000188__2)) { map__838000188__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000188__2) } else { lang.PersistentArrayMap_Init(); map__838000188__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000188__3 = map__838000188__2 }
//line :616:1
	var type__4 any = lang.RT_Get_O_O__O(map__838000188__3, A_arbace_g2a_convert_A_const_59); var body__5 any = lang.RT_Get_O_O__O(map__838000188__3, A_arbace_g2a_convert_A_const_315); var l__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_267; var has_results__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__4))))); var ___8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__4); var sig__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_316.GetRawRoot__O()).Invoke_O__O(type__4); var tmp3 any = A_arbace_g2a_convert_A_const_318; var body_forms__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()).Invoke_O_O__O(body__5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(has_results__7)).Ref()))); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp6 any = A_arbace_g2a_convert_A_const_320; var tmp7 any = A_arbace_g2a_convert_A_const_319; var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_147; var tmp9 any = A_arbace_g2a_convert_A_const_100; var tmp10 *lang.Keyword = A_arbace_g2a_convert_A_const_100; _ = ___8









	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, n__0, l__6, tmp6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(sig__9, body_forms__10)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_124.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(body__5)))))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__4)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_321.GetRawRoot__O()).Invoke_O__O(body__5)))
}
func A_arbace_g2a_convert_expr_A_New() *A_arbace_g2a_convert_expr_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_expr_A{}; t.Ctor(); return t }
//line :628:1
func (t *A_arbace_g2a_convert_expr_A) Ctor() {}
//line :628:1
func (t *A_arbace_g2a_convert_expr_A) Invoke_O_O__O(self, n__0 any) any { var a__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any = A_arbace_g2a_convert_A_const_59; if



	lang.Util_Equiv_O_O__Z(tmp1, A_arbace_g2a_convert_A_const_176.Invoke_O__O(a__2)) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(n__0) } else {
//line :632:1
			var f__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var G__838000192__5_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0)



			switch lang.Util_Hash_O__I(G__838000192__5_) >> 6 & 63 { case 2: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_42) {
































































				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_101, n__0) }
//line :636:1
			case 5: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_51) {






















				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :636:1
				var temp__1927000408__auto____6 any; var x__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)); var tmp2 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(Lit_102, A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__3))
























				if and__1927000168__auto____7 { var tmp3 any = A_arbace_g2a_convert_A_const_108; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__6)); if and__1927000168__auto____8 { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_322); var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_168; var and__1927000168__auto____9 any = tmp4.Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(x__6))); if jrt.A2g_Truth(and__1927000168__auto____9) { var v__10 any; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_195; var tmp7 any



					lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_11, nil)); var tmp8 any = A_arbace_g2a_convert_expr_fn__838000193_A_New_O(x__6); var tmp9 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_convert_expr_fn__838000193_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_g2a_convert_expr_fn__838000193_A_fn_class = fncls__36d; tmp9 = fncls__36d } else { tmp9 = fncls__36 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); v__10 = tmp6.Invoke_O__O(tmp7)
//line :661:1
					var or__1927000174__auto____11 bool = jrt.Double_InstanceOf(v__10)




					if or__1927000174__auto____11 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { tmp2 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(v__10)).Ref()) } } else {
//line :661:1
						tmp2 = and__1927000168__auto____9 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(tmp2) {





							var tmp10 any = A_arbace_g2a_convert_A_const_31; if lang.Util_Equiv_O_O__Z(tmp10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)) }
//line :661:1
							var v__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_323.GetRawRoot__O()).Invoke_O__O(x__6)







							lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_330)
							var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_convert_A_const_211; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_g2a_convert_A_const_211.Invoke_O__O(v__7))).Ref(); var tmp14 any = A_arbace_g2a_convert_A_const_195; var tmp15 any = lang.Numbers_MinusP_O__Number(A_arbace_g2a_convert_A_const_195.Invoke_O__O(v__7)); var tmp16 any = A_arbace_g2a_convert_A_const_152; var tmp17 any = A_arbace_g2a_convert_A_const_153; temp__1927000408__auto____6 = tmp11.Invoke_O_O_O_O_O_O_O_O_O__O(v__7, tmp12, tmp13, tmp14, tmp15, tmp16, l__4, tmp17, lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_52.Invoke_O__O(f__3))) } else {
//line :661:1
								temp__1927000408__auto____6 = nil }
//line :660:1
				if jrt.A2g_Truth(temp__1927000408__auto____6) { var neg__7 any = temp__1927000408__auto____6; return neg__7 } else { var temp__1927000408__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_324.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__3))












					if jrt.A2g_Truth(temp__1927000408__auto____7) { var op__8 any = temp__1927000408__auto____7
						return lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, op__8, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))) } else {
							if lang.Util_Equiv_O_O__Z(Lit_104, A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__3)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(n__0) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_105, n__0) } } } }
//line :636:1
			case 6: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_58) {


				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_325.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 12: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_77) { var map__838000195__6 any = f__3; var map__838000195__7 any











				if lang.ISeq_InstanceOf(map__838000195__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000195__6)) { map__838000195__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000195__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000195__6)) { map__838000195__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000195__6) } else { lang.PersistentArrayMap_Init(); map__838000195__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000195__7 = map__838000195__6 }
//line :636:1
				var x__8 any = lang.RT_Get_O_O__O(map__838000195__7, A_arbace_g2a_convert_A_const_33); var low__9 any = lang.RT_Get_O_O__O(map__838000195__7, A_arbace_g2a_convert_A_const_326); var high__10 any = lang.RT_Get_O_O__O(map__838000195__7, A_arbace_g2a_convert_A_const_327); var max__11 any = lang.RT_Get_O_O__O(map__838000195__7, A_arbace_g2a_convert_A_const_328); var parts__12 any












				if jrt.A2g_Truth(max__11) { parts__12 = lang.Tuple_Create_O_O_O__IPersistentVector(low__9, high__10, max__11) } else { if jrt.A2g_Truth(high__10) { parts__12 = lang.Tuple_Create_O_O__IPersistentVector(low__9, high__10) } else { if jrt.A2g_Truth(low__9) { parts__12 = lang.Tuple_Create_O__IPersistentVector(low__9) } else { if A_arbace_g2a_convert_A_const_156 != nil { lang.PersistentVector_Init(); parts__12 = lang.PersistentVector_EMPTY.Ref() } else { parts__12 = nil } } } }
				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp20 any = A_arbace_g2a_convert_A_const_332; var tmp21 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__8); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp23 any = A_arbace_g2a_convert_expr_fn__838000197_A_New_O(l__4); var tmp24 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_convert_expr_fn__838000197_A_fn_class
				if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_g2a_convert_expr_fn__838000197_A_fn_class = fncls__37d; tmp24 = fncls__37d } else { tmp24 = fncls__37 }
//line :651:1
				return tmp18.Invoke_O_O_O_O_O_O__O(tmp19, n__0, l__4, tmp20, tmp21, tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), parts__12)) }
//line :636:1
			case 13: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_79) {



















				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_331.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 16: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_84) {





				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_333.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 24: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_103) { var op__6 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_334.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_255.Invoke_O__O(f__3))








































				if jrt.A2g_Truth(or__1927000174__auto____6) { op__6 = or__1927000174__auto____6 } else { op__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_107, n__0) }
				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_335.GetRawRoot__O()).Invoke_O__O(op__6)) { var logical__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_336).Invoke_O__O(op__6); var operand__8 any; var tmp25 any = A_arbace_g2a_convert_expr_operand__838000199_A_New_O(logical__7); var tmp26 *jrt.Class
					var fncls__38 /*line :679:1*/*jrt.Class = A_arbace_g2a_convert_expr_operand__838000199_A_fn_class

					if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_g2a_convert_expr_operand__838000199_A_fn_class = fncls__38d; tmp26 = fncls__38d } else { tmp26 = fncls__38 }; operand__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil)
//line :679:1
					var operands__9 any; var tmp27 any = A_arbace_g2a_convert_expr_fn__838000201_A_New_O_O_O_O_O(operand__8, logical__7, f__3, n__0, op__6); var tmp28 *jrt.Class
					var fncls__39 /*line :679:1*/*jrt.Class = A_arbace_g2a_convert_expr_fn__838000201_A_fn_class






					if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_g2a_convert_expr_fn__838000201_A_fn_class = fncls__39d; tmp28 = fncls__39d } else { tmp28 = fncls__39 }; operands__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O()







					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), n__0, l__4, op__6, operands__9) } else {
//line :679:1
						var fm__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O_O__O(n__0, l__4, op__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_264.Invoke_O__O(f__3))); var tmp29 any; var and__1927000168__auto____8_2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_339).Invoke_O__O(op__6)
















						if jrt.A2g_Truth(and__1927000168__auto____8_2) { var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp31 any = A_arbace_g2a_convert_A_const_177; var and__1927000168__auto____9_2 any = tmp30.Invoke_O_O__O(tmp31, A_arbace_g2a_convert_A_const_176.Invoke_O__O(a__2)); if jrt.A2g_Truth(and__1927000168__auto____9_2) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_279.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)); if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = A_arbace_g2a_convert_A_const_283.Invoke_O__O(a__2); if jrt.A2g_Truth(and__1927000168__auto____11) {
							tmp29 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_284.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_283.Invoke_O__O(a__2))) } else {
//line :696:1
								tmp29 = and__1927000168__auto____11 } } else { tmp29 = and__1927000168__auto____10 } } else { tmp29 = and__1927000168__auto____9_2 } } else { tmp29 = and__1927000168__auto____8_2 }; if jrt.A2g_Truth(tmp29) {

									lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_340); var tmp32 any = A_arbace_g2a_convert_A_const_204; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(fm__7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.IFn_Cast(A_arbace_g2a_convert_A_const_164.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_283.Invoke_O__O(a__2))))) } else {
//line :696:1
										return fm__7 } } }
//line :636:1
			case 27: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_31) {




				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)) }
//line :636:1
			case 28: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_115) {
















				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
				if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__3)) { } else { lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_110, n__0) }
				var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_convert_A_const_341; return tmp33.Invoke_O_O_O_O_O__O(n__0, l__4, tmp34, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_59.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))) }
//line :636:1
			case 37: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_54) {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 43: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_72) {






				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp35 any = A_arbace_g2a_convert_A_const_59; var tmp36 *lang.Keyword = A_arbace_g2a_convert_A_const_176; if lang.Util_Equiv_O_O__Z(tmp35, tmp36.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_248.Invoke_O__O(f__3))))) {
					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_342.GetRawRoot__O()).Invoke_O__O(n__0) } else {
						var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp38 any = A_arbace_g2a_convert_A_const_343; return tmp37.Invoke_O_O_O_O_O__O(n__0, l__4, tmp38, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_248.Invoke_O__O(f__3))) } }
//line :636:1
			case 48: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_83) {































































				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_111, n__0) }
//line :636:1
			case 51: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_95) {



				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_344.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 52: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_97) {




















				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
				var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp41 any = A_arbace_g2a_convert_A_const_346; var tmp42 any = tmp40.Invoke_O_O_O_O__O(n__0, l__4, tmp41, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))); var tmp43 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp44 any = A_arbace_g2a_convert_A_const_345; var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; return tmp39.Invoke_O_O_O_O__O(tmp42, tmp43, tmp44, tmp45.Ref()) }
//line :636:1
			case 55: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_101) {










				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_342.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			case 57: if any(G__838000192__5_) == any(A_arbace_g2a_convert_A_const_108) {

				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_323.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :636:1
			default:
			}
































































			var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_329); if jrt.A2g_Truth(tmp46.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0))) {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(n__0) } else {
					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_112, n__0) } } }
//line :652:1
func A_arbace_g2a_convert_expr_fn__838000197_A_New_O(p0 any) *A_arbace_g2a_convert_expr_fn__838000197_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_expr_fn__838000197_A{}; t.Ctor_O(p0); return t }
//line :652:1
func (t *A_arbace_g2a_convert_expr_fn__838000197_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :652:1
func (t *A_arbace_g2a_convert_expr_fn__838000197_A) Invoke_O_O__O(self, p1__838000191_SHARP___1 any) any { if jrt.A2g_Truth(p1__838000191_SHARP___1) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(p1__838000191_SHARP___1) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(Lit_22), nil, t.F_l) } }












func A_arbace_g2a_convert_expr_fn__838000193_A_New_O(p0 any) *A_arbace_g2a_convert_expr_fn__838000193_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_expr_fn__838000193_A{}; t.Ctor_O(p0); return t }
//line :665:1
func (t *A_arbace_g2a_convert_expr_fn__838000193_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :665:1
func (t *A_arbace_g2a_convert_expr_fn__838000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_323.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }















func A_arbace_g2a_convert_expr_operand__838000199_A_New_O(p0 any) *A_arbace_g2a_convert_expr_operand__838000199_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_expr_operand__838000199_A{}; t.Ctor_O(p0); return t }
//line :681:1
func (t *A_arbace_g2a_convert_expr_operand__838000199_A) Ctor_O(c__logical any) { t.F_logical = c__logical }
//line :681:1
func (t *A_arbace_g2a_convert_expr_operand__838000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var and__1927000168__auto____2 any = t.F_logical; if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_g2a_convert_A_const_31; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var fx__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__1)

	lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_337)
	if lang.IObj_InstanceOf(fx__2) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(fx__2, A_arbace_g2a_convert_A_const_338) } else { return fx__2 } } else {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__1) } }
func A_arbace_g2a_convert_expr_fn__838000201_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_convert_expr_fn__838000201_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_expr_fn__838000201_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :686:1
func (t *A_arbace_g2a_convert_expr_fn__838000201_A) Ctor_O_O_O_O_O(c__operand, c__logical, c__f, c__n, c__op any) { t.F_operand = c__operand; t.F_logical = c__logical; t.F_f = c__f; t.F_n = c__n; t.F_op = c__op }
//line :686:1
func (t *A_arbace_g2a_convert_expr_fn__838000201_A) Invoke_O__O(self any) any { { var x__1 any = A_arbace_g2a_convert_A_const_33.Invoke_O__O(t.F_f); var acc__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(t.F_operand); var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_264; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; acc__2 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))); var nodes__3 any; var tmp5 any; var t__2 any = t.F_n; t.F_n = nil; tmp5 = t__2; nodes__3 = lang.Tuple_Create_O__IPersistentVector(tmp5); L1: for { var u__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(x__1); var tmp6 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(x__1, u__4)

	if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(t.F_logical); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp7 any = t.F_op; var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_255; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_334.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__4))))).Ref() } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp6) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(x__1) }
	var tmp9 any; var tmp10 any = A_arbace_g2a_convert_A_const_103; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z(tmp10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(u__4)); if and__1927000168__auto____5_2 { var tmp11 any = t.F_op; var tmp12 *lang.Keyword = A_arbace_g2a_convert_A_const_255; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_334.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__4)))); if and__1927000168__auto____6_2 {
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp14 any; var and__1927000168__auto____7 any = t.F_logical; if jrt.A2g_Truth(and__1927000168__auto____7) { tmp14 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(x__1, u__4) } else { tmp14 = and__1927000168__auto____7 }; tmp9 = tmp13.Invoke_O__O(tmp14) } else {
//line :689:1
			tmp9 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6_2).Ref() } } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }; if jrt.A2g_Truth(tmp9) {

				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(u__4)
				var tmp15 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var tmp16 lang.IFn = lang.IFn_Cast(t.F_operand); var tmp17 *lang.Keyword = A_arbace_g2a_convert_A_const_264; x__1, acc__2, nodes__3 = tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__4)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp16.Invoke_O__O(tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(u__4))), acc__2), lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O__O(nodes__3, u__4); continue L1 } else {
					return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_operand).Invoke_O__O(x__1), acc__2) } } }; /*line :686:1*/panic("a2g: unreachable") }





















func A_arbace_g2a_convert_targets_A_New() *A_arbace_g2a_convert_targets_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_targets_A{}; t.Ctor(); return t }
//line :708:1
func (t *A_arbace_g2a_convert_targets_A) Ctor() {}
//line :708:1
func (t *A_arbace_g2a_convert_targets_A) Invoke_O_O_O_O__O(self, lhs__0, l__1, mk__2 any) any {


	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__0))) {
		return lang.IFn_Cast(mk__2).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__0)) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp3 any = A_arbace_g2a_convert_A_const_347; return tmp1.Invoke_O_O_O_O_O__O(tmp2, nil, l__1, tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(mk__2, lhs__0))
		} }
func A_arbace_g2a_convert_inits_A_New() *A_arbace_g2a_convert_inits_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_inits_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_g2a_convert_inits_A) Ctor() {}
//line :715:1
func (t *A_arbace_g2a_convert_inits_A) Invoke_O_O_O__O(self, rhs__0, l__1 any) any {
	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rhs__0))) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__0)) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__0)); var tmp4 any = A_arbace_g2a_convert_A_const_348; return tmp1.Invoke_O_O_O_O_O__O(tmp2, nil, tmp3, tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_260.GetRawRoot__O(), rhs__0))
		} }
func A_arbace_g2a_convert_define_target_A_New() *A_arbace_g2a_convert_define_target_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_define_target_A{}; t.Ctor(); return t }
//line :720:1
func (t *A_arbace_g2a_convert_define_target_A) Ctor() {}
//line :720:1
func (t *A_arbace_g2a_convert_define_target_A) Invoke_O_O__O(self, n__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_155.GetRawRoot__O()).Invoke_O__O(s__2); if



	jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_349, s__2); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_163; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)), nil); if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_161; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(n__0)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp6 any = A_arbace_g2a_convert_A_const_350; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; return tmp4.Invoke_O_O_O_O__O(s__2, tmp5, tmp6, tmp7.Ref()) } else {
//line :724:1
			return s__2 } }



func A_arbace_g2a_convert_define_binding_A_New() *A_arbace_g2a_convert_define_binding_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_define_binding_A{}; t.Ctor(); return t }
//line :728:1
func (t *A_arbace_g2a_convert_define_binding_A) Ctor() {}
//line :728:1
func (t *A_arbace_g2a_convert_define_binding_A) Invoke_O_O__O(self, st__0 any) any { var map__838000207__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__0); var map__838000207__3 any; if


	lang.ISeq_InstanceOf(map__838000207__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000207__2)) { map__838000207__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000207__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000207__2)) { map__838000207__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000207__2) } else { lang.PersistentArrayMap_Init(); map__838000207__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000207__3 = map__838000207__2 }; var lhs__4 any = /*line :728:1*/lang.RT_Get_O_O__O(map__838000207__3, A_arbace_g2a_convert_A_const_78); var rhs__5 any = lang.RT_Get_O_O__O(map__838000207__3, A_arbace_g2a_convert_A_const_351); var l__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(st__0); var t__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_352.GetRawRoot__O()).Invoke_O_O_O__O(lhs__4, l__6, A_arbace_g2a_convert_A_const_353.GetRawRoot__O()); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(t__7, st__0, l__6), lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(rhs__5, l__6)) }







func A_arbace_g2a_convert_const_val_A_New() *A_arbace_g2a_convert_const_val_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_const_val_A{}; t.Ctor(); return t }
//line :736:1
func (t *A_arbace_g2a_convert_const_val_A) Ctor() {}
//line :736:1
func (t *A_arbace_g2a_convert_const_val_A) Invoke_O_O__O(self, nm__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_163; var o__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(nm__0)); if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_210.GetRawRoot__O()).Invoke_O_O__O(o__2, A_arbace_g2a_convert_A_const_356)) { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_355.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_356.Invoke_O__O(o__2), lang.IFn_Cast(A_arbace_g2a_convert_A_const_357.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_283.Invoke_O__O(o__2)))
		if jrt.A2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_356, v__4)) } else { return nil } } else {
//line :740:1
			return nil } }



func A_arbace_g2a_convert_decl_bindings_A_New() *A_arbace_g2a_convert_decl_bindings_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_g2a_convert_decl_bindings_A) Ctor() {}
//line :744:1
func (t *A_arbace_g2a_convert_decl_bindings_A) Invoke_O_O__O(self, st__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_75; var gd__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__0)); var map__838000212__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(gd__2); var map__838000212__4 any; if


	lang.ISeq_InstanceOf(map__838000212__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000212__3)) { map__838000212__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000212__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000212__3)) { map__838000212__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000212__3) } else { lang.PersistentArrayMap_Init(); map__838000212__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000212__4 = map__838000212__3 }; var tok__5 any = /*line :744:1*/lang.RT_Get_O_O__O(map__838000212__4, A_arbace_g2a_convert_A_const_358); var specs__6 any = lang.RT_Get_O_O__O(map__838000212__4, A_arbace_g2a_convert_A_const_359);




	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(gd__2); var G__838000214__7_ any = tok__5; switch
	lang.Util_Hash_O__I(G__838000214__7_) >> 2 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__838000214__7_, Lit_85) { var tmp2 any = A_arbace_g2a_convert_A_const_360; var tmp3 any = A_arbace_g2a_convert_decl_bindings_fn__838000215_A_New_O(specs__6); var tmp4 *jrt.Class
		var fncls__44 /*line :750:1*/*jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000215_A_fn_class


















		if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_g2a_convert_decl_bindings_fn__838000215_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }
//line :750:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()) }; case 1: if lang.Util_Equiv_O_O__Z(G__838000214__7_, Lit_87) { var tmp5 any = A_arbace_g2a_convert_A_const_360; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_decl_bindings_fn__838000229_A_New_O_O(specs__6, gd__2); var tmp9 *jrt.Class
			var fncls__46 /*line :750:1*/*jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000229_A_fn_class




			if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_g2a_convert_decl_bindings_fn__838000229_A_fn_class = fncls__46d; tmp9 = fncls__46d } else { tmp9 = fncls__46 }
//line :750:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), specs__6))) }; case 2: if lang.Util_Equiv_O_O__Z(G__838000214__7_, Lit_89) { var tmp10 any = A_arbace_g2a_convert_A_const_369; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_decl_bindings_fn__838000235_A_New(); var tmp14 *jrt.Class
				var fncls__47 /*line :750:1*/*jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000235_A_fn_class















































				if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_g2a_convert_decl_bindings_fn__838000235_A_fn_class = fncls__47d; tmp14 = fncls__47d } else { tmp14 = fncls__47 }
//line :750:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Invoke_O__O(tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), specs__6))) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__838000214__7_))))) }




func A_arbace_g2a_convert_decl_bindings_fn__838000229_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_decl_bindings_fn__838000229_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000229_A{}; t.Ctor_O_O(p0, p1); return t }
//line :755:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000229_A) Ctor_O_O(c__specs, c__gd any) { t.F_specs = c__specs; t.F_gd = c__gd }
//line :755:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000229_A) Invoke_O_O__O(self, sp__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__1)
//line :755:1
	var map__838000230__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__1); var map__838000230__3 any

	if lang.ISeq_InstanceOf(map__838000230__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000230__2)) { map__838000230__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000230__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000230__2)) { map__838000230__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000230__2) } else { lang.PersistentArrayMap_Init(); map__838000230__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000230__3 = map__838000230__2 }
//line :755:1
	var names__4 any = lang.RT_Get_O_O__O(map__838000230__3, A_arbace_g2a_convert_A_const_53); var type__5 any = lang.RT_Get_O_O__O(map__838000230__3, A_arbace_g2a_convert_A_const_59); var values__6 any = lang.RT_Get_O_O__O(map__838000230__3, A_arbace_g2a_convert_A_const_361); var l__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__1); var t__8 any



	if jrt.A2g_Truth(type__5) { t__8 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__5) } else { t__8 = nil }
//line :755:1
	var mk__9 any; var tmp1 any = A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A_New_O(t__8); var tmp2 *jrt.Class
	var fncls__45 /*line :755:1*/*jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A_fn_class

	if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; mk__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :755:1
	var tg__10 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_352.GetRawRoot__O()).Invoke_O_O_O__O(names__4, l__7, mk__9); var tmp5 any





	if lang.Util_Equiv_O_O__Z(sp__1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(t.F_specs)) { tmp5 = t.F_gd } else { tmp5 = nil }; tg__10 = tmp3.Invoke_O_O_O__O(tmp4, tmp5, l__7)
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(values__6)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_367; var tmp8 any; var or__1927000174__auto____11 any = t__8
		if jrt.A2g_Truth(or__1927000174__auto____11) { tmp8 = or__1927000174__auto____11 } else { tmp8 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_95, sp__1) }
//line :762:1
		return lang.Tuple_Create_O_O__IPersistentVector(tg__10, tmp6.Invoke_O_O_O_O__O(nil, l__7, tmp7, tmp8)) } else { if jrt.A2g_Truth(t__8) { return lang.Tuple_Create_O_O__IPersistentVector(tg__10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(values__6, l__7)) } else { if A_arbace_g2a_convert_A_const_156 != nil { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp11 any = A_arbace_g2a_convert_A_const_368; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O__IPersistentVector(tmp9.Invoke_O_O_O_O__O(tg__10, tmp10, tmp11, tmp12.Ref()), lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(values__6, l__7)) } else { return nil } } } }
//line :757:1
func A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A_New_O(p0 any) *A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A{}; t.Ctor_O(p0); return t }
//line :757:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :757:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A) Invoke_O_O__O(self, p1__838000211_SHARP___1 any) any {


	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(p1__838000211_SHARP___1), t.F_t)
}







func A_arbace_g2a_convert_decl_bindings_fn__838000215_A_New_O(p0 any) *A_arbace_g2a_convert_decl_bindings_fn__838000215_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000215_A{}; t.Ctor_O(p0); return t }
//line :769:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :769:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_A) Invoke_O__O(self any) any { { var specs__1 any; var t_ any = t.F_specs; t.F_specs = nil; specs__1 = t_; var prev__2 any; var acc__3 any; lang.PersistentVector_Init(); acc__3 = lang.PersistentVector_EMPTY.Ref(); var iota__4 int64 = 0; var specs_STAR___5 any = specs__1; L1: for { var temp__1927000408__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(specs__1)
											if jrt.A2g_Truth(temp__1927000408__auto____6) { var sp__7 any = temp__1927000408__auto____6; var map__838000216__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__7); var map__838000216__9 any
												if lang.ISeq_InstanceOf(map__838000216__8) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000216__8)) { map__838000216__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000216__8), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000216__8)) { map__838000216__9 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000216__8) } else { lang.PersistentArrayMap_Init(); map__838000216__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000216__9 = map__838000216__8 }
//line :770:1
		var names__10 any = lang.RT_Get_O_O__O(map__838000216__9, A_arbace_g2a_convert_A_const_53); var type__11 any = lang.RT_Get_O_O__O(map__838000216__9, A_arbace_g2a_convert_A_const_59); var values__12 any = lang.RT_Get_O_O__O(map__838000216__9, A_arbace_g2a_convert_A_const_361); var ___13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__7); var l__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__7); var vec__838000218__15 any; _ = ___13



		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(values__12)) { var tmp1 *jrt.Boolean; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE; vec__838000218__15 = lang.Tuple_Create_O_O_O__IPersistentVector(type__11, values__12, tmp1.Ref()) } else { var tmp2 any = A_arbace_g2a_convert_A_const_59.Invoke_O__O(prev__2); var tmp3 any = A_arbace_g2a_convert_A_const_361.Invoke_O__O(prev__2); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; vec__838000218__15 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, tmp4.Ref()) }
//line :770:1
		var type__16 any = lang.RT_Nth_O_I_O__O(vec__838000218__15, lang.RT_IntCast_J__I(0), nil); var values__17 any = lang.RT_Nth_O_I_O__O(vec__838000218__15, lang.RT_IntCast_J__I(1), nil); var implicit__18 any = lang.RT_Nth_O_I_O__O(vec__838000218__15, lang.RT_IntCast_J__I(2), nil); var ___19 any; _ = ___19





		if jrt.A2g_Truth(implicit__18) { ___19 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_363) } else { ___19 = nil }
//line :770:1
		var t__20 any






		if jrt.A2g_Truth(type__16) { if jrt.A2g_Truth(implicit__18) {
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_11, nil)); var tmp5 any = A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A_New_O_O(type__16, l__14); var tmp6 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A_fn_class = fncls__41d; tmp6 = fncls__41d } else { tmp6 = fncls__41 }; t__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() } else {
				t__20 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__16) } } else {
//line :777:1
					t__20 = nil }
//line :770:1
		var mk__21 any; var tmp7 any = A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A_New_O(t__20); var tmp8 *jrt.Class
		var fncls__42 /*line :770:1*/*jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A_fn_class









		if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A_fn_class = fncls__42d; tmp8 = fncls__42d } else { tmp8 = fncls__42 }; mk__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :770:1
		var tg__22 any; var G__838000225__22_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_352.GetRawRoot__O()).Invoke_O_O_O__O(names__10, l__14, mk__21); var G__838000225__23_ any; var tmp9 bool; var and__1927000168__auto____23 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(specs_STAR___5)), 1)














		if and__1927000168__auto____23 { tmp9 = lang.Numbers_IsPos_J__Z(iota__4) } else { tmp9 = and__1927000168__auto____23 }
//line :782:1
		if tmp9 {


			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp12 any = A_arbace_g2a_convert_A_const_207; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; G__838000225__23_ = tmp10.Invoke_O_O_O_O__O(G__838000225__22_, tmp11, tmp12, tmp13.Ref()) } else {
//line :782:1
				G__838000225__23_ = G__838000225__22_ }; if jrt.A2g_Truth(implicit__18) {



					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp15 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp16 any = A_arbace_g2a_convert_A_const_364; var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; tg__22 = tmp14.Invoke_O_O_O_O__O(G__838000225__23_, tmp15, tmp16, tmp17.Ref()) } else {
//line :782:1
						tg__22 = G__838000225__23_ }
//line :770:1
		var init__23 any
















		if jrt.A2g_Truth(implicit__18) {
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_11, nil)); var tmp18 any = A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A_New_O_O(values__17, l__14); var tmp19 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A_fn_class = fncls__43d; tmp19 = fncls__43d } else { tmp19 = fncls__43 }; init__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O() } else {
				init__23 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(values__17, l__14) }
		var tmp20 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(specs__1); var tmp21 any; if jrt.A2g_Truth(implicit__18) { tmp21 = prev__2 } else { tmp21 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__7) }; specs__1, prev__2, acc__3, iota__4, specs_STAR___5 = tmp20, tmp21, lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(acc__3, tg__22, init__23), lang.Numbers_Inc_J__J(iota__4), specs_STAR___5; continue L1 } else {
			if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(specs_STAR___5)), 1) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_365) }
			if lang.Numbers_Gt_J_J__Z(iota__4, 1) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_366) }
//line :770:1
			return acc__3 } } }; /*line :769:1*/panic("a2g: unreachable") }








func A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A{}; t.Ctor_O_O(p0, p1); return t }
//line :778:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A) Ctor_O_O(c__type, c__l any) { t.F_type = c__type; t.F_l = c__l }
//line :778:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_159.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_l; t.F_l = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_type; t.F_type = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5.Invoke_O__O(tmp6)) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A_New_O(p0 any) *A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A{}; t.Ctor_O(p0); return t }
//line :780:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :780:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A) Invoke_O_O__O(self, nm__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__1), t.F_t); var tmp4 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp5 any = A_arbace_g2a_convert_A_const_177; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Ref()), lang.IFn_Cast(A_arbace_g2a_convert_A_const_362.GetRawRoot__O()).Invoke_O__O(nm__1))
}





func A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A{}; t.Ctor_O_O(p0, p1); return t }
//line :788:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A) Ctor_O_O(c__values, c__l any) { t.F_values = c__values; t.F_l = c__l }
//line :788:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_159.GetRawRoot__O()); var tmp3 any = t.F_l; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_values; t.F_values = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any; var t__2 any = t.F_l; t.F_l = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp6, tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }









func A_arbace_g2a_convert_decl_bindings_fn__838000235_A_New() *A_arbace_g2a_convert_decl_bindings_fn__838000235_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_bindings_fn__838000235_A{}; t.Ctor(); return t }
//line :798:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000235_A) Ctor() {}
//line :798:1
func (t *A_arbace_g2a_convert_decl_bindings_fn__838000235_A) Invoke_O_O__O(self, sp__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__1)
//line :798:1
	var map__838000236__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__1); var map__838000236__3 any

	if lang.ISeq_InstanceOf(map__838000236__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000236__2)) { map__838000236__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000236__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000236__2)) { map__838000236__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000236__2) } else { lang.PersistentArrayMap_Init(); map__838000236__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000236__3 = map__838000236__2 }
//line :798:1
	var name__4 any = lang.RT_Get_O_O__O(map__838000236__3, A_arbace_g2a_convert_A_const_48); var assign__5 any = lang.RT_Get_O_O__O(map__838000236__3, A_arbace_g2a_convert_A_const_350); var type__6 any = lang.RT_Get_O_O__O(map__838000236__3, A_arbace_g2a_convert_A_const_59); var tparams__7 any = lang.RT_Get_O_O__O(map__838000236__3, A_arbace_g2a_convert_A_const_370); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O())
	var tmp2 any = A_arbace_g2a_convert_A_const_205

	lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_372.GetRawRoot__O()).Invoke_O__O(sp__1))).Ref()))
//line :798:1
	var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tps__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_371.GetRawRoot__O()).Invoke_O__O(tparams__7); var nm__11 any; var G__838000238__11_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(name__4); var G__838000238__12_ any




		if jrt.A2g_Truth(assign__5) {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp6 any = A_arbace_g2a_convert_A_const_373; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; G__838000238__12_ = tmp4.Invoke_O_O_O_O__O(G__838000238__11_, tmp5, tmp6, tmp7.Ref()) } else {
//line :803:1
				G__838000238__12_ = G__838000238__11_ }; if jrt.A2g_Truth(tps__10) {

					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp10 any = A_arbace_g2a_convert_A_const_370; nm__11 = tmp8.Invoke_O_O_O_O__O(G__838000238__12_, tmp9, tmp10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__1), tps__10)) } else {
//line :803:1
						nm__11 = G__838000238__12_ }
//line :798:1
		var ___12 any; _ = ___12







		if jrt.A2g_Truth(tps__10) { ___12 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_374) } else { ___12 = nil }
//line :798:1
		tmp3 = lang.Tuple_Create_O_O__IPersistentVector(nm__11, lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__6)) }; return nil }()


	lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O()
//line :798:1
	if tmp11 != nil { panic(tmp11) }; return tmp3
}










func A_arbace_g2a_convert_decl_stmt_QMARK__A_New() *A_arbace_g2a_convert_decl_stmt_QMARK__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_stmt_QMARK__A{}; t.Ctor(); return t }
//line :810:1
func (t *A_arbace_g2a_convert_decl_stmt_QMARK__A) Ctor() {}
//line :810:1
func (t *A_arbace_g2a_convert_decl_stmt_QMARK__A) Invoke_O_O__O(self, st__0 any) any { var G__838000241__2_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(st__0); switch


	lang.Util_Hash_O__I(G__838000241__2_) >> 2 & 3 { case 1: if any(G__838000241__2_) == any(A_arbace_g2a_convert_A_const_94) {


		var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_376; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_375.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__0))) }
//line :813:1
	case 2: if any(G__838000241__2_) == any(A_arbace_g2a_convert_A_const_73) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__838000241__2_) == any(A_arbace_g2a_convert_A_const_76) {
		var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_358; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_20, tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__0)))).Ref() }
//line :813:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }





func A_arbace_g2a_convert_bindings_of_A_New() *A_arbace_g2a_convert_bindings_of_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_bindings_of_A{}; t.Ctor(); return t }
//line :819:1
func (t *A_arbace_g2a_convert_bindings_of_A) Ctor() {}
//line :819:1
func (t *A_arbace_g2a_convert_bindings_of_A) Invoke_O_O__O(self, st__0 any) any { var G__838000243__2_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(st__0); switch
										lang.Util_Hash_O__I(G__838000243__2_) >> 2 & 3 { case 1: if any(G__838000243__2_) == any(A_arbace_g2a_convert_A_const_94) {


		var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_376; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_377.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__0))) }
//line :820:1
	case 2: if any(G__838000243__2_) == any(A_arbace_g2a_convert_A_const_73) {

		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(st__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_378.GetRawRoot__O()).Invoke_O__O(st__0) }
//line :820:1
	case 3: if any(G__838000243__2_) == any(A_arbace_g2a_convert_A_const_76) {
		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(st__0)
//line :820:1
		var tmp2 any = A_arbace_g2a_convert_A_const_360; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_379.GetRawRoot__O()).Invoke_O__O(st__0)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__838000243__2_))))) }






func A_arbace_g2a_convert_dir_form_A_New() *A_arbace_g2a_convert_dir_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_dir_form_A{}; t.Ctor(); return t }
//line :827:1
func (t *A_arbace_g2a_convert_dir_form_A) Ctor() {}
//line :827:1
func (t *A_arbace_g2a_convert_dir_form_A) Invoke_O_O__O(self, p__838000245__0 any) any { var vec__838000246__2 any = p__838000245__0; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000246__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000246__2, lang.RT_IntCast_J__I(1), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__838000246__2, lang.RT_IntCast_J__I(2), nil);
											lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_convert_A_const_380.Get__O(), A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4));
											lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_381); var tmp1 lang.IFn =
											lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_382; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(text__5), text__5)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_139, l__3))) }

func A_arbace_g2a_convert_gap_directives_A_New() *A_arbace_g2a_convert_gap_directives_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_A{}; t.Ctor(); return t }
//line :832:1
func (t *A_arbace_g2a_convert_gap_directives_A) Ctor() {}
//line :832:1
func (t *A_arbace_g2a_convert_gap_directives_A) Invoke_O_O_O_O__O(self, stmts__0, from__1, to__2 any) any { var dirs__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_gap_directives_fn__838000251_A_New_O_O(from__1, to__2); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_g2a_convert_gap_directives_fn__838000251_A_fn_class; if



	fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_g2a_convert_gap_directives_fn__838000251_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; dirs__4 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_g2a_convert_A_const_386.Get__O()); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(dirs__4)) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_387.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(stmts__0)))).Ref(), nil)) } else {
//line :837:1
			var ranges__5 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_gap_directives_fn__838000256_A_New(); var tmp6 *jrt.Class
			var fncls__53 /*line :837:1*/*jrt.Class = A_arbace_g2a_convert_gap_directives_fn__838000256_A_fn_class

			if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_g2a_convert_gap_directives_fn__838000256_A_fn_class = fncls__53d; tmp6 = fncls__53d } else { tmp6 = fncls__53 }; ranges__5 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), stmts__0)
//line :837:1
			var inside_QMARK___6 any; var tmp7 any = A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A_New_O(ranges__5); var tmp8 *jrt.Class
			var fncls__51 /*line :837:1*/*jrt.Class = A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A_fn_class


			if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A_fn_class = fncls__51d; tmp8 = fncls__51d } else { tmp8 = fncls__51 }; inside_QMARK___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :837:1
			var free__7 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_384.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_gap_directives_fn__838000267_A_New_O(inside_QMARK___6); var tmp11 *jrt.Class
			var fncls__54 /*line :837:1*/*jrt.Class = A_arbace_g2a_convert_gap_directives_fn__838000267_A_fn_class



			if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_g2a_convert_gap_directives_fn__838000267_A_fn_class = fncls__54d; tmp11 = fncls__54d } else { tmp11 = fncls__54 }; free__7 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), dirs__4)
			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_gap_directives_fn__838000273_A_New_O_O(stmts__0, ranges__5); var tmp14 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_g2a_convert_gap_directives_fn__838000273_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_g2a_convert_gap_directives_fn__838000273_A_fn_class = fncls__56d; tmp14 = fncls__56d } else { tmp14 = fncls__56 }; return tmp12.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_387.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(stmts__0)))).Ref(), nil)), free__7) } }
//line :836:1
func A_arbace_g2a_convert_gap_directives_fn__838000251_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_gap_directives_fn__838000251_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_fn__838000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :836:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000251_A) Ctor_O_O(c__from, c__to any) { t.F_from = c__from; t.F_to = c__to }
//line :836:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000251_A) Invoke_O_O__O(self, p__838000250__1 any) any { var vec__838000252__2 any = p__838000250__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000252__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000252__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_from))); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_to)))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }


func A_arbace_g2a_convert_gap_directives_fn__838000256_A_New() *A_arbace_g2a_convert_gap_directives_fn__838000256_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_fn__838000256_A{}; t.Ctor(); return t }
//line :839:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000256_A) Ctor() {}
//line :839:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000256_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(s__1)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_388.GetRawRoot__O()).Invoke_O__O(s__1)) }
func A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A_New_O(p0 any) *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A{}; t.Ctor_O(p0); return t }
//line :840:1
func (t *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :840:1
func (t *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_383.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A_New_O(p__1); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_ranges) }
//line :840:1
func A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A_New_O(p0 any) *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A{}; t.Ctor_O(p0); return t }
//line :840:1
func (t *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :840:1
func (t *A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A) Invoke_O_O__O(self, p__838000259__1 any) any { var vec__838000261__2 any = p__838000259__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__838000261__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__838000261__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(a__3, t.F_p)), 0); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(t.F_p, b__4)), 0)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }
func A_arbace_g2a_convert_gap_directives_fn__838000267_A_New_O(p0 any) *A_arbace_g2a_convert_gap_directives_fn__838000267_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_fn__838000267_A{}; t.Ctor_O(p0); return t }
//line :841:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000267_A) Ctor_O(c__inside_QMARK_ any) { t.F_inside_QMARK_ = c__inside_QMARK_ }
//line :841:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000267_A) Invoke_O_O__O(self, p__838000266__1 any) any { var vec__838000268__2 any = p__838000266__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000268__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000268__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_inside_QMARK_); return tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)) }
func A_arbace_g2a_convert_gap_directives_fn__838000273_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_gap_directives_fn__838000273_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_fn__838000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :842:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000273_A) Ctor_O_O(c__stmts, c__ranges any) { t.F_stmts = c__stmts; t.F_ranges = c__ranges }
//line :842:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000273_A) Invoke_O_O_O__O(self, gaps__1, p__838000272__2 any) any { var vec__838000274__3 any = p__838000272__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__838000274__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__838000274__3, lang.RT_IntCast_J__I(1), nil); var d__6 any = vec__838000274__3; var k__7 any; var or__1927000174__auto____7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_389.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A_New_O_O(l__4, c__5); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A_fn_class; if
															fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; or__1927000174__auto____7 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_ranges)); if jrt.A2g_Truth(or__1927000174__auto____7) { k__7 = or__1927000174__auto____7 } else {
																k__7 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_stmts)).Ref() }; var tmp5 lang.IFn =
															lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_8.GetRawRoot__O(); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; return tmp5.Invoke_O_O_O_O__O(gaps__1, k__7, tmp6.Invoke_O_O__O(tmp7, tmp8.Ref()), d__6) }
//line :843:1
func A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A{}; t.Ctor_O_O(p0, p1); return t }
//line :843:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :843:1
func (t *A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A) Invoke_O_O_O__O(self, i__1, p__838000277__2 any) any { var vec__838000279__3 any = p__838000277__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__838000279__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__838000279__3, lang.RT_IntCast_J__I(1), nil); _ = ___5; if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }





func A_arbace_g2a_convert_stmts_forms_A_New() *A_arbace_g2a_convert_stmts_forms_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_A{}; t.Ctor(); return t }
//line :849:1
func (t *A_arbace_g2a_convert_stmts_forms_A) Ctor() {}
//line :849:1
func (t *A_arbace_g2a_convert_stmts_forms_A) Invoke_O_O_O_O_O__O(self, list__0, from__1, to__2, p__838000287__3 any) any { var map__838000288__5 any = p__838000287__3; var map__838000288__6 any; if lang.ISeq_InstanceOf(map__838000288__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000288__5)) { map__838000288__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000288__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000288__5)) { map__838000288__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000288__5) } else { lang.PersistentArrayMap_Init(); map__838000288__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000288__6 = map__838000288__5 }; var tail__7 any = lang.RT_Get_O_O__O(map__838000288__6, A_arbace_g2a_convert_A_const_318); var stmts__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_384.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_stmts_forms_fn__838000290_A_New(); var tmp4 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_g2a_convert_stmts_forms_fn__838000290_A_fn_class; if




	fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_169, false); A_arbace_g2a_convert_stmts_forms_fn__838000290_A_fn_class = fncls__62d; tmp4 = fncls__62d } else { tmp4 = fncls__62 }; stmts__8 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), list__0)); var ___9 any; var tmp5 any = /*line :849:1*/A_arbace_g2a_convert_stmts_forms_fn__838000296_A_New_O(list__0); var tmp6 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_g2a_convert_stmts_forms_fn__838000296_A_fn_class; _ = ___9; if





	fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_g2a_convert_stmts_forms_fn__838000296_A_fn_class = fncls__57d; tmp6 = fncls__57d } else { tmp6 = fncls__57 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var gaps__10 any = /*line :849:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_390.GetRawRoot__O()).Invoke_O_O_O__O(stmts__8, from__1, to__2); var n__11 int32 = lang.RT_Count_O__I(stmts__8); var body_build__12 *A_arbace_g2a_convert_stmts_forms_build__838000298_A = A_arbace_g2a_convert_stmts_forms_build__838000298_A_New_I_O_O_O(n__11, stmts__8, tail__7, gaps__10); var build__12 any; var tmp7 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_g2a_convert_stmts_forms_build__838000298_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_171, false); A_arbace_g2a_convert_stmts_forms_build__838000298_A_fn_class = fncls__61d; tmp7 = fncls__61d } else { tmp7 = fncls__61 }; build__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_build__12), tmp7, nil); return /*line :895:1*/ lang.IFn_Cast(A_arbace_g2a_convert_A_const_400.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(build__12).Invoke_O__O(A_arbace_g2a_convert_A_const_17)) }
//line :854:1
func A_arbace_g2a_convert_stmts_forms_fn__838000290_A_New() *A_arbace_g2a_convert_stmts_forms_fn__838000290_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_fn__838000290_A{}; t.Ctor(); return t }
//line :854:1
func (t *A_arbace_g2a_convert_stmts_forms_fn__838000290_A) Ctor() {}
//line :854:1
func (t *A_arbace_g2a_convert_stmts_forms_fn__838000290_A) Invoke_O_O__O(self, p1__838000285_SHARP___1 any) any { var tmp1 any = A_arbace_g2a_convert_A_const_86; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(p1__838000285_SHARP___1))).Ref() }
func A_arbace_g2a_convert_stmts_forms_fn__838000296_A_New_O(p0 any) *A_arbace_g2a_convert_stmts_forms_fn__838000296_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_fn__838000296_A{}; t.Ctor_O(p0); return t }
//line :855:1
func (t *A_arbace_g2a_convert_stmts_forms_fn__838000296_A) Ctor_O(c__list any) { t.F_list = c__list }
//line :855:1
func (t *A_arbace_g2a_convert_stmts_forms_fn__838000296_A) Invoke_O__O(self any) any { { var seq_838000292__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_list; t.F_list = nil; tmp2 = t_; seq_838000292__1 = tmp1.Invoke_O__O(tmp2); var chunk_838000293__2 any; var count_838000294__3 int64 = 0; var i_838000295__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_838000295__4, count_838000294__3) { var s__5 any = lang.Indexed_Cast(chunk_838000293__2).Nth_I__O(lang.RT_IntCast_J__I(i_838000295__4)); var tmp3 any = A_arbace_g2a_convert_A_const_86; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(s__5)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__5); seq_838000292__1, chunk_838000293__2, count_838000294__3, i_838000295__4 = seq_838000292__1, chunk_838000293__2, count_838000294__3, lang.Numbers_Unchecked_inc_J__J(i_838000295__4); continue L1 } else { seq_838000292__1, chunk_838000293__2, count_838000294__3, i_838000295__4 = seq_838000292__1, chunk_838000293__2, count_838000294__3, lang.Numbers_Unchecked_inc_J__J(i_838000295__4); continue L1 } } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(seq_838000292__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_838000292__6 any = temp__1927000414__auto____5; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(seq_838000292__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_838000292__6); seq_838000292__1, chunk_838000293__2, count_838000294__3, i_838000295__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(seq_838000292__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var s__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_838000292__6); var tmp4 any = A_arbace_g2a_convert_A_const_86; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(s__7)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__7); seq_838000292__1, chunk_838000293__2, count_838000294__3, i_838000295__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000292__6), nil, 0, 0; continue L1 } else { seq_838000292__1, chunk_838000293__2, count_838000294__3, i_838000295__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000292__6), nil, 0, 0; continue L1 } } } else { return nil } } } }; panic("a2g: unreachable") }


func A_arbace_g2a_convert_stmts_forms_build__838000298_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_g2a_convert_stmts_forms_build__838000298_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_build__838000298_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :858:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_A) Ctor_I_O_O_O(c__n int32, c__stmts, c__tail, c__gaps any) { t.F_n = c__n; t.F_stmts = c__stmts; t.F_tail = c__tail; t.F_gaps = c__gaps }
//line :858:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_A) Invoke_O_O__O(self, i__1 any) any {
	if lang.Numbers_Gte_O_J__Z(i__1, int64(t.F_n)) {
		var tmp1 any = t.F_gaps; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_391.GetRawRoot__O(), lang.RT_Get_O_O__O(tmp1, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref())) } else {
//line :859:1
			var s__2 any = lang.IFn_Cast(t.F_stmts).Invoke_O__O(i__1); var pre__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_391.GetRawRoot__O(), lang.RT_Get_O_O__O(t.F_gaps, i__1))



			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_375.GetRawRoot__O()).Invoke_O__O(s__2)) { var kind_of__4 any; var tmp2 any = A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A_fn_class
				if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_172, false); A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; kind_of__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :863:1
				var kind__5 any = lang.IFn_Cast(kind_of__4).Invoke_O__O(s__2); var vec__838000299__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_377.GetRawRoot__O()).Invoke_O__O(s__2); var ___7 any = lang.RT_Nth_O_I_O__O(vec__838000299__6, lang.RT_IntCast_J__I(0), nil); var bs__8 any = lang.RT_Nth_O_I_O__O(vec__838000299__6, lang.RT_IntCast_J__I(1), nil); var bs__9 any; var tmp4 any = A_arbace_g2a_convert_A_const_94; _ = ___7








				if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(s__2)) { var ll__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(s__2); var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_376; var dl__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(s__2)))


					lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_392); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__2)
					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_17; var tmp8 any = A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A_New_O_O_O(s__2, ll__9, dl__10); var tmp9 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_173, false); A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A_fn_class = fncls__60d; tmp9 = fncls__60d } else { tmp9 = fncls__60 }; bs__9 = tmp6.Invoke_O_O_O__O(bs__8, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :872:1
						bs__9 = bs__8 }
//line :863:1
				var vec__838000302__10 any; var tmp10 any = A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A_New_I_O_O_O_O_O_O(t.F_n, t.F_stmts, i__1, bs__9, kind__5, t.F_gaps, kind_of__4); var tmp11 *jrt.Class
				var fncls__59 /*line :863:1*/*jrt.Class = A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A_fn_class

















				if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_174, false); A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A_fn_class = fncls__59d; tmp11 = fncls__59d } else { tmp11 = fncls__59 }; vec__838000302__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :863:1
				var j__11 any = lang.RT_Nth_O_I_O__O(vec__838000302__10, lang.RT_IntCast_J__I(0), nil); var bs__12 any = lang.RT_Nth_O_I_O__O(vec__838000302__10, lang.RT_IntCast_J__I(1), nil); var l__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(s__2); var lf__14 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp14 any
























				if lang.Util_Equiv_O_O__Z(kind__5, A_arbace_g2a_convert_A_const_360) { tmp14 = A_arbace_g2a_convert_A_const_396 } else { tmp14 = A_arbace_g2a_convert_A_const_397 }; lf__14 = tmp12.Invoke_O_O_O_O_O_O__O(tmp13, nil, l__13, tmp14, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__13, bs__12), lang.IFn_Cast(self).Invoke_O__O(j__11))

				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(pre__3, lang.Tuple_Create_O__IPersistentVector(lf__14)) } else {

					var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_127.GetRawRoot__O()); var tmp17 any = A_arbace_g2a_convert_A_const_398.GetRawRoot__O(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_399.GetRawRoot__O()); var tmp19 any; var and__1927000168__auto____4 any = t.F_tail
					if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Util_Equiv_O_J__Z(i__1, lang.Numbers_Dec_J__J(int64(t.F_n))); if and__1927000168__auto____5 { var tmp20 any = t.F_gaps; tmp19 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(tmp20, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref())) } else { tmp19 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { tmp19 = and__1927000168__auto____4 }
//line :892:1
					return tmp15.Invoke_O_O_O__O(pre__3, tmp16.Invoke_O_O__O(tmp17, lang.Tuple_Create_O__IPersistentVector(tmp18.Invoke_O_O__O(s__2, tmp19))), lang.IFn_Cast(self).Invoke_O__O(lang.Numbers_Inc_O__Number(i__1))) } } }
//line :864:1
func A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A_New() *A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A{}; t.Ctor(); return t }
//line :864:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A) Ctor() {}
//line :864:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A) Invoke_O_O__O(self, st__1 any) any { var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_73; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(st__1)); if and__1927000168__auto____2 {
															var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_75; tmp1 = lang.Util_Equiv_O_O__Z(Lit_89, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(st__1))))) } else {
//line :864:1
		tmp1 = and__1927000168__auto____2 }; if tmp1 { return A_arbace_g2a_convert_A_const_369 } else { return A_arbace_g2a_convert_A_const_360 } }











func A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :876:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A) Ctor_O_O_O(c__s, c__ll, c__dl any) { t.F_s = c__s; t.F_ll = c__ll; t.F_dl = c__dl }
//line :876:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A) Invoke_O_O__O(self, p1__838000286_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_146.GetRawRoot__O(); var tmp3 any = A_arbace_g2a_convert_A_const_393; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_96; var tmp5 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_394.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(t.F_s))))); var tmp6 lang.IPersistentMap; var tmp7 any; var and__1927000168__auto____2 any = t.F_ll; if

	jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = t.F_dl; if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(t.F_ll, t.F_dl); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp9 any = t.F_ll; tmp7 = tmp8.Invoke_O_O__O(tmp9, lang.Numbers_Dec_O__Number(t.F_dl)) } else { tmp7 = and__1927000168__auto____4 } } else { tmp7 = and__1927000168__auto____3 } } else { tmp7 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp7) { tmp6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_395, t.F_ll)) } else { tmp6 = nil }; return /*line :876:1*/ tmp1.Invoke_O_O_O_O__O(p1__838000286_SHARP___1, tmp2, tmp5, tmp6) }




func A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A_New_I_O_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5, p6 any) *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A{}; t.Ctor_I_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :881:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A) Ctor_I_O_O_O_O_O_O(c__n int32, c__stmts, c__i, c__bs, c__kind, c__gaps, c__kind_of any) { t.F_n = c__n; t.F_stmts = c__stmts; t.F_i = c__i; t.F_bs = c__bs; t.F_kind = c__kind; t.F_gaps = c__gaps; t.F_kind_of = c__kind_of }
//line :881:1
func (t *A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any; var t_ any = t.F_i; t.F_i = nil; tmp1 = t_; j__1 = lang.Numbers_Inc_O__Number(tmp1); var bs__2 any; var t__2 any = t.F_bs; t.F_bs = nil; bs__2 = t__2; L1: for {
													var tmp2 any; var and__1927000168__auto____3 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_375.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(t.F_gaps, j__1)); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_A_const_94; var and__1927000168__auto____6 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1))); if jrt.A2g_Truth(and__1927000168__auto____6) {

		var tmp5 any = t.F_kind; var tmp6 lang.IFn = lang.IFn_Cast(t.F_kind_of); tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)))).Ref() } else {
//line :882:1
			tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp2) {


				j__1, bs__2 = lang.Numbers_Inc_O__Number(j__1), lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()).Invoke_O_O__O(bs__2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_377.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_stmts).Invoke_O__O(j__1)))); continue L1 } else {
//line :882:1
					return lang.Tuple_Create_O_O__IPersistentVector(j__1, bs__2) } } }; /*line :881:1*/panic("a2g: unreachable") }















func A_arbace_g2a_convert_stmt_list_A_New() *A_arbace_g2a_convert_stmt_list_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmt_list_A{}; t.Ctor(); return t }
//line :897:1
func (t *A_arbace_g2a_convert_stmt_list_A) Ctor() {}
//line :897:1
func (t *A_arbace_g2a_convert_stmt_list_A) Invoke_O_O_O__O(self, block__0, opts__1 any) any {


	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(block__0)
//line :897:1
	var map__838000313__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(block__0); var map__838000313__4 any



	if lang.ISeq_InstanceOf(map__838000313__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000313__3)) { map__838000313__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000313__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000313__3)) { map__838000313__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000313__3) } else { lang.PersistentArrayMap_Init(); map__838000313__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000313__4 = map__838000313__3 }
//line :897:1
	var list__5 any = lang.RT_Get_O_O__O(map__838000313__4, A_arbace_g2a_convert_A_const_71); var lbrace__6 any = lang.RT_Get_O_O__O(map__838000313__4, A_arbace_g2a_convert_A_const_60); var rbrace__7 any = lang.RT_Get_O_O__O(map__838000313__4, A_arbace_g2a_convert_A_const_147)




	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_401.GetRawRoot__O()).Invoke_O_O_O_O__O(list__5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lbrace__6), lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(rbrace__7), opts__1)
}
func A_arbace_g2a_convert_block_forms_A_New() *A_arbace_g2a_convert_block_forms_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_block_forms_A{}; t.Ctor(); return t }
//line :904:1
func (t *A_arbace_g2a_convert_block_forms_A) Ctor() {}
//line :904:1
func (t *A_arbace_g2a_convert_block_forms_A) Invoke_O_O__O(self, b__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(b__0); var tmp4 any = A_arbace_g2a_convert_A_const_402; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O_O_O__O(tmp2, b__0, tmp3, tmp4, tmp5.Invoke_O_O__O(b__0, tmp6.Ref()))
}
func A_arbace_g2a_convert_branch_A_New() *A_arbace_g2a_convert_branch_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_branch_A{}; t.Ctor(); return t }
//line :909:1
func (t *A_arbace_g2a_convert_branch_A) Ctor() {}
//line :909:1
func (t *A_arbace_g2a_convert_branch_A) Invoke_O_O_O__O(self, b__0, else_QMARK___1 any) any { var fs__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;



	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; fs__3 = tmp1.Invoke_O_O__O(b__0, tmp2.Ref()); var l__4 any = /*line :909:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(b__0); var tmp3 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(fs__3))); if and__1927000168__auto____5 {





		var f0__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(fs__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(f0__6)

		if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp6 any = A_arbace_g2a_convert_A_const_403; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(f0__6)); if or__1927000174__auto____8 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var and__1927000168__auto____9 any = else_QMARK___1
			if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_404); tmp5 = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(f0__6)) } else { tmp5 = and__1927000168__auto____9 } } } else {
//line :917:1
				tmp5 = and__1927000168__auto____7 }; tmp3 = tmp4.Invoke_O__O(tmp5) } else {
//line :915:1
					tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.A2g_Truth(tmp3) {



						return lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(fs__3) } else {
							return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), b__0, l__4, A_arbace_g2a_convert_A_const_405, fs__3) } }

func A_arbace_g2a_convert_init_vec_A_New() *A_arbace_g2a_convert_init_vec_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_vec_A{}; t.Ctor(); return t }
//line :922:1
func (t *A_arbace_g2a_convert_init_vec_A) Ctor() {}
//line :922:1
func (t *A_arbace_g2a_convert_init_vec_A) Invoke_O_O_O__O(self, init__0, l__1 any) any {


	if lang.Util_Identical_O_O__Z(init__0, nil) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O__O(l__1, tmp2.Ref()) } else {
//line :925:1
			var tmp3 bool; var tmp4 any = A_arbace_g2a_convert_A_const_76; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(init__0))

			if and__1927000168__auto____3 { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp3 = lang.Util_Equiv_O_O__Z(Lit_20, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(init__0))) } else { tmp3 = and__1927000168__auto____3 }
//line :925:1
			if tmp3 {


				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(init__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(init__0), lang.IFn_Cast(A_arbace_g2a_convert_A_const_379.GetRawRoot__O()).Invoke_O__O(init__0)) } else {
//line :925:1
					if A_arbace_g2a_convert_A_const_156 != nil {



						return lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(init__0), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_406.GetRawRoot__O()).Invoke_O__O(init__0))) } else {
//line :925:1
							return nil
						}
				}
		}
}

func A_arbace_g2a_convert_if_form_A_New() *A_arbace_g2a_convert_if_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_if_form_A{}; t.Ctor(); return t }
//line :931:1
func (t *A_arbace_g2a_convert_if_form_A) Ctor() {}
//line :931:1
func (t *A_arbace_g2a_convert_if_form_A) Invoke_O_O__O(self, n__0 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :931:1
	var map__838000319__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000319__3 any

	if lang.ISeq_InstanceOf(map__838000319__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000319__2)) { map__838000319__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000319__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000319__2)) { map__838000319__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000319__2) } else { lang.PersistentArrayMap_Init(); map__838000319__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000319__3 = map__838000319__2 }
//line :931:1
	var init__4 any = lang.RT_Get_O_O__O(map__838000319__3, A_arbace_g2a_convert_A_const_407); var body__5 any = lang.RT_Get_O_O__O(map__838000319__3, A_arbace_g2a_convert_A_const_315); var else__6 any = lang.RT_Get_O_O__O(map__838000319__3, A_arbace_g2a_convert_A_const_156); var test__7 any = lang.RT_Get_O_O__O(map__838000319__3, A_arbace_g2a_convert_A_const_408); var l__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var chain__9 any; var tmp1 any = A_arbace_g2a_convert_if_form_fn__838000324_A_New_O_O_O(test__7, else__6, body__5); var tmp2 *jrt.Class
	var fncls__63 /*line :931:1*/*jrt.Class = A_arbace_g2a_convert_if_form_fn__838000324_A_fn_class



	if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_g2a_convert_if_form_fn__838000324_A_fn_class = fncls__63d; tmp2 = fncls__63d } else { tmp2 = fncls__63 }; chain__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :931:1
	var vec__838000321__10 any = chain__9; var tests__11 any = lang.RT_Nth_O_I_O__O(vec__838000321__10, lang.RT_IntCast_J__I(0), nil); var final__12 any = lang.RT_Nth_O_I_O__O(vec__838000321__10, lang.RT_IntCast_J__I(1), nil)








	if lang.Util_Identical_O_O__Z(else__6, nil) {


		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp6 any = A_arbace_g2a_convert_A_const_409; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp8 lang.IPersistentVector
//line :942:1
		if jrt.A2g_Truth(init__4) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_410.GetRawRoot__O()).Invoke_O_O__O(init__4, l__8)) } else { tmp8 = nil }
		var tmp9 any = tmp8; var tmp10 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(test__7)); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; return tmp3.Invoke_O_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, n__0, l__8, tmp6, tmp7.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O__O(body__5, tmp12.Ref()))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_321.GetRawRoot__O()).Invoke_O__O(body__5)) } else {
//line :940:1
			var tmp13 any; var and__1927000168__auto____13 bool = lang.Util_Identical_O_O__Z(init__4, nil)




			if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = lang.Numbers_Gte_J_J__Z(int64(lang.RT_Count_O__I(tests__11)), 2); if and__1927000168__auto____14 { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp15 any = A_arbace_g2a_convert_A_const_43; tmp13 = tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(final__12)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() }
//line :940:1
			if jrt.A2g_Truth(tmp13) {





				lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_408)
//line :940:1
				var seq_838000326__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(tests__11)); var chunk_838000327__14 any; var count_838000328__15 int64 = 0; var i_838000329__16 int64 = 0; L1: for {






					if lang.Numbers_Lt_J_J__Z(i_838000329__16, count_838000328__15) { var vec__838000330__17 any = lang.Indexed_Cast(chunk_838000327__14).Nth_I__O(lang.RT_IntCast_J__I(i_838000329__16)); var ___18 any = lang.RT_Nth_O_I_O__O(vec__838000330__17, lang.RT_IntCast_J__I(0), nil); var ___19 any = lang.RT_Nth_O_I_O__O(vec__838000330__17, lang.RT_IntCast_J__I(1), nil); var e__20 any = lang.RT_Nth_O_I_O__O(vec__838000330__17, lang.RT_IntCast_J__I(2), nil); _ = ___18; _ = ___19; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(e__20); seq_838000326__13, chunk_838000327__14, count_838000328__15, i_838000329__16 = seq_838000326__13, chunk_838000327__14, count_838000328__15, lang.Numbers_Unchecked_inc_J__J(i_838000329__16); continue L1 } else { var temp__1927000414__auto____17 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(seq_838000326__13); if jrt.A2g_Truth(temp__1927000414__auto____17) { var seq_838000326__18 any = temp__1927000414__auto____17; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(seq_838000326__18)) { var c__1927000678__auto____19 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_838000326__18); seq_838000326__13, chunk_838000327__14, count_838000328__15, i_838000329__16 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(seq_838000326__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__838000333__19 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_838000326__18); var ___20 any = lang.RT_Nth_O_I_O__O(vec__838000333__19, lang.RT_IntCast_J__I(0), nil); var ___21 any = lang.RT_Nth_O_I_O__O(vec__838000333__19, lang.RT_IntCast_J__I(1), nil); var e__22 any = lang.RT_Nth_O_I_O__O(vec__838000333__19, lang.RT_IntCast_J__I(2), nil); _ = ___20; _ = ___21; lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(e__22); seq_838000326__13, chunk_838000327__14, count_838000328__15, i_838000329__16 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000326__18), nil, 0, 0; continue L1 } } }
//line :940:1
					break L1
				}






				var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp17 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp18 any = A_arbace_g2a_convert_A_const_411; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp21 any = A_arbace_g2a_convert_if_form_fn__838000337_A_New(); var tmp22 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_g2a_convert_if_form_fn__838000337_A_fn_class
				if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_137, false); A_arbace_g2a_convert_if_form_fn__838000337_A_fn_class = fncls__64d; tmp22 = fncls__64d } else { tmp22 = fncls__64 }
//line :948:1
				var tmp23 any = tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), tests__11); var tmp24 lang.IPersistentVector

				if jrt.A2g_Truth(final__12) { var tmp25 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(Lit_138, A_arbace_g2a_convert_A_const_156); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_412.GetRawRoot__O()); var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; tmp24 = lang.Tuple_Create_O_O__IPersistentVector(tmp25, tmp26.Invoke_O_O__O(final__12, tmp27.Ref())) } else { tmp24 = nil }
//line :948:1
				return tmp16.Invoke_O_O_O_O_O__O(tmp17, n__0, l__8, tmp18, tmp19.Invoke_O_O__O(tmp23, tmp24)) } else {
//line :940:1
					if A_arbace_g2a_convert_A_const_156 != nil {

















						var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp30 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp31 any = A_arbace_g2a_convert_A_const_413; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp33 lang.IPersistentVector
//line :955:1
						if jrt.A2g_Truth(init__4) { tmp33 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_410.GetRawRoot__O()).Invoke_O_O__O(init__4, l__8)) } else { tmp33 = nil
						}

						var tmp34 any = tmp33; var tmp35 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(test__7); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_412.GetRawRoot__O()); var tmp37 *jrt.Boolean; jrt.Boolean_Init(); tmp37 = jrt.Boolean_FALSE; var tmp38 any = tmp36.Invoke_O_O__O(body__5, tmp37.Ref()); var tmp39 any; var tmp40 any = A_arbace_g2a_convert_A_const_43
//line :957:1
						if lang.Util_Equiv_O_O__Z(tmp40, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(else__6)) { tmp39 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_414.GetRawRoot__O()).Invoke_O__O(else__6) } else { var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_412.GetRawRoot__O()); var tmp42 *jrt.Boolean; jrt.Boolean_Init(); tmp42 = jrt.Boolean_TRUE; tmp39 = tmp41.Invoke_O_O__O(else__6, tmp42.Ref()) }
						var tmp43 any = tmp29.Invoke_O_O_O_O_O__O(tmp30, n__0, l__8, tmp31, tmp32.Invoke_O_O__O(tmp34, lang.Tuple_Create_O_O_O__IPersistentVector(tmp35, tmp38, tmp39))); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()); var tmp45 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_321.GetRawRoot__O()).Invoke_O__O(body__5); var tmp46 lang.IPersistentMap; var tmp47 any = A_arbace_g2a_convert_A_const_123
						if lang.Util_Equiv_O_O__Z(tmp47, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(else__6)) { var tmp48 any = A_arbace_g2a_convert_A_const_415; var tmp49 *lang.Keyword = A_arbace_g2a_convert_A_const_60; var tmp50 any = tmp49.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(else__6)); var tmp51 any = A_arbace_g2a_convert_A_const_416; var tmp52 *lang.Keyword = A_arbace_g2a_convert_A_const_147; tmp46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp50, tmp51, tmp52.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(else__6)))) } else { tmp46 = nil }
//line :958:1
						return tmp28.Invoke_O_O__O(tmp43, tmp44.Invoke_O_O__O(tmp45, tmp46)) } else {
//line :940:1
							return nil } } } }
//line :935:1
func A_arbace_g2a_convert_if_form_fn__838000324_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_if_form_fn__838000324_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_if_form_fn__838000324_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :935:1
func (t *A_arbace_g2a_convert_if_form_fn__838000324_A) Ctor_O_O_O(c__test, c__else, c__body any) { t.F_test = c__test; t.F_else = c__else; t.F_body = c__body }
//line :935:1
func (t *A_arbace_g2a_convert_if_form_fn__838000324_A) Invoke_O__O(self any) any { { var acc__1 any; var tmp1 any; var t_ any = t.F_test; t.F_test = nil; tmp1 = t_; var tmp2 any = tmp1; var tmp3 any; var t__2 any = t.F_body; t.F_body = nil; tmp3 = t__2; acc__1 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3)); var e__2 any; var t__3 any = t.F_else; t.F_else = nil; e__2 = t__3; L1: for {
											var tmp4 bool; var tmp5 any = A_arbace_g2a_convert_A_const_43; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(e__2)); if and__1927000168__auto____3 { var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_407; tmp4 = lang.Util_Identical_O_O__Z(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__2)), nil) } else { tmp4 = and__1927000168__auto____3 }; if tmp4 {
												var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_408; var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_315; var tmp9 *lang.Keyword = A_arbace_g2a_convert_A_const_156; acc__1, e__2 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__1, lang.Tuple_Create_O_O_O__IPersistentVector(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__2)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__2)), e__2)), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(e__2)); continue L1 } else {
//line :936:1
			return lang.Tuple_Create_O_O__IPersistentVector(acc__1, e__2) } } }; /*line :935:1*/panic("a2g: unreachable") }













func A_arbace_g2a_convert_if_form_fn__838000337_A_New() *A_arbace_g2a_convert_if_form_fn__838000337_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_if_form_fn__838000337_A{}; t.Ctor(); return t }
//line :949:1
func (t *A_arbace_g2a_convert_if_form_fn__838000337_A) Ctor() {}
//line :949:1
func (t *A_arbace_g2a_convert_if_form_fn__838000337_A) Invoke_O_O__O(self, p__838000336__1 any) any { var vec__838000338__2 any = p__838000336__1; var c__3 any = lang.RT_Nth_O_I_O__O(vec__838000338__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__838000338__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(c__3); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_412.GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O__O(b__4, tmp3.Ref())) }












func A_arbace_g2a_convert_clause_bound_A_New() *A_arbace_g2a_convert_clause_bound_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_clause_bound_A{}; t.Ctor(); return t }
//line :962:1
func (t *A_arbace_g2a_convert_clause_bound_A) Ctor() {}
//line :962:1
func (t *A_arbace_g2a_convert_clause_bound_A) Invoke_O_O_O__O(self, body__0, i__1 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var cl__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(body__0)); if



	lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__1), int64(lang.RT_Count_O__I(cl__3))) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(cl__3, lang.RT_IntCast_O__I(lang.Numbers_Inc_O__Number(i__1))))) } else {
			var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_147; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(body__0))) } }

func A_arbace_g2a_convert_case_clause_A_New() *A_arbace_g2a_convert_case_clause_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_case_clause_A{}; t.Ctor(); return t }
//line :970:1
func (t *A_arbace_g2a_convert_case_clause_A) Ctor() {}
//line :970:1
func (t *A_arbace_g2a_convert_case_clause_A) Invoke_O_O_O_O__O(self, c__0, to__1, tswitch__2 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(c__0)
//line :970:1
	var map__838000344__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(c__0); var map__838000344__5 any

	if lang.ISeq_InstanceOf(map__838000344__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000344__4)) { map__838000344__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000344__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000344__4)) { map__838000344__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000344__4) } else { lang.PersistentArrayMap_Init(); map__838000344__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000344__5 = map__838000344__4 }
//line :970:1
	var list__6 any = lang.RT_Get_O_O__O(map__838000344__5, A_arbace_g2a_convert_A_const_71); var body__7 any = lang.RT_Get_O_O__O(map__838000344__5, A_arbace_g2a_convert_A_const_315); var colon__8 any = lang.RT_Get_O_O__O(map__838000344__5, A_arbace_g2a_convert_A_const_417); var l__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(c__0); var body_forms__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_401.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(colon__8); var tmp3 *lang.PersistentArrayMap



	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; body_forms__10 = tmp1.Invoke_O_O_O_O__O(body__7, tmp2, to__1, tmp3.Ref())
	if lang.Util_Identical_O_O__Z(list__6, nil) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), c__0, l__9, A_arbace_g2a_convert_A_const_418, body_forms__10) } else {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp6 any = A_arbace_g2a_convert_A_const_419; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(list__6)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_case_clause_fn__838000346_A_New_O(tswitch__2); var tmp11 *jrt.Class
			var fncls__65 /*line :977:1*/*jrt.Class = A_arbace_g2a_convert_case_clause_fn__838000346_A_fn_class

			if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_g2a_convert_case_clause_fn__838000346_A_fn_class = fncls__65d; tmp11 = fncls__65d } else { tmp11 = fncls__65 }
//line :977:1
			return tmp4.Invoke_O_O_O_O_O_O__O(tmp5, c__0, l__9, tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), list__6)), body_forms__10)
		} }
func A_arbace_g2a_convert_case_clause_fn__838000346_A_New_O(p0 any) *A_arbace_g2a_convert_case_clause_fn__838000346_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_case_clause_fn__838000346_A{}; t.Ctor_O(p0); return t }
//line :979:1
func (t *A_arbace_g2a_convert_case_clause_fn__838000346_A) Ctor_O(c__tswitch any) { t.F_tswitch = c__tswitch }
//line :979:1
func (t *A_arbace_g2a_convert_case_clause_fn__838000346_A) Invoke_O_O__O(self, e__1 any) any { if jrt.A2g_Truth(t.F_tswitch) {
												var tmp1 any = A_arbace_g2a_convert_A_const_175; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_176; if lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(e__1)))) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(e__1) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(e__1) } } else {
													return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(e__1) } }



func A_arbace_g2a_convert_clauses_A_New() *A_arbace_g2a_convert_clauses_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_clauses_A{}; t.Ctor(); return t }
//line :985:1
func (t *A_arbace_g2a_convert_clauses_A) Ctor() {}
//line :985:1
func (t *A_arbace_g2a_convert_clauses_A) Invoke_O_O_O__O(self, body__0, tswitch__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(body__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_clauses_fn__838000349_A_New_O_O(body__0, tswitch__1); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_g2a_convert_clauses_fn__838000349_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_g2a_convert_clauses_fn__838000349_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_71; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(body__0))) }
//line :987:1
func A_arbace_g2a_convert_clauses_fn__838000349_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_clauses_fn__838000349_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_clauses_fn__838000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :987:1
func (t *A_arbace_g2a_convert_clauses_fn__838000349_A) Ctor_O_O(c__body, c__tswitch any) { t.F_body = c__body; t.F_tswitch = c__tswitch }
//line :987:1
func (t *A_arbace_g2a_convert_clauses_fn__838000349_A) Invoke_O_O_O__O(self, i__1, c__2 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_420.GetRawRoot__O()).Invoke_O_O_O__O(c__2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_421.GetRawRoot__O()).Invoke_O_O__O(t.F_body, i__1), t.F_tswitch) }

func A_arbace_g2a_convert_comm_clause_A_New() *A_arbace_g2a_convert_comm_clause_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_comm_clause_A{}; t.Ctor(); return t }
//line :989:1
func (t *A_arbace_g2a_convert_comm_clause_A) Ctor() {}
//line :989:1
func (t *A_arbace_g2a_convert_comm_clause_A) Invoke_O_O_O__O(self, c__0, to__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(c__0)
//line :989:1
	var map__838000352__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(c__0); var map__838000352__4 any

	if lang.ISeq_InstanceOf(map__838000352__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000352__3)) { map__838000352__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000352__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000352__3)) { map__838000352__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000352__3) } else { lang.PersistentArrayMap_Init(); map__838000352__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000352__4 = map__838000352__3 }
//line :989:1
	var comm__5 any = lang.RT_Get_O_O__O(map__838000352__4, A_arbace_g2a_convert_A_const_422); var body__6 any = lang.RT_Get_O_O__O(map__838000352__4, A_arbace_g2a_convert_A_const_315); var colon__7 any = lang.RT_Get_O_O__O(map__838000352__4, A_arbace_g2a_convert_A_const_417); var l__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(c__0); var body_forms__9 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_401.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(colon__7); var tmp3 *lang.PersistentArrayMap



	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; body_forms__9 = tmp1.Invoke_O_O_O_O__O(body__6, tmp2, to__1, tmp3.Ref())
	if lang.Util_Identical_O_O__Z(comm__5, nil) {
		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), c__0, l__8, A_arbace_g2a_convert_A_const_423, body_forms__9) } else {
//line :994:1
			var cf__10 any; var G__838000354__10_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(comm__5)

		L1: switch { default: switch lang.Util_Hash_O__I(G__838000354__10_) >> 2 & 3 { case 0: if any(G__838000354__10_) == any(A_arbace_g2a_convert_A_const_38) {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_399.GetRawRoot__O()); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; cf__10 = tmp4.Invoke_O_O__O(comm__5, tmp5.Ref())
//line :996:1
			break L1 }; case 2: if any(G__838000354__10_) == any(A_arbace_g2a_convert_A_const_74) {

				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(comm__5); var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_33; cf__10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(comm__5)))
//line :996:1
				break L1 }; case 3: if any(G__838000354__10_) == any(A_arbace_g2a_convert_A_const_76) {


					var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_358; if lang.Util_Equiv_O_O__Z(Lit_20, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(comm__5))) {
						lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(comm__5); cf__10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(comm__5), lang.IFn_Cast(A_arbace_g2a_convert_A_const_379.GetRawRoot__O()).Invoke_O__O(comm__5)) } else {
							var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_399.GetRawRoot__O()); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; cf__10 = tmp8.Invoke_O_O__O(comm__5, tmp9.Ref()) }
//line :996:1
					break L1 }; default:
		}




			cf__10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_21, comm__5)}
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_g2a_convert_A_const_179.GetRawRoot__O(), c__0, l__8, A_arbace_g2a_convert_A_const_424, cf__10, body_forms__9)
		} }
func A_arbace_g2a_convert_assign_A_New() *A_arbace_g2a_convert_assign_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_assign_A{}; t.Ctor(); return t }
//line :1005:1
func (t *A_arbace_g2a_convert_assign_A) Ctor() {}
//line :1005:1
func (t *A_arbace_g2a_convert_assign_A) Invoke_O_O__O(self, n__0 any) any { var map__838000356__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var map__838000356__3 any; if
										lang.ISeq_InstanceOf(map__838000356__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000356__2)) { map__838000356__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000356__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000356__2)) { map__838000356__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000356__2) } else { lang.PersistentArrayMap_Init(); map__838000356__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000356__3 = map__838000356__2 }; var lhs__4 any = /*line :1005:1*/lang.RT_Get_O_O__O(map__838000356__3, A_arbace_g2a_convert_A_const_78); var rhs__5 any = lang.RT_Get_O_O__O(map__838000356__3, A_arbace_g2a_convert_A_const_351); var tok__6 any = lang.RT_Get_O_O__O(map__838000356__3, A_arbace_g2a_convert_A_const_358); var l__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0);


	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); if
	lang.Util_Equiv_O_O__Z(tok__6, Lit_1) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_425.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_304; if jrt.A2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lhs__4)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(rhs__5)).Ref())) { var p__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__4)); var tmp3 any; var tmp4 any = A_arbace_g2a_convert_A_const_72; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(p__8))

			if and__1927000168__auto____9 { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_convert_A_const_59; var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_176; var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_248; tmp3 = tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(p__8)))))) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp3) {
				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(p__8)
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_A_const_427; var tmp11 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var tmp12 *lang.Keyword = A_arbace_g2a_convert_A_const_248; return tmp9.Invoke_O_O_O_O_O_O__O(n__0, l__7, tmp10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(p__8))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(p__8))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__5))) } else {
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_convert_A_const_428; return tmp13.Invoke_O_O_O_O_O__O(n__0, l__7, tmp14, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__4)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__5))) } } else {
						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp16 any = A_arbace_g2a_convert_A_const_429; return tmp15.Invoke_O_O_O_O_O__O(n__0, l__7, tmp16, lang.IFn_Cast(A_arbace_g2a_convert_A_const_352.GetRawRoot__O()).Invoke_O_O_O__O(lhs__4, l__7, A_arbace_g2a_convert_A_const_260.GetRawRoot__O()), lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(rhs__5, l__7)) } } else {
//line :1009:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_426.GetRawRoot__O()).Invoke_O__O(tok__6)) {









								var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp18 any = A_arbace_g2a_convert_A_const_430; return tmp17.Invoke_O_O_O_O_O_O__O(n__0, l__7, tmp18, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__4)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_426.GetRawRoot__O()).Invoke_O__O(tok__6), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__5))) } else {
//line :1009:1
									if A_arbace_g2a_convert_A_const_156 != nil {










										return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, tok__6)).Ref(), n__0) } else {
//line :1009:1
											return nil } } } }












func A_arbace_g2a_convert_simple_stmt_A_New() *A_arbace_g2a_convert_simple_stmt_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_simple_stmt_A{}; t.Ctor(); return t }
//line :1022:1
func (t *A_arbace_g2a_convert_simple_stmt_A) Ctor() {}
//line :1022:1
func (t *A_arbace_g2a_convert_simple_stmt_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_399.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(s__0, tmp2.Ref())
}


func A_arbace_g2a_convert_stmt_A_New() *A_arbace_g2a_convert_stmt_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmt_A{}; t.Ctor(); return t }
//line :1029:1
func (t *A_arbace_g2a_convert_stmt_A) Ctor() {}
//line :1029:1
func (t *A_arbace_g2a_convert_stmt_A) Invoke_O_O_O__O(self, n__0, tail__1 any) any { var x__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_431.GetRawRoot__O()).Invoke_O_O__O(n__0, tail__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_432); if




	jrt.A2g_Truth(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0))) {
		var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_315; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()).Invoke_O_O__O(x__3, lang.IFn_Cast(A_arbace_g2a_convert_A_const_321.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0)))) } else {
//line :1034:1
			return x__3 } }



func A_arbace_g2a_convert_stmt_STAR__A_New() *A_arbace_g2a_convert_stmt_STAR__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmt_STAR__A{}; t.Ctor(); return t }
//line :1038:1
func (t *A_arbace_g2a_convert_stmt_STAR__A) Ctor() {}
//line :1038:1
func (t *A_arbace_g2a_convert_stmt_STAR__A) Invoke_O_O_O__O(self, n__0, tail__1 any) any { var f__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(n__0); var l__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(n__0); var G__838000361__5_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0); switch



	lang.Util_Hash_O__I(G__838000361__5_) >> 11 & 63 { case 1: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_43) {


















		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_414.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1042:1
	case 3: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_56) {






		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		var rs__6 any = A_arbace_g2a_convert_A_const_267.Invoke_O__O(f__3); var tmp1 any
		var and__1927000168__auto____7 any = tail__1







		if jrt.A2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rs__6)))).Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp1) {
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_433); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rs__6)) } else {
				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp4 any = A_arbace_g2a_convert_A_const_434; return tmp2.Invoke_O_O_O_O_O__O(tmp3, n__0, l__4, tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_260.GetRawRoot__O(), rs__6)) } }
//line :1042:1
	case 6: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_94) {



































































		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		var s__6 any = A_arbace_g2a_convert_A_const_376.Invoke_O__O(f__3)
		var tmp5 any = A_arbace_g2a_convert_A_const_86




































































		if lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(s__6)) {
			lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(s__6); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_435; return tmp6.Invoke_O_O_O_O__O(n__0, l__4, tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_394.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_96.Invoke_O__O(f__3))) } else {
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_A_const_436; var tmp10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_394.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_96.Invoke_O__O(f__3)); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_399.GetRawRoot__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; return tmp8.Invoke_O_O_O_O_O__O(n__0, l__4, tmp9, tmp10, tmp11.Invoke_O_O__O(s__6, tmp12.Ref())) } }
//line :1042:1
	case 17: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_116) {







































		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_315.Invoke_O__O(f__3))
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp15 any = A_arbace_g2a_convert_A_const_438; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()); var tmp17 any = A_arbace_g2a_convert_stmt_STAR__fn__838000362_A_New_O(f__3); var tmp18 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_g2a_convert_stmt_STAR__fn__838000362_A_fn_class
		if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_g2a_convert_stmt_STAR__fn__838000362_A_fn_class = fncls__69d; tmp18 = fncls__69d } else { tmp18 = fncls__69 }
//line :1083:1
		var tmp19 *lang.Keyword = A_arbace_g2a_convert_A_const_71; return tmp13.Invoke_O_O_O_O_O__O(tmp14, n__0, l__4, tmp15, tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_315.Invoke_O__O(f__3))))) }
//line :1042:1
	case 20: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_92) {












































		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		var map__838000364__6 any = f__3; var map__838000364__7 any













































		if lang.ISeq_InstanceOf(map__838000364__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000364__6)) { map__838000364__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000364__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000364__6)) { map__838000364__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000364__6) } else { lang.PersistentArrayMap_Init(); map__838000364__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000364__7 = map__838000364__6 }
//line :1042:1
		var init__8 any = lang.RT_Get_O_O__O(map__838000364__7, A_arbace_g2a_convert_A_const_407); var post__9 any = lang.RT_Get_O_O__O(map__838000364__7, A_arbace_g2a_convert_A_const_437); var body__10 any = lang.RT_Get_O_O__O(map__838000364__7, A_arbace_g2a_convert_A_const_315); var test__11 any = lang.RT_Get_O_O__O(map__838000364__7, A_arbace_g2a_convert_A_const_408); var body_forms__12 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()); var tmp21 *lang.PersistentArrayMap














































		lang.PersistentArrayMap_Init(); tmp21 = lang.PersistentArrayMap_EMPTY; body_forms__12 = tmp20.Invoke_O_O__O(body__10, tmp21.Ref())
		var tmp22 bool; var and__1927000168__auto____13 bool = lang.Util_Identical_O_O__Z(init__8, nil)
		if and__1927000168__auto____13 { var and__1927000168__auto____14 bool = lang.Util_Identical_O_O__Z(post__9, nil); if and__1927000168__auto____14 { tmp22 = lang.Util_Identical_O_O__Z(test__11, nil) } else { tmp22 = and__1927000168__auto____14 } } else { tmp22 = and__1927000168__auto____13 }
//line :1090:1
		if tmp22 {

			var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp24 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp25 any = A_arbace_g2a_convert_A_const_441; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()); var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; return tmp23.Invoke_O_O_O_O_O_O__O(tmp24, n__0, l__4, tmp25, tmp26.Invoke_O_O__O(Lit_164, tmp27.Ref()), body_forms__12) } else {
//line :1090:1
				var tmp28 any; var and__1927000168__auto____13_2 bool = lang.Util_Identical_O_O__Z(init__8, nil)


				if and__1927000168__auto____13_2 { var and__1927000168__auto____14_2 bool = lang.Util_Identical_O_O__Z(post__9, nil); if and__1927000168__auto____14_2 {
					var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp30 any; var c__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(test__11); var tmp31 any = A_arbace_g2a_convert_A_const_54; var and__1927000168__auto____16 bool = lang.Util_Equiv_O_O__Z(tmp31, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(c__15))
					if and__1927000168__auto____16 { var and__1927000168__auto____17 bool = lang.Util_Equiv_O_O__Z(Lit_164, lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(c__15)); if and__1927000168__auto____17 { var tmp32 *lang.Keyword = A_arbace_g2a_convert_A_const_174; tmp30 = tmp32.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_167.GetRawRoot__O()).Invoke_O__O(c__15)) } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17).Ref() } } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____16).Ref() }
//line :1094:1
					tmp28 = tmp29.Invoke_O__O(tmp30) } else {
//line :1093:1
						tmp28 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14_2).Ref() } } else { tmp28 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13_2).Ref() }
//line :1090:1
				if jrt.A2g_Truth(tmp28) {





					var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp35 any = A_arbace_g2a_convert_A_const_442; return tmp33.Invoke_O_O_O_O_O_O__O(tmp34, n__0, l__4, tmp35, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(test__11), body_forms__12) } else {
//line :1090:1
						if A_arbace_g2a_convert_A_const_156 != nil {







							var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp37 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp38 any = A_arbace_g2a_convert_A_const_443; var tmp39 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_410.GetRawRoot__O()).Invoke_O_O__O(init__8, l__4); var tmp40 any
							if jrt.A2g_Truth(test__11) { tmp40 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(test__11) } else { tmp40 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(Lit_22), nil, l__4) }
//line :1098:1
							var tmp41 any = tmp40; var tmp42 any

							if jrt.A2g_Truth(post__9) { tmp42 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_406.GetRawRoot__O()).Invoke_O__O(post__9) } else { tmp42 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_172.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(Lit_22), nil, l__4) }
//line :1098:1
							return tmp36.Invoke_O_O_O_O_O_O_O_O__O(tmp37, n__0, l__4, tmp38, tmp39, tmp41, tmp42, body_forms__12) } else {
//line :1090:1
								return nil } } } }
//line :1042:1
	case 21: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_118) {











		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_440); var head__6 any = tmp43.Invoke_O__O(A_arbace_g2a_convert_A_const_358.Invoke_O__O(f__3))














		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_96.Invoke_O__O(f__3)) {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O_O__O(n__0, l__4, head__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_394.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_96.Invoke_O__O(f__3))) } else {
				return lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(n__0, l__4, head__6) } }
//line :1042:1
	case 32: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_76) {



		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_444.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1042:1
	case 34: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_106) {





		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp45 any = A_arbace_g2a_convert_A_const_445; return tmp44.Invoke_O_O_O_O__O(n__0, l__4, tmp45, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_446.Invoke_O__O(f__3))) }
//line :1042:1
	case 35: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_91) {


		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp47 any; if lang.Util_Equiv_O_O__Z(Lit_165, A_arbace_g2a_convert_A_const_358.Invoke_O__O(f__3)) { tmp47 = A_arbace_g2a_convert_A_const_447 } else { tmp47 = A_arbace_g2a_convert_A_const_448 }; return tmp46.Invoke_O_O_O_O__O(n__0, l__4, tmp47, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3))) }
//line :1042:1
	case 36: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_110) {

























		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		var as__6 any = A_arbace_g2a_convert_A_const_350.Invoke_O__O(f__3); var guard__7 any; var G__838000366__7_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(as__6)



























	L2: switch { default: switch lang.Util_Hash_O__I(G__838000366__7_) >> 0 & 1 { case 0: if any(G__838000366__7_) == any(A_arbace_g2a_convert_A_const_74) { var tmp48 *lang.Keyword = A_arbace_g2a_convert_A_const_33; var ta__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp48.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(as__6)))





		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(as__6); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(ta__8)
		var tmp49 *lang.Keyword = A_arbace_g2a_convert_A_const_33; guard__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp49.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(ta__8)))
//line :1070:1
		break L2 }; case 1: if any(G__838000366__7_) == any(A_arbace_g2a_convert_A_const_76) { var map__838000367__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(as__6); var map__838000367__9 any
			if lang.ISeq_InstanceOf(map__838000367__8) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000367__8)) { map__838000367__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000367__8), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000367__8)) { map__838000367__9 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000367__8) } else { lang.PersistentArrayMap_Init(); map__838000367__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000367__9 = map__838000367__8 }
//line :1070:1
			var lhs__10 any = lang.RT_Get_O_O__O(map__838000367__9, A_arbace_g2a_convert_A_const_78); var rhs__11 any = lang.RT_Get_O_O__O(map__838000367__9, A_arbace_g2a_convert_A_const_351); var ta__12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(rhs__11))


			lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(as__6); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(ta__12)
			var tmp50 *lang.Keyword = A_arbace_g2a_convert_A_const_33; guard__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(as__6), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__10)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(tmp50.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(ta__12)))))
//line :1070:1
			break L2 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__838000366__7_)))))
	}






		var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp52 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp53 any = A_arbace_g2a_convert_A_const_449; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp55 lang.IPersistentVector
		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_407.Invoke_O__O(f__3)) { tmp55 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_410.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_407.Invoke_O__O(f__3), l__4)) } else { tmp55 = nil }
//line :1078:1
		var tmp56 any = tmp55; var tmp57 any = lang.Tuple_Create_O__IPersistentVector(guard__7); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_450.GetRawRoot__O()); var tmp59 any = A_arbace_g2a_convert_A_const_315.Invoke_O__O(f__3); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; return tmp51.Invoke_O_O_O_O_O__O(tmp52, n__0, l__4, tmp53, tmp54.Invoke_O_O_O__O(tmp56, tmp57, tmp58.Invoke_O_O__O(tmp59, tmp60.Ref()))) }
//line :1042:1
	case 44: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_86) {








































































		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
		return nil }; case 45: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_113) {




























































			lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
//line :1042:1
			var map__838000369__6 any = f__3; var map__838000369__7 any





























































			if lang.ISeq_InstanceOf(map__838000369__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000369__6)) { map__838000369__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000369__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000369__6)) { map__838000369__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000369__6) } else { lang.PersistentArrayMap_Init(); map__838000369__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000369__7 = map__838000369__6 }
//line :1042:1
			var key__8 any = lang.RT_Get_O_O__O(map__838000369__7, A_arbace_g2a_convert_A_const_85); var value__9 any = lang.RT_Get_O_O__O(map__838000369__7, A_arbace_g2a_convert_A_const_195); var tok__10 any = lang.RT_Get_O_O__O(map__838000369__7, A_arbace_g2a_convert_A_const_358); var x__11 any = lang.RT_Get_O_O__O(map__838000369__7, A_arbace_g2a_convert_A_const_33); var body__12 any = lang.RT_Get_O_O__O(map__838000369__7, A_arbace_g2a_convert_A_const_315); var define__13 bool = lang.Util_Equiv_O_O__Z(tok__10, Lit_20); var tgt__14 any; var tmp61 any = A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A_New_Z(define__13); var tmp62 *jrt.Class
			var fncls__71 /*line :1042:1*/*jrt.Class = A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A_fn_class































































			if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A_fn_class = fncls__71d; tmp62 = fncls__71d } else { tmp62 = fncls__71 }; tgt__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp61, tmp62, nil)
//line :1042:1
			var v__15 any; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp65 lang.IPersistentVector
































































			if jrt.A2g_Truth(key__8) { tmp65 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(tgt__14).Invoke_O__O(key__8)) } else { tmp65 = nil }; var tmp66 any = tmp65; var tmp67 lang.IPersistentVector; if jrt.A2g_Truth(value__9) { tmp67 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(tgt__14).Invoke_O__O(value__9)) } else { tmp67 = nil }; v__15 = tmp63.Invoke_O_O__O(l__4, tmp64.Invoke_O_O_O__O(tmp66, tmp67, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(x__11))))
//line :1042:1
			var fm__16 any; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp69 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp70 any = A_arbace_g2a_convert_A_const_451; var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()); var tmp72 *lang.PersistentArrayMap

































































			lang.PersistentArrayMap_Init(); tmp72 = lang.PersistentArrayMap_EMPTY; fm__16 = tmp68.Invoke_O_O_O_O_O_O__O(tmp69, n__0, l__4, tmp70, v__15, tmp71.Invoke_O_O__O(body__12, tmp72.Ref()))
			if lang.Util_Equiv_O_O__Z(tok__10, Lit_1) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(fm__16, A_arbace_g2a_convert_A_const_452) } else { return fm__16 } }
//line :1042:1
	case 48: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_104) {



















		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0)
		var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp74 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp75 any = A_arbace_g2a_convert_A_const_453; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp77 lang.IPersistentVector
		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_407.Invoke_O__O(f__3)) { tmp77 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_410.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_407.Invoke_O__O(f__3), l__4)) } else { tmp77 = nil }
//line :1063:1
		var tmp78 any = tmp77; var tmp79 lang.IPersistentVector

		if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_204.Invoke_O__O(f__3)) { tmp79 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_204.Invoke_O__O(f__3))) } else { tmp79 = nil }
//line :1063:1
		var tmp80 any = tmp79; var tmp81 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_450.GetRawRoot__O()); var tmp82 any = A_arbace_g2a_convert_A_const_315.Invoke_O__O(f__3); var tmp83 *jrt.Boolean; jrt.Boolean_Init(); tmp83 = jrt.Boolean_FALSE; return tmp73.Invoke_O_O_O_O_O__O(tmp74, n__0, l__4, tmp75, tmp76.Invoke_O_O_O__O(tmp78, tmp80, tmp81.Invoke_O_O__O(tmp82, tmp83.Ref()))) }
//line :1042:1
	case 50: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_74) {
		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_33.Invoke_O__O(f__3)) }
//line :1042:1
	case 52: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_38) {

		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp84 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp85 any = A_arbace_g2a_convert_A_const_454; return tmp84.Invoke_O_O_O_O_O__O(n__0, l__4, tmp85, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_46.Invoke_O__O(f__3)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_195.Invoke_O__O(f__3))) }
//line :1042:1
	case 53: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_119) {




		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(n__0); var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_179.GetRawRoot__O()); var tmp87 any = A_arbace_g2a_convert_A_const_455; return tmp86.Invoke_O_O_O_O__O(n__0, l__4, tmp87, lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_446.Invoke_O__O(f__3))) }
//line :1042:1
	case 58: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_73) {









































































		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_167, n__0) }
//line :1042:1
	case 62: if any(G__838000361__5_) == any(A_arbace_g2a_convert_A_const_123) {

















		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_456.GetRawRoot__O()).Invoke_O__O(n__0) }
//line :1042:1
	default:}; return /*line :1117:1*/ lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_168, n__0) }
//line :1084:1
func A_arbace_g2a_convert_stmt_STAR__fn__838000362_A_New_O(p0 any) *A_arbace_g2a_convert_stmt_STAR__fn__838000362_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmt_STAR__fn__838000362_A{}; t.Ctor_O(p0); return t }
//line :1084:1
func (t *A_arbace_g2a_convert_stmt_STAR__fn__838000362_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1084:1
func (t *A_arbace_g2a_convert_stmt_STAR__fn__838000362_A) Invoke_O_O_O__O(self, i__1, c__2 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_439.GetRawRoot__O()).Invoke_O_O__O(c__2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_421.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_315.Invoke_O__O(t.F_f), i__1)) }





















func A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A_New_Z(p0 bool) *A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A{}; t.Ctor_Z(p0); return t }
//line :1106:1
func (t *A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A) Ctor_Z(c__define bool) { t.F_define = c__define }
//line :1106:1
func (t *A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A) Invoke_O_O__O(self, e__1 any) any { if t.F_define { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(e__1)) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_260.GetRawRoot__O()).Invoke_O__O(e__1) } }














func A_arbace_g2a_convert_fn_sig_forms_A_New() *A_arbace_g2a_convert_fn_sig_forms_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_fn_sig_forms_A{}; t.Ctor(); return t }
//line :1121:1
func (t *A_arbace_g2a_convert_fn_sig_forms_A) Ctor() {}
//line :1121:1
func (t *A_arbace_g2a_convert_fn_sig_forms_A) Invoke_O_O__O(self, ft__0 any) any {


	return lang.IFn_Cast(A_arbace_g2a_convert_A_const_233.GetRawRoot__O()).Invoke_O__O(ft__0)
}


func A_arbace_g2a_convert_directive_name_A_New() *A_arbace_g2a_convert_directive_name_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_directive_name_A{}; t.Ctor(); return t }
//line :1128:1
func (t *A_arbace_g2a_convert_directive_name_A) Ctor() {}
//line :1128:1
func (t *A_arbace_g2a_convert_directive_name_A) Invoke_O_O__O(self, text__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(text__0, Lit_100)) { var body__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(text__0, A_arbace_g2a_convert_A_const_459); var i__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_458.GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_96)


		if jrt.A2g_Truth(i__3) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(body__2, A_arbace_g2a_convert_A_const_17, i__3) } else { return body__2 } } else {
//line :1131:1
			return nil
		}
}


func A_arbace_g2a_convert_directive_args_A_New() *A_arbace_g2a_convert_directive_args_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_directive_args_A{}; t.Ctor(); return t }
//line :1136:1
func (t *A_arbace_g2a_convert_directive_args_A) Ctor() {}
//line :1136:1
func (t *A_arbace_g2a_convert_directive_args_A) Invoke_O_O__O(self, text__0 any) any { var body__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(text__0, A_arbace_g2a_convert_A_const_459); var i__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_458.GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_96); if


	jrt.A2g_Truth(i__3) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_460.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(body__2, lang.Numbers_Inc_O__Number(i__3))) } else { return nil } }





func A_arbace_g2a_convert_attachable_QMARK__A_New() *A_arbace_g2a_convert_attachable_QMARK__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_attachable_QMARK__A{}; t.Ctor(); return t }
//line :1145:1
func (t *A_arbace_g2a_convert_attachable_QMARK__A) Ctor() {}
//line :1145:1
func (t *A_arbace_g2a_convert_attachable_QMARK__A) Invoke_O_O_O__O(self, text__0, decl_name__1 any) any { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_461.GetRawRoot__O()).Invoke_O__O(text__0); if




	jrt.A2g_Truth(temp__1927000414__auto____3) { var nm__4 any = temp__1927000414__auto____3; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_462.GetRawRoot__O()).Invoke_O__O(nm__4))
		if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(nm__4, Lit_5)); if jrt.A2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(nm__4, Lit_6)

			if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_463.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_464.GetRawRoot__O()).Invoke_O__O(text__0); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp3 = or__1927000174__auto____8 } else { tmp3 = Lit_7 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(decl_name__1, tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, A_arbace_g2a_convert_A_const_465)))).Ref() } } else {
//line :1151:1
					return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :1150:1
						return nil } }





func A_arbace_g2a_convert_directive_meta_A_New() *A_arbace_g2a_convert_directive_meta_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_directive_meta_A{}; t.Ctor(); return t }
//line :1156:1
func (t *A_arbace_g2a_convert_directive_meta_A) Ctor() {}
//line :1156:1
func (t *A_arbace_g2a_convert_directive_meta_A) Invoke_O_O__O(self, texts__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_directive_meta_fn__838000379_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_g2a_convert_directive_meta_fn__838000379_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_g2a_convert_directive_meta_fn__838000379_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_g2a_convert_A_const_126.GetRawRoot__O()).Invoke__O(), texts__0) }
//line :1159:1
func A_arbace_g2a_convert_directive_meta_fn__838000379_A_New() *A_arbace_g2a_convert_directive_meta_fn__838000379_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_directive_meta_fn__838000379_A{}; t.Ctor(); return t }
//line :1159:1
func (t *A_arbace_g2a_convert_directive_meta_fn__838000379_A) Ctor() {}
//line :1159:1
func (t *A_arbace_g2a_convert_directive_meta_fn__838000379_A) Invoke_O_O_O__O(self, m__1, t__2 any) any { var k__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_191.GetRawRoot__O()).Invoke_O_O__O(Lit_98, lang.IFn_Cast(A_arbace_g2a_convert_A_const_461.GetRawRoot__O()).Invoke_O__O(t__2)); var v__4 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_464.GetRawRoot__O()).Invoke_O__O(t__2); if

	jrt.A2g_Truth(or__1927000174__auto____4) { v__4 = or__1927000174__auto____4 } else { jrt.Boolean_Init(); v__4 = jrt.Boolean_TRUE.Ref() }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_210.GetRawRoot__O()).Invoke_O_O__O(m__1, k__3)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A_New_O(v__4); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; return tmp1.Invoke_O_O_O__O(m__1, k__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
			return lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()).Invoke_O_O_O__O(m__1, k__3, v__4) } }
//line :1163:1
func A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A_New_O(p0 any) *A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A{}; t.Ctor_O(p0); return t }
//line :1163:1
func (t *A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :1163:1
func (t *A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A) Invoke_O_O__O(self, p1__838000378_SHARP___1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_131.GetRawRoot__O()).Invoke_O__O(p1__838000378_SHARP___1)) { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_8.GetRawRoot__O()).Invoke_O_O__O(p1__838000378_SHARP___1, t.F_v) } else { return lang.Tuple_Create_O_O__IPersistentVector(p1__838000378_SHARP___1, t.F_v) } }



func A_arbace_g2a_convert_free_directive_A_New() *A_arbace_g2a_convert_free_directive_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_free_directive_A{}; t.Ctor(); return t }
//line :1167:1
func (t *A_arbace_g2a_convert_free_directive_A) Ctor() {}
//line :1167:1
func (t *A_arbace_g2a_convert_free_directive_A) Invoke_O_O__O(self, p__838000384__0 any) any { var vec__838000385__2 any = p__838000384__0; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000385__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__838000385__2, lang.RT_IntCast_J__I(1), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__838000385__2, lang.RT_IntCast_J__I(2), nil); _ = ___4;
												lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_466); var tmp1 lang.IFn =
												lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_467; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(text__5), text__5)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_139, l__3))) }



func A_arbace_g2a_convert_generic_decl_QMARK__A_New() *A_arbace_g2a_convert_generic_decl_QMARK__A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_generic_decl_QMARK__A{}; t.Ctor(); return t }
//line :1173:1
func (t *A_arbace_g2a_convert_generic_decl_QMARK__A) Ctor() {}
//line :1173:1
func (t *A_arbace_g2a_convert_generic_decl_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var G__838000389__2_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__0); switch


	lang.Util_Hash_O__I(G__838000389__2_) >> 2 & 1 { case 0: if any(G__838000389__2_) == any(A_arbace_g2a_convert_A_const_88) {






		var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_370; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0))))) }
//line :1176:1
	case 1: if any(G__838000389__2_) == any(A_arbace_g2a_convert_A_const_122) { var map__838000390__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0); var map__838000390__4 any
		if lang.ISeq_InstanceOf(map__838000390__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000390__3)) { map__838000390__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000390__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000390__3)) { map__838000390__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000390__3) } else { lang.PersistentArrayMap_Init(); map__838000390__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000390__4 = map__838000390__3 }
//line :1176:1
		var recv__5 any = lang.RT_Get_O_O__O(map__838000390__4, A_arbace_g2a_convert_A_const_235); var type__6 any = lang.RT_Get_O_O__O(map__838000390__4, A_arbace_g2a_convert_A_const_59); var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_370; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__6)))))

		if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
			if jrt.A2g_Truth(recv__5) { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_59; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var t__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(recv__5)))))); var t__9 any
				var tmp7 any = A_arbace_g2a_convert_A_const_97
				if lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(t__8)) { var tmp8 *lang.Keyword = A_arbace_g2a_convert_A_const_33; t__9 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_193.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(t__8))) } else { t__9 = t__8 }
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_468); return tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(t__9)) } else {
//line :1179:1
					return nil } } }
//line :1176:1
	default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }









func A_arbace_g2a_convert_func_decl_A_New() *A_arbace_g2a_convert_func_decl_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_func_decl_A{}; t.Ctor(); return t }
//line :1186:1
func (t *A_arbace_g2a_convert_func_decl_A) Ctor() {}
//line :1186:1
func (t *A_arbace_g2a_convert_func_decl_A) Invoke_O_O_O__O(self, d__0, dmeta__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_205; lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_372.GetRawRoot__O()).Invoke_O__O(d__0))).Ref()))
//line :1186:1
	var tmp3 any; tmp39 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var map__838000393__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0); var map__838000393__6 any


		if lang.ISeq_InstanceOf(map__838000393__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000393__5)) { map__838000393__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000393__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000393__5)) { map__838000393__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000393__5) } else { lang.PersistentArrayMap_Init(); map__838000393__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000393__6 = map__838000393__5 }
//line :1186:1
		var doc__7 any = lang.RT_Get_O_O__O(map__838000393__6, A_arbace_g2a_convert_A_const_217); var recv__8 any = lang.RT_Get_O_O__O(map__838000393__6, A_arbace_g2a_convert_A_const_235); var name__9 any = lang.RT_Get_O_O__O(map__838000393__6, A_arbace_g2a_convert_A_const_48); var type__10 any = lang.RT_Get_O_O__O(map__838000393__6, A_arbace_g2a_convert_A_const_59); var body__11 any = lang.RT_Get_O_O__O(map__838000393__6, A_arbace_g2a_convert_A_const_315); var l__12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(d__0); var docstr__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__7, A_arbace_g2a_convert_A_const_225.Get__O()); var nm__14 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(name__9), dmeta__1); var tmp6 any





		if jrt.A2g_Truth(body__11) { tmp6 = nil } else { tmp6 = A_arbace_g2a_convert_A_const_469 }; nm__14 = tmp4.Invoke_O_O__O(tmp5, tmp6)
//line :1186:1
		var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_370; var tps__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_371.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__10))); var vec__838000395__16 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_233.GetRawRoot__O()).Invoke_O__O(type__10); var seq__838000396__17 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(vec__838000395__16); var first__838000397__18 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq__838000396__17); var seq__838000396__19 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq__838000396__17); var ps__20 any = first__838000397__18; var rs__21 any = seq__838000396__19; var ps__22 any








		if jrt.A2g_Truth(recv__8) {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_252.GetRawRoot__O()); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; var tmp13 any = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11.Invoke_O_O__O(recv__8, tmp12.Ref()), ps__20)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp15 any = lang.RT_Meta_O__IPersistentMap(ps__20); var tmp16 any = A_arbace_g2a_convert_A_const_139; var tmp17 any; var tmp18 *lang.Keyword = A_arbace_g2a_convert_A_const_70; var or__1927000174__auto____22 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_124.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(recv__8)))
			if jrt.A2g_Truth(or__1927000174__auto____22) { tmp17 = or__1927000174__auto____22 } else { tmp17 = l__12 }
//line :1196:1
			ps__22 = tmp8.Invoke_O_O__O(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp16, tmp17)) } else {
//line :1195:1
				ps__22 = ps__20 }
//line :1186:1
		var tmp19 *lang.Keyword = A_arbace_g2a_convert_A_const_71; var tmp20 *lang.Keyword = A_arbace_g2a_convert_A_const_267; var has_results__23 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__10))))); var body_forms__24 any













		if jrt.A2g_Truth(body__11) { var tmp21 any = A_arbace_g2a_convert_A_const_318; body_forms__24 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_317.GetRawRoot__O()).Invoke_O_O__O(body__11, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(has_results__23)).Ref()))) } else { body_forms__24 = nil }
		lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(type__10)





		var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_272.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp25 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp26 any
//line :1202:1
		if jrt.A2g_Truth(recv__8) { tmp26 = A_arbace_g2a_convert_A_const_470 } else { tmp26 = A_arbace_g2a_convert_A_const_471
		}



		var tmp27 any = tmp26; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp29 lang.IPersistentVector
//line :1203:1
		if jrt.A2g_Truth(docstr__13) { tmp29 = lang.Tuple_Create_O__IPersistentVector(docstr__13) } else { tmp29 = nil
		}


		var tmp30 any = tmp29; var tmp31 lang.IPersistentVector
//line :1204:1
		if jrt.A2g_Truth(tps__15) { var tmp32 any = A_arbace_g2a_convert_A_const_370; tmp31 = lang.Tuple_Create_O_O__IPersistentVector(tmp32, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__12, tps__15)) } else { tmp31 = nil
		}

		var tmp33 any = tmp24.Invoke_O_O_O_O_O_O__O(tmp25, d__0, l__12, tmp27, nm__14, tmp28.Invoke_O_O_O_O_O__O(tmp30, tmp31, lang.Tuple_Create_O__IPersistentVector(ps__22), rs__21, body_forms__24)); var tmp34 lang.IPersistentMap
//line :1206:1
		if jrt.A2g_Truth(body__11) { var tmp35 any = A_arbace_g2a_convert_A_const_319; var tmp36 *lang.Keyword = A_arbace_g2a_convert_A_const_147; tmp34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, lang.IFn_Cast(A_arbace_g2a_convert_A_const_124.GetRawRoot__O()).Invoke_O__O(tmp36.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(body__11))))) } else { tmp34 = nil }
		var tmp37 any = A_arbace_g2a_convert_A_const_100; var tmp38 *lang.Keyword = A_arbace_g2a_convert_A_const_100; tmp3 = tmp22.Invoke_O_O__O(tmp23.Invoke_O_O__O(tmp33, tmp34), lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(type__10)))), lang.IFn_Cast(A_arbace_g2a_convert_A_const_321.GetRawRoot__O()).Invoke_O__O(body__11))) }; return nil }()
//line :1188:1
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O()
//line :1186:1
	if tmp39 != nil { panic(tmp39) }; return tmp3
}





















func A_arbace_g2a_convert_value_spec_target_A_New() *A_arbace_g2a_convert_value_spec_target_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_value_spec_target_A{}; t.Ctor(); return t }
//line :1209:1
func (t *A_arbace_g2a_convert_value_spec_target_A) Ctor() {}
//line :1209:1
func (t *A_arbace_g2a_convert_value_spec_target_A) Invoke_O_O_O_O__O(self, sp__0, kind__1, extra__2 any) any { var map__838000399__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__0); var map__838000399__5 any; if



	lang.ISeq_InstanceOf(map__838000399__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000399__4)) { map__838000399__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000399__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000399__4)) { map__838000399__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000399__4) } else { lang.PersistentArrayMap_Init(); map__838000399__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000399__5 = map__838000399__4 }; var names__6 any = /*line :1209:1*/lang.RT_Get_O_O__O(map__838000399__5, A_arbace_g2a_convert_A_const_53); var type__7 any = lang.RT_Get_O_O__O(map__838000399__5, A_arbace_g2a_convert_A_const_59); var l__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__0); var t__9 any; if





	jrt.A2g_Truth(type__7) { t__9 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__7) } else { t__9 = nil }; var mk__10 any; var tmp1 any = /*line :1209:1*/A_arbace_g2a_convert_value_spec_target_mk__838000401_A_New_O_O_O(t__9, extra__2, kind__1); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_g2a_convert_value_spec_target_mk__838000401_A_fn_class; if






	fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_185, false); A_arbace_g2a_convert_value_spec_target_mk__838000401_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; mk__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if


	lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(names__6))) {
		var tmp3 lang.IFn = lang.IFn_Cast(mk__10); var tmp4 any = A_arbace_g2a_convert_A_const_17; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(names__6)) } else {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp7 any = A_arbace_g2a_convert_A_const_472; return tmp5.Invoke_O_O_O_O_O__O(tmp6, nil, l__8, tmp7, lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()).Invoke_O_O__O(mk__10, names__6)) } }
//line :1216:1
func A_arbace_g2a_convert_value_spec_target_mk__838000401_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_value_spec_target_mk__838000401_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_value_spec_target_mk__838000401_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1216:1
func (t *A_arbace_g2a_convert_value_spec_target_mk__838000401_A) Ctor_O_O_O(c__t, c__extra, c__kind any) { t.F_t = c__t; t.F_extra = c__extra; t.F_kind = c__kind }
//line :1216:1
func (t *A_arbace_g2a_convert_value_spec_target_mk__838000401_A) Invoke_O_O_O__O(self, i__1, nm__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_230.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(nm__2), t.F_t); var tmp4 any
//line :1217:1
	if lang.Util_Equiv_O_O__Z(t.F_kind, A_arbace_g2a_convert_A_const_177) { tmp4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_362.GetRawRoot__O()).Invoke_O__O(nm__2) } else { tmp4 = nil }
	var tmp5 any = tmp2.Invoke_O_O__O(tmp3, tmp4); var tmp6 any; if lang.Numbers_IsZero_O__Z(i__1) { tmp6 = t.F_extra } else { tmp6 = nil }; return tmp1.Invoke_O_O__O(tmp5, tmp6)
}



func A_arbace_g2a_convert_gen_decl_A_New() *A_arbace_g2a_convert_gen_decl_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gen_decl_A{}; t.Ctor(); return t }
//line :1223:1
func (t *A_arbace_g2a_convert_gen_decl_A) Ctor() {}
//line :1223:1
func (t *A_arbace_g2a_convert_gen_decl_A) Invoke_O_O_O__O(self, d__0, spec_meta__1 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__0)
//line :1223:1
	var map__838000404__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0); var map__838000404__4 any

	if lang.ISeq_InstanceOf(map__838000404__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000404__3)) { map__838000404__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000404__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000404__3)) { map__838000404__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000404__3) } else { lang.PersistentArrayMap_Init(); map__838000404__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000404__4 = map__838000404__3 }
//line :1223:1
	var tok__5 any = lang.RT_Get_O_O__O(map__838000404__4, A_arbace_g2a_convert_A_const_358); var specs__6 any = lang.RT_Get_O_O__O(map__838000404__4, A_arbace_g2a_convert_A_const_359); var lparen__7 any = lang.RT_Get_O_O__O(map__838000404__4, A_arbace_g2a_convert_A_const_114); var doc__8 any = lang.RT_Get_O_O__O(map__838000404__4, A_arbace_g2a_convert_A_const_217); var l__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(d__0); var docstr__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__8, A_arbace_g2a_convert_A_const_225.Get__O()); var head__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O_O__O(Lit_98, tok__5)





	if lang.Util_Equiv_O_O__Z(tok__5, Lit_89) { var spec__12 any; var tmp1 any = A_arbace_g2a_convert_gen_decl_spec__838000406_A_New_O(spec_meta__1); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_g2a_convert_gen_decl_spec__838000406_A_fn_class
		if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_g2a_convert_gen_decl_spec__838000406_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; spec__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)











		if jrt.A2g_Truth(lparen__7) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp6 lang.IPersistentVector; if jrt.A2g_Truth(docstr__10) { tmp6 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp6 = nil }; var tmp7 any = tmp6; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_gen_decl_fn__838000410_A_New_O(spec__12); var tmp10 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_g2a_convert_gen_decl_fn__838000410_A_fn_class
			if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_g2a_convert_gen_decl_fn__838000410_A_fn_class = fncls__78d; tmp10 = fncls__78d } else { tmp10 = fncls__78 }
//line :1243:1
			return tmp3.Invoke_O_O_O_O_O__O(tmp4, d__0, l__9, head__11, tmp5.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), specs__6))) } else {
//line :1242:1
				var tmp11 lang.IFn = lang.IFn_Cast(spec__12); var tmp12 any = A_arbace_g2a_convert_A_const_17; var vec__838000412__13 any = tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(specs__6), nil); var seq__838000413__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(vec__838000412__13); var first__838000414__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq__838000413__14); var seq__838000413__16 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq__838000413__14); var nm__17 any = first__838000414__15; var more__18 any = seq__838000413__16; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp16 lang.IPersistentVector



				if jrt.A2g_Truth(docstr__10) { tmp16 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp16 = nil }; return tmp13.Invoke_O_O_O_O_O_O__O(tmp14, d__0, l__9, head__11, nm__17, tmp15.Invoke_O_O__O(tmp16, more__18)) } } else {
//line :1229:1
					var kind__12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_191.GetRawRoot__O()).Invoke_O__O(tok__5); var spec_vec__13 any; var tmp17 any = A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A_New_O_O(spec_meta__1, kind__12); var tmp18 *jrt.Class
					var fncls__77 /*line :1229:1*/*jrt.Class = A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A_fn_class


















					if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A_fn_class = fncls__77d; tmp18 = fncls__77d } else { tmp18 = fncls__77 }; spec_vec__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)





					if jrt.A2g_Truth(lparen__7) {
						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp22 lang.IPersistentVector; if jrt.A2g_Truth(docstr__10) { tmp22 = lang.Tuple_Create_O__IPersistentVector(docstr__10) } else { tmp22 = nil }; return tmp19.Invoke_O_O_O_O_O__O(tmp20, d__0, l__9, head__11, tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()).Invoke_O_O__O(spec_vec__13, specs__6))) } else {
//line :1254:1
							var sp__14 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(specs__6); var map__838000419__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__14); var map__838000419__16 any

							if lang.ISeq_InstanceOf(map__838000419__15) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000419__15)) { map__838000419__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000419__15), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000419__15)) { map__838000419__16 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000419__15) } else { lang.PersistentArrayMap_Init(); map__838000419__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000419__16 = map__838000419__15 }
//line :1254:1
							var values__17 any = lang.RT_Get_O_O__O(map__838000419__16, A_arbace_g2a_convert_A_const_361); var ___18 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__14); var tg__19 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_474.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()); var tmp25 any = lang.IFn_Cast(spec_meta__1).Invoke_O__O(A_arbace_g2a_convert_A_const_17); var tmp26 lang.IPersistentMap; _ = ___18




							if jrt.A2g_Truth(docstr__10) { tmp26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, docstr__10)) } else { tmp26 = nil }; tg__19 = tmp23.Invoke_O_O_O__O(sp__14, kind__12, tmp24.Invoke_O_O__O(tmp25, tmp26))
							var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp28 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp29 lang.IPersistentVector; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(values__17)) { tmp29 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(values__17, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__14))) } else { tmp29 = nil }; return tmp27.Invoke_O_O_O_O_O_O__O(tmp28, d__0, l__9, head__11, tg__19, tmp29) } } }
//line :1230:1
func A_arbace_g2a_convert_gen_decl_spec__838000406_A_New_O(p0 any) *A_arbace_g2a_convert_gen_decl_spec__838000406_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gen_decl_spec__838000406_A{}; t.Ctor_O(p0); return t }
//line :1230:1
func (t *A_arbace_g2a_convert_gen_decl_spec__838000406_A) Ctor_O(c__spec_meta any) { t.F_spec_meta = c__spec_meta }
//line :1230:1
func (t *A_arbace_g2a_convert_gen_decl_spec__838000406_A) Invoke_O_O_O_O__O(self, i__1, sp__2, extra__3 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_205; lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_g2a_convert_A_const_372.GetRawRoot__O()).Invoke_O__O(sp__2))).Ref()))
//line :1230:1
	var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var map__838000407__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2); var map__838000407__7 any


		if lang.ISeq_InstanceOf(map__838000407__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000407__6)) { map__838000407__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000407__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000407__6)) { map__838000407__7 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000407__6) } else { lang.PersistentArrayMap_Init(); map__838000407__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000407__7 = map__838000407__6 }
//line :1230:1
		var name__8 any = lang.RT_Get_O_O__O(map__838000407__7, A_arbace_g2a_convert_A_const_48); var assign__9 any = lang.RT_Get_O_O__O(map__838000407__7, A_arbace_g2a_convert_A_const_350); var type__10 any = lang.RT_Get_O_O__O(map__838000407__7, A_arbace_g2a_convert_A_const_59); var doc__11 any = lang.RT_Get_O_O__O(map__838000407__7, A_arbace_g2a_convert_A_const_217); var tparams__12 any = lang.RT_Get_O_O__O(map__838000407__7, A_arbace_g2a_convert_A_const_370); var d2__13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__11, A_arbace_g2a_convert_A_const_225.Get__O()); var nm__14 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_180.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_190.GetRawRoot__O()).Invoke_O__O(name__8); var tmp9 any





		if jrt.A2g_Truth(assign__9) { tmp9 = A_arbace_g2a_convert_A_const_473 } else { tmp9 = nil
		}

		var tmp10 any = tmp6.Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9), lang.IFn_Cast(t.F_spec_meta).Invoke_O__O(i__1)); var tmp11 lang.IPersistentMap
//line :1238:1
		if jrt.A2g_Truth(d2__13) { tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d2__13)) } else { tmp11 = nil }
		nm__14 = tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp10, tmp11), extra__3)
//line :1230:1
		var tps__15 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_371.GetRawRoot__O()).Invoke_O__O(tparams__12); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp13 any = lang.Tuple_Create_O__IPersistentVector(nm__14); var tmp14 lang.IPersistentVector










		if jrt.A2g_Truth(tps__15) { var tmp15 any = A_arbace_g2a_convert_A_const_370; tmp14 = lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__2), tps__15)) } else { tmp14 = nil }; tmp3 = tmp12.Invoke_O_O_O__O(tmp13, tmp14, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_218.GetRawRoot__O()).Invoke_O__O(type__10))) }; return nil }()
//line :1232:1
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O()
//line :1230:1
	if tmp16 != nil { panic(tmp16) }; return tmp3
}












func A_arbace_g2a_convert_gen_decl_fn__838000410_A_New_O(p0 any) *A_arbace_g2a_convert_gen_decl_fn__838000410_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gen_decl_fn__838000410_A{}; t.Ctor_O(p0); return t }
//line :1244:1
func (t *A_arbace_g2a_convert_gen_decl_fn__838000410_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :1244:1
func (t *A_arbace_g2a_convert_gen_decl_fn__838000410_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__2), lang.IFn_Cast(t.F_spec).Invoke_O_O_O__O(i__1, sp__2, nil)) }



func A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1248:1
func (t *A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A) Ctor_O_O(c__spec_meta, c__kind any) { t.F_spec_meta = c__spec_meta; t.F_kind = c__kind }
//line :1248:1
func (t *A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any {
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2)
//line :1248:1
	var map__838000416__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2); var map__838000416__4 any

	if lang.ISeq_InstanceOf(map__838000416__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000416__3)) { map__838000416__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000416__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000416__3)) { map__838000416__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000416__3) } else { lang.PersistentArrayMap_Init(); map__838000416__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000416__4 = map__838000416__3 }
//line :1248:1
	var values__5 any = lang.RT_Get_O_O__O(map__838000416__4, A_arbace_g2a_convert_A_const_361); var doc__6 any = lang.RT_Get_O_O__O(map__838000416__4, A_arbace_g2a_convert_A_const_217); var d2__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(doc__6, A_arbace_g2a_convert_A_const_225.Get__O()); var tg__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_474.GetRawRoot__O()); var tmp2 any = t.F_kind; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_146.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(t.F_spec_meta).Invoke_O__O(i__1); var tmp5 lang.IPersistentMap



	if jrt.A2g_Truth(d2__7) { tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_convert_A_const_217, d2__7)) } else { tmp5 = nil }; tg__8 = tmp1.Invoke_O_O_O__O(sp__2, tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5))
	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__2); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tg__8); var tmp10 lang.IPersistentVector; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(values__5)) { tmp10 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_354.GetRawRoot__O()).Invoke_O_O__O(values__5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__2))) } else { tmp10 = nil }; return tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10))
}









func A_arbace_g2a_convert_file_directives_A_New() *A_arbace_g2a_convert_file_directives_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_file_directives_A{}; t.Ctor(); return t }
//line :1264:1
func (t *A_arbace_g2a_convert_file_directives_A) Ctor() {}
//line :1264:1
func (t *A_arbace_g2a_convert_file_directives_A) Invoke_O_O_O__O(self, dump__0, name__1 any) any { var prefix__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, name__1, nil)).Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A_New_O(prefix__3); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A_fn_class; if



	fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_g2a_convert_A_const_475.Invoke_O__O(dump__0)); return tmp1.Invoke_O__O(tmp2) }
//line :1268:1
func A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A_New_O(p0 any) *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A{}; t.Ctor_O(p0); return t }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A) Ctor_O(c__prefix any) { t.F_prefix = c__prefix }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A) Invoke_O_O__O(self, s__838000423__1 any) any { var tmp1 any = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A_New_O_O_O(self, s__838000423__1, t.F_prefix); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1268:1
func A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A) Ctor_O_O_O(c__iter__838000422, c__s__838000423, c__prefix any) { t.F_iter__838000422 = c__iter__838000422; t.F_s__838000423 = c__s__838000423; t.F_prefix = c__prefix }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A) Invoke_O__O(self any) any { { var s__838000423__1 any; var t_ any = t.F_s__838000423; t.F_s__838000423 = nil; s__838000423__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000423__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000423__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000423__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000423__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000425__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A_New_O_I_O_O(t.F_prefix, size__1927001038__auto____5, b__838000425__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000422); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000425__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000423__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000425__6), nil) } } else { var vec__838000436__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000423__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__838000436__4, lang.RT_IntCast_J__I(0), nil); var text__6 any = lang.RT_Nth_O_I_O__O(vec__838000436__4, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(p__5, t.F_prefix)) { var vec__838000439__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(p__5, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_prefix)).Ref())); var l__8 any = lang.RT_Nth_O_I_O__O(vec__838000439__7, lang.RT_IntCast_J__I(0), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__838000439__7, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(text__6, Lit_123)




	if jrt.A2g_Truth(and__1927000168__auto____10) { tmp5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(c__9, A_arbace_g2a_convert_A_const_304) } else { tmp5 = and__1927000168__auto____10 }
//line :1268:1
	if jrt.A2g_Truth(tmp4.Invoke_O__O(tmp5)) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__838000422); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(l__8, c__9, text__6), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000423__3))) } else { s__838000423__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000423__3); continue L1 } } else { s__838000423__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000423__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :1268:1
func A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A) Ctor_O_I_O_O(c__prefix any, c__size__1927001038__auto__ int32, c__b__838000425, c__c__1927001037__auto__ any) { t.F_prefix = c__prefix; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__838000425 = c__b__838000425; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1268:1
func (t *A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A) Invoke_O__O(self any) any { { var i__838000424__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000424__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__838000429__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000424__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__838000429__2, lang.RT_IntCast_J__I(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O(vec__838000429__2, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(p__3, t.F_prefix)) { var vec__838000432__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()).Invoke_O_O__O(p__3, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_prefix)).Ref())); var l__6 any = lang.RT_Nth_O_I_O__O(vec__838000432__5, lang.RT_IntCast_J__I(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O(vec__838000432__5, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()); var tmp3 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(text__4, Lit_123)




	if jrt.A2g_Truth(and__1927000168__auto____8) { tmp3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(c__7, A_arbace_g2a_convert_A_const_304) } else { tmp3 = and__1927000168__auto____8 }
//line :1268:1
	if jrt.A2g_Truth(tmp2.Invoke_O__O(tmp3)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp5 any = t.F_b__838000425; tmp4.Invoke_O_O__O(tmp5, lang.Tuple_Create_O_O_O__IPersistentVector(l__6, c__7, text__4)); i__838000424__1 = lang.Numbers_Unchecked_inc_J__J(i__838000424__1); continue L1 } else { i__838000424__1 = lang.Numbers_Unchecked_inc_J__J(i__838000424__1); continue L1 } } else { i__838000424__1 = lang.Numbers_Unchecked_inc_J__J(i__838000424__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }







func A_arbace_g2a_convert_decl_name_A_New() *A_arbace_g2a_convert_decl_name_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_decl_name_A{}; t.Ctor(); return t }
//line :1276:1
func (t *A_arbace_g2a_convert_decl_name_A) Ctor() {}
//line :1276:1
func (t *A_arbace_g2a_convert_decl_name_A) Invoke_O_O__O(self, d__0 any) any { var G__838000445__2_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__0); switch


	lang.Util_Hash_O__I(G__838000445__2_) >> 4 & 3 { case 0: if any(G__838000445__2_) == any(A_arbace_g2a_convert_A_const_49) {

		var tmp1 *lang.Keyword = A_arbace_g2a_convert_A_const_53; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0)))) }
//line :1279:1
	case 2: if any(G__838000445__2_) == any(A_arbace_g2a_convert_A_const_122) {
		var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_48; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0))) }
//line :1279:1
	case 3: if any(G__838000445__2_) == any(A_arbace_g2a_convert_A_const_88) {


		var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_48; return lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__0))) }
//line :1279:1
	default:}; return nil }





func A_arbace_g2a_convert_imports_of_A_New() *A_arbace_g2a_convert_imports_of_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_A{}; t.Ctor(); return t }
//line :1285:1
func (t *A_arbace_g2a_convert_imports_of_A) Ctor() {}
//line :1285:1
func (t *A_arbace_g2a_convert_imports_of_A) Invoke_O_O__O(self, decls__0 any) any { var seq_838000447__2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(decls__0); var chunk_838000448__3 any; var count_838000449__4 int64 = 0; var i_838000450__5 int64 = 0; L1: for {
											if lang.Numbers_Lt_J_J__Z(i_838000450__5, count_838000449__4) { var d__6 any = lang.Indexed_Cast(chunk_838000448__3).Nth_I__O(lang.RT_IntCast_J__I(i_838000450__5)); var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__6)); if and__1927000168__auto____7 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp1 = lang.Util_Equiv_O_O__Z(Lit_46, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__6))) } else { tmp1 = and__1927000168__auto____7 }; if tmp1 { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__6); seq_838000447__2, chunk_838000448__3, count_838000449__4, i_838000450__5 = seq_838000447__2, chunk_838000448__3, count_838000449__4, lang.Numbers_Unchecked_inc_J__J(i_838000450__5); continue L1 } else { seq_838000447__2, chunk_838000448__3, count_838000449__4, i_838000450__5 = seq_838000447__2, chunk_838000448__3, count_838000449__4, lang.Numbers_Unchecked_inc_J__J(i_838000450__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(seq_838000447__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_838000447__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(seq_838000447__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(seq_838000447__7); seq_838000447__2, chunk_838000448__3, count_838000449__4, i_838000450__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(seq_838000447__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var d__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_838000447__7); var tmp4 bool; var tmp5 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__8)); if and__1927000168__auto____9 { var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp4 = lang.Util_Equiv_O_O__Z(Lit_46, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__8))) } else { tmp4 = and__1927000168__auto____9 }; if tmp4 { lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(d__8); seq_838000447__2, chunk_838000448__3, count_838000449__4, i_838000450__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000447__7), nil, 0, 0; continue L1 } else { seq_838000447__2, chunk_838000448__3, count_838000449__4, i_838000450__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(seq_838000447__7), nil, 0, 0; continue L1 } } } }
//line :1285:1
	break L1 }; var tmp7 lang.IFn =

	lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp8 any; var iter__1927001039__auto____2 any; var tmp9 any = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A_New(); var tmp10 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A_fn_class; if
	fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A_fn_class = fncls__87d; tmp10 = fncls__87d } else { tmp10 = fncls__87 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(decls__0); return /*line :1287:1*/ tmp7.Invoke_O__O(tmp8) }
func A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A_New() *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A{}; t.Ctor(); return t }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A) Ctor() {}
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A) Invoke_O_O__O(self, s__838000452__1 any) any { var tmp1 any = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A_New_O_O(self, s__838000452__1); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1288:1
func A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A) Ctor_O_O(c__iter__838000451, c__s__838000452 any) { t.F_iter__838000451 = c__iter__838000451; t.F_s__838000452 = c__s__838000452 }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A) Invoke_O__O(self any) any { { var s__838000452__1 any; var t_ any = t.F_s__838000452; t.F_s__838000452 = nil; s__838000452__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000452__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__4))
														if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp1 = lang.Util_Equiv_O_O__Z(Lit_46, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1288:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A_New(); var tmp5 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A_fn_class = fncls__85d; tmp5 = fncls__85d } else { tmp5 = fncls__85 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_359; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__838000451); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000452__1))) } else { s__838000452__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000452__1); continue L1 } } else { s__838000452__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000452__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :1288:1
func A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A_New() *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A{}; t.Ctor(); return t }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A) Ctor() {}
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A) Invoke_O_O__O(self, s__838000454__1 any) any { var tmp1 any = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A_New_O_O(self, s__838000454__1); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1288:1
func A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A) Ctor_O_O(c__iter__838000453, c__s__838000454 any) { t.F_iter__838000453 = c__iter__838000453; t.F_s__838000454 = c__s__838000454 }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A) Invoke_O__O(self any) any { { var s__838000454__1 any; var t_ any = t.F_s__838000454; t.F_s__838000454 = nil; s__838000454__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000454__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000454__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000454__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000454__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000456__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A_New_O_I_O(b__838000456__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A_fn_class = fncls__83d; tmp2 = fncls__83d } else { tmp2 = fncls__83 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000453); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000456__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000454__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000456__6), nil) } } else { var sp__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000454__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()); var tmp5 any; var map__838000465__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__4); var map__838000465__6 any


	if lang.ISeq_InstanceOf(map__838000465__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000465__5)) { map__838000465__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000465__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000465__5)) { map__838000465__6 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000465__5) } else { lang.PersistentArrayMap_Init(); map__838000465__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000465__6 = map__838000465__5 }
//line :1288:1
	var name__7 any = lang.RT_Get_O_O__O(map__838000465__6, A_arbace_g2a_convert_A_const_48); var path__8 any = lang.RT_Get_O_O__O(map__838000465__6, A_arbace_g2a_convert_A_const_50); var l__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__4); var p__10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(path__8); var pv__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(p__10), p__10)






	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__4); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(path__8)
	if lang.Util_Identical_O_O__Z(name__7, nil) {
		var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_477; tmp5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__4)))), pv__11)) } else {
//line :1296:1
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_478); if jrt.A2g_Truth(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__7))) {

				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(name__7); tmp5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__7)), pv__11)) } else {
//line :1296:1
					if A_arbace_g2a_convert_A_const_156 != nil {


						lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(name__7); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__9, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__7)), pv__11)); var tmp11 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp12 any = A_arbace_g2a_convert_A_const_373; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp5 = tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, tmp12, tmp13.Ref()) } else {
//line :1296:1
							tmp5 = nil } } }
//line :1288:1
	var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__838000453); return tmp4.Invoke_O_O__O(tmp5, tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000454__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1288:1
func A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A) Ctor_O_I_O(c__b__838000456 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__838000456 = c__b__838000456; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1288:1
func (t *A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A) Invoke_O__O(self any) any { { var i__838000455__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000455__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000455__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000456; var tmp4 any; var map__838000462__3 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2); var map__838000462__4 any


	if lang.ISeq_InstanceOf(map__838000462__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000462__3)) { map__838000462__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000462__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000462__3)) { map__838000462__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000462__3) } else { lang.PersistentArrayMap_Init(); map__838000462__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000462__4 = map__838000462__3 }
//line :1288:1
	var name__5 any = lang.RT_Get_O_O__O(map__838000462__4, A_arbace_g2a_convert_A_const_48); var path__6 any = lang.RT_Get_O_O__O(map__838000462__4, A_arbace_g2a_convert_A_const_50); var l__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_171.GetRawRoot__O()).Invoke_O__O(sp__2); var p__8 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(path__6); var pv__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(p__8), p__8)






	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(sp__2); lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(path__6)
	if lang.Util_Identical_O_O__Z(name__5, nil) {
		var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_477; tmp4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__7, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__2)))), pv__9)) } else {
//line :1296:1
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_476); if jrt.A2g_Truth(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__5))) {

				lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(name__5); tmp4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__7, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__5)), pv__9)) } else {
//line :1296:1
					if A_arbace_g2a_convert_A_const_156 != nil {


						lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(name__5); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_144.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()).Invoke_O_O__O(l__7, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(name__5)), pv__9)); var tmp10 any = A_arbace_g2a_convert_A_const_140.GetRawRoot__O(); var tmp11 any = A_arbace_g2a_convert_A_const_373; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; tmp4 = tmp8.Invoke_O_O_O_O__O(tmp9, tmp10, tmp11, tmp12.Ref()) } else {
//line :1296:1
							tmp4 = nil } } }
//line :1288:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__838000455__1 = lang.Numbers_Unchecked_inc_J__J(i__838000455__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }












func A_arbace_g2a_convert_convert_file_A_New() *A_arbace_g2a_convert_convert_file_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_A{}; t.Ctor(); return t }
//line :1301:1
func (t *A_arbace_g2a_convert_convert_file_A) Ctor() {}
//line :1301:1
func (t *A_arbace_g2a_convert_convert_file_A) Invoke_O_O_O_O__O(self, dump__0, fe__1, ns_sym__2 any) any { var ast__4 any = A_arbace_g2a_convert_A_const_479.Invoke_O__O(fe__1); var f__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(ast__4); var name__6 any = A_arbace_g2a_convert_A_const_480.Invoke_O__O(fe__1); var groups__7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;







	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____7 any; var tmp5 any = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A_New(); var tmp6 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A_fn_class = fncls__106d; tmp6 = fncls__106d } else { tmp6 = fncls__106 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_g2a_convert_A_const_503.Invoke_O__O(fe__1)); groups__7 = tmp1.Invoke_O_O__O(tmp3, tmp4); var pkg_pos__8 any = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_491.Invoke_O__O(f__5)); var pkg_line__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(pkg_pos__8); var decls__10 any = A_arbace_g2a_convert_A_const_481.Invoke_O__O(f__5); var dirs__11 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_482.GetRawRoot__O()).Invoke_O_O__O(dump__0, name__6); var ranges__12 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_160.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_convert_file_fn__838000487_A_New(); var tmp9 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000487_A_fn_class; if












	fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_g2a_convert_convert_file_fn__838000487_A_fn_class = fncls__107d; tmp9 = fncls__107d } else { tmp9 = fncls__107 }; ranges__12 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), decls__10); var kept__13 any; var tmp10 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_483.GetRawRoot__O()); var tmp11 *lang.PersistentHashSet;













	lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; kept__13 = tmp10.Invoke_O__O(tmp11.Ref()); var placed__14 any; var tmp12 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_483.GetRawRoot__O()); var tmp13 *lang.PersistentHashSet;














	lang.PersistentHashSet_Init(); tmp13 = lang.PersistentHashSet_EMPTY; placed__14 = tmp12.Invoke_O__O(tmp13.Ref()); var header__15 any; var tmp14 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_27.GetRawRoot__O()); var tmp15 any = A_arbace_g2a_convert_convert_file_fn__838000490_A_New_O(pkg_pos__8); var tmp16 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000490_A_fn_class; if















	fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_g2a_convert_convert_file_fn__838000490_A_fn_class = fncls__108d; tmp16 = fncls__108d } else { tmp16 = fncls__108 }; header__15 = tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), dirs__11); var body_dirs__16 any; var tmp17 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_384.GetRawRoot__O()); var tmp18 any = A_arbace_g2a_convert_convert_file_fn__838000496_A_New_O(pkg_pos__8); var tmp19 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000496_A_fn_class; if
















	fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_g2a_convert_convert_file_fn__838000496_A_fn_class = fncls__109d; tmp19 = fncls__109d } else { tmp19 = fncls__109 }; body_dirs__16 = tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), dirs__11); var last_import__17 any; var tmp20 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_484.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_389.GetRawRoot__O()); var tmp22 any = A_arbace_g2a_convert_convert_file_fn__838000501_A_New_O(ranges__12); var tmp23 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000501_A_fn_class; if

















	fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_g2a_convert_convert_file_fn__838000501_A_fn_class = fncls__110d; tmp23 = fncls__110d } else { tmp23 = fncls__110 }; last_import__17 = tmp20.Invoke_O__O(tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), decls__10)); var inside_of__18 any; var tmp24 any = /*line :1301:1*/A_arbace_g2a_convert_convert_file_inside_of__838000504_A_New_O(ranges__12); var tmp25 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_g2a_convert_convert_file_inside_of__838000504_A_fn_class; if




















	fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_g2a_convert_convert_file_inside_of__838000504_A_fn_class = fncls__89d; tmp25 = fncls__89d } else { tmp25 = fncls__89 }; inside_of__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var plan__19 any; var tmp26 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp27 any = A_arbace_g2a_convert_convert_file_fn__838000516_A_New_O_O_O_O(inside_of__18, ranges__12, last_import__17, decls__10); var tmp28 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000516_A_fn_class; if


























	fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_g2a_convert_convert_file_fn__838000516_A_fn_class = fncls__113d; tmp28 = fncls__113d } else { tmp28 = fncls__113 }; var tmp29 any = /*line :1327:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var tmp30 any = A_arbace_g2a_convert_A_const_487; var tmp31 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp31 = lang.PersistentArrayMap_EMPTY; var tmp32 any = tmp31.Ref(); var tmp33 any = A_arbace_g2a_convert_A_const_498; var tmp34 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp34 = lang.PersistentArrayMap_EMPTY; var tmp35 any = tmp34.Ref(); var tmp36 any = A_arbace_g2a_convert_A_const_507; var tmp37 *lang.PersistentVector; lang.PersistentVector_Init(); tmp37 = lang.PersistentVector_EMPTY; var tmp38 any = tmp37.Ref(); var tmp39 any = A_arbace_g2a_convert_A_const_508; var tmp40 *lang.PersistentVector; lang.PersistentVector_Init(); tmp40 = lang.PersistentVector_EMPTY; plan__19 = tmp26.Invoke_O_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp32, tmp33, tmp35, tmp36, tmp38, tmp39, tmp40.Ref())), body_dirs__16); var attach_meta__20 any; var tmp41 any = /*line :1301:1*/A_arbace_g2a_convert_convert_file_attach_meta__838000529_A_New_O_O(placed__14, plan__19); var tmp42 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_g2a_convert_convert_file_attach_meta__838000529_A_fn_class; if





















































	fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_g2a_convert_convert_file_attach_meta__838000529_A_fn_class = fncls__92d; tmp42 = fncls__92d } else { tmp42 = fncls__92 }; attach_meta__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); var imports__21 any; var tmp43 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_509.GetRawRoot__O()); var tmp45 any = A_arbace_g2a_convert_convert_file_fn__838000539_A_New(); var tmp46 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000539_A_fn_class; if


























































	fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_g2a_convert_convert_file_fn__838000539_A_fn_class = fncls__114d; tmp46 = fncls__114d } else { tmp46 = fncls__114 }; var tmp47 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp49 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_510.GetRawRoot__O()).Invoke_O__O(decls__10); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp51 any = A_arbace_g2a_convert_convert_file_fn__838000541_A_New_O(placed__14); var tmp52 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000541_A_fn_class; if

	fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_g2a_convert_convert_file_fn__838000541_A_fn_class = fncls__115d; tmp52 = fncls__115d } else { tmp52 = fncls__115 }; imports__21 = /*line :1360:1*/tmp43.Invoke_O__O(tmp44.Invoke_O_O__O(tmp47, tmp48.Invoke_O_O__O(tmp49, tmp50.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil), A_arbace_g2a_convert_A_const_508.Invoke_O__O(plan__19))))); var doc__22 any = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_219.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_217.Invoke_O__O(f__5), groups__7); var file_form__23 any;































































	lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_213, kept__13)); var tmp53 any = A_arbace_g2a_convert_convert_file_fn__838000543_A_New_O_O_O_O_O_O_O_O(f__5, doc__22, name__6, dump__0, imports__21, fe__1, header__15, pkg_line__9); var tmp54 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000543_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_g2a_convert_convert_file_fn__838000543_A_fn_class = fncls__97d; tmp54 = fncls__97d } else { tmp54 = fncls__97 }; file_form__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O(); var ___24 any; var tmp55 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()); var tmp56 any = A_arbace_g2a_convert_A_const_125.GetRawRoot__O(); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp58 any = A_arbace_g2a_convert_convert_file_fn__838000554_A_New(); var tmp59 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000554_A_fn_class; _ = ___24; if













































































	fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_g2a_convert_convert_file_fn__838000554_A_fn_class = fncls__116d; tmp59 = fncls__116d } else { tmp59 = fncls__116 }; ___24 = tmp55.Invoke_O_O_O__O(placed__14, tmp56, tmp57.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp58, tmp59, nil), header__15)); var decl_forms__25 any; var tmp60 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp61 any = A_arbace_g2a_convert_A_const_225; var tmp62 any = A_arbace_g2a_convert_A_const_213; var tmp63 any = A_arbace_g2a_convert_A_const_380; var tmp64 any = A_arbace_g2a_convert_A_const_386;














































































	lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(tmp60.Invoke_O_O_O_O_O_O_O_O__O(tmp61, groups__7, tmp62, kept__13, tmp63, placed__14, tmp64, A_arbace_g2a_convert_A_const_507.Invoke_O__O(plan__19))); var tmp65 any = A_arbace_g2a_convert_convert_file_fn__838000559_A_New_O_O_O_O(attach_meta__20, placed__14, plan__19, decls__10); var tmp66 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000559_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_g2a_convert_convert_file_fn__838000559_A_fn_class = fncls__103d; tmp66 = fncls__103d } else { tmp66 = fncls__103 }; decl_forms__25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp65, tmp66, nil).Invoke__O(); var unplaced__26 any; var tmp67 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_384.GetRawRoot__O()); var tmp68 any = A_arbace_g2a_convert_convert_file_fn__838000571_A_New_O(placed__14); var tmp69 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000571_A_fn_class; if


































































































	fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_g2a_convert_convert_file_fn__838000571_A_fn_class = fncls__117d; tmp69 = fncls__117d } else { tmp69 = fncls__117 }; unplaced__26 = tmp67.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil), dirs__11); var comments__27 any; var tmp70 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp71 any = A_arbace_g2a_convert_convert_file_fn__838000576_A_New_O_O(kept__13, dirs__11); var tmp72 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000576_A_fn_class; if




































































































	fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_g2a_convert_convert_file_fn__838000576_A_fn_class = fncls__121d; tmp72 = fncls__121d } else { tmp72 = fncls__121 }; comments__27 = /*line :1401:1*/tmp70.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil), lang.IFn_Cast(A_arbace_g2a_convert_A_const_126.GetRawRoot__O()).Invoke__O(), A_arbace_g2a_convert_A_const_503.Invoke_O__O(fe__1));












	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(ast__4);
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_181.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_48.Invoke_O__O(f__5)); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(unplaced__26)) { lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_514) }; var tmp73 any = A_arbace_g2a_convert_A_const_48; var tmp74 any = A_arbace_g2a_convert_A_const_502; var tmp75 lang.IFn = /*line :1301:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()); var tmp76 any = A_arbace_g2a_convert_A_const_516; var tmp77 any = A_arbace_g2a_convert_A_const_139; var tmp78 any = A_arbace_g2a_convert_A_const_515; var tmp79 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_137.GetRawRoot__O()).Invoke_O_O__O(tmp75.Invoke_O_O__O(tmp76, lang.IFn_Cast(A_arbace_g2a_convert_A_const_141.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_517, ns_sym__2)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp77, pkg_line__9, tmp78, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__2, nil)).Ref()))), file_form__23), decl_forms__25); var tmp80 any = A_arbace_g2a_convert_A_const_503; var tmp81 any = A_arbace_g2a_convert_A_const_504; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, name__6, tmp74, tmp79, tmp80, comments__27, tmp81, lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(unplaced__26))) }







func A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A_New() *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A{}; t.Ctor(); return t }
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A) Ctor() {}
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A) Invoke_O_O__O(self, s__838000478__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A_New_O_O(self, s__838000478__1); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1309:1
func A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A) Ctor_O_O(c__iter__838000477, c__s__838000478 any) { t.F_iter__838000477 = c__iter__838000477; t.F_s__838000478 = c__s__838000478 }
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A) Invoke_O__O(self any) any { { var s__838000478__1 any; var t_ any = t.F_s__838000478; t.F_s__838000478 = nil; s__838000478__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000478__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000478__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000478__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000478__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000480__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A_New_O_I_O(b__838000480__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000477); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000480__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000478__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000480__6), nil) } } else { var g__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000478__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__838000477); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_71.Invoke_O__O(g__4))), g__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000478__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1309:1
func A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A) Ctor_O_I_O(c__b__838000480 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__838000480 = c__b__838000480; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1309:1
func (t *A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A) Invoke_O__O(self any) any { { var i__838000479__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000479__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var g__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000479__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000480; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_71.Invoke_O__O(g__2))), g__2)); i__838000479__1 = lang.Numbers_Unchecked_inc_J__J(i__838000479__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_g2a_convert_convert_file_fn__838000487_A_New() *A_arbace_g2a_convert_convert_file_fn__838000487_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000487_A{}; t.Ctor(); return t }
//line :1314:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000487_A) Ctor() {}
//line :1314:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000487_A) Invoke_O_O__O(self, d__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(d__1)), lang.IFn_Cast(A_arbace_g2a_convert_A_const_388.GetRawRoot__O()).Invoke_O__O(d__1)) }


func A_arbace_g2a_convert_convert_file_fn__838000490_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000490_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000490_A{}; t.Ctor_O(p0); return t }
//line :1317:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000490_A) Ctor_O(c__pkg_pos any) { t.F_pkg_pos = c__pkg_pos }
//line :1317:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000490_A) Invoke_O_O__O(self, p__838000489__1 any) any { var vec__838000491__2 any = p__838000489__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000491__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000491__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_pkg_pos)))).Ref() }
func A_arbace_g2a_convert_convert_file_fn__838000496_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000496_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000496_A{}; t.Ctor_O(p0); return t }
//line :1318:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000496_A) Ctor_O(c__pkg_pos any) { t.F_pkg_pos = c__pkg_pos }
//line :1318:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000496_A) Invoke_O_O__O(self, p__838000495__1 any) any { var vec__838000497__2 any = p__838000495__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000497__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000497__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4), t.F_pkg_pos)))).Ref() }
func A_arbace_g2a_convert_convert_file_fn__838000501_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000501_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000501_A{}; t.Ctor_O(p0); return t }
//line :1319:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000501_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :1319:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000501_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__2)); if and__1927000168__auto____3 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp1 = lang.Util_Equiv_O_O__Z(Lit_46, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__2))) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 {
													return lang.IFn_Cast(A_arbace_g2a_convert_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_ranges).Invoke_O__O(i__1)) } else {
//line :1319:1
		return nil } }


func A_arbace_g2a_convert_convert_file_inside_of__838000504_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_inside_of__838000504_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_inside_of__838000504_A{}; t.Ctor_O(p0); return t }
//line :1322:1
func (t *A_arbace_g2a_convert_convert_file_inside_of__838000504_A) Ctor_O(c__ranges any) { t.F_ranges = c__ranges }
//line :1322:1
func (t *A_arbace_g2a_convert_convert_file_inside_of__838000504_A) Invoke_O_O__O(self, p__838000503__1 any) any { var vec__838000505__2 any = p__838000503__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000505__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000505__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_389.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A_New_O_O(l__3, c__4); var tmp4 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A_fn_class; if
														fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A_fn_class = fncls__88d; tmp4 = fncls__88d } else { tmp4 = fncls__88 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_ranges)) }
//line :1323:1
func A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1323:1
func (t *A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1323:1
func (t *A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A) Invoke_O_O_O__O(self, i__1, p__838000508__2 any) any { var vec__838000510__3 any = p__838000508__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__838000510__3, lang.RT_IntCast_J__I(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O(vec__838000510__3, lang.RT_IntCast_J__I(1), nil); var tmp1 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c))), 0); if and__1927000168__auto____6 {
																	tmp1 = lang.Numbers_Lte_J_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c), b__5)), 0) } else {
//line :1323:1
		tmp1 = and__1927000168__auto____6 }; if tmp1 { return i__1 } else { return nil } }




func A_arbace_g2a_convert_convert_file_fn__838000516_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_convert_convert_file_fn__838000516_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000516_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1328:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_A) Ctor_O_O_O_O(c__inside_of, c__ranges, c__last_import, c__decls any) { t.F_inside_of = c__inside_of; t.F_ranges = c__ranges; t.F_last_import = c__last_import; t.F_decls = c__decls }
//line :1328:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_A) Invoke_O_O_O__O(self, acc__1, p__838000515__2 any) any { var vec__838000517__3 any = p__838000515__2; var l__4 any = lang.RT_Nth_O_I_O__O(vec__838000517__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__838000517__3, lang.RT_IntCast_J__I(1), nil); var text__6 any = lang.RT_Nth_O_I_O__O(vec__838000517__3, lang.RT_IntCast_J__I(2), nil); var dv__7 any = vec__838000517__3; var tmp1 lang.IFn = lang.IFn_Cast(t.F_inside_of); var temp__1927000408__auto____8 any = tmp1.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5)); if
															jrt.A2g_Truth(temp__1927000408__auto____8) { var k__9 any = temp__1927000408__auto____8; var tmp2 any = t.F_decls; var d__10 any = lang.RT_Nth_O_I__O(tmp2, lang.RT_IntCast_O__I(k__9)); var tmp3 any; var tmp4 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__10))

		if and__1927000168__auto____11 { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_114; tmp3 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__10)) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }; if jrt.A2g_Truth(tmp3) { var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_359; var specs__11 any = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__10)); var si__12 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_389.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A_New_O_O(l__4, c__5); var tmp10 *jrt.Class
			var fncls__111 /*line :1331:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A_fn_class

			if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A_fn_class = fncls__111d; tmp10 = fncls__111d } else { tmp10 = fncls__111 }; si__12 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), specs__11))
			var tmp11 any; var and__1927000168__auto____13 any = si__12; if jrt.A2g_Truth(and__1927000168__auto____13) { tmp11 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_505.GetRawRoot__O()).Invoke_O_O__O(text__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_506.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(specs__11, lang.RT_IntCast_O__I(si__12)))) } else { tmp11 = and__1927000168__auto____13 }; if jrt.A2g_Truth(tmp11) {
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_A_const_487; var tmp14 any = A_arbace_g2a_convert_A_const_145.GetRawRoot__O(); var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(k__9, si__12); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()); var tmp17 any = A_arbace_g2a_convert_A_const_8.GetRawRoot__O(); var tmp18 *lang.PersistentVector; lang.PersistentVector_Init(); tmp18 = lang.PersistentVector_EMPTY; return tmp12.Invoke_O_O_O_O_O_O__O(acc__1, tmp13, tmp14, tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Ref()), dv__7) } else {
					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_convert_A_const_507; return tmp19.Invoke_O_O_O_O__O(acc__1, tmp20, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), dv__7) } } else {
						var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp22 any = A_arbace_g2a_convert_A_const_507; return tmp21.Invoke_O_O_O_O__O(acc__1, tmp22, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), dv__7) } } else {
//line :1329:1
							var k__9_2 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_389.GetRawRoot__O()); var tmp25 any = A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A_New_O_O(l__4, c__5); var tmp26 *jrt.Class
							var fncls__112 /*line :1329:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A_fn_class








							if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A_fn_class = fncls__112d; tmp26 = fncls__112d } else { tmp26 = fncls__112 }; k__9_2 = tmp23.Invoke_O__O(tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), t.F_ranges))
//line :1329:1
							var d__10_2 any









							if jrt.A2g_Truth(k__9_2) { var tmp27 any = t.F_decls; d__10_2 = lang.RT_Nth_O_I__O(tmp27, lang.RT_IntCast_O__I(k__9_2)) } else { d__10_2 = nil }
//line :1329:1
							var target__11 any










							if jrt.A2g_Truth(d__10_2) {
								var tmp28 any = A_arbace_g2a_convert_A_const_122; if lang.Util_Equiv_O_O__Z(tmp28, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__10_2)) { target__11 = d__10_2 } else { var tmp29 any; var tmp30 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____11_2 bool = lang.Util_Equiv_O_O__Z(tmp30, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__10_2))

									if and__1927000168__auto____11_2 { var tmp31 *lang.Keyword = A_arbace_g2a_convert_A_const_114; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(tmp31.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__10_2))); if jrt.A2g_Truth(and__1927000168__auto____12) {
										var tmp32 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp29 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()).Invoke_O_O__O(Lit_46, tmp32.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__10_2))) } else {
//line :1343:1
											tmp29 = and__1927000168__auto____12 } } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11_2).Ref() }
//line :1341:1
									if jrt.A2g_Truth(tmp29) {



										var tmp33 *lang.Keyword = A_arbace_g2a_convert_A_const_359; target__11 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp33.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__10_2))) } else {
//line :1341:1
											target__11 = nil } } } else {
//line :1340:1
												target__11 = nil
											}




							var tmp34 any; var and__1927000168__auto____12_2 any = target__11
							if jrt.A2g_Truth(and__1927000168__auto____12_2) { tmp34 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_505.GetRawRoot__O()).Invoke_O_O__O(text__6, lang.IFn_Cast(A_arbace_g2a_convert_A_const_506.GetRawRoot__O()).Invoke_O__O(target__11)) } else { tmp34 = and__1927000168__auto____12_2 }
//line :1346:1
							if jrt.A2g_Truth(tmp34) {

								var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp36 any = A_arbace_g2a_convert_A_const_487; var tmp37 any = A_arbace_g2a_convert_A_const_145.GetRawRoot__O(); var tmp38 any = lang.Tuple_Create_O_O__IPersistentVector(k__9_2, A_arbace_g2a_convert_A_const_17); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()); var tmp40 any = A_arbace_g2a_convert_A_const_8.GetRawRoot__O(); var tmp41 *lang.PersistentVector; lang.PersistentVector_Init(); tmp41 = lang.PersistentVector_EMPTY; return tmp35.Invoke_O_O_O_O_O_O__O(acc__1, tmp36, tmp37, tmp38, tmp39.Invoke_O_O__O(tmp40, tmp41.Ref()), dv__7) } else {
//line :1346:1
									var tmp42 any; var and__1927000168__auto____12_3 any = t.F_last_import


									if jrt.A2g_Truth(and__1927000168__auto____12_3) { tmp42 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.Tuple_Create_O_O__IPersistentVector(l__4, c__5), t.F_last_import)))).Ref() } else { tmp42 = and__1927000168__auto____12_3 }
//line :1346:1
									if jrt.A2g_Truth(tmp42) {



										var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp44 any = A_arbace_g2a_convert_A_const_508; return tmp43.Invoke_O_O_O_O__O(acc__1, tmp44, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), dv__7) } else {
//line :1346:1
											if A_arbace_g2a_convert_A_const_156 != nil {





												var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp46 any = A_arbace_g2a_convert_A_const_498; var tmp47 any = A_arbace_g2a_convert_A_const_145.GetRawRoot__O(); var tmp48 any; var or__1927000174__auto____12 any = k__9_2; if jrt.A2g_Truth(or__1927000174__auto____12) { tmp48 = or__1927000174__auto____12 } else { tmp48 = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_decls)).Ref() }; var tmp49 any = tmp48; var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()); var tmp51 any = A_arbace_g2a_convert_A_const_8.GetRawRoot__O(); var tmp52 *lang.PersistentVector; lang.PersistentVector_Init(); tmp52 = lang.PersistentVector_EMPTY; return tmp45.Invoke_O_O_O_O_O_O__O(acc__1, tmp46, tmp47, tmp49, tmp50.Invoke_O_O__O(tmp51, tmp52.Ref()), dv__7) } else {
//line :1346:1
													return nil } } } } }
//line :1333:1
func A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1333:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1333:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A) Invoke_O_O_O__O(self, i__1, sp__2 any) any { if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_39.GetRawRoot__O()).Invoke_O__O(sp__2)), lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }




func A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1338:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1338:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A) Invoke_O_O_O__O(self, i__1, p__838000522__2 any) any { var vec__838000524__3 any = p__838000522__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__838000524__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__838000524__3, lang.RT_IntCast_J__I(1), nil); _ = ___5; if lang.Numbers_IsPos_J__Z(int64(lang.Util_Compare_O_O__I(a__4, lang.Tuple_Create_O_O__IPersistentVector(t.F_l, t.F_c)))) { return i__1 } else { return nil } }
















func A_arbace_g2a_convert_convert_file_attach_meta__838000529_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_attach_meta__838000529_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_attach_meta__838000529_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1355:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_A) Ctor_O_O(c__placed, c__plan any) { t.F_placed = c__placed; t.F_plan = c__plan }
//line :1355:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_A) Invoke_O_O_O__O(self, k__1, si__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_485.GetRawRoot__O()); var tmp2 any = t.F_plan; var tmp3 any = A_arbace_g2a_convert_A_const_487; var temp__1927000414__auto____3 any = tmp1.Invoke_O_O__O(tmp2, lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__1, si__2))); if
														jrt.A2g_Truth(temp__1927000414__auto____3) { var ds__4 any = temp__1927000414__auto____3; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()); var tmp5 any = t.F_placed; var tmp6 any = A_arbace_g2a_convert_A_const_125.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A_New(); var tmp9 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A_fn_class
															if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A_fn_class = fncls__90d; tmp9 = fncls__90d } else { tmp9 = fncls__90 }; tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ds__4))
															lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_488)
															var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_486.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A_New(); var tmp13 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A_fn_class = fncls__91d; tmp13 = fncls__91d } else { tmp13 = fncls__91 }; return tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), ds__4)) } else {
//line :1356:1
			return nil } }
func A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A_New() *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A{}; t.Ctor(); return t }
//line :1357:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A) Ctor() {}
//line :1357:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A) Invoke_O_O__O(self, p__838000530__1 any) any { var vec__838000532__2 any = p__838000530__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000532__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000532__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }

func A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A_New() *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A{}; t.Ctor(); return t }
//line :1359:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A) Ctor() {}
//line :1359:1
func (t *A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A) Invoke_O_O__O(self, p1__838000472_SHARP___1 any) any { return lang.RT_Nth_O_I__O(p1__838000472_SHARP___1, lang.RT_IntCast_J__I(2)) }
func A_arbace_g2a_convert_convert_file_fn__838000539_A_New() *A_arbace_g2a_convert_convert_file_fn__838000539_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000539_A{}; t.Ctor(); return t }
//line :1360:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000539_A) Ctor() {}
//line :1360:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000539_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_149.GetRawRoot__O()).Invoke_O__O(x__1); var tmp2 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_22.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp2 = A_arbace_g2a_convert_A_const_17 } else { tmp2 = A_arbace_g2a_convert_A_const_304 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_g2a_convert_convert_file_fn__838000541_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000541_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000541_A{}; t.Ctor_O(p0); return t }
//line :1362:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000541_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1362:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000541_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_496.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_497, dv__1))); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_495.GetRawRoot__O()).Invoke_O__O(dv__1) }


func A_arbace_g2a_convert_convert_file_fn__838000543_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_g2a_convert_convert_file_fn__838000543_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000543_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :1365:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_A) Ctor_O_O_O_O_O_O_O_O(c__f, c__doc, c__name, c__dump, c__imports, c__fe, c__header, c__pkg_line any) { t.F_f = c__f; t.F_doc = c__doc; t.F_name = c__name; t.F_dump = c__dump; t.F_imports = c__imports; t.F_fe = c__fe; t.F_header = c__header; t.F_pkg_line = c__pkg_line }
//line :1365:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_A) Invoke_O__O(self any) any { var tmp1 any; tmp58 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_A_const_179.GetRawRoot__O(); var tmp4 any = t.F_pkg_line; var tmp5 any = A_arbace_g2a_convert_A_const_489; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(t.F_name); var tmp8 any; var t_ any = t.F_name; t.F_name = nil; tmp8 = t_; var tmp9 any = tmp6.Invoke_O_O__O(tmp7, tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp11 lang.IPersistentVector; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_212.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_48.Invoke_O__O(t.F_f)); var tmp14 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp15 any; var t__2 any = t.F_dump

		t.F_dump = nil; tmp15 = t__2; if jrt.A2g_Truth(tmp12.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) { var tmp16 any = A_arbace_g2a_convert_A_const_491; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()); var tmp19 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp20 any; var t__3 any = t.F_f
			t.F_f = nil; tmp20 = t__3
//line :1368:1
			tmp11 = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O__O(tmp18.Invoke_O__O(tmp19.Invoke_O__O(tmp20)))) } else { tmp11 = nil }
//line :1366:1
		var tmp21 any = tmp11; var tmp22 lang.IPersistentVector; var b__3 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_27.GetRawRoot__O()); var tmp24 any = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A_New(); var tmp25 *jrt.Class
		var fncls__93 /*line :1366:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A_fn_class



		if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A_fn_class = fncls__93d; tmp25 = fncls__93d } else { tmp25 = fncls__93 }; b__3 = tmp23.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil), t.F_header)

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(b__3)) { var tmp26 any = A_arbace_g2a_convert_A_const_492; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp29 any = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A_New(); var tmp30 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A_fn_class = fncls__94d; tmp30 = fncls__94d } else { tmp30 = fncls__94 }; tmp22 = lang.Tuple_Create_O_O__IPersistentVector(tmp26, tmp27.Invoke_O__O(tmp28.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), b__3))) } else { tmp22 = nil }
//line :1366:1
		var tmp31 any = tmp22; var tmp32 lang.IPersistentVector; var o__3 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_384.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A_New(); var tmp35 *jrt.Class
		var fncls__95 /*line :1366:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A_fn_class






		if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A_fn_class = fncls__95d; tmp35 = fncls__95d } else { tmp35 = fncls__95 }; var tmp36 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var tmp37 any; var t__4 any = t.F_header; t.F_header = nil; tmp37 = t__4; o__3 = tmp33.Invoke_O_O__O(tmp36, tmp37)

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(o__3)) { var tmp38 any = A_arbace_g2a_convert_A_const_475; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp41 any = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A_New(); var tmp42 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A_fn_class = fncls__96d; tmp42 = fncls__96d } else { tmp42 = fncls__96 }; tmp32 = lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39.Invoke_O__O(tmp40.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil), o__3))) } else { tmp32 = nil }
//line :1366:1
		var tmp43 any = tmp32; var tmp44 lang.IPersistentVector; var temp__1927000414__auto____3 any; var tmp45 *lang.Keyword = A_arbace_g2a_convert_A_const_490; var tmp46 any; var t__5 any = t.F_fe









		t.F_fe = nil; tmp46 = t__5; temp__1927000414__auto____3 = tmp45.Invoke_O__O(tmp46); if jrt.A2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; var tmp47 any = A_arbace_g2a_convert_A_const_493; tmp44 = lang.Tuple_Create_O_O__IPersistentVector(tmp47, lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(v__4), v__4)) } else { tmp44 = nil }
//line :1366:1
		var tmp48 any = tmp44; var tmp49 lang.IPersistentVector










		if jrt.A2g_Truth(t.F_doc) { var tmp50 any = A_arbace_g2a_convert_A_const_217; var tmp51 any; var t__6 any = t.F_doc; t.F_doc = nil; tmp51 = t__6; tmp49 = lang.Tuple_Create_O_O__IPersistentVector(tmp50, tmp51) } else { tmp49 = nil }
//line :1366:1
		var tmp52 any = tmp49; var tmp53 any = A_arbace_g2a_convert_A_const_494; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_270.GetRawRoot__O()); var tmp55 any; var t__7 any = t.F_pkg_line











		t.F_pkg_line = nil; tmp55 = t__7
//line :1366:1
		var tmp56 any = tmp55; var tmp57 any; var t__8 any = t.F_imports











		t.F_imports = nil; tmp57 = t__8
//line :1366:1
		tmp1 = tmp2.Invoke_O_O_O_O_O_O__O(tmp3, nil, tmp4, tmp5, tmp9, tmp10.Invoke_O_O_O_O_O_O__O(tmp21, tmp31, tmp43, tmp48, tmp52, lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54.Invoke_O_O__O(tmp56, tmp57)))) }
//line :1365:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp58 != nil { panic(tmp58) }; return tmp1 }




func A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A_New() *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A{}; t.Ctor(); return t }
//line :1370:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A) Ctor() {}
//line :1370:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A) Invoke_O_O__O(self, p1__838000473_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__838000473_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_53); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
																return lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__838000473_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_54) } }
func A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A_New() *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A{}; t.Ctor(); return t }
//line :1372:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A) Ctor() {}
//line :1372:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A) Invoke_O_O__O(self, p1__838000474_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(p1__838000474_SHARP___1, lang.RT_IntCast_J__I(2))), lang.RT_Nth_O_I__O(p1__838000474_SHARP___1, lang.RT_IntCast_J__I(2))) }
func A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A_New() *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A{}; t.Ctor(); return t }
//line :1373:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A) Ctor() {}
//line :1373:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A) Invoke_O_O__O(self, p1__838000475_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__838000475_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_53); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
																return lang.IFn_Cast(A_arbace_g2a_convert_A_const_457.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O(p1__838000475_SHARP___1, lang.RT_IntCast_J__I(2)), Lit_54) } }
func A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A_New() *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A{}; t.Ctor(); return t }
//line :1375:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A) Ctor() {}
//line :1375:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A) Invoke_O_O__O(self, p1__838000476_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_183.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_188.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(p1__838000476_SHARP___1, lang.RT_IntCast_J__I(2))), lang.RT_Nth_O_I__O(p1__838000476_SHARP___1, lang.RT_IntCast_J__I(2))) }



func A_arbace_g2a_convert_convert_file_fn__838000554_A_New() *A_arbace_g2a_convert_convert_file_fn__838000554_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000554_A{}; t.Ctor(); return t }
//line :1379:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000554_A) Ctor() {}
//line :1379:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000554_A) Invoke_O_O__O(self, p__838000553__1 any) any { var vec__838000555__2 any = p__838000553__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000555__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000555__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4) }
func A_arbace_g2a_convert_convert_file_fn__838000559_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_convert_convert_file_fn__838000559_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000559_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1380:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_A) Ctor_O_O_O_O(c__attach_meta, c__placed, c__plan, c__decls any) { t.F_attach_meta = c__attach_meta; t.F_placed = c__placed; t.F_plan = c__plan; t.F_decls = c__decls }
//line :1380:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_400.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A_New_O_O_O(t.F_attach_meta, t.F_placed, t.F_plan); var tmp6 *jrt.Class
		var fncls__101 /*line :1384:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A_fn_class


		if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A_fn_class = fncls__101d; tmp6 = fncls__101d } else { tmp6 = fncls__101 }
//line :1384:1
		var tmp7 any = tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_g2a_convert_A_const_501.GetRawRoot__O()).Invoke__O(), t.F_decls); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A_New_O(t.F_placed); var tmp10 *jrt.Class
		var fncls__102 /*line :1384:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A_fn_class













		if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A_fn_class = fncls__102d; tmp10 = fncls__102d } else { tmp10 = fncls__102 }
//line :1384:1
		var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_485.GetRawRoot__O()); var tmp13 any; var t_ any = t.F_plan














		t.F_plan = nil; tmp13 = t_
//line :1384:1
		var tmp14 any = tmp13; var tmp15 any = A_arbace_g2a_convert_A_const_498; var tmp16 any; var t__2 any = t.F_decls














		t.F_decls = nil; tmp16 = t__2
//line :1384:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp14, lang.Tuple_Create_O_O__IPersistentVector(tmp15, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp16)).Ref()))))) }
//line :1380:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp17 != nil { panic(tmp17) }; return tmp1 }






func A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1387:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A) Ctor_O_O_O(c__attach_meta, c__placed, c__plan any) { t.F_attach_meta = c__attach_meta; t.F_placed = c__placed; t.F_plan = c__plan }
//line :1387:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A) Invoke_O_O_O__O(self, k__1, d__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A_New_O(t.F_placed); var tmp4 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A_fn_class
	if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A_fn_class = fncls__99d; tmp4 = fncls__99d } else { tmp4 = fncls__99 }
//line :1388:1
	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_485.GetRawRoot__O()); var tmp6 any = t.F_plan; var tmp7 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_convert_A_const_498, k__1))); var tmp8 any; var G__838000563__3_ any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__2)


L1: switch { default: switch lang.Util_Hash_O__I(G__838000563__3_) >> 0 & 1 { case 0: if any(G__838000563__3_) == any(A_arbace_g2a_convert_A_const_89) {

	var tmp9 *lang.Keyword = A_arbace_g2a_convert_A_const_358; if lang.Util_Equiv_O_O__Z(Lit_46, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__2))) { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_499.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A_New_O_O(k__1, t.F_attach_meta); var tmp12 *jrt.Class
		var fncls__100 /*line :1393:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A_fn_class

		if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A_fn_class = fncls__100d; tmp12 = fncls__100d } else { tmp12 = fncls__100 }
//line :1393:1
		tmp8 = lang.Tuple_Create_O__IPersistentVector(tmp10.Invoke_O_O__O(d__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }
//line :1391:1
	break L1 }; case 1: if any(G__838000563__3_) == any(A_arbace_g2a_convert_A_const_122) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_500.GetRawRoot__O()).Invoke_O_O__O(d__2, lang.IFn_Cast(t.F_attach_meta).Invoke_O_O__O(k__1, A_arbace_g2a_convert_A_const_17))); break L1 }; default:
}



	tmp8 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_59, d__2)}
//line :1388:1
	return tmp1.Invoke_O_O__O(tmp7, tmp8) }
func A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A{}; t.Ctor_O(p0); return t }
//line :1389:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1389:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_496.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_497, dv__1))); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_495.GetRawRoot__O()).Invoke_O__O(dv__1) }





func A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1395:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A) Ctor_O_O(c__k, c__attach_meta any) { t.F_k = c__k; t.F_attach_meta = c__attach_meta }
//line :1395:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A) Invoke_O_O__O(self, si__1 any) any { return lang.IFn_Cast(t.F_attach_meta).Invoke_O_O__O(t.F_k, si__1) }


func A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A{}; t.Ctor_O(p0); return t }
//line :1398:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1398:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A) Invoke_O_O__O(self, dv__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_12.GetRawRoot__O()); var tmp2 any = t.F_placed; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_convert_A_const_8.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_496.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_497, dv__1))); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_495.GetRawRoot__O()).Invoke_O__O(dv__1) }

func A_arbace_g2a_convert_convert_file_fn__838000571_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000571_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000571_A{}; t.Ctor_O(p0); return t }
//line :1400:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000571_A) Ctor_O(c__placed any) { t.F_placed = c__placed }
//line :1400:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000571_A) Invoke_O_O__O(self, p__838000570__1 any) any { var vec__838000572__2 any = p__838000570__1; var l__3 any = lang.RT_Nth_O_I_O__O(vec__838000572__2, lang.RT_IntCast_J__I(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O(vec__838000572__2, lang.RT_IntCast_J__I(1), nil); return lang.IFn_Cast(lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_placed)).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(l__3, c__4)) }

func A_arbace_g2a_convert_convert_file_fn__838000576_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_fn__838000576_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000576_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1402:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_A) Ctor_O_O(c__kept, c__dirs any) { t.F_kept = c__kept; t.F_dirs = c__dirs }
//line :1402:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_A) Invoke_O_O_O__O(self, m__1, g__2 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_kept)).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_71.Invoke_O__O(g__2))))) { return m__1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A_New_O(t.F_dirs); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), m__1, A_arbace_g2a_convert_A_const_71.Invoke_O__O(g__2)) } }
//line :1405:1
func A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A{}; t.Ctor_O(p0); return t }
//line :1405:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :1405:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A) Invoke_O_O_O__O(self, m__1, p__838000577__2 any) any { var vec__838000579__3 any = p__838000577__2; var p__4 any = lang.RT_Nth_O_I_O__O(vec__838000579__3, lang.RT_IntCast_J__I(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__838000579__3, lang.RT_IntCast_J__I(1), nil); var vec__838000582__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_37.GetRawRoot__O()).Invoke_O__O(p__4); var l__7 any = lang.RT_Nth_O_I_O__O(vec__838000582__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__838000582__6, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_383.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A_New_O_O(l__7, c__8); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A_fn_class; if

	fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; if jrt.A2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_dirs)) { return m__1 } else { var lines__9 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_511.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_512.GetRawRoot__O()).Invoke_O_O_O__O(text__5, Lit_62, Lit_7)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_385.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A_New_O(l__7); var tmp6 *jrt.Class
		var fncls__119 /*line :1407:1*/*jrt.Class = A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A_fn_class


		if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A_fn_class = fncls__119d; tmp6 = fncls__119d } else { tmp6 = fncls__119 }; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), m__1, lang.IFn_Cast(A_arbace_g2a_convert_A_const_209.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_513.GetRawRoot__O(), lines__9)) } }
//line :1407:1
func A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1407:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :1407:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A) Invoke_O_O__O(self, p__838000585__1 any) any { var vec__838000587__2 any = p__838000585__1; var dl__3 any = lang.RT_Nth_O_I_O__O(vec__838000587__2, lang.RT_IntCast_J__I(0), nil); var dc__4 any = lang.RT_Nth_O_I_O__O(vec__838000587__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(dl__3, t.F_l); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(dc__4, t.F_c)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }


func A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A_New_O(p0 any) *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A{}; t.Ctor_O(p0); return t }
//line :1410:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :1410:1
func (t *A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A) Invoke_O_O_O__O(self, m__1, p__838000591__2 any) any { var vec__838000593__3 any = p__838000591__2; var i__4 any = lang.RT_Nth_O_I_O__O(vec__838000593__3, lang.RT_IntCast_J__I(0), nil); var t__5 any = lang.RT_Nth_O_I_O__O(vec__838000593__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_145.GetRawRoot__O()); var tmp2 any = lang.Numbers_Add_O_O__Number(t.F_l, i__4); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_14.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_A_const_8.GetRawRoot__O(); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O_O_O__O(m__1, tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), t__5) }















func A_arbace_g2a_convert_init_order_A_New() *A_arbace_g2a_convert_init_order_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_A{}; t.Ctor(); return t }
//line :1426:1
func (t *A_arbace_g2a_convert_init_order_A) Ctor() {}
//line :1426:1
func (t *A_arbace_g2a_convert_init_order_A) Invoke_O_O__O(self, dump__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_g2a_convert_init_order_iter__838000600__838000604_A_New(); var tmp4 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_g2a_convert_init_order_iter__838000600__838000604_A_fn_class
	if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_g2a_convert_init_order_iter__838000600__838000604_A_fn_class = fncls__126d; tmp4 = fncls__126d } else { tmp4 = fncls__126 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_g2a_convert_A_const_520.Invoke_O__O(dump__0))
//line :1427:1
	return tmp1.Invoke_O__O(tmp2) }
func A_arbace_g2a_convert_init_order_iter__838000600__838000604_A_New() *A_arbace_g2a_convert_init_order_iter__838000600__838000604_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_iter__838000600__838000604_A{}; t.Ctor(); return t }
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_A) Ctor() {}
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_A) Invoke_O_O__O(self, s__838000601__1 any) any { var tmp1 any = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A_New_O_O(self, s__838000601__1); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1428:1
func A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A) Ctor_O_O(c__iter__838000600, c__s__838000601 any) { t.F_iter__838000600 = c__iter__838000600; t.F_s__838000601 = c__s__838000601 }
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A) Invoke_O__O(self any) any { { var s__838000601__1 any; var t_ any = t.F_s__838000601; t.F_s__838000601 = nil; s__838000601__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000601__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000601__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000601__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000601__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000603__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__838000603__6); var tmp2 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_146, false); A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A_fn_class = fncls__123d; tmp2 = fncls__123d } else { tmp2 = fncls__123 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000600); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000603__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000601__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000603__6), nil) } } else { var map__838000619__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000601__3); var map__838000619__5 any; if lang.ISeq_InstanceOf(map__838000619__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000619__4)) { map__838000619__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000619__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000619__4)) { map__838000619__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000619__4) } else { lang.PersistentArrayMap_Init(); map__838000619__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000619__5 = map__838000619__4 }; var lhs__6 any = lang.RT_Get_O_O__O(map__838000619__5, A_arbace_g2a_convert_A_const_78); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()); var tmp5 any; var one__7 any; var tmp6 any = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A_New(); var tmp7 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A_fn_class
														if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A_fn_class = fncls__124d; tmp7 = fncls__124d } else { tmp7 = fncls__124 }; one__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)




	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__6))) {
		tmp5 = lang.IFn_Cast(one__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__6)) } else {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp10 any = A_arbace_g2a_convert_A_const_519; tmp5 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(one__7, lhs__6)) }
//line :1428:1
	var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__838000600); return tmp4.Invoke_O_O__O(tmp5, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000601__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1428:1
func A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__838000603 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__838000603 = c__b__838000603 }
//line :1428:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A) Invoke_O__O(self any) any { { var i__838000602__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000602__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__838000607__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000602__1)); var map__838000607__3 any; if lang.ISeq_InstanceOf(map__838000607__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000607__2)) { map__838000607__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000607__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000607__2)) { map__838000607__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000607__2) } else { lang.PersistentArrayMap_Init(); map__838000607__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000607__3 = map__838000607__2 }; var lhs__4 any = lang.RT_Get_O_O__O(map__838000607__3, A_arbace_g2a_convert_A_const_78); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000603; var tmp4 any; var one__5 any; var tmp5 any = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A_New(); var tmp6 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A_fn_class
																if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A_fn_class = fncls__122d; tmp6 = fncls__122d } else { tmp6 = fncls__122 }; one__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)




	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(lhs__4))) {
		tmp4 = lang.IFn_Cast(one__5).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(lhs__4)) } else {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp9 any = A_arbace_g2a_convert_A_const_519; tmp4 = tmp7.Invoke_O_O_O__O(tmp8, tmp9, lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(one__5, lhs__4)) }
//line :1428:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__838000602__1 = lang.Numbers_Unchecked_inc_J__J(i__838000602__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A_New() *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A{}; t.Ctor(); return t }
//line :1429:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A) Ctor() {}
//line :1429:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A) Invoke_O_O__O(self, p__838000609__1 any) any { var vec__838000611__2 any = p__838000609__1; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__838000611__2, lang.RT_IntCast_J__I(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O(vec__838000611__2, lang.RT_IntCast_J__I(1), nil); if
																				lang.Util_Equiv_O_O__Z(nm__3, Lit_22) { var vec__838000614__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_518, p__4); var ___6 any = lang.RT_Nth_O_I_O__O(vec__838000614__5, lang.RT_IntCast_J__I(0), nil); var file__7 any = lang.RT_Nth_O_I_O__O(vec__838000614__5, lang.RT_IntCast_J__I(1), nil); var l__8 any = lang.RT_Nth_O_I_O__O(vec__838000614__5, lang.RT_IntCast_J__I(2), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__838000614__5, lang.RT_IntCast_J__I(3), nil); _ = ___6; return lang.Tuple_Create_O_O_O__IPersistentVector(file__7, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(l__8))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(c__9))).Ref()) } else {


		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(nm__3) } }
//line :1429:1
func A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A_New() *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A{}; t.Ctor(); return t }
//line :1429:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A) Ctor() {}
//line :1429:1
func (t *A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A) Invoke_O_O__O(self, p__838000621__1 any) any { var vec__838000623__2 any = p__838000621__1; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__838000623__2, lang.RT_IntCast_J__I(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O(vec__838000623__2, lang.RT_IntCast_J__I(1), nil); if
																			lang.Util_Equiv_O_O__Z(nm__3, Lit_22) { var vec__838000626__5 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_29.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_518, p__4); var ___6 any = lang.RT_Nth_O_I_O__O(vec__838000626__5, lang.RT_IntCast_J__I(0), nil); var file__7 any = lang.RT_Nth_O_I_O__O(vec__838000626__5, lang.RT_IntCast_J__I(1), nil); var l__8 any = lang.RT_Nth_O_I_O__O(vec__838000626__5, lang.RT_IntCast_J__I(2), nil); var c__9 any = lang.RT_Nth_O_I_O__O(vec__838000626__5, lang.RT_IntCast_J__I(3), nil); _ = ___6; return lang.Tuple_Create_O_O_O__IPersistentVector(file__7, jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(l__8))).Ref(), jrt.Long_ValueOf_J__Long(jrt.Long_ParseLong_String__J(jrt.String_Cast(c__9))).Ref()) } else {


		return lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()).Invoke_O__O(nm__3) } }




func A_arbace_g2a_convert_munge_name_A_New() *A_arbace_g2a_convert_munge_name_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_munge_name_A{}; t.Ctor(); return t }
//line :1438:1
func (t *A_arbace_g2a_convert_munge_name_A) Ctor() {}
//line :1438:1
func (t *A_arbace_g2a_convert_munge_name_A) Invoke_O_O__O(self, s__0 any) any { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_512.GetRawRoot__O()).Invoke_O_O_O__O(s__0, A_arbace_g2a_convert_A_const_521, Lit_22) }

func A_arbace_g2a_convert_package_form_A_New() *A_arbace_g2a_convert_package_form_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_package_form_A{}; t.Ctor(); return t }
//line :1440:1
func (t *A_arbace_g2a_convert_package_form_A) Ctor() {}
//line :1440:1
func (t *A_arbace_g2a_convert_package_form_A) Invoke_O_O_O__O(self, dump__0, p__838000635__1 any) any { var map__838000636__3 any = p__838000635__1; var map__838000636__4 any; if lang.ISeq_InstanceOf(map__838000636__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_135.GetRawRoot__O()).Invoke_O__O(map__838000636__3)) { map__838000636__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_convert_A_const_194.GetRawRoot__O()).Invoke_O__O(map__838000636__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(map__838000636__3)) { map__838000636__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(map__838000636__3) } else { lang.PersistentArrayMap_Init(); map__838000636__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__838000636__4 = map__838000636__3 }; var positions__5 any = lang.RT_Get_O_O__O(map__838000636__4, A_arbace_g2a_convert_A_const_522); var c__6 any = A_arbace_g2a_convert_A_const_523.Invoke_O__O(dump__0); var files__7 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_524.Invoke_O__O(dump__0)); var others__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_525.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_216.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_convert_package_form_fn__838000638_A_New_O(dump__0); var tmp5 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_g2a_convert_package_form_fn__838000638_A_fn_class; if


	fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_g2a_convert_package_form_fn__838000638_A_fn_class = fncls__127d; tmp5 = fncls__127d } else { tmp5 = fncls__127 }; others__8 = tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_g2a_convert_A_const_526))); var embeds__9 any = /*line :1440:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_527.Invoke_O__O(dump__0), A_arbace_g2a_convert_A_const_528.Invoke_O__O(dump__0))); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_138.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_141.GetRawRoot__O(); var tmp8 any = A_arbace_g2a_convert_A_const_529; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_182.GetRawRoot__O()); var tmp10 any; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_48.Invoke_O__O(dump__0))) {
		tmp10 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_530.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_484.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_463.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_491.Invoke_O__O(dump__0), A_arbace_g2a_convert_A_const_531))) } else {
			tmp10 = A_arbace_g2a_convert_A_const_48.Invoke_O__O(dump__0) }; var tmp11 any = /*line :1446:1*/tmp9.Invoke_O__O(tmp10); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_convert_A_const_50; var tmp14 any = A_arbace_g2a_convert_A_const_491.Invoke_O__O(dump__0); var tmp15 any = A_arbace_g2a_convert_A_const_523; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_532.GetRawRoot__O()); var tmp17 any = A_arbace_g2a_convert_A_const_534; var tmp18 any = A_arbace_g2a_convert_A_const_534.Invoke_O__O(c__6); var tmp19 any = A_arbace_g2a_convert_A_const_535; var tmp20 any = A_arbace_g2a_convert_A_const_535.Invoke_O__O(c__6); var tmp21 *lang.Keyword; if





	lang.Util_Equiv_O_O__Z(Lit_156, A_arbace_g2a_convert_A_const_535.Invoke_O__O(c__6)) { tmp21 = A_arbace_g2a_convert_A_const_536 } else { tmp21 = A_arbace_g2a_convert_A_const_537 }; var tmp22 any = /*line :1446:1*/tmp21.Ref(); var tmp23 any; var or__1927000174__auto____10 any = A_arbace_g2a_convert_A_const_536.Invoke_O__O(c__6); if






	jrt.A2g_Truth(or__1927000174__auto____10) { tmp23 = or__1927000174__auto____10 } else { tmp23 = A_arbace_g2a_convert_A_const_537.Invoke_O__O(c__6) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_g2a_convert_A_const_538; var tmp26 any = /*line :1446:1*/A_arbace_g2a_convert_A_const_538.Invoke_O__O(c__6); var tmp27 any = A_arbace_g2a_convert_A_const_493; var tmp28 any = A_arbace_g2a_convert_A_const_490.Invoke_O__O(c__6); var tmp29 any = A_arbace_g2a_convert_A_const_539; var tmp30 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_539.Invoke_O__O(c__6)); var tmp31 any = A_arbace_g2a_convert_A_const_540; var tmp32 any = A_arbace_g2a_convert_A_const_540.Invoke_O__O(c__6); var tmp33 any = A_arbace_g2a_convert_A_const_541; var tmp34 any = A_arbace_g2a_convert_A_const_541.Invoke_O__O(c__6); var tmp35 any = A_arbace_g2a_convert_A_const_542; var tmp36 any = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp13, tmp14, tmp15, tmp16.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp17, tmp18, tmp19, tmp20, tmp22, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, A_arbace_g2a_convert_A_const_542.Invoke_O__O(c__6)), A_arbace_g2a_convert_A_const_533, files__7); var tmp37 lang.IPersistentVector; if










	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(others__8)) { tmp37 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_convert_A_const_543, others__8) } else { tmp37 = nil }; var tmp38 any = tmp37; var tmp39 lang.IPersistentVector; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(embeds__9)) { var tmp40 any = A_arbace_g2a_convert_A_const_527; tmp39 = lang.Tuple_Create_O_O__IPersistentVector(tmp40, lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_convert_A_const_150.GetRawRoot__O(), embeds__9))) } else { tmp39 = nil }; var tmp41 any = tmp39; var tmp42 lang.IPersistentVector; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_544.Invoke_O__O(dump__0))) { var tmp43 any = A_arbace_g2a_convert_A_const_545; tmp42 = lang.Tuple_Create_O_O__IPersistentVector(tmp43, lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_544.Invoke_O__O(dump__0))) } else { tmp42 = nil }; var tmp44 any = A_arbace_g2a_convert_A_const_520; return /*line :1446:1*/ tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp11, tmp12.Invoke_O_O_O_O_O__O(tmp36, tmp38, tmp41, tmp42, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp44, lang.IFn_Cast(A_arbace_g2a_convert_A_const_546.GetRawRoot__O()).Invoke_O__O(dump__0), A_arbace_g2a_convert_A_const_522, positions__5))) }
//line :1443:1
func A_arbace_g2a_convert_package_form_fn__838000638_A_New_O(p0 any) *A_arbace_g2a_convert_package_form_fn__838000638_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_package_form_fn__838000638_A{}; t.Ctor_O(p0); return t }
//line :1443:1
func (t *A_arbace_g2a_convert_package_form_fn__838000638_A) Ctor_O(c__dump any) { t.F_dump = c__dump }
//line :1443:1
func (t *A_arbace_g2a_convert_package_form_fn__838000638_A) Invoke_O_O__O(self, p1__838000634_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_dump, p1__838000634_SHARP___1) }



















func A_arbace_g2a_convert_file_stem_A_New() *A_arbace_g2a_convert_file_stem_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_file_stem_A{}; t.Ctor(); return t }
//line :1463:1
func (t *A_arbace_g2a_convert_file_stem_A) Ctor() {}
//line :1463:1
func (t *A_arbace_g2a_convert_file_stem_A) Invoke_O_O_O__O(self, name__0, src_dir__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_36.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_convert_A_const_17; var stem__3 any = tmp1.Invoke_O_O_O__O(name__0, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(name__0)), 3)).Ref()); var tmp3 any; var and__1927000168__auto____4 any = src_dir__1; if





	jrt.A2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, src_dir__1, nil, stem__3))).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp3) {
		lang.IFn_Cast(A_arbace_g2a_convert_A_const_185.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_547)
//line :1469:1
		return name__0 } else { return stem__3 } }



func A_arbace_g2a_convert_convert_package_A_New() *A_arbace_g2a_convert_convert_package_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_A{}; t.Ctor(); return t }
//line :1473:1
func (t *A_arbace_g2a_convert_convert_package_A) Ctor() {}
//line :1473:1
func (t *A_arbace_g2a_convert_convert_package_A) Invoke_O_O_O__O(self, dump__0, opts__1 any) any { var stats__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_483.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;




	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; stats__3 = tmp1.Invoke_O__O(tmp2.Ref()); var ns_sym__4 any; var or__1927000174__auto____4 any = /*line :1473:1*/A_arbace_g2a_convert_A_const_548.Invoke_O__O(opts__1); if





	jrt.A2g_Truth(or__1927000174__auto____4) { ns_sym__4 = or__1927000174__auto____4 } else { ns_sym__4 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_549.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_491.Invoke_O__O(dump__0)) }; var underlying__5 any; var tmp3 lang.IFn = /*line :1473:1*/lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap;






	lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 any; var iter__1927001039__auto____5 any; var tmp7 any = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A_New(); var tmp8 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A_fn_class = fncls__130d; tmp8 = fncls__130d } else { tmp8 = fncls__130 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_g2a_convert_A_const_553.Invoke_O__O(dump__0)); underlying__5 = tmp3.Invoke_O_O__O(tmp5, tmp6); var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp10 any = A_arbace_g2a_convert_A_const_554; var tmp11 any = A_arbace_g2a_convert_A_const_11; var tmp12 any = A_arbace_g2a_convert_A_const_555; var tmp13 any = A_arbace_g2a_convert_A_const_556.Invoke_O__O(dump__0); var tmp14 any = A_arbace_g2a_convert_A_const_557; lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp10, dump__0, tmp11, stats__3, tmp12, tmp13, tmp14, A_arbace_g2a_convert_A_const_491.Invoke_O__O(dump__0), A_arbace_g2a_convert_A_const_558, underlying__5)); var tmp15 any; tmp25 := /*line :1473:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var files__8 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_150.GetRawRoot__O()); var tmp17 any; var iter__1927001039__auto____8 any; var tmp18 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A_New_O_O_O(ns_sym__4, dump__0, opts__1); var tmp19 *jrt.Class
		var fncls__145 /*line :1473:1*/*jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A_fn_class












		if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A_fn_class = fncls__145d; tmp19 = fncls__145d } else { tmp19 = fncls__145 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); tmp17 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(A_arbace_g2a_convert_A_const_533.Invoke_O__O(dump__0)); files__8 = tmp16.Invoke_O__O(tmp17)
//line :1473:1
		var tmp20 any = A_arbace_g2a_convert_A_const_548; var tmp21 any = A_arbace_g2a_convert_A_const_491; var tmp22 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_550.GetRawRoot__O()).Invoke_O_O__O(dump__0, opts__1); var tmp23 any = A_arbace_g2a_convert_A_const_533; var tmp24 any = A_arbace_g2a_convert_A_const_551; tmp15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, ns_sym__4, tmp21, tmp22, tmp23, files__8, tmp24, lang.IFn_Cast(A_arbace_g2a_convert_A_const_7.GetRawRoot__O()).Invoke_O__O(stats__3))) }; return nil }();







	lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if /*line :1473:1*/ tmp25 != nil { panic(tmp25) }; return tmp15 }






func A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A_New() *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A{}; t.Ctor(); return t }
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A) Ctor() {}
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A) Invoke_O_O__O(self, s__838000643__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A_New_O_O(self, s__838000643__1); var tmp2 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A_fn_class = fncls__129d; tmp2 = fncls__129d } else { tmp2 = fncls__129 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1480:1
func A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A) Ctor_O_O(c__iter__838000642, c__s__838000643 any) { t.F_iter__838000642 = c__iter__838000642; t.F_s__838000643 = c__s__838000643 }
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A) Invoke_O__O(self any) any { { var s__838000643__1 any; var t_ any = t.F_s__838000643; t.F_s__838000643 = nil; s__838000643__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000643__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000643__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000643__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000643__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000645__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A_New_I_O_O(size__1927001038__auto____5, b__838000645__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A_fn_class = fncls__128d; tmp2 = fncls__128d } else { tmp2 = fncls__128 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000642); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000645__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000643__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000645__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000643__3); if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_552.Invoke_O__O(t__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__838000642); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_convert_A_const_283.Invoke_O__O(t__4), A_arbace_g2a_convert_A_const_552.Invoke_O__O(t__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000643__3))) } else { s__838000643__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000643__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :1480:1
func A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__838000645, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__838000645 = c__b__838000645; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1480:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A) Invoke_O__O(self any) any { { var i__838000644__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000644__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000644__1)); if jrt.A2g_Truth(A_arbace_g2a_convert_A_const_552.Invoke_O__O(t__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000645; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_g2a_convert_A_const_283.Invoke_O__O(t__2), A_arbace_g2a_convert_A_const_552.Invoke_O__O(t__2))); i__838000644__1 = lang.Numbers_Unchecked_inc_J__J(i__838000644__1); continue L1 } else { i__838000644__1 = lang.Numbers_Unchecked_inc_J__J(i__838000644__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A) Ctor_O_O_O(c__ns_sym, c__dump, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_opts = c__opts }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A) Invoke_O_O__O(self, s__838000653__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A_New_O_O_O_O_O(self, t.F_ns_sym, s__838000653__1, t.F_dump, t.F_opts); var tmp2 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A_fn_class = fncls__144d; tmp2 = fncls__144d } else { tmp2 = fncls__144 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1486:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A) Ctor_O_O_O_O_O(c__iter__838000652, c__ns_sym, c__s__838000653, c__dump, c__opts any) { t.F_iter__838000652 = c__iter__838000652; t.F_ns_sym = c__ns_sym; t.F_s__838000653 = c__s__838000653; t.F_dump = c__dump; t.F_opts = c__opts }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A) Invoke_O__O(self any) any { { var s__838000653__1 any; var t_ any = t.F_s__838000653; t.F_s__838000653 = nil; s__838000653__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000653__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000653__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000653__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000653__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000655__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A_New_O_O_O_I_O_O(t.F_ns_sym, t.F_dump, b__838000655__6, size__1927001038__auto____5, t.F_opts, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A_fn_class = fncls__137d; tmp2 = fncls__137d } else { tmp2 = fncls__137 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000652); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000655__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000653__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000655__6), nil) } } else { var fe__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000653__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()); var tmp5 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_convert_A_const_563; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp10 *lang.PersistentArrayMap
															lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; var tmp11 any = tmp10.Ref(); var tmp12 any; var iter__1927001039__auto____5 any; var tmp13 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A_New(); var tmp14 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A_fn_class
															if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A_fn_class = fncls__143d; tmp14 = fncls__143d } else { tmp14 = fncls__143 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp15 *lang.Keyword = A_arbace_g2a_convert_A_const_481; tmp12 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_479.Invoke_O__O(fe__4))))
//line :1487:1
	tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp11, tmp12))); var tmp16 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A_New_O_O_O_O(t.F_ns_sym, t.F_dump, fe__4, t.F_opts); var tmp17 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A_fn_class = fncls__138d; tmp17 = fncls__138d } else { tmp17 = fncls__138 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
//line :1486:1
	var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__838000652); return tmp4.Invoke_O_O__O(tmp5, tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000653__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :1486:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A) Ctor_O_O_O_I_O_O(c__ns_sym, c__dump, c__b__838000655 any, c__size__1927001038__auto__ int32, c__opts, c__c__1927001037__auto__ any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_b__838000655 = c__b__838000655; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_opts = c__opts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1486:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A) Invoke_O__O(self any) any { { var i__838000654__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000654__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fe__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000654__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_b__838000655; var tmp4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_277.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_278.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_convert_A_const_563; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_125.GetRawRoot__O()); var tmp9 *lang.PersistentArrayMap
																	lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; var tmp10 any = tmp9.Ref(); var tmp11 any; var iter__1927001039__auto____3 any; var tmp12 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A_New(); var tmp13 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A_fn_class
																	if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A_fn_class = fncls__136d; tmp13 = fncls__136d } else { tmp13 = fncls__136 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 *lang.Keyword = A_arbace_g2a_convert_A_const_481; tmp11 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_convert_A_const_479.Invoke_O__O(fe__2))))
//line :1487:1
	tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp10, tmp11))); var tmp15 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A_New_O_O_O_O(t.F_ns_sym, t.F_dump, fe__2, t.F_opts); var tmp16 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A_fn_class = fncls__131d; tmp16 = fncls__131d } else { tmp16 = fncls__131 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :1486:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__838000654__1 = lang.Numbers_Unchecked_inc_J__J(i__838000654__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1487:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A) Ctor_O_O_O_O(c__ns_sym, c__dump, c__fe, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_fe = c__fe; t.F_opts = c__opts }
//line :1487:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_559.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_dump; t.F_dump = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = t.F_fe; var tmp7 any; var t__2 any = t.F_ns_sym; t.F_ns_sym = nil; tmp7 = t__2; var tmp8 any = tmp3.Invoke_O_O_O__O(tmp5, tmp6, tmp7); var tmp9 any = A_arbace_g2a_convert_A_const_560; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_561.GetRawRoot__O()); var tmp11 *lang.Keyword = A_arbace_g2a_convert_A_const_480; var tmp12 any; var t__3 any = t.F_fe
		t.F_fe = nil; tmp12 = t__3
//line :1494:1
		var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 *lang.Keyword = A_arbace_g2a_convert_A_const_562; var tmp15 any; var t__4 any = t.F_opts
		t.F_opts = nil; tmp15 = t__4
//line :1494:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :1487:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }
//line :1487:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1487:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A) Ctor_O_O_O_O(c__ns_sym, c__dump, c__fe, c__opts any) { t.F_ns_sym = c__ns_sym; t.F_dump = c__dump; t.F_fe = c__fe; t.F_opts = c__opts }
//line :1487:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_140.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_559.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_dump; t.F_dump = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = t.F_fe; var tmp7 any; var t__2 any = t.F_ns_sym; t.F_ns_sym = nil; tmp7 = t__2; var tmp8 any = tmp3.Invoke_O_O_O__O(tmp5, tmp6, tmp7); var tmp9 any = A_arbace_g2a_convert_A_const_560; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_561.GetRawRoot__O()); var tmp11 *lang.Keyword = A_arbace_g2a_convert_A_const_480; var tmp12 any; var t__3 any = t.F_fe
		t.F_fe = nil; tmp12 = t__3
//line :1494:1
		var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 *lang.Keyword = A_arbace_g2a_convert_A_const_562; var tmp15 any; var t__4 any = t.F_opts
		t.F_opts = nil; tmp15 = t__4
//line :1494:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :1487:1
	return nil }(); lang.IFn_Cast(A_arbace_g2a_convert_A_const_276.GetRawRoot__O()).Invoke__O(); if tmp16 != nil { panic(tmp16) }; return tmp1 }
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A_New() *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A{}; t.Ctor(); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A) Ctor() {}
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A) Invoke_O_O__O(self, s__838000660__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A_New_O_O(s__838000660__1, self); var tmp2 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A_fn_class = fncls__135d; tmp2 = fncls__135d } else { tmp2 = fncls__135 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A) Ctor_O_O(c__s__838000660, c__iter__838000659 any) { t.F_s__838000660 = c__s__838000660; t.F_iter__838000659 = c__iter__838000659 }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A) Invoke_O__O(self any) any { { var s__838000660__1 any; var t_ any = t.F_s__838000660; t.F_s__838000660 = nil; s__838000660__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000660__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__4))
																						if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp1 = lang.Util_Equiv_O_O__Z(Lit_46, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1488:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A_New(); var tmp5 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A_fn_class = fncls__134d; tmp5 = fncls__134d } else { tmp5 = fncls__134 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_359; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__838000659); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000660__1))) } else { s__838000660__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000660__1); continue L1 } } else { s__838000660__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000660__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A_New() *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A{}; t.Ctor(); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A) Ctor() {}
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A) Invoke_O_O__O(self, s__838000662__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A_New_O_O(self, s__838000662__1); var tmp2 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A_fn_class = fncls__133d; tmp2 = fncls__133d } else { tmp2 = fncls__133 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A) Ctor_O_O(c__iter__838000661, c__s__838000662 any) { t.F_iter__838000661 = c__iter__838000661; t.F_s__838000662 = c__s__838000662 }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A) Invoke_O__O(self any) any { { var s__838000662__1 any; var t_ any = t.F_s__838000662; t.F_s__838000662 = nil; s__838000662__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000662__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000662__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000662__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000662__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000664__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A_New_O_I_O(b__838000664__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000661); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000664__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000662__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000664__6), nil) } } else { var sp__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000662__3); var nm__5 any; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var temp__1927000408__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__4))


	if jrt.A2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; nm__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__6) } else { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_477; nm__5 = tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__4))) }
//line :1488:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_565).Invoke_O__O(nm__5))) { var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_50; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__838000661); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__4))), nm__5), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000662__3))) } else { s__838000662__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000662__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A) Ctor_O_I_O(c__b__838000664 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__838000664 = c__b__838000664; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A) Invoke_O__O(self any) any { { var i__838000663__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000663__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000663__1)); var nm__3 any; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2))


	if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; nm__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__4) } else { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_477; nm__3 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__2))) }
//line :1488:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_564).Invoke_O__O(nm__3))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp6 any = t.F_b__838000664; var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_50; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2))), nm__3)); i__838000663__1 = lang.Numbers_Unchecked_inc_J__J(i__838000663__1); continue L1 } else { i__838000663__1 = lang.Numbers_Unchecked_inc_J__J(i__838000663__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A_New() *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A{}; t.Ctor(); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A) Ctor() {}
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A) Invoke_O_O__O(self, s__838000679__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A_New_O_O(self, s__838000679__1); var tmp2 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A_fn_class = fncls__142d; tmp2 = fncls__142d } else { tmp2 = fncls__142 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A) Ctor_O_O(c__iter__838000678, c__s__838000679 any) { t.F_iter__838000678 = c__iter__838000678; t.F_s__838000679 = c__s__838000679 }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A) Invoke_O__O(self any) any { { var s__838000679__1 any; var t_ any = t.F_s__838000679; t.F_s__838000679 = nil; s__838000679__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000679__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 bool; var tmp2 any = A_arbace_g2a_convert_A_const_89; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_convert_A_const_32.GetRawRoot__O()).Invoke_O__O(d__4))
																				if and__1927000168__auto____5 { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_358; tmp1 = lang.Util_Equiv_O_O__Z(Lit_46, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4))) } else { tmp1 = and__1927000168__auto____5 }
//line :1488:1
	if tmp1 { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A_New(); var tmp5 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A_fn_class = fncls__141d; tmp5 = fncls__141d } else { tmp5 = fncls__141 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_359; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(d__4)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__838000678); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_220.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000679__1))) } else { s__838000679__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000679__1); continue L1 } } else { s__838000679__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000679__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A_New() *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A{}; t.Ctor(); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A) Ctor() {}
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A) Invoke_O_O__O(self, s__838000681__1 any) any { var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A_New_O_O(self, s__838000681__1); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A_New_O_O(p0, p1 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A) Ctor_O_O(c__iter__838000680, c__s__838000681 any) { t.F_iter__838000680 = c__iter__838000680; t.F_s__838000681 = c__s__838000681 }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A) Invoke_O__O(self any) any { { var s__838000681__1 any; var t_ any = t.F_s__838000681; t.F_s__838000681 = nil; s__838000681__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_64.GetRawRoot__O()).Invoke_O__O(s__838000681__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__838000681__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_129.GetRawRoot__O()).Invoke_O__O(s__838000681__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_130.GetRawRoot__O()).Invoke_O__O(s__838000681__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__838000683__6 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_228.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A_New_O_I_O(b__838000683__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__838000680); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000683__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_134.GetRawRoot__O()).Invoke_O__O(s__838000681__3))) } else { return lang.IFn_Cast(A_arbace_g2a_convert_A_const_231.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_232.GetRawRoot__O()).Invoke_O__O(b__838000683__6), nil) } } else { var sp__4 any = lang.IFn_Cast(A_arbace_g2a_convert_A_const_19.GetRawRoot__O()).Invoke_O__O(s__838000681__3); var nm__5 any; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var temp__1927000408__auto____5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__4))


	if jrt.A2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; nm__5 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__6) } else { var tmp5 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp6 *lang.Keyword = A_arbace_g2a_convert_A_const_477; nm__5 = tmp5.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__4))) }
//line :1488:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_567).Invoke_O__O(nm__5))) { var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_50; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__838000680); return lang.IFn_Cast(A_arbace_g2a_convert_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__4))), nm__5), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000681__3))) } else { s__838000681__1 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_208.GetRawRoot__O()).Invoke_O__O(s__838000681__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :1488:1
func A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A) Ctor_O_I_O(c__b__838000683 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__838000683 = c__b__838000683; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1488:1
func (t *A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A) Invoke_O__O(self any) any { { var i__838000682__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__838000682__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__838000682__1)); var nm__3 any; var tmp2 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2))


	if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; nm__3 = lang.IFn_Cast(A_arbace_g2a_convert_A_const_170.GetRawRoot__O()).Invoke_O__O(n__4) } else { var tmp3 *lang.Keyword = A_arbace_g2a_convert_A_const_48; var tmp4 *lang.Keyword = A_arbace_g2a_convert_A_const_477; nm__3 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_162.GetRawRoot__O()).Invoke_O__O(sp__2))) }
//line :1488:1
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_convert_A_const_148.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_566).Invoke_O__O(nm__3))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_convert_A_const_229.GetRawRoot__O()); var tmp6 any = t.F_b__838000683; var tmp7 *lang.Keyword = A_arbace_g2a_convert_A_const_50; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_convert_A_const_224.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_convert_A_const_34.GetRawRoot__O()).Invoke_O__O(sp__2))), nm__3)); i__838000682__1 = lang.Numbers_Unchecked_inc_J__J(i__838000682__1); continue L1 } else { i__838000682__1 = lang.Numbers_Unchecked_inc_J__J(i__838000682__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





























































































































































































































type A_arbace_g2a_convert_A struct{ jrt.Object }

var A_arbace_g2a_convert_A_const_pool *jrt.RefArray

var A_arbace_g2a_convert_A_const_0 *lang.Var

var A_arbace_g2a_convert_A_const_1 *lang.Var

var A_arbace_g2a_convert_A_const_2 any

var A_arbace_g2a_convert_A_const_3 any

var A_arbace_g2a_convert_A_const_4 any

var A_arbace_g2a_convert_A_const_5 any

var A_arbace_g2a_convert_A_const_6 *lang.Var

var A_arbace_g2a_convert_A_const_7 *lang.Var

var A_arbace_g2a_convert_A_const_8 *lang.Var

var A_arbace_g2a_convert_A_const_9 any

var A_arbace_g2a_convert_A_const_10 *lang.Var

var A_arbace_g2a_convert_A_const_11 *lang.Var

var A_arbace_g2a_convert_A_const_12 *lang.Var

var A_arbace_g2a_convert_A_const_13 *lang.Var

var A_arbace_g2a_convert_A_const_14 *lang.Var

var A_arbace_g2a_convert_A_const_15 *lang.Keyword

var A_arbace_g2a_convert_A_const_16 *lang.Var

var A_arbace_g2a_convert_A_const_17 any

var A_arbace_g2a_convert_A_const_18 *lang.Keyword

var A_arbace_g2a_convert_A_const_19 *lang.Var

var A_arbace_g2a_convert_A_const_20 *lang.Var

var A_arbace_g2a_convert_A_const_21 *lang.Var

var A_arbace_g2a_convert_A_const_22 *lang.Var

var A_arbace_g2a_convert_A_const_23 *lang.Var

var A_arbace_g2a_convert_A_const_24 *lang.Var

var A_arbace_g2a_convert_A_const_25 *lang.Var

var A_arbace_g2a_convert_A_const_26 *lang.Keyword

var A_arbace_g2a_convert_A_const_27 *lang.Var

var A_arbace_g2a_convert_A_const_28 *lang.Var

var A_arbace_g2a_convert_A_const_29 *lang.Var

var A_arbace_g2a_convert_A_const_30 any

var A_arbace_g2a_convert_A_const_31 *lang.Keyword

var A_arbace_g2a_convert_A_const_32 *lang.Var

var A_arbace_g2a_convert_A_const_33 *lang.Keyword

var A_arbace_g2a_convert_A_const_34 *lang.Var

var A_arbace_g2a_convert_A_const_35 any

var A_arbace_g2a_convert_A_const_36 *lang.Var

var A_arbace_g2a_convert_A_const_37 *lang.Var

var A_arbace_g2a_convert_A_const_38 *lang.Keyword

var A_arbace_g2a_convert_A_const_39 *lang.Var

var A_arbace_g2a_convert_A_const_40 *lang.Keyword

var A_arbace_g2a_convert_A_const_41 *lang.Keyword

var A_arbace_g2a_convert_A_const_42 *lang.Keyword

var A_arbace_g2a_convert_A_const_43 *lang.Keyword

var A_arbace_g2a_convert_A_const_44 *lang.Keyword

var A_arbace_g2a_convert_A_const_45 *lang.Var

var A_arbace_g2a_convert_A_const_46 *lang.Keyword

var A_arbace_g2a_convert_A_const_47 *lang.Keyword

var A_arbace_g2a_convert_A_const_48 *lang.Keyword

var A_arbace_g2a_convert_A_const_49 *lang.Keyword

var A_arbace_g2a_convert_A_const_50 *lang.Keyword

var A_arbace_g2a_convert_A_const_51 *lang.Keyword

var A_arbace_g2a_convert_A_const_52 *lang.Keyword

var A_arbace_g2a_convert_A_const_53 *lang.Keyword

var A_arbace_g2a_convert_A_const_54 *lang.Keyword

var A_arbace_g2a_convert_A_const_55 *lang.Keyword

var A_arbace_g2a_convert_A_const_56 *lang.Keyword

var A_arbace_g2a_convert_A_const_57 *lang.Keyword

var A_arbace_g2a_convert_A_const_58 *lang.Keyword

var A_arbace_g2a_convert_A_const_59 *lang.Keyword

var A_arbace_g2a_convert_A_const_60 *lang.Keyword

var A_arbace_g2a_convert_A_const_61 *lang.Keyword

var A_arbace_g2a_convert_A_const_62 *lang.Keyword

var A_arbace_g2a_convert_A_const_63 *lang.Keyword

var A_arbace_g2a_convert_A_const_64 *lang.Var

var A_arbace_g2a_convert_A_const_65 *lang.Keyword

var A_arbace_g2a_convert_A_const_66 *lang.Keyword

var A_arbace_g2a_convert_A_const_67 *lang.Keyword

var A_arbace_g2a_convert_A_const_68 *lang.Keyword

var A_arbace_g2a_convert_A_const_69 *lang.Keyword

var A_arbace_g2a_convert_A_const_70 *lang.Keyword

var A_arbace_g2a_convert_A_const_71 *lang.Keyword

var A_arbace_g2a_convert_A_const_72 *lang.Keyword

var A_arbace_g2a_convert_A_const_73 *lang.Keyword

var A_arbace_g2a_convert_A_const_74 *lang.Keyword

var A_arbace_g2a_convert_A_const_75 *lang.Keyword

var A_arbace_g2a_convert_A_const_76 *lang.Keyword

var A_arbace_g2a_convert_A_const_77 *lang.Keyword

var A_arbace_g2a_convert_A_const_78 *lang.Keyword

var A_arbace_g2a_convert_A_const_79 *lang.Keyword

var A_arbace_g2a_convert_A_const_80 *lang.Keyword

var A_arbace_g2a_convert_A_const_81 *lang.Keyword

var A_arbace_g2a_convert_A_const_82 *lang.Keyword

var A_arbace_g2a_convert_A_const_83 *lang.Keyword

var A_arbace_g2a_convert_A_const_84 *lang.Keyword

var A_arbace_g2a_convert_A_const_85 *lang.Keyword

var A_arbace_g2a_convert_A_const_86 *lang.Keyword

var A_arbace_g2a_convert_A_const_87 *lang.Keyword

var A_arbace_g2a_convert_A_const_88 *lang.Keyword

var A_arbace_g2a_convert_A_const_89 *lang.Keyword

var A_arbace_g2a_convert_A_const_90 *lang.Keyword

var A_arbace_g2a_convert_A_const_91 *lang.Keyword

var A_arbace_g2a_convert_A_const_92 *lang.Keyword

var A_arbace_g2a_convert_A_const_93 *lang.Keyword

var A_arbace_g2a_convert_A_const_94 *lang.Keyword

var A_arbace_g2a_convert_A_const_95 *lang.Keyword

var A_arbace_g2a_convert_A_const_96 *lang.Keyword

var A_arbace_g2a_convert_A_const_97 *lang.Keyword

var A_arbace_g2a_convert_A_const_98 *lang.Keyword

var A_arbace_g2a_convert_A_const_99 *lang.Keyword

var A_arbace_g2a_convert_A_const_100 *lang.Keyword

var A_arbace_g2a_convert_A_const_101 *lang.Keyword

var A_arbace_g2a_convert_A_const_102 *lang.Keyword

var A_arbace_g2a_convert_A_const_103 *lang.Keyword

var A_arbace_g2a_convert_A_const_104 *lang.Keyword

var A_arbace_g2a_convert_A_const_105 *lang.Keyword

var A_arbace_g2a_convert_A_const_106 *lang.Keyword

var A_arbace_g2a_convert_A_const_107 *lang.Keyword

var A_arbace_g2a_convert_A_const_108 *lang.Keyword

var A_arbace_g2a_convert_A_const_109 *lang.Keyword

var A_arbace_g2a_convert_A_const_110 *lang.Keyword

var A_arbace_g2a_convert_A_const_111 *lang.Keyword

var A_arbace_g2a_convert_A_const_112 *lang.Keyword

var A_arbace_g2a_convert_A_const_113 *lang.Keyword

var A_arbace_g2a_convert_A_const_114 *lang.Keyword

var A_arbace_g2a_convert_A_const_115 *lang.Keyword

var A_arbace_g2a_convert_A_const_116 *lang.Keyword

var A_arbace_g2a_convert_A_const_117 *lang.Keyword

var A_arbace_g2a_convert_A_const_118 *lang.Keyword

var A_arbace_g2a_convert_A_const_119 *lang.Keyword

var A_arbace_g2a_convert_A_const_120 *lang.Keyword

var A_arbace_g2a_convert_A_const_121 *lang.Keyword

var A_arbace_g2a_convert_A_const_122 *lang.Keyword

var A_arbace_g2a_convert_A_const_123 *lang.Keyword

var A_arbace_g2a_convert_A_const_124 *lang.Var

var A_arbace_g2a_convert_A_const_125 *lang.Var

var A_arbace_g2a_convert_A_const_126 *lang.Var

var A_arbace_g2a_convert_A_const_127 *lang.Var

var A_arbace_g2a_convert_A_const_128 *lang.Var

var A_arbace_g2a_convert_A_const_129 *lang.Var

var A_arbace_g2a_convert_A_const_130 *lang.Var

var A_arbace_g2a_convert_A_const_131 *lang.Var

var A_arbace_g2a_convert_A_const_132 *lang.Var

var A_arbace_g2a_convert_A_const_133 *lang.Var

var A_arbace_g2a_convert_A_const_134 *lang.Var

var A_arbace_g2a_convert_A_const_135 *lang.Var

var A_arbace_g2a_convert_A_const_136 any

var A_arbace_g2a_convert_A_const_137 *lang.Var

var A_arbace_g2a_convert_A_const_138 *lang.Var

var A_arbace_g2a_convert_A_const_139 *lang.Keyword

var A_arbace_g2a_convert_A_const_140 *lang.Var

var A_arbace_g2a_convert_A_const_141 *lang.Var

var A_arbace_g2a_convert_A_const_142 *lang.Keyword

var A_arbace_g2a_convert_A_const_143 *lang.Var

var A_arbace_g2a_convert_A_const_144 *lang.Var

var A_arbace_g2a_convert_A_const_145 *lang.Var

var A_arbace_g2a_convert_A_const_146 *lang.Var

var A_arbace_g2a_convert_A_const_147 *lang.Keyword

var A_arbace_g2a_convert_A_const_148 *lang.Var

var A_arbace_g2a_convert_A_const_149 *lang.Var

var A_arbace_g2a_convert_A_const_150 *lang.Var

var A_arbace_g2a_convert_A_const_151 *lang.Var

var A_arbace_g2a_convert_A_const_152 *lang.Keyword

var A_arbace_g2a_convert_A_const_153 *lang.Keyword

var A_arbace_g2a_convert_A_const_154 *lang.Var

var A_arbace_g2a_convert_A_const_155 *lang.Var

var A_arbace_g2a_convert_A_const_156 *lang.Keyword

var A_arbace_g2a_convert_A_const_157 *lang.Var

var A_arbace_g2a_convert_A_const_158 *lang.Var

var A_arbace_g2a_convert_A_const_159 *lang.Var

var A_arbace_g2a_convert_A_const_160 *lang.Var

var A_arbace_g2a_convert_A_const_161 *lang.Keyword

var A_arbace_g2a_convert_A_const_162 *lang.Var

var A_arbace_g2a_convert_A_const_163 *lang.Keyword

var A_arbace_g2a_convert_A_const_164 *lang.Var

var A_arbace_g2a_convert_A_const_165 *lang.Keyword

var A_arbace_g2a_convert_A_const_166 *lang.Keyword

var A_arbace_g2a_convert_A_const_167 *lang.Var

var A_arbace_g2a_convert_A_const_168 *lang.Keyword

var A_arbace_g2a_convert_A_const_169 *lang.Var

var A_arbace_g2a_convert_A_const_170 *lang.Var

var A_arbace_g2a_convert_A_const_171 *lang.Var

var A_arbace_g2a_convert_A_const_172 *lang.Var

var A_arbace_g2a_convert_A_const_173 any

var A_arbace_g2a_convert_A_const_174 *lang.Keyword

var A_arbace_g2a_convert_A_const_175 *lang.Keyword

var A_arbace_g2a_convert_A_const_176 *lang.Keyword

var A_arbace_g2a_convert_A_const_177 *lang.Keyword

var A_arbace_g2a_convert_A_const_178 *lang.Var

var A_arbace_g2a_convert_A_const_179 *lang.Var

var A_arbace_g2a_convert_A_const_180 *lang.Var

var A_arbace_g2a_convert_A_const_181 *lang.Var

var A_arbace_g2a_convert_A_const_182 *lang.Var

var A_arbace_g2a_convert_A_const_183 *lang.Var

var A_arbace_g2a_convert_A_const_184 any

var A_arbace_g2a_convert_A_const_185 *lang.Var

var A_arbace_g2a_convert_A_const_186 *lang.Keyword

var A_arbace_g2a_convert_A_const_187 any

var A_arbace_g2a_convert_A_const_188 *lang.Var

var A_arbace_g2a_convert_A_const_189 *lang.Var

var A_arbace_g2a_convert_A_const_190 *lang.Var

var A_arbace_g2a_convert_A_const_191 *lang.Var

var A_arbace_g2a_convert_A_const_192 *lang.Keyword

var A_arbace_g2a_convert_A_const_193 *lang.Var

var A_arbace_g2a_convert_A_const_194 *lang.Var

var A_arbace_g2a_convert_A_const_195 *lang.Keyword

var A_arbace_g2a_convert_A_const_196 *lang.Var

var A_arbace_g2a_convert_A_const_197 *lang.Var

var A_arbace_g2a_convert_A_const_198 *lang.Var

var A_arbace_g2a_convert_A_const_199 any

var A_arbace_g2a_convert_A_const_200 *lang.Var

var A_arbace_g2a_convert_A_const_201 *lang.Var

var A_arbace_g2a_convert_A_const_202 *lang.Var

var A_arbace_g2a_convert_A_const_203 *lang.Var

var A_arbace_g2a_convert_A_const_204 *lang.Keyword

var A_arbace_g2a_convert_A_const_205 *lang.Var

var A_arbace_g2a_convert_A_const_206 *lang.Var

var A_arbace_g2a_convert_A_const_207 *lang.Keyword

var A_arbace_g2a_convert_A_const_208 *lang.Var

var A_arbace_g2a_convert_A_const_209 *lang.Var

var A_arbace_g2a_convert_A_const_210 *lang.Var

var A_arbace_g2a_convert_A_const_211 *lang.Keyword

var A_arbace_g2a_convert_A_const_212 *lang.Var

var A_arbace_g2a_convert_A_const_213 *lang.Var

var A_arbace_g2a_convert_A_const_214 *lang.Keyword

var A_arbace_g2a_convert_A_const_215 *lang.Var

var A_arbace_g2a_convert_A_const_216 *lang.Var

var A_arbace_g2a_convert_A_const_217 *lang.Keyword

var A_arbace_g2a_convert_A_const_218 *lang.Var

var A_arbace_g2a_convert_A_const_219 *lang.Var

var A_arbace_g2a_convert_A_const_220 *lang.Var

var A_arbace_g2a_convert_A_const_221 any

var A_arbace_g2a_convert_A_const_222 *lang.Keyword

var A_arbace_g2a_convert_A_const_223 *lang.Keyword

var A_arbace_g2a_convert_A_const_224 *lang.Var

var A_arbace_g2a_convert_A_const_225 *lang.Var

var A_arbace_g2a_convert_A_const_226 any

var A_arbace_g2a_convert_A_const_227 *lang.Var

var A_arbace_g2a_convert_A_const_228 *lang.Var

var A_arbace_g2a_convert_A_const_229 *lang.Var

var A_arbace_g2a_convert_A_const_230 *lang.Var

var A_arbace_g2a_convert_A_const_231 *lang.Var

var A_arbace_g2a_convert_A_const_232 *lang.Var

var A_arbace_g2a_convert_A_const_233 *lang.Var

var A_arbace_g2a_convert_A_const_234 *lang.Keyword

var A_arbace_g2a_convert_A_const_235 *lang.Keyword

var A_arbace_g2a_convert_A_const_236 *lang.Keyword

var A_arbace_g2a_convert_A_const_237 *lang.Keyword

var A_arbace_g2a_convert_A_const_238 *lang.Var

var A_arbace_g2a_convert_A_const_239 *lang.Var

var A_arbace_g2a_convert_A_const_240 any

var A_arbace_g2a_convert_A_const_241 any

var A_arbace_g2a_convert_A_const_242 any

var A_arbace_g2a_convert_A_const_243 any

var A_arbace_g2a_convert_A_const_244 any

var A_arbace_g2a_convert_A_const_245 *lang.Var

var A_arbace_g2a_convert_A_const_246 *lang.Keyword

var A_arbace_g2a_convert_A_const_247 *lang.Keyword

var A_arbace_g2a_convert_A_const_248 *lang.Keyword

var A_arbace_g2a_convert_A_const_249 any

var A_arbace_g2a_convert_A_const_250 *lang.Keyword

var A_arbace_g2a_convert_A_const_251 any

var A_arbace_g2a_convert_A_const_252 *lang.Var

var A_arbace_g2a_convert_A_const_253 *lang.Keyword

var A_arbace_g2a_convert_A_const_254 any

var A_arbace_g2a_convert_A_const_255 *lang.Keyword

var A_arbace_g2a_convert_A_const_256 any

var A_arbace_g2a_convert_A_const_257 any

var A_arbace_g2a_convert_A_const_258 any

var A_arbace_g2a_convert_A_const_259 any

var A_arbace_g2a_convert_A_const_260 *lang.Var

var A_arbace_g2a_convert_A_const_261 any

var A_arbace_g2a_convert_A_const_262 *lang.Var

var A_arbace_g2a_convert_A_const_263 any

var A_arbace_g2a_convert_A_const_264 *lang.Keyword

var A_arbace_g2a_convert_A_const_265 *lang.Keyword

var A_arbace_g2a_convert_A_const_266 any

var A_arbace_g2a_convert_A_const_267 *lang.Keyword

var A_arbace_g2a_convert_A_const_268 any

var A_arbace_g2a_convert_A_const_269 any

var A_arbace_g2a_convert_A_const_270 *lang.Var

var A_arbace_g2a_convert_A_const_271 any

var A_arbace_g2a_convert_A_const_272 *lang.Var

var A_arbace_g2a_convert_A_const_273 *lang.Var

var A_arbace_g2a_convert_A_const_274 any

var A_arbace_g2a_convert_A_const_275 any

var A_arbace_g2a_convert_A_const_276 *lang.Var

var A_arbace_g2a_convert_A_const_277 *lang.Var

var A_arbace_g2a_convert_A_const_278 *lang.Var

var A_arbace_g2a_convert_A_const_279 *lang.Var

var A_arbace_g2a_convert_A_const_280 *lang.Keyword

var A_arbace_g2a_convert_A_const_281 any

var A_arbace_g2a_convert_A_const_282 *lang.Var

var A_arbace_g2a_convert_A_const_283 *lang.Keyword

var A_arbace_g2a_convert_A_const_284 *lang.Var

var A_arbace_g2a_convert_A_const_285 any

var A_arbace_g2a_convert_A_const_286 *lang.Keyword

var A_arbace_g2a_convert_A_const_287 any

var A_arbace_g2a_convert_A_const_288 any

var A_arbace_g2a_convert_A_const_289 *lang.Keyword

var A_arbace_g2a_convert_A_const_290 *lang.Keyword

var A_arbace_g2a_convert_A_const_291 *lang.Keyword

var A_arbace_g2a_convert_A_const_292 any

var A_arbace_g2a_convert_A_const_293 *lang.Keyword

var A_arbace_g2a_convert_A_const_294 any

var A_arbace_g2a_convert_A_const_295 *lang.Var

var A_arbace_g2a_convert_A_const_296 *lang.Var

var A_arbace_g2a_convert_A_const_297 *lang.Var

var A_arbace_g2a_convert_A_const_298 any

var A_arbace_g2a_convert_A_const_299 *lang.Var

var A_arbace_g2a_convert_A_const_300 *lang.Var

var A_arbace_g2a_convert_A_const_301 any

var A_arbace_g2a_convert_A_const_302 *lang.Keyword

var A_arbace_g2a_convert_A_const_303 *lang.Var

var A_arbace_g2a_convert_A_const_304 any

var A_arbace_g2a_convert_A_const_305 any

var A_arbace_g2a_convert_A_const_306 any

var A_arbace_g2a_convert_A_const_307 *lang.Keyword

var A_arbace_g2a_convert_A_const_308 *lang.Var

var A_arbace_g2a_convert_A_const_309 *lang.Keyword

var A_arbace_g2a_convert_A_const_310 any

var A_arbace_g2a_convert_A_const_311 any

var A_arbace_g2a_convert_A_const_312 any

var A_arbace_g2a_convert_A_const_313 *lang.Keyword

var A_arbace_g2a_convert_A_const_314 any

var A_arbace_g2a_convert_A_const_315 *lang.Keyword

var A_arbace_g2a_convert_A_const_316 *lang.Var

var A_arbace_g2a_convert_A_const_317 *lang.Var

var A_arbace_g2a_convert_A_const_318 *lang.Keyword

var A_arbace_g2a_convert_A_const_319 *lang.Keyword

var A_arbace_g2a_convert_A_const_320 any

var A_arbace_g2a_convert_A_const_321 *lang.Var

var A_arbace_g2a_convert_A_const_322 any

var A_arbace_g2a_convert_A_const_323 *lang.Var

var A_arbace_g2a_convert_A_const_324 *lang.Var

var A_arbace_g2a_convert_A_const_325 *lang.Var

var A_arbace_g2a_convert_A_const_326 *lang.Keyword

var A_arbace_g2a_convert_A_const_327 *lang.Keyword

var A_arbace_g2a_convert_A_const_328 *lang.Keyword

var A_arbace_g2a_convert_A_const_329 any

var A_arbace_g2a_convert_A_const_330 *lang.Keyword

var A_arbace_g2a_convert_A_const_331 *lang.Var

var A_arbace_g2a_convert_A_const_332 any

var A_arbace_g2a_convert_A_const_333 *lang.Var

var A_arbace_g2a_convert_A_const_334 *lang.Var

var A_arbace_g2a_convert_A_const_335 *lang.Var

var A_arbace_g2a_convert_A_const_336 any

var A_arbace_g2a_convert_A_const_337 *lang.Keyword

var A_arbace_g2a_convert_A_const_338 any

var A_arbace_g2a_convert_A_const_339 any

var A_arbace_g2a_convert_A_const_340 *lang.Keyword

var A_arbace_g2a_convert_A_const_341 any

var A_arbace_g2a_convert_A_const_342 *lang.Var

var A_arbace_g2a_convert_A_const_343 any

var A_arbace_g2a_convert_A_const_344 *lang.Var

var A_arbace_g2a_convert_A_const_345 *lang.Keyword

var A_arbace_g2a_convert_A_const_346 any

var A_arbace_g2a_convert_A_const_347 any

var A_arbace_g2a_convert_A_const_348 any

var A_arbace_g2a_convert_A_const_349 any

var A_arbace_g2a_convert_A_const_350 *lang.Keyword

var A_arbace_g2a_convert_A_const_351 *lang.Keyword

var A_arbace_g2a_convert_A_const_352 *lang.Var

var A_arbace_g2a_convert_A_const_353 *lang.Var

var A_arbace_g2a_convert_A_const_354 *lang.Var

var A_arbace_g2a_convert_A_const_355 *lang.Var

var A_arbace_g2a_convert_A_const_356 *lang.Keyword

var A_arbace_g2a_convert_A_const_357 *lang.Var

var A_arbace_g2a_convert_A_const_358 *lang.Keyword

var A_arbace_g2a_convert_A_const_359 *lang.Keyword

var A_arbace_g2a_convert_A_const_360 *lang.Keyword

var A_arbace_g2a_convert_A_const_361 *lang.Keyword

var A_arbace_g2a_convert_A_const_362 *lang.Var

var A_arbace_g2a_convert_A_const_363 *lang.Keyword

var A_arbace_g2a_convert_A_const_364 *lang.Keyword

var A_arbace_g2a_convert_A_const_365 *lang.Keyword

var A_arbace_g2a_convert_A_const_366 *lang.Keyword

var A_arbace_g2a_convert_A_const_367 any

var A_arbace_g2a_convert_A_const_368 *lang.Keyword

var A_arbace_g2a_convert_A_const_369 *lang.Keyword

var A_arbace_g2a_convert_A_const_370 *lang.Keyword

var A_arbace_g2a_convert_A_const_371 *lang.Var

var A_arbace_g2a_convert_A_const_372 *lang.Var

var A_arbace_g2a_convert_A_const_373 *lang.Keyword

var A_arbace_g2a_convert_A_const_374 *lang.Keyword

var A_arbace_g2a_convert_A_const_375 *lang.Var

var A_arbace_g2a_convert_A_const_376 *lang.Keyword

var A_arbace_g2a_convert_A_const_377 *lang.Var

var A_arbace_g2a_convert_A_const_378 *lang.Var

var A_arbace_g2a_convert_A_const_379 *lang.Var

var A_arbace_g2a_convert_A_const_380 *lang.Var

var A_arbace_g2a_convert_A_const_381 *lang.Keyword

var A_arbace_g2a_convert_A_const_382 any

var A_arbace_g2a_convert_A_const_383 *lang.Var

var A_arbace_g2a_convert_A_const_384 *lang.Var

var A_arbace_g2a_convert_A_const_385 *lang.Var

var A_arbace_g2a_convert_A_const_386 *lang.Var

var A_arbace_g2a_convert_A_const_387 *lang.Var

var A_arbace_g2a_convert_A_const_388 *lang.Var

var A_arbace_g2a_convert_A_const_389 *lang.Var

var A_arbace_g2a_convert_A_const_390 *lang.Var

var A_arbace_g2a_convert_A_const_391 *lang.Var

var A_arbace_g2a_convert_A_const_392 *lang.Keyword

var A_arbace_g2a_convert_A_const_393 *lang.Keyword

var A_arbace_g2a_convert_A_const_394 *lang.Var

var A_arbace_g2a_convert_A_const_395 *lang.Keyword

var A_arbace_g2a_convert_A_const_396 any

var A_arbace_g2a_convert_A_const_397 any

var A_arbace_g2a_convert_A_const_398 *lang.Var

var A_arbace_g2a_convert_A_const_399 *lang.Var

var A_arbace_g2a_convert_A_const_400 *lang.Var

var A_arbace_g2a_convert_A_const_401 *lang.Var

var A_arbace_g2a_convert_A_const_402 any

var A_arbace_g2a_convert_A_const_403 any

var A_arbace_g2a_convert_A_const_404 any

var A_arbace_g2a_convert_A_const_405 any

var A_arbace_g2a_convert_A_const_406 *lang.Var

var A_arbace_g2a_convert_A_const_407 *lang.Keyword

var A_arbace_g2a_convert_A_const_408 *lang.Keyword

var A_arbace_g2a_convert_A_const_409 any

var A_arbace_g2a_convert_A_const_410 *lang.Var

var A_arbace_g2a_convert_A_const_411 any

var A_arbace_g2a_convert_A_const_412 *lang.Var

var A_arbace_g2a_convert_A_const_413 any

var A_arbace_g2a_convert_A_const_414 *lang.Var

var A_arbace_g2a_convert_A_const_415 *lang.Keyword

var A_arbace_g2a_convert_A_const_416 *lang.Keyword

var A_arbace_g2a_convert_A_const_417 *lang.Keyword

var A_arbace_g2a_convert_A_const_418 any

var A_arbace_g2a_convert_A_const_419 any

var A_arbace_g2a_convert_A_const_420 *lang.Var

var A_arbace_g2a_convert_A_const_421 *lang.Var

var A_arbace_g2a_convert_A_const_422 *lang.Keyword

var A_arbace_g2a_convert_A_const_423 any

var A_arbace_g2a_convert_A_const_424 any

var A_arbace_g2a_convert_A_const_425 *lang.Var

var A_arbace_g2a_convert_A_const_426 *lang.Var

var A_arbace_g2a_convert_A_const_427 any

var A_arbace_g2a_convert_A_const_428 any

var A_arbace_g2a_convert_A_const_429 any

var A_arbace_g2a_convert_A_const_430 any

var A_arbace_g2a_convert_A_const_431 *lang.Var

var A_arbace_g2a_convert_A_const_432 any

var A_arbace_g2a_convert_A_const_433 *lang.Keyword

var A_arbace_g2a_convert_A_const_434 any

var A_arbace_g2a_convert_A_const_435 any

var A_arbace_g2a_convert_A_const_436 any

var A_arbace_g2a_convert_A_const_437 *lang.Keyword

var A_arbace_g2a_convert_A_const_438 any

var A_arbace_g2a_convert_A_const_439 *lang.Var

var A_arbace_g2a_convert_A_const_440 any

var A_arbace_g2a_convert_A_const_441 any

var A_arbace_g2a_convert_A_const_442 any

var A_arbace_g2a_convert_A_const_443 any

var A_arbace_g2a_convert_A_const_444 *lang.Var

var A_arbace_g2a_convert_A_const_445 any

var A_arbace_g2a_convert_A_const_446 *lang.Keyword

var A_arbace_g2a_convert_A_const_447 any

var A_arbace_g2a_convert_A_const_448 any

var A_arbace_g2a_convert_A_const_449 any

var A_arbace_g2a_convert_A_const_450 *lang.Var

var A_arbace_g2a_convert_A_const_451 any

var A_arbace_g2a_convert_A_const_452 any

var A_arbace_g2a_convert_A_const_453 any

var A_arbace_g2a_convert_A_const_454 any

var A_arbace_g2a_convert_A_const_455 any

var A_arbace_g2a_convert_A_const_456 *lang.Var

var A_arbace_g2a_convert_A_const_457 *lang.Var

var A_arbace_g2a_convert_A_const_458 *lang.Var

var A_arbace_g2a_convert_A_const_459 any

var A_arbace_g2a_convert_A_const_460 *lang.Var

var A_arbace_g2a_convert_A_const_461 *lang.Var

var A_arbace_g2a_convert_A_const_462 *lang.Var

var A_arbace_g2a_convert_A_const_463 *lang.Var

var A_arbace_g2a_convert_A_const_464 *lang.Var

var A_arbace_g2a_convert_A_const_465 any

var A_arbace_g2a_convert_A_const_466 *lang.Keyword

var A_arbace_g2a_convert_A_const_467 any

var A_arbace_g2a_convert_A_const_468 any

var A_arbace_g2a_convert_A_const_469 any

var A_arbace_g2a_convert_A_const_470 any

var A_arbace_g2a_convert_A_const_471 any

var A_arbace_g2a_convert_A_const_472 any

var A_arbace_g2a_convert_A_const_473 any

var A_arbace_g2a_convert_A_const_474 *lang.Var

var A_arbace_g2a_convert_A_const_475 *lang.Keyword

var A_arbace_g2a_convert_A_const_476 any

var A_arbace_g2a_convert_A_const_477 *lang.Keyword

var A_arbace_g2a_convert_A_const_478 any

var A_arbace_g2a_convert_A_const_479 *lang.Keyword

var A_arbace_g2a_convert_A_const_480 *lang.Keyword

var A_arbace_g2a_convert_A_const_481 *lang.Keyword

var A_arbace_g2a_convert_A_const_482 *lang.Var

var A_arbace_g2a_convert_A_const_483 *lang.Var

var A_arbace_g2a_convert_A_const_484 *lang.Var

var A_arbace_g2a_convert_A_const_485 *lang.Var

var A_arbace_g2a_convert_A_const_486 *lang.Var

var A_arbace_g2a_convert_A_const_487 *lang.Keyword

var A_arbace_g2a_convert_A_const_488 *lang.Keyword

var A_arbace_g2a_convert_A_const_489 any

var A_arbace_g2a_convert_A_const_490 *lang.Keyword

var A_arbace_g2a_convert_A_const_491 *lang.Keyword

var A_arbace_g2a_convert_A_const_492 *lang.Keyword

var A_arbace_g2a_convert_A_const_493 *lang.Keyword

var A_arbace_g2a_convert_A_const_494 *lang.Keyword

var A_arbace_g2a_convert_A_const_495 *lang.Var

var A_arbace_g2a_convert_A_const_496 *lang.Var

var A_arbace_g2a_convert_A_const_497 any

var A_arbace_g2a_convert_A_const_498 *lang.Keyword

var A_arbace_g2a_convert_A_const_499 *lang.Var

var A_arbace_g2a_convert_A_const_500 *lang.Var

var A_arbace_g2a_convert_A_const_501 *lang.Var

var A_arbace_g2a_convert_A_const_502 *lang.Keyword

var A_arbace_g2a_convert_A_const_503 *lang.Keyword

var A_arbace_g2a_convert_A_const_504 *lang.Keyword

var A_arbace_g2a_convert_A_const_505 *lang.Var

var A_arbace_g2a_convert_A_const_506 *lang.Var

var A_arbace_g2a_convert_A_const_507 *lang.Keyword

var A_arbace_g2a_convert_A_const_508 *lang.Keyword

var A_arbace_g2a_convert_A_const_509 *lang.Var

var A_arbace_g2a_convert_A_const_510 *lang.Var

var A_arbace_g2a_convert_A_const_511 *lang.Var

var A_arbace_g2a_convert_A_const_512 *lang.Var

var A_arbace_g2a_convert_A_const_513 *lang.Var

var A_arbace_g2a_convert_A_const_514 *lang.Keyword

var A_arbace_g2a_convert_A_const_515 *lang.Keyword

var A_arbace_g2a_convert_A_const_516 any

var A_arbace_g2a_convert_A_const_517 any

var A_arbace_g2a_convert_A_const_518 any

var A_arbace_g2a_convert_A_const_519 any

var A_arbace_g2a_convert_A_const_520 *lang.Keyword

var A_arbace_g2a_convert_A_const_521 any

var A_arbace_g2a_convert_A_const_522 *lang.Keyword

var A_arbace_g2a_convert_A_const_523 *lang.Keyword

var A_arbace_g2a_convert_A_const_524 *lang.Keyword

var A_arbace_g2a_convert_A_const_525 *lang.Var

var A_arbace_g2a_convert_A_const_526 any

var A_arbace_g2a_convert_A_const_527 *lang.Keyword

var A_arbace_g2a_convert_A_const_528 *lang.Keyword

var A_arbace_g2a_convert_A_const_529 any

var A_arbace_g2a_convert_A_const_530 *lang.Var

var A_arbace_g2a_convert_A_const_531 any

var A_arbace_g2a_convert_A_const_532 *lang.Var

var A_arbace_g2a_convert_A_const_533 *lang.Keyword

var A_arbace_g2a_convert_A_const_534 *lang.Keyword

var A_arbace_g2a_convert_A_const_535 *lang.Keyword

var A_arbace_g2a_convert_A_const_536 *lang.Keyword

var A_arbace_g2a_convert_A_const_537 *lang.Keyword

var A_arbace_g2a_convert_A_const_538 *lang.Keyword

var A_arbace_g2a_convert_A_const_539 *lang.Keyword

var A_arbace_g2a_convert_A_const_540 *lang.Keyword

var A_arbace_g2a_convert_A_const_541 *lang.Keyword

var A_arbace_g2a_convert_A_const_542 *lang.Keyword

var A_arbace_g2a_convert_A_const_543 *lang.Keyword

var A_arbace_g2a_convert_A_const_544 *lang.Keyword

var A_arbace_g2a_convert_A_const_545 *lang.Keyword

var A_arbace_g2a_convert_A_const_546 *lang.Var

var A_arbace_g2a_convert_A_const_547 *lang.Keyword

var A_arbace_g2a_convert_A_const_548 *lang.Keyword

var A_arbace_g2a_convert_A_const_549 *lang.Var

var A_arbace_g2a_convert_A_const_550 *lang.Var

var A_arbace_g2a_convert_A_const_551 *lang.Keyword

var A_arbace_g2a_convert_A_const_552 *lang.Keyword

var A_arbace_g2a_convert_A_const_553 *lang.Keyword

var A_arbace_g2a_convert_A_const_554 *lang.Var

var A_arbace_g2a_convert_A_const_555 *lang.Var

var A_arbace_g2a_convert_A_const_556 *lang.Keyword

var A_arbace_g2a_convert_A_const_557 *lang.Var

var A_arbace_g2a_convert_A_const_558 *lang.Var

var A_arbace_g2a_convert_A_const_559 *lang.Var

var A_arbace_g2a_convert_A_const_560 *lang.Keyword

var A_arbace_g2a_convert_A_const_561 *lang.Var

var A_arbace_g2a_convert_A_const_562 *lang.Keyword

var A_arbace_g2a_convert_A_const_563 *lang.Var

var A_arbace_g2a_convert_A_const_564 any

var A_arbace_g2a_convert_A_const_565 any

var A_arbace_g2a_convert_A_const_566 any

var A_arbace_g2a_convert_A_const_567 any

var A_arbace_g2a_convert_A_init jrt.ClassInit

func A_arbace_g2a_convert_A_Init() { if !A_arbace_g2a_convert_A_init.Done() { A_arbace_g2a_convert_A_init.Run(A_arbace_g2a_convert_A_clinit) } }

func A_arbace_g2a_convert_A_clinit() { A_arbace_g2a_convert_A_clinit_p0(); A_arbace_g2a_convert_A_clinit_p1(); A_arbace_g2a_convert_A_clinit_p2(); A_arbace_g2a_convert_A_clinit_p3(); A_arbace_g2a_convert_A_clinit_p4(); A_arbace_g2a_convert_A_clinit_p5(); A_arbace_g2a_convert_A_clinit_p6(); A_arbace_g2a_convert_A_clinit_p7(); A_arbace_g2a_convert_A_clinit_p8(); A_arbace_g2a_convert_A_clinit_p9(); A_arbace_g2a_convert_A_clinit_p10(); A_arbace_g2a_convert_A_clinit_p11(); A_arbace_g2a_convert_A_clinit_p12(); A_arbace_g2a_convert_A_clinit_p13(); A_arbace_g2a_convert_A_clinit_p14(); A_arbace_g2a_convert_A_clinit_p15(); A_arbace_g2a_convert_A_clinit_p16(); A_arbace_g2a_convert_A_clinit_p17(); A_arbace_g2a_convert_A_clinit_p18(); A_arbace_g2a_convert_A_clinit_p19(); A_arbace_g2a_convert_A_clinit_p20(); A_arbace_g2a_convert_A_clinit_p21(); A_arbace_g2a_convert_A_clinit_p22(); A_arbace_g2a_convert_A_clinit_p23(); A_arbace_g2a_convert_A_clinit_p24(); A_arbace_g2a_convert_A_clinit_p25(); A_arbace_g2a_convert_A_clinit_p26(); A_arbace_g2a_convert_A_clinit_p27(); A_arbace_g2a_convert_A_clinit_p28(); A_arbace_g2a_convert_A_clinit_p29(); A_arbace_g2a_convert_A_clinit_p30(); A_arbace_g2a_convert_A_clinit_p31(); A_arbace_g2a_convert_A_clinit_p32(); A_arbace_g2a_convert_A_clinit_p33(); A_arbace_g2a_convert_A_clinit_p34(); A_arbace_g2a_convert_A_clinit_p35(); A_arbace_g2a_convert_A_clinit_p36(); A_arbace_g2a_convert_A_clinit_p37(); A_arbace_g2a_convert_A_clinit_p38(); A_arbace_g2a_convert_A_clinit_p39(); A_arbace_g2a_convert_A_clinit_p40(); A_arbace_g2a_convert_A_clinit_p41(); A_arbace_g2a_convert_A_clinit_p42(); A_arbace_g2a_convert_A_clinit_p43(); A_arbace_g2a_convert_A_clinit_p44(); A_arbace_g2a_convert_A_clinit_p45() }

func A_arbace_g2a_convert_A_clinit_p0() { A_arbace_g2a_convert_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 879); A_arbace_g2a_convert_A_const_0 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[311]); A_arbace_g2a_convert_A_const_1 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[312]); A_arbace_g2a_convert_A_const_2 = A_arbace_g2a_convert_A_const_pool.A[313]; A_arbace_g2a_convert_A_const_3 = A_arbace_g2a_convert_A_const_pool.A[314]; A_arbace_g2a_convert_A_const_4 = A_arbace_g2a_convert_A_const_pool.A[315]; A_arbace_g2a_convert_A_const_5 = A_arbace_g2a_convert_A_const_pool.A[316]; A_arbace_g2a_convert_A_const_6 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[317]); A_arbace_g2a_convert_A_const_7 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[318]); A_arbace_g2a_convert_A_const_8 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[319]); A_arbace_g2a_convert_A_const_9 = A_arbace_g2a_convert_A_const_pool.A[320]; A_arbace_g2a_convert_A_const_10 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[321]); A_arbace_g2a_convert_A_const_11 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[322]) }

func A_arbace_g2a_convert_A_clinit_p1() { A_arbace_g2a_convert_A_const_12 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[323]); A_arbace_g2a_convert_A_const_13 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[324]); A_arbace_g2a_convert_A_const_14 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[325]); A_arbace_g2a_convert_A_const_15 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[326]); A_arbace_g2a_convert_A_const_16 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[327]); A_arbace_g2a_convert_A_const_17 = A_arbace_g2a_convert_A_const_pool.A[328]; A_arbace_g2a_convert_A_const_18 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[329]); A_arbace_g2a_convert_A_const_19 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[330]); A_arbace_g2a_convert_A_const_20 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[331]); A_arbace_g2a_convert_A_const_21 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[332]); A_arbace_g2a_convert_A_const_22 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[333]); A_arbace_g2a_convert_A_const_23 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[334]) }

func A_arbace_g2a_convert_A_clinit_p2() { A_arbace_g2a_convert_A_const_24 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[335]); A_arbace_g2a_convert_A_const_25 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[336]); A_arbace_g2a_convert_A_const_26 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[337]); A_arbace_g2a_convert_A_const_27 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[338]); A_arbace_g2a_convert_A_const_28 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[339]); A_arbace_g2a_convert_A_const_29 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[340]); A_arbace_g2a_convert_A_const_30 = A_arbace_g2a_convert_A_const_pool.A[341]; A_arbace_g2a_convert_A_const_31 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[342]); A_arbace_g2a_convert_A_const_32 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[343]); A_arbace_g2a_convert_A_const_33 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[344]); A_arbace_g2a_convert_A_const_34 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[345]); A_arbace_g2a_convert_A_const_35 = A_arbace_g2a_convert_A_const_pool.A[346] }

func A_arbace_g2a_convert_A_clinit_p3() { A_arbace_g2a_convert_A_const_36 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[347]); A_arbace_g2a_convert_A_const_37 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[348]); A_arbace_g2a_convert_A_const_38 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[349]); A_arbace_g2a_convert_A_const_39 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[350]); A_arbace_g2a_convert_A_const_40 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[351]); A_arbace_g2a_convert_A_const_41 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[352]); A_arbace_g2a_convert_A_const_42 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[353]); A_arbace_g2a_convert_A_const_43 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[354]); A_arbace_g2a_convert_A_const_44 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[355]); A_arbace_g2a_convert_A_const_45 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[356]); A_arbace_g2a_convert_A_const_46 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[357]); A_arbace_g2a_convert_A_const_47 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[358]) }

func A_arbace_g2a_convert_A_clinit_p4() { A_arbace_g2a_convert_A_const_48 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[359]); A_arbace_g2a_convert_A_const_49 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[360]); A_arbace_g2a_convert_A_const_50 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[361]); A_arbace_g2a_convert_A_const_51 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[362]); A_arbace_g2a_convert_A_const_52 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[363]); A_arbace_g2a_convert_A_const_53 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[364]); A_arbace_g2a_convert_A_const_54 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[365]); A_arbace_g2a_convert_A_const_55 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[366]); A_arbace_g2a_convert_A_const_56 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[367]); A_arbace_g2a_convert_A_const_57 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[368]); A_arbace_g2a_convert_A_const_58 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[369]); A_arbace_g2a_convert_A_const_59 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[370]) }

func A_arbace_g2a_convert_A_clinit_p5() { A_arbace_g2a_convert_A_const_60 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[371]); A_arbace_g2a_convert_A_const_61 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[372]); A_arbace_g2a_convert_A_const_62 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[373]); A_arbace_g2a_convert_A_const_63 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[374]); A_arbace_g2a_convert_A_const_64 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[375]); A_arbace_g2a_convert_A_const_65 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[376]); A_arbace_g2a_convert_A_const_66 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[377]); A_arbace_g2a_convert_A_const_67 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[378]); A_arbace_g2a_convert_A_const_68 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[379]); A_arbace_g2a_convert_A_const_69 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[380]); A_arbace_g2a_convert_A_const_70 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[381]); A_arbace_g2a_convert_A_const_71 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[382]) }

func A_arbace_g2a_convert_A_clinit_p6() { A_arbace_g2a_convert_A_const_72 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[383]); A_arbace_g2a_convert_A_const_73 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[384]); A_arbace_g2a_convert_A_const_74 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[385]); A_arbace_g2a_convert_A_const_75 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[386]); A_arbace_g2a_convert_A_const_76 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[387]); A_arbace_g2a_convert_A_const_77 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[388]); A_arbace_g2a_convert_A_const_78 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[389]); A_arbace_g2a_convert_A_const_79 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[390]); A_arbace_g2a_convert_A_const_80 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[391]); A_arbace_g2a_convert_A_const_81 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[392]); A_arbace_g2a_convert_A_const_82 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[393]); A_arbace_g2a_convert_A_const_83 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[394]) }

func A_arbace_g2a_convert_A_clinit_p7() { A_arbace_g2a_convert_A_const_84 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[395]); A_arbace_g2a_convert_A_const_85 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[396]); A_arbace_g2a_convert_A_const_86 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[397]); A_arbace_g2a_convert_A_const_87 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[398]); A_arbace_g2a_convert_A_const_88 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[399]); A_arbace_g2a_convert_A_const_89 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[400]); A_arbace_g2a_convert_A_const_90 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[401]); A_arbace_g2a_convert_A_const_91 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[402]); A_arbace_g2a_convert_A_const_92 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[403]); A_arbace_g2a_convert_A_const_93 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[404]); A_arbace_g2a_convert_A_const_94 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[405]); A_arbace_g2a_convert_A_const_95 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[406]) }

func A_arbace_g2a_convert_A_clinit_p8() { A_arbace_g2a_convert_A_const_96 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[407]); A_arbace_g2a_convert_A_const_97 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[408]); A_arbace_g2a_convert_A_const_98 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[409]); A_arbace_g2a_convert_A_const_99 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[410]); A_arbace_g2a_convert_A_const_100 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[411]); A_arbace_g2a_convert_A_const_101 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[412]); A_arbace_g2a_convert_A_const_102 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[413]); A_arbace_g2a_convert_A_const_103 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[414]); A_arbace_g2a_convert_A_const_104 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[415]); A_arbace_g2a_convert_A_const_105 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[416]); A_arbace_g2a_convert_A_const_106 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[417]); A_arbace_g2a_convert_A_const_107 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[418]) }

func A_arbace_g2a_convert_A_clinit_p9() { A_arbace_g2a_convert_A_const_108 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[419]); A_arbace_g2a_convert_A_const_109 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[420]); A_arbace_g2a_convert_A_const_110 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[421]); A_arbace_g2a_convert_A_const_111 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[422]); A_arbace_g2a_convert_A_const_112 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[423]); A_arbace_g2a_convert_A_const_113 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[424]); A_arbace_g2a_convert_A_const_114 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[425]); A_arbace_g2a_convert_A_const_115 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[426]); A_arbace_g2a_convert_A_const_116 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[427]); A_arbace_g2a_convert_A_const_117 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[428]); A_arbace_g2a_convert_A_const_118 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[429]); A_arbace_g2a_convert_A_const_119 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[430]) }

func A_arbace_g2a_convert_A_clinit_p10() { A_arbace_g2a_convert_A_const_120 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[431]); A_arbace_g2a_convert_A_const_121 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[432]); A_arbace_g2a_convert_A_const_122 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[433]); A_arbace_g2a_convert_A_const_123 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[434]); A_arbace_g2a_convert_A_const_124 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[435]); A_arbace_g2a_convert_A_const_125 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[436]); A_arbace_g2a_convert_A_const_126 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[437]); A_arbace_g2a_convert_A_const_127 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[438]); A_arbace_g2a_convert_A_const_128 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[439]); A_arbace_g2a_convert_A_const_129 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[440]); A_arbace_g2a_convert_A_const_130 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[441]); A_arbace_g2a_convert_A_const_131 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[442]) }

func A_arbace_g2a_convert_A_clinit_p11() { A_arbace_g2a_convert_A_const_132 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[443]); A_arbace_g2a_convert_A_const_133 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[444]); A_arbace_g2a_convert_A_const_134 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[445]); A_arbace_g2a_convert_A_const_135 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[446]); A_arbace_g2a_convert_A_const_136 = A_arbace_g2a_convert_A_const_pool.A[447]; A_arbace_g2a_convert_A_const_137 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[448]); A_arbace_g2a_convert_A_const_138 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[449]); A_arbace_g2a_convert_A_const_139 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[450]); A_arbace_g2a_convert_A_const_140 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[451]); A_arbace_g2a_convert_A_const_141 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[452]); A_arbace_g2a_convert_A_const_142 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[453]); A_arbace_g2a_convert_A_const_143 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[454]) }

func A_arbace_g2a_convert_A_clinit_p12() { A_arbace_g2a_convert_A_const_144 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[455]); A_arbace_g2a_convert_A_const_145 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[456]); A_arbace_g2a_convert_A_const_146 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[457]); A_arbace_g2a_convert_A_const_147 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[458]); A_arbace_g2a_convert_A_const_148 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[459]); A_arbace_g2a_convert_A_const_149 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[460]); A_arbace_g2a_convert_A_const_150 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[461]); A_arbace_g2a_convert_A_const_151 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[462]); A_arbace_g2a_convert_A_const_152 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[463]); A_arbace_g2a_convert_A_const_153 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[464]); A_arbace_g2a_convert_A_const_154 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[465]); A_arbace_g2a_convert_A_const_155 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[466]) }

func A_arbace_g2a_convert_A_clinit_p13() { A_arbace_g2a_convert_A_const_156 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[467]); A_arbace_g2a_convert_A_const_157 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[468]); A_arbace_g2a_convert_A_const_158 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[469]); A_arbace_g2a_convert_A_const_159 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[470]); A_arbace_g2a_convert_A_const_160 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[471]); A_arbace_g2a_convert_A_const_161 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[472]); A_arbace_g2a_convert_A_const_162 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[473]); A_arbace_g2a_convert_A_const_163 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[474]); A_arbace_g2a_convert_A_const_164 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[475]); A_arbace_g2a_convert_A_const_165 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[476]); A_arbace_g2a_convert_A_const_166 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[477]); A_arbace_g2a_convert_A_const_167 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[478]) }

func A_arbace_g2a_convert_A_clinit_p14() { A_arbace_g2a_convert_A_const_168 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[479]); A_arbace_g2a_convert_A_const_169 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[480]); A_arbace_g2a_convert_A_const_170 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[481]); A_arbace_g2a_convert_A_const_171 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[482]); A_arbace_g2a_convert_A_const_172 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[483]); A_arbace_g2a_convert_A_const_173 = A_arbace_g2a_convert_A_const_pool.A[484]; A_arbace_g2a_convert_A_const_174 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[485]); A_arbace_g2a_convert_A_const_175 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[486]); A_arbace_g2a_convert_A_const_176 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[487]); A_arbace_g2a_convert_A_const_177 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[488]); A_arbace_g2a_convert_A_const_178 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[489]); A_arbace_g2a_convert_A_const_179 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[490]) }

func A_arbace_g2a_convert_A_clinit_p15() { A_arbace_g2a_convert_A_const_180 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[491]); A_arbace_g2a_convert_A_const_181 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[492]); A_arbace_g2a_convert_A_const_182 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[493]); A_arbace_g2a_convert_A_const_183 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[494]); A_arbace_g2a_convert_A_const_184 = A_arbace_g2a_convert_A_const_pool.A[495]; A_arbace_g2a_convert_A_const_185 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[496]); A_arbace_g2a_convert_A_const_186 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[497]); A_arbace_g2a_convert_A_const_187 = A_arbace_g2a_convert_A_const_pool.A[498]; A_arbace_g2a_convert_A_const_188 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[499]); A_arbace_g2a_convert_A_const_189 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[500]); A_arbace_g2a_convert_A_const_190 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[501]); A_arbace_g2a_convert_A_const_191 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[502]) }

func A_arbace_g2a_convert_A_clinit_p16() { A_arbace_g2a_convert_A_const_192 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[503]); A_arbace_g2a_convert_A_const_193 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[504]); A_arbace_g2a_convert_A_const_194 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[505]); A_arbace_g2a_convert_A_const_195 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[506]); A_arbace_g2a_convert_A_const_196 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[507]); A_arbace_g2a_convert_A_const_197 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[508]); A_arbace_g2a_convert_A_const_198 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[509]); A_arbace_g2a_convert_A_const_199 = A_arbace_g2a_convert_A_const_pool.A[510]; A_arbace_g2a_convert_A_const_200 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[511]); A_arbace_g2a_convert_A_const_201 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[512]); A_arbace_g2a_convert_A_const_202 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[513]); A_arbace_g2a_convert_A_const_203 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[514]) }

func A_arbace_g2a_convert_A_clinit_p17() { A_arbace_g2a_convert_A_const_204 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[515]); A_arbace_g2a_convert_A_const_205 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[516]); A_arbace_g2a_convert_A_const_206 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[517]); A_arbace_g2a_convert_A_const_207 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[518]); A_arbace_g2a_convert_A_const_208 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[519]); A_arbace_g2a_convert_A_const_209 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[520]); A_arbace_g2a_convert_A_const_210 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[521]); A_arbace_g2a_convert_A_const_211 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[522]); A_arbace_g2a_convert_A_const_212 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[523]); A_arbace_g2a_convert_A_const_213 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[524]); A_arbace_g2a_convert_A_const_214 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[525]); A_arbace_g2a_convert_A_const_215 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[526]) }

func A_arbace_g2a_convert_A_clinit_p18() { A_arbace_g2a_convert_A_const_216 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[527]); A_arbace_g2a_convert_A_const_217 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[528]); A_arbace_g2a_convert_A_const_218 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[529]); A_arbace_g2a_convert_A_const_219 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[530]); A_arbace_g2a_convert_A_const_220 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[531]); A_arbace_g2a_convert_A_const_221 = A_arbace_g2a_convert_A_const_pool.A[532]; A_arbace_g2a_convert_A_const_222 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[533]); A_arbace_g2a_convert_A_const_223 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[534]); A_arbace_g2a_convert_A_const_224 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[535]); A_arbace_g2a_convert_A_const_225 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[536]); A_arbace_g2a_convert_A_const_226 = A_arbace_g2a_convert_A_const_pool.A[537]; A_arbace_g2a_convert_A_const_227 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[538]) }

func A_arbace_g2a_convert_A_clinit_p19() { A_arbace_g2a_convert_A_const_228 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[539]); A_arbace_g2a_convert_A_const_229 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[540]); A_arbace_g2a_convert_A_const_230 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[541]); A_arbace_g2a_convert_A_const_231 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[542]); A_arbace_g2a_convert_A_const_232 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[543]); A_arbace_g2a_convert_A_const_233 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[544]); A_arbace_g2a_convert_A_const_234 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[545]); A_arbace_g2a_convert_A_const_235 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[546]); A_arbace_g2a_convert_A_const_236 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[547]); A_arbace_g2a_convert_A_const_237 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[548]); A_arbace_g2a_convert_A_const_238 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[549]); A_arbace_g2a_convert_A_const_239 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[550]) }

func A_arbace_g2a_convert_A_clinit_p20() { A_arbace_g2a_convert_A_const_240 = A_arbace_g2a_convert_A_const_pool.A[551]; A_arbace_g2a_convert_A_const_241 = A_arbace_g2a_convert_A_const_pool.A[552]; A_arbace_g2a_convert_A_const_242 = A_arbace_g2a_convert_A_const_pool.A[553]; A_arbace_g2a_convert_A_const_243 = A_arbace_g2a_convert_A_const_pool.A[554]; A_arbace_g2a_convert_A_const_244 = A_arbace_g2a_convert_A_const_pool.A[555]; A_arbace_g2a_convert_A_const_245 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[556]); A_arbace_g2a_convert_A_const_246 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[557]); A_arbace_g2a_convert_A_const_247 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[558]); A_arbace_g2a_convert_A_const_248 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[559]); A_arbace_g2a_convert_A_const_249 = A_arbace_g2a_convert_A_const_pool.A[560]; A_arbace_g2a_convert_A_const_250 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[561]); A_arbace_g2a_convert_A_const_251 = A_arbace_g2a_convert_A_const_pool.A[562]; A_arbace_g2a_convert_A_const_252 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[563]) }

func A_arbace_g2a_convert_A_clinit_p21() { A_arbace_g2a_convert_A_const_253 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[564]); A_arbace_g2a_convert_A_const_254 = A_arbace_g2a_convert_A_const_pool.A[565]; A_arbace_g2a_convert_A_const_255 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[566]); A_arbace_g2a_convert_A_const_256 = A_arbace_g2a_convert_A_const_pool.A[567]; A_arbace_g2a_convert_A_const_257 = A_arbace_g2a_convert_A_const_pool.A[568]; A_arbace_g2a_convert_A_const_258 = A_arbace_g2a_convert_A_const_pool.A[569]; A_arbace_g2a_convert_A_const_259 = A_arbace_g2a_convert_A_const_pool.A[570]; A_arbace_g2a_convert_A_const_260 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[571]); A_arbace_g2a_convert_A_const_261 = A_arbace_g2a_convert_A_const_pool.A[572]; A_arbace_g2a_convert_A_const_262 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[573]); A_arbace_g2a_convert_A_const_263 = A_arbace_g2a_convert_A_const_pool.A[574]; A_arbace_g2a_convert_A_const_264 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[575]); A_arbace_g2a_convert_A_const_265 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[576]); A_arbace_g2a_convert_A_const_266 = A_arbace_g2a_convert_A_const_pool.A[577] }

func A_arbace_g2a_convert_A_clinit_p22() { A_arbace_g2a_convert_A_const_267 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[578]); A_arbace_g2a_convert_A_const_268 = A_arbace_g2a_convert_A_const_pool.A[579]; A_arbace_g2a_convert_A_const_269 = A_arbace_g2a_convert_A_const_pool.A[580]; A_arbace_g2a_convert_A_const_270 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[581]); A_arbace_g2a_convert_A_const_271 = A_arbace_g2a_convert_A_const_pool.A[582]; A_arbace_g2a_convert_A_const_272 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[583]); A_arbace_g2a_convert_A_const_273 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[584]); A_arbace_g2a_convert_A_const_274 = A_arbace_g2a_convert_A_const_pool.A[585]; A_arbace_g2a_convert_A_const_275 = A_arbace_g2a_convert_A_const_pool.A[586]; A_arbace_g2a_convert_A_const_276 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[587]); A_arbace_g2a_convert_A_const_277 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[588]); A_arbace_g2a_convert_A_const_278 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[589]); A_arbace_g2a_convert_A_const_279 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[590]) }

func A_arbace_g2a_convert_A_clinit_p23() { A_arbace_g2a_convert_A_const_280 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[591]); A_arbace_g2a_convert_A_const_281 = A_arbace_g2a_convert_A_const_pool.A[592]; A_arbace_g2a_convert_A_const_282 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[593]); A_arbace_g2a_convert_A_const_283 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[594]); A_arbace_g2a_convert_A_const_284 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[595]); A_arbace_g2a_convert_A_const_285 = A_arbace_g2a_convert_A_const_pool.A[596]; A_arbace_g2a_convert_A_const_286 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[597]); A_arbace_g2a_convert_A_const_287 = A_arbace_g2a_convert_A_const_pool.A[598]; A_arbace_g2a_convert_A_const_288 = A_arbace_g2a_convert_A_const_pool.A[599]; A_arbace_g2a_convert_A_const_289 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[600]); A_arbace_g2a_convert_A_const_290 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[601]); A_arbace_g2a_convert_A_const_291 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[602]); A_arbace_g2a_convert_A_const_292 = A_arbace_g2a_convert_A_const_pool.A[603] }

func A_arbace_g2a_convert_A_clinit_p24() { A_arbace_g2a_convert_A_const_293 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[604]); A_arbace_g2a_convert_A_const_294 = A_arbace_g2a_convert_A_const_pool.A[605]; A_arbace_g2a_convert_A_const_295 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[606]); A_arbace_g2a_convert_A_const_296 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[607]); A_arbace_g2a_convert_A_const_297 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[608]); A_arbace_g2a_convert_A_const_298 = A_arbace_g2a_convert_A_const_pool.A[609]; A_arbace_g2a_convert_A_const_299 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[610]); A_arbace_g2a_convert_A_const_300 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[611]); A_arbace_g2a_convert_A_const_301 = A_arbace_g2a_convert_A_const_pool.A[612]; A_arbace_g2a_convert_A_const_302 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[613]); A_arbace_g2a_convert_A_const_303 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[614]); A_arbace_g2a_convert_A_const_304 = A_arbace_g2a_convert_A_const_pool.A[615]; A_arbace_g2a_convert_A_const_305 = A_arbace_g2a_convert_A_const_pool.A[616] }

func A_arbace_g2a_convert_A_clinit_p25() { A_arbace_g2a_convert_A_const_306 = A_arbace_g2a_convert_A_const_pool.A[617]; A_arbace_g2a_convert_A_const_307 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[618]); A_arbace_g2a_convert_A_const_308 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[619]); A_arbace_g2a_convert_A_const_309 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[620]); A_arbace_g2a_convert_A_const_310 = A_arbace_g2a_convert_A_const_pool.A[621]; A_arbace_g2a_convert_A_const_311 = A_arbace_g2a_convert_A_const_pool.A[622]; A_arbace_g2a_convert_A_const_312 = A_arbace_g2a_convert_A_const_pool.A[623]; A_arbace_g2a_convert_A_const_313 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[624]); A_arbace_g2a_convert_A_const_314 = A_arbace_g2a_convert_A_const_pool.A[625]; A_arbace_g2a_convert_A_const_315 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[626]); A_arbace_g2a_convert_A_const_316 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[627]); A_arbace_g2a_convert_A_const_317 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[628]); A_arbace_g2a_convert_A_const_318 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[629]) }

func A_arbace_g2a_convert_A_clinit_p26() { A_arbace_g2a_convert_A_const_319 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[630]); A_arbace_g2a_convert_A_const_320 = A_arbace_g2a_convert_A_const_pool.A[631]; A_arbace_g2a_convert_A_const_321 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[632]); A_arbace_g2a_convert_A_const_322 = A_arbace_g2a_convert_A_const_pool.A[633]; A_arbace_g2a_convert_A_const_323 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[634]); A_arbace_g2a_convert_A_const_324 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[635]); A_arbace_g2a_convert_A_const_325 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[636]); A_arbace_g2a_convert_A_const_326 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[637]); A_arbace_g2a_convert_A_const_327 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[638]); A_arbace_g2a_convert_A_const_328 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[639]); A_arbace_g2a_convert_A_const_329 = A_arbace_g2a_convert_A_const_pool.A[640]; A_arbace_g2a_convert_A_const_330 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[641]) }

func A_arbace_g2a_convert_A_clinit_p27() { A_arbace_g2a_convert_A_const_331 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[642]); A_arbace_g2a_convert_A_const_332 = A_arbace_g2a_convert_A_const_pool.A[643]; A_arbace_g2a_convert_A_const_333 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[644]); A_arbace_g2a_convert_A_const_334 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[645]); A_arbace_g2a_convert_A_const_335 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[646]); A_arbace_g2a_convert_A_const_336 = A_arbace_g2a_convert_A_const_pool.A[647]; A_arbace_g2a_convert_A_const_337 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[648]); A_arbace_g2a_convert_A_const_338 = A_arbace_g2a_convert_A_const_pool.A[649]; A_arbace_g2a_convert_A_const_339 = A_arbace_g2a_convert_A_const_pool.A[650]; A_arbace_g2a_convert_A_const_340 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[651]); A_arbace_g2a_convert_A_const_341 = A_arbace_g2a_convert_A_const_pool.A[652]; A_arbace_g2a_convert_A_const_342 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[653]); A_arbace_g2a_convert_A_const_343 = A_arbace_g2a_convert_A_const_pool.A[654] }

func A_arbace_g2a_convert_A_clinit_p28() { A_arbace_g2a_convert_A_const_344 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[655]); A_arbace_g2a_convert_A_const_345 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[656]); A_arbace_g2a_convert_A_const_346 = A_arbace_g2a_convert_A_const_pool.A[657]; A_arbace_g2a_convert_A_const_347 = A_arbace_g2a_convert_A_const_pool.A[658]; A_arbace_g2a_convert_A_const_348 = A_arbace_g2a_convert_A_const_pool.A[659]; A_arbace_g2a_convert_A_const_349 = A_arbace_g2a_convert_A_const_pool.A[660]; A_arbace_g2a_convert_A_const_350 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[661]); A_arbace_g2a_convert_A_const_351 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[662]); A_arbace_g2a_convert_A_const_352 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[663]); A_arbace_g2a_convert_A_const_353 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[664]); A_arbace_g2a_convert_A_const_354 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[665]); A_arbace_g2a_convert_A_const_355 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[666]); A_arbace_g2a_convert_A_const_356 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[667]) }

func A_arbace_g2a_convert_A_clinit_p29() { A_arbace_g2a_convert_A_const_357 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[668]); A_arbace_g2a_convert_A_const_358 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[669]); A_arbace_g2a_convert_A_const_359 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[670]); A_arbace_g2a_convert_A_const_360 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[671]); A_arbace_g2a_convert_A_const_361 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[672]); A_arbace_g2a_convert_A_const_362 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[673]); A_arbace_g2a_convert_A_const_363 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[674]); A_arbace_g2a_convert_A_const_364 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[675]); A_arbace_g2a_convert_A_const_365 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[676]); A_arbace_g2a_convert_A_const_366 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[677]); A_arbace_g2a_convert_A_const_367 = A_arbace_g2a_convert_A_const_pool.A[678]; A_arbace_g2a_convert_A_const_368 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[679]) }

func A_arbace_g2a_convert_A_clinit_p30() { A_arbace_g2a_convert_A_const_369 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[680]); A_arbace_g2a_convert_A_const_370 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[681]); A_arbace_g2a_convert_A_const_371 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[682]); A_arbace_g2a_convert_A_const_372 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[683]); A_arbace_g2a_convert_A_const_373 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[684]); A_arbace_g2a_convert_A_const_374 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[685]); A_arbace_g2a_convert_A_const_375 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[686]); A_arbace_g2a_convert_A_const_376 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[687]); A_arbace_g2a_convert_A_const_377 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[688]); A_arbace_g2a_convert_A_const_378 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[689]); A_arbace_g2a_convert_A_const_379 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[690]); A_arbace_g2a_convert_A_const_380 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[691]) }

func A_arbace_g2a_convert_A_clinit_p31() { A_arbace_g2a_convert_A_const_381 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[692]); A_arbace_g2a_convert_A_const_382 = A_arbace_g2a_convert_A_const_pool.A[693]; A_arbace_g2a_convert_A_const_383 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[694]); A_arbace_g2a_convert_A_const_384 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[695]); A_arbace_g2a_convert_A_const_385 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[696]); A_arbace_g2a_convert_A_const_386 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[697]); A_arbace_g2a_convert_A_const_387 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[698]); A_arbace_g2a_convert_A_const_388 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[699]); A_arbace_g2a_convert_A_const_389 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[700]); A_arbace_g2a_convert_A_const_390 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[701]); A_arbace_g2a_convert_A_const_391 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[702]); A_arbace_g2a_convert_A_const_392 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[703]) }

func A_arbace_g2a_convert_A_clinit_p32() { A_arbace_g2a_convert_A_const_393 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[704]); A_arbace_g2a_convert_A_const_394 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[705]); A_arbace_g2a_convert_A_const_395 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[706]); A_arbace_g2a_convert_A_const_396 = A_arbace_g2a_convert_A_const_pool.A[707]; A_arbace_g2a_convert_A_const_397 = A_arbace_g2a_convert_A_const_pool.A[708]; A_arbace_g2a_convert_A_const_398 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[709]); A_arbace_g2a_convert_A_const_399 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[710]); A_arbace_g2a_convert_A_const_400 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[711]); A_arbace_g2a_convert_A_const_401 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[712]); A_arbace_g2a_convert_A_const_402 = A_arbace_g2a_convert_A_const_pool.A[713]; A_arbace_g2a_convert_A_const_403 = A_arbace_g2a_convert_A_const_pool.A[714]; A_arbace_g2a_convert_A_const_404 = A_arbace_g2a_convert_A_const_pool.A[715]; A_arbace_g2a_convert_A_const_405 = A_arbace_g2a_convert_A_const_pool.A[716] }

func A_arbace_g2a_convert_A_clinit_p33() { A_arbace_g2a_convert_A_const_406 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[717]); A_arbace_g2a_convert_A_const_407 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[718]); A_arbace_g2a_convert_A_const_408 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[719]); A_arbace_g2a_convert_A_const_409 = A_arbace_g2a_convert_A_const_pool.A[720]; A_arbace_g2a_convert_A_const_410 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[721]); A_arbace_g2a_convert_A_const_411 = A_arbace_g2a_convert_A_const_pool.A[722]; A_arbace_g2a_convert_A_const_412 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[723]); A_arbace_g2a_convert_A_const_413 = A_arbace_g2a_convert_A_const_pool.A[724]; A_arbace_g2a_convert_A_const_414 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[725]); A_arbace_g2a_convert_A_const_415 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[726]); A_arbace_g2a_convert_A_const_416 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[727]); A_arbace_g2a_convert_A_const_417 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[728]); A_arbace_g2a_convert_A_const_418 = A_arbace_g2a_convert_A_const_pool.A[729] }

func A_arbace_g2a_convert_A_clinit_p34() { A_arbace_g2a_convert_A_const_419 = A_arbace_g2a_convert_A_const_pool.A[730]; A_arbace_g2a_convert_A_const_420 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[731]); A_arbace_g2a_convert_A_const_421 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[732]); A_arbace_g2a_convert_A_const_422 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[733]); A_arbace_g2a_convert_A_const_423 = A_arbace_g2a_convert_A_const_pool.A[734]; A_arbace_g2a_convert_A_const_424 = A_arbace_g2a_convert_A_const_pool.A[735]; A_arbace_g2a_convert_A_const_425 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[736]); A_arbace_g2a_convert_A_const_426 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[737]); A_arbace_g2a_convert_A_const_427 = A_arbace_g2a_convert_A_const_pool.A[738]; A_arbace_g2a_convert_A_const_428 = A_arbace_g2a_convert_A_const_pool.A[739]; A_arbace_g2a_convert_A_const_429 = A_arbace_g2a_convert_A_const_pool.A[740]; A_arbace_g2a_convert_A_const_430 = A_arbace_g2a_convert_A_const_pool.A[741]; A_arbace_g2a_convert_A_const_431 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[742]); A_arbace_g2a_convert_A_const_432 = A_arbace_g2a_convert_A_const_pool.A[743] }

func A_arbace_g2a_convert_A_clinit_p35() { A_arbace_g2a_convert_A_const_433 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[744]); A_arbace_g2a_convert_A_const_434 = A_arbace_g2a_convert_A_const_pool.A[745]; A_arbace_g2a_convert_A_const_435 = A_arbace_g2a_convert_A_const_pool.A[746]; A_arbace_g2a_convert_A_const_436 = A_arbace_g2a_convert_A_const_pool.A[747]; A_arbace_g2a_convert_A_const_437 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[748]); A_arbace_g2a_convert_A_const_438 = A_arbace_g2a_convert_A_const_pool.A[749]; A_arbace_g2a_convert_A_const_439 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[750]); A_arbace_g2a_convert_A_const_440 = A_arbace_g2a_convert_A_const_pool.A[751]; A_arbace_g2a_convert_A_const_441 = A_arbace_g2a_convert_A_const_pool.A[752]; A_arbace_g2a_convert_A_const_442 = A_arbace_g2a_convert_A_const_pool.A[753]; A_arbace_g2a_convert_A_const_443 = A_arbace_g2a_convert_A_const_pool.A[754]; A_arbace_g2a_convert_A_const_444 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[755]); A_arbace_g2a_convert_A_const_445 = A_arbace_g2a_convert_A_const_pool.A[756]; A_arbace_g2a_convert_A_const_446 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[757]) }

func A_arbace_g2a_convert_A_clinit_p36() { A_arbace_g2a_convert_A_const_447 = A_arbace_g2a_convert_A_const_pool.A[758]; A_arbace_g2a_convert_A_const_448 = A_arbace_g2a_convert_A_const_pool.A[759]; A_arbace_g2a_convert_A_const_449 = A_arbace_g2a_convert_A_const_pool.A[760]; A_arbace_g2a_convert_A_const_450 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[761]); A_arbace_g2a_convert_A_const_451 = A_arbace_g2a_convert_A_const_pool.A[762]; A_arbace_g2a_convert_A_const_452 = A_arbace_g2a_convert_A_const_pool.A[763]; A_arbace_g2a_convert_A_const_453 = A_arbace_g2a_convert_A_const_pool.A[764]; A_arbace_g2a_convert_A_const_454 = A_arbace_g2a_convert_A_const_pool.A[765]; A_arbace_g2a_convert_A_const_455 = A_arbace_g2a_convert_A_const_pool.A[766]; A_arbace_g2a_convert_A_const_456 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[767]); A_arbace_g2a_convert_A_const_457 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[768]); A_arbace_g2a_convert_A_const_458 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[769]); A_arbace_g2a_convert_A_const_459 = A_arbace_g2a_convert_A_const_pool.A[770]; A_arbace_g2a_convert_A_const_460 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[771]) }

func A_arbace_g2a_convert_A_clinit_p37() { A_arbace_g2a_convert_A_const_461 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[772]); A_arbace_g2a_convert_A_const_462 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[773]); A_arbace_g2a_convert_A_const_463 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[774]); A_arbace_g2a_convert_A_const_464 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[775]); A_arbace_g2a_convert_A_const_465 = A_arbace_g2a_convert_A_const_pool.A[776]; A_arbace_g2a_convert_A_const_466 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[777]); A_arbace_g2a_convert_A_const_467 = A_arbace_g2a_convert_A_const_pool.A[778]; A_arbace_g2a_convert_A_const_468 = A_arbace_g2a_convert_A_const_pool.A[779]; A_arbace_g2a_convert_A_const_469 = A_arbace_g2a_convert_A_const_pool.A[780]; A_arbace_g2a_convert_A_const_470 = A_arbace_g2a_convert_A_const_pool.A[781]; A_arbace_g2a_convert_A_const_471 = A_arbace_g2a_convert_A_const_pool.A[782]; A_arbace_g2a_convert_A_const_472 = A_arbace_g2a_convert_A_const_pool.A[783]; A_arbace_g2a_convert_A_const_473 = A_arbace_g2a_convert_A_const_pool.A[784]; A_arbace_g2a_convert_A_const_474 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[785]) }

func A_arbace_g2a_convert_A_clinit_p38() { A_arbace_g2a_convert_A_const_475 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[786]); A_arbace_g2a_convert_A_const_476 = A_arbace_g2a_convert_A_const_pool.A[787]; A_arbace_g2a_convert_A_const_477 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[788]); A_arbace_g2a_convert_A_const_478 = A_arbace_g2a_convert_A_const_pool.A[789]; A_arbace_g2a_convert_A_const_479 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[790]); A_arbace_g2a_convert_A_const_480 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[791]); A_arbace_g2a_convert_A_const_481 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[792]); A_arbace_g2a_convert_A_const_482 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[793]); A_arbace_g2a_convert_A_const_483 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[794]); A_arbace_g2a_convert_A_const_484 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[795]); A_arbace_g2a_convert_A_const_485 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[796]); A_arbace_g2a_convert_A_const_486 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[797]) }

func A_arbace_g2a_convert_A_clinit_p39() { A_arbace_g2a_convert_A_const_487 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[798]); A_arbace_g2a_convert_A_const_488 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[799]); A_arbace_g2a_convert_A_const_489 = A_arbace_g2a_convert_A_const_pool.A[800]; A_arbace_g2a_convert_A_const_490 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[801]); A_arbace_g2a_convert_A_const_491 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[802]); A_arbace_g2a_convert_A_const_492 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[803]); A_arbace_g2a_convert_A_const_493 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[804]); A_arbace_g2a_convert_A_const_494 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[805]); A_arbace_g2a_convert_A_const_495 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[806]); A_arbace_g2a_convert_A_const_496 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[807]); A_arbace_g2a_convert_A_const_497 = A_arbace_g2a_convert_A_const_pool.A[808]; A_arbace_g2a_convert_A_const_498 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[809]) }

func A_arbace_g2a_convert_A_clinit_p40() { A_arbace_g2a_convert_A_const_499 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[810]); A_arbace_g2a_convert_A_const_500 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[811]); A_arbace_g2a_convert_A_const_501 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[812]); A_arbace_g2a_convert_A_const_502 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[813]); A_arbace_g2a_convert_A_const_503 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[814]); A_arbace_g2a_convert_A_const_504 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[815]); A_arbace_g2a_convert_A_const_505 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[816]); A_arbace_g2a_convert_A_const_506 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[817]); A_arbace_g2a_convert_A_const_507 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[818]); A_arbace_g2a_convert_A_const_508 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[819]); A_arbace_g2a_convert_A_const_509 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[820]); A_arbace_g2a_convert_A_const_510 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[821]) }

func A_arbace_g2a_convert_A_clinit_p41() { A_arbace_g2a_convert_A_const_511 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[822]); A_arbace_g2a_convert_A_const_512 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[823]); A_arbace_g2a_convert_A_const_513 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[824]); A_arbace_g2a_convert_A_const_514 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[825]); A_arbace_g2a_convert_A_const_515 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[826]); A_arbace_g2a_convert_A_const_516 = A_arbace_g2a_convert_A_const_pool.A[827]; A_arbace_g2a_convert_A_const_517 = A_arbace_g2a_convert_A_const_pool.A[828]; A_arbace_g2a_convert_A_const_518 = A_arbace_g2a_convert_A_const_pool.A[829]; A_arbace_g2a_convert_A_const_519 = A_arbace_g2a_convert_A_const_pool.A[830]; A_arbace_g2a_convert_A_const_520 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[831]); A_arbace_g2a_convert_A_const_521 = A_arbace_g2a_convert_A_const_pool.A[832]; A_arbace_g2a_convert_A_const_522 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[833]); A_arbace_g2a_convert_A_const_523 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[834]) }

func A_arbace_g2a_convert_A_clinit_p42() { A_arbace_g2a_convert_A_const_524 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[835]); A_arbace_g2a_convert_A_const_525 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[836]); A_arbace_g2a_convert_A_const_526 = A_arbace_g2a_convert_A_const_pool.A[837]; A_arbace_g2a_convert_A_const_527 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[838]); A_arbace_g2a_convert_A_const_528 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[839]); A_arbace_g2a_convert_A_const_529 = A_arbace_g2a_convert_A_const_pool.A[840]; A_arbace_g2a_convert_A_const_530 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[841]); A_arbace_g2a_convert_A_const_531 = A_arbace_g2a_convert_A_const_pool.A[842]; A_arbace_g2a_convert_A_const_532 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[843]); A_arbace_g2a_convert_A_const_533 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[844]); A_arbace_g2a_convert_A_const_534 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[845]); A_arbace_g2a_convert_A_const_535 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[846]) }

func A_arbace_g2a_convert_A_clinit_p43() { A_arbace_g2a_convert_A_const_536 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[847]); A_arbace_g2a_convert_A_const_537 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[848]); A_arbace_g2a_convert_A_const_538 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[849]); A_arbace_g2a_convert_A_const_539 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[850]); A_arbace_g2a_convert_A_const_540 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[851]); A_arbace_g2a_convert_A_const_541 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[852]); A_arbace_g2a_convert_A_const_542 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[853]); A_arbace_g2a_convert_A_const_543 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[854]); A_arbace_g2a_convert_A_const_544 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[855]); A_arbace_g2a_convert_A_const_545 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[856]); A_arbace_g2a_convert_A_const_546 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[857]); A_arbace_g2a_convert_A_const_547 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[858]) }

func A_arbace_g2a_convert_A_clinit_p44() { A_arbace_g2a_convert_A_const_548 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[859]); A_arbace_g2a_convert_A_const_549 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[860]); A_arbace_g2a_convert_A_const_550 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[861]); A_arbace_g2a_convert_A_const_551 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[862]); A_arbace_g2a_convert_A_const_552 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[863]); A_arbace_g2a_convert_A_const_553 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[864]); A_arbace_g2a_convert_A_const_554 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[865]); A_arbace_g2a_convert_A_const_555 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[866]); A_arbace_g2a_convert_A_const_556 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[867]); A_arbace_g2a_convert_A_const_557 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[868]); A_arbace_g2a_convert_A_const_558 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[869]); A_arbace_g2a_convert_A_const_559 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[870]) }

func A_arbace_g2a_convert_A_clinit_p45() { A_arbace_g2a_convert_A_const_560 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[871]); A_arbace_g2a_convert_A_const_561 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[872]); A_arbace_g2a_convert_A_const_562 = lang.Keyword_Cast(A_arbace_g2a_convert_A_const_pool.A[873]); A_arbace_g2a_convert_A_const_563 = lang.Var_Cast(A_arbace_g2a_convert_A_const_pool.A[874]); A_arbace_g2a_convert_A_const_564 = A_arbace_g2a_convert_A_const_pool.A[875]; A_arbace_g2a_convert_A_const_565 = A_arbace_g2a_convert_A_const_pool.A[876]; A_arbace_g2a_convert_A_const_566 = A_arbace_g2a_convert_A_const_pool.A[877]; A_arbace_g2a_convert_A_const_567 = A_arbace_g2a_convert_A_const_pool.A[878] }

func A_arbace_g2a_convert_A_New() *A_arbace_g2a_convert_A { A_arbace_g2a_convert_A_Init(); t := &A_arbace_g2a_convert_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_convert_A) Ctor() {}

func (t *A_arbace_g2a_convert_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_convert_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_convert_A_class }

func (t *A_arbace_g2a_convert_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_convert_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_convert_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_convert_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_convert_A); return ok }

func A_arbace_g2a_convert_A_Cast(x any) *A_arbace_g2a_convert_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_convert_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_convert_A_class)) }; return v }



type A_arbace_g2a_convert_add_meta_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_add_meta_A_fn_class *jrt.Class



type A_arbace_g2a_convert_an_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_an_A_fn_class *jrt.Class



type A_arbace_g2a_convert_as_inst_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_as_inst_A_fn_class *jrt.Class



type A_arbace_g2a_convert_assign_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_assign_A_fn_class *jrt.Class



type A_arbace_g2a_convert_at_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_at_A_fn_class *jrt.Class



type A_arbace_g2a_convert_at_fn__838000046_A struct{ a2g_header uint64; F_l, F_n any }

var A_arbace_g2a_convert_at_fn__838000046_A_fn_class *jrt.Class



type A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A struct{ a2g_header uint64; F_n any }

var A_arbace_g2a_convert_at_fn__838000046_fn__838000048_A_fn_class *jrt.Class



type A_arbace_g2a_convert_attachable_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_attachable_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_convert_basic_lit_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_basic_lit_A_fn_class *jrt.Class



type A_arbace_g2a_convert_bindings_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_bindings_of_A_fn_class *jrt.Class



type A_arbace_g2a_convert_block_forms_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_block_forms_A_fn_class *jrt.Class



type A_arbace_g2a_convert_block_pos_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_block_pos_A_fn_class *jrt.Class



type A_arbace_g2a_convert_branch_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_branch_A_fn_class *jrt.Class



type A_arbace_g2a_convert_builtin_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_builtin_name_A_fn_class *jrt.Class



type A_arbace_g2a_convert_call_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_call_A_fn_class *jrt.Class



type A_arbace_g2a_convert_call_fn__838000173_A struct{ a2g_header uint64; F_fun any }

var A_arbace_g2a_convert_call_fn__838000173_A_fn_class *jrt.Class



type A_arbace_g2a_convert_call_args_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_call_args_A_fn_class *jrt.Class



type A_arbace_g2a_convert_case_clause_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_case_clause_A_fn_class *jrt.Class



type A_arbace_g2a_convert_case_clause_fn__838000346_A struct{ a2g_header uint64; F_tswitch any }

var A_arbace_g2a_convert_case_clause_fn__838000346_A_fn_class *jrt.Class



type A_arbace_g2a_convert_clause_bound_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_clause_bound_A_fn_class *jrt.Class



type A_arbace_g2a_convert_clauses_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_clauses_A_fn_class *jrt.Class



type A_arbace_g2a_convert_clauses_fn__838000349_A struct{ a2g_header uint64; F_body, F_tswitch any }

var A_arbace_g2a_convert_clauses_fn__838000349_A_fn_class *jrt.Class



type A_arbace_g2a_convert_comm_clause_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_comm_clause_A_fn_class *jrt.Class



type A_arbace_g2a_convert_composite_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_composite_A_fn_class *jrt.Class



type A_arbace_g2a_convert_composite_fn__838000181_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_composite_fn__838000181_A_fn_class *jrt.Class



type A_arbace_g2a_convert_composite_fn__838000183_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_composite_fn__838000183_A_fn_class *jrt.Class



type A_arbace_g2a_convert_const_val_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_const_val_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_attach_meta__838000529_A struct{ a2g_header uint64; F_placed, F_plan any }

var A_arbace_g2a_convert_convert_file_attach_meta__838000529_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000531_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_attach_meta__838000529_fn__838000536_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000487_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000487_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000490_A struct{ a2g_header uint64; F_pkg_pos any }

var A_arbace_g2a_convert_convert_file_fn__838000490_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000496_A struct{ a2g_header uint64; F_pkg_pos any }

var A_arbace_g2a_convert_convert_file_fn__838000496_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000501_A struct{ a2g_header uint64; F_ranges any }

var A_arbace_g2a_convert_convert_file_fn__838000501_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000516_A struct{ a2g_header uint64; F_inside_of, F_ranges, F_last_import, F_decls any }

var A_arbace_g2a_convert_convert_file_fn__838000516_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A struct{ a2g_header uint64; F_l, F_c any }

var A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000520_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A struct{ a2g_header uint64; F_l, F_c any }

var A_arbace_g2a_convert_convert_file_fn__838000516_fn__838000523_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000539_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000539_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000541_A struct{ a2g_header uint64; F_placed any }

var A_arbace_g2a_convert_convert_file_fn__838000541_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000543_A struct{ a2g_header uint64; F_f, F_doc, F_name, F_dump, F_imports, F_fe, F_header, F_pkg_line any }

var A_arbace_g2a_convert_convert_file_fn__838000543_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000544_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000546_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000548_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000543_fn__838000550_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000554_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_fn__838000554_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000559_A struct{ a2g_header uint64; F_attach_meta, F_placed, F_plan, F_decls any }

var A_arbace_g2a_convert_convert_file_fn__838000559_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A struct{ a2g_header uint64; F_attach_meta, F_placed, F_plan any }

var A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A struct{ a2g_header uint64; F_placed any }

var A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000561_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A struct{ a2g_header uint64; F_k, F_attach_meta any }

var A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000560_fn__838000564_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A struct{ a2g_header uint64; F_placed any }

var A_arbace_g2a_convert_convert_file_fn__838000559_fn__838000567_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000571_A struct{ a2g_header uint64; F_placed any }

var A_arbace_g2a_convert_convert_file_fn__838000571_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000576_A struct{ a2g_header uint64; F_kept, F_dirs any }

var A_arbace_g2a_convert_convert_file_fn__838000576_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A struct{ a2g_header uint64; F_dirs any }

var A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A struct{ a2g_header uint64; F_l, F_c any }

var A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000586_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A struct{ a2g_header uint64; F_l any }

var A_arbace_g2a_convert_convert_file_fn__838000576_fn__838000578_fn__838000592_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_inside_of__838000504_A struct{ a2g_header uint64; F_ranges any }

var A_arbace_g2a_convert_convert_file_inside_of__838000504_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A struct{ a2g_header uint64; F_l, F_c any }

var A_arbace_g2a_convert_convert_file_inside_of__838000504_fn__838000509_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_file_iter__838000477__838000481_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A struct{ a2g_header uint64; F_iter__838000477, F_s__838000478 any }

var A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A struct{ a2g_header uint64; F_b__838000480 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_convert_file_iter__838000477__838000481_fn__838000482_fn__838000483_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_iter__838000642__838000646_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A struct{ a2g_header uint64; F_iter__838000642, F_s__838000643 any }

var A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_b__838000645, F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_convert_package_iter__838000642__838000646_fn__838000647_fn__838000648_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A struct{ a2g_header uint64; F_ns_sym, F_dump, F_opts any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A struct{ a2g_header uint64; F_iter__838000652, F_ns_sym, F_s__838000653, F_dump, F_opts any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A struct{ a2g_header uint64; F_ns_sym, F_dump, F_b__838000655 any; F_size__1927001038__auto__ int32; F_opts, F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A struct{ a2g_header uint64; F_ns_sym, F_dump, F_fe, F_opts any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_fn__838000675_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A struct{ a2g_header uint64; F_s__838000660, F_iter__838000659 any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A struct{ a2g_header uint64; F_iter__838000661, F_s__838000662 any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A struct{ a2g_header uint64; F_b__838000664 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000658_iter__838000659__838000665_fn__838000666_iter__838000661__838000667_fn__838000668_fn__838000669_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A struct{ a2g_header uint64; F_ns_sym, F_dump, F_fe, F_opts any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_fn__838000694_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A struct{ a2g_header uint64; F_iter__838000678, F_s__838000679 any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A struct{ a2g_header uint64; F_iter__838000680, F_s__838000681 any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_A_fn_class *jrt.Class



type A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A struct{ a2g_header uint64; F_b__838000683 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_convert_package_iter__838000652__838000656_fn__838000657_iter__838000678__838000684_fn__838000685_iter__838000680__838000686_fn__838000687_fn__838000688_A_fn_class *jrt.Class



type A_arbace_g2a_convert_count_node_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_count_node_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_decl_bindings_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000215_A struct{ a2g_header uint64; F_specs any }

var A_arbace_g2a_convert_decl_bindings_fn__838000215_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A struct{ a2g_header uint64; F_type, F_l any }

var A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000221_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A struct{ a2g_header uint64; F_values, F_l any }

var A_arbace_g2a_convert_decl_bindings_fn__838000215_fn__838000226_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A struct{ a2g_header uint64; F_t any }

var A_arbace_g2a_convert_decl_bindings_fn__838000215_mk__838000223_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000229_A struct{ a2g_header uint64; F_specs, F_gd any }

var A_arbace_g2a_convert_decl_bindings_fn__838000229_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A struct{ a2g_header uint64; F_t any }

var A_arbace_g2a_convert_decl_bindings_fn__838000229_mk__838000232_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_bindings_fn__838000235_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_decl_bindings_fn__838000235_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_decl_name_A_fn_class *jrt.Class



type A_arbace_g2a_convert_decl_stmt_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_decl_stmt_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_convert_define_binding_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_define_binding_A_fn_class *jrt.Class



type A_arbace_g2a_convert_define_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_define_target_A_fn_class *jrt.Class



type A_arbace_g2a_convert_dir_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_dir_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_directive_args_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_directive_args_A_fn_class *jrt.Class



type A_arbace_g2a_convert_directive_meta_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_directive_meta_A_fn_class *jrt.Class



type A_arbace_g2a_convert_directive_meta_fn__838000379_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_directive_meta_fn__838000379_A_fn_class *jrt.Class



type A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A struct{ a2g_header uint64; F_v any }

var A_arbace_g2a_convert_directive_meta_fn__838000379_fn__838000380_A_fn_class *jrt.Class



type A_arbace_g2a_convert_directive_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_directive_name_A_fn_class *jrt.Class



type A_arbace_g2a_convert_doc_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_doc_of_A_fn_class *jrt.Class



type A_arbace_g2a_convert_eval838000004_A struct{ jrt.Object }

func A_arbace_g2a_convert_eval838000004_A_New() *A_arbace_g2a_convert_eval838000004_A { t := &A_arbace_g2a_convert_eval838000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_convert_eval838000004_A) Ctor() {}

func (t *A_arbace_g2a_convert_eval838000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_convert_eval838000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_convert_eval838000004_A_class }

func (t *A_arbace_g2a_convert_eval838000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_convert_eval838000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_convert_eval838000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_convert_eval838000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_convert_eval838000004_A); return ok }

func A_arbace_g2a_convert_eval838000004_A_Cast(x any) *A_arbace_g2a_convert_eval838000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_convert_eval838000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_convert_eval838000004_A_class)) }; return v }



type A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_eval838000004_loading__1927001464__auto____838000005_A_fn_class *jrt.Class



type A_arbace_g2a_convert_eval838000008_A struct{ jrt.Object }

func A_arbace_g2a_convert_eval838000008_A_New() *A_arbace_g2a_convert_eval838000008_A { t := &A_arbace_g2a_convert_eval838000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_convert_eval838000008_A) Ctor() {}

func (t *A_arbace_g2a_convert_eval838000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_convert_eval838000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_convert_eval838000008_A_class }

func (t *A_arbace_g2a_convert_eval838000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_convert_eval838000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_convert_eval838000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_convert_eval838000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_convert_eval838000008_A); return ok }

func A_arbace_g2a_convert_eval838000008_A_Cast(x any) *A_arbace_g2a_convert_eval838000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_convert_eval838000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_convert_eval838000008_A_class)) }; return v }



type A_arbace_g2a_convert_eval838000008_fn__838000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_eval838000008_fn__838000009_A_fn_class *jrt.Class



type A_arbace_g2a_convert_expr_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_expr_A_fn_class *jrt.Class



type A_arbace_g2a_convert_expr_fn__838000193_A struct{ a2g_header uint64; F_x any }

var A_arbace_g2a_convert_expr_fn__838000193_A_fn_class *jrt.Class



type A_arbace_g2a_convert_expr_fn__838000197_A struct{ a2g_header uint64; F_l any }

var A_arbace_g2a_convert_expr_fn__838000197_A_fn_class *jrt.Class



type A_arbace_g2a_convert_expr_fn__838000201_A struct{ a2g_header uint64; F_operand, F_logical, F_f, F_n, F_op any }

var A_arbace_g2a_convert_expr_fn__838000201_A_fn_class *jrt.Class



type A_arbace_g2a_convert_expr_operand__838000199_A struct{ a2g_header uint64; F_logical any }

var A_arbace_g2a_convert_expr_operand__838000199_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fail_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_fail_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fail_fn__838000016_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_fail_fn__838000016_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fields_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_fields_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fields_fn__838000102_A struct{ a2g_header uint64; F_struct_QMARK_ any }

var A_arbace_g2a_convert_fields_fn__838000102_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A struct{ a2g_header uint64; F_extra, F_t any }

var A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A struct{ a2g_header uint64; F_extra, F_t, F_iter__838000106, F_s__838000107 any }

var A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A struct{ a2g_header uint64; F_extra, F_t any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__838000109 any }

var A_arbace_g2a_convert_fields_fn__838000102_iter__838000106__838000110_fn__838000111_fn__838000112_A_fn_class *jrt.Class



type A_arbace_g2a_convert_file_directives_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_file_directives_A_fn_class *jrt.Class



type A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A struct{ a2g_header uint64; F_prefix any }

var A_arbace_g2a_convert_file_directives_iter__838000422__838000426_A_fn_class *jrt.Class



type A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A struct{ a2g_header uint64; F_iter__838000422, F_s__838000423, F_prefix any }

var A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_A_fn_class *jrt.Class



type A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A struct{ a2g_header uint64; F_prefix any; F_size__1927001038__auto__ int32; F_b__838000425, F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_file_directives_iter__838000422__838000426_fn__838000427_fn__838000428_A_fn_class *jrt.Class



type A_arbace_g2a_convert_file_stem_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_file_stem_A_fn_class *jrt.Class



type A_arbace_g2a_convert_fn_sig_forms_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_fn_sig_forms_A_fn_class *jrt.Class



type A_arbace_g2a_convert_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_free_directive_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_free_directive_A_fn_class *jrt.Class



type A_arbace_g2a_convert_func_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_func_decl_A_fn_class *jrt.Class



type A_arbace_g2a_convert_func_lit_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_func_lit_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_gap_directives_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_fn__838000251_A struct{ a2g_header uint64; F_from, F_to any }

var A_arbace_g2a_convert_gap_directives_fn__838000251_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_fn__838000256_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_gap_directives_fn__838000256_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_fn__838000267_A struct{ a2g_header uint64; F_inside_QMARK_ any }

var A_arbace_g2a_convert_gap_directives_fn__838000267_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_fn__838000273_A struct{ a2g_header uint64; F_stmts, F_ranges any }

var A_arbace_g2a_convert_gap_directives_fn__838000273_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A struct{ a2g_header uint64; F_l, F_c any }

var A_arbace_g2a_convert_gap_directives_fn__838000273_fn__838000278_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A struct{ a2g_header uint64; F_ranges any }

var A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A struct{ a2g_header uint64; F_p any }

var A_arbace_g2a_convert_gap_directives_inside_QMARK___838000258_fn__838000260_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gen_decl_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_gen_decl_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gen_decl_fn__838000410_A struct{ a2g_header uint64; F_spec any }

var A_arbace_g2a_convert_gen_decl_fn__838000410_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gen_decl_spec__838000406_A struct{ a2g_header uint64; F_spec_meta any }

var A_arbace_g2a_convert_gen_decl_spec__838000406_A_fn_class *jrt.Class



type A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A struct{ a2g_header uint64; F_spec_meta, F_kind any }

var A_arbace_g2a_convert_gen_decl_spec_vec__838000415_A_fn_class *jrt.Class



type A_arbace_g2a_convert_generic_decl_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_generic_decl_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_convert_group_marks_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_group_marks_A_fn_class *jrt.Class



type A_arbace_g2a_convert_group_marks_fn__838000092_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_group_marks_fn__838000092_A_fn_class *jrt.Class



type A_arbace_g2a_convert_ident_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_ident_A_fn_class *jrt.Class



type A_arbace_g2a_convert_ident_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_ident_name_A_fn_class *jrt.Class



type A_arbace_g2a_convert_if_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_if_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_if_form_fn__838000324_A struct{ a2g_header uint64; F_test, F_else, F_body any }

var A_arbace_g2a_convert_if_form_fn__838000324_A_fn_class *jrt.Class



type A_arbace_g2a_convert_if_form_fn__838000337_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_if_form_fn__838000337_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_imports_of_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_imports_of_iter__838000451__838000457_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A struct{ a2g_header uint64; F_iter__838000451, F_s__838000452 any }

var A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A struct{ a2g_header uint64; F_iter__838000453, F_s__838000454 any }

var A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_A_fn_class *jrt.Class



type A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A struct{ a2g_header uint64; F_b__838000456 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_imports_of_iter__838000451__838000457_fn__838000458_iter__838000453__838000459_fn__838000460_fn__838000461_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_init_order_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_iter__838000600__838000604_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_init_order_iter__838000600__838000604_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A struct{ a2g_header uint64; F_iter__838000600, F_s__838000601 any }

var A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__838000603 any }

var A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_fn__838000606_one__838000610_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_init_order_iter__838000600__838000604_fn__838000605_one__838000622_A_fn_class *jrt.Class



type A_arbace_g2a_convert_init_vec_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_init_vec_A_fn_class *jrt.Class



type A_arbace_g2a_convert_inits_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_inits_A_fn_class *jrt.Class



type A_arbace_g2a_convert_inst_meta_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_inst_meta_A_fn_class *jrt.Class



type A_arbace_g2a_convert_instantiation_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_instantiation_A_fn_class *jrt.Class



type A_arbace_g2a_convert_interface_elems_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_interface_elems_A_fn_class *jrt.Class



type A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_A_fn_class *jrt.Class



type A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A struct{ a2g_header uint64; F_iter__838000118, F_s__838000119 any }

var A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_A_fn_class *jrt.Class



type A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A struct{ a2g_header uint64; F_b__838000121 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_interface_elems_iter__838000118__838000122_fn__838000123_fn__838000124_A_fn_class *jrt.Class



type A_arbace_g2a_convert_label_kw_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_label_kw_A_fn_class *jrt.Class



type A_arbace_g2a_convert_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_line_A_fn_class *jrt.Class



type A_arbace_g2a_convert_line_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_line_of_A_fn_class *jrt.Class



type A_arbace_g2a_convert_lit_at_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_lit_at_A_fn_class *jrt.Class



type A_arbace_g2a_convert_mark_ungrouped_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_mark_ungrouped_A_fn_class *jrt.Class



type A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A struct{ a2g_header uint64; F_names_only, F_elems any }

var A_arbace_g2a_convert_mark_ungrouped_fn__838000095_A_fn_class *jrt.Class



type A_arbace_g2a_convert_max_pos_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_max_pos_A_fn_class *jrt.Class



type A_arbace_g2a_convert_max_pos_walk__838000036_A struct{ a2g_header uint64; F_best any }

var A_arbace_g2a_convert_max_pos_walk__838000036_A_fn_class *jrt.Class



type A_arbace_g2a_convert_munge_name_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_munge_name_A_fn_class *jrt.Class



type A_arbace_g2a_convert_nf_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_nf_A_fn_class *jrt.Class



type A_arbace_g2a_convert_note_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_note_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_convert_nt_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_nt_A_fn_class *jrt.Class



type A_arbace_g2a_convert_obj_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_obj_A_fn_class *jrt.Class



type A_arbace_g2a_convert_package_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_package_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_package_form_fn__838000638_A struct{ a2g_header uint64; F_dump any }

var A_arbace_g2a_convert_package_form_fn__838000638_A_fn_class *jrt.Class



type A_arbace_g2a_convert_parse_pos_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_parse_pos_A_fn_class *jrt.Class



type A_arbace_g2a_convert_pkg_ident_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_pkg_ident_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_convert_pos_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_pos_line_A_fn_class *jrt.Class



type A_arbace_g2a_convert_positions_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_positions_A_fn_class *jrt.Class



type A_arbace_g2a_convert_positions_fn__838000030_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_positions_fn__838000030_A_fn_class *jrt.Class



type A_arbace_g2a_convert_relined_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_relined_A_fn_class *jrt.Class



type A_arbace_g2a_convert_relined_fn__838000071_A struct{ a2g_header uint64; F_l any }

var A_arbace_g2a_convert_relined_fn__838000071_A_fn_class *jrt.Class



type A_arbace_g2a_convert_relined_fn__838000073_A struct{ a2g_header uint64; F_l any }

var A_arbace_g2a_convert_relined_fn__838000073_A_fn_class *jrt.Class



type A_arbace_g2a_convert_relined_fn__838000075_A struct{ a2g_header uint64; F_l any }

var A_arbace_g2a_convert_relined_fn__838000075_A_fn_class *jrt.Class



type A_arbace_g2a_convert_selection_via_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_selection_via_A_fn_class *jrt.Class



type A_arbace_g2a_convert_selector_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_selector_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_signature_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_signature_A_fn_class *jrt.Class



type A_arbace_g2a_convert_simple_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_simple_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_convert_start_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_start_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmt_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmt_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmt_STAR__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmt_STAR__A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmt_STAR__fn__838000362_A struct{ a2g_header uint64; F_f any }

var A_arbace_g2a_convert_stmt_STAR__fn__838000362_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A struct{ a2g_header uint64; F_define bool }

var A_arbace_g2a_convert_stmt_STAR__tgt__838000371_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmt_list_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmt_list_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmts_forms_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_build__838000298_A struct{ a2g_header uint64; F_n int32; F_stmts, F_tail, F_gaps any }

var A_arbace_g2a_convert_stmts_forms_build__838000298_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A struct{ a2g_header uint64; F_s, F_ll, F_dl any }

var A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000307_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A struct{ a2g_header uint64; F_n int32; F_stmts, F_i, F_bs, F_kind, F_gaps, F_kind_of any }

var A_arbace_g2a_convert_stmts_forms_build__838000298_fn__838000309_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmts_forms_build__838000298_kind_of__838000305_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_fn__838000290_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_stmts_forms_fn__838000290_A_fn_class *jrt.Class



type A_arbace_g2a_convert_stmts_forms_fn__838000296_A struct{ a2g_header uint64; F_list any }

var A_arbace_g2a_convert_stmts_forms_fn__838000296_A_fn_class *jrt.Class



type A_arbace_g2a_convert_string_value_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_string_value_A_fn_class *jrt.Class



type A_arbace_g2a_convert_tagged_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_tagged_A_fn_class *jrt.Class



type A_arbace_g2a_convert_targets_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_targets_A_fn_class *jrt.Class



type A_arbace_g2a_convert_targs_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_targs_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_type_form_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_form_fn__838000141_A struct{ a2g_header uint64; F_f any }

var A_arbace_g2a_convert_type_form_fn__838000141_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_params_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_type_params_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_params_fn__838000145_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_type_params_fn__838000145_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A struct{ a2g_header uint64; F_c any }

var A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A struct{ a2g_header uint64; F_iter__838000148, F_s__838000149, F_c any }

var A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_A_fn_class *jrt.Class



type A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A struct{ a2g_header uint64; F_b__838000151 any; F_size__1927001038__auto__ int32; F_c, F_c__1927001037__auto__ any }

var A_arbace_g2a_convert_type_params_fn__838000145_iter__838000148__838000152_fn__838000153_fn__838000154_A_fn_class *jrt.Class



type A_arbace_g2a_convert_unparen_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_unparen_A_fn_class *jrt.Class



type A_arbace_g2a_convert_untyped_const_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_untyped_const_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_convert_value_spec_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_value_spec_target_A_fn_class *jrt.Class



type A_arbace_g2a_convert_value_spec_target_mk__838000401_A struct{ a2g_header uint64; F_t, F_extra, F_kind any }

var A_arbace_g2a_convert_value_spec_target_mk__838000401_A_fn_class *jrt.Class



type A_arbace_g2a_convert_vec_at_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_vec_at_A_fn_class *jrt.Class



type A_arbace_g2a_convert_with_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_with_line_A_fn_class *jrt.Class



type A_arbace_g2a_convert_with_pos_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_with_pos_A_fn_class *jrt.Class



type A_arbace_g2a_convert_with_pos_fn__838000055_A struct{ a2g_header uint64 }

var A_arbace_g2a_convert_with_pos_fn__838000055_A_fn_class *jrt.Class



type A_arbace_g2a_convert_with_pos_fn__838000060_A struct{ a2g_header uint64; F_ps any }

var A_arbace_g2a_convert_with_pos_fn__838000060_A_fn_class *jrt.Class
