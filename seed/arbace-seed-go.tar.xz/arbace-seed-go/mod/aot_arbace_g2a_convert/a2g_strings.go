//line a2g_strings.ae:1
package aot_arbace_g2a_convert

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.lit")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("lit")

var Lit_6 *jrt.String = jrt.Intern("arbace.g2a.types")

var Lit_7 *jrt.String = jrt.Intern("ty")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.g2a.convert")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("g2a's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.g2a.lit/Lit (text and value). arbace.g2a.layout writes them as text.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("*stats*")

var Lit_18 *jrt.String = jrt.Intern("swap!")

var Lit_19 *jrt.String = jrt.Intern("update-in")

var Lit_20 *jrt.String = jrt.Intern("fnil")

var Lit_21 *jrt.String = jrt.Intern("notes")

var Lit_22 *jrt.String = jrt.Intern("inc")

var Lit_23 *jrt.String = jrt.Intern("nodes")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("ex-info")

var Lit_26 *jrt.String = jrt.Intern("pr-str")

var Lit_27 *jrt.String = jrt.Intern("seq?")

var Lit_28 *jrt.String = jrt.Intern("map?")

var Lit_29 *jrt.String = jrt.Intern("second")

var Lit_30 *jrt.String = jrt.Intern("vals")

var Lit_31 *jrt.String = jrt.Intern("node")

var Lit_32 *jrt.String = jrt.Intern("filter")

var Lit_33 *jrt.String = jrt.Intern("string?")

var Lit_34 *jrt.String = jrt.Intern("re-matches")

var Lit_35 *jrt.String = jrt.Intern("\\d+:\\d+")

var Lit_36 *jrt.String = jrt.Intern("paren-expr")

var Lit_37 *jrt.String = jrt.Intern("nt")

var Lit_38 *jrt.String = jrt.Intern("x")

var Lit_39 *jrt.String = jrt.Intern("nf")

var Lit_40 *jrt.String = jrt.Intern("subs")

var Lit_41 *jrt.String = jrt.Intern("parse-pos")

var Lit_42 *jrt.String = jrt.Intern("send-stmt")

var Lit_43 *jrt.String = jrt.Intern("start")

var Lit_44 *jrt.String = jrt.Intern("array-type")

var Lit_45 *jrt.String = jrt.Intern("lbrack")

var Lit_46 *jrt.String = jrt.Intern("ellipsis")

var Lit_47 *jrt.String = jrt.Intern("if-stmt")

var Lit_48 *jrt.String = jrt.Intern("if")

var Lit_49 *jrt.String = jrt.Intern("fail")

var Lit_50 *jrt.String = jrt.Intern("chan")

var Lit_51 *jrt.String = jrt.Intern("import-spec")

var Lit_52 *jrt.String = jrt.Intern("name")

var Lit_53 *jrt.String = jrt.Intern("value-spec")

var Lit_54 *jrt.String = jrt.Intern("path")

var Lit_55 *jrt.String = jrt.Intern("unary-expr")

var Lit_56 *jrt.String = jrt.Intern("op-pos")

var Lit_57 *jrt.String = jrt.Intern("names")

var Lit_58 *jrt.String = jrt.Intern("ident")

var Lit_59 *jrt.String = jrt.Intern("name-pos")

var Lit_60 *jrt.String = jrt.Intern("return-stmt")

var Lit_61 *jrt.String = jrt.Intern("return")

var Lit_62 *jrt.String = jrt.Intern("composite-lit")

var Lit_63 *jrt.String = jrt.Intern("type")

var Lit_64 *jrt.String = jrt.Intern("lbrace")

var Lit_65 *jrt.String = jrt.Intern("chan-type")

var Lit_66 *jrt.String = jrt.Intern("begin")

var Lit_67 *jrt.String = jrt.Intern("field")

var Lit_68 *jrt.String = jrt.Intern("seq")

var Lit_69 *jrt.String = jrt.Intern("map-type")

var Lit_70 *jrt.String = jrt.Intern("map")

var Lit_71 *jrt.String = jrt.Intern("case-clause")

var Lit_72 *jrt.String = jrt.Intern("case")

var Lit_73 *jrt.String = jrt.Intern("field-list")

var Lit_74 *jrt.String = jrt.Intern("opening")

var Lit_75 *jrt.String = jrt.Intern("list")

var Lit_76 *jrt.String = jrt.Intern("index-expr")

var Lit_77 *jrt.String = jrt.Intern("decl-stmt")

var Lit_78 *jrt.String = jrt.Intern("expr-stmt")

var Lit_79 *jrt.String = jrt.Intern("decl")

var Lit_80 *jrt.String = jrt.Intern("assign-stmt")

var Lit_81 *jrt.String = jrt.Intern("slice-expr")

var Lit_82 *jrt.String = jrt.Intern("lhs")

var Lit_83 *jrt.String = jrt.Intern("call-expr")

var Lit_84 *jrt.String = jrt.Intern("interface-type")

var Lit_85 *jrt.String = jrt.Intern("interface")

var Lit_86 *jrt.String = jrt.Intern("fun")

var Lit_87 *jrt.String = jrt.Intern("key-value-expr")

var Lit_88 *jrt.String = jrt.Intern("selector-expr")

var Lit_89 *jrt.String = jrt.Intern("key")

var Lit_90 *jrt.String = jrt.Intern("empty-stmt")

var Lit_91 *jrt.String = jrt.Intern("semicolon")

var Lit_92 *jrt.String = jrt.Intern("type-spec")

var Lit_93 *jrt.String = jrt.Intern("gen-decl")

var Lit_94 *jrt.String = jrt.Intern("tok-pos")

var Lit_95 *jrt.String = jrt.Intern("inc-dec-stmt")

var Lit_96 *jrt.String = jrt.Intern("for-stmt")

var Lit_97 *jrt.String = jrt.Intern("for")

var Lit_98 *jrt.String = jrt.Intern("labeled-stmt")

var Lit_99 *jrt.String = jrt.Intern("func-lit")

var Lit_100 *jrt.String = jrt.Intern("label")

var Lit_101 *jrt.String = jrt.Intern("star-expr")

var Lit_102 *jrt.String = jrt.Intern("star")

var Lit_103 *jrt.String = jrt.Intern("func-type")

var Lit_104 *jrt.String = jrt.Intern("func")

var Lit_105 *jrt.String = jrt.Intern("index-list-expr")

var Lit_106 *jrt.String = jrt.Intern("params")

var Lit_107 *jrt.String = jrt.Intern("binary-expr")

var Lit_108 *jrt.String = jrt.Intern("switch-stmt")

var Lit_109 *jrt.String = jrt.Intern("switch")

var Lit_110 *jrt.String = jrt.Intern("defer-stmt")

var Lit_111 *jrt.String = jrt.Intern("defer")

var Lit_112 *jrt.String = jrt.Intern("basic-lit")

var Lit_113 *jrt.String = jrt.Intern("value-pos")

var Lit_114 *jrt.String = jrt.Intern("type-switch-stmt")

var Lit_115 *jrt.String = jrt.Intern("struct-type")

var Lit_116 *jrt.String = jrt.Intern("struct")

var Lit_117 *jrt.String = jrt.Intern("range-stmt")

var Lit_118 *jrt.String = jrt.Intern("lparen")

var Lit_119 *jrt.String = jrt.Intern("type-assert-expr")

var Lit_120 *jrt.String = jrt.Intern("select-stmt")

var Lit_121 *jrt.String = jrt.Intern("select")

var Lit_122 *jrt.String = jrt.Intern("branch-stmt")

var Lit_123 *jrt.String = jrt.Intern("go-stmt")

var Lit_124 *jrt.String = jrt.Intern("go")

var Lit_125 *jrt.String = jrt.Intern("comm-clause")

var Lit_126 *jrt.String = jrt.Intern("func-decl")

var Lit_127 *jrt.String = jrt.Intern("block-stmt")

var Lit_128 *jrt.String = jrt.Intern("pos-line")

var Lit_129 *jrt.String = jrt.Intern("into")

var Lit_130 *jrt.String = jrt.Intern("sorted-map")

var Lit_131 *jrt.String = jrt.Intern("keep")

var Lit_132 *jrt.String = jrt.Intern("volatile!")

var Lit_133 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_134 *jrt.String = jrt.Intern("chunk-first")

var Lit_135 *jrt.String = jrt.Intern("vector?")

var Lit_136 *jrt.String = jrt.Intern("run!")

var Lit_137 *jrt.String = jrt.Intern("vreset!")

var Lit_138 *jrt.String = jrt.Intern("chunk-rest")

var Lit_139 *jrt.String = jrt.Intern("next")

var Lit_140 *jrt.String = jrt.Intern("with-meta")

var Lit_141 *jrt.String = jrt.Intern("apply")

var Lit_142 *jrt.String = jrt.Intern("l")

var Lit_143 *jrt.String = jrt.Intern("assoc")

var Lit_144 *jrt.String = jrt.Intern("pos")

var Lit_145 *jrt.String = jrt.Intern("positions")

var Lit_146 *jrt.String = jrt.Intern("vary-meta")

var Lit_147 *jrt.String = jrt.Intern("update")

var Lit_148 *jrt.String = jrt.Intern("merge")

var Lit_149 *jrt.String = jrt.Intern("rbrace")

var Lit_150 *jrt.String = jrt.Intern("not")

var Lit_151 *jrt.String = jrt.Intern("line")

var Lit_152 *jrt.String = jrt.Intern("vec")

var Lit_153 *jrt.String = jrt.Intern("empty?")

var Lit_154 *jrt.String = jrt.Intern("lit?")

var Lit_155 *jrt.String = jrt.Intern("symbol?")

var Lit_156 *jrt.String = jrt.Intern("else")

var Lit_157 *jrt.String = jrt.Intern("dissoc")

var Lit_158 *jrt.String = jrt.Intern("relined")

var Lit_159 *jrt.String = jrt.Intern("mapv")

var Lit_160 *jrt.String = jrt.Intern("use")

var Lit_161 *jrt.String = jrt.Intern("an")

var Lit_162 *jrt.String = jrt.Intern("def")

var Lit_163 *jrt.String = jrt.Intern("type-form")

var Lit_164 *jrt.String = jrt.Intern("targs")

var Lit_165 *jrt.String = jrt.Intern("inst")

var Lit_166 *jrt.String = jrt.Intern("obj")

var Lit_167 *jrt.String = jrt.Intern("kind")

var Lit_168 *jrt.String = jrt.Intern("ident-name")

var Lit_169 *jrt.String = jrt.Intern("line-of")

var Lit_170 *jrt.String = jrt.Intern("at")

var Lit_171 *jrt.String = jrt.Intern("false")

var Lit_172 *jrt.String = jrt.Intern("true")

var Lit_173 *jrt.String = jrt.Intern("nil")

var Lit_174 *jrt.String = jrt.Intern("universe")

var Lit_175 *jrt.String = jrt.Intern("mode")

var Lit_176 *jrt.String = jrt.Intern("const")

var Lit_177 *jrt.String = jrt.Intern("lit-at")

var Lit_178 *jrt.String = jrt.Intern("form")

var Lit_179 *jrt.String = jrt.Intern("add-meta")

var Lit_180 *jrt.String = jrt.Intern("count-node!")

var Lit_181 *jrt.String = jrt.Intern("symbol")

var Lit_182 *jrt.String = jrt.Intern("note!")

var Lit_183 *jrt.String = jrt.Intern("go-id")

var Lit_184 *jrt.String = jrt.Intern("id")

var Lit_185 *jrt.String = jrt.Intern("string-text")

var Lit_186 *jrt.String = jrt.Intern("inst-meta")

var Lit_187 *jrt.String = jrt.Intern("keyword")

var Lit_188 *jrt.String = jrt.Intern("pkg")

var Lit_189 *jrt.String = jrt.Intern("unparen")

var Lit_190 *jrt.String = jrt.Intern("to-array")

var Lit_191 *jrt.String = jrt.Intern("value")

var Lit_192 *jrt.String = jrt.Intern("bytes-form")

var Lit_193 *jrt.String = jrt.Intern("rune-form")

var Lit_194 *jrt.String = jrt.Intern("string-bytes")

var Lit_195 *jrt.String = jrt.Intern("imaginary")

var Lit_196 *jrt.String = jrt.Intern("imag-inner")

var Lit_197 *jrt.String = jrt.Intern("float-text-lit")

var Lit_198 *jrt.String = jrt.Intern("rune-value")

var Lit_199 *jrt.String = jrt.Intern("int-lit")

var Lit_200 *jrt.String = jrt.Intern("tag")

var Lit_201 *jrt.String = jrt.Intern("*generic*")

var Lit_202 *jrt.String = jrt.Intern("cons")

var Lit_203 *jrt.String = jrt.Intern("grouped")

var Lit_204 *jrt.String = jrt.Intern("rest")

var Lit_205 *jrt.String = jrt.Intern("map-indexed")

var Lit_206 *jrt.String = jrt.Intern("contains?")

var Lit_207 *jrt.String = jrt.Intern("text")

var Lit_208 *jrt.String = jrt.Intern("not=")

var Lit_209 *jrt.String = jrt.Intern("*kept-docs*")

var Lit_210 *jrt.String = jrt.Intern("struct?")

var Lit_211 *jrt.String = jrt.Intern("mark-ungrouped")

var Lit_212 *jrt.String = jrt.Intern("mapcat")

var Lit_213 *jrt.String = jrt.Intern("doc-of")

var Lit_214 *jrt.String = jrt.Intern("concat")

var Lit_215 *jrt.String = jrt.Intern("slice")

var Lit_216 *jrt.String = jrt.Intern("elt")

var Lit_217 *jrt.String = jrt.Intern("string-value")

var Lit_218 *jrt.String = jrt.Intern("*groups*")

var Lit_219 *jrt.String = jrt.Intern("&")

var Lit_220 *jrt.String = jrt.Intern("group-marks")

var Lit_221 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_222 *jrt.String = jrt.Intern("chunk-append")

var Lit_223 *jrt.String = jrt.Intern("tagged")

var Lit_224 *jrt.String = jrt.Intern("chunk-cons")

var Lit_225 *jrt.String = jrt.Intern("chunk")

var Lit_226 *jrt.String = jrt.Intern("signature")

var Lit_227 *jrt.String = jrt.Intern("dir")

var Lit_228 *jrt.String = jrt.Intern("recv")

var Lit_229 *jrt.String = jrt.Intern("both")

var Lit_230 *jrt.String = jrt.Intern("send")

var Lit_231 *jrt.String = jrt.Intern("namespace")

var Lit_232 *jrt.String = jrt.Intern("reserved-type-heads")

var Lit_233 *jrt.String = jrt.Intern("interface-elems")

var Lit_234 *jrt.String = jrt.Intern("methods")

var Lit_235 *jrt.String = jrt.Intern("indices")

var Lit_236 *jrt.String = jrt.Intern("index")

var Lit_237 *jrt.String = jrt.Intern("len")

var Lit_238 *jrt.String = jrt.Intern("fields")

var Lit_239 *jrt.String = jrt.Intern("op")

var Lit_240 *jrt.String = jrt.Intern("array")

var Lit_241 *jrt.String = jrt.Intern("...")

var Lit_242 *jrt.String = jrt.Intern("expr")

var Lit_243 *jrt.String = jrt.Intern("tilde")

var Lit_244 *jrt.String = jrt.Intern("pkg-ident?")

var Lit_245 *jrt.String = jrt.Intern("y")

var Lit_246 *jrt.String = jrt.Intern("sel")

var Lit_247 *jrt.String = jrt.Intern("|")

var Lit_248 *jrt.String = jrt.Intern("results")

var Lit_249 *jrt.String = jrt.Intern("*")

var Lit_250 *jrt.String = jrt.Intern("vec-at")

var Lit_251 *jrt.String = jrt.Intern("with-pos")

var Lit_252 *jrt.String = jrt.Intern("select-keys")

var Lit_253 *jrt.String = jrt.Intern("closing")

var Lit_254 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_255 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_256 *jrt.String = jrt.Intern("hash-map")

var Lit_257 *jrt.String = jrt.Intern("untyped-const?")

var Lit_258 *jrt.String = jrt.Intern("builtin")

var Lit_259 *jrt.String = jrt.Intern("imag")

var Lit_260 *jrt.String = jrt.Intern("real")

var Lit_261 *jrt.String = jrt.Intern("complex")

var Lit_262 *jrt.String = jrt.Intern("every?")

var Lit_263 *jrt.String = jrt.Intern("t")

var Lit_264 *jrt.String = jrt.Intern("untyped?")

var Lit_265 *jrt.String = jrt.Intern(">>")

var Lit_266 *jrt.String = jrt.Intern("<<")

var Lit_267 *jrt.String = jrt.Intern("args")

var Lit_268 *jrt.String = jrt.Intern("via")

var Lit_269 *jrt.String = jrt.Intern("method-expr")

var Lit_270 *jrt.String = jrt.Intern("method")

var Lit_271 *jrt.String = jrt.Intern("x-pos")

var Lit_272 *jrt.String = jrt.Intern("as-inst")

var Lit_273 *jrt.String = jrt.Intern("selection-via")

var Lit_274 *jrt.String = jrt.Intern("pop")

var Lit_275 *jrt.String = jrt.Intern("spread")

var Lit_276 *jrt.String = jrt.Intern("peek")

var Lit_277 *jrt.String = jrt.Intern("builtin-name")

var Lit_278 *jrt.String = jrt.Intern("new")

var Lit_279 *jrt.String = jrt.Intern("reserved-heads")

var Lit_280 *jrt.String = jrt.Intern("conv")

var Lit_281 *jrt.String = jrt.Intern("dot")

var Lit_282 *jrt.String = jrt.Intern("call-args")

var Lit_283 *jrt.String = jrt.Intern("go-call")

var Lit_284 *jrt.String = jrt.Intern("call")

var Lit_285 *jrt.String = jrt.Intern("elts")

var Lit_286 *jrt.String = jrt.Intern("body")

var Lit_287 *jrt.String = jrt.Intern("fn-sig-forms")

var Lit_288 *jrt.String = jrt.Intern("stmt-list")

var Lit_289 *jrt.String = jrt.Intern("tail")

var Lit_290 *jrt.String = jrt.Intern("end")

var Lit_291 *jrt.String = jrt.Intern("fn")

var Lit_292 *jrt.String = jrt.Intern("block-pos")

var Lit_293 *jrt.String = jrt.Intern("INT")

var Lit_294 *jrt.String = jrt.Intern("FLOAT")

var Lit_295 *jrt.String = jrt.Intern("unary-ops")

var Lit_296 *jrt.String = jrt.Intern("composite")

var Lit_297 *jrt.String = jrt.Intern("low")

var Lit_298 *jrt.String = jrt.Intern("high")

var Lit_299 *jrt.String = jrt.Intern("max")

var Lit_300 *jrt.String = jrt.Intern("negative-literal")

var Lit_301 *jrt.String = jrt.Intern("subslice")

var Lit_302 *jrt.String = jrt.Intern("selector-form")

var Lit_303 *jrt.String = jrt.Intern("binary-ops")

var Lit_304 *jrt.String = jrt.Intern("nary-ops")

var Lit_305 *jrt.String = jrt.Intern("or")

var Lit_306 *jrt.String = jrt.Intern("and")

var Lit_307 *jrt.String = jrt.Intern("logical-paren")

var Lit_308 *jrt.String = jrt.Intern("paren")

var Lit_309 *jrt.String = jrt.Intern("shift-tag")

var Lit_310 *jrt.String = jrt.Intern("assert")

var Lit_311 *jrt.String = jrt.Intern("instantiation")

var Lit_312 *jrt.String = jrt.Intern("aget")

var Lit_313 *jrt.String = jrt.Intern("values")

var Lit_314 *jrt.String = jrt.Intern("_")

var Lit_315 *jrt.String = jrt.Intern("assign")

var Lit_316 *jrt.String = jrt.Intern("rhs")

var Lit_317 *jrt.String = jrt.Intern("targets")

var Lit_318 *jrt.String = jrt.Intern("define-target")

var Lit_319 *jrt.String = jrt.Intern("inits")

var Lit_320 *jrt.String = jrt.Intern("const-form")

var Lit_321 *jrt.String = jrt.Intern("val")

var Lit_322 *jrt.String = jrt.Intern("const-kind")

var Lit_323 *jrt.String = jrt.Intern("tok")

var Lit_324 *jrt.String = jrt.Intern("specs")

var Lit_325 *jrt.String = jrt.Intern("let")

var Lit_326 *jrt.String = jrt.Intern("const-val")

var Lit_327 *jrt.String = jrt.Intern("local-const-repeated")

var Lit_328 *jrt.String = jrt.Intern("implicit")

var Lit_329 *jrt.String = jrt.Intern("local-const-group")

var Lit_330 *jrt.String = jrt.Intern("local-const-group-split")

var Lit_331 *jrt.String = jrt.Intern("zero")

var Lit_332 *jrt.String = jrt.Intern("var")

var Lit_333 *jrt.String = jrt.Intern("let-type")

var Lit_334 *jrt.String = jrt.Intern("type-params")

var Lit_335 *jrt.String = jrt.Intern("generic-decl?")

var Lit_336 *jrt.String = jrt.Intern("alias")

var Lit_337 *jrt.String = jrt.Intern("local-generic-type")

var Lit_338 *jrt.String = jrt.Intern("decl-stmt?")

var Lit_339 *jrt.String = jrt.Intern("stmt")

var Lit_340 *jrt.String = jrt.Intern("bindings-of")

var Lit_341 *jrt.String = jrt.Intern("decl-bindings")

var Lit_342 *jrt.String = jrt.Intern("define-binding")

var Lit_343 *jrt.String = jrt.Intern("*placed*")

var Lit_344 *jrt.String = jrt.Intern("directive-statement")

var Lit_345 *jrt.String = jrt.Intern("directive")

var Lit_346 *jrt.String = jrt.Intern("some")

var Lit_347 *jrt.String = jrt.Intern("remove")

var Lit_348 *jrt.String = jrt.Intern("reduce")

var Lit_349 *jrt.String = jrt.Intern("*fn-dirs*")

var Lit_350 *jrt.String = jrt.Intern("repeat")

var Lit_351 *jrt.String = jrt.Intern("max-pos")

var Lit_352 *jrt.String = jrt.Intern("keep-indexed")

var Lit_353 *jrt.String = jrt.Intern("gap-directives")

var Lit_354 *jrt.String = jrt.Intern("dir-form")

var Lit_355 *jrt.String = jrt.Intern("labeled-declaration")

var Lit_356 *jrt.String = jrt.Intern("label-kw")

var Lit_357 *jrt.String = jrt.Intern("identity")

var Lit_358 *jrt.String = jrt.Intern("doall")

var Lit_359 *jrt.String = jrt.Intern("stmts-forms")

var Lit_360 *jrt.String = jrt.Intern("do")

var Lit_361 *jrt.String = jrt.Intern("when")

var Lit_362 *jrt.String = jrt.Intern("cond")

var Lit_363 *jrt.String = jrt.Intern("simple-stmt")

var Lit_364 *jrt.String = jrt.Intern("init")

var Lit_365 *jrt.String = jrt.Intern("init-vec")

var Lit_366 *jrt.String = jrt.Intern("branch")

var Lit_367 *jrt.String = jrt.Intern("if-form")

var Lit_368 *jrt.String = jrt.Intern("else-lbrace")

var Lit_369 *jrt.String = jrt.Intern("else-rbrace")

var Lit_370 *jrt.String = jrt.Intern("colon")

var Lit_371 *jrt.String = jrt.Intern("default")

var Lit_372 *jrt.String = jrt.Intern("clause-bound")

var Lit_373 *jrt.String = jrt.Intern("comm")

var Lit_374 *jrt.String = jrt.Intern("=")

var Lit_375 *jrt.String = jrt.Intern("assign-ops")

var Lit_376 *jrt.String = jrt.Intern("aset")

var Lit_377 *jrt.String = jrt.Intern("set!")

var Lit_378 *jrt.String = jrt.Intern("stmt*")

var Lit_379 *jrt.String = jrt.Intern("implicit-return")

var Lit_380 *jrt.String = jrt.Intern("post")

var Lit_381 *jrt.String = jrt.Intern("break")

var Lit_382 *jrt.String = jrt.Intern("continue")

var Lit_383 *jrt.String = jrt.Intern("goto")

var Lit_384 *jrt.String = jrt.Intern("fallthrough")

var Lit_385 *jrt.String = jrt.Intern("while")

var Lit_386 *jrt.String = jrt.Intern("inc!")

var Lit_387 *jrt.String = jrt.Intern("dec!")

var Lit_388 *jrt.String = jrt.Intern("type-switch")

var Lit_389 *jrt.String = jrt.Intern("clauses")

var Lit_390 *jrt.String = jrt.Intern("range")

var Lit_391 *jrt.String = jrt.Intern(">!")

var Lit_392 *jrt.String = jrt.Intern("block-forms")

var Lit_393 *jrt.String = jrt.Intern("starts-with?")

var Lit_394 *jrt.String = jrt.Intern("index-of")

var Lit_395 *jrt.String = jrt.Intern("triml")

var Lit_396 *jrt.String = jrt.Intern("directive-name")

var Lit_397 *jrt.String = jrt.Intern("free-standing-names")

var Lit_398 *jrt.String = jrt.Intern("split")

var Lit_399 *jrt.String = jrt.Intern("directive-args")

var Lit_400 *jrt.String = jrt.Intern("\\s+")

var Lit_401 *jrt.String = jrt.Intern("directive-free")

var Lit_402 *jrt.String = jrt.Intern("extern")

var Lit_403 *jrt.String = jrt.Intern("value-spec-target")

var Lit_404 *jrt.String = jrt.Intern("directives")

var Lit_405 *jrt.String = jrt.Intern(".")

var Lit_406 *jrt.String = jrt.Intern("ast")

var Lit_407 *jrt.String = jrt.Intern("file")

var Lit_408 *jrt.String = jrt.Intern("decls")

var Lit_409 *jrt.String = jrt.Intern("file-directives")

var Lit_410 *jrt.String = jrt.Intern("atom")

var Lit_411 *jrt.String = jrt.Intern("last")

var Lit_412 *jrt.String = jrt.Intern("get-in")

var Lit_413 *jrt.String = jrt.Intern("directive-meta")

var Lit_414 *jrt.String = jrt.Intern("attach")

var Lit_415 *jrt.String = jrt.Intern("directive-attached")

var Lit_416 *jrt.String = jrt.Intern("go-version")

var Lit_417 *jrt.String = jrt.Intern("package")

var Lit_418 *jrt.String = jrt.Intern("build")

var Lit_419 *jrt.String = jrt.Intern("lang")

var Lit_420 *jrt.String = jrt.Intern("imports")

var Lit_421 *jrt.String = jrt.Intern("free-directive")

var Lit_422 *jrt.String = jrt.Intern("take")

var Lit_423 *jrt.String = jrt.Intern("free")

var Lit_424 *jrt.String = jrt.Intern("forms")

var Lit_425 *jrt.String = jrt.Intern("comments")

var Lit_426 *jrt.String = jrt.Intern("unplaced")

var Lit_427 *jrt.String = jrt.Intern("attachable?")

var Lit_428 *jrt.String = jrt.Intern("decl-name")

var Lit_429 *jrt.String = jrt.Intern("inner")

var Lit_430 *jrt.String = jrt.Intern("in-imports")

var Lit_431 *jrt.String = jrt.Intern("sort-by")

var Lit_432 *jrt.String = jrt.Intern("imports-of")

var Lit_433 *jrt.String = jrt.Intern("split-lines")

var Lit_434 *jrt.String = jrt.Intern("replace")

var Lit_435 *jrt.String = jrt.Intern("vector")

var Lit_436 *jrt.String = jrt.Intern("directive-unplaced")

var Lit_437 *jrt.String = jrt.Intern("raw")

var Lit_438 *jrt.String = jrt.Intern("in-ns")

var Lit_439 *jrt.String = jrt.Intern("quote")

var Lit_440 *jrt.String = jrt.Intern("(.*):(\\d+):(\\d+)")

var Lit_441 *jrt.String = jrt.Intern("init-order")

var Lit_442 *jrt.String = jrt.Intern("[.-]")

var Lit_443 *jrt.String = jrt.Intern("config")

var Lit_444 *jrt.String = jrt.Intern("go-files")

var Lit_445 *jrt.String = jrt.Intern("sort")

var Lit_446 *jrt.String = jrt.Intern("s-files")

var Lit_447 *jrt.String = jrt.Intern("h-files")

var Lit_448 *jrt.String = jrt.Intern("syso-files")

var Lit_449 *jrt.String = jrt.Intern("c-files")

var Lit_450 *jrt.String = jrt.Intern("cxx-files")

var Lit_451 *jrt.String = jrt.Intern("m-files")

var Lit_452 *jrt.String = jrt.Intern("f-files")

var Lit_453 *jrt.String = jrt.Intern("swig-files")

var Lit_454 *jrt.String = jrt.Intern("swig-cxx-files")

var Lit_455 *jrt.String = jrt.Intern("embed-files")

var Lit_456 *jrt.String = jrt.Intern("test-embed-files")

var Lit_457 *jrt.String = jrt.Intern("munge-name")

var Lit_458 *jrt.String = jrt.Intern("/")

var Lit_459 *jrt.String = jrt.Intern("array-map")

var Lit_460 *jrt.String = jrt.Intern("files")

var Lit_461 *jrt.String = jrt.Intern("goos")

var Lit_462 *jrt.String = jrt.Intern("goarch")

var Lit_463 *jrt.String = jrt.Intern("goamd64")

var Lit_464 *jrt.String = jrt.Intern("goarm64")

var Lit_465 *jrt.String = jrt.Intern("toolchain")

var Lit_466 *jrt.String = jrt.Intern("tags")

var Lit_467 *jrt.String = jrt.Intern("goexperiment")

var Lit_468 *jrt.String = jrt.Intern("cgo")

var Lit_469 *jrt.String = jrt.Intern("compiler")

var Lit_470 *jrt.String = jrt.Intern("other-files")

var Lit_471 *jrt.String = jrt.Intern("test-go-files")

var Lit_472 *jrt.String = jrt.Intern("test-files")

var Lit_473 *jrt.String = jrt.Intern("file-name-collision")

var Lit_474 *jrt.String = jrt.Intern("ns")

var Lit_475 *jrt.String = jrt.Intern("ns-name-of")

var Lit_476 *jrt.String = jrt.Intern("package-form")

var Lit_477 *jrt.String = jrt.Intern("stats")

var Lit_478 *jrt.String = jrt.Intern("underlying")

var Lit_479 *jrt.String = jrt.Intern("types")

var Lit_480 *jrt.String = jrt.Intern("*dump*")

var Lit_481 *jrt.String = jrt.Intern("*table*")

var Lit_482 *jrt.String = jrt.Intern("type-table")

var Lit_483 *jrt.String = jrt.Intern("*pkg*")

var Lit_484 *jrt.String = jrt.Intern("*underlying*")

var Lit_485 *jrt.String = jrt.Intern("convert-file")

var Lit_486 *jrt.String = jrt.Intern("stem")

var Lit_487 *jrt.String = jrt.Intern("file-stem")

var Lit_488 *jrt.String = jrt.Intern("src-dir")

var Lit_489 *jrt.String = jrt.Intern("*imports*")

var Lit_490 *jrt.String = jrt.Intern("arbace.g2a.convert$add_meta")

var Lit_491 *jrt.String = jrt.Intern("arbace.g2a.convert$an")

var Lit_492 *jrt.String = jrt.Intern("arbace.g2a.convert$as_inst")

var Lit_493 *jrt.String = jrt.Intern("arbace.g2a.convert$assign")

var Lit_494 *jrt.String = jrt.Intern("assignment ")

var Lit_495 *jrt.String = jrt.Intern("arbace.g2a.convert$at")

var Lit_496 *jrt.String = jrt.Intern("arbace.g2a.convert$at$fn__838000046")

var Lit_497 *jrt.String = jrt.Intern("arbace.g2a.convert$at$fn__838000046$fn__838000048")

var Lit_498 *jrt.String = jrt.Intern("arbace.g2a.convert$attachable_QMARK_")

var Lit_499 *jrt.String = jrt.Intern("cgo_")

var Lit_500 *jrt.String = jrt.Intern("linkname")

var Lit_501 *jrt.String = jrt.Intern("")

var Lit_502 *jrt.String = jrt.Intern("arbace.g2a.convert$basic_lit")

var Lit_503 *jrt.String = jrt.Intern("STRING")

var Lit_504 *jrt.String = jrt.Intern("IMAG")

var Lit_505 *jrt.String = jrt.Intern("CHAR")

var Lit_506 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_507 *jrt.String = jrt.Intern("arbace.g2a.convert$bindings_of")

var Lit_508 *jrt.String = jrt.Intern("arbace.g2a.convert$block_forms")

var Lit_509 *jrt.String = jrt.Intern("arbace.g2a.convert$block_pos")

var Lit_510 *jrt.String = jrt.Intern("arbace.g2a.convert$branch")

var Lit_511 *jrt.String = jrt.Intern("arbace.g2a.convert$builtin_name")

var Lit_512 *jrt.String = jrt.Intern("arbace.g2a.convert$call")

var Lit_513 *jrt.String = jrt.Intern("conversion arity")

var Lit_514 *jrt.String = jrt.Intern("arbace.g2a.convert$call$fn__838000173")

var Lit_515 *jrt.String = jrt.Intern("arbace.g2a.convert$call_args")

var Lit_516 *jrt.String = jrt.Intern("arbace.g2a.convert$case_clause")

var Lit_517 *jrt.String = jrt.Intern("arbace.g2a.convert$case_clause$fn__838000346")

var Lit_518 *jrt.String = jrt.Intern("arbace.g2a.convert$clause_bound")

var Lit_519 *jrt.String = jrt.Intern("arbace.g2a.convert$clauses")

var Lit_520 *jrt.String = jrt.Intern("arbace.g2a.convert$clauses$fn__838000349")

var Lit_521 *jrt.String = jrt.Intern("arbace.g2a.convert$comm_clause")

var Lit_522 *jrt.String = jrt.Intern(":=")

var Lit_523 *jrt.String = jrt.Intern("select case")

var Lit_524 *jrt.String = jrt.Intern("arbace.g2a.convert$composite")

var Lit_525 *jrt.String = jrt.Intern("arbace.g2a.convert$composite$fn__838000181")

var Lit_526 *jrt.String = jrt.Intern("arbace.g2a.convert$composite$fn__838000183")

var Lit_527 *jrt.String = jrt.Intern("struct literal key")

var Lit_528 *jrt.String = jrt.Intern(":")

var Lit_529 *jrt.String = jrt.Intern("arbace.g2a.convert$const_val")

var Lit_530 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file")

var Lit_531 *jrt.String = jrt.Intern("(in-ns '")

var Lit_532 *jrt.String = jrt.Intern(")")

var Lit_533 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529")

var Lit_534 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529$fn__838000531")

var Lit_535 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529$fn__838000536")

var Lit_536 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000487")

var Lit_537 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000490")

var Lit_538 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000496")

var Lit_539 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000501")

var Lit_540 *jrt.String = jrt.Intern("import")

var Lit_541 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516")

var Lit_542 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516$fn__838000520")

var Lit_543 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516$fn__838000523")

var Lit_544 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000539")

var Lit_545 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000541")

var Lit_546 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543")

var Lit_547 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000544")

var Lit_548 *jrt.String = jrt.Intern("//go:build")

var Lit_549 *jrt.String = jrt.Intern("// +build")

var Lit_550 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000546")

var Lit_551 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000548")

var Lit_552 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000550")

var Lit_553 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000554")

var Lit_554 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559")

var Lit_555 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560")

var Lit_556 *jrt.String = jrt.Intern("declaration")

var Lit_557 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560$fn__838000561")

var Lit_558 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560$fn__838000564")

var Lit_559 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000567")

var Lit_560 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000571")

var Lit_561 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576")

var Lit_562 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578")

var Lit_563 *jrt.String = jrt.Intern("\r")

var Lit_564 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578$fn__838000586")

var Lit_565 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578$fn__838000592")

var Lit_566 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$inside_of__838000504")

var Lit_567 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$inside_of__838000504$fn__838000509")

var Lit_568 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481")

var Lit_569 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481$fn__838000482")

var Lit_570 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481$fn__838000482$fn__838000483")

var Lit_571 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package")

var Lit_572 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646")

var Lit_573 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646$fn__838000647")

var Lit_574 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646$fn__838000647$fn__838000648")

var Lit_575 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656")

var Lit_576 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657")

var Lit_577 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658")

var Lit_578 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$fn__838000675")

var Lit_579 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665")

var Lit_580 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666")

var Lit_581 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667")

var Lit_582 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667$fn__838000668")

var Lit_583 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667$fn__838000668$fn__838000669")

var Lit_584 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000694")

var Lit_585 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684")

var Lit_586 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685")

var Lit_587 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686")

var Lit_588 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686$fn__838000687")

var Lit_589 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686$fn__838000687$fn__838000688")

var Lit_590 *jrt.String = jrt.Intern("arbace.g2a.convert$count_node_BANG_")

var Lit_591 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings")

var Lit_592 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215")

var Lit_593 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$fn__838000221")

var Lit_594 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$fn__838000226")

var Lit_595 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$mk__838000223")

var Lit_596 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000229")

var Lit_597 *jrt.String = jrt.Intern("var without type")

var Lit_598 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000229$mk__838000232")

var Lit_599 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000235")

var Lit_600 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_name")

var Lit_601 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_stmt_QMARK_")

var Lit_602 *jrt.String = jrt.Intern("arbace.g2a.convert$define_binding")

var Lit_603 *jrt.String = jrt.Intern("arbace.g2a.convert$define_target")

var Lit_604 *jrt.String = jrt.Intern("arbace.g2a.convert$dir_form")

var Lit_605 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_args")

var Lit_606 *jrt.String = jrt.Intern(" ")

var Lit_607 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta")

var Lit_608 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta$fn__838000379")

var Lit_609 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta$fn__838000379$fn__838000380")

var Lit_610 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_name")

var Lit_611 *jrt.String = jrt.Intern("//go:")

var Lit_612 *jrt.String = jrt.Intern("arbace.g2a.convert$doc_of")

var Lit_613 *jrt.String = jrt.Intern("arbace.g2a.convert$eval838000004$loading__1927001464__auto____838000005")

var Lit_614 *jrt.String = jrt.Intern("arbace.g2a.convert$eval838000008$fn__838000009")

var Lit_615 *jrt.String = jrt.Intern("arbace.g2a.convert$expr")

var Lit_616 *jrt.String = jrt.Intern("ellipsis outside a parameter list")

var Lit_617 *jrt.String = jrt.Intern("-")

var Lit_618 *jrt.String = jrt.Intern("~")

var Lit_619 *jrt.String = jrt.Intern("unary operator")

var Lit_620 *jrt.String = jrt.Intern("binary operator")

var Lit_621 *jrt.String = jrt.Intern("x.(type) outside a type switch")

var Lit_622 *jrt.String = jrt.Intern("key-value outside a literal")

var Lit_623 *jrt.String = jrt.Intern("expression")

var Lit_624 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000193")

var Lit_625 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000197")

var Lit_626 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000201")

var Lit_627 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$operand__838000199")

var Lit_628 *jrt.String = jrt.Intern("arbace.g2a.convert$fail")

var Lit_629 *jrt.String = jrt.Intern(": ")

var Lit_630 *jrt.String = jrt.Intern(" at ")

var Lit_631 *jrt.String = jrt.Intern("arbace.g2a.convert$fail$fn__838000016")

var Lit_632 *jrt.String = jrt.Intern("arbace.g2a.convert$fields")

var Lit_633 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102")

var Lit_634 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110")

var Lit_635 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110$fn__838000111")

var Lit_636 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110$fn__838000111$fn__838000112")

var Lit_637 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives")

var Lit_638 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426")

var Lit_639 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426$fn__838000427")

var Lit_640 *jrt.String = jrt.Intern("//line ")

var Lit_641 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426$fn__838000427$fn__838000428")

var Lit_642 *jrt.String = jrt.Intern("arbace.g2a.convert$file_stem")

var Lit_643 *jrt.String = jrt.Intern("arbace.g2a.convert$fn_sig_forms")

var Lit_644 *jrt.String = jrt.Intern("arbace.g2a.convert$form")

var Lit_645 *jrt.String = jrt.Intern("arbace.g2a.convert$free_directive")

var Lit_646 *jrt.String = jrt.Intern("arbace.g2a.convert$func_decl")

var Lit_647 *jrt.String = jrt.Intern("arbace.g2a.convert$func_lit")

var Lit_648 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives")

var Lit_649 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000251")

var Lit_650 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000256")

var Lit_651 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000267")

var Lit_652 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000273")

var Lit_653 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000273$fn__838000278")

var Lit_654 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$inside_QMARK___838000258")

var Lit_655 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$inside_QMARK___838000258$fn__838000260")

var Lit_656 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl")

var Lit_657 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$fn__838000410")

var Lit_658 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$spec__838000406")

var Lit_659 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$spec_vec__838000415")

var Lit_660 *jrt.String = jrt.Intern("arbace.g2a.convert$generic_decl_QMARK_")

var Lit_661 *jrt.String = jrt.Intern("arbace.g2a.convert$group_marks")

var Lit_662 *jrt.String = jrt.Intern("arbace.g2a.convert$group_marks$fn__838000092")

var Lit_663 *jrt.String = jrt.Intern("arbace.g2a.convert$ident")

var Lit_664 *jrt.String = jrt.Intern("arbace.g2a.convert$ident_name")

var Lit_665 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form")

var Lit_666 *jrt.String = jrt.Intern(":else")

var Lit_667 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form$fn__838000324")

var Lit_668 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form$fn__838000337")

var Lit_669 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of")

var Lit_670 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457")

var Lit_671 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458")

var Lit_672 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459")

var Lit_673 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459$fn__838000460")

var Lit_674 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459$fn__838000460$fn__838000461")

var Lit_675 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order")

var Lit_676 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604")

var Lit_677 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605")

var Lit_678 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$fn__838000606")

var Lit_679 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$fn__838000606$one__838000610")

var Lit_680 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$one__838000622")

var Lit_681 *jrt.String = jrt.Intern("arbace.g2a.convert$init_vec")

var Lit_682 *jrt.String = jrt.Intern("arbace.g2a.convert$inits")

var Lit_683 *jrt.String = jrt.Intern("arbace.g2a.convert$inst_meta")

var Lit_684 *jrt.String = jrt.Intern("arbace.g2a.convert$instantiation")

var Lit_685 *jrt.String = jrt.Intern(".-")

var Lit_686 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems")

var Lit_687 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122")

var Lit_688 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122$fn__838000123")

var Lit_689 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122$fn__838000123$fn__838000124")

var Lit_690 *jrt.String = jrt.Intern("arbace.g2a.convert$label_kw")

var Lit_691 *jrt.String = jrt.Intern("arbace.g2a.convert$line")

var Lit_692 *jrt.String = jrt.Intern("arbace.g2a.convert$line_of")

var Lit_693 *jrt.String = jrt.Intern("arbace.g2a.convert$lit_at")

var Lit_694 *jrt.String = jrt.Intern("arbace.g2a.convert$mark_ungrouped")

var Lit_695 *jrt.String = jrt.Intern("arbace.g2a.convert$mark_ungrouped$fn__838000095")

var Lit_696 *jrt.String = jrt.Intern("arbace.g2a.convert$max_pos")

var Lit_697 *jrt.String = jrt.Intern("arbace.g2a.convert$max_pos$walk__838000036")

var Lit_698 *jrt.String = jrt.Intern("arbace.g2a.convert$munge_name")

var Lit_699 *jrt.String = jrt.Intern("arbace.g2a.convert$nf")

var Lit_700 *jrt.String = jrt.Intern("arbace.g2a.convert$note_BANG_")

var Lit_701 *jrt.String = jrt.Intern("arbace.g2a.convert$nt")

var Lit_702 *jrt.String = jrt.Intern("arbace.g2a.convert$obj")

var Lit_703 *jrt.String = jrt.Intern("arbace.g2a.convert$package_form")

var Lit_704 *jrt.String = jrt.Intern("amd64")

var Lit_705 *jrt.String = jrt.Intern("arbace.g2a.convert$package_form$fn__838000638")

var Lit_706 *jrt.String = jrt.Intern("arbace.g2a.convert$parse_pos")

var Lit_707 *jrt.String = jrt.Intern("arbace.g2a.convert$pkg_ident_QMARK_")

var Lit_708 *jrt.String = jrt.Intern("arbace.g2a.convert$pos_line")

var Lit_709 *jrt.String = jrt.Intern("arbace.g2a.convert$positions")

var Lit_710 *jrt.String = jrt.Intern("arbace.g2a.convert$positions$fn__838000030")

var Lit_711 *jrt.String = jrt.Intern("arbace.g2a.convert$relined")

var Lit_712 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000071")

var Lit_713 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000073")

var Lit_714 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000075")

var Lit_715 *jrt.String = jrt.Intern("arbace.g2a.convert$selection_via")

var Lit_716 *jrt.String = jrt.Intern("arbace.g2a.convert$selector_form")

var Lit_717 *jrt.String = jrt.Intern("selector")

var Lit_718 *jrt.String = jrt.Intern("arbace.g2a.convert$signature")

var Lit_719 *jrt.String = jrt.Intern("arbace.g2a.convert$simple_stmt")

var Lit_720 *jrt.String = jrt.Intern("arbace.g2a.convert$start")

var Lit_721 *jrt.String = jrt.Intern("no start for")

var Lit_722 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt")

var Lit_723 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_")

var Lit_724 *jrt.String = jrt.Intern("++")

var Lit_725 *jrt.String = jrt.Intern("declaration outside a statement list")

var Lit_726 *jrt.String = jrt.Intern("statement")

var Lit_727 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_$fn__838000362")

var Lit_728 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_$tgt__838000371")

var Lit_729 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_list")

var Lit_730 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms")

var Lit_731 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298")

var Lit_732 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$fn__838000307")

var Lit_733 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$fn__838000309")

var Lit_734 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$kind_of__838000305")

var Lit_735 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$fn__838000290")

var Lit_736 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$fn__838000296")

var Lit_737 *jrt.String = jrt.Intern("arbace.g2a.convert$string_value")

var Lit_738 *jrt.String = jrt.Intern("arbace.g2a.convert$tagged")

var Lit_739 *jrt.String = jrt.Intern("arbace.g2a.convert$targets")

var Lit_740 *jrt.String = jrt.Intern("arbace.g2a.convert$targs")

var Lit_741 *jrt.String = jrt.Intern("arbace.g2a.convert$type_form")

var Lit_742 *jrt.String = jrt.Intern("unary type")

var Lit_743 *jrt.String = jrt.Intern("type selector")

var Lit_744 *jrt.String = jrt.Intern("binary type")

var Lit_745 *jrt.String = jrt.Intern("arbace.g2a.convert$type_form$fn__838000141")

var Lit_746 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params")

var Lit_747 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145")

var Lit_748 *jrt.String = jrt.Intern("any")

var Lit_749 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152")

var Lit_750 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152$fn__838000153")

var Lit_751 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152$fn__838000153$fn__838000154")

var Lit_752 *jrt.String = jrt.Intern("arbace.g2a.convert$unparen")

var Lit_753 *jrt.String = jrt.Intern("arbace.g2a.convert$untyped_const_QMARK_")

var Lit_754 *jrt.String = jrt.Intern("arbace.g2a.convert$value_spec_target")

var Lit_755 *jrt.String = jrt.Intern("arbace.g2a.convert$value_spec_target$mk__838000401")

var Lit_756 *jrt.String = jrt.Intern("arbace.g2a.convert$vec_at")

var Lit_757 *jrt.String = jrt.Intern("arbace.g2a.convert$with_line")

var Lit_758 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos")

var Lit_759 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos$fn__838000055")

var Lit_760 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos$fn__838000060")

var Lit_761 *jrt.String = jrt.Intern("dynamic")

var Lit_762 *jrt.String = jrt.Intern("column")

var Lit_763 *jrt.String = jrt.Intern("arbace/g2a/convert.ae")

var Lit_764 *jrt.String = jrt.Intern("arglists")

var Lit_765 *jrt.String = jrt.Intern("k")

var Lit_766 *jrt.String = jrt.Intern("n")

var Lit_767 *jrt.String = jrt.Intern("msg")

var Lit_768 *jrt.String = jrt.Intern("s")

var Lit_769 *jrt.String = jrt.Intern("String")

var Lit_770 *jrt.String = jrt.Intern("The position string of a node's start, go/ast's Pos().")

var Lit_771 *jrt.String = jrt.Intern("The position fields of a node: {:field [line col]}.")

var Lit_772 *jrt.String = jrt.Intern("The greatest position [line col] in a node's subtree.")

var Lit_773 *jrt.String = jrt.Intern("xs")

var Lit_774 *jrt.String = jrt.Intern("A list form beginning on line l, built from node n (whose positions it keeps for :full).")

var Lit_775 *jrt.String = jrt.Intern("x (a symbol, list or vector) with line l and node n's positions.")

var Lit_776 *jrt.String = jrt.Intern("m")

var Lit_777 *jrt.String = jrt.Intern("x with more positions for mode :full: m maps keys to position strings (nil ones skipped).")

var Lit_778 *jrt.String = jrt.Intern("b")

var Lit_779 *jrt.String = jrt.Intern("with-line")

var Lit_780 *jrt.String = jrt.Intern("x with the public metadata m merged in.")

var Lit_781 *jrt.String = jrt.Intern("arbace.g2a.lit.Lit")

var Lit_782 *jrt.String = jrt.Intern("A Lit placed on line l (layout records it in its parent).")

var Lit_783 *jrt.String = jrt.Intern("x with every form inside on line l and no positions (an implicitly repeated init).")

var Lit_784 *jrt.String = jrt.Intern("Unqualified heads of Go context (§13.5): a call of a Go name among them is go/call.")

var Lit_785 *jrt.String = jrt.Intern("The type forms of the type arguments of an instance annotation.")

var Lit_786 *jrt.String = jrt.Intern("explicit")

var Lit_787 *jrt.String = jrt.Intern("{:inst [...]} for the use of a generic function or method whose type arguments are not\n  all in the source (explicit: how many are).")

var Lit_788 *jrt.String = jrt.Intern("An identifier as a symbol, a literal (the universe's true, false, nil) or (go/id \"x\").")

var Lit_789 *jrt.String = jrt.Intern("The Go string value of a STRING basic literal (import paths, struct tags).")

var Lit_790 *jrt.String = jrt.Intern("declared")

var Lit_791 *jrt.String = jrt.Intern("field-list-vec")

var Lit_792 *jrt.String = jrt.Intern("sym")

var Lit_793 *jrt.String = jrt.Intern("The symbol sym with the type form t as :tag.")

var Lit_794 *jrt.String = jrt.Intern("private")

var Lit_795 *jrt.String = jrt.Intern("syms")

var Lit_796 *jrt.String = jrt.Intern("Names of one field after the first get :go/group inside generic declarations (proposed\n  amendment: gc's output depends on field groups there).")

var Lit_797 *jrt.String = jrt.Intern("elems")

var Lit_798 *jrt.String = jrt.Intern("names-only")

var Lit_799 *jrt.String = jrt.Intern("Inside generic declarations, a name declared apart from the name before it although of an\n  equal type gets :go/grouped false, so that the printer does not group them (A1).")

var Lit_800 *jrt.String = jrt.Intern("pos-str")

var Lit_801 *jrt.String = jrt.Intern("groups")

var Lit_802 *jrt.String = jrt.Intern("The kept doc text of a comment group position, recording it as kept; nil when empty.")

var Lit_803 *jrt.String = jrt.Intern("keys")

var Lit_804 *jrt.String = jrt.Intern("The elements of a struct type's fields, or of a parameter/result vector: a tagged name per\n  name, a type form for an unnamed field (embedded or unnamed parameter). opts: :struct (tags,\n  docs), :variadic (an Ellipsis type is the last parameter).")

var Lit_805 *jrt.String = jrt.Intern("The type form of a type expression node.")

var Lit_806 *jrt.String = jrt.Intern("ft")

var Lit_807 *jrt.String = jrt.Intern("[params-vector results...] of a func-type: the parameter vector (tagged with a single\n  unnamed result) and, for named or several results, :results [...].")

var Lit_808 *jrt.String = jrt.Intern("&&")

var Lit_809 *jrt.String = jrt.Intern("!=")

var Lit_810 *jrt.String = jrt.Intern("%")

var Lit_811 *jrt.String = jrt.Intern("<=")

var Lit_812 *jrt.String = jrt.Intern("bit-or")

var Lit_813 *jrt.String = jrt.Intern(">=")

var Lit_814 *jrt.String = jrt.Intern("bit-and")

var Lit_815 *jrt.String = jrt.Intern("<")

var Lit_816 *jrt.String = jrt.Intern("&^")

var Lit_817 *jrt.String = jrt.Intern("bit-and-not")

var Lit_818 *jrt.String = jrt.Intern("||")

var Lit_819 *jrt.String = jrt.Intern("==")

var Lit_820 *jrt.String = jrt.Intern("^")

var Lit_821 *jrt.String = jrt.Intern("bit-xor")

var Lit_822 *jrt.String = jrt.Intern("+")

var Lit_823 *jrt.String = jrt.Intern(">")

var Lit_824 *jrt.String = jrt.Intern("bit-not")

var Lit_825 *jrt.String = jrt.Intern("!")

var Lit_826 *jrt.String = jrt.Intern("addr")

var Lit_827 *jrt.String = jrt.Intern("<-")

var Lit_828 *jrt.String = jrt.Intern("<!")

var Lit_829 *jrt.String = jrt.Intern("-=")

var Lit_830 *jrt.String = jrt.Intern("/=")

var Lit_831 *jrt.String = jrt.Intern("%=")

var Lit_832 *jrt.String = jrt.Intern("*=")

var Lit_833 *jrt.String = jrt.Intern("|=")

var Lit_834 *jrt.String = jrt.Intern("<<=")

var Lit_835 *jrt.String = jrt.Intern(">>=")

var Lit_836 *jrt.String = jrt.Intern("&^=")

var Lit_837 *jrt.String = jrt.Intern("^=")

var Lit_838 *jrt.String = jrt.Intern("&=")

var Lit_839 *jrt.String = jrt.Intern("+=")

var Lit_840 *jrt.String = jrt.Intern("Whether a constant expression is untyped (for §8.3's shifts).")

var Lit_841 *jrt.String = jrt.Intern("A generic type instance (G T...) as (inst G T...): in operands the printer reads as\n  expressions too (new, method-expr; PRINTER-NOTES A5).")

var Lit_842 *jrt.String = jrt.Intern("a")

var Lit_843 *jrt.String = jrt.Intern("A selector expression not in callee position.")

var Lit_844 *jrt.String = jrt.Intern("The head of a builtin call: len, append, ..., or unsafe/Sizeof with the file's name.")

var Lit_845 *jrt.String = jrt.Intern("F[T...] in an expression: (inst F T...), F carrying :inst when the arguments are partial.")

var Lit_846 *jrt.String = jrt.Intern("The form of an expression node.")

var Lit_847 *jrt.String = jrt.Intern("mk")

var Lit_848 *jrt.String = jrt.Intern("Binding or assignment targets: one form, or (values ...).")

var Lit_849 *jrt.String = jrt.Intern("A := target: a new name, or a reused one marked ^:assign.")

var Lit_850 *jrt.String = jrt.Intern("st")

var Lit_851 *jrt.String = jrt.Intern("[target init] of x, y := e...")

var Lit_852 *jrt.String = jrt.Intern("nm")

var Lit_853 *jrt.String = jrt.Intern("{:val v} of a constant name's definition.")

var Lit_854 *jrt.String = jrt.Intern("The let bindings of a local declaration (a decl-stmt), and the kind :let or :let-type.")

var Lit_855 *jrt.String = jrt.Intern("Whether a statement declares (it becomes a let or let-type).")

var Lit_856 *jrt.String = jrt.Intern("c")

var Lit_857 *jrt.String = jrt.Intern("stmts")

var Lit_858 *jrt.String = jrt.Intern("from")

var Lit_859 *jrt.String = jrt.Intern("to")

var Lit_860 *jrt.String = jrt.Intern("For statements stmts in a block spanning [from to] (positions), the directives in the gaps:\n  a vector of n+1 lists, gap k before statement k, gap n after the last.")

var Lit_861 *jrt.String = jrt.Intern("The forms of a statement list stmts spanning the positions (from, to). Declarations become\n  a let (or let-type) whose body is the rest of the list (§7.3). opts :tail: the list ends a\n  function with results, so a final return of one expression is that expression (§6.4).")

var Lit_862 *jrt.String = jrt.Intern("block")

var Lit_863 *jrt.String = jrt.Intern("opts")

var Lit_864 *jrt.String = jrt.Intern("The forms of a block's statements (stmts-forms).")

var Lit_865 *jrt.String = jrt.Intern("A nested Go block as (do ...).")

var Lit_866 *jrt.String = jrt.Intern("else?")

var Lit_867 *jrt.String = jrt.Intern("A branch of if/cond (§7.2): one statement, or (do ...) for a statement list; else? (an else\n  branch): a single if, when or cond is wrapped in do, which an else if is not.")

var Lit_868 *jrt.String = jrt.Intern("The init vector of if, switch, type-switch and for: [target expr] for a :=, [stmt] else.")

var Lit_869 *jrt.String = jrt.Intern("i")

var Lit_870 *jrt.String = jrt.Intern("The end bound of clause i of a switch or select body: the next clause, or the }.")

var Lit_871 *jrt.String = jrt.Intern("tswitch")

var Lit_872 *jrt.String = jrt.Intern("A simple statement in an init or post position.")

var Lit_873 *jrt.String = jrt.Intern("The form of a statement (not a declaration). tail: the last of a function body with\n  results.")

var Lit_874 *jrt.String = jrt.Intern("The signature part of fn: params, results.")

var Lit_875 *jrt.String = jrt.Intern("The name of a //go: directive (\"nosplit\"), else nil.")

var Lit_876 *jrt.String = jrt.Intern("linknamestd")

var Lit_877 *jrt.String = jrt.Intern("generate")

var Lit_878 *jrt.String = jrt.Intern("//go: directives that gc applies by name or to the file, never to the next declaration.")

var Lit_879 *jrt.String = jrt.Intern("Whether the directive attaches to a declaration named decl-name that follows it: gc's\n  pragmas (noder.go) other than linkname naming another declaration, cgo's and the\n  file-level ones.")

var Lit_880 *jrt.String = jrt.Intern("texts")

var Lit_881 *jrt.String = jrt.Intern("The metadata of attached directives (texts in order): {:go/name true|\"args\"|[...]}.")

var Lit_882 *jrt.String = jrt.Intern("d")

var Lit_883 *jrt.String = jrt.Intern("A func-decl with type parameters or a receiver of a generic type, or a generic type spec.")

var Lit_884 *jrt.String = jrt.Intern("dmeta")

var Lit_885 *jrt.String = jrt.Intern("sp")

var Lit_886 *jrt.String = jrt.Intern("extra")

var Lit_887 *jrt.String = jrt.Intern("The target of a package-level value spec: a name or (values ...); docs and directive\n  metadata on the first name.")

var Lit_888 *jrt.String = jrt.Intern("spec-meta")

var Lit_889 *jrt.String = jrt.Intern("dump")

var Lit_890 *jrt.String = jrt.Intern("The dump's directives of file name: [[line col text] ...].")

var Lit_891 *jrt.String = jrt.Intern("The name a directive before declaration d (or spec) would attach to.")

var Lit_892 *jrt.String = jrt.Intern("fe")

var Lit_893 *jrt.String = jrt.Intern("ns-sym")

var Lit_894 *jrt.String = jrt.Intern("The forms of one Go file of the dump: {:name :forms [...] :comments {line [text]}\n  :unplaced [...]} (forms in order: in-ns, go/file, declarations and free-standing\n  directives).")

var Lit_895 *jrt.String = jrt.Intern("The .ae path stem of Go file name in package directory dir (a Go source directory): x for\n  x.go, or x.go when dir has a subdirectory x (a package of that name would own x.ae:\n  proposed amendment).")

var Lit_896 *jrt.String = jrt.Intern("convert-package")

var Lit_897 *jrt.String = jrt.Intern("Converts a dump. opts: :positions (:lines or :full), :ns (the namespace symbol, default from\n  the import path), :src-dir (the package's source directory, for file-name collisions).\n  Returns {:ns sym :package form :files [{:name :stem :forms :comments :unplaced}] :stats}.")
