//line a2g_strings.ae:1
package aot_arbace_g2a_convert

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.g2a.litkn2,asyn3,lityn16,arbace.g2a.typesyn2,tyyn13,arbace.stringyn3,strkn3,dockn5,noteskn5,nodeskn4,nodekn10,paren-exprkn1,xkn9,send-stmtkn10,array-typekn6,lbrackkn8,ellipsiskn7,if-stmtkn2,ifkn4,chankn11,import-speckn4,namekn10,value-speckn4,pathkn10,unary-exprkn6,op-poskn5,nameskn5,identkn8,name-poskn11,return-stmtkn6,returnkn13,composite-litkn4,typekn6,lbracekn9,chan-typekn5,beginkn5,fieldkn8,map-typekn3,mapkn11,case-clausekn4,casekn10,field-listkn7,openingkn4,listkn10,index-exprkn9,decl-stmtkn9,expr-stmtkn4,declkn11,assign-stmtkn10,slice-exprkn3,lhskn9,call-exprkn14,interface-typekn9,interfacekn3,funkn14,key-value-exprkn13,selector-exprkn3,keykn10,empty-stmtkn9,semicolonkn9,type-speckn8,gen-declkn7,tok-poskn12,inc-dec-stmtkn8,for-stmtkn3,forkn12,labeled-stmtkn8,func-litkn5,labelkn9,star-exprkn4,starkn9,func-typekn4,funckn15,index-list-exprkn6,paramskn11,binary-exprkn11,switch-stmtkn6,switchkn10,defer-stmtkn5,deferkn9,basic-litkn9,value-poskn16,type-switch-stmtkn11,struct-typekn6,structkn10,range-stmtkn6,lparenkn16,type-assert-exprkn11,select-stmtkn6,selectkn11,branch-stmtkn7,go-stmtkn2,gokn11,comm-clausekn9,func-declkn10,block-stmtks18,arbace.g2a.convert1,lks18,arbace.g2a.convert3,poskn6,rbracekn4,linekn3,poskn4,elsekn3,usekn3,defkn5,targskn4,instkn4,kindkn8,universekn3,nilkn4,modekn5,constkn5,go-idys2,go2,idkn3,pkgkn5,valueyn9,imaginarykn3,tagks2,go7,groupedkn4,textkn7,struct?yn5,slicekn3,eltks2,go3,tagyn1,&kn3,dirkn4,recvkn4,bothkn4,sendyn4,chanyn9,interfacekn7,methodskn7,indiceskn5,indexyn4,instkn3,lenyn6,structkn6,fieldskn2,opyn5,arrayyn3,...yn5,tildeyn3,mapkn1,ykn3,selyn1,|kn7,resultsyn1,*yn4,funckn7,closingkn7,builtinkn1,tkn4,argskn3,viaks2,go3,viakn11,method-exprkn6,methodkn5,x-posyn11,method-expryn6,spreadyn3,newyn4,convkn3,dotkn7,go-callys2,go4,callkn4,eltskn4,bodykn4,tailks2,go3,endyn2,fnkn3,lowkn4,highkn3,maxkn16,negative-literalyn8,subsliceyn2,oryn3,andkn13,logical-parenks2,go5,parenyn2,>>yn2,<<kn9,shift-tagyn6,assertyn4,agetks18,arbace.g2a.convert5,derefyn5,derefyn6,valuesyn1,_kn6,assignkn3,rhskn3,valkn3,tokkn5,specskn3,letkn6,valueskn20,local-const-repeatedks2,go8,implicitkn17,local-const-groupkn23,local-const-group-splityn4,zerokn3,varkn8,let-typekn11,type-paramskn5,aliaskn18,local-generic-typekn4,stmtkn19,directive-statementys2,go9,directivekn19,labeled-declarationks2,go5,labelks2,go10,label-lineyn3,letyn8,let-typeyn2,doyn4,whenyn2,ifyn4,condkn4,initkn4,condkn11,else-lbracekn11,else-rbracekn5,colonyn7,defaultyn4,casekn4,commyn4,asetyn4,set!kn15,implicit-returnyn6,returnyn5,labelkn4,postyn6,selectyn5,breakyn8,continueyn4,gotoyn11,fallthroughyn5,whileyn3,foryn5,deferkn4,callyn4,inc!yn4,dec!yn11,type-switchyn5,rangeyn6,switchyn2,>!yn2,gokn14,directive-freekn6,externys2,go6,methodys2,go4,funckn10,directiveskn8,implicitkn3,astkn4,filekn5,declskn6,attachkn18,directive-attachedys2,go4,filekn10,go-versionkn7,packagekn5,buildkn4,langkn7,importskn4,freekn5,formskn8,commentskn8,unplacedkn5,innerkn10,in-importskn18,directive-unplacedks18,arbace.g2a.convert3,rawyn5,in-nsyn5,quotekn10,init-orderkn9,positionskn6,configkn8,go-fileskn7,s-fileskn7,h-fileskn10,syso-fileskn7,c-fileskn9,cxx-fileskn7,m-fileskn7,f-fileskn10,swig-fileskn14,swig-cxx-fileskn11,embed-fileskn16,test-embed-filesys2,go7,packagekn5,fileskn4,gooskn6,goarchkn7,goamd64kn7,goarm64kn9,toolchainkn4,tagskn12,goexperimentkn3,cgokn8,compilerkn11,other-fileskn13,test-go-fileskn10,test-fileskn19,file-name-collisionkn2,nskn5,statskn10,underlyingkn5,typeskn10,type-tablekn4,stemkn7,src-dirv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn18,arbace.g2a.convertm2,R8,s603,g2a's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.g2a.lit/Lit (text and value). arbace.g2a.layout writes them as text.v11,arbace.core13,*loaded-libs*v18,arbace.g2a.convert7,*stats*v11,arbace.core5,swap!v11,arbace.core9,update-inv11,arbace.core4,fnilR9,v11,arbace.core3,incl0,R10,v11,arbace.core5,firstv11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core4,seq?v11,arbace.core4,map?v11,arbace.core6,secondv11,arbace.core4,valsR11,v11,arbace.core6,filterv11,arbace.core7,string?v11,arbace.core10,re-matchesp7,\\d+:\\d+R12,v18,arbace.g2a.convert2,ntR13,v18,arbace.g2a.convert2,nfp7,\\d+:\\d+v11,arbace.core4,subsv18,arbace.g2a.convert9,parse-posR14,v18,arbace.g2a.convert5,startR15,R16,R17,R18,R19,v18,arbace.g2a.convert4,failR20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,v11,arbace.core3,seqR38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R95,R96,v18,arbace.g2a.convert8,pos-linev11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core4,keepv11,arbace.core9,volatile!v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core7,vector?v11,arbace.core4,run!v11,arbace.core7,vreset!v11,arbace.core10,chunk-restv11,arbace.core4,nextV2,l0,l0,v11,arbace.core9,with-metav11,arbace.core5,applyR97,v11,arbace.core5,assocv11,arbace.core4,listR98,v18,arbace.g2a.convert9,positionsv11,arbace.core9,vary-metav11,arbace.core6,updatev11,arbace.core5,mergeR99,v11,arbace.core3,notv18,arbace.g2a.convert4,linev11,arbace.core3,vecv11,arbace.core6,empty?R100,R101,v14,arbace.g2a.lit4,lit?v11,arbace.core7,symbol?R102,v11,arbace.core6,dissocv11,arbace.core3,mapv18,arbace.g2a.convert7,relinedv11,arbace.core4,mapvR103,v18,arbace.g2a.convert2,anR104,v16,arbace.g2a.types9,type-formR105,R106,v18,arbace.g2a.convert3,objR107,v18,arbace.g2a.convert5,targsv18,arbace.g2a.convert10,ident-namev18,arbace.g2a.convert7,line-ofv18,arbace.g2a.convert2,atS3,s5,falses4,trues3,nilR108,R109,R110,R111,v18,arbace.g2a.convert6,lit-atv18,arbace.g2a.convert4,formv18,arbace.g2a.convert8,add-metav18,arbace.g2a.convert11,count-node!v11,arbace.core6,symbolv14,arbace.g2a.lit3,litm6,s4,trueTs5,falseFs3,nilnv18,arbace.g2a.convert5,note!R112,R113,v14,arbace.g2a.lit11,string-textv18,arbace.g2a.convert9,inst-metav18,arbace.g2a.convert5,identv11,arbace.core7,keywordR114,v18,arbace.g2a.convert7,unparenv11,arbace.core8,to-arrayR115,v14,arbace.g2a.lit10,bytes-formv14,arbace.g2a.lit9,rune-formv14,arbace.g2a.lit12,string-bytesR116,v14,arbace.g2a.lit10,imag-innerv14,arbace.g2a.lit14,float-text-litv14,arbace.g2a.lit10,rune-valuev14,arbace.g2a.lit7,int-litR117,v18,arbace.g2a.convert9,*generic*v11,arbace.core4,consR118,v11,arbace.core4,restv11,arbace.core11,map-indexedv11,arbace.core9,contains?R119,v11,arbace.core4,not=v18,arbace.g2a.convert11,*kept-docs*R120,v18,arbace.g2a.convert14,mark-ungroupedv11,arbace.core6,mapcatR8,v18,arbace.g2a.convert9,type-formv18,arbace.g2a.convert6,doc-ofv11,arbace.core6,concatR121,R122,R123,v18,arbace.g2a.convert12,string-valuev18,arbace.g2a.convert8,*groups*V1,R124,v18,arbace.g2a.convert11,group-marksv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv18,arbace.g2a.convert6,taggedv11,arbace.core10,chunk-consv11,arbace.core5,chunkv18,arbace.g2a.convert9,signatureR125,R126,R127,R128,v11,arbace.core9,namespacev16,arbace.g2a.types19,reserved-type-headsR121,R129,R129,R129,R130,v18,arbace.g2a.convert15,interface-elemsR131,R132,R133,R134,R135,R136,v18,arbace.g2a.convert6,fieldsR137,m2,R120,TR138,R121,R139,R140,R139,v18,arbace.g2a.convert4,exprR141,v18,arbace.g2a.convert10,pkg-ident?R142,R143,R144,R145,R146,R147,R148,v18,arbace.g2a.convert6,vec-atR148,v18,arbace.g2a.convert8,with-posv11,arbace.core11,select-keysV2,R43,R149,V2,R43,R149,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv18,arbace.g2a.convert14,untyped-const?R150,S3,s4,imags4,reals7,complexv11,arbace.core6,every?R151,v16,arbace.g2a.types8,untyped?S2,s2,>>s2,<<R152,S1,R134,R134,R153,R154,R155,S2,R156,R37,R157,R158,v18,arbace.g2a.convert7,as-instv18,arbace.g2a.convert13,selection-viav11,arbace.core3,popR159,v11,arbace.core4,peekv18,arbace.g2a.convert12,builtin-nameR160,R156,v18,arbace.g2a.convert14,reserved-headsl1,R161,R159,R162,v18,arbace.g2a.convert9,call-argsR163,R164,R158,R134,R165,R3,R166,v18,arbace.g2a.convert12,fn-sig-formsv18,arbace.g2a.convert9,stmt-listR167,R168,R169,v18,arbace.g2a.convert9,block-posS2,s3,INTs5,FLOATv18,arbace.g2a.convert9,basic-litv18,arbace.g2a.convert9,unary-opsv18,arbace.g2a.convert9,compositeR170,R171,R172,S6,R15,R72,R35,R84,R38,R53,R173,v18,arbace.g2a.convert4,callR174,v18,arbace.g2a.convert13,selector-formv18,arbace.g2a.convert10,binary-opsv18,arbace.g2a.convert8,nary-opsS2,R175,R176,R177,m2,R178,TS2,R179,R180,R181,R182,v18,arbace.g2a.convert13,instantiationR183,v18,arbace.g2a.convert8,func-litR184,R185,R186,R186,R187,R188,R189,v18,arbace.g2a.convert7,targetsv18,arbace.g2a.convert13,define-targetv18,arbace.g2a.convert5,initsv14,arbace.g2a.lit10,const-formR190,v16,arbace.g2a.types10,const-kindR191,R192,R193,R194,v18,arbace.g2a.convert9,const-valR195,R196,R197,R198,R199,R200,R201,R202,v18,arbace.g2a.convert11,type-paramsv18,arbace.g2a.convert13,generic-decl?R203,R204,v18,arbace.g2a.convert10,decl-stmt?R205,v18,arbace.g2a.convert11,bindings-ofv18,arbace.g2a.convert13,decl-bindingsv18,arbace.g2a.convert14,define-bindingv18,arbace.g2a.convert8,*placed*R206,R207,v11,arbace.core4,somev11,arbace.core6,removev11,arbace.core6,reducev18,arbace.g2a.convert9,*fn-dirs*v11,arbace.core6,repeatv18,arbace.g2a.convert7,max-posv11,arbace.core12,keep-indexedv18,arbace.g2a.convert14,gap-directivesv18,arbace.g2a.convert8,dir-formR208,R209,v18,arbace.g2a.convert8,label-kwR210,R211,R212,v11,arbace.core8,identityv18,arbace.g2a.convert4,stmtv11,arbace.core5,doallv18,arbace.g2a.convert11,stmts-formsR213,R213,S3,R214,R215,R216,R213,v18,arbace.g2a.convert11,simple-stmtR217,R218,R214,v18,arbace.g2a.convert8,init-vecR216,v18,arbace.g2a.convert6,branchR215,v18,arbace.g2a.convert7,if-formR219,R220,R221,R222,R223,v18,arbace.g2a.convert11,case-clausev18,arbace.g2a.convert12,clause-boundR224,R222,R223,v11,arbace.core1,=v18,arbace.g2a.convert10,assign-opsR225,R226,R226,R226,v18,arbace.g2a.convert5,stmt*S5,R83,R65,R89,R77,R86,R227,R228,R229,R229,R230,R231,v18,arbace.g2a.convert11,comm-clausem8,s5,breakR232,s8,continueR233,s4,gotoR234,s11,fallthroughR235,R236,R236,R237,v18,arbace.g2a.convert6,assignR238,R239,R240,R241,R242,v18,arbace.g2a.convert7,clausesR243,m2,R188,TR244,R245,R246,v18,arbace.g2a.convert11,block-formsv13,arbace.string12,starts-with?v13,arbace.string8,index-ofl5,v13,arbace.string5,trimlv18,arbace.g2a.convert14,directive-namev18,arbace.g2a.convert19,free-standing-namesv13,arbace.string5,splitv18,arbace.g2a.convert14,directive-argsp3,\\s+R247,R207,S2,R74,R45,m2,R248,TR249,R250,R186,m2,R203,Tv18,arbace.g2a.convert17,value-spec-targetR251,S2,s1,_s1,.R252,S2,s1,_s1,.R253,R254,R255,v18,arbace.g2a.convert15,file-directivesv11,arbace.core4,atomv11,arbace.core4,lastv11,arbace.core6,get-inv18,arbace.g2a.convert14,directive-metaR256,R257,R258,R259,R260,R261,R262,R263,v18,arbace.g2a.convert14,free-directivev11,arbace.core4,takel2,R264,v18,arbace.g2a.convert8,gen-declv18,arbace.g2a.convert9,func-declv11,arbace.core5,rangeR265,R266,R267,v18,arbace.g2a.convert11,attachable?v18,arbace.g2a.convert9,decl-nameR268,R269,v11,arbace.core7,sort-byv18,arbace.g2a.convert10,imports-ofv13,arbace.string11,split-linesv13,arbace.string7,replacev11,arbace.core6,vectorR270,R271,R272,R273,p16,(.*):(\\d+):(\\d+)R186,R274,p4,[.-]R275,R276,R277,v11,arbace.core4,sortV9,R278,R279,R280,R281,R282,R283,R284,R285,R286,R287,R288,R289,v18,arbace.g2a.convert10,munge-namep1,/v11,arbace.core9,array-mapR290,R291,R292,R293,R294,R295,R296,R297,R298,R299,R300,R301,R302,v18,arbace.g2a.convert10,init-orderR303,R304,v16,arbace.g2a.types10,ns-name-ofv18,arbace.g2a.convert12,package-formR305,R306,R307,v18,arbace.g2a.convert6,*dump*v16,arbace.g2a.types7,*table*R308,v16,arbace.g2a.types5,*pkg*v16,arbace.g2a.types12,*underlying*v18,arbace.g2a.convert12,convert-fileR309,v18,arbace.g2a.convert9,file-stemR310,v16,arbace.g2a.types9,*imports*S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.S2,s1,_s1,.")

var Lit_1 *jrt.String = jrt.Intern("=")

var Lit_2 *jrt.String = jrt.Intern("assignment ")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.convert$at$fn__838000046")

var Lit_4 *jrt.String = jrt.Intern("arbace.g2a.convert$at$fn__838000046$fn__838000048")

var Lit_5 *jrt.String = jrt.Intern("cgo_")

var Lit_6 *jrt.String = jrt.Intern("linkname")

var Lit_7 *jrt.String = jrt.Intern("")

var Lit_8 *jrt.String = jrt.Intern("STRING")

var Lit_9 *jrt.String = jrt.Intern("IMAG")

var Lit_10 *jrt.String = jrt.Intern("FLOAT")

var Lit_11 *jrt.String = jrt.Intern("CHAR")

var Lit_12 *jrt.String = jrt.Intern("INT")

var Lit_13 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_14 *jrt.String = jrt.Intern("builtin")

var Lit_15 *jrt.String = jrt.Intern("conversion arity")

var Lit_16 *jrt.String = jrt.Intern("arbace.g2a.convert$call$fn__838000173")

var Lit_17 *jrt.String = jrt.Intern(".")

var Lit_18 *jrt.String = jrt.Intern("arbace.g2a.convert$case_clause$fn__838000346")

var Lit_19 *jrt.String = jrt.Intern("arbace.g2a.convert$clauses$fn__838000349")

var Lit_20 *jrt.String = jrt.Intern(":=")

var Lit_21 *jrt.String = jrt.Intern("select case")

var Lit_22 *jrt.String = jrt.Intern("_")

var Lit_23 *jrt.String = jrt.Intern("arbace.g2a.convert$composite$fn__838000181")

var Lit_24 *jrt.String = jrt.Intern("arbace.g2a.convert$composite$fn__838000183")

var Lit_25 *jrt.String = jrt.Intern("struct literal key")

var Lit_26 *jrt.String = jrt.Intern(":")

var Lit_27 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481")

var Lit_28 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000487")

var Lit_29 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000490")

var Lit_30 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000496")

var Lit_31 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000501")

var Lit_32 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$inside_of__838000504")

var Lit_33 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516")

var Lit_34 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529")

var Lit_35 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000539")

var Lit_36 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000541")

var Lit_37 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543")

var Lit_38 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000554")

var Lit_39 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559")

var Lit_40 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000571")

var Lit_41 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576")

var Lit_42 *jrt.String = jrt.Intern("(in-ns '")

var Lit_43 *jrt.String = jrt.Intern(")")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529$fn__838000531")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$attach_meta__838000529$fn__838000536")

var Lit_46 *jrt.String = jrt.Intern("import")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516$fn__838000520")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000516$fn__838000523")

var Lit_49 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000544")

var Lit_50 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000546")

var Lit_51 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000548")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000543$fn__838000550")

var Lit_53 *jrt.String = jrt.Intern("//go:build")

var Lit_54 *jrt.String = jrt.Intern("// +build")

var Lit_55 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560")

var Lit_56 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000567")

var Lit_57 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560$fn__838000561")

var Lit_58 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000559$fn__838000560$fn__838000564")

var Lit_59 *jrt.String = jrt.Intern("declaration")

var Lit_60 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578")

var Lit_61 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578$fn__838000586")

var Lit_62 *jrt.String = jrt.Intern("\r")

var Lit_63 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$fn__838000576$fn__838000578$fn__838000592")

var Lit_64 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$inside_of__838000504$fn__838000509")

var Lit_65 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481$fn__838000482")

var Lit_66 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file$iter__838000477__838000481$fn__838000482$fn__838000483")

var Lit_67 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646")

var Lit_68 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656")

var Lit_69 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646$fn__838000647")

var Lit_70 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000642__838000646$fn__838000647$fn__838000648")

var Lit_71 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657")

var Lit_72 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658")

var Lit_73 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684")

var Lit_74 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000694")

var Lit_75 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665")

var Lit_76 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$fn__838000675")

var Lit_77 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666")

var Lit_78 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667")

var Lit_79 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667$fn__838000668")

var Lit_80 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$fn__838000658$iter__838000659__838000665$fn__838000666$iter__838000661__838000667$fn__838000668$fn__838000669")

var Lit_81 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685")

var Lit_82 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686")

var Lit_83 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686$fn__838000687")

var Lit_84 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package$iter__838000652__838000656$fn__838000657$iter__838000678__838000684$fn__838000685$iter__838000680__838000686$fn__838000687$fn__838000688")

var Lit_85 *jrt.String = jrt.Intern("const")

var Lit_86 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215")

var Lit_87 *jrt.String = jrt.Intern("var")

var Lit_88 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000229")

var Lit_89 *jrt.String = jrt.Intern("type")

var Lit_90 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000235")

var Lit_91 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$fn__838000221")

var Lit_92 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$mk__838000223")

var Lit_93 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000215$fn__838000226")

var Lit_94 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings$fn__838000229$mk__838000232")

var Lit_95 *jrt.String = jrt.Intern("var without type")

var Lit_96 *jrt.String = jrt.Intern(" ")

var Lit_97 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta$fn__838000379")

var Lit_98 *jrt.String = jrt.Intern("go")

var Lit_99 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta$fn__838000379$fn__838000380")

var Lit_100 *jrt.String = jrt.Intern("//go:")

var Lit_101 *jrt.String = jrt.Intern("ellipsis outside a parameter list")

var Lit_102 *jrt.String = jrt.Intern("-")

var Lit_103 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000193")

var Lit_104 *jrt.String = jrt.Intern("~")

var Lit_105 *jrt.String = jrt.Intern("unary operator")

var Lit_106 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000197")

var Lit_107 *jrt.String = jrt.Intern("binary operator")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$operand__838000199")

var Lit_109 *jrt.String = jrt.Intern("arbace.g2a.convert$expr$fn__838000201")

var Lit_110 *jrt.String = jrt.Intern("x.(type) outside a type switch")

var Lit_111 *jrt.String = jrt.Intern("key-value outside a literal")

var Lit_112 *jrt.String = jrt.Intern("expression")

var Lit_113 *jrt.String = jrt.Intern(": ")

var Lit_114 *jrt.String = jrt.Intern(" at ")

var Lit_115 *jrt.String = jrt.Intern("arbace.g2a.convert$fail$fn__838000016")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110")

var Lit_118 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110$fn__838000111")

var Lit_119 *jrt.String = jrt.Intern("arbace.g2a.convert$fields$fn__838000102$iter__838000106__838000110$fn__838000111$fn__838000112")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426")

var Lit_121 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426$fn__838000427")

var Lit_122 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives$iter__838000422__838000426$fn__838000427$fn__838000428")

var Lit_123 *jrt.String = jrt.Intern("//line ")

var Lit_124 *jrt.String = jrt.Intern("/")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000251")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000256")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$inside_QMARK___838000258")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000267")

var Lit_129 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000273")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$fn__838000273$fn__838000278")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives$inside_QMARK___838000258$fn__838000260")

var Lit_132 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$spec__838000406")

var Lit_133 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$fn__838000410")

var Lit_134 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl$spec_vec__838000415")

var Lit_135 *jrt.String = jrt.Intern("arbace.g2a.convert$group_marks$fn__838000092")

var Lit_136 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form$fn__838000324")

var Lit_137 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form$fn__838000337")

var Lit_138 *jrt.String = jrt.Intern(":else")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457")

var Lit_140 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458")

var Lit_141 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459")

var Lit_142 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459$fn__838000460")

var Lit_143 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of$iter__838000451__838000457$fn__838000458$iter__838000453__838000459$fn__838000460$fn__838000461")

var Lit_144 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604")

var Lit_145 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605")

var Lit_146 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$fn__838000606")

var Lit_147 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$one__838000622")

var Lit_148 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order$iter__838000600__838000604$fn__838000605$fn__838000606$one__838000610")

var Lit_149 *jrt.String = jrt.Intern(".-")

var Lit_150 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122")

var Lit_151 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122$fn__838000123")

var Lit_152 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems$iter__838000118__838000122$fn__838000123$fn__838000124")

var Lit_153 *jrt.String = jrt.Intern("arbace.g2a.convert$mark_ungrouped$fn__838000095")

var Lit_154 *jrt.String = jrt.Intern("arbace.g2a.convert$max_pos$walk__838000036")

var Lit_155 *jrt.String = jrt.Intern("arbace.g2a.convert$package_form$fn__838000638")

var Lit_156 *jrt.String = jrt.Intern("amd64")

var Lit_157 *jrt.String = jrt.Intern("arbace.g2a.convert$positions$fn__838000030")

var Lit_158 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000071")

var Lit_159 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000073")

var Lit_160 *jrt.String = jrt.Intern("arbace.g2a.convert$relined$fn__838000075")

var Lit_161 *jrt.String = jrt.Intern("selector")

var Lit_162 *jrt.String = jrt.Intern("no start for")

var Lit_163 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_$fn__838000362")

var Lit_164 *jrt.String = jrt.Intern("true")

var Lit_165 *jrt.String = jrt.Intern("++")

var Lit_166 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_$tgt__838000371")

var Lit_167 *jrt.String = jrt.Intern("declaration outside a statement list")

var Lit_168 *jrt.String = jrt.Intern("statement")

var Lit_169 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$fn__838000290")

var Lit_170 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$fn__838000296")

var Lit_171 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298")

var Lit_172 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$kind_of__838000305")

var Lit_173 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$fn__838000307")

var Lit_174 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms$build__838000298$fn__838000309")

var Lit_175 *jrt.String = jrt.Intern("unary type")

var Lit_176 *jrt.String = jrt.Intern("type selector")

var Lit_177 *jrt.String = jrt.Intern("|")

var Lit_178 *jrt.String = jrt.Intern("arbace.g2a.convert$type_form$fn__838000141")

var Lit_179 *jrt.String = jrt.Intern("binary type")

var Lit_180 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145")

var Lit_181 *jrt.String = jrt.Intern("any")

var Lit_182 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152")

var Lit_183 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152$fn__838000153")

var Lit_184 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params$fn__838000145$iter__838000148__838000152$fn__838000153$fn__838000154")

var Lit_185 *jrt.String = jrt.Intern("arbace.g2a.convert$value_spec_target$mk__838000401")

var Lit_186 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos$fn__838000055")

var Lit_187 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos$fn__838000060")

var Lit_188 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,kyn1,nyn3,msgkn3,tagyn6,Stringyn1,syn1,lyn1,&yn2,xsyn1,xyn1,myn1,byn18,arbace.g2a.lit.Lityn3,posyn4,instyn8,explicitkn8,declaredyn3,symyn1,tkn7,privateyn4,symsyn5,elemsyn10,names-onlyyn7,pos-stryn6,groupsyn10,field-listkn4,keysyn7,struct?yn2,ftyn2,>>yn3,andyn2,!=yn1,*yn1,%yn2,<=yn6,bit-oryn1,/yn1,-yn2,>=yn7,bit-andyn1,<yn2,<<yn11,bit-and-notyn2,oryn2,==yn7,bit-xoryn1,+yn1,>yn7,bit-notyn3,notyn4,addryn2,<!yn1,ayn4,argsyn8,ellipsisyn3,funyn3,lhsyn2,mkyn3,rhsyn2,styn2,nmyn1,cyn4,textyn5,stmtsyn4,fromyn2,toyn4,listyn4,tailyn5,blockyn4,optsyn5,else?yn4,inityn4,bodyyn1,iyn7,tswitchyn9,decl-nameyn5,textsyn1,_yn1,dyn5,dmetayn2,spyn4,kindyn5,extrayn9,spec-metayn4,dumpyn4,nameyn5,declsyn2,feyn6,ns-symyn9,positionsyn7,src-dirv11,arbace.core5,in-nsMyn18,arbace.g2a.convertm2,R0,s603,g2a's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.g2a.lit/Lit (text and value). arbace.g2a.layout writes them as text.m2,R0,s603,g2a's converter: the helper's typed syntax tree of a Go package (doc/go/HELPER-NOTES.md,\n  format :godump 2) to Go forms (doc/go/SPEC.md). Every decision about forms is made here; the\n  helper is dumb. See doc/go/CONVERTER-NOTES.md.\n\n  The forms are built in memory as Clojure data: lists, vectors and symbols carry the public\n  metadata of the spec (:tag, :val, :inst, :go/via, ...) and the private layout keys of this\n  namespace (::l, the Go line a form begins on; ::pos, its node's positions for mode :full).\n  Literals are arbace.g2a.lit/Lit (text and value). arbace.g2a.layout writes them as text.R1,v18,arbace.g2a.convert6,*dump*m8,R2,TR3,i16,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,*stats*m8,R2,TR3,i17,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,*generic*m8,R2,TR3,i18,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,*kept-docs*m8,R2,TR3,i19,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,*fn-dirs*m8,R2,TR3,i20,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,*placed*m8,R2,TR3,i21,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,note!m8,R6,L1,V1,R7,R3,i23,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,count-node!m8,R6,L1,V1,R8,R3,i24,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,failm8,R6,L1,V2,R9,R8,R3,i26,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert2,ntm8,R6,L1,V1,R8,R3,i34,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert2,nfm8,R6,L1,V1,R8,R3,i35,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert2,anm8,R6,L1,V1,R8,R3,i36,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,unparenm8,R6,L1,V1,R8,R3,i38,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,parse-posm8,R6,L1,V1,Myn1,sm2,R10,R11,R3,i40,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,pos-linem8,R6,L1,V1,R12,R3,i45,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,startm10,R6,L1,V1,R8,R0,s54,The position string of a node's start, go/ast's Pos().R3,i47,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,line-ofm8,R6,L1,V1,R8,R3,i96,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,positionsm10,R6,L1,V1,R8,R0,s51,The position fields of a node: {:field [line col]}.R3,i98,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,max-posm10,R6,L1,V1,R8,R0,s53,The greatest position [line col] in a node's subtree.R3,i105,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,formm10,R6,L1,V4,R8,R13,R14,R15,R0,s88,A list form beginning on line l, built from node n (whose positions it keeps for :full).R3,i121,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert2,atm10,R6,L1,V3,R16,R8,R13,R0,s64,x (a symbol, list or vector) with line l and node n's positions.R3,i126,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,linem8,R6,L1,V1,R16,R3,i134,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,with-posm10,R6,L1,V2,R16,R17,R0,s89,x with more positions for mode :full: m maps keys to position strings (nil ones skipped).R3,i136,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,block-posm8,R6,L1,V1,R18,R3,i144,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,with-linem8,R6,L1,V2,R13,R16,R3,i146,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,vec-atm8,R6,L1,V2,R13,R15,R3,i149,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,add-metam10,R6,L1,V2,R16,R17,R0,s39,x with the public metadata m merged in.R3,i151,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,lit-atm10,R6,L1,V3,R13,Myn1,xm2,R10,R19,R20,R0,s57,A Lit placed on line l (layout records it in its parent).R3,i156,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,relinedm10,R6,L1,V2,R13,R16,R0,s82,x with every form inside on line l and no positions (an implicitly repeated init).R3,i161,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,reserved-headsv11,arbace.core4,intom8,R3,i174,R4,i1,R5,s21,arbace/g2a/convert.aeR0,s83,Unqualified heads of Go context (§13.5): a call of a Go name among them is go/call.v11,arbace.core3,mapv11,arbace.core6,concatv11,arbace.core6,symbolV27,s3,lets8,let-types4,set!s4,asets4,inc!s4,dec!s2,>!s2,gos5,defers6,returns5,breaks8,continues4,gotos11,fallthroughs5,labels2,dos2,ifs4,whens4,conds6,switchs11,type-switchs6,selects4,cases7,defaults3,fors5,whiles5,rangeV38,s1,+s1,-s1,*s1,/s1,%s2,<<s2,>>s2,==s2,!=s1,<s2,<=s1,>s2,>=s3,ands2,ors3,nots7,bit-ands6,bit-ors7,bit-xors7,bit-nots11,bit-and-nots4,addrs2,<!s3,lits4,convs6,asserts4,agets8,subslices6,spreads6,valuess4,insts11,method-exprs2,fns4,zeros4,runes9,imaginarys11,byte-strings5,derefV18,s6,appends3,caps5,clears5,closes7,complexs4,copys6,deletes4,imags3,lens4,makes3,maxs3,mins3,news5,panics5,prints7,printlns4,reals7,recoverV9,s5,slices5,arrays3,maps4,chans4,funcs6,structs9,interfaces1,|s5,tildev18,arbace.g2a.convert10,ident-namem8,R6,L1,V1,R8,R3,i190,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert3,objm8,R6,L1,V1,R8,R3,i192,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,targsm10,R6,L1,V1,R21,R0,s63,The type forms of the type arguments of an instance annotation.R3,i194,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,inst-metam10,R6,L1,V2,R8,R22,R0,s132,{:inst [...]} for the use of a generic function or method whose type arguments are not\n  all in the source (explicit: how many are).R3,i199,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,identm10,R6,L2,V1,R8,V2,R8,R22,R0,s86,An identifier as a symbol, a literal (the universe's true, false, nil) or (go/id \"x\").R3,i208,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,label-kwm8,R6,L1,V1,R8,R3,i224,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,pkg-ident?m8,R6,L1,V1,R8,R3,i226,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,basic-litm8,R6,L1,V1,R8,R3,i230,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,string-valuem10,R6,L1,V1,R8,R0,s74,The Go string value of a STRING basic literal (import paths, struct tags).R3,i244,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,exprm8,R23,TR3,i251,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,type-formm8,R23,TR3,i251,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,signaturem8,R23,TR3,i251,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,field-list-vecm8,R23,TR3,i251,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,taggedm10,R6,L1,V2,R24,R25,R0,s44,The symbol sym with the type form t as :tag.R3,i253,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,group-marksm12,R26,TR6,L1,V1,R27,R0,s143,Names of one field after the first get :go/group inside generic declarations (proposed\n  amendment: gc's output depends on field groups there).R3,i258,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,mark-ungroupedm10,R6,L1,V2,R28,R29,R0,s172,Inside generic declarations, a name declared apart from the name before it although of an\n  equal type gets :go/grouped false, so that the printer does not group them (A1).R3,i266,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,doc-ofm10,R6,L1,V2,R30,R31,R0,s84,The kept doc text of a comment group position, recording it as kept; nil when empty.R3,i282,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,*groups*m8,R2,TR3,i291,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,fieldsm10,R6,L1,V2,R32,m2,R33,V1,R34,R0,s246,The elements of a struct type's fields, or of a parameter/result vector: a tagged name per\n  name, a type form for an unnamed field (embedded or unnamed parameter). opts: :struct (tags,\n  docs), :variadic (an Ellipsis type is the last parameter).R3,i293,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert15,interface-elemsm8,R6,L1,V1,R32,R3,i324,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R8,R0,s40,The type form of a type expression node.R3,i338,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R35,R0,s154,[params-vector results...] of a func-type: the parameter vector (tagged with a single\n  unnamed result) and, for named or several results, :results [...].R3,i392,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,type-paramsm8,R6,L1,V1,R32,R3,i409,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,binary-opsm38,s2,>>R36,s2,&&R37,s2,!=R38,s1,*R39,s1,%R40,s2,<=R41,s1,|R42,s1,/R43,s1,-R44,s2,>=R45,s1,&R46,s1,<R47,s2,<<R48,s2,&^R49,s2,||R50,s2,==R51,s1,^R52,s1,+R53,s1,>R54,m6,R3,i430,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,nary-opsS10,R52,R39,R49,R44,R50,R46,R43,R42,R53,R37,m6,R3,i434,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,unary-opsm12,s1,-R44,s1,+R53,s1,^R55,s1,!R56,s1,&R57,s2,<-R58,m6,R3,i436,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,assign-opsm22,s2,-=R44,s2,/=R43,s2,%=R40,s2,*=R39,s2,|=R42,s3,<<=R48,s3,>>=R36,s3,&^=R49,s2,^=R52,s2,&=R46,s2,+=R53,m6,R3,i438,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,untyped-const?m10,R6,L1,V1,R8,R0,s61,Whether a constant expression is untyped (for §8.3's shifts).R3,i442,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,as-instm10,R6,L1,V1,R25,R0,s139,A generic type instance (G T...) as (inst G T...): in operands the printer reads as\n  expressions too (new, method-expr; PRINTER-NOTES A5).R3,i463,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,selection-viam8,R6,L1,V1,R59,R3,i472,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,selector-formm10,R6,L1,V1,R8,R0,s45,A selector expression not in callee position.R3,i476,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,call-argsm8,R6,L1,V2,R60,R61,R3,i499,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,builtin-namem10,R6,L1,V1,R62,R0,s84,The head of a builtin call: len, append, ..., or unsafe/Sizeof with the file's name.R3,i505,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,callm8,R6,L1,V1,R8,R3,i514,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,instantiationm10,R6,L1,V1,R8,R0,s89,F[T...] in an expression: (inst F T...), F carrying :inst when the arguments are partial.R3,i560,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,compositem8,R6,L1,V1,R8,R3,i587,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,stmt-listm8,R23,TR3,i614,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,fn-sig-formsm8,R23,TR3,i614,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,generic-decl?m8,R23,TR3,i614,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,func-litm8,R6,L1,V1,R8,R3,i616,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R8,R0,s31,The form of an expression node.R3,i628,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,targetsm10,R6,L1,V3,R63,R13,R64,R0,s57,Binding or assignment targets: one form, or (values ...).R3,i708,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,initsm8,R6,L1,V2,R65,R13,R3,i715,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,define-targetm10,R6,L1,V1,R8,R0,s57,A := target: a new name, or a reused one marked ^:assign.R3,i720,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,define-bindingm10,R6,L1,V1,R66,R0,s29,[target init] of x, y := e...R3,i728,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,const-valm10,R6,L1,V1,R67,R0,s41,{:val v} of a constant name's definition.R3,i736,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert13,decl-bindingsm10,R6,L1,V1,R66,R0,s86,The let bindings of a local declaration (a decl-stmt), and the kind :let or :let-type.R3,i744,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,decl-stmt?m10,R6,L1,V1,R66,R0,s60,Whether a statement declares (it becomes a let or let-type).R3,i810,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,bindings-ofm8,R6,L1,V1,R66,R3,i819,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert4,stmtm8,R23,TR3,i825,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,simple-stmtm8,R23,TR3,i825,R4,i1,R5,s21,arbace/g2a/convert.aem8,R23,TR3,i825,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,dir-formm8,R6,L1,V1,V3,R13,R68,R69,R3,i827,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,gap-directivesm12,R26,TR6,L1,V3,R70,R71,R72,R0,s164,For statements stmts in a block spanning [from to] (positions), the directives in the gaps:\n  a vector of n+1 lists, gap k before statement k, gap n after the last.R3,i832,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,stmts-formsm10,R6,L1,V4,R73,R71,R72,m2,R33,V1,R74,R0,s271,The forms of a statement list stmts spanning the positions (from, to). Declarations become\n  a let (or let-type) whose body is the rest of the list (§7.3). opts :tail: the list ends a\n  function with results, so a final return of one expression is that expression (§6.4).R3,i849,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V2,R75,R76,R0,s48,The forms of a block's statements (stmts-forms).R3,i897,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,block-formsm10,R6,L1,V1,R18,R0,s30,A nested Go block as (do ...).R3,i904,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,branchm10,R6,L1,V2,R18,R77,R0,s171,A branch of if/cond (§7.2): one statement, or (do ...) for a statement list; else? (an else\n  branch): a single if, when or cond is wrapped in do, which an else if is not.R3,i909,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,init-vecm10,R6,L1,V2,R78,R13,R0,s88,The init vector of if, switch, type-switch and for: [target expr] for a :=, [stmt] else.R3,i922,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,if-formm8,R6,L1,V1,R8,R3,i931,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,clause-boundm10,R6,L1,V2,R79,R80,R0,s80,The end bound of clause i of a switch or select body: the next clause, or the }.R3,i962,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,case-clausem8,R6,L1,V3,R68,R72,R81,R3,i970,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert7,clausesm8,R6,L1,V2,R79,R81,R3,i985,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert11,comm-clausem8,R6,L1,V2,R68,R72,R3,i989,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert6,assignm8,R6,L1,V1,R8,R3,i1005,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R12,R0,s47,A simple statement in an init or post position.R3,i1022,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert5,stmt*m8,R23,TR3,i1027,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V2,R8,R74,R0,s94,The form of a statement (not a declaration). tail: the last of a function body with\n  results.R3,i1029,R4,i1,R5,s21,arbace/g2a/convert.aem8,R6,L1,V2,R8,R74,R3,i1038,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R35,R0,s42,The signature part of fn: params, results.R3,i1121,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,directive-namem10,R6,L1,V1,Myn4,textm2,R10,R11,R0,s52,The name of a //go: directive (\"nosplit\"), else nil.R3,i1128,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,directive-argsm8,R6,L1,V1,Myn4,textm2,R10,R11,R3,i1136,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert19,free-standing-namesS3,s11,linknamestds8,generates5,buildm8,R3,i1141,R4,i1,R5,s21,arbace/g2a/convert.aeR0,s87,//go: directives that gc applies by name or to the file, never to the next declaration.v18,arbace.g2a.convert11,attachable?m10,R6,L1,V2,R69,R82,R0,s187,Whether the directive attaches to a declaration named decl-name that follows it: gc's\n  pragmas (noder.go) other than linkname naming another declaration, cgo's and the\n  file-level ones.R3,i1145,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,directive-metam10,R6,L1,V1,R83,R0,s83,The metadata of attached directives (texts in order): {:go/name true|\"args\"|[...]}.R3,i1156,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert14,free-directivem8,R6,L1,V1,V3,R13,R84,R69,R3,i1167,R4,i1,R5,s21,arbace/g2a/convert.aem10,R6,L1,V1,R85,R0,s89,A func-decl with type parameters or a receiver of a generic type, or a generic type spec.R3,i1173,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,func-declm8,R6,L1,V2,R85,R86,R3,i1186,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert17,value-spec-targetm10,R6,L1,V3,R87,R88,R89,R0,s114,The target of a package-level value spec: a name or (values ...); docs and directive\n  metadata on the first name.R3,i1209,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert8,gen-declm8,R6,L1,V2,R85,R90,R3,i1223,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert15,file-directivesm10,R6,L1,V2,R91,R92,R0,s58,The dump's directives of file name: [[line col text] ...].R3,i1264,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,decl-namem10,R6,L1,V1,R85,R0,s68,The name a directive before declaration d (or spec) would attach to.R3,i1276,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,imports-ofm8,R6,L1,V1,R93,R3,i1285,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,convert-filem10,R6,L1,V3,R91,R94,R95,R0,s179,The forms of one Go file of the dump: {:name :forms [...] :comments {line [text]}\n  :unplaced [...]} (forms in order: in-ns, go/file, declarations and free-standing\n  directives).R3,i1301,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,init-orderm8,R6,L1,V1,R91,R3,i1426,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert10,munge-namem10,R26,TR6,L1,V1,R12,R3,i1438,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert12,package-formm8,R6,L1,V2,R91,m2,R33,V1,R96,R3,i1440,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert9,file-stemm10,R6,L1,V2,R92,R97,R0,s198,The .ae path stem of Go file name in package directory dir (a Go source directory): x for\n  x.go, or x.go when dir has a subdirectory x (a package of that name would own x.ae:\n  proposed amendment).R3,i1463,R4,i1,R5,s21,arbace/g2a/convert.aev18,arbace.g2a.convert15,convert-packagem10,R6,L1,V2,R91,R76,R0,s273,Converts a dump. opts: :positions (:lines or :full), :ns (the namespace symbol, default from\n  the import path), :src-dir (the package's source directory, for file-name collisions).\n  Returns {:ns sym :package form :files [{:name :stem :forms :comments :unplaced}] :stats}.R3,i1473,R4,i1,R5,s21,arbace/g2a/convert.ae")

var Lit_189 *jrt.String = jrt.Intern("arbace.g2a.convert$eval838000004$loading__1927001464__auto____838000005")

var Lit_190 *jrt.String = jrt.Intern("arbace.g2a.convert$eval838000008$fn__838000009")

var Lit_191 *jrt.String = jrt.Intern("arbace.g2a.convert$note_BANG_")

var Lit_192 *jrt.String = jrt.Intern("arbace.g2a.convert$count_node_BANG_")

var Lit_193 *jrt.String = jrt.Intern("arbace.g2a.convert$fail")

var Lit_194 *jrt.String = jrt.Intern("arbace.g2a.convert$nt")

var Lit_195 *jrt.String = jrt.Intern("arbace.g2a.convert$nf")

var Lit_196 *jrt.String = jrt.Intern("arbace.g2a.convert$an")

var Lit_197 *jrt.String = jrt.Intern("arbace.g2a.convert$unparen")

var Lit_198 *jrt.String = jrt.Intern("arbace.g2a.convert$parse_pos")

var Lit_199 *jrt.String = jrt.Intern("arbace.g2a.convert$pos_line")

var Lit_200 *jrt.String = jrt.Intern("arbace.g2a.convert$start")

var Lit_201 *jrt.String = jrt.Intern("arbace.g2a.convert$line_of")

var Lit_202 *jrt.String = jrt.Intern("arbace.g2a.convert$positions")

var Lit_203 *jrt.String = jrt.Intern("arbace.g2a.convert$max_pos")

var Lit_204 *jrt.String = jrt.Intern("arbace.g2a.convert$form")

var Lit_205 *jrt.String = jrt.Intern("arbace.g2a.convert$at")

var Lit_206 *jrt.String = jrt.Intern("arbace.g2a.convert$line")

var Lit_207 *jrt.String = jrt.Intern("arbace.g2a.convert$with_pos")

var Lit_208 *jrt.String = jrt.Intern("arbace.g2a.convert$block_pos")

var Lit_209 *jrt.String = jrt.Intern("arbace.g2a.convert$with_line")

var Lit_210 *jrt.String = jrt.Intern("arbace.g2a.convert$vec_at")

var Lit_211 *jrt.String = jrt.Intern("arbace.g2a.convert$add_meta")

var Lit_212 *jrt.String = jrt.Intern("arbace.g2a.convert$lit_at")

var Lit_213 *jrt.String = jrt.Intern("arbace.g2a.convert$relined")

var Lit_214 *jrt.String = jrt.Intern("arbace.g2a.convert$ident_name")

var Lit_215 *jrt.String = jrt.Intern("arbace.g2a.convert$obj")

var Lit_216 *jrt.String = jrt.Intern("arbace.g2a.convert$targs")

var Lit_217 *jrt.String = jrt.Intern("arbace.g2a.convert$inst_meta")

var Lit_218 *jrt.String = jrt.Intern("arbace.g2a.convert$ident")

var Lit_219 *jrt.String = jrt.Intern("arbace.g2a.convert$label_kw")

var Lit_220 *jrt.String = jrt.Intern("arbace.g2a.convert$pkg_ident_QMARK_")

var Lit_221 *jrt.String = jrt.Intern("arbace.g2a.convert$basic_lit")

var Lit_222 *jrt.String = jrt.Intern("arbace.g2a.convert$string_value")

var Lit_223 *jrt.String = jrt.Intern("arbace.g2a.convert$tagged")

var Lit_224 *jrt.String = jrt.Intern("arbace.g2a.convert$group_marks")

var Lit_225 *jrt.String = jrt.Intern("arbace.g2a.convert$mark_ungrouped")

var Lit_226 *jrt.String = jrt.Intern("arbace.g2a.convert$doc_of")

var Lit_227 *jrt.String = jrt.Intern("arbace.g2a.convert$fields")

var Lit_228 *jrt.String = jrt.Intern("arbace.g2a.convert$interface_elems")

var Lit_229 *jrt.String = jrt.Intern("arbace.g2a.convert$type_form")

var Lit_230 *jrt.String = jrt.Intern("arbace.g2a.convert$signature")

var Lit_231 *jrt.String = jrt.Intern("arbace.g2a.convert$type_params")

var Lit_232 *jrt.String = jrt.Intern("arbace.g2a.convert$untyped_const_QMARK_")

var Lit_233 *jrt.String = jrt.Intern("arbace.g2a.convert$as_inst")

var Lit_234 *jrt.String = jrt.Intern("arbace.g2a.convert$selection_via")

var Lit_235 *jrt.String = jrt.Intern("arbace.g2a.convert$selector_form")

var Lit_236 *jrt.String = jrt.Intern("arbace.g2a.convert$call_args")

var Lit_237 *jrt.String = jrt.Intern("arbace.g2a.convert$builtin_name")

var Lit_238 *jrt.String = jrt.Intern("arbace.g2a.convert$call")

var Lit_239 *jrt.String = jrt.Intern("arbace.g2a.convert$instantiation")

var Lit_240 *jrt.String = jrt.Intern("arbace.g2a.convert$composite")

var Lit_241 *jrt.String = jrt.Intern("arbace.g2a.convert$func_lit")

var Lit_242 *jrt.String = jrt.Intern("arbace.g2a.convert$expr")

var Lit_243 *jrt.String = jrt.Intern("arbace.g2a.convert$targets")

var Lit_244 *jrt.String = jrt.Intern("arbace.g2a.convert$inits")

var Lit_245 *jrt.String = jrt.Intern("arbace.g2a.convert$define_target")

var Lit_246 *jrt.String = jrt.Intern("arbace.g2a.convert$define_binding")

var Lit_247 *jrt.String = jrt.Intern("arbace.g2a.convert$const_val")

var Lit_248 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_bindings")

var Lit_249 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_stmt_QMARK_")

var Lit_250 *jrt.String = jrt.Intern("arbace.g2a.convert$bindings_of")

var Lit_251 *jrt.String = jrt.Intern("arbace.g2a.convert$dir_form")

var Lit_252 *jrt.String = jrt.Intern("arbace.g2a.convert$gap_directives")

var Lit_253 *jrt.String = jrt.Intern("arbace.g2a.convert$stmts_forms")

var Lit_254 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_list")

var Lit_255 *jrt.String = jrt.Intern("arbace.g2a.convert$block_forms")

var Lit_256 *jrt.String = jrt.Intern("arbace.g2a.convert$branch")

var Lit_257 *jrt.String = jrt.Intern("arbace.g2a.convert$init_vec")

var Lit_258 *jrt.String = jrt.Intern("arbace.g2a.convert$if_form")

var Lit_259 *jrt.String = jrt.Intern("arbace.g2a.convert$clause_bound")

var Lit_260 *jrt.String = jrt.Intern("arbace.g2a.convert$case_clause")

var Lit_261 *jrt.String = jrt.Intern("arbace.g2a.convert$clauses")

var Lit_262 *jrt.String = jrt.Intern("arbace.g2a.convert$comm_clause")

var Lit_263 *jrt.String = jrt.Intern("arbace.g2a.convert$assign")

var Lit_264 *jrt.String = jrt.Intern("arbace.g2a.convert$simple_stmt")

var Lit_265 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt")

var Lit_266 *jrt.String = jrt.Intern("arbace.g2a.convert$stmt_STAR_")

var Lit_267 *jrt.String = jrt.Intern("arbace.g2a.convert$fn_sig_forms")

var Lit_268 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_name")

var Lit_269 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_args")

var Lit_270 *jrt.String = jrt.Intern("arbace.g2a.convert$attachable_QMARK_")

var Lit_271 *jrt.String = jrt.Intern("arbace.g2a.convert$directive_meta")

var Lit_272 *jrt.String = jrt.Intern("arbace.g2a.convert$free_directive")

var Lit_273 *jrt.String = jrt.Intern("arbace.g2a.convert$generic_decl_QMARK_")

var Lit_274 *jrt.String = jrt.Intern("arbace.g2a.convert$func_decl")

var Lit_275 *jrt.String = jrt.Intern("arbace.g2a.convert$value_spec_target")

var Lit_276 *jrt.String = jrt.Intern("arbace.g2a.convert$gen_decl")

var Lit_277 *jrt.String = jrt.Intern("arbace.g2a.convert$file_directives")

var Lit_278 *jrt.String = jrt.Intern("arbace.g2a.convert$decl_name")

var Lit_279 *jrt.String = jrt.Intern("arbace.g2a.convert$imports_of")

var Lit_280 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_file")

var Lit_281 *jrt.String = jrt.Intern("arbace.g2a.convert$init_order")

var Lit_282 *jrt.String = jrt.Intern("arbace.g2a.convert$munge_name")

var Lit_283 *jrt.String = jrt.Intern("arbace.g2a.convert$package_form")

var Lit_284 *jrt.String = jrt.Intern("arbace.g2a.convert$file_stem")

var Lit_285 *jrt.String = jrt.Intern("arbace.g2a.convert$convert_package")
