//line j2g_strings.ae:1
package aot_arbace_j2g_meta

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn22,arbace.classes.analyzeyn1,ayn17,arbace.j2g.accessyn3,accyn16,arbace.j2g.namesyn2,nmyn11,arbace.corekn3,dockn4,elsekn6,modulekn9,classpathkn3,badkn2,atkn5,rootskn5,errorkn6,errorskn5,constkn2,opkn3,valkn9,class-litkn5,classkn6,invokekn4,argskn6,targetkn5,fieldkn4,ctorkn11,lookup-ctorkn5,ownerkn4,namekn6,rootedkn7,dynamickn6,lookupkn6,memberkn5,statekn8,analyzedkn15,analysis-failedkn6,bodieskn6,clinitkn4,initkn7,stubbedkn7,droppedv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,v11,arbace.core5,referR11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.metam2,R12,s1520,bin/j2g: a program's discovery metadata as closed-world tables and roots (doc/go/J2G-SPEC.md §4.1,\n  \"Roots from a program's metadata\"; §10.3; the Ghidra case study's GH4 (ii)-(iv) and GH6 (iv), items\n  A4-A7 of its G1 plan):\n\n  - the service registry (GH4 (ii), A4): every META-INF/services/S of the program's resources, in the\n    order of its resource directories (the class path's jars), and the world's module `provides`\n    (jdk/provides.txt, bin/jrt provides), as one generated table the program embeds,\n    META-INF/arbace/services, which jrt's own java.util.ServiceLoader iterates; each provider rooted\n    (its constructors and a static provider()) once its service is reached;\n  - the resource roots (A5): a resource the program's resource directories hold more than once is\n    embedded at its path from the first and at META-INF/arbace/roots/K/PATH from directory K, listed in\n    META-INF/arbace/roots, so that ClassLoader.getResources enumerates one URL a directory;\n  - reflection roots (GH4 (iv), A6): GraalVM native-image's reachability metadata under\n    META-INF/native-image/ (reflect-config.json, jni-config.json, resource-config.json's bundles,\n    reachability-metadata.json), and the reflective call sites whose names are constant strings;\n  - the refusals (GH6 (iv), A7): the classes j2g refused, each stubbed (a reached method needs it: its\n    uses throw with the cause) or dropped (nothing reached needs it).\n\n  Pure functions over the resources and the analyzed world; main.ae applies them.v13,arbace.string4,joinv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core11,map-indexedv11,arbace.core6,vectorv11,arbace.core4,sortv15,arbace.j2g.meta12,roots-prefixv11,arbace.core10,re-matchesp32,META-INF/arbace/roots/(\\d+)/(.+)l-1,v11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core3,vecv11,arbace.core7,sort-byv15,arbace.j2g.meta6,unrootv11,arbace.core8,group-byv11,arbace.core6,secondv11,arbace.core6,every?v13,arbace.string5,splitp2,\\.v13,arbace.string11,split-linesv11,arbace.core4,nextv13,arbace.string4,trimv11,arbace.core4,subsl0,v15,arbace.j2g.meta10,java-name?R13,v11,arbace.core8,distinctp23,META-INF/services/[^/]+v14,arbace.java.io4,filev11,arbace.core3,notv13,arbace.string12,starts-with?p3,\\s+v11,arbace.core5,slurpv15,arbace.j2g.meta13,by-plain-pathv11,arbace.core6,filterv15,arbace.j2g.meta14,services-path?v11,arbace.core4,keysv11,arbace.core6,reducev11,arbace.core6,updatev11,arbace.core4,fnilR14,v15,arbace.j2g.meta19,parse-services-fileR15,v11,arbace.core9,with-metav11,arbace.core4,valsv11,arbace.core9,contains?v11,arbace.core5,assocv11,arbace.core9,array-mapR16,v11,arbace.core4,namev15,arbace.j2g.meta17,distinct-by-firstv11,arbace.core6,concatv13,arbace.string7,replacev15,arbace.j2g.meta8,internalv11,arbace.core6,mapcatv11,arbace.core4,keepv11,arbace.core7,ex-infoR17,c123,c125,v11,arbace.core7,string?v15,arbace.j2g.meta9,json-failc58,c44,c91,c93,c34,c92,c117,S15,c69,c101,c43,c45,c46,c48,c49,c50,c51,c52,c53,c54,c55,c56,c57,v11,arbace.core3,strc98,c8,c102,c12,c110,c10,c114,c13,c116,c9,v11,arbace.core7,re-findp5,[.eE]p96,META-INF/native-image/.*/(reflect-config|jni-config|resource-config|reachability-metadata)\\.jsonv11,arbace.core4,map?v11,arbace.core5,true?v11,arbace.core4,someV4,s23,allDeclaredConstructorss21,allPublicConstructorss28,queryAllDeclaredConstructorss26,queryAllPublicConstructorsV2,s18,allDeclaredMethodss16,allPublicMethodsv15,arbace.j2g.meta16,reflection-specsv15,arbace.j2g.meta12,condition-ofp27,(reflect|jni)-config\\.json$p22,resource-config\\.json$p28,reachability-metadata\\.json$R18,v15,arbace.j2g.meta14,metadata-rootsv15,arbace.j2g.meta9,read-jsonR19,R20,v15,arbace.j2g.meta14,metadata-path?v17,arbace.j2g.access8,unaccessR21,R22,R23,R24,R25,l1,R26,v15,arbace.j2g.meta16,reflective-callsR27,v15,arbace.j2g.meta16,class-lit-binaryR28,R29,R30,v15,arbace.j2g.meta12,const-stringR31,R32,R33,R34,R35,R36,R37,v22,arbace.classes.analyze4,declR38,R39,R40,v15,arbace.j2g.meta10,site-rootsv11,arbace.core8,tree-seqv11,arbace.core7,some-fnv11,arbace.core7,vector?v11,arbace.core4,seq?R41,R42,R43,p1,#l2,v15,arbace.j2g.meta10,spec-classv13,arbace.string9,includes?v11,arbace.core3,setv11,arbace.core3,mapv11,arbace.core4,compv15,arbace.j2g.meta6,top-ofv11,arbace.core3,keyv15,arbace.j2g.meta12,names-class?R44,R45,")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$iter__849000054__849000058")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$fn__849000074")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$iter__849000054__849000058$fn__849000059")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$iter__849000054__849000058$fn__849000059$fn__849000060")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$iter__849000054__849000058$fn__849000059$fn__849000070")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path$iter__849000054__849000058$fn__849000059$fn__849000060$fn__849000064")

var Lit_7 *jrt.String = jrt.Intern("L")

var Lit_8 *jrt.String = jrt.Intern("/")

var Lit_9 *jrt.String = jrt.Intern(".")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.meta$classpath_index_text$iter__849000012__849000016")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.meta$classpath_index_text$iter__849000012__849000016$fn__849000017")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.meta$classpath_index_text$iter__849000012__849000016$fn__849000017$fn__849000018")

var Lit_13 *jrt.String = jrt.Intern(" ")

var Lit_14 *jrt.String = jrt.Intern("\n")

var Lit_15 *jrt.String = jrt.Intern(":")

var Lit_16 *jrt.String = jrt.Intern("condition")

var Lit_17 *jrt.String = jrt.Intern("typeReachable")

var Lit_18 *jrt.String = jrt.Intern("typeReached")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots$iter__849000336__849000340")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots$iter__849000336__849000340$fn__849000341")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots$iter__849000336__849000340$fn__849000341$fn__849000342")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots$iter__849000336__849000340$fn__849000341$fn__849000346")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots$iter__849000336__849000340$fn__849000341$fn__849000342$fn__849000343")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.meta$java_name_QMARK_$fn__849000078")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.meta$java_name_QMARK_$fn__849000078$fn__849000079")

var Lit_26 *jrt.String = jrt.Intern("JSON: ")

var Lit_27 *jrt.String = jrt.Intern(" at ")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$entries__849000311")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$bundles__849000323")

var Lit_30 *jrt.String = jrt.Intern("bundles")

var Lit_31 *jrt.String = jrt.Intern("reflection")

var Lit_32 *jrt.String = jrt.Intern("jni")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$bundles__849000323$iter__849000324__849000328")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$bundles__849000323$iter__849000324__849000328$fn__849000329")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$bundles__849000323$iter__849000324__849000328$fn__849000329$fn__849000330")

var Lit_36 *jrt.String = jrt.Intern("name")

var Lit_37 *jrt.String = jrt.Intern("#<init>")

var Lit_38 *jrt.String = jrt.Intern("#<clinit>")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$entries__849000311$iter__849000312__849000316")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$entries__849000311$iter__849000312__849000316$fn__849000317")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots$entries__849000311$iter__849000312__849000316$fn__849000317$fn__849000318")

var Lit_42 *jrt.String = jrt.Intern("class ")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.meta$owners_text$iter__849000029__849000033")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.meta$owners_text$iter__849000029__849000033$fn__849000034")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.meta$owners_text$iter__849000029__849000033$fn__849000034$fn__849000035")

var Lit_46 *jrt.String = jrt.Intern("#")

var Lit_47 *jrt.String = jrt.Intern("")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.meta$present_specs$fn__849000428")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.meta$read_json$ws__849000277")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.meta$read_json$value__849000279")

var Lit_51 *jrt.String = jrt.Intern("text after the value")

var Lit_52 *jrt.String = jrt.Intern("unexpected end")

var Lit_53 *jrt.String = jrt.Intern("a key that is not a string")

var Lit_54 *jrt.String = jrt.Intern("no :")

var Lit_55 *jrt.String = jrt.Intern("no , or }")

var Lit_56 *jrt.String = jrt.Intern("no , or ]")

var Lit_57 *jrt.String = jrt.Intern("an unterminated string")

var Lit_58 *jrt.String = jrt.Intern("true")

var Lit_59 *jrt.String = jrt.Intern("false")

var Lit_60 *jrt.String = jrt.Intern("null")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.meta$read_json$value__849000279$fn__849000291")

var Lit_62 *jrt.String = jrt.Intern("an unexpected ")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.meta$read_provides$iter__849000095__849000099")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.meta$read_provides$iter__849000095__849000099$fn__849000100")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.meta$read_provides$iter__849000095__849000099$fn__849000100$fn__849000101")

var Lit_66 *jrt.String = jrt.Intern("type")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.meta$reflection_specs$all_QMARK___849000298")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.meta$reflection_specs$iter__849000300__849000304")

var Lit_69 *jrt.String = jrt.Intern("methods")

var Lit_70 *jrt.String = jrt.Intern("queriedMethods")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.meta$reflection_specs$iter__849000300__849000304$fn__849000305")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.meta$reflection_specs$iter__849000300__849000304$fn__849000305$fn__849000306")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000381__849000387")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000403__849000407")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$iter__849000361__849000367")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$fn__849000377")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$iter__849000361__849000367$fn__849000368")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$iter__849000361__849000367$fn__849000368$fn__849000369")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$iter__849000361__849000367$fn__849000368$fn__849000373")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000359__849000365$fn__849000366$iter__849000361__849000367$fn__849000368$fn__849000369$fn__849000370")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000381__849000387$fn__849000388")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000381__849000387$fn__849000388$iter__849000383__849000395")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000381__849000387$fn__849000388$iter__849000383__849000395$fn__849000396")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000381__849000387$fn__849000388$iter__849000383__849000395$fn__849000396$fn__849000397")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000403__849000407$fn__849000408")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites$iter__849000403__849000407$fn__849000408$fn__849000409")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000490__849000494")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$iter__849000468__849000472")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440$iter__849000444__849000448")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440$iter__849000444__849000448$fn__849000449")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440$iter__849000444__849000448$fn__849000449$fn__849000450")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440$iter__849000444__849000448$fn__849000449$fn__849000460")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$fn__849000440$iter__849000444__849000448$fn__849000449$fn__849000450$fn__849000454")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$iter__849000468__849000472$fn__849000473")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$iter__849000468__849000472$fn__849000473$fn__849000474")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$iter__849000468__849000472$fn__849000473$fn__849000484")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000434__849000438$fn__849000439$iter__849000468__849000472$fn__849000473$fn__849000474$fn__849000478")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000490__849000494$fn__849000495")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals$iter__849000490__849000494$fn__849000495$fn__849000496")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.meta$roots_index_text$fn__849000257")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.meta$roots_index_text$iter__849000262__849000266")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.meta$roots_index_text$iter__849000262__849000266$fn__849000267")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.meta$roots_index_text$iter__849000262__849000266$fn__849000267$fn__849000268")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots$iter__849000227__849000231")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots$iter__849000227__849000231$fn__849000232")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots$iter__849000227__849000231$fn__849000232$fn__849000233")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots$iter__849000227__849000231$fn__849000232$fn__849000248")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots$iter__849000227__849000231$fn__849000232$fn__849000233$fn__849000238")

var Lit_114 *jrt.String = jrt.Intern("#provider")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000116")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.meta$services$iter__849000160__849000164")

var Lit_118 *jrt.String = jrt.Intern("META-INF/services/")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000138__849000142")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000148__849000152")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000138__849000142$fn__849000143")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000138__849000142$fn__849000143$fn__849000144")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000148__849000152$fn__849000153")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.meta$services$fn__849000123$fn__849000131$iter__849000148__849000152$fn__849000153$fn__849000154")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.meta$services$iter__849000160__849000164$fn__849000165")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.meta$services$iter__849000160__849000164$fn__849000165$fn__849000166")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.meta$services$iter__849000160__849000164$fn__849000165$fn__849000181")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.meta$services$iter__849000160__849000164$fn__849000165$fn__849000166$fn__849000171")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text$iter__849000200__849000206")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text$iter__849000200__849000206$fn__849000207")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text$iter__849000200__849000206$fn__849000207$iter__849000202__849000211")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text$iter__849000200__849000206$fn__849000207$iter__849000202__849000211$fn__849000212")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text$iter__849000200__849000206$fn__849000207$iter__849000202__849000211$fn__849000212$fn__849000213")

var Lit_135 *jrt.String = jrt.Intern(" on a class not constant")

var Lit_136 *jrt.String = jrt.Intern(" of a name not constant")

var Lit_137 *jrt.String = jrt.Intern(" not of a constant class")

var Lit_138 *jrt.String = jrt.Intern(" not of constants")

var Lit_139 *jrt.String = jrt.Intern(" of ")

var Lit_140 *jrt.String = jrt.Intern(" by a name not constant")

var Lit_141 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_142 *jrt.String = jrt.Intern("$")

var Lit_143 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistsyn5,namesyn6,ownersyn1,kyn1,pkn3,tagyn6,Stringyn2,pskn7,privateyn1,fyn8,providesyn4,datayn4,svcsyn5,pathsyn1,iyn4,whatyn1,eyn1,vyn1,xkn4,ctorkn6,lookupkn5,fieldkn6,memberkn5,classkn11,lookup-ctoryn4,nodeyn2,nsyn5,specsyn6,failedyn11,unavailablev11,arbace.core5,in-nsMyn15,arbace.j2g.metam2,R0,s1520,bin/j2g: a program's discovery metadata as closed-world tables and roots (doc/go/J2G-SPEC.md §4.1,\n  \"Roots from a program's metadata\"; §10.3; the Ghidra case study's GH4 (ii)-(iv) and GH6 (iv), items\n  A4-A7 of its G1 plan):\n\n  - the service registry (GH4 (ii), A4): every META-INF/services/S of the program's resources, in the\n    order of its resource directories (the class path's jars), and the world's module `provides`\n    (jdk/provides.txt, bin/jrt provides), as one generated table the program embeds,\n    META-INF/arbace/services, which jrt's own java.util.ServiceLoader iterates; each provider rooted\n    (its constructors and a static provider()) once its service is reached;\n  - the resource roots (A5): a resource the program's resource directories hold more than once is\n    embedded at its path from the first and at META-INF/arbace/roots/K/PATH from directory K, listed in\n    META-INF/arbace/roots, so that ClassLoader.getResources enumerates one URL a directory;\n  - reflection roots (GH4 (iv), A6): GraalVM native-image's reachability metadata under\n    META-INF/native-image/ (reflect-config.json, jni-config.json, resource-config.json's bundles,\n    reachability-metadata.json), and the reflective call sites whose names are constant strings;\n  - the refusals (GH6 (iv), A7): the classes j2g refused, each stubbed (a reached method needs it: its\n    uses throw with the cause) or dropped (nothing reached needs it).\n\n  Pure functions over the resources and the analyzed world; main.ae applies them.m2,R0,s1520,bin/j2g: a program's discovery metadata as closed-world tables and roots (doc/go/J2G-SPEC.md §4.1,\n  \"Roots from a program's metadata\"; §10.3; the Ghidra case study's GH4 (ii)-(iv) and GH6 (iv), items\n  A4-A7 of its G1 plan):\n\n  - the service registry (GH4 (ii), A4): every META-INF/services/S of the program's resources, in the\n    order of its resource directories (the class path's jars), and the world's module `provides`\n    (jdk/provides.txt, bin/jrt provides), as one generated table the program embeds,\n    META-INF/arbace/services, which jrt's own java.util.ServiceLoader iterates; each provider rooted\n    (its constructors and a static provider()) once its service is reached;\n  - the resource roots (A5): a resource the program's resource directories hold more than once is\n    embedded at its path from the first and at META-INF/arbace/roots/K/PATH from directory K, listed in\n    META-INF/arbace/roots, so that ClassLoader.getResources enumerates one URL a directory;\n  - reflection roots (GH4 (iv), A6): GraalVM native-image's reachability metadata under\n    META-INF/native-image/ (reflect-config.json, jni-config.json, resource-config.json's bundles,\n    reachability-metadata.json), and the reflective call sites whose names are constant strings;\n  - the refusals (GH6 (iv), A7): the classes j2g refused, each stubbed (a reached method needs it: its\n    uses throw with the cause) or dropped (nothing reached needs it).\n\n  Pure functions over the resources and the analyzed world; main.ae applies them.R1,v15,arbace.j2g.meta17,services-resourcem8,R2,i27,R3,i1,R4,s18,arbace/j2g/meta.aeR0,s235,The generated service registry's resource path: one provider a line, KIND SERVICE PROVIDER (KIND\n  module, the world's provides, or classpath, a META-INF/services file's), services sorted, each\n  service's providers in discovery order.v15,arbace.j2g.meta14,roots-resourcem8,R2,i33,R3,i1,R4,s18,arbace/j2g/meta.aeR0,s175,The resource roots' index: one line K NAME a resource directory some of whose resources another\n  directory before it holds too (their copies at META-INF/arbace/roots/K/PATH).v15,arbace.j2g.meta12,roots-prefixm6,R2,i38,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta18,classpath-resourcem8,R2,i40,R3,i1,R4,s18,arbace/j2g/meta.aeR0,s255,The class path's entries (GH4 (iii) of the Ghidra case study's G1 plan): one line K NAME a --resources\n  directory, in the class path's order, K its index (root-path's), NAME its name (java.class.path lists the\n  names, a program's entries by name alone).v15,arbace.j2g.meta15,owners-resourcem8,R2,i46,R3,i1,R4,s18,arbace/j2g/meta.aeR0,s327,Which entry a plain resource path belongs to: one line K PATH a resource of a --resources directory (the\n  first directory holding a path has it at its plain path, the others' copies are at root-path), so that\n  an entry's resources are told from the JDK's and from another entry's (jdk.internal.jrt.ClassPathResources.findIn).v15,arbace.j2g.meta20,classpath-index-textm10,R5,L1,V1,R6,R0,s94,The entries' index (classpath-resource): K NAME a line, names the directories' names by index.R2,i52,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta11,owners-textm10,R5,L1,V1,R7,R0,s97,The owners' index (owners-resource) of owners, [[k path] ...]: K PATH a line, by index then path.R2,i57,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta18,classpath-propertym10,R5,L1,V1,R6,R0,s95,java.class.path's value for the entries' names: the names in order, the path separator between.R2,i62,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta9,root-pathm10,R5,L1,V2,R8,R9,R0,s56,Where resource directory k's copy of path p is embedded.R2,i67,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta6,unrootm10,R5,L1,V1,Myn1,pm2,R10,R11,R0,s83,[k path]: a root copy's directory index and plain path, or [-1 p] for a plain path.R2,i72,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta13,by-plain-pathm10,R5,L1,V1,R12,R0,s225,The resource paths ps grouped by their plain path, each group in the class path's order (the plain\n  path, which the first directory holding it gives, then the copies by directory): {plain [path ...]},\n  sorted by plain path.R2,i79,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta10,java-name?m10,R13,TR5,L1,V1,Myn1,sm2,R10,R11,R2,i91,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta19,parse-services-filem10,R5,L1,V1,Myn4,textm2,R10,R11,R0,s241,A META-INF/services file's providers, as java.util.ServiceLoader reads one (its javadoc): a\n  provider's binary name a line, # beginning a comment, blanks around it ignored, empty lines skipped,\n  duplicates kept once. [providers bad-lines].R2,i98,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta14,services-path?m8,R5,L1,V1,Myn1,pm2,R10,R11,R2,i112,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta13,read-providesm10,R5,L1,V1,R14,R0,s163,The world's module provides (jdk/provides.txt, bin/jrt provides: MODULE SERVICE PROVIDER a line),\n  [[service provider] ...] in order; empty when f does not exist.R2,i115,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta8,servicesm10,R5,L1,V2,R15,R16,R0,s351,The registry: {service [[provider kind] ...]} sorted by service, the world's provides first (kind\n  :module), then the META-INF/services files of data ({path text-fn}, the program's resources with\n  their root copies) in the class path's order (kind :classpath), a provider once a service. Also\n  :bad, the lines that name no class, [[path line] ...].R2,i129,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta17,distinct-by-firstm10,R13,TR5,L1,V1,R12,R2,i150,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta13,services-textm10,R5,L1,V1,R17,R0,s49,The registry's resource text (services-resource).R2,i156,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta8,internalm8,R5,L1,V1,Myn1,sm2,R10,R11,R2,i162,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta13,service-rootsm10,R5,L1,V1,R17,R0,s186,The conditional roots of the registry: [[service-internal [spec ...]] ...]: a provider's\n  constructors and its static provider() (root specs, binary names), once the service is reached.R2,i164,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta16,roots-index-textm10,R5,L1,V2,R18,R6,R0,s175,The resource roots' index (roots-resource) of the copies among paths: K NAME a line, K a directory\n  some copy is from, NAME its name (names: the directories' names by index).R2,i171,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta9,json-failm10,R13,TR5,L1,V3,Myn1,sm2,R10,R11,R19,R20,R2,i182,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta9,read-jsonm10,R5,L1,V1,Myn1,sm2,R10,R11,R0,s54,The JSON value of text s (an error on malformed text).R2,i185,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta14,metadata-path?m10,R5,L1,V1,Myn1,pm2,R10,R11,R0,s77,A native-image metadata file j2g reads (META-INF/native-image/.../NAME.json).R2,i246,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta12,condition-ofm10,R13,TR5,L1,V1,R21,R2,i252,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta16,reflection-specsm12,R13,TR5,L1,V1,R21,R0,s260,The root specs of one reflection entry: the class itself (its initializer: Class.forName finds a\n  translated class), its constructors when the entry asks for them or names <init>, its members of\n  the names it lists, every member when it asks for all methods.R2,i256,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta14,metadata-rootsm10,R5,L1,V2,Myn4,pathm2,R10,R11,R22,R0,s487,The roots of one metadata file's JSON value v (its file name decides the format): [[condition\n  [spec ...]] ...], condition a service-like binary name (nil: unconditional). reflect-config and\n  jni-config are arrays of reflection entries; reachability-metadata.json has :reflection, :jni and\n  :bundles; resource-config.json's bundles name ResourceBundle classes (their constructors, as\n  ResourceBundle.getBundle makes them); resource patterns need no root (every resource is embedded).R2,i275,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta19,data-metadata-rootsm10,R5,L1,V1,R16,R0,s154,The roots of every metadata file of data ({path text-fn}): [[condition [spec ...]] ...] in path\n  order, and :errors [[path message] ...] in its metadata.R2,i294,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta12,const-stringm10,R13,TR5,L1,V1,R23,R2,i306,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta16,class-lit-binarym10,R13,TR5,L1,V1,R23,R2,i310,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta16,reflective-callsm22,V2,s15,java/lang/Classs14,getConstructorR24,V2,s37,java/lang/invoke/MethodHandles$Lookups10,findStaticR25,V2,s15,java/lang/Classs16,getDeclaredFieldR26,V2,s15,java/lang/Classs9,getMethodR27,V2,s21,java/lang/ClassLoaders9,loadClassR28,V2,s15,java/lang/Classs22,getDeclaredConstructorR24,V2,s37,java/lang/invoke/MethodHandles$Lookups11,findVirtualR25,V2,s15,java/lang/Classs17,getDeclaredMethodR27,V2,s15,java/lang/Classs8,getFieldR26,V2,s15,java/lang/Classs7,forNameR28,V2,s37,java/lang/invoke/MethodHandles$Lookups15,findConstructorR29,m10,R13,TR2,i315,R3,i1,R4,s18,arbace/j2g/meta.aeR0,s152,[owner name] of the reflective calls whose first argument names a class (:class) or a member of\n  the receiver's class literal (:member, :ctor, :field).v15,arbace.j2g.meta10,site-rootsm10,R5,L1,V1,R30,R0,s494,The root specs of one analyzed node, when it is a reflective call whose names are constants:\n  Class.forName(\"p.C\") (and ClassLoader.loadClass) the class (its initializer); C.class.getMethod(\"m\",\n  ...) C's members named m; C.class.getConstructor(...) C's constructors; C.class.getField(\"f\") the\n  class; a Lookup's findVirtual and findStatic of (C.class, \"m\", ...) C#m, findConstructor C's\n  constructors. Returns [:rooted specs], [:dynamic what] for a site whose name is not constant, or nil.R2,i330,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta16,reflective-sitesm10,R5,L1,V1,R31,R0,s190,The reflective call sites of the analyzed classes ns (internal names; in the world a/*unit* binds):\n  {:rooted [[class spec] ...] :dynamic [[class what] ...]}, each distinct, in class order.R2,i353,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta10,spec-classm10,R5,L1,V1,Myn4,specm2,R10,R11,R0,s41,The internal name of a root spec's class.R2,i373,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta13,present-specsm10,R5,L1,V1,R32,R0,s69,specs split by whether their class is in the world: [present absent].R2,i378,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta6,top-ofm10,R13,TR5,L1,V1,Myn1,nm2,R10,R11,R2,i387,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta12,names-class?m10,R13,TR5,L1,V2,Myn3,whym2,R10,R11,Myn1,nm2,R10,R11,R2,i389,R3,i1,R4,s18,arbace/j2g/meta.aev15,arbace.j2g.meta8,refusalsm10,R5,L1,V2,R33,R34,R0,s442,The classes j2g refused, by whether the program reaches them: failed, {class cause} (the load's\n  analysis failures and reach's unavailable classes), unavailable, reach's {[class method desc]\n  #{why}}. {:stubbed [[class cause [method-key ...]] ...] :dropped [[class cause] ...]}: stubbed, a\n  reached method of another class needs the class (its operations there throw with the cause);\n  dropped, none does (the class is not in the program).R2,i394,R3,i1,R4,s18,arbace/j2g/meta.ae")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.meta$eval849000004$loading__1927001464__auto____849000005")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.meta$eval849000008$fn__849000009")

var Lit_146 *jrt.String = jrt.Intern("META-INF/arbace/services")

var Lit_147 *jrt.String = jrt.Intern("META-INF/arbace/roots")

var Lit_148 *jrt.String = jrt.Intern("META-INF/arbace/roots/")

var Lit_149 *jrt.String = jrt.Intern("META-INF/arbace/classpath")

var Lit_150 *jrt.String = jrt.Intern("META-INF/arbace/owners")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.meta$classpath_index_text")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.meta$owners_text")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.meta$classpath_property")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.meta$root_path")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.meta$unroot")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.meta$by_plain_path")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.meta$java_name_QMARK_")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.meta$parse_services_file")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.meta$services_path_QMARK_")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.meta$read_provides")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.meta$services")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.meta$distinct_by_first")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.meta$services_text")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.meta$internal")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.meta$service_roots")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.meta$roots_index_text")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.meta$json_fail")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.meta$read_json")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_path_QMARK_")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.meta$condition_of")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.meta$reflection_specs")

var Lit_172 *jrt.String = jrt.Intern("arbace.j2g.meta$metadata_roots")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.meta$data_metadata_roots")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.meta$const_string")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.meta$class_lit_binary")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.meta$site_roots")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.meta$reflective_sites")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.meta$spec_class")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.meta$present_specs")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.meta$top_of")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.meta$names_class_QMARK_")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.meta$refusals")
