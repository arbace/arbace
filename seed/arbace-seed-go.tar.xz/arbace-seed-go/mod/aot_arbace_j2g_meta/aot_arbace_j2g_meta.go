//line aot_arbace_j2g_meta.ae:1
package aot_arbace_j2g_meta

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_access"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A_New() *A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_meta_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_meta_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_j2g_meta_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_meta_A_const_1, A_arbace_j2g_meta_A_const_2, A_arbace_j2g_meta_A_const_3, A_arbace_j2g_meta_A_const_4, A_arbace_j2g_meta_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_meta_eval849000008_fn__849000009_A_New() *A_arbace_j2g_meta_eval849000008_fn__849000009_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_eval849000008_fn__849000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_meta_eval849000008_fn__849000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_meta_eval849000008_fn__849000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_meta_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_j2g_meta_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_j2g_meta_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_meta_A_const_11.GetRawRoot__O(), A_arbace_j2g_meta_A_const_12) }


















































func A_arbace_j2g_meta_classpath_index_text_A_New() *A_arbace_j2g_meta_classpath_index_text_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_classpath_index_text_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_meta_classpath_index_text_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_meta_classpath_index_text_A) Invoke_O_O__O(self, names__0 any) any {


	var root_23 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var iter__1927001039__auto____2 any; var fnbody__88 any = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A_New(); var tmp1 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A_fn_class = fncls__87d; tmp1 = fncls__87d } else { tmp1 = fncls__87 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_89 any = A_arbace_j2g_meta_A_const_25.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = A_arbace_j2g_meta_A_const_26.GetRawRoot__O(); var arg_93 any = names__0; if linked_90 == nil { tmp3 = ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { tmp3 = linked_90.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_89, arg_92, arg_93) }; arg_26 = tmp2.Invoke_O__O(tmp3); if linked_24 == nil { return ifn_25.Invoke_O__O(arg_26) } else { return linked_24.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_23, arg_26) } }
//line :55:1
func A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A_New() *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A) Invoke_O_O__O(self, s__849000013__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A_New_O_O(self, s__849000013__1); var tmp2 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__86); A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A_fn_class = fncls__85d; tmp2 = fncls__85d } else { tmp2 = fncls__85 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :55:1
func A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A) Ctor_O_O(c__iter__849000012, c__s__849000013 any) { t.F_iter__849000012 = c__iter__849000012; t.F_s__849000013 = c__s__849000013 }
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A) Invoke_O__O(self any) any { { var s__849000013__1 any; var t_ any = t.F_s__849000013; t.F_s__849000013 = nil; s__849000013__1 = t_; for { var temp__1927000414__auto____2 any; var root_27 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = s__849000013__1; if linked_28 == nil { temp__1927000414__auto____2 = ifn_29.Invoke_O__O(arg_30) } else { temp__1927000414__auto____2 = linked_28.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000013__3 any = temp__1927000414__auto____2; var tmp1 any; var root_31 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__849000013__3; if linked_32 == nil { tmp1 = ifn_33.Invoke_O__O(arg_34) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_35 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__849000013__3; if linked_36 == nil { c__1927001037__auto____4 = ifn_37.Invoke_O__O(arg_38) } else { c__1927001037__auto____4 = linked_36.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_35, arg_38) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000015__6 any; var root_39 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_40 == nil { b__849000015__6 = ifn_41.Invoke_O__O(arg_42) } else { b__849000015__6 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_39, arg_42) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__49 any = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A_New_O_I_O(b__849000015__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__49); A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__49, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_50 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any; var root_55 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = b__849000015__6; if linked_56 == nil { arg_53 = ifn_57.Invoke_O__O(arg_58) } else { arg_53 = linked_56.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_55, arg_58) }; var arg_54 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000012); var tmp5 any; var root_59 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = s__849000013__3; if linked_60 == nil { tmp5 = ifn_61.Invoke_O__O(arg_62) } else { tmp5 = linked_60.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_59, arg_62) }; arg_54 = tmp4.Invoke_O__O(tmp5); if linked_51 == nil { return ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { return linked_51.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_50, arg_53, arg_54) } } else { var root_63 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_68 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = b__849000015__6; if linked_69 == nil { arg_66 = ifn_70.Invoke_O__O(arg_71) } else { arg_66 = linked_69.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_68, arg_71) }; var arg_67 any; if linked_64 == nil { return ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { return linked_64.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) } } } else { var vec__849000023__4 any; var root_72 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = s__849000013__3; if linked_73 == nil { vec__849000023__4 = ifn_74.Invoke_O__O(arg_75) } else { vec__849000023__4 = linked_73.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_72, arg_75) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000023__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000023__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_76 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__5, nil, n__6, nil)).Ref(); var arg_80 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000012); var tmp7 any; var root_81 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = s__849000013__3; if linked_82 == nil { tmp7 = ifn_83.Invoke_O__O(arg_84) } else { tmp7 = linked_82.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_81, arg_84) }; arg_80 = tmp6.Invoke_O__O(tmp7); if linked_77 == nil { return ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { return linked_77.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A) Ctor_O_I_O(c__b__849000015 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000015 = c__b__849000015; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :55:1
func (t *A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A) Invoke_O__O(self any) any { { var i__849000014__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000014__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000019__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000014__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000019__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000019__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_43 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = t.F_b__849000015; var arg_47 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__3, nil, n__4, nil)).Ref(); if linked_44 == nil { ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { linked_44.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; i__849000014__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000014__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_meta_owners_text_A_New() *A_arbace_j2g_meta_owners_text_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_owners_text_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_j2g_meta_owners_text_A) Ctor() {}
//line :57:1
func (t *A_arbace_j2g_meta_owners_text_A) Invoke_O_O__O(self, owners__0 any) any {


	var root_94 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var iter__1927001039__auto____2 any; var fnbody__159 any = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A_New(); var tmp1 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A_fn_class = fncls__158d; tmp1 = fncls__158d } else { tmp1 = fncls__158 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__159, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_160 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = owners__0; if linked_161 == nil { tmp3 = ifn_162.Invoke_O__O(arg_163) } else { tmp3 = linked_161.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_160, arg_163) }; arg_97 = tmp2.Invoke_O__O(tmp3); if linked_95 == nil { return ifn_96.Invoke_O__O(arg_97) } else { return linked_95.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_94, arg_97) } }
//line :60:1
func A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A_New() *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A) Invoke_O_O__O(self, s__849000030__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__157 any = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A_New_O_O(s__849000030__1, self); var tmp2 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__157); A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A_fn_class = fncls__156d; tmp2 = fncls__156d } else { tmp2 = fncls__156 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__157, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :60:1
func A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A) Ctor_O_O(c__s__849000030, c__iter__849000029 any) { t.F_s__849000030 = c__s__849000030; t.F_iter__849000029 = c__iter__849000029 }
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A) Invoke_O__O(self any) any { { var s__849000030__1 any; var t_ any = t.F_s__849000030; t.F_s__849000030 = nil; s__849000030__1 = t_; for { var temp__1927000414__auto____2 any; var root_98 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = s__849000030__1; if linked_99 == nil { temp__1927000414__auto____2 = ifn_100.Invoke_O__O(arg_101) } else { temp__1927000414__auto____2 = linked_99.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_98, arg_101) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000030__3 any = temp__1927000414__auto____2; var tmp1 any; var root_102 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = s__849000030__3; if linked_103 == nil { tmp1 = ifn_104.Invoke_O__O(arg_105) } else { tmp1 = linked_103.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_102, arg_105) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_106 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = s__849000030__3; if linked_107 == nil { c__1927001037__auto____4 = ifn_108.Invoke_O__O(arg_109) } else { c__1927001037__auto____4 = linked_107.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_106, arg_109) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000032__6 any; var root_110 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_111 == nil { b__849000032__6 = ifn_112.Invoke_O__O(arg_113) } else { b__849000032__6 = linked_111.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_110, arg_113) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A_New_O_I_O(b__849000032__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__120); A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_121 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var root_126 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = b__849000032__6; if linked_127 == nil { arg_124 = ifn_128.Invoke_O__O(arg_129) } else { arg_124 = linked_127.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_126, arg_129) }; var arg_125 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000029); var tmp5 any; var root_130 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = s__849000030__3; if linked_131 == nil { tmp5 = ifn_132.Invoke_O__O(arg_133) } else { tmp5 = linked_131.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_130, arg_133) }; arg_125 = tmp4.Invoke_O__O(tmp5); if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } } else { var root_134 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any; var root_139 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = b__849000032__6; if linked_140 == nil { arg_137 = ifn_141.Invoke_O__O(arg_142) } else { arg_137 = linked_140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_139, arg_142) }; var arg_138 any; if linked_135 == nil { return ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { return linked_135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) } } } else { var vec__849000040__4 any; var root_143 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = s__849000030__3; if linked_144 == nil { vec__849000040__4 = ifn_145.Invoke_O__O(arg_146) } else { vec__849000040__4 = linked_144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_143, arg_146) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000040__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000040__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_147 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__5, nil, p__6, nil)).Ref(); var arg_151 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000029); var tmp7 any; var root_152 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = s__849000030__3; if linked_153 == nil { tmp7 = ifn_154.Invoke_O__O(arg_155) } else { tmp7 = linked_153.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_152, arg_155) }; arg_151 = tmp6.Invoke_O__O(tmp7); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :60:1
func A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A) Ctor_O_I_O(c__b__849000032 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000032 = c__b__849000032; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :60:1
func (t *A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A) Invoke_O__O(self any) any { { var i__849000031__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000031__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000036__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000031__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_114 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = t.F_b__849000032; var arg_118 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__3, nil, p__4, nil)).Ref(); if linked_115 == nil { ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { linked_115.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) }; i__849000031__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000031__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_meta_classpath_property_A_New() *A_arbace_j2g_meta_classpath_property_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_classpath_property_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_j2g_meta_classpath_property_A) Ctor() {}
//line :62:1
func (t *A_arbace_j2g_meta_classpath_property_A) Invoke_O_O__O(self, names__0 any) any {


	var root_164 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = Lit_15; var arg_168 any = names__0; if linked_165 == nil { return ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { return linked_165.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_164, arg_167, arg_168)
	} }
func A_arbace_j2g_meta_root_path_A_New() *A_arbace_j2g_meta_root_path_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_root_path_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_meta_root_path_A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_meta_root_path_A) Invoke_O_O_O__O(self, k__0, p__1 any) any {


	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_28.GetRawRoot__O(), k__0, nil, p__1)).Ref()
}
func A_arbace_j2g_meta_unroot_A_New() *A_arbace_j2g_meta_unroot_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_unroot_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_j2g_meta_unroot_A) Ctor() {}
//line :72:1
func (t *A_arbace_j2g_meta_unroot_A) Invoke_O_O__O(self, p__0 any) any { var temp__1927000408__auto____2 any; var root_169 any = A_arbace_j2g_meta_A_const_29.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_171 lang.IFn; if


	linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_j2g_meta_A_const_30; var arg_173 any = p__0; if linked_170 == nil { temp__1927000408__auto____2 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { temp__1927000408__auto____2 = linked_170.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__849000048__3 any = temp__1927000408__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000048__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000048__3, lang.RT_IntCast_J__I_NoInit(1), nil); var q__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000048__3, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(k__5))).Ref(), q__6) } else { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_meta_A_const_31, p__0) } }



func A_arbace_j2g_meta_by_plain_path_A_New() *A_arbace_j2g_meta_by_plain_path_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_j2g_meta_by_plain_path_A) Ctor() {}
//line :79:1
func (t *A_arbace_j2g_meta_by_plain_path_A) Invoke_O_O__O(self, ps__0 any) any {




	var root_174 any = A_arbace_j2g_meta_A_const_32.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = lang.IFn_Cast(A_arbace_j2g_meta_A_const_33.GetRawRoot__O()).Invoke__O(); var arg_178 any; var iter__1927001039__auto____2 any; var fnbody__281 any = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A_New(); var tmp1 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A_fn_class
	if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A_fn_class = fncls__280d; tmp1 = fncls__280d } else { tmp1 = fncls__280 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__281, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_282 any = A_arbace_j2g_meta_A_const_37.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var fnbody__296 any = A_arbace_j2g_meta_by_plain_path_fn__849000074_A_New(); var tmp4 *jrt.Class; var fncls__295 *jrt.Class = A_arbace_j2g_meta_by_plain_path_fn__849000074_A_fn_class; if fncls__295 == nil { var fncls__295d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_j2g_meta_by_plain_path_fn__849000074_A_fn_class = fncls__295d; tmp4 = fncls__295d } else { tmp4 = fncls__295 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__296, tmp4, nil); var arg_286 any = ps__0; if linked_283 == nil { tmp3 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { tmp3 = linked_283.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; arg_178 = tmp2.Invoke_O__O(tmp3)
//line :84:1
	if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } }
func A_arbace_j2g_meta_by_plain_path_fn__849000074_A_New() *A_arbace_j2g_meta_by_plain_path_fn__849000074_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_fn__849000074_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_fn__849000074_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_fn__849000074_A) Invoke_O_O__O(self, p1__849000052_SHARP___1 any) any { var root_287 any = A_arbace_j2g_meta_A_const_38.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any; var root_291 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = p1__849000052_SHARP___1; if linked_292 == nil { arg_290 = ifn_293.Invoke_O__O(arg_294) } else { arg_290 = linked_292.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_291, arg_294) }; if linked_288 == nil { return ifn_289.Invoke_O__O(arg_290) } else { return linked_288.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_287, arg_290) } }
//line :85:1
func A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A_New() *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A) Invoke_O_O__O(self, s__849000055__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__279 any = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A_New_O_O(self, s__849000055__1); var tmp2 *jrt.Class; var fncls__278 *jrt.Class = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A_fn_class; if fncls__278 == nil { var fncls__278d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__279); A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A_fn_class = fncls__278d; tmp2 = fncls__278d } else { tmp2 = fncls__278 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__279, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :85:1
func A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A) Ctor_O_O(c__iter__849000054, c__s__849000055 any) { t.F_iter__849000054 = c__iter__849000054; t.F_s__849000055 = c__s__849000055 }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A) Invoke_O__O(self any) any { { var s__849000055__1 any; var t_ any = t.F_s__849000055; t.F_s__849000055 = nil; s__849000055__1 = t_; for { var temp__1927000414__auto____2 any; var root_182 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__849000055__1; if linked_183 == nil { temp__1927000414__auto____2 = ifn_184.Invoke_O__O(arg_185) } else { temp__1927000414__auto____2 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000055__3 any = temp__1927000414__auto____2; var tmp1 any; var root_186 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__849000055__3; if linked_187 == nil { tmp1 = ifn_188.Invoke_O__O(arg_189) } else { tmp1 = linked_187.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_190 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__849000055__3; if linked_191 == nil { c__1927001037__auto____4 = ifn_192.Invoke_O__O(arg_193) } else { c__1927001037__auto____4 = linked_191.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_190, arg_193) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000057__6 any; var root_194 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_195 == nil { b__849000057__6 = ifn_196.Invoke_O__O(arg_197) } else { b__849000057__6 = linked_195.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_194, arg_197) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__223 any = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A_New_O_I_O(b__849000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__223); A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__223, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_224 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any; var root_229 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = b__849000057__6; if linked_230 == nil { arg_227 = ifn_231.Invoke_O__O(arg_232) } else { arg_227 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_229, arg_232) }; var arg_228 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000054); var tmp5 any; var root_233 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = s__849000055__3; if linked_234 == nil { tmp5 = ifn_235.Invoke_O__O(arg_236) } else { tmp5 = linked_234.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_233, arg_236) }; arg_228 = tmp4.Invoke_O__O(tmp5); if linked_225 == nil { return ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { return linked_225.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) } } else { var root_237 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any; var root_242 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = b__849000057__6; if linked_243 == nil { arg_240 = ifn_244.Invoke_O__O(arg_245) } else { arg_240 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_242, arg_245) }; var arg_241 any; if linked_238 == nil { return ifn_239.Invoke_O_O__O(arg_240, arg_241) } else { return linked_238.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_237, arg_240, arg_241) } } } else { var vec__849000067__4 any; var root_246 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = s__849000055__3; if linked_247 == nil { vec__849000067__4 = ifn_248.Invoke_O__O(arg_249) } else { vec__849000067__4 = linked_247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_246, arg_249) }; var q__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000067__4, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000067__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_250 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any; var tmp6 any; var root_255 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_257 lang.IFn
														if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var root_259 any = A_arbace_j2g_meta_A_const_35.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var fnbody__273 any = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A_New(); var tmp7 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A_fn_class; if fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A_fn_class = fncls__272d; tmp7 = fncls__272d } else { tmp7 = fncls__272 }; arg_262 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__273, tmp7, nil); var arg_263 any = xs__6; if linked_260 == nil { arg_258 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { arg_258 = linked_260.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }; if linked_256 == nil { tmp6 = ifn_257.Invoke_O__O(arg_258) } else { tmp6 = linked_256.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_255, arg_258) }
//line :85:1
	arg_253 = lang.Tuple_Create_O_O__IPersistentVector(q__5, tmp6); var arg_254 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000054); var tmp9 any; var root_274 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = s__849000055__3; if linked_275 == nil { tmp9 = ifn_276.Invoke_O__O(arg_277) } else { tmp9 = linked_275.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_274, arg_277) }; arg_254 = tmp8.Invoke_O__O(tmp9); if linked_251 == nil { return ifn_252.Invoke_O_O__O(arg_253, arg_254) } else { return linked_251.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_250, arg_253, arg_254) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :85:1
func A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A) Ctor_O_I_O(c__b__849000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000057 = c__b__849000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :85:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A) Invoke_O__O(self any) any { { var i__849000056__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000056__1)); var q__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_198 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = t.F_b__849000057; var arg_202 any; var tmp2 any; var root_203 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_205 lang.IFn
																if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_207 any = A_arbace_j2g_meta_A_const_35.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var fnbody__221 any = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; arg_210 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__221, tmp3, nil); var arg_211 any = xs__4; if linked_208 == nil { arg_206 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; if linked_204 == nil { tmp2 = ifn_205.Invoke_O__O(arg_206) } else { tmp2 = linked_204.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_203, arg_206) }
//line :85:1
	arg_202 = lang.Tuple_Create_O_O__IPersistentVector(q__3, tmp2); if linked_199 == nil { ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { linked_199.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; i__849000056__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000056__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A_New() *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A) Ctor() {}
//line :86:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A) Invoke_O_O__O(self, p1__849000053_SHARP___1 any) any { var root_212 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_216 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = p1__849000053_SHARP___1; if linked_217 == nil { arg_215 = ifn_218.Invoke_O__O(arg_219) } else { arg_215 = linked_217.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_216, arg_219) }; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_212, arg_215) } }
//line :86:1
func A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A_New() *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A) Ctor() {}
//line :86:1
func (t *A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A) Invoke_O_O__O(self, p1__849000053_SHARP___1 any) any { var root_264 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = p1__849000053_SHARP___1; if linked_269 == nil { arg_267 = ifn_270.Invoke_O__O(arg_271) } else { arg_267 = linked_269.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_268, arg_271) }; if linked_265 == nil { return ifn_266.Invoke_O__O(arg_267) } else { return linked_265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_264, arg_267) } }




func A_arbace_j2g_meta_java_name_QMARK__A_New() *A_arbace_j2g_meta_java_name_QMARK__A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_java_name_QMARK__A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_j2g_meta_java_name_QMARK__A) Ctor() {}
//line :91:1
func (t *A_arbace_j2g_meta_java_name_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s__0))); if and__1927000168__auto____2 {

	var root_297 any = A_arbace_j2g_meta_A_const_39.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var fnbody__314 any = A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A_New(); var tmp1 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A_fn_class = fncls__313d; tmp1 = fncls__313d } else { tmp1 = fncls__313 }; arg_300 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__314, tmp1, nil); var arg_301 any; var root_315 any = A_arbace_j2g_meta_A_const_40.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_317 lang.IFn


	if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = s__0; var arg_319 any = A_arbace_j2g_meta_A_const_41; var arg_320 any = A_arbace_j2g_meta_A_const_31; if linked_316 == nil { arg_301 = ifn_317.Invoke_O_O_O__O(arg_318, arg_319, arg_320) } else { arg_301 = linked_316.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_315, arg_318, arg_319, arg_320) }
//line :93:1
	if linked_298 == nil { return ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { return linked_298.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_297, arg_300, arg_301) } } else {
//line :92:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A_New() *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A) Invoke_O_O__O(self, part__1 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(part__1))); if and__1927000168__auto____2 { var and__1927000168__auto____3 bool = jrt.Character_IsJavaIdentifierStart_C__Z_NoInit(jrt.NN(jrt.String_Cast(part__1)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____3 {

	var root_302 any = A_arbace_j2g_meta_A_const_39.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var fnbody__308 any = A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A_New(); var tmp1 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A_fn_class = fncls__307d; tmp1 = fncls__307d } else { tmp1 = fncls__307 }; arg_305 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__308, tmp1, nil); var arg_306 any; var root_309 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = part__1; if linked_310 == nil { arg_306 = ifn_311.Invoke_O__O(arg_312) } else { arg_306 = linked_310.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_309, arg_312) }; if linked_303 == nil { return ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { return linked_303.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_302, arg_305, arg_306) } } else {
//line :93:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A_New() *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A) Invoke_O_O__O(self, p1__849000077_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsJavaIdentifierPart_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(p1__849000077_SHARP___1))).Ref() }


func A_arbace_j2g_meta_parse_services_file_A_New() *A_arbace_j2g_meta_parse_services_file_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_parse_services_file_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_j2g_meta_parse_services_file_A) Ctor() {}
//line :98:1
func (t *A_arbace_j2g_meta_parse_services_file_A) Invoke_O_O__O(self, text__0 any) any { { var G__849000086__2_ any; var root_321 any = A_arbace_j2g_meta_A_const_42.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_323 lang.IFn




	if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = text__0; if linked_322 == nil { G__849000086__2_ = ifn_323.Invoke_O__O(arg_324) } else { G__849000086__2_ = linked_322.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_321, arg_324) }
//line :98:1
	var vec__849000087__3 any = G__849000086__2_; var seq__849000088__4 any; var root_325 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_327 lang.IFn




	if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = vec__849000087__3; if linked_326 == nil { seq__849000088__4 = ifn_327.Invoke_O__O(arg_328) } else { seq__849000088__4 = linked_326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_325, arg_328) }
//line :98:1
	var first__849000089__5 any; var root_329 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_331 lang.IFn




	if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = seq__849000088__4; if linked_330 == nil { first__849000089__5 = ifn_331.Invoke_O__O(arg_332) } else { first__849000089__5 = linked_330.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_329, arg_332) }
//line :98:1
	var seq__849000088__6 any; var root_333 any = A_arbace_j2g_meta_A_const_43.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_335 lang.IFn




	if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = seq__849000088__4; if linked_334 == nil { seq__849000088__6 = ifn_335.Invoke_O__O(arg_336) } else { seq__849000088__6 = linked_334.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_333, arg_336) }
//line :98:1
	var l__7 any = first__849000089__5; var more__8 any = seq__849000088__6; var ps__9 any = lang.PersistentVector_EMPTY.Ref(); var bad__10 any = lang.PersistentVector_EMPTY.Ref(); var G__849000086__11_ any = G__849000086__2_; var ps__12 any = ps__9; var bad__13 any = bad__10; _ = l__7; _ = more__8; L1: for { var vec__849000090__14 any = G__849000086__11_; var seq__849000091__15 any; var root_337 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_339 lang.IFn




		if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = vec__849000090__14; if linked_338 == nil { seq__849000091__15 = ifn_339.Invoke_O__O(arg_340) } else { seq__849000091__15 = linked_338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_337, arg_340) }
//line :98:1
		var first__849000092__16 any; var root_341 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_343 lang.IFn




		if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = seq__849000091__15; if linked_342 == nil { first__849000092__16 = ifn_343.Invoke_O__O(arg_344) } else { first__849000092__16 = linked_342.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_341, arg_344) }
//line :98:1
		var seq__849000091__17 any; var root_345 any = A_arbace_j2g_meta_A_const_43.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_347 lang.IFn




		if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = seq__849000091__15; if linked_346 == nil { seq__849000091__17 = ifn_347.Invoke_O__O(arg_348) } else { seq__849000091__17 = linked_346.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_345, arg_348) }
//line :98:1
		var l__18 any = first__849000092__16
		var more__19 any = seq__849000091__17
		var ps__20 any = ps__12
		var bad__21 any = bad__13


		if lang.Util_Identical_O_O__Z_NoInit(l__18, nil) { var tmp1 any; var root_363 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_365 lang.IFn
			if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; var root_367 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = ps__20; if linked_368 == nil { arg_366 = ifn_369.Invoke_O__O(arg_370) } else { arg_366 = linked_368.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_367, arg_370) }; if linked_364 == nil { tmp1 = ifn_365.Invoke_O__O(arg_366) } else { tmp1 = linked_364.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_363, arg_366) }
//line :104:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp1, bad__21) } else { var i__22 int32 = jrt.NN(jrt.String_Cast(l__18)).IndexOf_String__I(Lit_46); var n__23 any; var root_349 any = A_arbace_j2g_meta_A_const_44.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_351 lang.IFn


				if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__22)) { arg_352 = l__18 } else { var root_353 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = l__18; var arg_357 any = A_arbace_j2g_meta_A_const_46; var arg_358 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__22).Ref(); if linked_354 == nil { arg_352 = ifn_355.Invoke_O_O_O__O(arg_356, arg_357, arg_358) } else { arg_352 = linked_354.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_353, arg_356, arg_357, arg_358) } }; if linked_350 == nil { n__23 = ifn_351.Invoke_O__O(arg_352) } else { n__23 = linked_350.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_349, arg_352) }
				if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, n__23) { G__849000086__11_, ps__12, bad__13 = more__19, ps__20, bad__21; continue L1 } else { var tmp2 any; var root_359 any = A_arbace_j2g_meta_A_const_47.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_j2g_meta_java_name_QMARK__A_fn_class); var ifn_361 lang.IFn
					if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = n__23; if linked_360 == nil { tmp2 = ifn_361.Invoke_O__O(arg_362) } else { tmp2 = linked_360.(*A_arbace_j2g_meta_java_name_QMARK__A).Invoke_O_O__O(root_359, arg_362) }
//line :108:1
					if jrt.J2g_Truth(tmp2) {
						var tmp3 any; var root_371 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = ps__20; var arg_375 any = n__23; if linked_372 == nil { tmp3 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp3 = linked_372.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; G__849000086__11_, ps__12, bad__13 = more__19, tmp3, bad__21; continue L1 } else {
//line :108:1
							if A_arbace_j2g_meta_A_const_48 != nil {

								var tmp4 any; var root_376 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = bad__21; var arg_380 any = l__18; if linked_377 == nil { tmp4 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { tmp4 = linked_377.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }; G__849000086__11_, ps__12, bad__13 = more__19, ps__20, tmp4; continue L1 } else {
//line :108:1
									return nil } } } } } }; /*line :98:1*/panic("j2g: unreachable") }













func A_arbace_j2g_meta_services_path_QMARK__A_New() *A_arbace_j2g_meta_services_path_QMARK__A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_path_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_j2g_meta_services_path_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_j2g_meta_services_path_QMARK__A) Invoke_O_O__O(self, p__0 any) any {
	var tmp1 any; var root_381 any = A_arbace_j2g_meta_A_const_29.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_j2g_meta_A_const_50; var arg_385 any; var root_386 any = A_arbace_j2g_meta_A_const_38.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var root_390 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = p__0; if linked_391 == nil { arg_389 = ifn_392.Invoke_O__O(arg_393) } else { arg_389 = linked_391.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_390, arg_393) }; if linked_387 == nil { arg_385 = ifn_388.Invoke_O__O(arg_389) } else { arg_385 = linked_387.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_386, arg_389) }; if linked_382 == nil { tmp1 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { tmp1 = linked_382.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_meta_read_provides_A_New() *A_arbace_j2g_meta_read_provides_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_provides_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_meta_read_provides_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_meta_read_provides_A) Invoke_O_O__O(self, f__0 any) any { var f__2 any; var root_394 any = A_arbace_j2g_meta_A_const_51.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_396 lang.IFn; if



	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = f__0; if linked_395 == nil { f__2 = ifn_396.Invoke_O__O(arg_397) } else { f__2 = linked_395.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_394, arg_397) }; if
	jrt.File_Cast(f__2).IsFile__Z() {
		var root_398 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var iter__1927001039__auto____3 any; var fnbody__515 any = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A_New(); var tmp1 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A_fn_class = fncls__514d; tmp1 = fncls__514d } else { tmp1 = fncls__514 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__515, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_516 any = A_arbace_j2g_meta_A_const_42.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = lang.IFn_Cast(A_arbace_j2g_meta_A_const_55.GetRawRoot__O()).Invoke_O__O(f__2); if linked_517 == nil { tmp3 = ifn_518.Invoke_O__O(arg_519) } else { tmp3 = linked_517.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_516, arg_519) }; arg_401 = tmp2.Invoke_O__O(tmp3); if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_398, arg_401) } } else {
//line :120:1
			return lang.PersistentVector_EMPTY.Ref() } }
func A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A_New() *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A) Ctor() {}
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A) Invoke_O_O__O(self, s__849000096__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__513 any = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A_New_O_O(self, s__849000096__1); var tmp2 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__513); A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A_fn_class = fncls__512d; tmp2 = fncls__512d } else { tmp2 = fncls__512 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__513, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :121:1
func A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A) Ctor_O_O(c__iter__849000095, c__s__849000096 any) { t.F_iter__849000095 = c__iter__849000095; t.F_s__849000096 = c__s__849000096 }
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A) Invoke_O__O(self any) any { { var s__849000096__1 any; var t_ any = t.F_s__849000096; t.F_s__849000096 = nil; s__849000096__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_402 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__849000096__1; if linked_403 == nil { temp__1927000414__auto____2 = ifn_404.Invoke_O__O(arg_405) } else { temp__1927000414__auto____2 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000096__3 any = temp__1927000414__auto____2; var tmp1 any; var root_406 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__849000096__3; if linked_407 == nil { tmp1 = ifn_408.Invoke_O__O(arg_409) } else { tmp1 = linked_407.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_410 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__849000096__3; if linked_411 == nil { c__1927001037__auto____4 = ifn_412.Invoke_O__O(arg_413) } else { c__1927001037__auto____4 = linked_411.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_410, arg_413) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000098__6 any; var root_414 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_415 == nil { b__849000098__6 = ifn_416.Invoke_O__O(arg_417) } else { b__849000098__6 = linked_415.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_414, arg_417) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__446 any = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A_New_O_I_O(b__849000098__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__445 *jrt.Class = A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A_fn_class; if fncls__445 == nil { var fncls__445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__446); A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A_fn_class = fncls__445d; tmp3 = fncls__445d } else { tmp3 = fncls__445 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__446, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_447 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var root_452 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = b__849000098__6; if linked_453 == nil { arg_450 = ifn_454.Invoke_O__O(arg_455) } else { arg_450 = linked_453.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_452, arg_455) }; var arg_451 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000095); var tmp5 any; var root_456 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = s__849000096__3; if linked_457 == nil { tmp5 = ifn_458.Invoke_O__O(arg_459) } else { tmp5 = linked_457.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_456, arg_459) }; arg_451 = tmp4.Invoke_O__O(tmp5); if linked_448 == nil { return ifn_449.Invoke_O_O__O(arg_450, arg_451) } else { return linked_448.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_447, arg_450, arg_451) } } else { var root_460 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var root_465 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = b__849000098__6; if linked_466 == nil { arg_463 = ifn_467.Invoke_O__O(arg_468) } else { arg_463 = linked_466.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_465, arg_468) }; var arg_464 any; if linked_461 == nil { return ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { return linked_461.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_460, arg_463, arg_464) } } } else { var l__4 any; var root_469 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = s__849000096__3; if linked_470 == nil { l__4 = ifn_471.Invoke_O__O(arg_472) } else { l__4 = linked_470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_469, arg_472) }; var l__5 any; var root_473 any = A_arbace_j2g_meta_A_const_44.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_475 lang.IFn
														if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = l__4; if linked_474 == nil { l__5 = ifn_475.Invoke_O__O(arg_476) } else { l__5 = linked_474.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_473, arg_476) }
//line :121:1
	var tmp6 any; var and__1927000168__auto____6 any; var root_477 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_479 lang.IFn

	if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = l__5; if linked_478 == nil { and__1927000168__auto____6 = ifn_479.Invoke_O__O(arg_480) } else { and__1927000168__auto____6 = linked_478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_477, arg_480) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_481 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var root_485 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = l__5; var arg_489 any = Lit_46; if linked_486 == nil { arg_484 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { arg_484 = linked_486.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; if linked_482 == nil { tmp6 = ifn_483.Invoke_O__O(arg_484) } else { tmp6 = linked_482.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_481, arg_484) } } else { tmp6 = and__1927000168__auto____6 }
//line :121:1
	if jrt.J2g_Truth(tmp6) { var vec__849000106__6 any; var root_490 any = A_arbace_j2g_meta_A_const_40.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_492 lang.IFn


		if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = l__5; var arg_494 any = A_arbace_j2g_meta_A_const_54; if linked_491 == nil { vec__849000106__6 = ifn_492.Invoke_O_O__O(arg_493, arg_494) } else { vec__849000106__6 = linked_491.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_490, arg_493, arg_494) }
//line :121:1
		var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000106__6, lang.RT_IntCast_J__I_NoInit(0), nil); var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000106__6, lang.RT_IntCast_J__I_NoInit(1), nil); var p__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000106__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp7 any; var and__1927000168__auto____10 any = s__8; _ = ___7



		if jrt.J2g_Truth(and__1927000168__auto____10) { tmp7 = p__9 } else { tmp7 = and__1927000168__auto____10 }
//line :121:1
		if jrt.J2g_Truth(tmp7) { var root_495 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = lang.Tuple_Create_O_O__IPersistentVector(s__8, p__9); var arg_499 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000095); var tmp9 any; var root_500 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = s__849000096__3; if linked_501 == nil { tmp9 = ifn_502.Invoke_O__O(arg_503) } else { tmp9 = linked_501.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_500, arg_503) }; arg_499 = tmp8.Invoke_O__O(tmp9); if linked_496 == nil { return ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { return linked_496.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) } } else { var tmp10 any; var root_504 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = s__849000096__3; if linked_505 == nil { tmp10 = ifn_506.Invoke_O__O(arg_507) } else { tmp10 = linked_505.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_504, arg_507) }; s__849000096__1 = tmp10; continue L1 } } else { var tmp11 any; var root_508 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = s__849000096__3; if linked_509 == nil { tmp11 = ifn_510.Invoke_O__O(arg_511) } else { tmp11 = linked_509.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_508, arg_511) }; s__849000096__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :121:1
func A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A) Ctor_O_I_O(c__b__849000098 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000098 = c__b__849000098; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :121:1
func (t *A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A) Invoke_O__O(self any) any { { var i__849000097__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000097__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000097__1)); var l__3 any; var root_418 any = A_arbace_j2g_meta_A_const_44.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_420 lang.IFn
																if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = l__2; if linked_419 == nil { l__3 = ifn_420.Invoke_O__O(arg_421) } else { l__3 = linked_419.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_418, arg_421) }
//line :121:1
	var tmp2 any; var and__1927000168__auto____4 any; var root_422 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_424 lang.IFn

	if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = l__3; if linked_423 == nil { and__1927000168__auto____4 = ifn_424.Invoke_O__O(arg_425) } else { and__1927000168__auto____4 = linked_423.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_426 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var root_430 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = l__3; var arg_434 any = Lit_46; if linked_431 == nil { arg_429 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { arg_429 = linked_431.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }; if linked_427 == nil { tmp2 = ifn_428.Invoke_O__O(arg_429) } else { tmp2 = linked_427.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_426, arg_429) } } else { tmp2 = and__1927000168__auto____4 }
//line :121:1
	if jrt.J2g_Truth(tmp2) { var vec__849000102__4 any; var root_435 any = A_arbace_j2g_meta_A_const_40.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_437 lang.IFn


		if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = l__3; var arg_439 any = A_arbace_j2g_meta_A_const_54; if linked_436 == nil { vec__849000102__4 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { vec__849000102__4 = linked_436.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }
//line :121:1
		var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var p__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000102__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp3 any; var and__1927000168__auto____8 any = s__6; _ = ___5



		if jrt.J2g_Truth(and__1927000168__auto____8) { tmp3 = p__7 } else { tmp3 = and__1927000168__auto____8 }
//line :121:1
		if jrt.J2g_Truth(tmp3) { var root_440 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = t.F_b__849000098; var arg_444 any = lang.Tuple_Create_O_O__IPersistentVector(s__6, p__7); if linked_441 == nil { ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { linked_441.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; i__849000097__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000097__1); continue L1 } else { i__849000097__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000097__1); continue L1 } } else { i__849000097__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000097__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_meta_services_A_New() *A_arbace_j2g_meta_services_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_meta_services_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_meta_services_A) Invoke_O_O_O__O(self, provides__0, data__1 any) any { var files__3 any; var root_524 any = A_arbace_j2g_meta_A_const_56.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_j2g_meta_by_plain_path_A_fn_class); var ifn_526 lang.IFn; if





	linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_528 any = A_arbace_j2g_meta_A_const_57.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = A_arbace_j2g_meta_A_const_58.GetRawRoot__O(); var arg_532 any; var root_533 any = A_arbace_j2g_meta_A_const_59.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = data__1; if linked_534 == nil { arg_532 = ifn_535.Invoke_O__O(arg_536) } else { arg_532 = linked_534.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_533, arg_536) }; if linked_529 == nil { arg_527 = ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { arg_527 = linked_529.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) }; if linked_525 == nil { files__3 = ifn_526.Invoke_O__O(arg_527) } else { files__3 = linked_525.(*A_arbace_j2g_meta_by_plain_path_A).Invoke_O_O__O(root_524, arg_527) }; var acc__4 any; var root_537 any = /*line :129:1*/A_arbace_j2g_meta_A_const_60.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_539 lang.IFn; if






	linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var fnbody__556 any = A_arbace_j2g_meta_services_fn__849000116_A_New(); var tmp1 *jrt.Class; var fncls__555 *jrt.Class = A_arbace_j2g_meta_services_fn__849000116_A_fn_class; if fncls__555 == nil { var fncls__555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_j2g_meta_services_fn__849000116_A_fn_class = fncls__555d; tmp1 = fncls__555d } else { tmp1 = fncls__555 }; arg_540 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__556, tmp1, nil); var arg_541 any = lang.IFn_Cast(A_arbace_j2g_meta_A_const_33.GetRawRoot__O()).Invoke__O(); var arg_542 any = provides__0; if linked_538 == nil { acc__4 = ifn_539.Invoke_O_O_O__O(arg_540, arg_541, arg_542) } else { acc__4 = linked_538.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_537, arg_540, arg_541, arg_542) }; var vec__849000112__5 any; var root_560 any = /*line :129:1*/A_arbace_j2g_meta_A_const_60.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_562 lang.IFn; if







	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any; var fnbody__725 any = A_arbace_j2g_meta_services_fn__849000123_A_New_O(data__1); var tmp2 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_A_fn_class; if fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, fnbody__725); A_arbace_j2g_meta_services_fn__849000123_A_fn_class = fncls__724d; tmp2 = fncls__724d } else { tmp2 = fncls__724 }; arg_563 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__725, tmp2, nil); var arg_564 any = lang.Tuple_Create_O_O__IPersistentVector(acc__4, lang.PersistentVector_EMPTY.Ref()); var arg_565 any = files__3; if linked_561 == nil { vec__849000112__5 = ifn_562.Invoke_O_O_O__O(arg_563, arg_564, arg_565) } else { vec__849000112__5 = linked_561.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_560, arg_563, arg_564, arg_565) }; var acc__6 any = /*line :129:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__849000112__5, lang.RT_IntCast_J__I_NoInit(0), nil); var bad__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000112__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_726 any = A_arbace_j2g_meta_A_const_66.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_728 lang.IFn; if















	linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any; var root_731 any = A_arbace_j2g_meta_A_const_32.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = lang.IFn_Cast(A_arbace_j2g_meta_A_const_33.GetRawRoot__O()).Invoke__O(); var arg_735 any; var iter__1927001039__auto____8 any; var fnbody__860 any = A_arbace_j2g_meta_services_iter__849000160__849000164_A_New(); var tmp3 *jrt.Class; var fncls__859 *jrt.Class = A_arbace_j2g_meta_services_iter__849000160__849000164_A_fn_class; if fncls__859 == nil { var fncls__859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_j2g_meta_services_iter__849000160__849000164_A_fn_class = fncls__859d; tmp3 = fncls__859d } else { tmp3 = fncls__859 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__860, tmp3, nil); arg_735 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(acc__6); if linked_732 == nil { arg_729 = ifn_733.Invoke_O_O__O(arg_734, arg_735) } else { arg_729 = linked_732.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_731, arg_734, arg_735) }; var arg_730 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_71, bad__7)); if linked_727 == nil { return ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { return linked_727.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) } }
//line :136:1
func A_arbace_j2g_meta_services_fn__849000116_A_New() *A_arbace_j2g_meta_services_fn__849000116_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000116_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_j2g_meta_services_fn__849000116_A) Ctor() {}
//line :136:1
func (t *A_arbace_j2g_meta_services_fn__849000116_A) Invoke_O_O_O__O(self, m__1, p__849000115__2 any) any { var vec__849000117__3 any = p__849000115__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000117__3, lang.RT_IntCast_J__I_NoInit(0), nil); var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000117__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_543 any = A_arbace_j2g_meta_A_const_61.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = m__1; var arg_547 any = s__4; var arg_548 any; var root_550 any = A_arbace_j2g_meta_A_const_62.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var arg_554 any = lang.PersistentVector_EMPTY.Ref(); if linked_551 == nil { arg_548 = ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { arg_548 = linked_551.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) }; var arg_549 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, A_arbace_j2g_meta_A_const_63); if linked_544 == nil { return ifn_545.Invoke_O_O_O_O__O(arg_546, arg_547, arg_548, arg_549) } else { return linked_544.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_543, arg_546, arg_547, arg_548, arg_549) } }
func A_arbace_j2g_meta_services_fn__849000123_A_New_O(p0 any) *A_arbace_j2g_meta_services_fn__849000123_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_j2g_meta_services_fn__849000123_A) Ctor_O(c__data any) { t.F_data = c__data }
//line :137:1
func (t *A_arbace_j2g_meta_services_fn__849000123_A) Invoke_O_O_O__O(self, p__849000121__1, p__849000122__2 any) any { var vec__849000124__3 any = p__849000121__1; var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000124__3, lang.RT_IntCast_J__I_NoInit(0), nil); var bad__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000124__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__849000127__6 any = p__849000122__2; var q__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000127__6, lang.RT_IntCast_J__I_NoInit(0), nil); var paths__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000127__6, lang.RT_IntCast_J__I_NoInit(1), nil); var s__9 any; var root_566 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_568 lang.IFn; if
															linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = q__7; var arg_570 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(Lit_118)).Ref(); if linked_567 == nil { s__9 = ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { s__9 = linked_567.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) }; var root_571 any =
															A_arbace_j2g_meta_A_const_60.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any; var fnbody__723 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A_New_O_O(t.F_data, s__9); var tmp1 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__723); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A_fn_class = fncls__722d; tmp1 = fncls__722d } else { tmp1 = fncls__722 }; arg_574 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__723, tmp1, nil); var arg_575 any = lang.Tuple_Create_O_O__IPersistentVector(m__4, bad__5); var arg_576 any = paths__8; if linked_572 == nil { return ifn_573.Invoke_O_O_O__O(arg_574, arg_575, arg_576) } else { return linked_572.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_571, arg_574, arg_575, arg_576) } }
//line :139:1
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A{}; t.Ctor_O_O(p0, p1); return t }
//line :139:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A) Ctor_O_O(c__data, c__s any) { t.F_data = c__data; t.F_s = c__s }
//line :139:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A) Invoke_O_O_O__O(self, p__849000130__1, path__2 any) any { var vec__849000132__3 any = p__849000130__1; var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000132__3, lang.RT_IntCast_J__I_NoInit(0), nil); var bad__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000132__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__849000135__6 any; var root_577 any = A_arbace_j2g_meta_A_const_64.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, A_arbace_j2g_meta_parse_services_file_A_fn_class); var ifn_579 lang.IFn; if
																linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = lang.IFn_Cast(lang.RT_Get_O_O__O_NoInit(t.F_data, path__2)).Invoke__O(); if linked_578 == nil { vec__849000135__6 = ifn_579.Invoke_O__O(arg_580) } else { vec__849000135__6 = linked_578.(*A_arbace_j2g_meta_parse_services_file_A).Invoke_O_O__O(root_577, arg_580) }; var ps__7 any = /*line :139:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__849000135__6, lang.RT_IntCast_J__I_NoInit(0), nil); var b__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000135__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_581 any = A_arbace_j2g_meta_A_const_61.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_583 lang.IFn; if

	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = m__4; var arg_585 any = t.F_s; var arg_586 any; var root_588 any = A_arbace_j2g_meta_A_const_62.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_j2g_meta_A_const_32.GetRawRoot__O(); var arg_592 any = lang.PersistentVector_EMPTY.Ref(); if linked_589 == nil { arg_586 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_586 = linked_589.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; var arg_587 any; var iter__1927001039__auto____9 any; var fnbody__654 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A_New(); var tmp2 *jrt.Class; var fncls__653 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A_fn_class; if fncls__653 == nil { var fncls__653d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A_fn_class = fncls__653d; tmp2 = fncls__653d } else { tmp2 = fncls__653 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__654, tmp2, nil); arg_587 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(ps__7); if linked_582 == nil { tmp1 = ifn_583.Invoke_O_O_O_O__O(arg_584, arg_585, arg_586, arg_587) } else { tmp1 = linked_582.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_581, arg_584, arg_585, arg_586, arg_587) }; var tmp3 any = tmp1; var tmp4 any; var root_655 any = /*line :139:1*/A_arbace_j2g_meta_A_const_32.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_657 lang.IFn; if


	linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = bad__5; var arg_659 any; var iter__1927001039__auto____9_2 any; var fnbody__721 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A_New_O(path__2); var tmp5 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__721); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A_fn_class = fncls__720d; tmp5 = fncls__720d } else { tmp5 = fncls__720 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__721, tmp5, nil); arg_659 = lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(b__8); if linked_656 == nil { tmp4 = ifn_657.Invoke_O_O__O(arg_658, arg_659) } else { tmp4 = linked_656.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_655, arg_658, arg_659) }; return /*line :139:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) }

func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A_New() *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A) Ctor() {}
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A) Invoke_O_O__O(self, s__849000139__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__652 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A_New_O_O(self, s__849000139__1); var tmp2 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__652); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A_fn_class = fncls__651d; tmp2 = fncls__651d } else { tmp2 = fncls__651 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__652, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :141:1
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A) Ctor_O_O(c__iter__849000138, c__s__849000139 any) { t.F_iter__849000138 = c__iter__849000138; t.F_s__849000139 = c__s__849000139 }
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A) Invoke_O__O(self any) any { { var s__849000139__1 any; var t_ any = t.F_s__849000139; t.F_s__849000139 = nil; s__849000139__1 = t_; for { var temp__1927000414__auto____2 any; var root_593 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = s__849000139__1; if linked_594 == nil { temp__1927000414__auto____2 = ifn_595.Invoke_O__O(arg_596) } else { temp__1927000414__auto____2 = linked_594.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_593, arg_596) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000139__3 any = temp__1927000414__auto____2; var tmp1 any; var root_597 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = s__849000139__3; if linked_598 == nil { tmp1 = ifn_599.Invoke_O__O(arg_600) } else { tmp1 = linked_598.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_597, arg_600) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_601 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = s__849000139__3; if linked_602 == nil { c__1927001037__auto____4 = ifn_603.Invoke_O__O(arg_604) } else { c__1927001037__auto____4 = linked_602.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_601, arg_604) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000141__6 any; var root_605 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_606 == nil { b__849000141__6 = ifn_607.Invoke_O__O(arg_608) } else { b__849000141__6 = linked_606.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_605, arg_608) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__615 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A_New_O_I_O(b__849000141__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__615); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A_fn_class = fncls__614d; tmp3 = fncls__614d } else { tmp3 = fncls__614 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__615, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_616 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_621 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = b__849000141__6; if linked_622 == nil { arg_619 = ifn_623.Invoke_O__O(arg_624) } else { arg_619 = linked_622.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_621, arg_624) }; var arg_620 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000138); var tmp5 any; var root_625 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = s__849000139__3; if linked_626 == nil { tmp5 = ifn_627.Invoke_O__O(arg_628) } else { tmp5 = linked_626.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_625, arg_628) }; arg_620 = tmp4.Invoke_O__O(tmp5); if linked_617 == nil { return ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { return linked_617.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) } } else { var root_629 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var root_634 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = b__849000141__6; if linked_635 == nil { arg_632 = ifn_636.Invoke_O__O(arg_637) } else { arg_632 = linked_635.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_634, arg_637) }; var arg_633 any; if linked_630 == nil { return ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { return linked_630.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) } } } else { var p__4 any; var root_638 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__849000139__3; if linked_639 == nil { p__4 = ifn_640.Invoke_O__O(arg_641) } else { p__4 = linked_639.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_638, arg_641) }; var root_642 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = lang.Tuple_Create_O_O__IPersistentVector(p__4, A_arbace_j2g_meta_A_const_65); var arg_646 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000138); var tmp7 any; var root_647 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__849000139__3; if linked_648 == nil { tmp7 = ifn_649.Invoke_O__O(arg_650) } else { tmp7 = linked_648.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_647, arg_650) }; arg_646 = tmp6.Invoke_O__O(tmp7); if linked_643 == nil { return ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { return linked_643.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :141:1
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A) Ctor_O_I_O(c__b__849000141 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000141 = c__b__849000141; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :141:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A) Invoke_O__O(self any) any { { var i__849000140__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000140__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000140__1)); var root_609 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = t.F_b__849000141; var arg_613 any = lang.Tuple_Create_O_O__IPersistentVector(p__2, A_arbace_j2g_meta_A_const_65); if linked_610 == nil { ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { linked_610.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }; i__849000140__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000140__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A_New_O(p0 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A) Ctor_O(c__path any) { t.F_path = c__path }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A) Invoke_O_O__O(self, s__849000149__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__719 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A_New_O_O_O(t.F_path, self, s__849000149__1); var tmp2 *jrt.Class; var fncls__718 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A_fn_class; if fncls__718 == nil { var fncls__718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__719); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A_fn_class = fncls__718d; tmp2 = fncls__718d } else { tmp2 = fncls__718 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__719, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :142:1
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A) Ctor_O_O_O(c__path, c__iter__849000148, c__s__849000149 any) { t.F_path = c__path; t.F_iter__849000148 = c__iter__849000148; t.F_s__849000149 = c__s__849000149 }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A) Invoke_O__O(self any) any { { var s__849000149__1 any; var t_ any = t.F_s__849000149; t.F_s__849000149 = nil; s__849000149__1 = t_; for { var temp__1927000414__auto____2 any; var root_660 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = s__849000149__1; if linked_661 == nil { temp__1927000414__auto____2 = ifn_662.Invoke_O__O(arg_663) } else { temp__1927000414__auto____2 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000149__3 any = temp__1927000414__auto____2; var tmp1 any; var root_664 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = s__849000149__3; if linked_665 == nil { tmp1 = ifn_666.Invoke_O__O(arg_667) } else { tmp1 = linked_665.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_664, arg_667) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_668 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = s__849000149__3; if linked_669 == nil { c__1927001037__auto____4 = ifn_670.Invoke_O__O(arg_671) } else { c__1927001037__auto____4 = linked_669.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_668, arg_671) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000151__6 any; var root_672 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_673 == nil { b__849000151__6 = ifn_674.Invoke_O__O(arg_675) } else { b__849000151__6 = linked_673.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_672, arg_675) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__682 any = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A_New_O_O_I_O(t.F_path, b__849000151__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__681 *jrt.Class = A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A_fn_class; if fncls__681 == nil { var fncls__681d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__682); A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A_fn_class = fncls__681d; tmp3 = fncls__681d } else { tmp3 = fncls__681 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__682, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_683 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var root_688 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = b__849000151__6; if linked_689 == nil { arg_686 = ifn_690.Invoke_O__O(arg_691) } else { arg_686 = linked_689.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_688, arg_691) }; var arg_687 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000148); var tmp5 any; var root_692 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = s__849000149__3; if linked_693 == nil { tmp5 = ifn_694.Invoke_O__O(arg_695) } else { tmp5 = linked_693.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_692, arg_695) }; arg_687 = tmp4.Invoke_O__O(tmp5); if linked_684 == nil { return ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { return linked_684.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) } } else { var root_696 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_701 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = b__849000151__6; if linked_702 == nil { arg_699 = ifn_703.Invoke_O__O(arg_704) } else { arg_699 = linked_702.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_701, arg_704) }; var arg_700 any; if linked_697 == nil { return ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { return linked_697.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) } } } else { var l__4 any; var root_705 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = s__849000149__3; if linked_706 == nil { l__4 = ifn_707.Invoke_O__O(arg_708) } else { l__4 = linked_706.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_705, arg_708) }; var root_709 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_path, l__4); var arg_713 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000148); var tmp7 any; var root_714 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = s__849000149__3; if linked_715 == nil { tmp7 = ifn_716.Invoke_O__O(arg_717) } else { tmp7 = linked_715.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_714, arg_717) }; arg_713 = tmp6.Invoke_O__O(tmp7); if linked_710 == nil { return ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { return linked_710.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :142:1
func A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A) Ctor_O_O_I_O(c__path, c__b__849000151 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_path = c__path; t.F_b__849000151 = c__b__849000151; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :142:1
func (t *A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A) Invoke_O__O(self any) any { { var i__849000150__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000150__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000150__1)); var root_676 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = t.F_b__849000151; var arg_680 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_path, l__2); if linked_677 == nil { ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { linked_677.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; i__849000150__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000150__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_meta_services_iter__849000160__849000164_A_New() *A_arbace_j2g_meta_services_iter__849000160__849000164_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_iter__849000160__849000164_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_A) Invoke_O_O__O(self, s__849000161__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__858 any = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A_New_O_O(self, s__849000161__1); var tmp2 *jrt.Class; var fncls__857 *jrt.Class = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A_fn_class; if fncls__857 == nil { var fncls__857d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__858); A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A_fn_class = fncls__857d; tmp2 = fncls__857d } else { tmp2 = fncls__857 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__858, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :145:1
func A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A{}; t.Ctor_O_O(p0, p1); return t }
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A) Ctor_O_O(c__iter__849000160, c__s__849000161 any) { t.F_iter__849000160 = c__iter__849000160; t.F_s__849000161 = c__s__849000161 }
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A) Invoke_O__O(self any) any { { var s__849000161__1 any; var t_ any = t.F_s__849000161; t.F_s__849000161 = nil; s__849000161__1 = t_; for { var temp__1927000414__auto____2 any; var root_739 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = s__849000161__1; if linked_740 == nil { temp__1927000414__auto____2 = ifn_741.Invoke_O__O(arg_742) } else { temp__1927000414__auto____2 = linked_740.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_739, arg_742) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000161__3 any = temp__1927000414__auto____2; var tmp1 any; var root_743 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = s__849000161__3; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_747 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = s__849000161__3; if linked_748 == nil { c__1927001037__auto____4 = ifn_749.Invoke_O__O(arg_750) } else { c__1927001037__auto____4 = linked_748.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_747, arg_750) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000163__6 any; var root_751 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_752 == nil { b__849000163__6 = ifn_753.Invoke_O__O(arg_754) } else { b__849000163__6 = linked_752.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_751, arg_754) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__791 any = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A_New_O_I_O(b__849000163__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__790 *jrt.Class = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A_fn_class; if fncls__790 == nil { var fncls__790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, fnbody__791); A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A_fn_class = fncls__790d; tmp3 = fncls__790d } else { tmp3 = fncls__790 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__791, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_792 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any; var root_797 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = b__849000163__6; if linked_798 == nil { arg_795 = ifn_799.Invoke_O__O(arg_800) } else { arg_795 = linked_798.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_797, arg_800) }; var arg_796 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000160); var tmp5 any; var root_801 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = s__849000161__3; if linked_802 == nil { tmp5 = ifn_803.Invoke_O__O(arg_804) } else { tmp5 = linked_802.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_801, arg_804) }; arg_796 = tmp4.Invoke_O__O(tmp5); if linked_793 == nil { return ifn_794.Invoke_O_O__O(arg_795, arg_796) } else { return linked_793.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_792, arg_795, arg_796) } } else { var root_805 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any; var root_810 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = b__849000163__6; if linked_811 == nil { arg_808 = ifn_812.Invoke_O__O(arg_813) } else { arg_808 = linked_811.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_810, arg_813) }; var arg_809 any; if linked_806 == nil { return ifn_807.Invoke_O_O__O(arg_808, arg_809) } else { return linked_806.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_805, arg_808, arg_809) } } } else { var vec__849000177__4 any; var root_814 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = s__849000161__3; if linked_815 == nil { vec__849000177__4 = ifn_816.Invoke_O__O(arg_817) } else { vec__849000177__4 = linked_815.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_814, arg_817) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000177__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000177__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_818 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var tmp6 any; var root_823 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_825 lang.IFn
														if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var root_827 any = A_arbace_j2g_meta_A_const_67.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any; var root_831 any = A_arbace_j2g_meta_A_const_60.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var fnbody__849 any = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A_New(); var tmp7 *jrt.Class; var fncls__848 *jrt.Class = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A_fn_class; if fncls__848 == nil { var fncls__848d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A_fn_class = fncls__848d; tmp7 = fncls__848d } else { tmp7 = fncls__848 }; arg_834 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__849, tmp7, nil); var arg_835 any; var root_850 any = A_arbace_j2g_meta_A_const_70.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_852 lang.IFn
														if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; if linked_851 == nil { arg_835 = ifn_852.Invoke__O() } else { arg_835 = linked_851.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_850) }
//line :146:1
	var arg_836 any = ps__6; if linked_832 == nil { arg_830 = ifn_833.Invoke_O_O_O__O(arg_834, arg_835, arg_836) } else { arg_830 = linked_832.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_831, arg_834, arg_835, arg_836) }; if linked_828 == nil { arg_826 = ifn_829.Invoke_O__O(arg_830) } else { arg_826 = linked_828.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_827, arg_830) }; if linked_824 == nil { tmp6 = ifn_825.Invoke_O__O(arg_826) } else { tmp6 = linked_824.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_823, arg_826) }
//line :145:1
	arg_821 = lang.Tuple_Create_O_O__IPersistentVector(s__5, tmp6); var arg_822 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000160); var tmp9 any; var root_853 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = s__849000161__3; if linked_854 == nil { tmp9 = ifn_855.Invoke_O__O(arg_856) } else { tmp9 = linked_854.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_853, arg_856) }; arg_822 = tmp8.Invoke_O__O(tmp9); if linked_819 == nil { return ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { return linked_819.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :145:1
func A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A) Ctor_O_I_O(c__b__849000163 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000163 = c__b__849000163; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :145:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A) Invoke_O__O(self any) any { { var i__849000162__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000162__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000167__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000162__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000167__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000167__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_755 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = t.F_b__849000163; var arg_759 any; var tmp2 any; var root_760 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_762 lang.IFn
															if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var root_764 any = A_arbace_j2g_meta_A_const_67.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var root_768 any = A_arbace_j2g_meta_A_const_60.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any; var fnbody__786 any = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A_New(); var tmp3 *jrt.Class; var fncls__785 *jrt.Class = A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A_fn_class; if fncls__785 == nil { var fncls__785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A_fn_class = fncls__785d; tmp3 = fncls__785d } else { tmp3 = fncls__785 }; arg_771 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__786, tmp3, nil); var arg_772 any; var root_787 any = A_arbace_j2g_meta_A_const_70.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_789 lang.IFn
															if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; if linked_788 == nil { arg_772 = ifn_789.Invoke__O() } else { arg_772 = linked_788.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_787) }
//line :146:1
	var arg_773 any = ps__4; if linked_769 == nil { arg_767 = ifn_770.Invoke_O_O_O__O(arg_771, arg_772, arg_773) } else { arg_767 = linked_769.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_768, arg_771, arg_772, arg_773) }; if linked_765 == nil { arg_763 = ifn_766.Invoke_O__O(arg_767) } else { arg_763 = linked_765.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_764, arg_767) }; if linked_761 == nil { tmp2 = ifn_762.Invoke_O__O(arg_763) } else { tmp2 = linked_761.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_760, arg_763) }
//line :145:1
	arg_759 = lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp2); if linked_756 == nil { ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { linked_756.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) }; i__849000162__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000162__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A_New() *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A) Invoke_O_O_O__O(self, m__1, p__849000170__2 any) any { var vec__849000172__3 any = p__849000170__2; var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000172__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000172__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_774 any = A_arbace_j2g_meta_A_const_68.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = m__1; var arg_778 any = p__4; if linked_775 == nil { tmp1 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { tmp1 = linked_775.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; if jrt.J2g_Truth(tmp1) { return m__1 } else { var root_779 any = A_arbace_j2g_meta_A_const_69.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = m__1; var arg_783 any = p__4; var arg_784 any = lang.Tuple_Create_O_O__IPersistentVector(p__4, k__5); if linked_780 == nil { return ifn_781.Invoke_O_O_O__O(arg_782, arg_783, arg_784) } else { return linked_780.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_779, arg_782, arg_783, arg_784) } } }
//line :146:1
func A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A_New() *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A) Invoke_O_O_O__O(self, m__1, p__849000180__2 any) any { var vec__849000182__3 any = p__849000180__2; var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000182__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000182__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_837 any = A_arbace_j2g_meta_A_const_68.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = m__1; var arg_841 any = p__4; if linked_838 == nil { tmp1 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { tmp1 = linked_838.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; if jrt.J2g_Truth(tmp1) { return m__1 } else { var root_842 any = A_arbace_j2g_meta_A_const_69.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = m__1; var arg_846 any = p__4; var arg_847 any = lang.Tuple_Create_O_O__IPersistentVector(p__4, k__5); if linked_843 == nil { return ifn_844.Invoke_O_O_O__O(arg_845, arg_846, arg_847) } else { return linked_843.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_842, arg_845, arg_846, arg_847) } } }



func A_arbace_j2g_meta_distinct_by_first_A_New() *A_arbace_j2g_meta_distinct_by_first_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_distinct_by_first_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_meta_distinct_by_first_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_meta_distinct_by_first_A) Invoke_O_O__O(self, ps__0 any) any { { var G__849000192__2_ any = ps__0; var vec__849000193__3 any = G__849000192__2_; var seq__849000194__4 any; var root_861 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn
											if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = vec__849000193__3; if linked_862 == nil { seq__849000194__4 = ifn_863.Invoke_O__O(arg_864) } else { seq__849000194__4 = linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) }
//line :150:1
	var first__849000195__5 any; var root_865 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_867 lang.IFn
	if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = seq__849000194__4; if linked_866 == nil { first__849000195__5 = ifn_867.Invoke_O__O(arg_868) } else { first__849000195__5 = linked_866.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_865, arg_868) }
//line :150:1
	var seq__849000194__6 any; var root_869 any = A_arbace_j2g_meta_A_const_43.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_871 lang.IFn
	if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = seq__849000194__4; if linked_870 == nil { seq__849000194__6 = ifn_871.Invoke_O__O(arg_872) } else { seq__849000194__6 = linked_870.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_869, arg_872) }
//line :150:1
	var x__7 any = first__849000195__5; var more__8 any = seq__849000194__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__849000192__11_ any = G__849000192__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = x__7; _ = more__8; L1: for { var vec__849000196__14 any = G__849000192__11_; var seq__849000197__15 any; var root_873 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_875 lang.IFn
		if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = vec__849000196__14; if linked_874 == nil { seq__849000197__15 = ifn_875.Invoke_O__O(arg_876) } else { seq__849000197__15 = linked_874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_873, arg_876) }
//line :150:1
		var first__849000198__16 any; var root_877 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_879 lang.IFn
		if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = seq__849000197__15; if linked_878 == nil { first__849000198__16 = ifn_879.Invoke_O__O(arg_880) } else { first__849000198__16 = linked_878.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_877, arg_880) }
//line :150:1
		var seq__849000197__17 any; var root_881 any = A_arbace_j2g_meta_A_const_43.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_883 lang.IFn
		if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = seq__849000197__15; if linked_882 == nil { seq__849000197__17 = ifn_883.Invoke_O__O(arg_884) } else { seq__849000197__17 = linked_882.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_881, arg_884) }
//line :150:1
		var x__18 any = first__849000198__16
		var more__19 any = seq__849000197__17; var seen__20 any = seen__12; var out__21 any = out__13
		if lang.Util_Identical_O_O__Z_NoInit(x__18, nil) { return out__21 } else { var tmp1 lang.IFn = lang.IFn_Cast(seen__20); var tmp2 any; var root_885 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_887 lang.IFn
			if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = x__18; if linked_886 == nil { tmp2 = ifn_887.Invoke_O__O(arg_888) } else { tmp2 = linked_886.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_885, arg_888) }
//line :152:1
			if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) {
				G__849000192__11_, seen__12, out__13 = more__19, seen__20, out__21; continue L1 } else {
//line :152:1
					if A_arbace_j2g_meta_A_const_48 != nil {

						var tmp3 any; var root_889 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = seen__20; var arg_893 any; var root_894 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = x__18; if linked_895 == nil { arg_893 = ifn_896.Invoke_O__O(arg_897) } else { arg_893 = linked_895.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_894, arg_897) }; if linked_890 == nil { tmp3 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { tmp3 = linked_890.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; var tmp4 any = tmp3; var tmp5 any; var root_898 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = out__21; var arg_902 any = x__18; if linked_899 == nil { tmp5 = ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { tmp5 = linked_899.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_898, arg_901, arg_902) }; G__849000192__11_, seen__12, out__13 = more__19, tmp4, tmp5; continue L1 } else {
//line :152:1
							return nil } } } } }; /*line :150:1*/panic("j2g: unreachable") }





func A_arbace_j2g_meta_services_text_A_New() *A_arbace_j2g_meta_services_text_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_meta_services_text_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_meta_services_text_A) Invoke_O_O__O(self, svcs__0 any) any {


	var root_903 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any; var iter__1927001039__auto____2 any; var fnbody__1009 any = A_arbace_j2g_meta_services_text_iter__849000200__849000206_A_New(); var tmp1 *jrt.Class; var fncls__1008 *jrt.Class = A_arbace_j2g_meta_services_text_iter__849000200__849000206_A_fn_class; if fncls__1008 == nil { var fncls__1008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_j2g_meta_services_text_iter__849000200__849000206_A_fn_class = fncls__1008d; tmp1 = fncls__1008d } else { tmp1 = fncls__1008 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1009, tmp1, nil); arg_906 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(svcs__0); if linked_904 == nil { return ifn_905.Invoke_O__O(arg_906) } else { return linked_904.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_903, arg_906) } }
//line :159:1
func A_arbace_j2g_meta_services_text_iter__849000200__849000206_A_New() *A_arbace_j2g_meta_services_text_iter__849000200__849000206_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_iter__849000200__849000206_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_A) Invoke_O_O__O(self, s__849000201__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1007 any = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A_New_O_O(self, s__849000201__1); var tmp2 *jrt.Class; var fncls__1006 *jrt.Class = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A_fn_class; if fncls__1006 == nil { var fncls__1006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__1007); A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A_fn_class = fncls__1006d; tmp2 = fncls__1006d } else { tmp2 = fncls__1006 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1007, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :159:1
func A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A) Ctor_O_O(c__iter__849000200, c__s__849000201 any) { t.F_iter__849000200 = c__iter__849000200; t.F_s__849000201 = c__s__849000201 }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A) Invoke_O__O(self any) any { { var s__849000201__1 any; var t_ any = t.F_s__849000201; t.F_s__849000201 = nil; s__849000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_907 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = s__849000201__1; if linked_908 == nil { temp__1927000414__auto____2 = ifn_909.Invoke_O__O(arg_910) } else { temp__1927000414__auto____2 = linked_908.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_907, arg_910) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__849000208__4 any; var root_911 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = xs__1927001018__auto____3; if linked_912 == nil { vec__849000208__4 = ifn_913.Invoke_O__O(arg_914) } else { vec__849000208__4 = linked_912.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_911, arg_914) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000208__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000208__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__984 any = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A_New_O(s__5); var tmp1 *jrt.Class; var fncls__983 *jrt.Class = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A_fn_class; if fncls__983 == nil { var fncls__983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__984); A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A_fn_class = fncls__983d; tmp1 = fncls__983d } else { tmp1 = fncls__983 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__984, tmp1, nil); var fs__1927001036__auto____8 any; var root_985 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; var root_989 any = A_arbace_j2g_meta_A_const_73.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_j2g_meta_distinct_by_first_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = ps__6; if linked_990 == nil { tmp3 = ifn_991.Invoke_O__O(arg_992) } else { tmp3 = linked_990.(*A_arbace_j2g_meta_distinct_by_first_A).Invoke_O_O__O(root_989, arg_992) }; arg_988 = tmp2.Invoke_O__O(tmp3); if linked_986 == nil { fs__1927001036__auto____8 = ifn_987.Invoke_O__O(arg_988) } else { fs__1927001036__auto____8 = linked_986.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_985, arg_988) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_993 any = A_arbace_j2g_meta_A_const_74.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = fs__1927001036__auto____8; var arg_997 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000200); var tmp5 any; var root_998 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__849000201__1; if linked_999 == nil { tmp5 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp5 = linked_999.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_998, arg_1001) }; arg_997 = tmp4.Invoke_O__O(tmp5); if linked_994 == nil { return ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { return linked_994.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) } } else { var tmp6 any; var root_1002 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__849000201__1; if linked_1003 == nil { tmp6 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp6 = linked_1003.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1002, arg_1005) }; s__849000201__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A_New_O(p0 any) *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A) Invoke_O_O__O(self, s__849000203__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__982 any = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A_New_O_O_O(self, t.F_s, s__849000203__1); var tmp2 *jrt.Class; var fncls__981 *jrt.Class = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A_fn_class; if fncls__981 == nil { var fncls__981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, fnbody__982); A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A_fn_class = fncls__981d; tmp2 = fncls__981d } else { tmp2 = fncls__981 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__982, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :159:1
func A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A) Ctor_O_O_O(c__iter__849000202, c__s, c__s__849000203 any) { t.F_iter__849000202 = c__iter__849000202; t.F_s = c__s; t.F_s__849000203 = c__s__849000203 }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A) Invoke_O__O(self any) any { { var s__849000203__1 any; var t_ any = t.F_s__849000203; t.F_s__849000203 = nil; s__849000203__1 = t_; for { var temp__1927000414__auto____2 any; var root_915 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__849000203__1; if linked_916 == nil { temp__1927000414__auto____2 = ifn_917.Invoke_O__O(arg_918) } else { temp__1927000414__auto____2 = linked_916.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_915, arg_918) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000203__3 any = temp__1927000414__auto____2; var tmp1 any; var root_919 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__849000203__3; if linked_920 == nil { tmp1 = ifn_921.Invoke_O__O(arg_922) } else { tmp1 = linked_920.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_919, arg_922) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_923 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = s__849000203__3; if linked_924 == nil { c__1927001037__auto____4 = ifn_925.Invoke_O__O(arg_926) } else { c__1927001037__auto____4 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_923, arg_926) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000205__6 any; var root_927 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_928 == nil { b__849000205__6 = ifn_929.Invoke_O__O(arg_930) } else { b__849000205__6 = linked_928.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_927, arg_930) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__941 any = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A_New_O_I_O_O(t.F_s, size__1927001038__auto____5, b__849000205__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__940 *jrt.Class = A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A_fn_class; if fncls__940 == nil { var fncls__940d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__941); A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A_fn_class = fncls__940d; tmp3 = fncls__940d } else { tmp3 = fncls__940 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__941, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_942 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any; var root_947 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = b__849000205__6; if linked_948 == nil { arg_945 = ifn_949.Invoke_O__O(arg_950) } else { arg_945 = linked_948.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_947, arg_950) }; var arg_946 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000202); var tmp5 any; var root_951 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = s__849000203__3; if linked_952 == nil { tmp5 = ifn_953.Invoke_O__O(arg_954) } else { tmp5 = linked_952.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_951, arg_954) }; arg_946 = tmp4.Invoke_O__O(tmp5); if linked_943 == nil { return ifn_944.Invoke_O_O__O(arg_945, arg_946) } else { return linked_943.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_942, arg_945, arg_946) } } else { var root_955 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any; var root_960 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = b__849000205__6; if linked_961 == nil { arg_958 = ifn_962.Invoke_O__O(arg_963) } else { arg_958 = linked_961.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_960, arg_963) }; var arg_959 any; if linked_956 == nil { return ifn_957.Invoke_O_O__O(arg_958, arg_959) } else { return linked_956.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_955, arg_958, arg_959) } } } else { var vec__849000218__4 any; var root_964 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = s__849000203__3; if linked_965 == nil { vec__849000218__4 = ifn_966.Invoke_O__O(arg_967) } else { vec__849000218__4 = linked_965.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_964, arg_967) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000218__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000218__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_968 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_13, nil, Lit_14); var tmp7 any; var root_973 any = A_arbace_j2g_meta_A_const_72.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_975 lang.IFn
																			if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = k__6; if linked_974 == nil { tmp7 = ifn_975.Invoke_O__O(arg_976) } else { tmp7 = linked_974.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_973, arg_976) }; arg_971 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, t.F_s, nil, p__5, nil)).Ref()
//line :159:1
	var arg_972 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000202); var tmp9 any; var root_977 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = s__849000203__3; if linked_978 == nil { tmp9 = ifn_979.Invoke_O__O(arg_980) } else { tmp9 = linked_978.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_977, arg_980) }; arg_972 = tmp8.Invoke_O__O(tmp9); if linked_969 == nil { return ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { return linked_969.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A) Ctor_O_I_O_O(c__s any, c__size__1927001038__auto__ int32, c__b__849000205, c__c__1927001037__auto__ any) { t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__849000205 = c__b__849000205; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A) Invoke_O__O(self any) any { { var i__849000204__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000214__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000204__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000214__2, lang.RT_IntCast_J__I_NoInit(0), nil); var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000214__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_931 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = t.F_b__849000205; var arg_935 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_13, nil, Lit_14); var tmp3 any; var root_936 any = A_arbace_j2g_meta_A_const_72.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_938 lang.IFn
																					if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = k__4; if linked_937 == nil { tmp3 = ifn_938.Invoke_O__O(arg_939) } else { tmp3 = linked_937.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_936, arg_939) }; arg_935 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_s, nil, p__3, nil)).Ref()
//line :159:1
	if linked_932 == nil { ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { linked_932.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }; i__849000204__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000204__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_meta_internal_A_New() *A_arbace_j2g_meta_internal_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_internal_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_j2g_meta_internal_A) Ctor() {}
//line :162:1
func (t *A_arbace_j2g_meta_internal_A) Invoke_O_O__O(self, s__0 any) any { var root_1010 any = A_arbace_j2g_meta_A_const_75.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = s__0; var arg_1014 any = Lit_9; var arg_1015 any = Lit_8; if linked_1011 == nil { return ifn_1012.Invoke_O_O_O__O(arg_1013, arg_1014, arg_1015) } else { return linked_1011.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1010, arg_1013, arg_1014, arg_1015) } }

func A_arbace_j2g_meta_service_roots_A_New() *A_arbace_j2g_meta_service_roots_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_meta_service_roots_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_meta_service_roots_A) Invoke_O_O__O(self, svcs__0 any) any {



	var root_1016 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any; var iter__1927001039__auto____2 any; var fnbody__1111 any = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A_New(); var tmp1 *jrt.Class; var fncls__1110 *jrt.Class = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A_fn_class; if fncls__1110 == nil { var fncls__1110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A_fn_class = fncls__1110d; tmp1 = fncls__1110d } else { tmp1 = fncls__1110 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1111, tmp1, nil); arg_1019 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(svcs__0); if linked_1017 == nil { return ifn_1018.Invoke_O__O(arg_1019) } else { return linked_1017.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1016, arg_1019) } }
//line :168:1
func A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A_New() *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A) Ctor() {}
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A) Invoke_O_O__O(self, s__849000228__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1109 any = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A_New_O_O(self, s__849000228__1); var tmp2 *jrt.Class; var fncls__1108 *jrt.Class = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A_fn_class; if fncls__1108 == nil { var fncls__1108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, fnbody__1109); A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A_fn_class = fncls__1108d; tmp2 = fncls__1108d } else { tmp2 = fncls__1108 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1109, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :168:1
func A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A{}; t.Ctor_O_O(p0, p1); return t }
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A) Ctor_O_O(c__iter__849000227, c__s__849000228 any) { t.F_iter__849000227 = c__iter__849000227; t.F_s__849000228 = c__s__849000228 }
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A) Invoke_O__O(self any) any { { var s__849000228__1 any; var t_ any = t.F_s__849000228; t.F_s__849000228 = nil; s__849000228__1 = t_; for { var temp__1927000414__auto____2 any; var root_1020 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = s__849000228__1; if linked_1021 == nil { temp__1927000414__auto____2 = ifn_1022.Invoke_O__O(arg_1023) } else { temp__1927000414__auto____2 = linked_1021.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1020, arg_1023) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000228__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1024 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = s__849000228__3; if linked_1025 == nil { tmp1 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp1 = linked_1025.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1024, arg_1027) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1028 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = s__849000228__3; if linked_1029 == nil { c__1927001037__auto____4 = ifn_1030.Invoke_O__O(arg_1031) } else { c__1927001037__auto____4 = linked_1029.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1028, arg_1031) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000230__6 any; var root_1032 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1033 == nil { b__849000230__6 = ifn_1034.Invoke_O__O(arg_1035) } else { b__849000230__6 = linked_1033.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1032, arg_1035) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1057 any = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A_New_O_I_O(b__849000230__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__1057); A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A_fn_class = fncls__1056d; tmp3 = fncls__1056d } else { tmp3 = fncls__1056 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1057, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1058 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var root_1063 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = b__849000230__6; if linked_1064 == nil { arg_1061 = ifn_1065.Invoke_O__O(arg_1066) } else { arg_1061 = linked_1064.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1063, arg_1066) }; var arg_1062 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000227); var tmp5 any; var root_1067 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = s__849000228__3; if linked_1068 == nil { tmp5 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp5 = linked_1068.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1067, arg_1070) }; arg_1062 = tmp4.Invoke_O__O(tmp5); if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } } else { var root_1071 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any; var root_1076 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = b__849000230__6; if linked_1077 == nil { arg_1074 = ifn_1078.Invoke_O__O(arg_1079) } else { arg_1074 = linked_1077.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1076, arg_1079) }; var arg_1075 any; if linked_1072 == nil { return ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { return linked_1072.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) } } } else { var vec__849000244__4 any; var root_1080 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = s__849000228__3; if linked_1081 == nil { vec__849000244__4 = ifn_1082.Invoke_O__O(arg_1083) } else { vec__849000244__4 = linked_1081.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1080, arg_1083) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000244__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000244__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1084 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any; var tmp6 any; var root_1089 any = A_arbace_j2g_meta_A_const_76.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_j2g_meta_internal_A_fn_class); var ifn_1091 lang.IFn
														if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__5; if linked_1090 == nil { tmp6 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp6 = linked_1090.(*A_arbace_j2g_meta_internal_A).Invoke_O_O__O(root_1089, arg_1092) }
//line :168:1
	var tmp7 any = tmp6; var tmp8 any; var root_1093 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1095 lang.IFn
	if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_meta_A_const_77.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__1103 any = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A_New(); var tmp11 *jrt.Class; var fncls__1102 *jrt.Class = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A_fn_class; if fncls__1102 == nil { var fncls__1102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A_fn_class = fncls__1102d; tmp11 = fncls__1102d } else { tmp11 = fncls__1102 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1103, tmp11, nil); arg_1096 = tmp9.Invoke_O_O__O(tmp10.Ref(), ps__6); if linked_1094 == nil { tmp8 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp8 = linked_1094.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1093, arg_1096) }
//line :168:1
	arg_1087 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8); var arg_1088 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__849000227); var tmp13 any; var root_1104 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = s__849000228__3; if linked_1105 == nil { tmp13 = ifn_1106.Invoke_O__O(arg_1107) } else { tmp13 = linked_1105.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1104, arg_1107) }; arg_1088 = tmp12.Invoke_O__O(tmp13); if linked_1085 == nil { return ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { return linked_1085.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :168:1
func A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A) Ctor_O_I_O(c__b__849000230 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__849000230 = c__b__849000230; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :168:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A) Invoke_O__O(self any) any { { var i__849000229__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000229__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000234__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000229__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1036 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = t.F_b__849000230; var arg_1040 any; var tmp2 any; var root_1041 any = A_arbace_j2g_meta_A_const_76.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_j2g_meta_internal_A_fn_class); var ifn_1043 lang.IFn
																if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = s__3; if linked_1042 == nil { tmp2 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp2 = linked_1042.(*A_arbace_j2g_meta_internal_A).Invoke_O_O__O(root_1041, arg_1044) }
//line :168:1
	var tmp3 any = tmp2; var tmp4 any; var root_1045 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1047 lang.IFn
	if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_meta_A_const_77.GetRawRoot__O()); var tmp6 *lang.Compiler_AOTFn; var fnbody__1055 any = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A_New(); var tmp7 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A_fn_class; if fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A_fn_class = fncls__1054d; tmp7 = fncls__1054d } else { tmp7 = fncls__1054 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1055, tmp7, nil); arg_1048 = tmp5.Invoke_O_O__O(tmp6.Ref(), ps__4); if linked_1046 == nil { tmp4 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp4 = linked_1046.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1045, arg_1048) }
//line :168:1
	arg_1040 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4); if linked_1037 == nil { ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { linked_1037.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) }; i__849000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000229__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A_New() *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A) Invoke_O_O__O(self, p__849000237__1 any) any { var vec__849000239__2 any = p__849000237__1; var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000239__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000239__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, p__3, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114), jrt.RefArrayOf(jrt.Object_class, p__3, nil)).Ref()) }
//line :169:1
func A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A_New() *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A) Invoke_O_O__O(self, p__849000247__1 any) any { var vec__849000249__2 any = p__849000247__1; var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, p__3, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114), jrt.RefArrayOf(jrt.Object_class, p__3, nil)).Ref()) }

func A_arbace_j2g_meta_roots_index_text_A_New() *A_arbace_j2g_meta_roots_index_text_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_roots_index_text_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_meta_roots_index_text_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_meta_roots_index_text_A) Invoke_O_O_O__O(self, paths__0, names__1 any) any { var ks__3 any; var root_1112 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1114 lang.IFn; if



	linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any; var root_1116 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var root_1120 any = A_arbace_j2g_meta_A_const_78.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any; var fnbody__1135 any = A_arbace_j2g_meta_roots_index_text_fn__849000257_A_New(); var tmp1 *jrt.Class; var fncls__1134 *jrt.Class = A_arbace_j2g_meta_roots_index_text_fn__849000257_A_fn_class; if fncls__1134 == nil { var fncls__1134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_j2g_meta_roots_index_text_fn__849000257_A_fn_class = fncls__1134d; tmp1 = fncls__1134d } else { tmp1 = fncls__1134 }; arg_1123 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1135, tmp1, nil); var arg_1124 any = paths__0; if linked_1121 == nil { arg_1119 = ifn_1122.Invoke_O_O__O(arg_1123, arg_1124) } else { arg_1119 = linked_1121.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1120, arg_1123, arg_1124) }; if linked_1117 == nil { arg_1115 = ifn_1118.Invoke_O__O(arg_1119) } else { arg_1115 = linked_1117.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1116, arg_1119) }; if linked_1113 == nil { ks__3 = ifn_1114.Invoke_O__O(arg_1115) } else { ks__3 = linked_1113.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1112, arg_1115) }; var root_1136 any =
	A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var iter__1927001039__auto____4 any; var fnbody__1201 any = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A_New_O(names__1); var tmp2 *jrt.Class; var fncls__1200 *jrt.Class = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A_fn_class; if fncls__1200 == nil { var fncls__1200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__1201); A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A_fn_class = fncls__1200d; tmp2 = fncls__1200d } else { tmp2 = fncls__1200 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1201, tmp2, nil); arg_1139 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(ks__3); if linked_1137 == nil { return ifn_1138.Invoke_O__O(arg_1139) } else { return linked_1137.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1136, arg_1139) } }
//line :175:1
func A_arbace_j2g_meta_roots_index_text_fn__849000257_A_New() *A_arbace_j2g_meta_roots_index_text_fn__849000257_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_roots_index_text_fn__849000257_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_meta_roots_index_text_fn__849000257_A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_meta_roots_index_text_fn__849000257_A) Invoke_O_O__O(self, p1__849000256_SHARP___1 any) any { var vec__849000258__2 any; var root_1125 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = p1__849000256_SHARP___1; if linked_1126 == nil { vec__849000258__2 = ifn_1127.Invoke_O__O(arg_1128) } else { vec__849000258__2 = linked_1126.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_1125, arg_1128) }; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000258__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000258__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1129 any = k__3; var na_1130 int64 = 0; _ = ___4; if jrt.Long_InstanceOf(na_1129) { var n0_1131 int64 = jrt.NN(jrt.Long_Cast(na_1129)).LongValue__J(); var n1_1132 int64 = na_1130; tmp1 = n0_1131 >= n1_1132 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1129, na_1130) }; if tmp1 { return k__3 } else { return nil } }
func A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A_New_O(p0 any) *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A) Ctor_O(c__names any) { t.F_names = c__names }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A) Invoke_O_O__O(self, s__849000263__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1199 any = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A_New_O_O_O(self, t.F_names, s__849000263__1); var tmp2 *jrt.Class; var fncls__1198 *jrt.Class = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A_fn_class; if fncls__1198 == nil { var fncls__1198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__1199); A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A_fn_class = fncls__1198d; tmp2 = fncls__1198d } else { tmp2 = fncls__1198 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1199, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :176:1
func A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A) Ctor_O_O_O(c__iter__849000262, c__names, c__s__849000263 any) { t.F_iter__849000262 = c__iter__849000262; t.F_names = c__names; t.F_s__849000263 = c__s__849000263 }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A) Invoke_O__O(self any) any { { var s__849000263__1 any; var t_ any = t.F_s__849000263; t.F_s__849000263 = nil; s__849000263__1 = t_; for { var temp__1927000414__auto____2 any; var root_1140 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = s__849000263__1; if linked_1141 == nil { temp__1927000414__auto____2 = ifn_1142.Invoke_O__O(arg_1143) } else { temp__1927000414__auto____2 = linked_1141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1140, arg_1143) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000263__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1144 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = s__849000263__3; if linked_1145 == nil { tmp1 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp1 = linked_1145.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1144, arg_1147) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1148 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = s__849000263__3; if linked_1149 == nil { c__1927001037__auto____4 = ifn_1150.Invoke_O__O(arg_1151) } else { c__1927001037__auto____4 = linked_1149.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1148, arg_1151) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000265__6 any; var root_1152 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1153 == nil { b__849000265__6 = ifn_1154.Invoke_O__O(arg_1155) } else { b__849000265__6 = linked_1153.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1152, arg_1155) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1162 any = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A_New_O_O_I_O(t.F_names, b__849000265__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1161 *jrt.Class = A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A_fn_class; if fncls__1161 == nil { var fncls__1161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__1162); A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A_fn_class = fncls__1161d; tmp3 = fncls__1161d } else { tmp3 = fncls__1161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1162, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1163 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1168 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = b__849000265__6; if linked_1169 == nil { arg_1166 = ifn_1170.Invoke_O__O(arg_1171) } else { arg_1166 = linked_1169.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1168, arg_1171) }; var arg_1167 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000262); var tmp5 any; var root_1172 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = s__849000263__3; if linked_1173 == nil { tmp5 = ifn_1174.Invoke_O__O(arg_1175) } else { tmp5 = linked_1173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1172, arg_1175) }; arg_1167 = tmp4.Invoke_O__O(tmp5); if linked_1164 == nil { return ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) } } else { var root_1176 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var root_1181 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = b__849000265__6; if linked_1182 == nil { arg_1179 = ifn_1183.Invoke_O__O(arg_1184) } else { arg_1179 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1181, arg_1184) }; var arg_1180 any; if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } } else { var k__4 any; var root_1185 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = s__849000263__3; if linked_1186 == nil { k__4 = ifn_1187.Invoke_O__O(arg_1188) } else { k__4 = linked_1186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1185, arg_1188) }; var root_1189 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var tmp6 any = t.F_names; var arg_1192 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__4, nil, lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(k__4)), nil)).Ref(); var arg_1193 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__849000262); var tmp8 any; var root_1194 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = s__849000263__3; if linked_1195 == nil { tmp8 = ifn_1196.Invoke_O__O(arg_1197) } else { tmp8 = linked_1195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1194, arg_1197) }; arg_1193 = tmp7.Invoke_O__O(tmp8); if linked_1190 == nil { return ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { return linked_1190.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A) Ctor_O_O_I_O(c__names, c__b__849000265 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_names = c__names; t.F_b__849000265 = c__b__849000265; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A) Invoke_O__O(self any) any { { var i__849000264__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000264__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000264__1)); var root_1156 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = t.F_b__849000265; var tmp2 any = t.F_names; var arg_1160 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil, Lit_14), jrt.RefArrayOf(jrt.Object_class, k__2, nil, lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__2)), nil)).Ref(); if linked_1157 == nil { ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { linked_1157.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }; i__849000264__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000264__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_meta_json_fail_A_New() *A_arbace_j2g_meta_json_fail_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_json_fail_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_meta_json_fail_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_meta_json_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, what__2 any) any { var tmp1 any; var root_1202 any = A_arbace_j2g_meta_A_const_79.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1204 lang.IFn; if
												linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, what__2, nil, i__1)).Ref(); var arg_1206 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_80, i__1)); if linked_1203 == nil { tmp1 = ifn_1204.Invoke_O_O__O(arg_1205, arg_1206) } else { tmp1 = linked_1203.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1202, arg_1205, arg_1206) }; /*line :182:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_j2g_meta_read_json_A_New() *A_arbace_j2g_meta_read_json_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_json_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_j2g_meta_read_json_A) Ctor() {}
//line :185:1
func (t *A_arbace_j2g_meta_read_json_A) Invoke_O_O__O(self, s__0 any) any { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var ws__3 any; var fnbody__1215 any = A_arbace_j2g_meta_read_json_ws__849000277_A_New_I_O(n__2, s__0); var tmp1 *jrt.Class; var fncls__1214 *jrt.Class = A_arbace_j2g_meta_read_json_ws__849000277_A_fn_class; if



	fncls__1214 == nil { var fncls__1214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1215); A_arbace_j2g_meta_read_json_ws__849000277_A_fn_class = fncls__1214d; tmp1 = fncls__1214d } else { tmp1 = fncls__1214 }; ws__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1215, tmp1, nil); var value__4 any; var fnbody__1442 any = /*line :185:1*/A_arbace_j2g_meta_read_json_value__849000279_A_New_I_O_O(n__2, s__0, ws__3); var tmp2 *jrt.Class; var fncls__1441 *jrt.Class = A_arbace_j2g_meta_read_json_value__849000279_A_fn_class; if




	fncls__1441 == nil { var fncls__1441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1442); A_arbace_j2g_meta_read_json_value__849000279_A_fn_class = fncls__1441d; tmp2 = fncls__1441d } else { tmp2 = fncls__1441 }; value__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1442, tmp2, nil); var vec__849000274__5 any = /*line :185:1*/lang.IFn_Cast(value__4).Invoke_O__O(A_arbace_j2g_meta_A_const_46); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000274__5, lang.RT_IntCast_J__I_NoInit(0), nil); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000274__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 bool; var na_1443 any = lang.IFn_Cast(ws__3).Invoke_O__O(i__7); var na_1444 int64 = int64(n__2); if






















































	jrt.Long_InstanceOf(na_1443) { var n0_1445 int64 = jrt.NN(jrt.Long_Cast(na_1443)).LongValue__J(); var n1_1446 int64 = na_1444; tmp3 = n0_1445 < n1_1446 } else { tmp3 = lang.Numbers_Lt_O_J__Z_NoInit(na_1443, na_1444) }; if tmp3 { var root_1448 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = s__0; var arg_1452 any = i__7; var arg_1453 any = Lit_51; if linked_1449 == nil { ifn_1450.Invoke_O_O_O__O(arg_1451, arg_1452, arg_1453) } else { linked_1449.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1448, arg_1451, arg_1452, arg_1453) } }; return v__6 }
//line :189:1
func A_arbace_j2g_meta_read_json_ws__849000277_A_New_I_O(p0 int32, p1 any) *A_arbace_j2g_meta_read_json_ws__849000277_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_json_ws__849000277_A{}; t.Ctor_I_O(p0, p1); return t }
//line :189:1
func (t *A_arbace_j2g_meta_read_json_ws__849000277_A) Ctor_I_O(c__n int32, c__s any) { t.F_n = c__n; t.F_s = c__s }
//line :189:1
func (t *A_arbace_j2g_meta_read_json_ws__849000277_A) Invoke_O_O__O(self, i__1 any) any { { var i__2 any = i__1; L1: for { var tmp1 bool; var and__1927000168__auto____3 bool; var na_1207 any = i__2; var na_1208 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1207) { var n0_1209 int64 = jrt.NN(jrt.Long_Cast(na_1207)).LongValue__J(); var n1_1210 int64 = na_1208; and__1927000168__auto____3 = n0_1209 < n1_1210 } else { and__1927000168__auto____3 = lang.Numbers_Lt_O_J__Z_NoInit(na_1207, na_1208) }; if and__1927000168__auto____3 { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); tmp1 = jrt.Character_IsWhitespace_C__Z_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__2))) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var tmp3 jrt.Number_I; var na_1212 any = i__2; if jrt.Long_InstanceOf(na_1212) { var n0_1213 int64 = jrt.NN(jrt.Long_Cast(na_1212)).LongValue__J(); if n0_1213 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_1212) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1213 + 1)) } } else { if jrt.Double_InstanceOf(na_1212) { var n0_1213_2 float64 = jrt.NN(jrt.Double_Cast(na_1212)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1213_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_1212) } }; i__2 = tmp3; continue L1 } else { return i__2 } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_read_json_value__849000279_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_meta_read_json_value__849000279_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_json_value__849000279_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_j2g_meta_read_json_value__849000279_A) Ctor_I_O_O(c__n int32, c__s, c__ws any) { t.F_n = c__n; t.F_s = c__s; t.F_ws = c__ws }
//line :190:1
func (t *A_arbace_j2g_meta_read_json_value__849000279_A) Invoke_O_O__O(self, i__1 any) any { { var i__2 any = lang.IFn_Cast(t.F_ws).Invoke_O__O(i__1); var tmp1 bool; var na_1340 any = i__2; var na_1341 int64 = int64(t.F_n)

	if jrt.Long_InstanceOf(na_1340) { var n0_1342 int64 = jrt.NN(jrt.Long_Cast(na_1340)).LongValue__J(); var n1_1343 int64 = na_1341; tmp1 = n0_1342 >= n1_1343 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1340, na_1341) }; if tmp1 { var root_1345 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = t.F_s; var arg_1349 any = i__2; var arg_1350 any = Lit_52; if linked_1346 == nil { ifn_1347.Invoke_O_O_O__O(arg_1348, arg_1349, arg_1350) } else { linked_1346.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1345, arg_1348, arg_1349, arg_1350) } }
//line :190:1
	var tmp2 *jrt.String = jrt.String_Cast(t.F_s); var c__3 uint16 = jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__2))



	if lang.Util_Equiv_C_C__Z_NoInit(c__3, jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_81)).CharValue__C()) { var i__4 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_ws); var tmp4 jrt.Number_I; var na_1351 any = i__2
		if jrt.Long_InstanceOf(na_1351) { var n0_1352 int64 = jrt.NN(jrt.Long_Cast(na_1351)).LongValue__J(); if n0_1352 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1351) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1352 + 1)) } } else { if jrt.Double_InstanceOf(na_1351) { var n0_1352_2 float64 = jrt.NN(jrt.Double_Cast(na_1351)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1352_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1351) } }; i__4 = tmp3.Invoke_O__O(tmp4)
//line :194:1
		var m__5 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {

			var tmp5 bool; var and__1927000168__auto____6 bool; var na_1216 any = i__4; var na_1217 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1216) { var n0_1218 int64 = jrt.NN(jrt.Long_Cast(na_1216)).LongValue__J(); var n1_1219 int64 = na_1217; and__1927000168__auto____6 = n0_1218 < n1_1219 } else { and__1927000168__auto____6 = lang.Numbers_Lt_O_J__Z_NoInit(na_1216, na_1217) }; if and__1927000168__auto____6 { var tmp6 *jrt.String = jrt.String_Cast(t.F_s); tmp5 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_82)).CharValue__C(), jrt.NN(tmp6).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))) } else { tmp5 = and__1927000168__auto____6 }; if tmp5 { var tmp7 jrt.Number_I; var na_1353 any = i__4
				if jrt.Long_InstanceOf(na_1353) { var n0_1354 int64 = jrt.NN(jrt.Long_Cast(na_1353)).LongValue__J(); if n0_1354 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1353) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1354 + 1)) } } else { if jrt.Double_InstanceOf(na_1353) { var n0_1354_2 float64 = jrt.NN(jrt.Double_Cast(na_1353)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1354_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1353) } }
//line :196:1
				return lang.Tuple_Create_O_O__IPersistentVector(m__5, tmp7) } else { var vec__849000280__6 any = lang.IFn_Cast(self).Invoke_O__O(i__4); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000280__6, lang.RT_IntCast_J__I_NoInit(0), nil); var i__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000280__6, lang.RT_IntCast_J__I_NoInit(1), nil); var ___9 any; var tmp8 any; var root_1221 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1223 lang.IFn; _ = ___9


					if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = k__7; if linked_1222 == nil { tmp8 = ifn_1223.Invoke_O__O(arg_1224) } else { tmp8 = linked_1222.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1221, arg_1224) }; if jrt.J2g_Truth(tmp8) { ___9 = nil } else { var root_1225 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = t.F_s; var arg_1229 any = i__8; var arg_1230 any = Lit_53; if linked_1226 == nil { ___9 = ifn_1227.Invoke_O_O_O__O(arg_1228, arg_1229, arg_1230) } else { ___9 = linked_1226.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230) } }
//line :196:1
					var i__10 any = lang.IFn_Cast(t.F_ws).Invoke_O__O(i__8); var ___11 any; var tmp9 bool; var and__1927000168__auto____11 bool; var na_1231 any = i__10; var na_1232 int64 = int64(t.F_n); _ = ___11




					if jrt.Long_InstanceOf(na_1231) { var n0_1233 int64 = jrt.NN(jrt.Long_Cast(na_1231)).LongValue__J(); var n1_1234 int64 = na_1232; and__1927000168__auto____11 = n0_1233 < n1_1234 } else { and__1927000168__auto____11 = lang.Numbers_Lt_O_J__Z_NoInit(na_1231, na_1232) }; if and__1927000168__auto____11 { var tmp10 *jrt.String = jrt.String_Cast(t.F_s); tmp9 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_85)).CharValue__C(), jrt.NN(tmp10).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__10))) } else { tmp9 = and__1927000168__auto____11 }; if tmp9 { ___11 = nil } else { var root_1236 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = t.F_s; var arg_1240 any = i__10; var arg_1241 any = Lit_54; if linked_1237 == nil { ___11 = ifn_1238.Invoke_O_O_O__O(arg_1239, arg_1240, arg_1241) } else { ___11 = linked_1237.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241) } }
//line :196:1
					var vec__849000283__12 any; var tmp11 lang.IFn = lang.IFn_Cast(self); var tmp12 jrt.Number_I
					var na_1355 any = i__10




					if jrt.Long_InstanceOf(na_1355) { var n0_1356 int64 = jrt.NN(jrt.Long_Cast(na_1355)).LongValue__J(); if n0_1356 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1355) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1356 + 1)) } } else { if jrt.Double_InstanceOf(na_1355) { var n0_1356_2 float64 = jrt.NN(jrt.Double_Cast(na_1355)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1356_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1355) } }; vec__849000283__12 = tmp11.Invoke_O__O(tmp12)
//line :196:1
					var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000283__12, lang.RT_IntCast_J__I_NoInit(0), nil); var i__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000283__12, lang.RT_IntCast_J__I_NoInit(1), nil); var i__15 any = lang.IFn_Cast(t.F_ws).Invoke_O__O(i__14); var m__16 any; var root_1242 any = A_arbace_j2g_meta_A_const_69.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1244 lang.IFn







					if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = m__5; var arg_1246 any = k__7; var arg_1247 any = v__13; if linked_1243 == nil { m__16 = ifn_1244.Invoke_O_O_O__O(arg_1245, arg_1246, arg_1247) } else { m__16 = linked_1243.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1242, arg_1245, arg_1246, arg_1247) }
					var tmp13 bool; var and__1927000168__auto____17 bool; var na_1248 any = i__15; var na_1249 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1248) { var n0_1250 int64 = jrt.NN(jrt.Long_Cast(na_1248)).LongValue__J(); var n1_1251 int64 = na_1249; and__1927000168__auto____17 = n0_1250 < n1_1251 } else { and__1927000168__auto____17 = lang.Numbers_Lt_O_J__Z_NoInit(na_1248, na_1249) }; if and__1927000168__auto____17 { var tmp14 *jrt.String = jrt.String_Cast(t.F_s); tmp13 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_86)).CharValue__C(), jrt.NN(tmp14).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__15))) } else { tmp13 = and__1927000168__auto____17 }; if tmp13 { var tmp15 lang.IFn = lang.IFn_Cast(t.F_ws); var tmp16 jrt.Number_I; var na_1357 any = i__15; if jrt.Long_InstanceOf(na_1357) { var n0_1358 int64 = jrt.NN(jrt.Long_Cast(na_1357)).LongValue__J(); if n0_1358 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1357) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1358 + 1)) } } else { if jrt.Double_InstanceOf(na_1357) { var n0_1358_2 float64 = jrt.NN(jrt.Double_Cast(na_1357)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1358_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1357) } }; i__4, m__5 = tmp15.Invoke_O__O(tmp16), m__16; continue L1 } else { var tmp17 bool; var and__1927000168__auto____17_2 bool; var na_1253 any = i__15; var na_1254 int64 = int64(t.F_n)
						if jrt.Long_InstanceOf(na_1253) { var n0_1255 int64 = jrt.NN(jrt.Long_Cast(na_1253)).LongValue__J(); var n1_1256 int64 = na_1254; and__1927000168__auto____17_2 = n0_1255 < n1_1256 } else { and__1927000168__auto____17_2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1253, na_1254) }; if and__1927000168__auto____17_2 { var tmp18 *jrt.String = jrt.String_Cast(t.F_s); tmp17 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_82)).CharValue__C(), jrt.NN(tmp18).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__15))) } else { tmp17 = and__1927000168__auto____17_2 }
//line :205:1
						if tmp17 { var tmp19 jrt.Number_I; var na_1359 any = i__15
							if jrt.Long_InstanceOf(na_1359) { var n0_1360 int64 = jrt.NN(jrt.Long_Cast(na_1359)).LongValue__J(); if n0_1360 == 9223372036854775807 { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_1359) } else { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1360 + 1)) } } else { if jrt.Double_InstanceOf(na_1359) { var n0_1360_2 float64 = jrt.NN(jrt.Double_Cast(na_1359)).DoubleValue__D(); tmp19 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1360_2 + 1.0)) } else { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_1359) } }
//line :205:1
							return lang.Tuple_Create_O_O__IPersistentVector(m__16, tmp19) } else { if A_arbace_j2g_meta_A_const_48 != nil {

								var root_1258 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = t.F_s; var arg_1262 any = i__15; var arg_1263 any = Lit_55; if linked_1259 == nil { return ifn_1260.Invoke_O_O_O__O(arg_1261, arg_1262, arg_1263) } else { return linked_1259.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1258, arg_1261, arg_1262, arg_1263) } } else {
//line :205:1
									return nil } } } } } } else {
//line :194:1
										if lang.Util_Equiv_C_C__Z_NoInit(c__3, jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_87)).CharValue__C()) { var i__4_2 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_ws); var tmp21 jrt.Number_I
											var na_1361 any = i__2












											if jrt.Long_InstanceOf(na_1361) { var n0_1362 int64 = jrt.NN(jrt.Long_Cast(na_1361)).LongValue__J(); if n0_1362 == 9223372036854775807 { tmp21 = lang.Numbers_Inc_O__Number_NoInit(na_1361) } else { tmp21 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1362 + 1)) } } else { if jrt.Double_InstanceOf(na_1361) { var n0_1362_2 float64 = jrt.NN(jrt.Double_Cast(na_1361)).DoubleValue__D(); tmp21 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1362_2 + 1.0)) } else { tmp21 = lang.Numbers_Inc_O__Number_NoInit(na_1361) } }; i__4_2 = tmp20.Invoke_O__O(tmp21)
//line :194:1
											var v__5 any = lang.PersistentVector_EMPTY.Ref(); L2: for {














												var tmp22 bool; var and__1927000168__auto____6_2 bool; var na_1264 any = i__4_2; var na_1265 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1264) { var n0_1266 int64 = jrt.NN(jrt.Long_Cast(na_1264)).LongValue__J(); var n1_1267 int64 = na_1265; and__1927000168__auto____6_2 = n0_1266 < n1_1267 } else { and__1927000168__auto____6_2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1264, na_1265) }; if and__1927000168__auto____6_2 { var tmp23 *jrt.String = jrt.String_Cast(t.F_s); tmp22 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_88)).CharValue__C(), jrt.NN(tmp23).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4_2))) } else { tmp22 = and__1927000168__auto____6_2 }; if tmp22 { var tmp24 jrt.Number_I; var na_1363 any = i__4_2
													if jrt.Long_InstanceOf(na_1363) { var n0_1364 int64 = jrt.NN(jrt.Long_Cast(na_1363)).LongValue__J(); if n0_1364 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_1363) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1364 + 1)) } } else { if jrt.Double_InstanceOf(na_1363) { var n0_1364_2 float64 = jrt.NN(jrt.Double_Cast(na_1363)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1364_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_1363) } }
//line :209:1
													return lang.Tuple_Create_O_O__IPersistentVector(v__5, tmp24) } else { var vec__849000286__6 any = lang.IFn_Cast(self).Invoke_O__O(i__4_2); var x__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000286__6, lang.RT_IntCast_J__I_NoInit(0), nil); var i__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000286__6, lang.RT_IntCast_J__I_NoInit(1), nil); var i__9 any = lang.IFn_Cast(t.F_ws).Invoke_O__O(i__8_2); var v__10 any; var root_1269 any = A_arbace_j2g_meta_A_const_11.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1271 lang.IFn



														if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = v__5; var arg_1273 any = x__7; if linked_1270 == nil { v__10 = ifn_1271.Invoke_O_O__O(arg_1272, arg_1273) } else { v__10 = linked_1270.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1269, arg_1272, arg_1273) }
														var tmp25 bool; var and__1927000168__auto____11_2 bool; var na_1274 any = i__9; var na_1275 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1274) { var n0_1276 int64 = jrt.NN(jrt.Long_Cast(na_1274)).LongValue__J(); var n1_1277 int64 = na_1275; and__1927000168__auto____11_2 = n0_1276 < n1_1277 } else { and__1927000168__auto____11_2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1274, na_1275) }; if and__1927000168__auto____11_2 { var tmp26 *jrt.String = jrt.String_Cast(t.F_s); tmp25 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_86)).CharValue__C(), jrt.NN(tmp26).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__9))) } else { tmp25 = and__1927000168__auto____11_2 }; if tmp25 { var tmp27 lang.IFn = lang.IFn_Cast(t.F_ws); var tmp28 jrt.Number_I; var na_1365 any = i__9; if jrt.Long_InstanceOf(na_1365) { var n0_1366 int64 = jrt.NN(jrt.Long_Cast(na_1365)).LongValue__J(); if n0_1366 == 9223372036854775807 { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_1365) } else { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1366 + 1)) } } else { if jrt.Double_InstanceOf(na_1365) { var n0_1366_2 float64 = jrt.NN(jrt.Double_Cast(na_1365)).DoubleValue__D(); tmp28 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1366_2 + 1.0)) } else { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_1365) } }; i__4_2, v__5 = tmp27.Invoke_O__O(tmp28), v__10; continue L2 } else { var tmp29 bool; var and__1927000168__auto____11_3 bool; var na_1279 any = i__9; var na_1280 int64 = int64(t.F_n)
															if jrt.Long_InstanceOf(na_1279) { var n0_1281 int64 = jrt.NN(jrt.Long_Cast(na_1279)).LongValue__J(); var n1_1282 int64 = na_1280; and__1927000168__auto____11_3 = n0_1281 < n1_1282 } else { and__1927000168__auto____11_3 = lang.Numbers_Lt_O_J__Z_NoInit(na_1279, na_1280) }; if and__1927000168__auto____11_3 { var tmp30 *jrt.String = jrt.String_Cast(t.F_s); tmp29 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_88)).CharValue__C(), jrt.NN(tmp30).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__9))) } else { tmp29 = and__1927000168__auto____11_3 }
//line :214:1
															if tmp29 { var tmp31 jrt.Number_I; var na_1367 any = i__9
																if jrt.Long_InstanceOf(na_1367) { var n0_1368 int64 = jrt.NN(jrt.Long_Cast(na_1367)).LongValue__J(); if n0_1368 == 9223372036854775807 { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_1367) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1368 + 1)) } } else { if jrt.Double_InstanceOf(na_1367) { var n0_1368_2 float64 = jrt.NN(jrt.Double_Cast(na_1367)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1368_2 + 1.0)) } else { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_1367) } }
//line :214:1
																return lang.Tuple_Create_O_O__IPersistentVector(v__10, tmp31) } else { if A_arbace_j2g_meta_A_const_48 != nil {

																	var root_1284 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = t.F_s; var arg_1288 any = i__9; var arg_1289 any = Lit_56; if linked_1285 == nil { return ifn_1286.Invoke_O_O_O__O(arg_1287, arg_1288, arg_1289) } else { return linked_1285.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1284, arg_1287, arg_1288, arg_1289) } } else {
//line :214:1
																		return nil } } } } } } else {
//line :194:1
																			if lang.Util_Equiv_C_C__Z_NoInit(c__3, jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_89)).CharValue__C()) { var sb__4 any = jrt.StringBuilder_New(); var i__5 any
																				var na_1290 any = i__2






















																				if jrt.Long_InstanceOf(na_1290) { var n0_1291 int64 = jrt.NN(jrt.Long_Cast(na_1290)).LongValue__J(); if n0_1291 == 9223372036854775807 { i__5 = lang.Numbers_Inc_O__Number_NoInit(na_1290) } else { i__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1291 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1290) { var n0_1291_2 float64 = jrt.NN(jrt.Double_Cast(na_1290)).DoubleValue__D(); i__5 = jrt.Double_ValueOf_D__Double_NoInit(n0_1291_2 + 1.0).Ref() } else { i__5 = lang.Numbers_Inc_O__Number_NoInit(na_1290) } }
//line :194:1
																			L3: for {
























																				var tmp32 bool; var na_1369 any = i__5; var na_1370 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1369) { var n0_1371 int64 = jrt.NN(jrt.Long_Cast(na_1369)).LongValue__J(); var n1_1372 int64 = na_1370; tmp32 = n0_1371 >= n1_1372 } else { tmp32 = lang.Numbers_Gte_O_J__Z_NoInit(na_1369, na_1370) }; if tmp32 { var root_1374 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = t.F_s; var arg_1378 any = i__5; var arg_1379 any = Lit_57; if linked_1375 == nil { ifn_1376.Invoke_O_O_O__O(arg_1377, arg_1378, arg_1379) } else { linked_1375.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1374, arg_1377, arg_1378, arg_1379) } }
//line :194:1
																				var tmp33 *jrt.String = jrt.String_Cast(t.F_s); var c__6 uint16 = jrt.NN(tmp33).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__5))


























																				if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_89)).CharValue__C()) { var tmp34 any; var root_1380 any = A_arbace_j2g_meta_A_const_93.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1382 lang.IFn
																					if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = sb__4; if linked_1381 == nil { tmp34 = ifn_1382.Invoke_O__O(arg_1383) } else { tmp34 = linked_1381.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1380, arg_1383) }
//line :221:1
																					var tmp35 any = tmp34; var tmp36 jrt.Number_I; var na_1384 any = i__5
																					if jrt.Long_InstanceOf(na_1384) { var n0_1385 int64 = jrt.NN(jrt.Long_Cast(na_1384)).LongValue__J(); if n0_1385 == 9223372036854775807 { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_1384) } else { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1385 + 1)) } } else { if jrt.Double_InstanceOf(na_1384) { var n0_1385_2 float64 = jrt.NN(jrt.Double_Cast(na_1384)).DoubleValue__D(); tmp36 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1385_2 + 1.0)) } else { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_1384) } }
//line :221:1
																					return lang.Tuple_Create_O_O__IPersistentVector(tmp35, tmp36) } else { if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_j2g_meta_A_const_90)).CharValue__C()) { var e__7 uint16; var tmp37 *jrt.String = jrt.String_Cast(t.F_s); var tmp38 jrt.Number_I
																						var na_1292 any = i__5
																						if jrt.Long_InstanceOf(na_1292) { var n0_1293 int64 = jrt.NN(jrt.Long_Cast(na_1292)).LongValue__J(); if n0_1293 == 9223372036854775807 { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_1292) } else { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1293 + 1)) } } else { if jrt.Double_InstanceOf(na_1292) { var n0_1293_2 float64 = jrt.NN(jrt.Double_Cast(na_1292)).DoubleValue__D(); tmp38 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1293_2 + 1.0)) } else { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_1292) } }; e__7 = jrt.NN(tmp37).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp38))
//line :221:1
																						var G__849000289__8_ uint16 = e__7


																						switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000289__8_).Ref()) { case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000289__8_).Ref(), A_arbace_j2g_meta_A_const_91) {
																							var tmp39 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp40 any; var root_1386 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = t.F_s; var arg_1390 any; var na_1392 any = i__5; var na_1393 int64 = 2; if jrt.Long_InstanceOf(na_1392) { var n0_1394 int64 = jrt.NN(jrt.Long_Cast(na_1392)).LongValue__J(); var n1_1395 int64 = na_1393; var nr_1396 int64 = n0_1394 + n1_1395; if (n0_1394^nr_1396)&(n1_1395^nr_1396) >= 0 { arg_1390 = jrt.Long_ValueOf_J__Long_NoInit(nr_1396).Ref() } else { arg_1390 = lang.Numbers_Add_O_J__Number_NoInit(na_1392, na_1393) } } else { arg_1390 = lang.Numbers_Add_O_J__Number_NoInit(na_1392, na_1393) }; var arg_1391 any; var na_1397 any = i__5; var na_1398 int64 = 6; if jrt.Long_InstanceOf(na_1397) { var n0_1399 int64 = jrt.NN(jrt.Long_Cast(na_1397)).LongValue__J(); var n1_1400 int64 = na_1398; var nr_1401 int64 = n0_1399 + n1_1400; if (n0_1399^nr_1401)&(n1_1400^nr_1401) >= 0 { arg_1391 = jrt.Long_ValueOf_J__Long_NoInit(nr_1401).Ref() } else { arg_1391 = lang.Numbers_Add_O_J__Number_NoInit(na_1397, na_1398) } } else { arg_1391 = lang.Numbers_Add_O_J__Number_NoInit(na_1397, na_1398) }; if linked_1387 == nil { tmp40 = ifn_1388.Invoke_O_O_O__O(arg_1389, arg_1390, arg_1391) } else { tmp40 = linked_1387.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1386, arg_1389, arg_1390, arg_1391) }; jrt.NN(tmp39).Append_C__StringBuilder(lang.RT_CharCast_I__C_NoInit(jrt.Integer_ParseInt_String_I__I_NoInit(jrt.String_Cast(tmp40), lang.RT_IntCast_J__I_NoInit(16))))
																							var tmp41 jrt.Number_I; var na_1402 any = i__5; var na_1403 int64 = 6; if jrt.Long_InstanceOf(na_1402) { var n0_1404 int64 = jrt.NN(jrt.Long_Cast(na_1402)).LongValue__J(); var n1_1405 int64 = na_1403; var nr_1406 int64 = n0_1404 + n1_1405; if (n0_1404^nr_1406)&(n1_1405^nr_1406) >= 0 { tmp41 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1406)) } else { tmp41 = lang.Numbers_Add_O_J__Number_NoInit(na_1402, na_1403) } } else { tmp41 = lang.Numbers_Add_O_J__Number_NoInit(na_1402, na_1403) }; i__5 = tmp41; continue L3 }
//line :224:1
																						default:
																						}

																						var tmp42 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp43 any; var G__849000290__9_ uint16 = e__7; L5: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref()) { case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref(), A_arbace_j2g_meta_A_const_94) { tmp43 = A_arbace_j2g_meta_A_const_95; break L5 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref(), A_arbace_j2g_meta_A_const_96) { tmp43 = A_arbace_j2g_meta_A_const_97; break L5 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref(), A_arbace_j2g_meta_A_const_98) { tmp43 = A_arbace_j2g_meta_A_const_99; break L5 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref(), A_arbace_j2g_meta_A_const_100) { tmp43 = A_arbace_j2g_meta_A_const_101; break L5 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__849000290__9_).Ref(), A_arbace_j2g_meta_A_const_102) { tmp43 = A_arbace_j2g_meta_A_const_103; break L5 }; default:}; tmp43 = jrt.Character_ValueOf_C__Character_NoInit(e__7).Ref()}; jrt.NN(tmp42).Append_O__StringBuilder(tmp43)

																						var tmp44 jrt.Number_I; var na_1408 any = i__5; var na_1409 int64 = 2; if jrt.Long_InstanceOf(na_1408) { var n0_1410 int64 = jrt.NN(jrt.Long_Cast(na_1408)).LongValue__J(); var n1_1411 int64 = na_1409; var nr_1412 int64 = n0_1410 + n1_1411; if (n0_1410^nr_1412)&(n1_1411^nr_1412) >= 0 { tmp44 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1412)) } else { tmp44 = lang.Numbers_Add_O_J__Number_NoInit(na_1408, na_1409) } } else { tmp44 = lang.Numbers_Add_O_J__Number_NoInit(na_1408, na_1409) }; i__5 = tmp44; continue L3 } else {
//line :221:1
																							if A_arbace_j2g_meta_A_const_48 != nil {








																								jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_C__StringBuilder(c__6); var tmp45 jrt.Number_I; var na_1413 any = i__5; if jrt.Long_InstanceOf(na_1413) { var n0_1414 int64 = jrt.NN(jrt.Long_Cast(na_1413)).LongValue__J(); if n0_1414 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_1413) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1414 + 1)) } } else { if jrt.Double_InstanceOf(na_1413) { var n0_1414_2 float64 = jrt.NN(jrt.Double_Cast(na_1413)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1414_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_1413) } }; i__5 = tmp45; continue L3 } else {
//line :221:1
																									return nil } } } } } else {
//line :194:1
																										var tmp46 any; var root_1295 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1297 lang.IFn




































																										if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var root_1300 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = t.F_s; var arg_1304 any = i__2; if linked_1301 == nil { arg_1298 = ifn_1302.Invoke_O_O__O(arg_1303, arg_1304) } else { arg_1298 = linked_1301.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1300, arg_1303, arg_1304) }; var arg_1299 any = Lit_58; if linked_1296 == nil { tmp46 = ifn_1297.Invoke_O_O__O(arg_1298, arg_1299) } else { tmp46 = linked_1296.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1295, arg_1298, arg_1299) }
//line :194:1
																										if jrt.J2g_Truth(tmp46) { var tmp47 any = jrt.Boolean_TRUE.Ref(); var tmp48 jrt.Number_I
																											var na_1415 any = i__2
																											var na_1416 int64 = 4


































																											if jrt.Long_InstanceOf(na_1415) { var n0_1417 int64 = jrt.NN(jrt.Long_Cast(na_1415)).LongValue__J(); var n1_1418 int64 = na_1416; var nr_1419 int64 = n0_1417 + n1_1418; if (n0_1417^nr_1419)&(n1_1418^nr_1419) >= 0 { tmp48 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1419)) } else { tmp48 = lang.Numbers_Add_O_J__Number_NoInit(na_1415, na_1416) } } else { tmp48 = lang.Numbers_Add_O_J__Number_NoInit(na_1415, na_1416) }
//line :194:1
																											return lang.Tuple_Create_O_O__IPersistentVector(tmp47, tmp48) } else { var tmp49 any; var root_1305 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1307 lang.IFn





































																												if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var root_1310 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = t.F_s; var arg_1314 any = i__2; if linked_1311 == nil { arg_1308 = ifn_1312.Invoke_O_O__O(arg_1313, arg_1314) } else { arg_1308 = linked_1311.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1310, arg_1313, arg_1314) }; var arg_1309 any = Lit_59; if linked_1306 == nil { tmp49 = ifn_1307.Invoke_O_O__O(arg_1308, arg_1309) } else { tmp49 = linked_1306.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1305, arg_1308, arg_1309) }
//line :194:1
																												if jrt.J2g_Truth(tmp49) { var tmp50 any = jrt.Boolean_FALSE.Ref(); var tmp51 jrt.Number_I
																													var na_1420 any = i__2
																													var na_1421 int64 = 5



































																													if jrt.Long_InstanceOf(na_1420) { var n0_1422 int64 = jrt.NN(jrt.Long_Cast(na_1420)).LongValue__J(); var n1_1423 int64 = na_1421; var nr_1424 int64 = n0_1422 + n1_1423; if (n0_1422^nr_1424)&(n1_1423^nr_1424) >= 0 { tmp51 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1424)) } else { tmp51 = lang.Numbers_Add_O_J__Number_NoInit(na_1420, na_1421) } } else { tmp51 = lang.Numbers_Add_O_J__Number_NoInit(na_1420, na_1421) }
//line :194:1
																													return lang.Tuple_Create_O_O__IPersistentVector(tmp50, tmp51) } else { var tmp52 any; var root_1315 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1317 lang.IFn






































																														if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any; var root_1320 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = t.F_s; var arg_1324 any = i__2; if linked_1321 == nil { arg_1318 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { arg_1318 = linked_1321.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) }; var arg_1319 any = Lit_60; if linked_1316 == nil { tmp52 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { tmp52 = linked_1316.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }
//line :194:1
																														if jrt.J2g_Truth(tmp52) { var tmp53 jrt.Number_I
																															var na_1425 any = i__2
																															var na_1426 int64 = 4




































																															if jrt.Long_InstanceOf(na_1425) { var n0_1427 int64 = jrt.NN(jrt.Long_Cast(na_1425)).LongValue__J(); var n1_1428 int64 = na_1426; var nr_1429 int64 = n0_1427 + n1_1428; if (n0_1427^nr_1429)&(n1_1428^nr_1429) >= 0 { tmp53 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1429)) } else { tmp53 = lang.Numbers_Add_O_J__Number_NoInit(na_1425, na_1426) } } else { tmp53 = lang.Numbers_Add_O_J__Number_NoInit(na_1425, na_1426) }
//line :194:1
																															return lang.Tuple_Create_O_O__IPersistentVector(nil, tmp53) } else { if A_arbace_j2g_meta_A_const_48 != nil { var j__4 any; var tmp54 *lang.Compiler_AOTFn; var fnbody__1333 any = A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A_New_O_I_O(i__2, t.F_n, t.F_s); var tmp55 *jrt.Class
																																var fncls__1332 /*line :194:1*/*jrt.Class = A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A_fn_class







































																																if fncls__1332 == nil { var fncls__1332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__1333); A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A_fn_class = fncls__1332d; tmp55 = fncls__1332d } else { tmp55 = fncls__1332 }; tmp54 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1333, tmp55, nil); j__4 = Up_Compiler_AOTFn_IFn(tmp54).Invoke__O()
//line :194:1
																																var t__5 any; var root_1334 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1336 lang.IFn









































																																if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = t.F_s; var arg_1338 any = i__2; var arg_1339 any = j__4; if linked_1335 == nil { t__5 = ifn_1336.Invoke_O_O_O__O(arg_1337, arg_1338, arg_1339) } else { t__5 = linked_1335.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1334, arg_1337, arg_1338, arg_1339) }
																																if lang.Util_Equiv_O_O__Z_NoInit(i__2, j__4) { var root_1430 any = A_arbace_j2g_meta_A_const_84.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, A_arbace_j2g_meta_json_fail_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = t.F_s; var arg_1434 any = i__2; var arg_1435 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character_NoInit(c__3).Ref())).Ref(); if linked_1431 == nil { ifn_1432.Invoke_O_O_O__O(arg_1433, arg_1434, arg_1435) } else { linked_1431.(*A_arbace_j2g_meta_json_fail_A).Invoke_O_O_O_O__O(root_1430, arg_1433, arg_1434, arg_1435) } }
//line :194:1
																																var tmp56 jrt.Number_I; var tmp57 any; var root_1436 any = A_arbace_j2g_meta_A_const_104.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1438 lang.IFn











































																																if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = A_arbace_j2g_meta_A_const_105; var arg_1440 any = t__5; if linked_1437 == nil { tmp57 = ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { tmp57 = linked_1437.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) }; if jrt.J2g_Truth(tmp57) { tmp56 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(jrt.Double_ParseDouble_String__D_NoInit(jrt.String_Cast(t__5)))) } else { tmp56 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(t__5)))) }
//line :194:1
																																return lang.Tuple_Create_O_O__IPersistentVector(tmp56, j__4) } else { return nil } } } } } } } }; /*line :190:1*/panic("j2g: unreachable") }











































func A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A) Ctor_O_I_O(c__i any, c__n int32, c__s any) { t.F_i = c__i; t.F_n = c__n; t.F_s = c__s }
//line :234:1
func (t *A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; var and__1927000168__auto____2 bool; var na_1325 any = j__1; var na_1326 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_1325) { var n0_1327 int64 = jrt.NN(jrt.Long_Cast(na_1325)).LongValue__J(); var n1_1328 int64 = na_1326; and__1927000168__auto____2 = n0_1327 < n1_1328 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_1325, na_1326) }; if and__1927000168__auto____2 { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_meta_A_const_92); var tmp3 *jrt.String = jrt.String_Cast(t.F_s); tmp1 = tmp2.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))).Ref()) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
													var tmp4 jrt.Number_I; var na_1330 any = j__1; if jrt.Long_InstanceOf(na_1330) { var n0_1331 int64 = jrt.NN(jrt.Long_Cast(na_1330)).LongValue__J(); if n0_1331 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1330) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1331 + 1)) } } else { if jrt.Double_InstanceOf(na_1330) { var n0_1331_2 float64 = jrt.NN(jrt.Double_Cast(na_1330)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1331_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1330) } }; j__1 = tmp4; continue L1 } else {
//line :234:1
		return j__1 } } }; panic("j2g: unreachable") }











func A_arbace_j2g_meta_metadata_path_QMARK__A_New() *A_arbace_j2g_meta_metadata_path_QMARK__A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_path_QMARK__A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_j2g_meta_metadata_path_QMARK__A) Ctor() {}
//line :246:1
func (t *A_arbace_j2g_meta_metadata_path_QMARK__A) Invoke_O_O__O(self, p__0 any) any {


	var tmp1 any; var root_1454 any = A_arbace_j2g_meta_A_const_29.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = A_arbace_j2g_meta_A_const_106; var arg_1458 any; var root_1459 any = A_arbace_j2g_meta_A_const_38.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1461 lang.IFn
	if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1463 any = A_arbace_j2g_meta_A_const_36.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, A_arbace_j2g_meta_unroot_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = p__0; if linked_1464 == nil { arg_1462 = ifn_1465.Invoke_O__O(arg_1466) } else { arg_1462 = linked_1464.(*A_arbace_j2g_meta_unroot_A).Invoke_O_O__O(root_1463, arg_1466) }; if linked_1460 == nil { arg_1458 = ifn_1461.Invoke_O__O(arg_1462) } else { arg_1458 = linked_1460.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1459, arg_1462) }
//line :249:1
	if linked_1455 == nil { tmp1 = ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { tmp1 = linked_1455.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_meta_condition_of_A_New() *A_arbace_j2g_meta_condition_of_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_condition_of_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_j2g_meta_condition_of_A) Ctor() {}
//line :252:1
func (t *A_arbace_j2g_meta_condition_of_A) Invoke_O_O__O(self, e__0 any) any { var c__2 any = lang.RT_Get_O_O__O_NoInit(e__0, Lit_16); var tmp1 any; var root_1467 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1469 lang.IFn; if

	linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = c__2; if linked_1468 == nil { tmp1 = ifn_1469.Invoke_O__O(arg_1470) } else { tmp1 = linked_1468.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1467, arg_1470) }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(c__2, Lit_17); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return lang.RT_Get_O_O__O_NoInit(c__2, Lit_18) } } else { return nil } }

func A_arbace_j2g_meta_reflection_specs_A_New() *A_arbace_j2g_meta_reflection_specs_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflection_specs_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_meta_reflection_specs_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_meta_reflection_specs_A) Invoke_O_O__O(self, e__0 any) any { var c__2 any; var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(e__0, Lit_36); if




	jrt.J2g_Truth(or__1927000174__auto____2) { c__2 = or__1927000174__auto____2 } else { c__2 = lang.RT_Get_O_O__O_NoInit(e__0, Lit_66) }; var tmp1 any; var root_1471 any =
	A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = c__2; if linked_1472 == nil { tmp1 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp1 = linked_1472.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1471, arg_1474) }; if jrt.J2g_Truth(tmp1) { var all_QMARK___3 any; var fnbody__1480 any = A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A_New_O(e__0); var tmp2 *jrt.Class; var fncls__1479 *jrt.Class = A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A_fn_class
		if fncls__1479 == nil { var fncls__1479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__1480); A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A_fn_class = fncls__1479d; tmp2 = fncls__1479d } else { tmp2 = fncls__1479 }; all_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1480, tmp2, nil)
		var root_1481 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any; var root_1485 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_meta_A_const_74.GetRawRoot__O()); var tmp4 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, c__2, nil)).Ref()); var tmp5 lang.IPersistentVector; var tmp6 any; var root_1496 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1498 lang.IFn

		if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = all_QMARK___3; var arg_1500 any = A_arbace_j2g_meta_A_const_110; if linked_1497 == nil { tmp6 = ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { tmp6 = linked_1497.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) }; if jrt.J2g_Truth(tmp6) { tmp5 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, c__2, nil)).Ref()) } else { tmp5 = nil }
//line :265:1
		var tmp7 any = tmp5; var tmp8 lang.IPersistentVector; var tmp9 any; var root_1501 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1503 lang.IFn



		if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = all_QMARK___3; var arg_1505 any = A_arbace_j2g_meta_A_const_111; if linked_1502 == nil { tmp9 = ifn_1503.Invoke_O_O__O(arg_1504, arg_1505) } else { tmp9 = linked_1502.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1501, arg_1504, arg_1505) }; if jrt.J2g_Truth(tmp9) { tmp8 = lang.Tuple_Create_O__IPersistentVector(c__2) } else { tmp8 = nil }
//line :265:1
		var tmp10 any = tmp8; var tmp11 any; var iter__1927001039__auto____4 any; var fnbody__1579 any = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A_New_O(c__2); var tmp12 *jrt.Class
		var fncls__1578 /*line :265:1*/*jrt.Class = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A_fn_class





		if fncls__1578 == nil { var fncls__1578d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1579); A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A_fn_class = fncls__1578d; tmp12 = fncls__1578d } else { tmp12 = fncls__1578 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1579, tmp12, nil); var tmp13 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp14 any; var root_1580 any = A_arbace_j2g_meta_A_const_74.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = lang.RT_Get_O_O__O_NoInit(e__0, Lit_69); var arg_1584 any = lang.RT_Get_O_O__O_NoInit(e__0, Lit_70); if linked_1581 == nil { tmp14 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { tmp14 = linked_1581.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; tmp11 = tmp13.Invoke_O__O(tmp14)
//line :265:1
		arg_1488 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp7, tmp10, tmp11)
//line :264:1
		if linked_1486 == nil { arg_1484 = ifn_1487.Invoke_O__O(arg_1488) } else { arg_1484 = linked_1486.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1485, arg_1488) }; if linked_1482 == nil { return ifn_1483.Invoke_O__O(arg_1484) } else { return linked_1482.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1481, arg_1484) } } else {
//line :262:1
			return nil } }
func A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A_New_O(p0 any) *A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :263:1
func (t *A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A) Invoke_O_O__O(self, p1__849000297_SHARP___1 any) any { var root_1475 any = A_arbace_j2g_meta_A_const_108.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = lang.RT_Get_O_O__O_NoInit(t.F_e, p1__849000297_SHARP___1); if linked_1476 == nil { return ifn_1477.Invoke_O__O(arg_1478) } else { return linked_1476.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_1475, arg_1478) } }







func A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A_New_O(p0 any) *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A{}; t.Ctor_O(p0); return t }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A) Invoke_O_O__O(self, s__849000301__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1577 any = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A_New_O_O_O(t.F_c, self, s__849000301__1); var tmp2 *jrt.Class; var fncls__1576 *jrt.Class = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A_fn_class; if fncls__1576 == nil { var fncls__1576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__1577); A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A_fn_class = fncls__1576d; tmp2 = fncls__1576d } else { tmp2 = fncls__1576 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1577, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :271:1
func A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A) Ctor_O_O_O(c__c, c__iter__849000300, c__s__849000301 any) { t.F_c = c__c; t.F_iter__849000300 = c__iter__849000300; t.F_s__849000301 = c__s__849000301 }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A) Invoke_O__O(self any) any { { var s__849000301__1 any; var t_ any = t.F_s__849000301; t.F_s__849000301 = nil; s__849000301__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1506 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = s__849000301__1; if linked_1507 == nil { temp__1927000414__auto____2 = ifn_1508.Invoke_O__O(arg_1509) } else { temp__1927000414__auto____2 = linked_1507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1506, arg_1509) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000301__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1510 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__849000301__3; if linked_1511 == nil { tmp1 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp1 = linked_1511.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1510, arg_1513) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1514 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = s__849000301__3; if linked_1515 == nil { c__1927001037__auto____4 = ifn_1516.Invoke_O__O(arg_1517) } else { c__1927001037__auto____4 = linked_1515.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1514, arg_1517) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000303__6 any; var root_1518 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1519 == nil { b__849000303__6 = ifn_1520.Invoke_O__O(arg_1521) } else { b__849000303__6 = linked_1519.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1518, arg_1521) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1532 any = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A_New_O_O_I_O(t.F_c, b__849000303__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1531 *jrt.Class = A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A_fn_class; if fncls__1531 == nil { var fncls__1531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1532); A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A_fn_class = fncls__1531d; tmp3 = fncls__1531d } else { tmp3 = fncls__1531 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1532, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1533 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any; var root_1538 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = b__849000303__6; if linked_1539 == nil { arg_1536 = ifn_1540.Invoke_O__O(arg_1541) } else { arg_1536 = linked_1539.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1538, arg_1541) }; var arg_1537 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000300); var tmp5 any; var root_1542 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = s__849000301__3; if linked_1543 == nil { tmp5 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp5 = linked_1543.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1542, arg_1545) }; arg_1537 = tmp4.Invoke_O__O(tmp5); if linked_1534 == nil { return ifn_1535.Invoke_O_O__O(arg_1536, arg_1537) } else { return linked_1534.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1533, arg_1536, arg_1537) } } else { var root_1546 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any; var root_1551 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = b__849000303__6; if linked_1552 == nil { arg_1549 = ifn_1553.Invoke_O__O(arg_1554) } else { arg_1549 = linked_1552.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1551, arg_1554) }; var arg_1550 any; if linked_1547 == nil { return ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { return linked_1547.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) } } } else { var m__4 any; var root_1555 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = s__849000301__3; if linked_1556 == nil { m__4 = ifn_1557.Invoke_O__O(arg_1558) } else { m__4 = linked_1556.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1555, arg_1558) }; var nme__5 any = lang.RT_Get_O_O__O_NoInit(m__4, Lit_36); var tmp6 any; var root_1559 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1561 lang.IFn
															if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = nme__5; if linked_1560 == nil { tmp6 = ifn_1561.Invoke_O__O(arg_1562) } else { tmp6 = linked_1560.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1559, arg_1562) }
//line :271:1
	if jrt.J2g_Truth(tmp6) { var root_1563 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, t.F_c, nil, nme__5)).Ref(); var arg_1567 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__849000300); var tmp8 any; var root_1568 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = s__849000301__3; if linked_1569 == nil { tmp8 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp8 = linked_1569.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1568, arg_1571) }; arg_1567 = tmp7.Invoke_O__O(tmp8); if linked_1564 == nil { return ifn_1565.Invoke_O_O__O(arg_1566, arg_1567) } else { return linked_1564.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1563, arg_1566, arg_1567) } } else { var tmp9 any; var root_1572 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = s__849000301__3; if linked_1573 == nil { tmp9 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp9 = linked_1573.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1572, arg_1575) }; s__849000301__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :271:1
func A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A) Ctor_O_O_I_O(c__c, c__b__849000303 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_b__849000303 = c__b__849000303; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :271:1
func (t *A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A) Invoke_O__O(self any) any { { var i__849000302__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000302__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000302__1)); var nme__3 any = lang.RT_Get_O_O__O_NoInit(m__2, Lit_36); var tmp2 any; var root_1522 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1524 lang.IFn
																if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = nme__3; if linked_1523 == nil { tmp2 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp2 = linked_1523.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1522, arg_1525) }
//line :271:1
	if jrt.J2g_Truth(tmp2) { var root_1526 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = t.F_b__849000303; var arg_1530 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, t.F_c, nil, nme__3)).Ref(); if linked_1527 == nil { ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { linked_1527.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) }; i__849000302__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000302__1); continue L1 } else { i__849000302__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000302__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_meta_metadata_roots_A_New() *A_arbace_j2g_meta_metadata_roots_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_meta_metadata_roots_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_meta_metadata_roots_A) Invoke_O_O_O__O(self, path__0, v__1 any) any { var entries__3 any; var fnbody__1688 any = A_arbace_j2g_meta_metadata_roots_entries__849000311_A_New(); var tmp1 *jrt.Class; var fncls__1687 *jrt.Class = A_arbace_j2g_meta_metadata_roots_entries__849000311_A_fn_class; if






	fncls__1687 == nil { var fncls__1687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_j2g_meta_metadata_roots_entries__849000311_A_fn_class = fncls__1687d; tmp1 = fncls__1687d } else { tmp1 = fncls__1687 }; entries__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1688, tmp1, nil); var bundles__4 any; var fnbody__1784 any = /*line :275:1*/A_arbace_j2g_meta_metadata_roots_bundles__849000323_A_New(); var tmp2 *jrt.Class; var fncls__1783 *jrt.Class = A_arbace_j2g_meta_metadata_roots_bundles__849000323_A_fn_class; if








	fncls__1783 == nil { var fncls__1783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_j2g_meta_metadata_roots_bundles__849000323_A_fn_class = fncls__1783d; tmp2 = fncls__1783d } else { tmp2 = fncls__1783 }; bundles__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1784, tmp2, nil); var root_1785 any =

	A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any; var tmp3 any; var root_1789 any = A_arbace_j2g_meta_A_const_104.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1791 lang.IFn; if

	linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = A_arbace_j2g_meta_A_const_114; var arg_1793 any = path__0; if linked_1790 == nil { tmp3 = ifn_1791.Invoke_O_O__O(arg_1792, arg_1793) } else { tmp3 = linked_1790.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1789, arg_1792, arg_1793) }; if /*line :287:1*/ jrt.J2g_Truth(tmp3) {
		arg_1788 = lang.IFn_Cast(entries__3).Invoke_O__O(v__1) } else {
//line :287:1
			var tmp4 any; var root_1794 any = A_arbace_j2g_meta_A_const_104.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1796 lang.IFn

			if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = A_arbace_j2g_meta_A_const_115; var arg_1798 any = path__0; if linked_1795 == nil { tmp4 = ifn_1796.Invoke_O_O__O(arg_1797, arg_1798) } else { tmp4 = linked_1795.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1794, arg_1797, arg_1798) }
//line :287:1
			if jrt.J2g_Truth(tmp4) {

				var tmp5 any; var root_1799 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = v__1; if linked_1800 == nil { tmp5 = ifn_1801.Invoke_O__O(arg_1802) } else { tmp5 = linked_1800.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1799, arg_1802) }; if jrt.J2g_Truth(tmp5) { arg_1788 = lang.IFn_Cast(bundles__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(v__1, Lit_30)) } else { arg_1788 = nil } } else {
//line :287:1
					var tmp6 any; var root_1803 any = A_arbace_j2g_meta_A_const_104.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1805 lang.IFn


					if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = A_arbace_j2g_meta_A_const_116; var arg_1807 any = path__0; if linked_1804 == nil { tmp6 = ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { tmp6 = linked_1804.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) }
//line :287:1
					if jrt.J2g_Truth(tmp6) {



						var tmp7 any; var root_1808 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1810 lang.IFn; if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = v__1; if linked_1809 == nil { tmp7 = ifn_1810.Invoke_O__O(arg_1811) } else { tmp7 = linked_1809.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1808, arg_1811) }; if jrt.J2g_Truth(tmp7) { arg_1788 = lang.IFn_Cast(A_arbace_j2g_meta_A_const_74.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(entries__3).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(v__1, Lit_31)), lang.IFn_Cast(entries__3).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(v__1, Lit_32)), lang.IFn_Cast(bundles__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(v__1, Lit_30))) } else { arg_1788 = nil } } else {
//line :287:1
							if A_arbace_j2g_meta_A_const_48 != nil { arg_1788 = nil } else { arg_1788 = nil } } } }; if /*line :286:1*/ linked_1786 == nil { return ifn_1787.Invoke_O__O(arg_1788) } else { return linked_1786.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1785, arg_1788) } }
//line :282:1
func A_arbace_j2g_meta_metadata_roots_entries__849000311_A_New() *A_arbace_j2g_meta_metadata_roots_entries__849000311_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_entries__849000311_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_A) Ctor() {}
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_A) Invoke_O_O__O(self, xs__1 any) any { var iter__1927001039__auto____2 any; var fnbody__1686 any = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A_New(); var tmp1 *jrt.Class; var fncls__1685 *jrt.Class = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A_fn_class; if fncls__1685 == nil { var fncls__1685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A_fn_class = fncls__1685d; tmp1 = fncls__1685d } else { tmp1 = fncls__1685 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1686, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(xs__1) }
//line :282:1
func A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A_New() *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A) Ctor() {}
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A) Invoke_O_O__O(self, s__849000313__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1684 any = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A_New_O_O(self, s__849000313__1); var tmp2 *jrt.Class; var fncls__1683 *jrt.Class = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A_fn_class; if fncls__1683 == nil { var fncls__1683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1684); A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A_fn_class = fncls__1683d; tmp2 = fncls__1683d } else { tmp2 = fncls__1683 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1684, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :282:1
func A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A{}; t.Ctor_O_O(p0, p1); return t }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A) Ctor_O_O(c__iter__849000312, c__s__849000313 any) { t.F_iter__849000312 = c__iter__849000312; t.F_s__849000313 = c__s__849000313 }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A) Invoke_O__O(self any) any { { var s__849000313__1 any; var t_ any = t.F_s__849000313; t.F_s__849000313 = nil; s__849000313__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1585 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = s__849000313__1; if linked_1586 == nil { temp__1927000414__auto____2 = ifn_1587.Invoke_O__O(arg_1588) } else { temp__1927000414__auto____2 = linked_1586.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1585, arg_1588) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000313__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1589 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = s__849000313__3; if linked_1590 == nil { tmp1 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp1 = linked_1590.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1593 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = s__849000313__3; if linked_1594 == nil { c__1927001037__auto____4 = ifn_1595.Invoke_O__O(arg_1596) } else { c__1927001037__auto____4 = linked_1594.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1593, arg_1596) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000315__6 any; var root_1597 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1598 == nil { b__849000315__6 = ifn_1599.Invoke_O__O(arg_1600) } else { b__849000315__6 = linked_1598.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1597, arg_1600) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1623 any = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A_New_I_O_O(size__1927001038__auto____5, b__849000315__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1622 *jrt.Class = A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A_fn_class; if fncls__1622 == nil { var fncls__1622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1623); A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A_fn_class = fncls__1622d; tmp3 = fncls__1622d } else { tmp3 = fncls__1622 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1623, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1624 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var root_1629 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = b__849000315__6; if linked_1630 == nil { arg_1627 = ifn_1631.Invoke_O__O(arg_1632) } else { arg_1627 = linked_1630.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1629, arg_1632) }; var arg_1628 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000312); var tmp5 any; var root_1633 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = s__849000313__3; if linked_1634 == nil { tmp5 = ifn_1635.Invoke_O__O(arg_1636) } else { tmp5 = linked_1634.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1633, arg_1636) }; arg_1628 = tmp4.Invoke_O__O(tmp5); if linked_1625 == nil { return ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { return linked_1625.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) } } else { var root_1637 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any; var root_1642 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = b__849000315__6; if linked_1643 == nil { arg_1640 = ifn_1644.Invoke_O__O(arg_1645) } else { arg_1640 = linked_1643.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1642, arg_1645) }; var arg_1641 any; if linked_1638 == nil { return ifn_1639.Invoke_O_O__O(arg_1640, arg_1641) } else { return linked_1638.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1637, arg_1640, arg_1641) } } } else { var e__4 any; var root_1646 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = s__849000313__3; if linked_1647 == nil { e__4 = ifn_1648.Invoke_O__O(arg_1649) } else { e__4 = linked_1647.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1646, arg_1649) }; var tmp6 any; var root_1650 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = e__4; if linked_1651 == nil { tmp6 = ifn_1652.Invoke_O__O(arg_1653) } else { tmp6 = linked_1651.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1650, arg_1653) }; if jrt.J2g_Truth(tmp6) { var ss__5 any; var root_1654 any = A_arbace_j2g_meta_A_const_112.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, A_arbace_j2g_meta_reflection_specs_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = e__4; if linked_1655 == nil { ss__5 = ifn_1656.Invoke_O__O(arg_1657) } else { ss__5 = linked_1655.(*A_arbace_j2g_meta_reflection_specs_A).Invoke_O_O__O(root_1654, arg_1657) }; var tmp7 any; var root_1658 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = ss__5; if linked_1659 == nil { tmp7 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp7 = linked_1659.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1658, arg_1661) }; if jrt.J2g_Truth(tmp7) { var root_1662 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var tmp8 any; var root_1667 any = A_arbace_j2g_meta_A_const_113.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, A_arbace_j2g_meta_condition_of_A_fn_class); var ifn_1669 lang.IFn
																	if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = e__4; if linked_1668 == nil { tmp8 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp8 = linked_1668.(*A_arbace_j2g_meta_condition_of_A).Invoke_O_O__O(root_1667, arg_1670) }
//line :282:1
	arg_1665 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, ss__5); var arg_1666 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__849000312); var tmp10 any; var root_1671 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = s__849000313__3; if linked_1672 == nil { tmp10 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp10 = linked_1672.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1671, arg_1674) }; arg_1666 = tmp9.Invoke_O__O(tmp10); if linked_1663 == nil { return ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { return linked_1663.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) } } else { var tmp11 any; var root_1675 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = s__849000313__3; if linked_1676 == nil { tmp11 = ifn_1677.Invoke_O__O(arg_1678) } else { tmp11 = linked_1676.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1675, arg_1678) }; s__849000313__1 = tmp11; continue L1 } } else { var tmp12 any; var root_1679 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = s__849000313__3; if linked_1680 == nil { tmp12 = ifn_1681.Invoke_O__O(arg_1682) } else { tmp12 = linked_1680.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1679, arg_1682) }; s__849000313__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :282:1
func A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__849000315, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__849000315 = c__b__849000315; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :282:1
func (t *A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A) Invoke_O__O(self any) any { { var i__849000314__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000314__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000314__1)); var tmp2 any; var root_1601 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = e__2; if linked_1602 == nil { tmp2 = ifn_1603.Invoke_O__O(arg_1604) } else { tmp2 = linked_1602.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1601, arg_1604) }; if jrt.J2g_Truth(tmp2) { var ss__3 any; var root_1605 any = A_arbace_j2g_meta_A_const_112.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, A_arbace_j2g_meta_reflection_specs_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = e__2; if linked_1606 == nil { ss__3 = ifn_1607.Invoke_O__O(arg_1608) } else { ss__3 = linked_1606.(*A_arbace_j2g_meta_reflection_specs_A).Invoke_O_O__O(root_1605, arg_1608) }; var tmp3 any; var root_1609 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = ss__3; if linked_1610 == nil { tmp3 = ifn_1611.Invoke_O__O(arg_1612) } else { tmp3 = linked_1610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1609, arg_1612) }; if jrt.J2g_Truth(tmp3) { var root_1613 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = t.F_b__849000315; var arg_1617 any; var tmp4 any; var root_1618 any = A_arbace_j2g_meta_A_const_113.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, A_arbace_j2g_meta_condition_of_A_fn_class); var ifn_1620 lang.IFn
																			if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = e__2; if linked_1619 == nil { tmp4 = ifn_1620.Invoke_O__O(arg_1621) } else { tmp4 = linked_1619.(*A_arbace_j2g_meta_condition_of_A).Invoke_O_O__O(root_1618, arg_1621) }
//line :282:1
	arg_1617 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, ss__3); if linked_1614 == nil { ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { linked_1614.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) }; i__849000314__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000314__1); continue L1 } else { i__849000314__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000314__1); continue L1 } } else { i__849000314__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000314__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_meta_metadata_roots_bundles__849000323_A_New() *A_arbace_j2g_meta_metadata_roots_bundles__849000323_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_bundles__849000323_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_A) Ctor() {}
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_A) Invoke_O_O__O(self, xs__1 any) any { var iter__1927001039__auto____2 any; var fnbody__1782 any = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A_New(); var tmp1 *jrt.Class; var fncls__1781 *jrt.Class = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A_fn_class; if fncls__1781 == nil { var fncls__1781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A_fn_class = fncls__1781d; tmp1 = fncls__1781d } else { tmp1 = fncls__1781 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1782, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(xs__1) }
//line :284:1
func A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A_New() *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A) Ctor() {}
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A) Invoke_O_O__O(self, s__849000325__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1780 any = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A_New_O_O(self, s__849000325__1); var tmp2 *jrt.Class; var fncls__1779 *jrt.Class = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A_fn_class; if fncls__1779 == nil { var fncls__1779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1780); A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A_fn_class = fncls__1779d; tmp2 = fncls__1779d } else { tmp2 = fncls__1779 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1780, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :284:1
func A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A) Ctor_O_O(c__iter__849000324, c__s__849000325 any) { t.F_iter__849000324 = c__iter__849000324; t.F_s__849000325 = c__s__849000325 }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A) Invoke_O__O(self any) any { { var s__849000325__1 any; var t_ any = t.F_s__849000325; t.F_s__849000325 = nil; s__849000325__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1689 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = s__849000325__1; if linked_1690 == nil { temp__1927000414__auto____2 = ifn_1691.Invoke_O__O(arg_1692) } else { temp__1927000414__auto____2 = linked_1690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1689, arg_1692) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000325__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1693 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = s__849000325__3; if linked_1694 == nil { tmp1 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp1 = linked_1694.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1693, arg_1696) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1697 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = s__849000325__3; if linked_1698 == nil { c__1927001037__auto____4 = ifn_1699.Invoke_O__O(arg_1700) } else { c__1927001037__auto____4 = linked_1698.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1697, arg_1700) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000327__6 any; var root_1701 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1702 == nil { b__849000327__6 = ifn_1703.Invoke_O__O(arg_1704) } else { b__849000327__6 = linked_1702.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1701, arg_1704) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1723 any = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A_New_I_O_O(size__1927001038__auto____5, b__849000327__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1722 *jrt.Class = A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A_fn_class; if fncls__1722 == nil { var fncls__1722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1723); A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A_fn_class = fncls__1722d; tmp3 = fncls__1722d } else { tmp3 = fncls__1722 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1723, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1724 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any; var root_1729 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = b__849000327__6; if linked_1730 == nil { arg_1727 = ifn_1731.Invoke_O__O(arg_1732) } else { arg_1727 = linked_1730.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1729, arg_1732) }; var arg_1728 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000324); var tmp5 any; var root_1733 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = s__849000325__3; if linked_1734 == nil { tmp5 = ifn_1735.Invoke_O__O(arg_1736) } else { tmp5 = linked_1734.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1733, arg_1736) }; arg_1728 = tmp4.Invoke_O__O(tmp5); if linked_1725 == nil { return ifn_1726.Invoke_O_O__O(arg_1727, arg_1728) } else { return linked_1725.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1724, arg_1727, arg_1728) } } else { var root_1737 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any; var root_1742 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = b__849000327__6; if linked_1743 == nil { arg_1740 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1740 = linked_1743.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1742, arg_1745) }; var arg_1741 any; if linked_1738 == nil { return ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { return linked_1738.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) } } } else { var b__4 any; var root_1746 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = s__849000325__3; if linked_1747 == nil { b__4 = ifn_1748.Invoke_O__O(arg_1749) } else { b__4 = linked_1747.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1746, arg_1749) }; var tmp6 any; var root_1750 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = b__4; if linked_1751 == nil { tmp6 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp6 = linked_1751.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1750, arg_1753) }; if jrt.J2g_Truth(tmp6) { var nme__5 any = lang.RT_Get_O_O__O_NoInit(b__4, Lit_36); var tmp7 any; var root_1754 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = nme__5; if linked_1755 == nil { tmp7 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp7 = linked_1755.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1754, arg_1757) }; if jrt.J2g_Truth(tmp7) { var root_1758 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any; var tmp8 any; var root_1763 any = A_arbace_j2g_meta_A_const_113.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, A_arbace_j2g_meta_condition_of_A_fn_class); var ifn_1765 lang.IFn
																	if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = b__4; if linked_1764 == nil { tmp8 = ifn_1765.Invoke_O__O(arg_1766) } else { tmp8 = linked_1764.(*A_arbace_j2g_meta_condition_of_A).Invoke_O_O__O(root_1763, arg_1766) }
//line :284:1
	arg_1761 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nme__5, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, nme__5, nil)).Ref())); var arg_1762 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__849000324); var tmp10 any; var root_1767 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = s__849000325__3; if linked_1768 == nil { tmp10 = ifn_1769.Invoke_O__O(arg_1770) } else { tmp10 = linked_1768.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1767, arg_1770) }; arg_1762 = tmp9.Invoke_O__O(tmp10); if linked_1759 == nil { return ifn_1760.Invoke_O_O__O(arg_1761, arg_1762) } else { return linked_1759.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1758, arg_1761, arg_1762) } } else { var tmp11 any; var root_1771 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = s__849000325__3; if linked_1772 == nil { tmp11 = ifn_1773.Invoke_O__O(arg_1774) } else { tmp11 = linked_1772.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1771, arg_1774) }; s__849000325__1 = tmp11; continue L1 } } else { var tmp12 any; var root_1775 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = s__849000325__3; if linked_1776 == nil { tmp12 = ifn_1777.Invoke_O__O(arg_1778) } else { tmp12 = linked_1776.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1775, arg_1778) }; s__849000325__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :284:1
func A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__849000327, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__849000327 = c__b__849000327; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :284:1
func (t *A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A) Invoke_O__O(self any) any { { var i__849000326__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000326__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000326__1)); var tmp2 any; var root_1705 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = b__2; if linked_1706 == nil { tmp2 = ifn_1707.Invoke_O__O(arg_1708) } else { tmp2 = linked_1706.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1705, arg_1708) }; if jrt.J2g_Truth(tmp2) { var nme__3 any = lang.RT_Get_O_O__O_NoInit(b__2, Lit_36); var tmp3 any; var root_1709 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = nme__3; if linked_1710 == nil { tmp3 = ifn_1711.Invoke_O__O(arg_1712) } else { tmp3 = linked_1710.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1709, arg_1712) }; if jrt.J2g_Truth(tmp3) { var root_1713 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = t.F_b__849000327; var arg_1717 any; var tmp4 any; var root_1718 any = A_arbace_j2g_meta_A_const_113.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, A_arbace_j2g_meta_condition_of_A_fn_class); var ifn_1720 lang.IFn
																			if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = b__2; if linked_1719 == nil { tmp4 = ifn_1720.Invoke_O__O(arg_1721) } else { tmp4 = linked_1719.(*A_arbace_j2g_meta_condition_of_A).Invoke_O_O__O(root_1718, arg_1721) }
//line :284:1
	arg_1717 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nme__3, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, nme__3, nil)).Ref())); if linked_1714 == nil { ifn_1715.Invoke_O_O__O(arg_1716, arg_1717) } else { linked_1714.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1713, arg_1716, arg_1717) }; i__849000326__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000326__1); continue L1 } else { i__849000326__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000326__1); continue L1 } } else { i__849000326__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000326__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_meta_data_metadata_roots_A_New() *A_arbace_j2g_meta_data_metadata_roots_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_j2g_meta_data_metadata_roots_A) Ctor() {}
//line :294:1
func (t *A_arbace_j2g_meta_data_metadata_roots_A) Invoke_O_O__O(self, data__0 any) any { var rs__2 any; var iter__1927001039__auto____2 any; var fnbody__1901 any = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A_New_O(data__0); var tmp1 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A_fn_class; if



	fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__1901); A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A_fn_class = fncls__1900d; tmp1 = fncls__1900d } else { tmp1 = fncls__1900 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1901, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_1925 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any; var root_1929 any = A_arbace_j2g_meta_A_const_57.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = A_arbace_j2g_meta_A_const_122.GetRawRoot__O(); var arg_1933 any; var root_1934 any = A_arbace_j2g_meta_A_const_59.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = data__0; if linked_1935 == nil { arg_1933 = ifn_1936.Invoke_O__O(arg_1937) } else { arg_1933 = linked_1935.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1934, arg_1937) }; if linked_1930 == nil { arg_1928 = ifn_1931.Invoke_O_O__O(arg_1932, arg_1933) } else { arg_1928 = linked_1930.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1929, arg_1932, arg_1933) }; if linked_1926 == nil { tmp3 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp3 = linked_1926.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1925, arg_1928) }; rs__2 = tmp2.Invoke_O__O(tmp3); var root_1902 any =


	A_arbace_j2g_meta_A_const_66.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any; var root_1907 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = lang.IFn_Cast(A_arbace_j2g_meta_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_meta_A_const_117, rs__2); if linked_1908 == nil { arg_1905 = ifn_1909.Invoke_O__O(arg_1910) } else { arg_1905 = linked_1908.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1907, arg_1910) }; var arg_1906 any; var tmp4 any = A_arbace_j2g_meta_A_const_121; var tmp5 any; var root_1916 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1918 lang.IFn; if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any; var root_1920 any = A_arbace_j2g_meta_A_const_78.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = A_arbace_j2g_meta_A_const_120; var arg_1924 any = rs__2; if linked_1921 == nil { arg_1919 = ifn_1922.Invoke_O_O__O(arg_1923, arg_1924) } else { arg_1919 = linked_1921.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1920, arg_1923, arg_1924) }; if linked_1917 == nil { tmp5 = ifn_1918.Invoke_O__O(arg_1919) } else { tmp5 = linked_1917.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1916, arg_1919) }; arg_1906 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_1903 == nil { return ifn_1904.Invoke_O_O__O(arg_1905, arg_1906) } else { return linked_1903.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1902, arg_1905, arg_1906) } }
//line :298:1
func A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A_New_O(p0 any) *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A) Ctor_O(c__data any) { t.F_data = c__data }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A) Invoke_O_O__O(self, s__849000337__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1899 any = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A_New_O_O_O(t.F_data, self, s__849000337__1); var tmp2 *jrt.Class; var fncls__1898 *jrt.Class = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A_fn_class; if fncls__1898 == nil { var fncls__1898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1899); A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A_fn_class = fncls__1898d; tmp2 = fncls__1898d } else { tmp2 = fncls__1898 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1899, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :298:1
func A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A) Ctor_O_O_O(c__data, c__iter__849000336, c__s__849000337 any) { t.F_data = c__data; t.F_iter__849000336 = c__iter__849000336; t.F_s__849000337 = c__s__849000337 }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A) Invoke_O__O(self any) any { { var s__849000337__1 any; var t_ any = t.F_s__849000337; t.F_s__849000337 = nil; s__849000337__1 = t_; for { var temp__1927000414__auto____2 any; var root_1818 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = s__849000337__1; if linked_1819 == nil { temp__1927000414__auto____2 = ifn_1820.Invoke_O__O(arg_1821) } else { temp__1927000414__auto____2 = linked_1819.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1818, arg_1821) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000337__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1822 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = s__849000337__3; if linked_1823 == nil { tmp1 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp1 = linked_1823.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1822, arg_1825) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1826 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = s__849000337__3; if linked_1827 == nil { c__1927001037__auto____4 = ifn_1828.Invoke_O__O(arg_1829) } else { c__1927001037__auto____4 = linked_1827.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1826, arg_1829) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000339__6 any; var root_1830 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1831 == nil { b__849000339__6 = ifn_1832.Invoke_O__O(arg_1833) } else { b__849000339__6 = linked_1831.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1830, arg_1833) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1851 any = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A_New_O_I_O_O(t.F_data, size__1927001038__auto____5, c__1927001037__auto____4, b__849000339__6); var tmp3 *jrt.Class; var fncls__1850 *jrt.Class = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A_fn_class; if fncls__1850 == nil { var fncls__1850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1851); A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A_fn_class = fncls__1850d; tmp3 = fncls__1850d } else { tmp3 = fncls__1850 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1851, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1852 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any; var root_1857 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = b__849000339__6; if linked_1858 == nil { arg_1855 = ifn_1859.Invoke_O__O(arg_1860) } else { arg_1855 = linked_1858.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1857, arg_1860) }; var arg_1856 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000336); var tmp5 any; var root_1861 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = s__849000337__3; if linked_1862 == nil { tmp5 = ifn_1863.Invoke_O__O(arg_1864) } else { tmp5 = linked_1862.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1861, arg_1864) }; arg_1856 = tmp4.Invoke_O__O(tmp5); if linked_1853 == nil { return ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { return linked_1853.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) } } else { var root_1865 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any; var root_1870 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = b__849000339__6; if linked_1871 == nil { arg_1868 = ifn_1872.Invoke_O__O(arg_1873) } else { arg_1868 = linked_1871.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1870, arg_1873) }; var arg_1869 any; if linked_1866 == nil { return ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { return linked_1866.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) } } } else { var p__4 any; var root_1874 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = s__849000337__3; if linked_1875 == nil { p__4 = ifn_1876.Invoke_O__O(arg_1877) } else { p__4 = linked_1875.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1874, arg_1877) }; var root_1878 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1880 lang.IFn; if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__1893 any = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A_New_O_O(t.F_data, p__4); var tmp7 *jrt.Class; var fncls__1892 *jrt.Class = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A_fn_class
															if fncls__1892 == nil { var fncls__1892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__1893); A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A_fn_class = fncls__1892d; tmp7 = fncls__1892d } else { tmp7 = fncls__1892 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1893, tmp7, nil); arg_1881 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :298:1
	var arg_1882 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000336); var tmp9 any; var root_1894 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = s__849000337__3; if linked_1895 == nil { tmp9 = ifn_1896.Invoke_O__O(arg_1897) } else { tmp9 = linked_1895.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1894, arg_1897) }; arg_1882 = tmp8.Invoke_O__O(tmp9); if linked_1879 == nil { return ifn_1880.Invoke_O_O__O(arg_1881, arg_1882) } else { return linked_1879.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1878, arg_1881, arg_1882) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :298:1
func A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A) Ctor_O_I_O_O(c__data any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__849000339 any) { t.F_data = c__data; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__849000339 = c__b__849000339 }
//line :298:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A) Invoke_O__O(self any) any { { var i__849000338__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000338__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000338__1)); var root_1834 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = t.F_b__849000339; var arg_1838 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__1849 any = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A_New_O_O(t.F_data, p__2); var tmp3 *jrt.Class; var fncls__1848 *jrt.Class = A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A_fn_class
																	if fncls__1848 == nil { var fncls__1848d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__1849); A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A_fn_class = fncls__1848d; tmp3 = fncls__1848d } else { tmp3 = fncls__1848 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1849, tmp3, nil); arg_1838 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :298:1
	if linked_1835 == nil { ifn_1836.Invoke_O_O__O(arg_1837, arg_1838) } else { linked_1835.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1834, arg_1837, arg_1838) }; i__849000338__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000338__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A{}; t.Ctor_O_O(p0, p1); return t }
//line :299:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A) Ctor_O_O(c__data, c__p any) { t.F_data = c__data; t.F_p = c__p }
//line :299:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any = A_arbace_j2g_meta_A_const_117; var tmp3 any; var root_1839 any = A_arbace_j2g_meta_A_const_118.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, A_arbace_j2g_meta_metadata_roots_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = t.F_p; var arg_1843 any; var root_1844 any = A_arbace_j2g_meta_A_const_119.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, A_arbace_j2g_meta_read_json_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any; var tmp4 any; var t_ any = t.F_data; t.F_data = nil; tmp4 = t_; arg_1847 = lang.IFn_Cast(lang.RT_Get_O_O__O_NoInit(tmp4, t.F_p)).Invoke__O(); if linked_1845 == nil { arg_1843 = ifn_1846.Invoke_O__O(arg_1847) } else { arg_1843 = linked_1845.(*A_arbace_j2g_meta_read_json_A).Invoke_O_O__O(root_1844, arg_1847) }; if linked_1840 == nil { tmp3 = ifn_1841.Invoke_O_O__O(arg_1842, arg_1843) } else { tmp3 = linked_1840.(*A_arbace_j2g_meta_metadata_roots_A).Invoke_O_O_O__O(root_1839, arg_1842, arg_1843) }; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any = A_arbace_j2g_meta_A_const_120; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, e__3.GetMessage__String().Ref()))) } else { panic(tmp5) } }; return tmp1 }
//line :299:1
func A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A{}; t.Ctor_O_O(p0, p1); return t }
//line :299:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A) Ctor_O_O(c__data, c__p any) { t.F_data = c__data; t.F_p = c__p }
//line :299:1
func (t *A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any = A_arbace_j2g_meta_A_const_117; var tmp3 any; var root_1883 any = A_arbace_j2g_meta_A_const_118.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, A_arbace_j2g_meta_metadata_roots_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = t.F_p; var arg_1887 any; var root_1888 any = A_arbace_j2g_meta_A_const_119.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, A_arbace_j2g_meta_read_json_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any; var tmp4 any; var t_ any = t.F_data; t.F_data = nil; tmp4 = t_; arg_1891 = lang.IFn_Cast(lang.RT_Get_O_O__O_NoInit(tmp4, t.F_p)).Invoke__O(); if linked_1889 == nil { arg_1887 = ifn_1890.Invoke_O__O(arg_1891) } else { arg_1887 = linked_1889.(*A_arbace_j2g_meta_read_json_A).Invoke_O_O__O(root_1888, arg_1891) }; if linked_1884 == nil { tmp3 = ifn_1885.Invoke_O_O__O(arg_1886, arg_1887) } else { tmp3 = linked_1884.(*A_arbace_j2g_meta_metadata_roots_A).Invoke_O_O_O__O(root_1883, arg_1886, arg_1887) }; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any = A_arbace_j2g_meta_A_const_120; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, e__3.GetMessage__String().Ref()))) } else { panic(tmp5) } }; return tmp1 }






func A_arbace_j2g_meta_const_string_A_New() *A_arbace_j2g_meta_const_string_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_const_string_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_j2g_meta_const_string_A) Ctor() {}
//line :306:1
func (t *A_arbace_j2g_meta_const_string_A) Invoke_O_O__O(self, x__0 any) any { var x__2 any; var root_1938 any = A_arbace_j2g_meta_A_const_123.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_1940 lang.IFn; if
										linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = x__0; if linked_1939 == nil { x__2 = ifn_1940.Invoke_O__O(arg_1941) } else { x__2 = linked_1939.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_1938, arg_1941) }; var tmp1 any; var and__1927000168__auto____3 any; var root_1942 any =
										A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = x__2; if linked_1943 == nil { and__1927000168__auto____3 = ifn_1944.Invoke_O__O(arg_1945) } else { and__1927000168__auto____3 = linked_1943.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1942, arg_1945) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_j2g_meta_A_const_124; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_meta_A_const_125.Invoke_O__O(x__2)); if and__1927000168__auto____4 { var root_1946 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = A_arbace_j2g_meta_A_const_126.Invoke_O__O(x__2); if linked_1947 == nil { tmp1 = ifn_1948.Invoke_O__O(arg_1949) } else { tmp1 = linked_1947.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1946, arg_1949) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_meta_A_const_126.Invoke_O__O(x__2) } else { return nil } }

func A_arbace_j2g_meta_class_lit_binary_A_New() *A_arbace_j2g_meta_class_lit_binary_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_class_lit_binary_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_j2g_meta_class_lit_binary_A) Ctor() {}
//line :310:1
func (t *A_arbace_j2g_meta_class_lit_binary_A) Invoke_O_O__O(self, x__0 any) any { var x__2 any; var root_1950 any = A_arbace_j2g_meta_A_const_123.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_1952 lang.IFn; if
											linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = x__0; if linked_1951 == nil { x__2 = ifn_1952.Invoke_O__O(arg_1953) } else { x__2 = linked_1951.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_1950, arg_1953) }; var tmp1 any; var and__1927000168__auto____3 any; var root_1954 any =
											A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = x__2; if linked_1955 == nil { and__1927000168__auto____3 = ifn_1956.Invoke_O__O(arg_1957) } else { and__1927000168__auto____3 = linked_1955.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1954, arg_1957) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_j2g_meta_A_const_127; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_meta_A_const_125.Invoke_O__O(x__2)); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_1958 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = A_arbace_j2g_meta_A_const_128.Invoke_O__O(x__2); if linked_1959 == nil { and__1927000168__auto____5 = ifn_1960.Invoke_O__O(arg_1961) } else { and__1927000168__auto____5 = linked_1959.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1958, arg_1961) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1962 any = A_arbace_j2g_meta_A_const_53.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = A_arbace_j2g_meta_A_const_128.Invoke_O__O(x__2); var arg_1966 any = Lit_7; if linked_1963 == nil { tmp1 = ifn_1964.Invoke_O_O__O(arg_1965, arg_1966) } else { tmp1 = linked_1963.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1962, arg_1965, arg_1966) } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
												var root_1967 any = A_arbace_j2g_meta_A_const_75.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any; var root_1973 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1973, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1975 lang.IFn; if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any = A_arbace_j2g_meta_A_const_128.Invoke_O__O(x__2); var arg_1977 any = A_arbace_j2g_meta_A_const_129; var arg_1978 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_meta_A_const_128.Invoke_O__O(x__2))))).Ref(); if linked_1974 == nil { arg_1970 = ifn_1975.Invoke_O_O_O__O(arg_1976, arg_1977, arg_1978) } else { arg_1970 = linked_1974.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1973, arg_1976, arg_1977, arg_1978) }; var arg_1971 any = Lit_8; var arg_1972 any = Lit_9; if linked_1968 == nil { return ifn_1969.Invoke_O_O_O__O(arg_1970, arg_1971, arg_1972) } else { return linked_1968.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1967, arg_1970, arg_1971, arg_1972) } } else {
//line :312:1
			return nil } }

















func A_arbace_j2g_meta_site_roots_A_New() *A_arbace_j2g_meta_site_roots_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_site_roots_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_j2g_meta_site_roots_A) Ctor() {}
//line :330:1
func (t *A_arbace_j2g_meta_site_roots_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any; var root_1979 any = A_arbace_j2g_meta_A_const_123.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_1981 lang.IFn; if






	linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = node__0; if linked_1980 == nil { node__2 = ifn_1981.Invoke_O__O(arg_1982) } else { node__2 = linked_1980.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_1979, arg_1982) }; var tmp1 any; var and__1927000168__auto____3 any; var root_1983 any =
	A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = node__2; if linked_1984 == nil { and__1927000168__auto____3 = ifn_1985.Invoke_O__O(arg_1986) } else { and__1927000168__auto____3 = linked_1984.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1983, arg_1986) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 any = A_arbace_j2g_meta_A_const_130; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_meta_A_const_125.Invoke_O__O(node__2))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_meta_A_const_131.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_meta_A_const_139.Invoke_O__O(node__2), A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2)))
		if jrt.J2g_Truth(temp__1927000414__auto____3) { var k__4 any = temp__1927000414__auto____3; var vec__849000353__5 any = A_arbace_j2g_meta_A_const_132.Invoke_O__O(node__2); var a0__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000353__5, lang.RT_IntCast_J__I_NoInit(0), nil); var a1__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000353__5, lang.RT_IntCast_J__I_NoInit(1), nil); var cls__8 any; var root_1987 any = A_arbace_j2g_meta_A_const_133.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, A_arbace_j2g_meta_class_lit_binary_A_fn_class); var ifn_1989 lang.IFn

			if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = A_arbace_j2g_meta_A_const_134.Invoke_O__O(node__2); if linked_1988 == nil { cls__8 = ifn_1989.Invoke_O__O(arg_1990) } else { cls__8 = linked_1988.(*A_arbace_j2g_meta_class_lit_binary_A).Invoke_O_O__O(root_1987, arg_1990) }
//line :339:1
			var G__849000356__9_ any = k__4


			switch lang.Util_Hash_O__I_NoInit(G__849000356__9_) >> 6 & 7 { case 1: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_135) {





				if jrt.J2g_Truth(cls__8) { var tmp3 any = A_arbace_j2g_meta_A_const_141; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, cls__8, nil)).Ref())) } else { var tmp4 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_135), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } }
//line :342:1
			case 3: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_136) {




				if jrt.J2g_Truth(cls__8) { var tmp5 any = A_arbace_j2g_meta_A_const_141; return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, cls__8, nil)).Ref())) } else { var tmp6 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_135), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } }
//line :342:1
			case 4: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_128) { var temp__1927000408__auto____10 any; var root_1992 any = A_arbace_j2g_meta_A_const_137.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, A_arbace_j2g_meta_const_string_A_fn_class); var ifn_1994 lang.IFn
				if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = a0__6; if linked_1993 == nil { temp__1927000408__auto____10 = ifn_1994.Invoke_O__O(arg_1995) } else { temp__1927000408__auto____10 = linked_1993.(*A_arbace_j2g_meta_const_string_A).Invoke_O_O__O(root_1992, arg_1995) }; if jrt.J2g_Truth(temp__1927000408__auto____10) { var c__11 any = temp__1927000408__auto____10; var tmp7 any = A_arbace_j2g_meta_A_const_141; return lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, c__11, nil)).Ref())) } else { var tmp8 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_136), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } }
//line :342:1
			case 5: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_138) { var temp__1927000408__auto____10_2 any; var root_1996 any = A_arbace_j2g_meta_A_const_133.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, A_arbace_j2g_meta_class_lit_binary_A_fn_class); var ifn_1998 lang.IFn








				if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = a0__6; if linked_1997 == nil { temp__1927000408__auto____10_2 = ifn_1998.Invoke_O__O(arg_1999) } else { temp__1927000408__auto____10_2 = linked_1997.(*A_arbace_j2g_meta_class_lit_binary_A).Invoke_O_O__O(root_1996, arg_1999) }; if jrt.J2g_Truth(temp__1927000408__auto____10_2) { var c__11_2 any = temp__1927000408__auto____10_2; var tmp9 any = A_arbace_j2g_meta_A_const_141; return lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, c__11_2, nil)).Ref())) } else { var tmp10 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_137), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } }
//line :342:1
			case 6: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_143) { var c__10 any; var root_2000 any = A_arbace_j2g_meta_A_const_133.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, A_arbace_j2g_meta_class_lit_binary_A_fn_class); var ifn_2002 lang.IFn






				if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = a0__6; if linked_2001 == nil { c__10 = ifn_2002.Invoke_O__O(arg_2003) } else { c__10 = linked_2001.(*A_arbace_j2g_meta_class_lit_binary_A).Invoke_O_O__O(root_2000, arg_2003) }
//line :342:1
				var m__11 any; var root_2004 any = A_arbace_j2g_meta_A_const_137.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, A_arbace_j2g_meta_const_string_A_fn_class); var ifn_2006 lang.IFn






				if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = a1__7; if linked_2005 == nil { m__11 = ifn_2006.Invoke_O__O(arg_2007) } else { m__11 = linked_2005.(*A_arbace_j2g_meta_const_string_A).Invoke_O_O__O(root_2004, arg_2007) }
				var tmp11 any; var and__1927000168__auto____12 any = c__10; if jrt.J2g_Truth(and__1927000168__auto____12) { tmp11 = m__11 } else { tmp11 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp11) { var tmp12 any = A_arbace_j2g_meta_A_const_141; return lang.Tuple_Create_O_O__IPersistentVector(tmp12, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, c__10, nil, m__11)).Ref())) } else { var tmp13 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } }
//line :342:1
			case 7: if any(G__849000356__9_) == any(A_arbace_j2g_meta_A_const_144) {

				var tmp14 any; var and__1927000168__auto____10 any = cls__8; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2008 any = A_arbace_j2g_meta_A_const_137.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, A_arbace_j2g_meta_const_string_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = a0__6; if linked_2009 == nil { tmp14 = ifn_2010.Invoke_O__O(arg_2011) } else { tmp14 = linked_2009.(*A_arbace_j2g_meta_const_string_A).Invoke_O_O__O(root_2008, arg_2011) } } else { tmp14 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp14) { var tmp15 any = A_arbace_j2g_meta_A_const_141; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil); var tmp17 any; var root_2012 any = A_arbace_j2g_meta_A_const_137.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, A_arbace_j2g_meta_const_string_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = a0__6; if linked_2013 == nil { tmp17 = ifn_2014.Invoke_O__O(arg_2015) } else { tmp17 = linked_2013.(*A_arbace_j2g_meta_const_string_A).Invoke_O_O__O(root_2012, arg_2015) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, cls__8, nil, tmp17)).Ref())) } else { if jrt.J2g_Truth(cls__8) { var tmp18 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_139, nil, Lit_140), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil, cls__8, nil)).Ref()) } else { if A_arbace_j2g_meta_A_const_48 != nil { var tmp19 any = A_arbace_j2g_meta_A_const_142; return lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_135), jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_meta_A_const_140.Invoke_O__O(node__2), nil)).Ref()) } else { return nil } } } }
//line :342:1
			default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_141, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__849000356__9_))))) } else {
//line :339:1
				return nil } } else {
//line :338:1
					return nil } }














func A_arbace_j2g_meta_reflective_sites_A_New() *A_arbace_j2g_meta_reflective_sites_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_j2g_meta_reflective_sites_A) Ctor() {}
//line :353:1
func (t *A_arbace_j2g_meta_reflective_sites_A) Invoke_O_O__O(self, ns__0 any) any { var hits__2 any; var iter__1927001039__auto____2 any; var fnbody__2168 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A_New(); var tmp1 *jrt.Class; var fncls__2167 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A_fn_class; if



	fncls__2167 == nil { var fncls__2167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A_fn_class = fncls__2167d; tmp1 = fncls__2167d } else { tmp1 = fncls__2167 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2168, tmp1, nil); hits__2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ns__0); var tmp2 any = A_arbace_j2g_meta_A_const_141; var tmp3 any; var root_2169 any = /*line :353:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2171 lang.IFn; if













	linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any; var root_2173 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any; var iter__1927001039__auto____3 any; var fnbody__2271 any = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A_New(); var tmp4 *jrt.Class; var fncls__2270 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A_fn_class; if fncls__2270 == nil { var fncls__2270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A_fn_class = fncls__2270d; tmp4 = fncls__2270d } else { tmp4 = fncls__2270 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2271, tmp4, nil); arg_2176 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hits__2); if linked_2174 == nil { arg_2172 = ifn_2175.Invoke_O__O(arg_2176) } else { arg_2172 = linked_2174.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2173, arg_2176) }; if linked_2170 == nil { tmp3 = ifn_2171.Invoke_O__O(arg_2172) } else { tmp3 = linked_2170.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2169, arg_2172) }; var tmp5 any = tmp3; var tmp6 any = A_arbace_j2g_meta_A_const_142; var tmp7 any; var root_2272 any = /*line :353:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2274 lang.IFn; if














	linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any; var root_2276 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any; var iter__1927001039__auto____3_2 any; var fnbody__2345 any = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A_New(); var tmp8 *jrt.Class; var fncls__2344 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A_fn_class; if fncls__2344 == nil { var fncls__2344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A_fn_class = fncls__2344d; tmp8 = fncls__2344d } else { tmp8 = fncls__2344 }; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2345, tmp8, nil); arg_2279 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(hits__2); if linked_2277 == nil { arg_2275 = ifn_2278.Invoke_O__O(arg_2279) } else { arg_2275 = linked_2277.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2276, arg_2279) }; if linked_2273 == nil { tmp7 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp7 = linked_2273.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2272, arg_2275) }; return /*line :353:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp7)) }



func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A_New() *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A) Ctor() {}
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A) Invoke_O_O__O(self, s__849000360__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2166 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A_New_O_O(s__849000360__1, self); var tmp2 *jrt.Class; var fncls__2165 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A_fn_class; if fncls__2165 == nil { var fncls__2165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__2166); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A_fn_class = fncls__2165d; tmp2 = fncls__2165d } else { tmp2 = fncls__2165 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2166, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :357:1
func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A{}; t.Ctor_O_O(p0, p1); return t }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A) Ctor_O_O(c__s__849000360, c__iter__849000359 any) { t.F_s__849000360 = c__s__849000360; t.F_iter__849000359 = c__iter__849000359 }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A) Invoke_O__O(self any) any { { var s__849000360__1 any; var t_ any = t.F_s__849000360; t.F_s__849000360 = nil; s__849000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2016 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = s__849000360__1; if linked_2017 == nil { temp__1927000414__auto____2 = ifn_2018.Invoke_O__O(arg_2019) } else { temp__1927000414__auto____2 = linked_2017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2016, arg_2019) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_2020 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = xs__1927001018__auto____3; if linked_2021 == nil { n__4 = ifn_2022.Invoke_O__O(arg_2023) } else { n__4 = linked_2021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2020, arg_2023) }; var d__5 any; var root_2024 any = A_arbace_j2g_meta_A_const_145.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2026 lang.IFn
															if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = n__4; if linked_2025 == nil { d__5 = ifn_2026.Invoke_O__O(arg_2027) } else { d__5 = linked_2025.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2024, arg_2027) }
//line :357:1
	if jrt.J2g_Truth(d__5) { var st__6 any; var root_2028 any = A_arbace_j2g_meta_A_const_9.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = A_arbace_j2g_meta_A_const_146.Invoke_O__O(d__5); if linked_2029 == nil { st__6 = ifn_2030.Invoke_O__O(arg_2031) } else { st__6 = linked_2029.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2028, arg_2031) }; var tmp1 any; var and__1927000168__auto____7 any = A_arbace_j2g_meta_A_const_147.Invoke_O__O(st__6)



		if jrt.J2g_Truth(and__1927000168__auto____7) { var root_2032 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = A_arbace_j2g_meta_A_const_148.Invoke_O__O(st__6); if linked_2033 == nil { tmp1 = ifn_2034.Invoke_O__O(arg_2035) } else { tmp1 = linked_2033.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2032, arg_2035) } } else { tmp1 = and__1927000168__auto____7 }
//line :357:1
		if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____7 any; var fnbody__2113 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__2112 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A_fn_class; if fncls__2112 == nil { var fncls__2112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__2113); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A_fn_class = fncls__2112d; tmp2 = fncls__2112d } else { tmp2 = fncls__2112 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2113, tmp2, nil); var fs__1927001036__auto____8 any; var root_2114 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp4 any; var root_2118 any = A_arbace_j2g_meta_A_const_150.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_2120 lang.IFn




			if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any; var root_2124 any = A_arbace_j2g_meta_A_const_151.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_some_fn_A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var arg_2128 any = A_arbace_j2g_meta_A_const_152.GetRawRoot__O(); var arg_2129 any = A_arbace_j2g_meta_A_const_153.GetRawRoot__O(); if linked_2125 == nil { arg_2121 = ifn_2126.Invoke_O_O_O__O(arg_2127, arg_2128, arg_2129) } else { arg_2121 = linked_2125.(*aot_arbace_core.A_arbace_core_some_fn_A).Invoke_O_O_O_O__O(root_2124, arg_2127, arg_2128, arg_2129) }; var arg_2122 any; var fnbody__2143 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A_New(); var tmp5 *jrt.Class; var fncls__2142 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A_fn_class; if fncls__2142 == nil { var fncls__2142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A_fn_class = fncls__2142d; tmp5 = fncls__2142d } else { tmp5 = fncls__2142 }; arg_2122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2143, tmp5, nil); var arg_2123 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_j2g_meta_A_const_154.Invoke_O__O(st__6), A_arbace_j2g_meta_A_const_155.Invoke_O__O(st__6), A_arbace_j2g_meta_A_const_156.Invoke_O__O(st__6)); if linked_2119 == nil { tmp4 = ifn_2120.Invoke_O_O_O__O(arg_2121, arg_2122, arg_2123) } else { tmp4 = linked_2119.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_2118, arg_2121, arg_2122, arg_2123) }
//line :357:1
			arg_2117 = tmp3.Invoke_O__O(tmp4); if linked_2115 == nil { fs__1927001036__auto____8 = ifn_2116.Invoke_O__O(arg_2117) } else { fs__1927001036__auto____8 = linked_2115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2114, arg_2117) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2144 any = A_arbace_j2g_meta_A_const_74.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = fs__1927001036__auto____8; var arg_2148 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000359); var tmp7 any; var root_2149 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2151 lang.IFn; if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = s__849000360__1; if linked_2150 == nil { tmp7 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp7 = linked_2150.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2149, arg_2152) }; arg_2148 = tmp6.Invoke_O__O(tmp7); if linked_2145 == nil { return ifn_2146.Invoke_O_O__O(arg_2147, arg_2148) } else { return linked_2145.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2144, arg_2147, arg_2148) } } else { var tmp8 any; var root_2153 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = s__849000360__1; if linked_2154 == nil { tmp8 = ifn_2155.Invoke_O__O(arg_2156) } else { tmp8 = linked_2154.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2153, arg_2156) }; s__849000360__1 = tmp8; continue L1 } } else { var tmp9 any; var root_2157 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = s__849000360__1; if linked_2158 == nil { tmp9 = ifn_2159.Invoke_O__O(arg_2160) } else { tmp9 = linked_2158.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2157, arg_2160) }; s__849000360__1 = tmp9; continue L1 } } else { var tmp10 any; var root_2161 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = s__849000360__1; if linked_2162 == nil { tmp10 = ifn_2163.Invoke_O__O(arg_2164) } else { tmp10 = linked_2162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2161, arg_2164) }; s__849000360__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :357:1
func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A_New_O(p0 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A) Invoke_O_O__O(self, s__849000362__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2111 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A_New_O_O_O(self, s__849000362__1, t.F_n); var tmp2 *jrt.Class; var fncls__2110 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A_fn_class; if fncls__2110 == nil { var fncls__2110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__2111); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A_fn_class = fncls__2110d; tmp2 = fncls__2110d } else { tmp2 = fncls__2110 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2111, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :357:1
func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A) Ctor_O_O_O(c__iter__849000361, c__s__849000362, c__n any) { t.F_iter__849000361 = c__iter__849000361; t.F_s__849000362 = c__s__849000362; t.F_n = c__n }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A) Invoke_O__O(self any) any { { var s__849000362__1 any; var t_ any = t.F_s__849000362; t.F_s__849000362 = nil; s__849000362__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2036 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = s__849000362__1; if linked_2037 == nil { temp__1927000414__auto____2 = ifn_2038.Invoke_O__O(arg_2039) } else { temp__1927000414__auto____2 = linked_2037.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2036, arg_2039) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000362__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2040 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = s__849000362__3; if linked_2041 == nil { tmp1 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp1 = linked_2041.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2040, arg_2043) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2044 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = s__849000362__3; if linked_2045 == nil { c__1927001037__auto____4 = ifn_2046.Invoke_O__O(arg_2047) } else { c__1927001037__auto____4 = linked_2045.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2044, arg_2047) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000364__6 any; var root_2048 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2049 == nil { b__849000364__6 = ifn_2050.Invoke_O__O(arg_2051) } else { b__849000364__6 = linked_2049.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2048, arg_2051) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2064 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A_New_O_O_I_O(t.F_n, b__849000364__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2063 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A_fn_class; if fncls__2063 == nil { var fncls__2063d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__2064); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A_fn_class = fncls__2063d; tmp3 = fncls__2063d } else { tmp3 = fncls__2063 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2064, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2065 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any; var root_2070 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = b__849000364__6; if linked_2071 == nil { arg_2068 = ifn_2072.Invoke_O__O(arg_2073) } else { arg_2068 = linked_2071.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2070, arg_2073) }; var arg_2069 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000361); var tmp5 any; var root_2074 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = s__849000362__3; if linked_2075 == nil { tmp5 = ifn_2076.Invoke_O__O(arg_2077) } else { tmp5 = linked_2075.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2074, arg_2077) }; arg_2069 = tmp4.Invoke_O__O(tmp5); if linked_2066 == nil { return ifn_2067.Invoke_O_O__O(arg_2068, arg_2069) } else { return linked_2066.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2065, arg_2068, arg_2069) } } else { var root_2078 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any; var root_2083 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = b__849000364__6; if linked_2084 == nil { arg_2081 = ifn_2085.Invoke_O__O(arg_2086) } else { arg_2081 = linked_2084.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2083, arg_2086) }; var arg_2082 any; if linked_2079 == nil { return ifn_2080.Invoke_O_O__O(arg_2081, arg_2082) } else { return linked_2079.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2078, arg_2081, arg_2082) } } } else { var node__4 any; var root_2087 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = s__849000362__3; if linked_2088 == nil { node__4 = ifn_2089.Invoke_O__O(arg_2090) } else { node__4 = linked_2088.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2087, arg_2090) }; var r__5 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__2096 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A_New_O(node__4); var tmp7 *jrt.Class
																				var fncls__2095 /*line :357:1*/*jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A_fn_class






	if fncls__2095 == nil { var fncls__2095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__2096); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A_fn_class = fncls__2095d; tmp7 = fncls__2095d } else { tmp7 = fncls__2095 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2096, tmp7, nil); r__5 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :357:1
	if jrt.J2g_Truth(r__5) { var root_2097 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_n, r__5); var arg_2101 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000361); var tmp9 any; var root_2102 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = s__849000362__3; if linked_2103 == nil { tmp9 = ifn_2104.Invoke_O__O(arg_2105) } else { tmp9 = linked_2103.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2102, arg_2105) }; arg_2101 = tmp8.Invoke_O__O(tmp9); if linked_2098 == nil { return ifn_2099.Invoke_O_O__O(arg_2100, arg_2101) } else { return linked_2098.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2097, arg_2100, arg_2101) } } else { var tmp10 any; var root_2106 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = s__849000362__3; if linked_2107 == nil { tmp10 = ifn_2108.Invoke_O__O(arg_2109) } else { tmp10 = linked_2107.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2106, arg_2109) }; s__849000362__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :357:1
func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A) Ctor_O_O_I_O(c__n, c__b__849000364 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__849000364 = c__b__849000364; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :357:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A) Invoke_O__O(self any) any { { var i__849000363__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000363__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var node__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000363__1)); var r__3 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__2057 any = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A_New_O(node__2); var tmp3 *jrt.Class
																						var fncls__2056 /*line :357:1*/*jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A_fn_class






	if fncls__2056 == nil { var fncls__2056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__2057); A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A_fn_class = fncls__2056d; tmp3 = fncls__2056d } else { tmp3 = fncls__2056 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2057, tmp3, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :357:1
	if jrt.J2g_Truth(r__3) { var root_2058 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = t.F_b__849000364; var arg_2062 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_n, r__3); if linked_2059 == nil { ifn_2060.Invoke_O_O__O(arg_2061, arg_2062) } else { linked_2059.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2058, arg_2061, arg_2062) }; i__849000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000363__1); continue L1 } else { i__849000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000363__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A_New() *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A) Ctor() {}
//line :362:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A) Invoke_O_O__O(self, p1__849000358_SHARP___1 any) any { var tmp1 any; var root_2130 any = A_arbace_j2g_meta_A_const_107.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = p1__849000358_SHARP___1; if linked_2131 == nil { tmp1 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp1 = linked_2131.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2130, arg_2133) }; if jrt.J2g_Truth(tmp1) { var root_2134 any = A_arbace_j2g_meta_A_const_67.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = p1__849000358_SHARP___1; if linked_2135 == nil { return ifn_2136.Invoke_O__O(arg_2137) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2134, arg_2137) } } else { var root_2138 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = p1__849000358_SHARP___1; if linked_2139 == nil { return ifn_2140.Invoke_O__O(arg_2141) } else { return linked_2139.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2138, arg_2141) } } }

func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A_New_O(p0 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A) Ctor_O(c__node any) { t.F_node = c__node }
//line :364:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2052 any = A_arbace_j2g_meta_A_const_149.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, A_arbace_j2g_meta_site_roots_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any; var t_ any = t.F_node; t.F_node = nil; arg_2055 = t_; if linked_2053 == nil { tmp1 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp1 = linked_2053.(*A_arbace_j2g_meta_site_roots_A).Invoke_O_O__O(root_2052, arg_2055) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :364:1
func A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A_New_O(p0 any) *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A) Ctor_O(c__node any) { t.F_node = c__node }
//line :364:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2091 any = A_arbace_j2g_meta_A_const_149.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, A_arbace_j2g_meta_site_roots_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any; var t_ any = t.F_node; t.F_node = nil; arg_2094 = t_; if linked_2092 == nil { tmp1 = ifn_2093.Invoke_O__O(arg_2094) } else { tmp1 = linked_2092.(*A_arbace_j2g_meta_site_roots_A).Invoke_O_O__O(root_2091, arg_2094) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }


func A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A_New() *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A) Ctor() {}
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A) Invoke_O_O__O(self, s__849000382__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2269 any = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A_New_O_O(self, s__849000382__1); var tmp2 *jrt.Class; var fncls__2268 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A_fn_class; if fncls__2268 == nil { var fncls__2268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__2269); A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A_fn_class = fncls__2268d; tmp2 = fncls__2268d } else { tmp2 = fncls__2268 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2269, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :367:1
func A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A{}; t.Ctor_O_O(p0, p1); return t }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A) Ctor_O_O(c__iter__849000381, c__s__849000382 any) { t.F_iter__849000381 = c__iter__849000381; t.F_s__849000382 = c__s__849000382 }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A) Invoke_O__O(self any) any { { var s__849000382__1 any; var t_ any = t.F_s__849000382; t.F_s__849000382 = nil; s__849000382__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2177 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = s__849000382__1; if linked_2178 == nil { temp__1927000414__auto____2 = ifn_2179.Invoke_O__O(arg_2180) } else { temp__1927000414__auto____2 = linked_2178.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2177, arg_2180) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__849000389__4 any; var root_2181 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = xs__1927001018__auto____3; if linked_2182 == nil { vec__849000389__4 = ifn_2183.Invoke_O__O(arg_2184) } else { vec__849000389__4 = linked_2182.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2181, arg_2184) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000389__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__849000392__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000389__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000392__6, lang.RT_IntCast_J__I_NoInit(0), nil); var specs__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000392__6, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_j2g_meta_A_const_141) { var iterys__1927001035__auto____9 any; var fnbody__2246 any = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A_New_O(n__5); var tmp1 *jrt.Class; var fncls__2245 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A_fn_class; if fncls__2245 == nil { var fncls__2245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__2246); A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A_fn_class = fncls__2245d; tmp1 = fncls__2245d } else { tmp1 = fncls__2245 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2246, tmp1, nil); var fs__1927001036__auto____10 any; var root_2247 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(specs__8); if linked_2248 == nil { fs__1927001036__auto____10 = ifn_2249.Invoke_O__O(arg_2250) } else { fs__1927001036__auto____10 = linked_2248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2247, arg_2250) }; if jrt.J2g_Truth(fs__1927001036__auto____10) { var root_2251 any = A_arbace_j2g_meta_A_const_74.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2251, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = fs__1927001036__auto____10; var arg_2255 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__849000381); var tmp3 any; var root_2256 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = s__849000382__1; if linked_2257 == nil { tmp3 = ifn_2258.Invoke_O__O(arg_2259) } else { tmp3 = linked_2257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2256, arg_2259) }; arg_2255 = tmp2.Invoke_O__O(tmp3); if linked_2252 == nil { return ifn_2253.Invoke_O_O__O(arg_2254, arg_2255) } else { return linked_2252.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2251, arg_2254, arg_2255) } } else { var tmp4 any; var root_2260 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = s__849000382__1; if linked_2261 == nil { tmp4 = ifn_2262.Invoke_O__O(arg_2263) } else { tmp4 = linked_2261.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2260, arg_2263) }; s__849000382__1 = tmp4; continue L1 } } else { var tmp5 any; var root_2264 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = s__849000382__1; if linked_2265 == nil { tmp5 = ifn_2266.Invoke_O__O(arg_2267) } else { tmp5 = linked_2265.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2264, arg_2267) }; s__849000382__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :367:1
func A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A_New_O(p0 any) *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A{}; t.Ctor_O(p0); return t }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A) Invoke_O_O__O(self, s__849000384__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2244 any = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A_New_O_O_O(self, s__849000384__1, t.F_n); var tmp2 *jrt.Class; var fncls__2243 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A_fn_class; if fncls__2243 == nil { var fncls__2243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__2244); A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A_fn_class = fncls__2243d; tmp2 = fncls__2243d } else { tmp2 = fncls__2243 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2244, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :367:1
func A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A) Ctor_O_O_O(c__iter__849000383, c__s__849000384, c__n any) { t.F_iter__849000383 = c__iter__849000383; t.F_s__849000384 = c__s__849000384; t.F_n = c__n }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A) Invoke_O__O(self any) any { { var s__849000384__1 any; var t_ any = t.F_s__849000384; t.F_s__849000384 = nil; s__849000384__1 = t_; for { var temp__1927000414__auto____2 any; var root_2185 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = s__849000384__1; if linked_2186 == nil { temp__1927000414__auto____2 = ifn_2187.Invoke_O__O(arg_2188) } else { temp__1927000414__auto____2 = linked_2186.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2185, arg_2188) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000384__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2189 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = s__849000384__3; if linked_2190 == nil { tmp1 = ifn_2191.Invoke_O__O(arg_2192) } else { tmp1 = linked_2190.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2189, arg_2192) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2193 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = s__849000384__3; if linked_2194 == nil { c__1927001037__auto____4 = ifn_2195.Invoke_O__O(arg_2196) } else { c__1927001037__auto____4 = linked_2194.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2193, arg_2196) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000386__6 any; var root_2197 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2198 == nil { b__849000386__6 = ifn_2199.Invoke_O__O(arg_2200) } else { b__849000386__6 = linked_2198.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2197, arg_2200) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2207 any = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A_New_O_O_I_O(t.F_n, b__849000386__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2206 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A_fn_class; if fncls__2206 == nil { var fncls__2206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__2207); A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A_fn_class = fncls__2206d; tmp3 = fncls__2206d } else { tmp3 = fncls__2206 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2207, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2208 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any; var root_2213 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any = b__849000386__6; if linked_2214 == nil { arg_2211 = ifn_2215.Invoke_O__O(arg_2216) } else { arg_2211 = linked_2214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2213, arg_2216) }; var arg_2212 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000383); var tmp5 any; var root_2217 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = s__849000384__3; if linked_2218 == nil { tmp5 = ifn_2219.Invoke_O__O(arg_2220) } else { tmp5 = linked_2218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2217, arg_2220) }; arg_2212 = tmp4.Invoke_O__O(tmp5); if linked_2209 == nil { return ifn_2210.Invoke_O_O__O(arg_2211, arg_2212) } else { return linked_2209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2208, arg_2211, arg_2212) } } else { var root_2221 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any; var root_2226 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = b__849000386__6; if linked_2227 == nil { arg_2224 = ifn_2228.Invoke_O__O(arg_2229) } else { arg_2224 = linked_2227.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2226, arg_2229) }; var arg_2225 any; if linked_2222 == nil { return ifn_2223.Invoke_O_O__O(arg_2224, arg_2225) } else { return linked_2222.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2221, arg_2224, arg_2225) } } } else { var s__4 any; var root_2230 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = s__849000384__3; if linked_2231 == nil { s__4 = ifn_2232.Invoke_O__O(arg_2233) } else { s__4 = linked_2231.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2230, arg_2233) }; var root_2234 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_n, s__4); var arg_2238 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000383); var tmp7 any; var root_2239 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = s__849000384__3; if linked_2240 == nil { tmp7 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp7 = linked_2240.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2239, arg_2242) }; arg_2238 = tmp6.Invoke_O__O(tmp7); if linked_2235 == nil { return ifn_2236.Invoke_O_O__O(arg_2237, arg_2238) } else { return linked_2235.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2234, arg_2237, arg_2238) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :367:1
func A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A) Ctor_O_O_I_O(c__n, c__b__849000386 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__849000386 = c__b__849000386; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :367:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A) Invoke_O__O(self any) any { { var i__849000385__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000385__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000385__1)); var root_2201 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2203 lang.IFn; if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = t.F_b__849000386; var arg_2205 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_n, s__2); if linked_2202 == nil { ifn_2203.Invoke_O_O__O(arg_2204, arg_2205) } else { linked_2202.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2201, arg_2204, arg_2205) }; i__849000385__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000385__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A_New() *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A) Ctor() {}
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A) Invoke_O_O__O(self, s__849000404__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2343 any = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A_New_O_O(self, s__849000404__1); var tmp2 *jrt.Class; var fncls__2342 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A_fn_class; if fncls__2342 == nil { var fncls__2342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__2343); A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A_fn_class = fncls__2342d; tmp2 = fncls__2342d } else { tmp2 = fncls__2342 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2343, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :368:1
func A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A{}; t.Ctor_O_O(p0, p1); return t }
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A) Ctor_O_O(c__iter__849000403, c__s__849000404 any) { t.F_iter__849000403 = c__iter__849000403; t.F_s__849000404 = c__s__849000404 }
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A) Invoke_O__O(self any) any { { var s__849000404__1 any; var t_ any = t.F_s__849000404; t.F_s__849000404 = nil; s__849000404__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2280 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = s__849000404__1; if linked_2281 == nil { temp__1927000414__auto____2 = ifn_2282.Invoke_O__O(arg_2283) } else { temp__1927000414__auto____2 = linked_2281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2280, arg_2283) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000404__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2284 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = s__849000404__3; if linked_2285 == nil { tmp1 = ifn_2286.Invoke_O__O(arg_2287) } else { tmp1 = linked_2285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2284, arg_2287) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2288 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = s__849000404__3; if linked_2289 == nil { c__1927001037__auto____4 = ifn_2290.Invoke_O__O(arg_2291) } else { c__1927001037__auto____4 = linked_2289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2288, arg_2291) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000406__6 any; var root_2292 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2293 == nil { b__849000406__6 = ifn_2294.Invoke_O__O(arg_2295) } else { b__849000406__6 = linked_2293.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2292, arg_2295) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2302 any = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__849000406__6); var tmp3 *jrt.Class; var fncls__2301 *jrt.Class = A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A_fn_class; if fncls__2301 == nil { var fncls__2301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__2302); A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A_fn_class = fncls__2301d; tmp3 = fncls__2301d } else { tmp3 = fncls__2301 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2302, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2303 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any; var root_2308 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = b__849000406__6; if linked_2309 == nil { arg_2306 = ifn_2310.Invoke_O__O(arg_2311) } else { arg_2306 = linked_2309.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2308, arg_2311) }; var arg_2307 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000403); var tmp5 any; var root_2312 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = s__849000404__3; if linked_2313 == nil { tmp5 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp5 = linked_2313.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2312, arg_2315) }; arg_2307 = tmp4.Invoke_O__O(tmp5); if linked_2304 == nil { return ifn_2305.Invoke_O_O__O(arg_2306, arg_2307) } else { return linked_2304.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2303, arg_2306, arg_2307) } } else { var root_2316 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any; var root_2321 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = b__849000406__6; if linked_2322 == nil { arg_2319 = ifn_2323.Invoke_O__O(arg_2324) } else { arg_2319 = linked_2322.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2321, arg_2324) }; var arg_2320 any; if linked_2317 == nil { return ifn_2318.Invoke_O_O__O(arg_2319, arg_2320) } else { return linked_2317.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2316, arg_2319, arg_2320) } } } else { var vec__849000417__4 any; var root_2325 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = s__849000404__3; if linked_2326 == nil { vec__849000417__4 = ifn_2327.Invoke_O__O(arg_2328) } else { vec__849000417__4 = linked_2326.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2325, arg_2328) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000417__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__849000420__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000417__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000420__6, lang.RT_IntCast_J__I_NoInit(0), nil); var what__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000420__6, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(k__7, A_arbace_j2g_meta_A_const_142) { var root_2329 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, what__8); var arg_2333 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__849000403); var tmp7 any; var root_2334 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = s__849000404__3; if linked_2335 == nil { tmp7 = ifn_2336.Invoke_O__O(arg_2337) } else { tmp7 = linked_2335.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2334, arg_2337) }; arg_2333 = tmp6.Invoke_O__O(tmp7); if linked_2330 == nil { return ifn_2331.Invoke_O_O__O(arg_2332, arg_2333) } else { return linked_2330.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2329, arg_2332, arg_2333) } } else { var tmp8 any; var root_2338 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = s__849000404__3; if linked_2339 == nil { tmp8 = ifn_2340.Invoke_O__O(arg_2341) } else { tmp8 = linked_2339.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2338, arg_2341) }; s__849000404__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :368:1
func A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__849000406 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__849000406 = c__b__849000406 }
//line :368:1
func (t *A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A) Invoke_O__O(self any) any { { var i__849000405__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000405__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000410__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000405__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000410__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__849000413__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000410__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000413__4, lang.RT_IntCast_J__I_NoInit(0), nil); var what__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000413__4, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(k__5, A_arbace_j2g_meta_A_const_142) { var root_2296 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = t.F_b__849000406; var arg_2300 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, what__6); if linked_2297 == nil { ifn_2298.Invoke_O_O__O(arg_2299, arg_2300) } else { linked_2297.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2296, arg_2299, arg_2300) }; i__849000405__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000405__1); continue L1 } else { i__849000405__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000405__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_meta_spec_class_A_New() *A_arbace_j2g_meta_spec_class_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_spec_class_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_j2g_meta_spec_class_A) Ctor() {}
//line :373:1
func (t *A_arbace_j2g_meta_spec_class_A) Invoke_O_O__O(self, spec__0 any) any {


	var root_2346 any = A_arbace_j2g_meta_A_const_76.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, A_arbace_j2g_meta_internal_A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any; var root_2350 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any; var root_2354 any = A_arbace_j2g_meta_A_const_40.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2356 lang.IFn; if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any = spec__0; var arg_2358 any = A_arbace_j2g_meta_A_const_157; var arg_2359 any = A_arbace_j2g_meta_A_const_158; if linked_2355 == nil { arg_2353 = ifn_2356.Invoke_O_O_O__O(arg_2357, arg_2358, arg_2359) } else { arg_2353 = linked_2355.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_2354, arg_2357, arg_2358, arg_2359) }; if linked_2351 == nil { arg_2349 = ifn_2352.Invoke_O__O(arg_2353) } else { arg_2349 = linked_2351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2350, arg_2353) }; if linked_2347 == nil { return ifn_2348.Invoke_O__O(arg_2349) } else { return linked_2347.(*A_arbace_j2g_meta_internal_A).Invoke_O_O__O(root_2346, arg_2349)
	} }
func A_arbace_j2g_meta_present_specs_A_New() *A_arbace_j2g_meta_present_specs_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_present_specs_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_j2g_meta_present_specs_A) Ctor() {}
//line :378:1
func (t *A_arbace_j2g_meta_present_specs_A) Invoke_O_O__O(self, specs__0 any) any { var g__2 any; var root_2360 any = A_arbace_j2g_meta_A_const_37.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2362 lang.IFn; if


	linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any; var fnbody__2374 any = A_arbace_j2g_meta_present_specs_fn__849000428_A_New(); var tmp1 *jrt.Class; var fncls__2373 *jrt.Class = A_arbace_j2g_meta_present_specs_fn__849000428_A_fn_class; if fncls__2373 == nil { var fncls__2373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_j2g_meta_present_specs_fn__849000428_A_fn_class = fncls__2373d; tmp1 = fncls__2373d } else { tmp1 = fncls__2373 }; arg_2363 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2374, tmp1, nil); var arg_2364 any = specs__0; if linked_2361 == nil { g__2 = ifn_2362.Invoke_O_O__O(arg_2363, arg_2364) } else { g__2 = linked_2361.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2360, arg_2363, arg_2364) }; var tmp2 any; var root_2375 any = /*line :378:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2377 lang.IFn; if



	linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any; var root_2379 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = lang.RT_Get_O_O__O_NoInit(g__2, jrt.Boolean_TRUE.Ref()); if linked_2380 == nil { arg_2378 = ifn_2381.Invoke_O__O(arg_2382) } else { arg_2378 = linked_2380.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2379, arg_2382) }; if linked_2376 == nil { tmp2 = ifn_2377.Invoke_O__O(arg_2378) } else { tmp2 = linked_2376.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2375, arg_2378) }; var tmp3 any = tmp2; var tmp4 any; var root_2383 any = /*line :378:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2385 lang.IFn; if



	linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var root_2387 any = A_arbace_j2g_meta_A_const_49.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = lang.RT_Get_O_O__O_NoInit(g__2, jrt.Boolean_FALSE.Ref()); if linked_2388 == nil { arg_2386 = ifn_2389.Invoke_O__O(arg_2390) } else { arg_2386 = linked_2388.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2387, arg_2390) }; if linked_2384 == nil { tmp4 = ifn_2385.Invoke_O__O(arg_2386) } else { tmp4 = linked_2384.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2383, arg_2386) }; return /*line :378:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) }


func A_arbace_j2g_meta_present_specs_fn__849000428_A_New() *A_arbace_j2g_meta_present_specs_fn__849000428_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_present_specs_fn__849000428_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_j2g_meta_present_specs_fn__849000428_A) Ctor() {}
//line :381:1
func (t *A_arbace_j2g_meta_present_specs_fn__849000428_A) Invoke_O_O__O(self, p1__849000427_SHARP___1 any) any { var tmp1 any; var root_2365 any = A_arbace_j2g_meta_A_const_145.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any; var root_2369 any = A_arbace_j2g_meta_A_const_159.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2369, A_arbace_j2g_meta_spec_class_A_fn_class); var ifn_2371 lang.IFn; if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = p1__849000427_SHARP___1; if linked_2370 == nil { arg_2368 = ifn_2371.Invoke_O__O(arg_2372) } else { arg_2368 = linked_2370.(*A_arbace_j2g_meta_spec_class_A).Invoke_O_O__O(root_2369, arg_2372) }; if linked_2366 == nil { tmp1 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp1 = linked_2366.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2365, arg_2368) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }





func A_arbace_j2g_meta_top_of_A_New() *A_arbace_j2g_meta_top_of_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_top_of_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_j2g_meta_top_of_A) Ctor() {}
//line :387:1
func (t *A_arbace_j2g_meta_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_142); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_2391 any = A_arbace_j2g_meta_A_const_45.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = n__0; var arg_2395 any = A_arbace_j2g_meta_A_const_46; var arg_2396 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_2392 == nil { return ifn_2393.Invoke_O_O_O__O(arg_2394, arg_2395, arg_2396) } else { return linked_2392.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2391, arg_2394, arg_2395, arg_2396) } } }

func A_arbace_j2g_meta_names_class_QMARK__A_New() *A_arbace_j2g_meta_names_class_QMARK__A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_names_class_QMARK__A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_j2g_meta_names_class_QMARK__A) Ctor() {}
//line :389:1
func (t *A_arbace_j2g_meta_names_class_QMARK__A) Invoke_O_O_O__O(self, why__0, n__1 any) any { var or__1927000174__auto____3 any; var root_2397 any = A_arbace_j2g_meta_A_const_160.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2399 lang.IFn; if


	linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = why__0; var arg_2401 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, n__1, nil)).Ref(); if linked_2398 == nil { or__1927000174__auto____3 = ifn_2399.Invoke_O_O__O(arg_2400, arg_2401) } else { or__1927000174__auto____3 = linked_2398.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2397, arg_2400, arg_2401) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_2402 any = A_arbace_j2g_meta_A_const_160.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = why__0; var arg_2406 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, nil, n__1, nil)).Ref(); if linked_2403 == nil { return ifn_2404.Invoke_O_O__O(arg_2405, arg_2406) } else { return linked_2403.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2402, arg_2405, arg_2406) } } }

func A_arbace_j2g_meta_refusals_A_New() *A_arbace_j2g_meta_refusals_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_j2g_meta_refusals_A) Ctor() {}
//line :394:1
func (t *A_arbace_j2g_meta_refusals_A) Invoke_O_O_O__O(self, failed__0, unavailable__1 any) any { var refused_tops__3 any; var root_2407 any = A_arbace_j2g_meta_A_const_161.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2409 lang.IFn; if






	linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any; var root_2411 any = A_arbace_j2g_meta_A_const_162.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any; var root_2416 any = A_arbace_j2g_meta_A_const_163.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2418 lang.IFn; if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = A_arbace_j2g_meta_A_const_164.GetRawRoot__O(); var arg_2420 any = A_arbace_j2g_meta_A_const_165.GetRawRoot__O(); if linked_2417 == nil { arg_2414 = ifn_2418.Invoke_O_O__O(arg_2419, arg_2420) } else { arg_2414 = linked_2417.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2416, arg_2419, arg_2420) }; var arg_2415 any = failed__0; if linked_2412 == nil { arg_2410 = ifn_2413.Invoke_O_O__O(arg_2414, arg_2415) } else { arg_2410 = linked_2412.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2411, arg_2414, arg_2415) }; if linked_2408 == nil { refused_tops__3 = ifn_2409.Invoke_O__O(arg_2410) } else { refused_tops__3 = linked_2408.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2407, arg_2410) }; var stubbed__4 any; var iter__1927001039__auto____4 any; var fnbody__2822 any = /*line :394:1*/A_arbace_j2g_meta_refusals_iter__849000434__849000438_A_New_O_O(refused_tops__3, unavailable__1); var tmp1 *jrt.Class; var fncls__2821 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_A_fn_class; if







	fncls__2821 == nil { var fncls__2821d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__2822); A_arbace_j2g_meta_refusals_iter__849000434__849000438_A_fn_class = fncls__2821d; tmp1 = fncls__2821d } else { tmp1 = fncls__2821 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2822, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_2918 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_2919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2918, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2920 lang.IFn; if linked_2919 == nil { ifn_2920 = lang.IFn_Cast(root_2918) } else { ifn_2920 = nil }; var arg_2921 any = failed__0; if linked_2919 == nil { tmp3 = ifn_2920.Invoke_O__O(arg_2921) } else { tmp3 = linked_2919.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2918, arg_2921) }; stubbed__4 = tmp2.Invoke_O__O(tmp3); var s__5 any; var root_2823 any = /*line :394:1*/A_arbace_j2g_meta_A_const_161.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2825 lang.IFn; if
















	linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any; var root_2827 any = A_arbace_j2g_meta_A_const_162.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2827, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2829 lang.IFn; if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var arg_2831 any = stubbed__4; if linked_2828 == nil { arg_2826 = ifn_2829.Invoke_O_O__O(arg_2830, arg_2831) } else { arg_2826 = linked_2828.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2827, arg_2830, arg_2831) }; if linked_2824 == nil { s__5 = ifn_2825.Invoke_O__O(arg_2826) } else { s__5 = linked_2824.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2823, arg_2826) }; var tmp4 any = A_arbace_j2g_meta_A_const_167; var tmp5 any; var root_2832 any = /*line :394:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2832, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2834 lang.IFn; if

















	linked_2833 == nil { ifn_2834 = lang.IFn_Cast(root_2832) } else { ifn_2834 = nil }; var arg_2835 any = stubbed__4; if linked_2833 == nil { tmp5 = ifn_2834.Invoke_O__O(arg_2835) } else { tmp5 = linked_2833.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2832, arg_2835) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_j2g_meta_A_const_168; var tmp8 any; var root_2836 any = /*line :394:1*/A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2836, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2838 lang.IFn; if


















	linked_2837 == nil { ifn_2838 = lang.IFn_Cast(root_2836) } else { ifn_2838 = nil }; var arg_2839 any; var iter__1927001039__auto____6 any; var fnbody__2913 any = A_arbace_j2g_meta_refusals_iter__849000490__849000494_A_New_O(s__5); var tmp9 *jrt.Class; var fncls__2912 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000490__849000494_A_fn_class; if fncls__2912 == nil { var fncls__2912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__2913); A_arbace_j2g_meta_refusals_iter__849000490__849000494_A_fn_class = fncls__2912d; tmp9 = fncls__2912d } else { tmp9 = fncls__2912 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2913, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp11 any; var root_2914 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = failed__0; if linked_2915 == nil { tmp11 = ifn_2916.Invoke_O__O(arg_2917) } else { tmp11 = linked_2915.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2914, arg_2917) }; arg_2839 = tmp10.Invoke_O__O(tmp11); if linked_2837 == nil { tmp8 = ifn_2838.Invoke_O__O(arg_2839) } else { tmp8 = linked_2837.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2836, arg_2839) }; return /*line :394:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8)) }







func A_arbace_j2g_meta_refusals_iter__849000434__849000438_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_A{}; t.Ctor_O_O(p0, p1); return t }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_A) Ctor_O_O(c__refused_tops, c__unavailable any) { t.F_refused_tops = c__refused_tops; t.F_unavailable = c__unavailable }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_A) Invoke_O_O__O(self, s__849000435__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2820 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A_New_O_O_O_O(t.F_refused_tops, self, t.F_unavailable, s__849000435__1); var tmp2 *jrt.Class; var fncls__2819 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A_fn_class; if fncls__2819 == nil { var fncls__2819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__2820); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A_fn_class = fncls__2819d; tmp2 = fncls__2819d } else { tmp2 = fncls__2819 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2820, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :402:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A) Ctor_O_O_O_O(c__refused_tops, c__iter__849000434, c__unavailable, c__s__849000435 any) { t.F_refused_tops = c__refused_tops; t.F_iter__849000434 = c__iter__849000434; t.F_unavailable = c__unavailable; t.F_s__849000435 = c__s__849000435 }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A) Invoke_O__O(self any) any { { var s__849000435__1 any; var t_ any = t.F_s__849000435; t.F_s__849000435 = nil; s__849000435__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2421 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = s__849000435__1; if linked_2422 == nil { temp__1927000414__auto____2 = ifn_2423.Invoke_O__O(arg_2424) } else { temp__1927000414__auto____2 = linked_2422.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2421, arg_2424) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000435__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2425 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = s__849000435__3; if linked_2426 == nil { tmp1 = ifn_2427.Invoke_O__O(arg_2428) } else { tmp1 = linked_2426.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2425, arg_2428) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2429 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any = s__849000435__3; if linked_2430 == nil { c__1927001037__auto____4 = ifn_2431.Invoke_O__O(arg_2432) } else { c__1927001037__auto____4 = linked_2430.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2429, arg_2432) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000437__6 any; var root_2433 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2434 == nil { b__849000437__6 = ifn_2435.Invoke_O__O(arg_2436) } else { b__849000437__6 = linked_2434.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2433, arg_2436) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2611 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A_New_O_O_I_O_O(t.F_refused_tops, t.F_unavailable, size__1927001038__auto____5, b__849000437__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2610 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A_fn_class; if fncls__2610 == nil { var fncls__2610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__2611); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A_fn_class = fncls__2610d; tmp3 = fncls__2610d } else { tmp3 = fncls__2610 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2611, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2612 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any; var root_2617 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = b__849000437__6; if linked_2618 == nil { arg_2615 = ifn_2619.Invoke_O__O(arg_2620) } else { arg_2615 = linked_2618.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2617, arg_2620) }; var arg_2616 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000434); var tmp5 any; var root_2621 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = s__849000435__3; if linked_2622 == nil { tmp5 = ifn_2623.Invoke_O__O(arg_2624) } else { tmp5 = linked_2622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2621, arg_2624) }; arg_2616 = tmp4.Invoke_O__O(tmp5); if linked_2613 == nil { return ifn_2614.Invoke_O_O__O(arg_2615, arg_2616) } else { return linked_2613.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2612, arg_2615, arg_2616) } } else { var root_2625 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any; var root_2630 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = b__849000437__6; if linked_2631 == nil { arg_2628 = ifn_2632.Invoke_O__O(arg_2633) } else { arg_2628 = linked_2631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2630, arg_2633) }; var arg_2629 any; if linked_2626 == nil { return ifn_2627.Invoke_O_O__O(arg_2628, arg_2629) } else { return linked_2626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2625, arg_2628, arg_2629) } } } else { var vec__849000465__4 any; var root_2634 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2636 lang.IFn; if linked_2635 == nil { ifn_2636 = lang.IFn_Cast(root_2634) } else { ifn_2636 = nil }; var arg_2637 any = s__849000435__3; if linked_2635 == nil { vec__849000465__4 = ifn_2636.Invoke_O__O(arg_2637) } else { vec__849000465__4 = linked_2635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2634, arg_2637) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000465__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cause__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000465__4, lang.RT_IntCast_J__I_NoInit(1), nil); var refs__7 any; var root_2638 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2640 lang.IFn
														if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2641 any; var root_2642 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any; var iter__1927001039__auto____7 any; var fnbody__2801 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A_New_O_O(n__5, t.F_refused_tops); var tmp6 *jrt.Class; var fncls__2800 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A_fn_class; if fncls__2800 == nil { var fncls__2800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__2801); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A_fn_class = fncls__2800d; tmp6 = fncls__2800d } else { tmp6 = fncls__2800 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2801, tmp6, nil); arg_2645 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(t.F_unavailable); if linked_2643 == nil { arg_2641 = ifn_2644.Invoke_O__O(arg_2645) } else { arg_2641 = linked_2643.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2642, arg_2645) }; if linked_2639 == nil { refs__7 = ifn_2640.Invoke_O__O(arg_2641) } else { refs__7 = linked_2639.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2638, arg_2641) }
//line :402:1
	var tmp7 any; var root_2802 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2804 lang.IFn






	if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = refs__7; if linked_2803 == nil { tmp7 = ifn_2804.Invoke_O__O(arg_2805) } else { tmp7 = linked_2803.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2802, arg_2805) }
//line :402:1
	if jrt.J2g_Truth(tmp7) { var root_2806 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2808 lang.IFn; if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__5, cause__6, refs__7); var arg_2810 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__849000434); var tmp9 any; var root_2811 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any = s__849000435__3; if linked_2812 == nil { tmp9 = ifn_2813.Invoke_O__O(arg_2814) } else { tmp9 = linked_2812.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2811, arg_2814) }; arg_2810 = tmp8.Invoke_O__O(tmp9); if linked_2807 == nil { return ifn_2808.Invoke_O_O__O(arg_2809, arg_2810) } else { return linked_2807.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2806, arg_2809, arg_2810) } } else { var tmp10 any; var root_2815 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = s__849000435__3; if linked_2816 == nil { tmp10 = ifn_2817.Invoke_O__O(arg_2818) } else { tmp10 = linked_2816.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2815, arg_2818) }; s__849000435__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :402:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A) Ctor_O_O_I_O_O(c__refused_tops, c__unavailable any, c__size__1927001038__auto__ int32, c__b__849000437, c__c__1927001037__auto__ any) { t.F_refused_tops = c__refused_tops; t.F_unavailable = c__unavailable; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__849000437 = c__b__849000437; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :402:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A) Invoke_O__O(self any) any { { var i__849000436__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000436__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000441__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000436__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000441__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cause__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000441__2, lang.RT_IntCast_J__I_NoInit(1), nil); var refs__5 any; var root_2437 any = A_arbace_j2g_meta_A_const_34.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2439 lang.IFn
															if linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any; var root_2441 any = A_arbace_j2g_meta_A_const_27.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any; var iter__1927001039__auto____5 any; var fnbody__2600 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A_New_O_O(t.F_refused_tops, n__3); var tmp2 *jrt.Class; var fncls__2599 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A_fn_class; if fncls__2599 == nil { var fncls__2599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__2600); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A_fn_class = fncls__2599d; tmp2 = fncls__2599d } else { tmp2 = fncls__2599 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2600, tmp2, nil); arg_2444 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(t.F_unavailable); if linked_2442 == nil { arg_2440 = ifn_2443.Invoke_O__O(arg_2444) } else { arg_2440 = linked_2442.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2441, arg_2444) }; if linked_2438 == nil { refs__5 = ifn_2439.Invoke_O__O(arg_2440) } else { refs__5 = linked_2438.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2437, arg_2440) }
//line :402:1
	var tmp3 any; var root_2601 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2601, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2603 lang.IFn






	if linked_2602 == nil { ifn_2603 = lang.IFn_Cast(root_2601) } else { ifn_2603 = nil }; var arg_2604 any = refs__5; if linked_2602 == nil { tmp3 = ifn_2603.Invoke_O__O(arg_2604) } else { tmp3 = linked_2602.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2601, arg_2604) }
//line :402:1
	if jrt.J2g_Truth(tmp3) { var root_2605 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = t.F_b__849000437; var arg_2609 any = lang.Tuple_Create_O_O_O__IPersistentVector(n__3, cause__4, refs__5); if linked_2606 == nil { ifn_2607.Invoke_O_O__O(arg_2608, arg_2609) } else { linked_2606.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2605, arg_2608, arg_2609) }; i__849000436__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000436__1); continue L1 } else { i__849000436__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000436__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A{}; t.Ctor_O_O(p0, p1); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A) Ctor_O_O(c__refused_tops, c__n any) { t.F_refused_tops = c__refused_tops; t.F_n = c__n }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A) Invoke_O_O__O(self, s__849000445__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2598 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A_New_O_O_O_O(self, t.F_refused_tops, t.F_n, s__849000445__1); var tmp2 *jrt.Class; var fncls__2597 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A_fn_class; if fncls__2597 == nil { var fncls__2597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__2598); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A_fn_class = fncls__2597d; tmp2 = fncls__2597d } else { tmp2 = fncls__2597 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2598, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :403:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A) Ctor_O_O_O_O(c__iter__849000444, c__refused_tops, c__n, c__s__849000445 any) { t.F_iter__849000444 = c__iter__849000444; t.F_refused_tops = c__refused_tops; t.F_n = c__n; t.F_s__849000445 = c__s__849000445 }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A) Invoke_O__O(self any) any { { var s__849000445__1 any; var t_ any = t.F_s__849000445; t.F_s__849000445 = nil; s__849000445__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2445 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = s__849000445__1; if linked_2446 == nil { temp__1927000414__auto____2 = ifn_2447.Invoke_O__O(arg_2448) } else { temp__1927000414__auto____2 = linked_2446.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2445, arg_2448) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000445__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2449 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2451 lang.IFn; if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = s__849000445__3; if linked_2450 == nil { tmp1 = ifn_2451.Invoke_O__O(arg_2452) } else { tmp1 = linked_2450.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2449, arg_2452) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2453 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2455 lang.IFn; if linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = s__849000445__3; if linked_2454 == nil { c__1927001037__auto____4 = ifn_2455.Invoke_O__O(arg_2456) } else { c__1927001037__auto____4 = linked_2454.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2453, arg_2456) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000447__6 any; var root_2457 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2458 == nil { b__849000447__6 = ifn_2459.Invoke_O__O(arg_2460) } else { b__849000447__6 = linked_2458.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2457, arg_2460) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2512 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A_New_O_O_I_O_O(t.F_refused_tops, t.F_n, size__1927001038__auto____5, b__849000447__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2511 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A_fn_class; if fncls__2511 == nil { var fncls__2511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__2512); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A_fn_class = fncls__2511d; tmp3 = fncls__2511d } else { tmp3 = fncls__2511 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2512, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2513 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2513, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2515 lang.IFn; if linked_2514 == nil { ifn_2515 = lang.IFn_Cast(root_2513) } else { ifn_2515 = nil }; var arg_2516 any; var root_2518 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = b__849000447__6; if linked_2519 == nil { arg_2516 = ifn_2520.Invoke_O__O(arg_2521) } else { arg_2516 = linked_2519.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2518, arg_2521) }; var arg_2517 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000444); var tmp5 any; var root_2522 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any = s__849000445__3; if linked_2523 == nil { tmp5 = ifn_2524.Invoke_O__O(arg_2525) } else { tmp5 = linked_2523.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2522, arg_2525) }; arg_2517 = tmp4.Invoke_O__O(tmp5); if linked_2514 == nil { return ifn_2515.Invoke_O_O__O(arg_2516, arg_2517) } else { return linked_2514.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2513, arg_2516, arg_2517) } } else { var root_2526 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2528 lang.IFn; if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any; var root_2531 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = b__849000447__6; if linked_2532 == nil { arg_2529 = ifn_2533.Invoke_O__O(arg_2534) } else { arg_2529 = linked_2532.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2531, arg_2534) }; var arg_2530 any; if linked_2527 == nil { return ifn_2528.Invoke_O_O__O(arg_2529, arg_2530) } else { return linked_2527.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2526, arg_2529, arg_2530) } } } else { var vec__849000457__4 any; var root_2535 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = s__849000445__3; if linked_2536 == nil { vec__849000457__4 = ifn_2537.Invoke_O__O(arg_2538) } else { vec__849000457__4 = linked_2536.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2535, arg_2538) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000457__4, lang.RT_IntCast_J__I_NoInit(0), nil); var whys__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000457__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_2539 any = A_arbace_j2g_meta_A_const_152.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2541 lang.IFn
																					if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = k__5; if linked_2540 == nil { and__1927000168__auto____7 = ifn_2541.Invoke_O__O(arg_2542) } else { and__1927000168__auto____7 = linked_2540.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2539, arg_2542) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2543 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any; var root_2547 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = k__5; if linked_2548 == nil { arg_2546 = ifn_2549.Invoke_O__O(arg_2550) } else { arg_2546 = linked_2548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2547, arg_2550) }; if linked_2544 == nil { and__1927000168__auto____8 = ifn_2545.Invoke_O__O(arg_2546) } else { and__1927000168__auto____8 = linked_2544.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2543, arg_2546) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2551 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2553 lang.IFn

		if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_refused_tops); var tmp8 any; var root_2555 any = A_arbace_j2g_meta_A_const_164.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, A_arbace_j2g_meta_top_of_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any; var root_2559 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = k__5; if linked_2560 == nil { arg_2558 = ifn_2561.Invoke_O__O(arg_2562) } else { arg_2558 = linked_2560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2559, arg_2562) }; if linked_2556 == nil { tmp8 = ifn_2557.Invoke_O__O(arg_2558) } else { tmp8 = linked_2556.(*A_arbace_j2g_meta_top_of_A).Invoke_O_O__O(root_2555, arg_2558) }; arg_2554 = tmp7.Invoke_O__O(tmp8); if linked_2552 == nil { and__1927000168__auto____9 = ifn_2553.Invoke_O__O(arg_2554) } else { and__1927000168__auto____9 = linked_2552.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2551, arg_2554) }
//line :404:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {


			var root_2563 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any; var fnbody__2578 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A_New_O(t.F_n); var tmp9 *jrt.Class; var fncls__2577 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A_fn_class; if fncls__2577 == nil { var fncls__2577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__2578); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A_fn_class = fncls__2577d; tmp9 = fncls__2577d } else { tmp9 = fncls__2577 }; arg_2566 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2578, tmp9, nil); var arg_2567 any = whys__6; if linked_2564 == nil { tmp6 = ifn_2565.Invoke_O_O__O(arg_2566, arg_2567) } else { tmp6 = linked_2564.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2563, arg_2566, arg_2567) } } else {
//line :404:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = and__1927000168__auto____8 } } else { tmp6 = and__1927000168__auto____7 }
//line :403:1
	if jrt.J2g_Truth(tmp6) { var root_2579 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any; var root_2584 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2586 lang.IFn




		if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = Lit_13; var arg_2588 any = k__5; if linked_2585 == nil { arg_2582 = ifn_2586.Invoke_O_O__O(arg_2587, arg_2588) } else { arg_2582 = linked_2585.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2584, arg_2587, arg_2588) }
//line :403:1
		var arg_2583 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__849000444); var tmp11 any; var root_2589 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = s__849000445__3; if linked_2590 == nil { tmp11 = ifn_2591.Invoke_O__O(arg_2592) } else { tmp11 = linked_2590.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2589, arg_2592) }; arg_2583 = tmp10.Invoke_O__O(tmp11); if linked_2580 == nil { return ifn_2581.Invoke_O_O__O(arg_2582, arg_2583) } else { return linked_2580.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2579, arg_2582, arg_2583) } } else { var tmp12 any; var root_2593 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any = s__849000445__3; if linked_2594 == nil { tmp12 = ifn_2595.Invoke_O__O(arg_2596) } else { tmp12 = linked_2594.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2593, arg_2596) }; s__849000445__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :403:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A) Ctor_O_O_I_O_O(c__refused_tops, c__n any, c__size__1927001038__auto__ int32, c__b__849000447, c__c__1927001037__auto__ any) { t.F_refused_tops = c__refused_tops; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__849000447 = c__b__849000447; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A) Invoke_O__O(self any) any { { var i__849000446__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000446__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000451__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000446__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000451__2, lang.RT_IntCast_J__I_NoInit(0), nil); var whys__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000451__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_2461 any = A_arbace_j2g_meta_A_const_152.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2463 lang.IFn
																						if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = k__3; if linked_2462 == nil { and__1927000168__auto____5 = ifn_2463.Invoke_O__O(arg_2464) } else { and__1927000168__auto____5 = linked_2462.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2461, arg_2464) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2465 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_2466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2465, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2467 lang.IFn; if linked_2466 == nil { ifn_2467 = lang.IFn_Cast(root_2465) } else { ifn_2467 = nil }; var arg_2468 any; var root_2469 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = k__3; if linked_2470 == nil { arg_2468 = ifn_2471.Invoke_O__O(arg_2472) } else { arg_2468 = linked_2470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2469, arg_2472) }; if linked_2466 == nil { and__1927000168__auto____6 = ifn_2467.Invoke_O__O(arg_2468) } else { and__1927000168__auto____6 = linked_2466.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2465, arg_2468) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2473 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2475 lang.IFn

		if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_refused_tops); var tmp4 any; var root_2477 any = A_arbace_j2g_meta_A_const_164.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, A_arbace_j2g_meta_top_of_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any; var root_2481 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = k__3; if linked_2482 == nil { arg_2480 = ifn_2483.Invoke_O__O(arg_2484) } else { arg_2480 = linked_2482.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2481, arg_2484) }; if linked_2478 == nil { tmp4 = ifn_2479.Invoke_O__O(arg_2480) } else { tmp4 = linked_2478.(*A_arbace_j2g_meta_top_of_A).Invoke_O_O__O(root_2477, arg_2480) }; arg_2476 = tmp3.Invoke_O__O(tmp4); if linked_2474 == nil { and__1927000168__auto____7 = ifn_2475.Invoke_O__O(arg_2476) } else { and__1927000168__auto____7 = linked_2474.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2473, arg_2476) }
//line :404:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {


			var root_2485 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any; var fnbody__2500 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A_New_O(t.F_n); var tmp5 *jrt.Class; var fncls__2499 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A_fn_class; if fncls__2499 == nil { var fncls__2499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__2500); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A_fn_class = fncls__2499d; tmp5 = fncls__2499d } else { tmp5 = fncls__2499 }; arg_2488 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2500, tmp5, nil); var arg_2489 any = whys__4; if linked_2486 == nil { tmp2 = ifn_2487.Invoke_O_O__O(arg_2488, arg_2489) } else { tmp2 = linked_2486.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2485, arg_2488, arg_2489) } } else {
//line :404:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 }
//line :403:1
	if jrt.J2g_Truth(tmp2) { var root_2501 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2503 lang.IFn; if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any = t.F_b__849000447; var arg_2505 any; var root_2506 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2508 lang.IFn




		if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = Lit_13; var arg_2510 any = k__3; if linked_2507 == nil { arg_2505 = ifn_2508.Invoke_O_O__O(arg_2509, arg_2510) } else { arg_2505 = linked_2507.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2506, arg_2509, arg_2510) }
//line :403:1
		if linked_2502 == nil { ifn_2503.Invoke_O_O__O(arg_2504, arg_2505) } else { linked_2502.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2501, arg_2504, arg_2505) }; i__849000446__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000446__1); continue L1 } else { i__849000446__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000446__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :403:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A_New_O_O(p0, p1 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A{}; t.Ctor_O_O(p0, p1); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A) Ctor_O_O(c__n, c__refused_tops any) { t.F_n = c__n; t.F_refused_tops = c__refused_tops }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A) Invoke_O_O__O(self, s__849000469__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2799 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A_New_O_O_O_O(t.F_n, t.F_refused_tops, self, s__849000469__1); var tmp2 *jrt.Class; var fncls__2798 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A_fn_class; if fncls__2798 == nil { var fncls__2798d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__2799); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A_fn_class = fncls__2798d; tmp2 = fncls__2798d } else { tmp2 = fncls__2798 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2799, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :403:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A) Ctor_O_O_O_O(c__n, c__refused_tops, c__iter__849000468, c__s__849000469 any) { t.F_n = c__n; t.F_refused_tops = c__refused_tops; t.F_iter__849000468 = c__iter__849000468; t.F_s__849000469 = c__s__849000469 }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A) Invoke_O__O(self any) any { { var s__849000469__1 any; var t_ any = t.F_s__849000469; t.F_s__849000469 = nil; s__849000469__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2646 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = s__849000469__1; if linked_2647 == nil { temp__1927000414__auto____2 = ifn_2648.Invoke_O__O(arg_2649) } else { temp__1927000414__auto____2 = linked_2647.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2646, arg_2649) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000469__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2650 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = s__849000469__3; if linked_2651 == nil { tmp1 = ifn_2652.Invoke_O__O(arg_2653) } else { tmp1 = linked_2651.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2650, arg_2653) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2654 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var arg_2657 any = s__849000469__3; if linked_2655 == nil { c__1927001037__auto____4 = ifn_2656.Invoke_O__O(arg_2657) } else { c__1927001037__auto____4 = linked_2655.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2654, arg_2657) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000471__6 any; var root_2658 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2659 == nil { b__849000471__6 = ifn_2660.Invoke_O__O(arg_2661) } else { b__849000471__6 = linked_2659.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2658, arg_2661) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2713 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A_New_O_O_O_I_O(t.F_n, t.F_refused_tops, b__849000471__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2712 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A_fn_class; if fncls__2712 == nil { var fncls__2712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__2713); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A_fn_class = fncls__2712d; tmp3 = fncls__2712d } else { tmp3 = fncls__2712 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2713, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2714 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2714, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2716 lang.IFn; if linked_2715 == nil { ifn_2716 = lang.IFn_Cast(root_2714) } else { ifn_2716 = nil }; var arg_2717 any; var root_2719 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = b__849000471__6; if linked_2720 == nil { arg_2717 = ifn_2721.Invoke_O__O(arg_2722) } else { arg_2717 = linked_2720.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2719, arg_2722) }; var arg_2718 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000468); var tmp5 any; var root_2723 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = s__849000469__3; if linked_2724 == nil { tmp5 = ifn_2725.Invoke_O__O(arg_2726) } else { tmp5 = linked_2724.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2723, arg_2726) }; arg_2718 = tmp4.Invoke_O__O(tmp5); if linked_2715 == nil { return ifn_2716.Invoke_O_O__O(arg_2717, arg_2718) } else { return linked_2715.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2714, arg_2717, arg_2718) } } else { var root_2727 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2729 lang.IFn; if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2730 any; var root_2732 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2732, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2734 lang.IFn; if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = b__849000471__6; if linked_2733 == nil { arg_2730 = ifn_2734.Invoke_O__O(arg_2735) } else { arg_2730 = linked_2733.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2732, arg_2735) }; var arg_2731 any; if linked_2728 == nil { return ifn_2729.Invoke_O_O__O(arg_2730, arg_2731) } else { return linked_2728.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2727, arg_2730, arg_2731) } } } else { var vec__849000481__4 any; var root_2736 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any = s__849000469__3; if linked_2737 == nil { vec__849000481__4 = ifn_2738.Invoke_O__O(arg_2739) } else { vec__849000481__4 = linked_2737.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2736, arg_2739) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000481__4, lang.RT_IntCast_J__I_NoInit(0), nil); var whys__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000481__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_2740 any = A_arbace_j2g_meta_A_const_152.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2742 lang.IFn
																			if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = k__5; if linked_2741 == nil { and__1927000168__auto____7 = ifn_2742.Invoke_O__O(arg_2743) } else { and__1927000168__auto____7 = linked_2741.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2740, arg_2743) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2744 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2746 lang.IFn; if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any; var root_2748 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = k__5; if linked_2749 == nil { arg_2747 = ifn_2750.Invoke_O__O(arg_2751) } else { arg_2747 = linked_2749.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2748, arg_2751) }; if linked_2745 == nil { and__1927000168__auto____8 = ifn_2746.Invoke_O__O(arg_2747) } else { and__1927000168__auto____8 = linked_2745.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2744, arg_2747) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_2752 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2754 lang.IFn

		if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_refused_tops); var tmp8 any; var root_2756 any = A_arbace_j2g_meta_A_const_164.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, A_arbace_j2g_meta_top_of_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any; var root_2760 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = k__5; if linked_2761 == nil { arg_2759 = ifn_2762.Invoke_O__O(arg_2763) } else { arg_2759 = linked_2761.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2760, arg_2763) }; if linked_2757 == nil { tmp8 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp8 = linked_2757.(*A_arbace_j2g_meta_top_of_A).Invoke_O_O__O(root_2756, arg_2759) }; arg_2755 = tmp7.Invoke_O__O(tmp8); if linked_2753 == nil { and__1927000168__auto____9 = ifn_2754.Invoke_O__O(arg_2755) } else { and__1927000168__auto____9 = linked_2753.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2752, arg_2755) }
//line :404:1
		if jrt.J2g_Truth(and__1927000168__auto____9) {


			var root_2764 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any; var fnbody__2779 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A_New_O(t.F_n); var tmp9 *jrt.Class; var fncls__2778 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A_fn_class; if fncls__2778 == nil { var fncls__2778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__2779); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A_fn_class = fncls__2778d; tmp9 = fncls__2778d } else { tmp9 = fncls__2778 }; arg_2767 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2779, tmp9, nil); var arg_2768 any = whys__6; if linked_2765 == nil { tmp6 = ifn_2766.Invoke_O_O__O(arg_2767, arg_2768) } else { tmp6 = linked_2765.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2764, arg_2767, arg_2768) } } else {
//line :404:1
				tmp6 = and__1927000168__auto____9 } } else { tmp6 = and__1927000168__auto____8 } } else { tmp6 = and__1927000168__auto____7 }
//line :403:1
	if jrt.J2g_Truth(tmp6) { var root_2780 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any; var root_2785 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2787 lang.IFn




		if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = Lit_13; var arg_2789 any = k__5; if linked_2786 == nil { arg_2783 = ifn_2787.Invoke_O_O__O(arg_2788, arg_2789) } else { arg_2783 = linked_2786.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2785, arg_2788, arg_2789) }
//line :403:1
		var arg_2784 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__849000468); var tmp11 any; var root_2790 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any = s__849000469__3; if linked_2791 == nil { tmp11 = ifn_2792.Invoke_O__O(arg_2793) } else { tmp11 = linked_2791.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2790, arg_2793) }; arg_2784 = tmp10.Invoke_O__O(tmp11); if linked_2781 == nil { return ifn_2782.Invoke_O_O__O(arg_2783, arg_2784) } else { return linked_2781.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2780, arg_2783, arg_2784) } } else { var tmp12 any; var root_2794 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = s__849000469__3; if linked_2795 == nil { tmp12 = ifn_2796.Invoke_O__O(arg_2797) } else { tmp12 = linked_2795.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2794, arg_2797) }; s__849000469__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :403:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A) Ctor_O_O_O_I_O(c__n, c__refused_tops, c__b__849000471 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_refused_tops = c__refused_tops; t.F_b__849000471 = c__b__849000471; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :403:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A) Invoke_O__O(self any) any { { var i__849000470__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000470__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000475__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000470__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000475__2, lang.RT_IntCast_J__I_NoInit(0), nil); var whys__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000475__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_2662 any = A_arbace_j2g_meta_A_const_152.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2664 lang.IFn
																					if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = k__3; if linked_2663 == nil { and__1927000168__auto____5 = ifn_2664.Invoke_O__O(arg_2665) } else { and__1927000168__auto____5 = linked_2663.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2662, arg_2665) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2666 any = A_arbace_j2g_meta_A_const_83.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any; var root_2670 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = k__3; if linked_2671 == nil { arg_2669 = ifn_2672.Invoke_O__O(arg_2673) } else { arg_2669 = linked_2671.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2670, arg_2673) }; if linked_2667 == nil { and__1927000168__auto____6 = ifn_2668.Invoke_O__O(arg_2669) } else { and__1927000168__auto____6 = linked_2667.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2666, arg_2669) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2674 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2676 lang.IFn

		if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_refused_tops); var tmp4 any; var root_2678 any = A_arbace_j2g_meta_A_const_164.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, A_arbace_j2g_meta_top_of_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any; var root_2682 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = k__3; if linked_2683 == nil { arg_2681 = ifn_2684.Invoke_O__O(arg_2685) } else { arg_2681 = linked_2683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2682, arg_2685) }; if linked_2679 == nil { tmp4 = ifn_2680.Invoke_O__O(arg_2681) } else { tmp4 = linked_2679.(*A_arbace_j2g_meta_top_of_A).Invoke_O_O__O(root_2678, arg_2681) }; arg_2677 = tmp3.Invoke_O__O(tmp4); if linked_2675 == nil { and__1927000168__auto____7 = ifn_2676.Invoke_O__O(arg_2677) } else { and__1927000168__auto____7 = linked_2675.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2674, arg_2677) }
//line :404:1
		if jrt.J2g_Truth(and__1927000168__auto____7) {


			var root_2686 any = A_arbace_j2g_meta_A_const_109.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any; var fnbody__2701 any = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A_New_O(t.F_n); var tmp5 *jrt.Class; var fncls__2700 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A_fn_class; if fncls__2700 == nil { var fncls__2700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__2701); A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A_fn_class = fncls__2700d; tmp5 = fncls__2700d } else { tmp5 = fncls__2700 }; arg_2689 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2701, tmp5, nil); var arg_2690 any = whys__4; if linked_2687 == nil { tmp2 = ifn_2688.Invoke_O_O__O(arg_2689, arg_2690) } else { tmp2 = linked_2687.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2686, arg_2689, arg_2690) } } else {
//line :404:1
				tmp2 = and__1927000168__auto____7 } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 }
//line :403:1
	if jrt.J2g_Truth(tmp2) { var root_2702 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = t.F_b__849000471; var arg_2706 any; var root_2707 any = A_arbace_j2g_meta_A_const_13.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2709 lang.IFn




		if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = Lit_13; var arg_2711 any = k__3; if linked_2708 == nil { arg_2706 = ifn_2709.Invoke_O_O__O(arg_2710, arg_2711) } else { arg_2706 = linked_2708.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2707, arg_2710, arg_2711) }
//line :403:1
		if linked_2703 == nil { ifn_2704.Invoke_O_O__O(arg_2705, arg_2706) } else { linked_2703.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2702, arg_2705, arg_2706) }; i__849000470__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000470__1); continue L1 } else { i__849000470__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000470__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A_New_O(p0 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A{}; t.Ctor_O(p0); return t }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A) Invoke_O_O__O(self, p1__849000433_SHARP___1 any) any { var root_2490 any = A_arbace_j2g_meta_A_const_166.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, A_arbace_j2g_meta_names_class_QMARK__A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any; var root_2495 any = A_arbace_j2g_meta_A_const_93.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any = p1__849000433_SHARP___1; if linked_2496 == nil { arg_2493 = ifn_2497.Invoke_O__O(arg_2498) } else { arg_2493 = linked_2496.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2495, arg_2498) }; var arg_2494 any = t.F_n; if linked_2491 == nil { return ifn_2492.Invoke_O_O__O(arg_2493, arg_2494) } else { return linked_2491.(*A_arbace_j2g_meta_names_class_QMARK__A).Invoke_O_O_O__O(root_2490, arg_2493, arg_2494) } }
//line :407:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A_New_O(p0 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A{}; t.Ctor_O(p0); return t }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A) Invoke_O_O__O(self, p1__849000433_SHARP___1 any) any { var root_2568 any = A_arbace_j2g_meta_A_const_166.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, A_arbace_j2g_meta_names_class_QMARK__A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any; var root_2573 any = A_arbace_j2g_meta_A_const_93.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any = p1__849000433_SHARP___1; if linked_2574 == nil { arg_2571 = ifn_2575.Invoke_O__O(arg_2576) } else { arg_2571 = linked_2574.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2573, arg_2576) }; var arg_2572 any = t.F_n; if linked_2569 == nil { return ifn_2570.Invoke_O_O__O(arg_2571, arg_2572) } else { return linked_2569.(*A_arbace_j2g_meta_names_class_QMARK__A).Invoke_O_O_O__O(root_2568, arg_2571, arg_2572) } }
//line :407:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A_New_O(p0 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A{}; t.Ctor_O(p0); return t }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A) Invoke_O_O__O(self, p1__849000433_SHARP___1 any) any { var root_2691 any = A_arbace_j2g_meta_A_const_166.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, A_arbace_j2g_meta_names_class_QMARK__A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any; var root_2696 any = A_arbace_j2g_meta_A_const_93.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any = p1__849000433_SHARP___1; if linked_2697 == nil { arg_2694 = ifn_2698.Invoke_O__O(arg_2699) } else { arg_2694 = linked_2697.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2696, arg_2699) }; var arg_2695 any = t.F_n; if linked_2692 == nil { return ifn_2693.Invoke_O_O__O(arg_2694, arg_2695) } else { return linked_2692.(*A_arbace_j2g_meta_names_class_QMARK__A).Invoke_O_O_O__O(root_2691, arg_2694, arg_2695) } }
//line :407:1
func A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A_New_O(p0 any) *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A{}; t.Ctor_O(p0); return t }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :407:1
func (t *A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A) Invoke_O_O__O(self, p1__849000433_SHARP___1 any) any { var root_2769 any = A_arbace_j2g_meta_A_const_166.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2769, A_arbace_j2g_meta_names_class_QMARK__A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any; var root_2774 any = A_arbace_j2g_meta_A_const_93.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any = p1__849000433_SHARP___1; if linked_2775 == nil { arg_2772 = ifn_2776.Invoke_O__O(arg_2777) } else { arg_2772 = linked_2775.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2774, arg_2777) }; var arg_2773 any = t.F_n; if linked_2770 == nil { return ifn_2771.Invoke_O_O__O(arg_2772, arg_2773) } else { return linked_2770.(*A_arbace_j2g_meta_names_class_QMARK__A).Invoke_O_O_O__O(root_2769, arg_2772, arg_2773) } }





func A_arbace_j2g_meta_refusals_iter__849000490__849000494_A_New_O(p0 any) *A_arbace_j2g_meta_refusals_iter__849000490__849000494_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000490__849000494_A{}; t.Ctor_O(p0); return t }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_A) Invoke_O_O__O(self, s__849000491__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2911 any = A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A_New_O_O_O(self, s__849000491__1, t.F_s); var tmp2 *jrt.Class; var fncls__2910 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A_fn_class; if fncls__2910 == nil { var fncls__2910d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__2911); A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A_fn_class = fncls__2910d; tmp2 = fncls__2910d } else { tmp2 = fncls__2910 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2911, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :413:1
func A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A) Ctor_O_O_O(c__iter__849000490, c__s__849000491, c__s any) { t.F_iter__849000490 = c__iter__849000490; t.F_s__849000491 = c__s__849000491; t.F_s = c__s }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A) Invoke_O__O(self any) any { { var s__849000491__1 any; var t_ any = t.F_s__849000491; t.F_s__849000491 = nil; s__849000491__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2840 any = A_arbace_j2g_meta_A_const_14.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2842 lang.IFn; if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any = s__849000491__1; if linked_2841 == nil { temp__1927000414__auto____2 = ifn_2842.Invoke_O__O(arg_2843) } else { temp__1927000414__auto____2 = linked_2841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2840, arg_2843) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__849000491__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2844 any = A_arbace_j2g_meta_A_const_15.GetRawRoot__O(); var linked_2845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2844, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2846 lang.IFn; if linked_2845 == nil { ifn_2846 = lang.IFn_Cast(root_2844) } else { ifn_2846 = nil }; var arg_2847 any = s__849000491__3; if linked_2845 == nil { tmp1 = ifn_2846.Invoke_O__O(arg_2847) } else { tmp1 = linked_2845.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2844, arg_2847) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2848 any = A_arbace_j2g_meta_A_const_16.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2850 lang.IFn; if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = s__849000491__3; if linked_2849 == nil { c__1927001037__auto____4 = ifn_2850.Invoke_O__O(arg_2851) } else { c__1927001037__auto____4 = linked_2849.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2848, arg_2851) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__849000493__6 any; var root_2852 any = A_arbace_j2g_meta_A_const_17.GetRawRoot__O(); var linked_2853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2852, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2854 lang.IFn; if linked_2853 == nil { ifn_2854 = lang.IFn_Cast(root_2852) } else { ifn_2854 = nil }; var arg_2855 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2853 == nil { b__849000493__6 = ifn_2854.Invoke_O__O(arg_2855) } else { b__849000493__6 = linked_2853.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2852, arg_2855) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2866 any = A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A_New_O_O_I_O(t.F_s, b__849000493__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2865 *jrt.Class = A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A_fn_class; if fncls__2865 == nil { var fncls__2865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__2866); A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A_fn_class = fncls__2865d; tmp3 = fncls__2865d } else { tmp3 = fncls__2865 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2866, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2867 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any; var root_2872 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2874 lang.IFn; if linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any = b__849000493__6; if linked_2873 == nil { arg_2870 = ifn_2874.Invoke_O__O(arg_2875) } else { arg_2870 = linked_2873.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2872, arg_2875) }; var arg_2871 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__849000490); var tmp5 any; var root_2876 any = A_arbace_j2g_meta_A_const_21.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = s__849000491__3; if linked_2877 == nil { tmp5 = ifn_2878.Invoke_O__O(arg_2879) } else { tmp5 = linked_2877.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2876, arg_2879) }; arg_2871 = tmp4.Invoke_O__O(tmp5); if linked_2868 == nil { return ifn_2869.Invoke_O_O__O(arg_2870, arg_2871) } else { return linked_2868.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2867, arg_2870, arg_2871) } } else { var root_2880 any = A_arbace_j2g_meta_A_const_19.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any; var root_2885 any = A_arbace_j2g_meta_A_const_20.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = b__849000493__6; if linked_2886 == nil { arg_2883 = ifn_2887.Invoke_O__O(arg_2888) } else { arg_2883 = linked_2886.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2885, arg_2888) }; var arg_2884 any; if linked_2881 == nil { return ifn_2882.Invoke_O_O__O(arg_2883, arg_2884) } else { return linked_2881.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2880, arg_2883, arg_2884) } } } else { var vec__849000501__4 any; var root_2889 any = A_arbace_j2g_meta_A_const_22.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = s__849000491__3; if linked_2890 == nil { vec__849000501__4 = ifn_2891.Invoke_O__O(arg_2892) } else { vec__849000501__4 = linked_2890.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2889, arg_2892) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000501__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cause__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000501__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2893 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2895 lang.IFn; if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = lang.IFn_Cast(t.F_s).Invoke_O__O(n__5); if linked_2894 == nil { tmp6 = ifn_2895.Invoke_O__O(arg_2896) } else { tmp6 = linked_2894.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2893, arg_2896) }; if jrt.J2g_Truth(tmp6) { var root_2897 any = A_arbace_j2g_meta_A_const_23.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2899 lang.IFn; if linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, cause__6); var arg_2901 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__849000490); var tmp8 any; var root_2902 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2904 lang.IFn; if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = s__849000491__3; if linked_2903 == nil { tmp8 = ifn_2904.Invoke_O__O(arg_2905) } else { tmp8 = linked_2903.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2902, arg_2905) }; arg_2901 = tmp7.Invoke_O__O(tmp8); if linked_2898 == nil { return ifn_2899.Invoke_O_O__O(arg_2900, arg_2901) } else { return linked_2898.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2897, arg_2900, arg_2901) } } else { var tmp9 any; var root_2906 any = A_arbace_j2g_meta_A_const_24.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2908 lang.IFn; if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = s__849000491__3; if linked_2907 == nil { tmp9 = ifn_2908.Invoke_O__O(arg_2909) } else { tmp9 = linked_2907.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2906, arg_2909) }; s__849000491__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :413:1
func A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A) Ctor_O_O_I_O(c__s, c__b__849000493 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_s = c__s; t.F_b__849000493 = c__b__849000493; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :413:1
func (t *A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A) Invoke_O__O(self any) any { { var i__849000492__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__849000492__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__849000497__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__849000492__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000497__2, lang.RT_IntCast_J__I_NoInit(0), nil); var cause__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__849000497__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2856 any = A_arbace_j2g_meta_A_const_52.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any = lang.IFn_Cast(t.F_s).Invoke_O__O(n__3); if linked_2857 == nil { tmp2 = ifn_2858.Invoke_O__O(arg_2859) } else { tmp2 = linked_2857.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2856, arg_2859) }; if jrt.J2g_Truth(tmp2) { var root_2860 any = A_arbace_j2g_meta_A_const_18.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2862 lang.IFn; if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = t.F_b__849000493; var arg_2864 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, cause__4); if linked_2861 == nil { ifn_2862.Invoke_O_O__O(arg_2863, arg_2864) } else { linked_2861.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2860, arg_2863, arg_2864) }; i__849000492__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000492__1); continue L1 } else { i__849000492__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__849000492__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




































































































































































































































































































































































































































type A_arbace_j2g_meta_A struct{ jrt.Object }

var A_arbace_j2g_meta_A_const_pool *jrt.RefArray

var A_arbace_j2g_meta_A_const_0 *lang.Var

var A_arbace_j2g_meta_A_const_1 any

var A_arbace_j2g_meta_A_const_2 any

var A_arbace_j2g_meta_A_const_3 any

var A_arbace_j2g_meta_A_const_4 any

var A_arbace_j2g_meta_A_const_5 any

var A_arbace_j2g_meta_A_const_6 *lang.Var

var A_arbace_j2g_meta_A_const_7 any

var A_arbace_j2g_meta_A_const_8 *lang.Var

var A_arbace_j2g_meta_A_const_9 *lang.Var

var A_arbace_j2g_meta_A_const_10 *lang.Var

var A_arbace_j2g_meta_A_const_11 *lang.Var

var A_arbace_j2g_meta_A_const_12 any

var A_arbace_j2g_meta_A_const_13 *lang.Var

var A_arbace_j2g_meta_A_const_14 *lang.Var

var A_arbace_j2g_meta_A_const_15 *lang.Var

var A_arbace_j2g_meta_A_const_16 *lang.Var

var A_arbace_j2g_meta_A_const_17 *lang.Var

var A_arbace_j2g_meta_A_const_18 *lang.Var

var A_arbace_j2g_meta_A_const_19 *lang.Var

var A_arbace_j2g_meta_A_const_20 *lang.Var

var A_arbace_j2g_meta_A_const_21 *lang.Var

var A_arbace_j2g_meta_A_const_22 *lang.Var

var A_arbace_j2g_meta_A_const_23 *lang.Var

var A_arbace_j2g_meta_A_const_24 *lang.Var

var A_arbace_j2g_meta_A_const_25 *lang.Var

var A_arbace_j2g_meta_A_const_26 *lang.Var

var A_arbace_j2g_meta_A_const_27 *lang.Var

var A_arbace_j2g_meta_A_const_28 *lang.Var

var A_arbace_j2g_meta_A_const_29 *lang.Var

var A_arbace_j2g_meta_A_const_30 any

var A_arbace_j2g_meta_A_const_31 any

var A_arbace_j2g_meta_A_const_32 *lang.Var

var A_arbace_j2g_meta_A_const_33 *lang.Var

var A_arbace_j2g_meta_A_const_34 *lang.Var

var A_arbace_j2g_meta_A_const_35 *lang.Var

var A_arbace_j2g_meta_A_const_36 *lang.Var

var A_arbace_j2g_meta_A_const_37 *lang.Var

var A_arbace_j2g_meta_A_const_38 *lang.Var

var A_arbace_j2g_meta_A_const_39 *lang.Var

var A_arbace_j2g_meta_A_const_40 *lang.Var

var A_arbace_j2g_meta_A_const_41 any

var A_arbace_j2g_meta_A_const_42 *lang.Var

var A_arbace_j2g_meta_A_const_43 *lang.Var

var A_arbace_j2g_meta_A_const_44 *lang.Var

var A_arbace_j2g_meta_A_const_45 *lang.Var

var A_arbace_j2g_meta_A_const_46 any

var A_arbace_j2g_meta_A_const_47 *lang.Var

var A_arbace_j2g_meta_A_const_48 *lang.Keyword

var A_arbace_j2g_meta_A_const_49 *lang.Var

var A_arbace_j2g_meta_A_const_50 any

var A_arbace_j2g_meta_A_const_51 *lang.Var

var A_arbace_j2g_meta_A_const_52 *lang.Var

var A_arbace_j2g_meta_A_const_53 *lang.Var

var A_arbace_j2g_meta_A_const_54 any

var A_arbace_j2g_meta_A_const_55 *lang.Var

var A_arbace_j2g_meta_A_const_56 *lang.Var

var A_arbace_j2g_meta_A_const_57 *lang.Var

var A_arbace_j2g_meta_A_const_58 *lang.Var

var A_arbace_j2g_meta_A_const_59 *lang.Var

var A_arbace_j2g_meta_A_const_60 *lang.Var

var A_arbace_j2g_meta_A_const_61 *lang.Var

var A_arbace_j2g_meta_A_const_62 *lang.Var

var A_arbace_j2g_meta_A_const_63 *lang.Keyword

var A_arbace_j2g_meta_A_const_64 *lang.Var

var A_arbace_j2g_meta_A_const_65 *lang.Keyword

var A_arbace_j2g_meta_A_const_66 *lang.Var

var A_arbace_j2g_meta_A_const_67 *lang.Var

var A_arbace_j2g_meta_A_const_68 *lang.Var

var A_arbace_j2g_meta_A_const_69 *lang.Var

var A_arbace_j2g_meta_A_const_70 *lang.Var

var A_arbace_j2g_meta_A_const_71 *lang.Keyword

var A_arbace_j2g_meta_A_const_72 *lang.Var

var A_arbace_j2g_meta_A_const_73 *lang.Var

var A_arbace_j2g_meta_A_const_74 *lang.Var

var A_arbace_j2g_meta_A_const_75 *lang.Var

var A_arbace_j2g_meta_A_const_76 *lang.Var

var A_arbace_j2g_meta_A_const_77 *lang.Var

var A_arbace_j2g_meta_A_const_78 *lang.Var

var A_arbace_j2g_meta_A_const_79 *lang.Var

var A_arbace_j2g_meta_A_const_80 *lang.Keyword

var A_arbace_j2g_meta_A_const_81 any

var A_arbace_j2g_meta_A_const_82 any

var A_arbace_j2g_meta_A_const_83 *lang.Var

var A_arbace_j2g_meta_A_const_84 *lang.Var

var A_arbace_j2g_meta_A_const_85 any

var A_arbace_j2g_meta_A_const_86 any

var A_arbace_j2g_meta_A_const_87 any

var A_arbace_j2g_meta_A_const_88 any

var A_arbace_j2g_meta_A_const_89 any

var A_arbace_j2g_meta_A_const_90 any

var A_arbace_j2g_meta_A_const_91 any

var A_arbace_j2g_meta_A_const_92 any

var A_arbace_j2g_meta_A_const_93 *lang.Var

var A_arbace_j2g_meta_A_const_94 any

var A_arbace_j2g_meta_A_const_95 any

var A_arbace_j2g_meta_A_const_96 any

var A_arbace_j2g_meta_A_const_97 any

var A_arbace_j2g_meta_A_const_98 any

var A_arbace_j2g_meta_A_const_99 any

var A_arbace_j2g_meta_A_const_100 any

var A_arbace_j2g_meta_A_const_101 any

var A_arbace_j2g_meta_A_const_102 any

var A_arbace_j2g_meta_A_const_103 any

var A_arbace_j2g_meta_A_const_104 *lang.Var

var A_arbace_j2g_meta_A_const_105 any

var A_arbace_j2g_meta_A_const_106 any

var A_arbace_j2g_meta_A_const_107 *lang.Var

var A_arbace_j2g_meta_A_const_108 *lang.Var

var A_arbace_j2g_meta_A_const_109 *lang.Var

var A_arbace_j2g_meta_A_const_110 any

var A_arbace_j2g_meta_A_const_111 any

var A_arbace_j2g_meta_A_const_112 *lang.Var

var A_arbace_j2g_meta_A_const_113 *lang.Var

var A_arbace_j2g_meta_A_const_114 any

var A_arbace_j2g_meta_A_const_115 any

var A_arbace_j2g_meta_A_const_116 any

var A_arbace_j2g_meta_A_const_117 *lang.Keyword

var A_arbace_j2g_meta_A_const_118 *lang.Var

var A_arbace_j2g_meta_A_const_119 *lang.Var

var A_arbace_j2g_meta_A_const_120 *lang.Keyword

var A_arbace_j2g_meta_A_const_121 *lang.Keyword

var A_arbace_j2g_meta_A_const_122 *lang.Var

var A_arbace_j2g_meta_A_const_123 *lang.Var

var A_arbace_j2g_meta_A_const_124 *lang.Keyword

var A_arbace_j2g_meta_A_const_125 *lang.Keyword

var A_arbace_j2g_meta_A_const_126 *lang.Keyword

var A_arbace_j2g_meta_A_const_127 *lang.Keyword

var A_arbace_j2g_meta_A_const_128 *lang.Keyword

var A_arbace_j2g_meta_A_const_129 any

var A_arbace_j2g_meta_A_const_130 *lang.Keyword

var A_arbace_j2g_meta_A_const_131 *lang.Var

var A_arbace_j2g_meta_A_const_132 *lang.Keyword

var A_arbace_j2g_meta_A_const_133 *lang.Var

var A_arbace_j2g_meta_A_const_134 *lang.Keyword

var A_arbace_j2g_meta_A_const_135 *lang.Keyword

var A_arbace_j2g_meta_A_const_136 *lang.Keyword

var A_arbace_j2g_meta_A_const_137 *lang.Var

var A_arbace_j2g_meta_A_const_138 *lang.Keyword

var A_arbace_j2g_meta_A_const_139 *lang.Keyword

var A_arbace_j2g_meta_A_const_140 *lang.Keyword

var A_arbace_j2g_meta_A_const_141 *lang.Keyword

var A_arbace_j2g_meta_A_const_142 *lang.Keyword

var A_arbace_j2g_meta_A_const_143 *lang.Keyword

var A_arbace_j2g_meta_A_const_144 *lang.Keyword

var A_arbace_j2g_meta_A_const_145 *lang.Var

var A_arbace_j2g_meta_A_const_146 *lang.Keyword

var A_arbace_j2g_meta_A_const_147 *lang.Keyword

var A_arbace_j2g_meta_A_const_148 *lang.Keyword

var A_arbace_j2g_meta_A_const_149 *lang.Var

var A_arbace_j2g_meta_A_const_150 *lang.Var

var A_arbace_j2g_meta_A_const_151 *lang.Var

var A_arbace_j2g_meta_A_const_152 *lang.Var

var A_arbace_j2g_meta_A_const_153 *lang.Var

var A_arbace_j2g_meta_A_const_154 *lang.Keyword

var A_arbace_j2g_meta_A_const_155 *lang.Keyword

var A_arbace_j2g_meta_A_const_156 *lang.Keyword

var A_arbace_j2g_meta_A_const_157 any

var A_arbace_j2g_meta_A_const_158 any

var A_arbace_j2g_meta_A_const_159 *lang.Var

var A_arbace_j2g_meta_A_const_160 *lang.Var

var A_arbace_j2g_meta_A_const_161 *lang.Var

var A_arbace_j2g_meta_A_const_162 *lang.Var

var A_arbace_j2g_meta_A_const_163 *lang.Var

var A_arbace_j2g_meta_A_const_164 *lang.Var

var A_arbace_j2g_meta_A_const_165 *lang.Var

var A_arbace_j2g_meta_A_const_166 *lang.Var

var A_arbace_j2g_meta_A_const_167 *lang.Keyword

var A_arbace_j2g_meta_A_const_168 *lang.Keyword

var A_arbace_j2g_meta_A_init jrt.ClassInit

func A_arbace_j2g_meta_A_Init() { if !A_arbace_j2g_meta_A_init.Done() { A_arbace_j2g_meta_A_init.Run(A_arbace_j2g_meta_A_clinit) } }

func A_arbace_j2g_meta_A_clinit() { A_arbace_j2g_meta_A_clinit_p0(); A_arbace_j2g_meta_A_clinit_p1(); A_arbace_j2g_meta_A_clinit_p2(); A_arbace_j2g_meta_A_clinit_p3(); A_arbace_j2g_meta_A_clinit_p4(); A_arbace_j2g_meta_A_clinit_p5(); A_arbace_j2g_meta_A_clinit_p6(); A_arbace_j2g_meta_A_clinit_p7(); A_arbace_j2g_meta_A_clinit_p8(); A_arbace_j2g_meta_A_clinit_p9(); A_arbace_j2g_meta_A_clinit_p10(); A_arbace_j2g_meta_A_clinit_p11(); A_arbace_j2g_meta_A_clinit_p12(); A_arbace_j2g_meta_A_clinit_p13() }

func A_arbace_j2g_meta_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_meta_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 215); A_arbace_j2g_meta_A_const_0 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[46]); A_arbace_j2g_meta_A_const_1 = A_arbace_j2g_meta_A_const_pool.A[47]; A_arbace_j2g_meta_A_const_2 = A_arbace_j2g_meta_A_const_pool.A[48]; A_arbace_j2g_meta_A_const_3 = A_arbace_j2g_meta_A_const_pool.A[49]; A_arbace_j2g_meta_A_const_4 = A_arbace_j2g_meta_A_const_pool.A[50]; A_arbace_j2g_meta_A_const_5 = A_arbace_j2g_meta_A_const_pool.A[51]; A_arbace_j2g_meta_A_const_6 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[52]); A_arbace_j2g_meta_A_const_7 = A_arbace_j2g_meta_A_const_pool.A[53]; A_arbace_j2g_meta_A_const_8 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[54]); A_arbace_j2g_meta_A_const_9 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[55]); A_arbace_j2g_meta_A_const_10 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[56]); A_arbace_j2g_meta_A_const_11 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[57]); A_arbace_j2g_meta_A_const_12 = A_arbace_j2g_meta_A_const_pool.A[58] }

func A_arbace_j2g_meta_A_clinit_p1() { A_arbace_j2g_meta_A_const_13 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[59]); A_arbace_j2g_meta_A_const_14 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[60]); A_arbace_j2g_meta_A_const_15 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[61]); A_arbace_j2g_meta_A_const_16 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[62]); A_arbace_j2g_meta_A_const_17 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[63]); A_arbace_j2g_meta_A_const_18 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[64]); A_arbace_j2g_meta_A_const_19 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[65]); A_arbace_j2g_meta_A_const_20 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[66]); A_arbace_j2g_meta_A_const_21 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[67]); A_arbace_j2g_meta_A_const_22 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[68]); A_arbace_j2g_meta_A_const_23 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[69]); A_arbace_j2g_meta_A_const_24 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[70]) }

func A_arbace_j2g_meta_A_clinit_p2() { A_arbace_j2g_meta_A_const_25 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[71]); A_arbace_j2g_meta_A_const_26 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[72]); A_arbace_j2g_meta_A_const_27 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[73]); A_arbace_j2g_meta_A_const_28 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[74]); A_arbace_j2g_meta_A_const_29 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[75]); A_arbace_j2g_meta_A_const_30 = A_arbace_j2g_meta_A_const_pool.A[76]; A_arbace_j2g_meta_A_const_31 = A_arbace_j2g_meta_A_const_pool.A[77]; A_arbace_j2g_meta_A_const_32 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[78]); A_arbace_j2g_meta_A_const_33 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[79]); A_arbace_j2g_meta_A_const_34 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[80]); A_arbace_j2g_meta_A_const_35 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[81]); A_arbace_j2g_meta_A_const_36 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[82]) }

func A_arbace_j2g_meta_A_clinit_p3() { A_arbace_j2g_meta_A_const_37 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[83]); A_arbace_j2g_meta_A_const_38 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[84]); A_arbace_j2g_meta_A_const_39 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[85]); A_arbace_j2g_meta_A_const_40 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[86]); A_arbace_j2g_meta_A_const_41 = A_arbace_j2g_meta_A_const_pool.A[87]; A_arbace_j2g_meta_A_const_42 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[88]); A_arbace_j2g_meta_A_const_43 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[89]); A_arbace_j2g_meta_A_const_44 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[90]); A_arbace_j2g_meta_A_const_45 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[91]); A_arbace_j2g_meta_A_const_46 = A_arbace_j2g_meta_A_const_pool.A[92]; A_arbace_j2g_meta_A_const_47 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[93]); A_arbace_j2g_meta_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[94]) }

func A_arbace_j2g_meta_A_clinit_p4() { A_arbace_j2g_meta_A_const_49 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[95]); A_arbace_j2g_meta_A_const_50 = A_arbace_j2g_meta_A_const_pool.A[96]; A_arbace_j2g_meta_A_const_51 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[97]); A_arbace_j2g_meta_A_const_52 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[98]); A_arbace_j2g_meta_A_const_53 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[99]); A_arbace_j2g_meta_A_const_54 = A_arbace_j2g_meta_A_const_pool.A[100]; A_arbace_j2g_meta_A_const_55 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[101]); A_arbace_j2g_meta_A_const_56 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[102]); A_arbace_j2g_meta_A_const_57 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[103]); A_arbace_j2g_meta_A_const_58 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[104]); A_arbace_j2g_meta_A_const_59 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[105]); A_arbace_j2g_meta_A_const_60 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[106]) }

func A_arbace_j2g_meta_A_clinit_p5() { A_arbace_j2g_meta_A_const_61 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[107]); A_arbace_j2g_meta_A_const_62 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[108]); A_arbace_j2g_meta_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[109]); A_arbace_j2g_meta_A_const_64 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[110]); A_arbace_j2g_meta_A_const_65 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[111]); A_arbace_j2g_meta_A_const_66 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[112]); A_arbace_j2g_meta_A_const_67 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[113]); A_arbace_j2g_meta_A_const_68 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[114]); A_arbace_j2g_meta_A_const_69 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[115]); A_arbace_j2g_meta_A_const_70 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[116]); A_arbace_j2g_meta_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[117]); A_arbace_j2g_meta_A_const_72 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[118]) }

func A_arbace_j2g_meta_A_clinit_p6() { A_arbace_j2g_meta_A_const_73 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[119]); A_arbace_j2g_meta_A_const_74 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[120]); A_arbace_j2g_meta_A_const_75 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[121]); A_arbace_j2g_meta_A_const_76 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[122]); A_arbace_j2g_meta_A_const_77 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[123]); A_arbace_j2g_meta_A_const_78 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[124]); A_arbace_j2g_meta_A_const_79 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[125]); A_arbace_j2g_meta_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[126]); A_arbace_j2g_meta_A_const_81 = A_arbace_j2g_meta_A_const_pool.A[127]; A_arbace_j2g_meta_A_const_82 = A_arbace_j2g_meta_A_const_pool.A[128]; A_arbace_j2g_meta_A_const_83 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[129]); A_arbace_j2g_meta_A_const_84 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[130]) }

func A_arbace_j2g_meta_A_clinit_p7() { A_arbace_j2g_meta_A_const_85 = A_arbace_j2g_meta_A_const_pool.A[131]; A_arbace_j2g_meta_A_const_86 = A_arbace_j2g_meta_A_const_pool.A[132]; A_arbace_j2g_meta_A_const_87 = A_arbace_j2g_meta_A_const_pool.A[133]; A_arbace_j2g_meta_A_const_88 = A_arbace_j2g_meta_A_const_pool.A[134]; A_arbace_j2g_meta_A_const_89 = A_arbace_j2g_meta_A_const_pool.A[135]; A_arbace_j2g_meta_A_const_90 = A_arbace_j2g_meta_A_const_pool.A[136]; A_arbace_j2g_meta_A_const_91 = A_arbace_j2g_meta_A_const_pool.A[137]; A_arbace_j2g_meta_A_const_92 = A_arbace_j2g_meta_A_const_pool.A[138]; A_arbace_j2g_meta_A_const_93 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[139]); A_arbace_j2g_meta_A_const_94 = A_arbace_j2g_meta_A_const_pool.A[140]; A_arbace_j2g_meta_A_const_95 = A_arbace_j2g_meta_A_const_pool.A[141]; A_arbace_j2g_meta_A_const_96 = A_arbace_j2g_meta_A_const_pool.A[142]; A_arbace_j2g_meta_A_const_97 = A_arbace_j2g_meta_A_const_pool.A[143]; A_arbace_j2g_meta_A_const_98 = A_arbace_j2g_meta_A_const_pool.A[144]; A_arbace_j2g_meta_A_const_99 = A_arbace_j2g_meta_A_const_pool.A[145] }

func A_arbace_j2g_meta_A_clinit_p8() { A_arbace_j2g_meta_A_const_100 = A_arbace_j2g_meta_A_const_pool.A[146]; A_arbace_j2g_meta_A_const_101 = A_arbace_j2g_meta_A_const_pool.A[147]; A_arbace_j2g_meta_A_const_102 = A_arbace_j2g_meta_A_const_pool.A[148]; A_arbace_j2g_meta_A_const_103 = A_arbace_j2g_meta_A_const_pool.A[149]; A_arbace_j2g_meta_A_const_104 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[150]); A_arbace_j2g_meta_A_const_105 = A_arbace_j2g_meta_A_const_pool.A[151]; A_arbace_j2g_meta_A_const_106 = A_arbace_j2g_meta_A_const_pool.A[152]; A_arbace_j2g_meta_A_const_107 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[153]); A_arbace_j2g_meta_A_const_108 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[154]); A_arbace_j2g_meta_A_const_109 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[155]); A_arbace_j2g_meta_A_const_110 = A_arbace_j2g_meta_A_const_pool.A[156]; A_arbace_j2g_meta_A_const_111 = A_arbace_j2g_meta_A_const_pool.A[157]; A_arbace_j2g_meta_A_const_112 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[158]); A_arbace_j2g_meta_A_const_113 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[159]) }

func A_arbace_j2g_meta_A_clinit_p9() { A_arbace_j2g_meta_A_const_114 = A_arbace_j2g_meta_A_const_pool.A[160]; A_arbace_j2g_meta_A_const_115 = A_arbace_j2g_meta_A_const_pool.A[161]; A_arbace_j2g_meta_A_const_116 = A_arbace_j2g_meta_A_const_pool.A[162]; A_arbace_j2g_meta_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[163]); A_arbace_j2g_meta_A_const_118 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[164]); A_arbace_j2g_meta_A_const_119 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[165]); A_arbace_j2g_meta_A_const_120 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[166]); A_arbace_j2g_meta_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[167]); A_arbace_j2g_meta_A_const_122 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[168]); A_arbace_j2g_meta_A_const_123 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[169]); A_arbace_j2g_meta_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[170]); A_arbace_j2g_meta_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[171]) }

func A_arbace_j2g_meta_A_clinit_p10() { A_arbace_j2g_meta_A_const_126 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[172]); A_arbace_j2g_meta_A_const_127 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[173]); A_arbace_j2g_meta_A_const_128 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[174]); A_arbace_j2g_meta_A_const_129 = A_arbace_j2g_meta_A_const_pool.A[175]; A_arbace_j2g_meta_A_const_130 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[176]); A_arbace_j2g_meta_A_const_131 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[177]); A_arbace_j2g_meta_A_const_132 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[178]); A_arbace_j2g_meta_A_const_133 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[179]); A_arbace_j2g_meta_A_const_134 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[180]); A_arbace_j2g_meta_A_const_135 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[181]); A_arbace_j2g_meta_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[182]); A_arbace_j2g_meta_A_const_137 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[183]) }

func A_arbace_j2g_meta_A_clinit_p11() { A_arbace_j2g_meta_A_const_138 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[184]); A_arbace_j2g_meta_A_const_139 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[185]); A_arbace_j2g_meta_A_const_140 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[186]); A_arbace_j2g_meta_A_const_141 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[187]); A_arbace_j2g_meta_A_const_142 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[188]); A_arbace_j2g_meta_A_const_143 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[189]); A_arbace_j2g_meta_A_const_144 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[190]); A_arbace_j2g_meta_A_const_145 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[191]); A_arbace_j2g_meta_A_const_146 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[192]); A_arbace_j2g_meta_A_const_147 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[193]); A_arbace_j2g_meta_A_const_148 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[194]); A_arbace_j2g_meta_A_const_149 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[195]) }

func A_arbace_j2g_meta_A_clinit_p12() { A_arbace_j2g_meta_A_const_150 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[196]); A_arbace_j2g_meta_A_const_151 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[197]); A_arbace_j2g_meta_A_const_152 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[198]); A_arbace_j2g_meta_A_const_153 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[199]); A_arbace_j2g_meta_A_const_154 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[200]); A_arbace_j2g_meta_A_const_155 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[201]); A_arbace_j2g_meta_A_const_156 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[202]); A_arbace_j2g_meta_A_const_157 = A_arbace_j2g_meta_A_const_pool.A[203]; A_arbace_j2g_meta_A_const_158 = A_arbace_j2g_meta_A_const_pool.A[204]; A_arbace_j2g_meta_A_const_159 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[205]); A_arbace_j2g_meta_A_const_160 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[206]); A_arbace_j2g_meta_A_const_161 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[207]) }

func A_arbace_j2g_meta_A_clinit_p13() { A_arbace_j2g_meta_A_const_162 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[208]); A_arbace_j2g_meta_A_const_163 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[209]); A_arbace_j2g_meta_A_const_164 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[210]); A_arbace_j2g_meta_A_const_165 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[211]); A_arbace_j2g_meta_A_const_166 = lang.Var_Cast(A_arbace_j2g_meta_A_const_pool.A[212]); A_arbace_j2g_meta_A_const_167 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[213]); A_arbace_j2g_meta_A_const_168 = lang.Keyword_Cast(A_arbace_j2g_meta_A_const_pool.A[214]) }

func A_arbace_j2g_meta_A_New() *A_arbace_j2g_meta_A { A_arbace_j2g_meta_A_Init(); t := &A_arbace_j2g_meta_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_meta_A) Ctor() {}

func (t *A_arbace_j2g_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_meta_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_meta_A_class }

func (t *A_arbace_j2g_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_meta_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_meta_A); return ok }

func A_arbace_j2g_meta_A_Cast(x any) *A_arbace_j2g_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_meta_A_class)) }; return v }



type A_arbace_j2g_meta_by_plain_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_by_plain_path_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_fn__849000074_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_by_plain_path_fn__849000074_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A struct{ j2g_header uint64; F_iter__849000054, F_s__849000055 any }

var A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A struct{ j2g_header uint64; F_b__849000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000060_fn__849000064_A_fn_class *jrt.Class



type A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_by_plain_path_iter__849000054__849000058_fn__849000059_fn__849000070_A_fn_class *jrt.Class



type A_arbace_j2g_meta_class_lit_binary_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_class_lit_binary_A_fn_class *jrt.Class



type A_arbace_j2g_meta_classpath_index_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_classpath_index_text_A_fn_class *jrt.Class



type A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_A_fn_class *jrt.Class



type A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A struct{ j2g_header uint64; F_iter__849000012, F_s__849000013 any }

var A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_A_fn_class *jrt.Class



type A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A struct{ j2g_header uint64; F_b__849000015 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_classpath_index_text_iter__849000012__849000016_fn__849000017_fn__849000018_A_fn_class *jrt.Class



type A_arbace_j2g_meta_classpath_property_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_classpath_property_A_fn_class *jrt.Class



type A_arbace_j2g_meta_condition_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_condition_of_A_fn_class *jrt.Class



type A_arbace_j2g_meta_const_string_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_const_string_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_data_metadata_roots_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A struct{ j2g_header uint64; F_data any }

var A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A struct{ j2g_header uint64; F_data, F_iter__849000336, F_s__849000337 any }

var A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A struct{ j2g_header uint64; F_data any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__849000339 any }

var A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A struct{ j2g_header uint64; F_data, F_p any }

var A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000342_fn__849000343_A_fn_class *jrt.Class



type A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A struct{ j2g_header uint64; F_data, F_p any }

var A_arbace_j2g_meta_data_metadata_roots_iter__849000336__849000340_fn__849000341_fn__849000346_A_fn_class *jrt.Class



type A_arbace_j2g_meta_distinct_by_first_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_distinct_by_first_A_fn_class *jrt.Class



type A_arbace_j2g_meta_eval849000004_A struct{ jrt.Object }

func A_arbace_j2g_meta_eval849000004_A_New() *A_arbace_j2g_meta_eval849000004_A { t := &A_arbace_j2g_meta_eval849000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_meta_eval849000004_A) Ctor() {}

func (t *A_arbace_j2g_meta_eval849000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_meta_eval849000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_meta_eval849000004_A_class }

func (t *A_arbace_j2g_meta_eval849000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_meta_eval849000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_meta_eval849000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_meta_eval849000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_meta_eval849000004_A); return ok }

func A_arbace_j2g_meta_eval849000004_A_Cast(x any) *A_arbace_j2g_meta_eval849000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_meta_eval849000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_meta_eval849000004_A_class)) }; return v }



type A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_eval849000004_loading__1927001464__auto____849000005_A_fn_class *jrt.Class



type A_arbace_j2g_meta_eval849000008_A struct{ jrt.Object }

func A_arbace_j2g_meta_eval849000008_A_New() *A_arbace_j2g_meta_eval849000008_A { t := &A_arbace_j2g_meta_eval849000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_meta_eval849000008_A) Ctor() {}

func (t *A_arbace_j2g_meta_eval849000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_meta_eval849000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_meta_eval849000008_A_class }

func (t *A_arbace_j2g_meta_eval849000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_meta_eval849000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_meta_eval849000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_meta_eval849000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_meta_eval849000008_A); return ok }

func A_arbace_j2g_meta_eval849000008_A_Cast(x any) *A_arbace_j2g_meta_eval849000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_meta_eval849000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_meta_eval849000008_A_class)) }; return v }



type A_arbace_j2g_meta_eval849000008_fn__849000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_eval849000008_fn__849000009_A_fn_class *jrt.Class



type A_arbace_j2g_meta_internal_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_internal_A_fn_class *jrt.Class



type A_arbace_j2g_meta_java_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_java_name_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_java_name_QMARK__fn__849000078_A_fn_class *jrt.Class



type A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_java_name_QMARK__fn__849000078_fn__849000079_A_fn_class *jrt.Class



type A_arbace_j2g_meta_json_fail_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_json_fail_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_path_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_path_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_roots_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_bundles__849000323_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_roots_bundles__849000323_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A struct{ j2g_header uint64; F_iter__849000324, F_s__849000325 any }

var A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__849000327, F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_metadata_roots_bundles__849000323_iter__849000324__849000328_fn__849000329_fn__849000330_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_entries__849000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_roots_entries__849000311_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A struct{ j2g_header uint64; F_iter__849000312, F_s__849000313 any }

var A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_A_fn_class *jrt.Class



type A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__849000315, F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_metadata_roots_entries__849000311_iter__849000312__849000316_fn__849000317_fn__849000318_A_fn_class *jrt.Class



type A_arbace_j2g_meta_names_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_names_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_meta_owners_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_owners_text_A_fn_class *jrt.Class



type A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_owners_text_iter__849000029__849000033_A_fn_class *jrt.Class



type A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A struct{ j2g_header uint64; F_s__849000030, F_iter__849000029 any }

var A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_A_fn_class *jrt.Class



type A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A struct{ j2g_header uint64; F_b__849000032 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_owners_text_iter__849000029__849000033_fn__849000034_fn__849000035_A_fn_class *jrt.Class



type A_arbace_j2g_meta_parse_services_file_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_parse_services_file_A_fn_class *jrt.Class



type A_arbace_j2g_meta_present_specs_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_present_specs_A_fn_class *jrt.Class



type A_arbace_j2g_meta_present_specs_fn__849000428_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_present_specs_fn__849000428_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_json_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_read_json_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_json_value__849000279_A struct{ j2g_header uint64; F_n int32; F_s, F_ws any }

var A_arbace_j2g_meta_read_json_value__849000279_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A struct{ j2g_header uint64; F_i any; F_n int32; F_s any }

var A_arbace_j2g_meta_read_json_value__849000279_fn__849000291_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_json_ws__849000277_A struct{ j2g_header uint64; F_n int32; F_s any }

var A_arbace_j2g_meta_read_json_ws__849000277_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_provides_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_read_provides_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_read_provides_iter__849000095__849000099_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A struct{ j2g_header uint64; F_iter__849000095, F_s__849000096 any }

var A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_A_fn_class *jrt.Class



type A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A struct{ j2g_header uint64; F_b__849000098 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_read_provides_iter__849000095__849000099_fn__849000100_fn__849000101_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflection_specs_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflection_specs_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_meta_reflection_specs_all_QMARK___849000298_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A struct{ j2g_header uint64; F_c any }

var A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A struct{ j2g_header uint64; F_c, F_iter__849000300, F_s__849000301 any }

var A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A struct{ j2g_header uint64; F_c, F_b__849000303 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_reflection_specs_iter__849000300__849000304_fn__849000305_fn__849000306_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflective_sites_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A struct{ j2g_header uint64; F_s__849000360, F_iter__849000359 any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_fn__849000377_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A struct{ j2g_header uint64; F_iter__849000361, F_s__849000362, F_n any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A struct{ j2g_header uint64; F_n, F_b__849000364 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A struct{ j2g_header uint64; F_node any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000369_fn__849000370_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A struct{ j2g_header uint64; F_node any }

var A_arbace_j2g_meta_reflective_sites_iter__849000359__849000365_fn__849000366_iter__849000361__849000367_fn__849000368_fn__849000373_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A struct{ j2g_header uint64; F_iter__849000381, F_s__849000382 any }

var A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A struct{ j2g_header uint64; F_iter__849000383, F_s__849000384, F_n any }

var A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A struct{ j2g_header uint64; F_n, F_b__849000386 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_reflective_sites_iter__849000381__849000387_fn__849000388_iter__849000383__849000395_fn__849000396_fn__849000397_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A struct{ j2g_header uint64; F_iter__849000403, F_s__849000404 any }

var A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_A_fn_class *jrt.Class



type A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__849000406 any }

var A_arbace_j2g_meta_reflective_sites_iter__849000403__849000407_fn__849000408_fn__849000409_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_refusals_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_A struct{ j2g_header uint64; F_refused_tops, F_unavailable any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A struct{ j2g_header uint64; F_refused_tops, F_iter__849000434, F_unavailable, F_s__849000435 any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A struct{ j2g_header uint64; F_refused_tops, F_unavailable any; F_size__1927001038__auto__ int32; F_b__849000437, F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A struct{ j2g_header uint64; F_refused_tops, F_n any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A struct{ j2g_header uint64; F_iter__849000444, F_refused_tops, F_n, F_s__849000445 any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A struct{ j2g_header uint64; F_refused_tops, F_n any; F_size__1927001038__auto__ int32; F_b__849000447, F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000450_fn__849000454_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_fn__849000440_iter__849000444__849000448_fn__849000449_fn__849000460_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A struct{ j2g_header uint64; F_n, F_refused_tops any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A struct{ j2g_header uint64; F_n, F_refused_tops, F_iter__849000468, F_s__849000469 any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A struct{ j2g_header uint64; F_n, F_refused_tops, F_b__849000471 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000474_fn__849000478_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_meta_refusals_iter__849000434__849000438_fn__849000439_iter__849000468__849000472_fn__849000473_fn__849000484_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000490__849000494_A struct{ j2g_header uint64; F_s any }

var A_arbace_j2g_meta_refusals_iter__849000490__849000494_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A struct{ j2g_header uint64; F_iter__849000490, F_s__849000491, F_s any }

var A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_A_fn_class *jrt.Class



type A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A struct{ j2g_header uint64; F_s, F_b__849000493 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_refusals_iter__849000490__849000494_fn__849000495_fn__849000496_A_fn_class *jrt.Class



type A_arbace_j2g_meta_root_path_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_root_path_A_fn_class *jrt.Class



type A_arbace_j2g_meta_roots_index_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_roots_index_text_A_fn_class *jrt.Class



type A_arbace_j2g_meta_roots_index_text_fn__849000257_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_roots_index_text_fn__849000257_A_fn_class *jrt.Class



type A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A struct{ j2g_header uint64; F_names any }

var A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_A_fn_class *jrt.Class



type A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A struct{ j2g_header uint64; F_iter__849000262, F_names, F_s__849000263 any }

var A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_A_fn_class *jrt.Class



type A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A struct{ j2g_header uint64; F_names, F_b__849000265 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_roots_index_text_iter__849000262__849000266_fn__849000267_fn__849000268_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_service_roots_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_service_roots_iter__849000227__849000231_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A struct{ j2g_header uint64; F_iter__849000227, F_s__849000228 any }

var A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A struct{ j2g_header uint64; F_b__849000230 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000233_fn__849000238_A_fn_class *jrt.Class



type A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_service_roots_iter__849000227__849000231_fn__849000232_fn__849000248_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000116_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_fn__849000116_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_A struct{ j2g_header uint64; F_data any }

var A_arbace_j2g_meta_services_fn__849000123_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A struct{ j2g_header uint64; F_data, F_s any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A struct{ j2g_header uint64; F_iter__849000138, F_s__849000139 any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A struct{ j2g_header uint64; F_b__849000141 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000138__849000142_fn__849000143_fn__849000144_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A struct{ j2g_header uint64; F_path any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A struct{ j2g_header uint64; F_path, F_iter__849000148, F_s__849000149 any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A struct{ j2g_header uint64; F_path, F_b__849000151 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_services_fn__849000123_fn__849000131_iter__849000148__849000152_fn__849000153_fn__849000154_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_iter__849000160__849000164_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_iter__849000160__849000164_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A struct{ j2g_header uint64; F_iter__849000160, F_s__849000161 any }

var A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A struct{ j2g_header uint64; F_b__849000163 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000166_fn__849000171_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_iter__849000160__849000164_fn__849000165_fn__849000181_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_path_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_path_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_text_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_iter__849000200__849000206_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_services_text_iter__849000200__849000206_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A struct{ j2g_header uint64; F_iter__849000200, F_s__849000201 any }

var A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A struct{ j2g_header uint64; F_s any }

var A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A struct{ j2g_header uint64; F_iter__849000202, F_s, F_s__849000203 any }

var A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_A_fn_class *jrt.Class



type A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A struct{ j2g_header uint64; F_s any; F_size__1927001038__auto__ int32; F_b__849000205, F_c__1927001037__auto__ any }

var A_arbace_j2g_meta_services_text_iter__849000200__849000206_fn__849000207_iter__849000202__849000211_fn__849000212_fn__849000213_A_fn_class *jrt.Class



type A_arbace_j2g_meta_site_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_site_roots_A_fn_class *jrt.Class



type A_arbace_j2g_meta_spec_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_spec_class_A_fn_class *jrt.Class



type A_arbace_j2g_meta_top_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_top_of_A_fn_class *jrt.Class



type A_arbace_j2g_meta_unroot_A struct{ j2g_header uint64 }

var A_arbace_j2g_meta_unroot_A_fn_class *jrt.Class
