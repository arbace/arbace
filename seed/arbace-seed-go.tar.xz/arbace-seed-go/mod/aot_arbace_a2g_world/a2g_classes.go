//line a2g_classes.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_world_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_A_New()}; return nil }

var A_arbace_a2g_world_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_world_A_new}

var A_arbace_a2g_world_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_A"})

func init() { i := A_arbace_a2g_world_A_class.Info(); i.IsInstance = A_arbace_a2g_world_A_InstanceOf; i.Init = A_arbace_a2g_world_A_Init; i.Table = A_arbace_a2g_world_A_members; jrt.RegisterGoType(A_arbace_a2g_world_A_class, reflect.TypeFor[A_arbace_a2g_world_A]()) }

func A_arbace_a2g_world_apply_variant_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_a2g_world_apply_variant_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_world_apply_variant_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_A_New()}; return nil }

func A_arbace_a2g_world_apply_variant_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_A_invoke, New: A_arbace_a2g_world_apply_variant_A_new, Get: A_arbace_a2g_world_apply_variant_A_get}

var A_arbace_a2g_world_apply_variant_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "apply_variant", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_A_Init; i.Table = A_arbace_a2g_world_apply_variant_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000127_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000127_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000127_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000127_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000127_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_apply_variant_A_class, Simple: "fn__1607000127", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000127_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000127_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000127_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000127_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000127_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000127_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000127_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000129_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000129_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000129_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000129_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000129_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000129_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000129_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000129", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_apply_variant_A_class, Simple: "fn__1607000129", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000129_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000129_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000129_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000129_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000129_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000129_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000129_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_apply_variant_fn__1607000129_A_class, Simple: "fn__1607000131", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_apply_variant_fn__1607000129_A_class, Simple: "fn__1607000133", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_apply_variant_fn__1607000129_A_class, Simple: "fn__1607000135", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A]()) }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_apply_variant_fn__1607000138_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_apply_variant_fn__1607000138_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class)}; return nil }

var A_arbace_a2g_world_apply_variant_fn__1607000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_apply_variant_fn__1607000138_A_invoke, New: A_arbace_a2g_world_apply_variant_fn__1607000138_A_new, Get: A_arbace_a2g_world_apply_variant_fn__1607000138_A_get}

var A_arbace_a2g_world_apply_variant_fn__1607000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$apply_variant$fn__1607000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_apply_variant_A_class, Simple: "fn__1607000138", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_apply_variant_fn__1607000138_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_apply_variant_fn__1607000138_A_class.Info(); i.IsInstance = A_arbace_a2g_world_apply_variant_fn__1607000138_A_InstanceOf; i.Init = A_arbace_a2g_world_apply_variant_fn__1607000138_A_Init; i.Table = A_arbace_a2g_world_apply_variant_fn__1607000138_A_members; jrt.RegisterGoType(A_arbace_a2g_world_apply_variant_fn__1607000138_A_class, reflect.TypeFor[A_arbace_a2g_world_apply_variant_fn__1607000138_A]()) }

func A_arbace_a2g_world_class_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_form_QMARK__A_New()}; return nil }

func A_arbace_a2g_world_class_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_form_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_world_class_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_form_QMARK__A_invoke, New: A_arbace_a2g_world_class_form_QMARK__A_new, Get: A_arbace_a2g_world_class_form_QMARK__A_get}

var A_arbace_a2g_world_class_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "class_form_QMARK_", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_form_QMARK__A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_form_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_world_class_form_QMARK__A_Init; i.Table = A_arbace_a2g_world_class_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_form_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_world_class_form_QMARK__A]()) }

func A_arbace_a2g_world_class_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_A_New()}; return nil }

func A_arbace_a2g_world_class_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_A_invoke, New: A_arbace_a2g_world_class_forms_A_new, Get: A_arbace_a2g_world_class_forms_A_get}

var A_arbace_a2g_world_class_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "class_forms", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_A_Init; i.Table = A_arbace_a2g_world_class_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_A]()) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_New()}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_invoke, New: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_new, Get: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_get}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms$iter__1607000019__1607000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_class_forms_A_class, Simple: "iter__1607000019__1607000025", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_Init; i.Table = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A]()) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_invoke, New: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_new, Get: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_get}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class, Simple: "fn__1607000026", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_Init; i.Table = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A]()) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_New()}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_invoke, New: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_new, Get: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_get}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class, Simple: "iter__1607000021__1607000027", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_Init; i.Table = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A]()) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_invoke, New: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_new, Get: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_get}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class, Simple: "fn__1607000028", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_Init; i.Table = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A]()) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_invoke, New: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_new, Get: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_get}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028$fn__1607000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class, Simple: "fn__1607000029", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_InstanceOf; i.Init = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_Init; i.Table = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_class, reflect.TypeFor[A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A]()) }

func A_arbace_a2g_world_class_parts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_class_parts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_class_parts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_class_parts_A_New()}; return nil }

func A_arbace_a2g_world_class_parts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_class_parts_A_fn_class)}; return nil }

var A_arbace_a2g_world_class_parts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_class_parts_A_invoke, New: A_arbace_a2g_world_class_parts_A_new, Get: A_arbace_a2g_world_class_parts_A_get}

var A_arbace_a2g_world_class_parts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$class_parts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "class_parts", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_class_parts_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_class_parts_A_class.Info(); i.IsInstance = A_arbace_a2g_world_class_parts_A_InstanceOf; i.Init = A_arbace_a2g_world_class_parts_A_Init; i.Table = A_arbace_a2g_world_class_parts_A_members; jrt.RegisterGoType(A_arbace_a2g_world_class_parts_A_class, reflect.TypeFor[A_arbace_a2g_world_class_parts_A]()) }

func A_arbace_a2g_world_cut_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_cut_key_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_cut_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_cut_key_A_New()}; return nil }

func A_arbace_a2g_world_cut_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_cut_key_A_fn_class)}; return nil }

var A_arbace_a2g_world_cut_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_cut_key_A_invoke, New: A_arbace_a2g_world_cut_key_A_new, Get: A_arbace_a2g_world_cut_key_A_get}

var A_arbace_a2g_world_cut_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$cut_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "cut_key", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_cut_key_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_cut_key_A_class.Info(); i.IsInstance = A_arbace_a2g_world_cut_key_A_InstanceOf; i.Init = A_arbace_a2g_world_cut_key_A_Init; i.Table = A_arbace_a2g_world_cut_key_A_members; jrt.RegisterGoType(A_arbace_a2g_world_cut_key_A_class, reflect.TypeFor[A_arbace_a2g_world_cut_key_A]()) }

func A_arbace_a2g_world_eval1607000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_eval1607000004_A_New()}; return nil }

var A_arbace_a2g_world_eval1607000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_world_eval1607000004_A_new}

var A_arbace_a2g_world_eval1607000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$eval1607000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_world_A_class, Simple: "eval1607000004", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_eval1607000004_A"})

func init() { i := A_arbace_a2g_world_eval1607000004_A_class.Info(); i.IsInstance = A_arbace_a2g_world_eval1607000004_A_InstanceOf; i.Table = A_arbace_a2g_world_eval1607000004_A_members; jrt.RegisterGoType(A_arbace_a2g_world_eval1607000004_A_class, reflect.TypeFor[A_arbace_a2g_world_eval1607000004_A]()) }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New()}; return nil }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class)}; return nil }

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_invoke, New: A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_new, Get: A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_get}

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$eval1607000004$loading__1927001464__auto____1607000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_eval1607000004_A_class, Simple: "loading__1927001464__auto____1607000005", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_class.Info(); i.IsInstance = A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_InstanceOf; i.Init = A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_Init; i.Table = A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_members; jrt.RegisterGoType(A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_class, reflect.TypeFor[A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A]()) }

func A_arbace_a2g_world_eval1607000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_eval1607000008_A_New()}; return nil }

var A_arbace_a2g_world_eval1607000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_world_eval1607000008_A_new}

var A_arbace_a2g_world_eval1607000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$eval1607000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_world_A_class, Simple: "eval1607000008", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_eval1607000008_A"})

func init() { i := A_arbace_a2g_world_eval1607000008_A_class.Info(); i.IsInstance = A_arbace_a2g_world_eval1607000008_A_InstanceOf; i.Table = A_arbace_a2g_world_eval1607000008_A_members; jrt.RegisterGoType(A_arbace_a2g_world_eval1607000008_A_class, reflect.TypeFor[A_arbace_a2g_world_eval1607000008_A]()) }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_eval1607000008_fn__1607000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New()}; return nil }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class)}; return nil }

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_eval1607000008_fn__1607000009_A_invoke, New: A_arbace_a2g_world_eval1607000008_fn__1607000009_A_new, Get: A_arbace_a2g_world_eval1607000008_fn__1607000009_A_get}

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$eval1607000008$fn__1607000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_eval1607000008_A_class, Simple: "fn__1607000009", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_eval1607000008_fn__1607000009_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_eval1607000008_fn__1607000009_A_class.Info(); i.IsInstance = A_arbace_a2g_world_eval1607000008_fn__1607000009_A_InstanceOf; i.Init = A_arbace_a2g_world_eval1607000008_fn__1607000009_A_Init; i.Table = A_arbace_a2g_world_eval1607000008_fn__1607000009_A_members; jrt.RegisterGoType(A_arbace_a2g_world_eval1607000008_fn__1607000009_A_class, reflect.TypeFor[A_arbace_a2g_world_eval1607000008_fn__1607000009_A]()) }

func A_arbace_a2g_world_head_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_head_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_head_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_head_name_A_New()}; return nil }

func A_arbace_a2g_world_head_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_head_name_A_fn_class)}; return nil }

var A_arbace_a2g_world_head_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_head_name_A_invoke, New: A_arbace_a2g_world_head_name_A_new, Get: A_arbace_a2g_world_head_name_A_get}

var A_arbace_a2g_world_head_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$head_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "head_name", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_head_name_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_head_name_A_class.Info(); i.IsInstance = A_arbace_a2g_world_head_name_A_InstanceOf; i.Init = A_arbace_a2g_world_head_name_A_Init; i.Table = A_arbace_a2g_world_head_name_A_members; jrt.RegisterGoType(A_arbace_a2g_world_head_name_A_class, reflect.TypeFor[A_arbace_a2g_world_head_name_A]()) }

func A_arbace_a2g_world_id_space_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_id_space_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_id_space_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_id_space_A_New()}; return nil }

func A_arbace_a2g_world_id_space_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_id_space_A_fn_class)}; return nil }

var A_arbace_a2g_world_id_space_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_id_space_A_invoke, New: A_arbace_a2g_world_id_space_A_new, Get: A_arbace_a2g_world_id_space_A_get}

var A_arbace_a2g_world_id_space_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$id_space", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "id_space", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_id_space_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_id_space_A_class.Info(); i.IsInstance = A_arbace_a2g_world_id_space_A_InstanceOf; i.Init = A_arbace_a2g_world_id_space_A_Init; i.Table = A_arbace_a2g_world_id_space_A_members; jrt.RegisterGoType(A_arbace_a2g_world_id_space_A_class, reflect.TypeFor[A_arbace_a2g_world_id_space_A]()) }

func A_arbace_a2g_world_load_world_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_load_world_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_A_New()}; return nil }

func A_arbace_a2g_world_load_world_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_A_invoke, New: A_arbace_a2g_world_load_world_A_new, Get: A_arbace_a2g_world_load_world_A_get}

var A_arbace_a2g_world_load_world_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "load_world", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_A_Init; i.Table = A_arbace_a2g_world_load_world_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000158_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000158_A_New()}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000158_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000158_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000158_A_get}

var A_arbace_a2g_world_load_world_fn__1607000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "fn__1607000158", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000158_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000158_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000158_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000158_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000158_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000158_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000158_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000161_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000161_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000161_A_New()}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000161_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000161_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000161_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000161_A_get}

var A_arbace_a2g_world_load_world_fn__1607000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "fn__1607000161", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000161_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000161_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000161_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000161_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000161_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000161_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000161_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "fn__1607000169", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$analyze_BANG___1607000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "analyze_BANG___1607000260", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_New()}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$compiled_QMARK___1607000263", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "compiled_QMARK___1607000263", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000176", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class, Simple: "fn__1607000185", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185$fn__1607000189", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class, Simple: "fn__1607000189", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class, Simple: "fn__1607000192", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192$fn__1607000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class, Simple: "fn__1607000196", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000202", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000202", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class, Simple: "fn__1607000211", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211$fn__1607000215", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class, Simple: "fn__1607000215", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class, Simple: "fn__1607000218", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218$fn__1607000222", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class, Simple: "fn__1607000222", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000232", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000232", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000234", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000240", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000240", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000242", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000242", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000248", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000250", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000256", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000258", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000258", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000266", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000266", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000294", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000294", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$fn__1607000296", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "fn__1607000296", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "iter__1607000270__1607000274", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class, Simple: "fn__1607000275", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275$fn__1607000276", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class, Simple: "fn__1607000276", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "iter__1607000280__1607000284", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class, Simple: "fn__1607000285", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285$fn__1607000286", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class, Simple: "fn__1607000286", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_New()}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "iter__1607000299__1607000303", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class, Simple: "fn__1607000304", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304$fn__1607000305", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class, Simple: "fn__1607000305", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$lap__1607000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "lap__1607000226", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A]()) }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_New()}; return nil }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_invoke, New: A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_new, Get: A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_get}

var A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$fn__1607000169$tops_QMARK___1607000268", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_fn__1607000169_A_class, Simple: "tops_QMARK___1607000268", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_Init; i.Table = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A]()) }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_from_source__1607000167_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_from_source__1607000167_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_from_source__1607000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_from_source__1607000167_A_invoke, New: A_arbace_a2g_world_load_world_from_source__1607000167_A_new, Get: A_arbace_a2g_world_load_world_from_source__1607000167_A_get}

var A_arbace_a2g_world_load_world_from_source__1607000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$from_source__1607000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "from_source__1607000167", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_from_source__1607000167_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_from_source__1607000167_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_from_source__1607000167_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_from_source__1607000167_A_Init; i.Table = A_arbace_a2g_world_load_world_from_source__1607000167_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_from_source__1607000167_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_from_source__1607000167_A]()) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_New()}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_invoke, New: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_new, Get: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_get}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$iter__1607000320__1607000326", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "iter__1607000320__1607000326", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_Init; i.Table = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A]()) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_invoke, New: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_new, Get: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_get}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class, Simple: "fn__1607000327", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_Init; i.Table = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A]()) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_invoke, New: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_new, Get: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_get}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class, Simple: "iter__1607000322__1607000330", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_Init; i.Table = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A]()) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_invoke, New: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_new, Get: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_get}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class, Simple: "fn__1607000331", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_Init; i.Table = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A]()) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_invoke, New: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_new, Get: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_get}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331$fn__1607000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class, Simple: "fn__1607000332", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_Init; i.Table = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A]()) }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_load_world_top_of__1607000165_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_load_world_top_of__1607000165_A_New()}; return nil }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class)}; return nil }

var A_arbace_a2g_world_load_world_top_of__1607000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_load_world_top_of__1607000165_A_invoke, New: A_arbace_a2g_world_load_world_top_of__1607000165_A_new, Get: A_arbace_a2g_world_load_world_top_of__1607000165_A_get}

var A_arbace_a2g_world_load_world_top_of__1607000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$load_world$top_of__1607000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_load_world_A_class, Simple: "top_of__1607000165", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_load_world_top_of__1607000165_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_load_world_top_of__1607000165_A_class.Info(); i.IsInstance = A_arbace_a2g_world_load_world_top_of__1607000165_A_InstanceOf; i.Init = A_arbace_a2g_world_load_world_top_of__1607000165_A_Init; i.Table = A_arbace_a2g_world_load_world_top_of__1607000165_A_members; jrt.RegisterGoType(A_arbace_a2g_world_load_world_top_of__1607000165_A_class, reflect.TypeFor[A_arbace_a2g_world_load_world_top_of__1607000165_A]()) }

func A_arbace_a2g_world_new_unit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_new_unit_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_new_unit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_new_unit_A_New()}; return nil }

func A_arbace_a2g_world_new_unit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_new_unit_A_fn_class)}; return nil }

var A_arbace_a2g_world_new_unit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_new_unit_A_invoke, New: A_arbace_a2g_world_new_unit_A_new, Get: A_arbace_a2g_world_new_unit_A_get}

var A_arbace_a2g_world_new_unit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$new_unit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "new_unit", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_new_unit_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_new_unit_A_class.Info(); i.IsInstance = A_arbace_a2g_world_new_unit_A_InstanceOf; i.Init = A_arbace_a2g_world_new_unit_A_Init; i.Table = A_arbace_a2g_world_new_unit_A_members; jrt.RegisterGoType(A_arbace_a2g_world_new_unit_A_class, reflect.TypeFor[A_arbace_a2g_world_new_unit_A]()) }

func A_arbace_a2g_world_ns_of_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_ns_of_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_ns_of_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_ns_of_forms_A_New()}; return nil }

func A_arbace_a2g_world_ns_of_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_ns_of_forms_A_fn_class)}; return nil }

var A_arbace_a2g_world_ns_of_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_ns_of_forms_A_invoke, New: A_arbace_a2g_world_ns_of_forms_A_new, Get: A_arbace_a2g_world_ns_of_forms_A_get}

var A_arbace_a2g_world_ns_of_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$ns_of_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "ns_of_forms", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_ns_of_forms_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_ns_of_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_world_ns_of_forms_A_InstanceOf; i.Init = A_arbace_a2g_world_ns_of_forms_A_Init; i.Table = A_arbace_a2g_world_ns_of_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_world_ns_of_forms_A_class, reflect.TypeFor[A_arbace_a2g_world_ns_of_forms_A]()) }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_ns_of_forms_fn__1607000037_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_New()}; return nil }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class)}; return nil }

var A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_invoke, New: A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_new, Get: A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_get}

var A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$ns_of_forms$fn__1607000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_ns_of_forms_A_class, Simple: "fn__1607000037", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_ns_of_forms_fn__1607000037_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_class.Info(); i.IsInstance = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_InstanceOf; i.Init = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_Init; i.Table = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_members; jrt.RegisterGoType(A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_class, reflect.TypeFor[A_arbace_a2g_world_ns_of_forms_fn__1607000037_A]()) }

func A_arbace_a2g_world_param_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_param_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_A_New()}; return nil }

func A_arbace_a2g_world_param_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_A_invoke, New: A_arbace_a2g_world_param_key_A_new, Get: A_arbace_a2g_world_param_key_A_get}

var A_arbace_a2g_world_param_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "param_key", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_A_Init; i.Table = A_arbace_a2g_world_param_key_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000089_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000089_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000089_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000089_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000089_A_get}

var A_arbace_a2g_world_param_key_fn__1607000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000089", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000089_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000089_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000089_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000089_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000089_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000089_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000089_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000091_A_New()}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000091_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000091_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000091_A_get}

var A_arbace_a2g_world_param_key_fn__1607000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000091", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000091_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000091_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000091_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000091_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000091_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000091_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000091_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000097_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000097_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000097_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000097_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000097_A_get}

var A_arbace_a2g_world_param_key_fn__1607000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000097", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000097_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000097_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000097_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000097_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000097_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000097_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000097_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000099_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000099_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000099_A_New()}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000099_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000099_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000099_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000099_A_get}

var A_arbace_a2g_world_param_key_fn__1607000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000099", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000099_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000099_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000099_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000099_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000099_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000099_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000099_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000105_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000105_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000105_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000105_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000105_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000105_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000105_A_get}

var A_arbace_a2g_world_param_key_fn__1607000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000105", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000105_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000105_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000105_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000105_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000105_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000105_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000105_A]()) }

func A_arbace_a2g_world_param_key_fn__1607000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_param_key_fn__1607000107_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_param_key_fn__1607000107_A_New()}; return nil }

func A_arbace_a2g_world_param_key_fn__1607000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class)}; return nil }

var A_arbace_a2g_world_param_key_fn__1607000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_param_key_fn__1607000107_A_invoke, New: A_arbace_a2g_world_param_key_fn__1607000107_A_new, Get: A_arbace_a2g_world_param_key_fn__1607000107_A_get}

var A_arbace_a2g_world_param_key_fn__1607000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$param_key$fn__1607000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_param_key_A_class, Simple: "fn__1607000107", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_param_key_fn__1607000107_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_param_key_fn__1607000107_A_class.Info(); i.IsInstance = A_arbace_a2g_world_param_key_fn__1607000107_A_InstanceOf; i.Init = A_arbace_a2g_world_param_key_fn__1607000107_A_Init; i.Table = A_arbace_a2g_world_param_key_fn__1607000107_A_members; jrt.RegisterGoType(A_arbace_a2g_world_param_key_fn__1607000107_A_class, reflect.TypeFor[A_arbace_a2g_world_param_key_fn__1607000107_A]()) }

func A_arbace_a2g_world_read_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_read_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_forms_A_New()}; return nil }

func A_arbace_a2g_world_read_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_forms_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_forms_A_invoke, New: A_arbace_a2g_world_read_forms_A_new, Get: A_arbace_a2g_world_read_forms_A_get}

var A_arbace_a2g_world_read_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "read_forms", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_forms_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_forms_A_InstanceOf; i.Init = A_arbace_a2g_world_read_forms_A_Init; i.Table = A_arbace_a2g_world_read_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_forms_A_class, reflect.TypeFor[A_arbace_a2g_world_read_forms_A]()) }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_forms_fn__1607000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_forms_fn__1607000013_A_New()}; return nil }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_forms_fn__1607000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_forms_fn__1607000013_A_invoke, New: A_arbace_a2g_world_read_forms_fn__1607000013_A_new, Get: A_arbace_a2g_world_read_forms_fn__1607000013_A_get}

var A_arbace_a2g_world_read_forms_fn__1607000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_forms$fn__1607000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_read_forms_A_class, Simple: "fn__1607000013", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_forms_fn__1607000013_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_forms_fn__1607000013_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_forms_fn__1607000013_A_InstanceOf; i.Init = A_arbace_a2g_world_read_forms_fn__1607000013_A_Init; i.Table = A_arbace_a2g_world_read_forms_fn__1607000013_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_forms_fn__1607000013_A_class, reflect.TypeFor[A_arbace_a2g_world_read_forms_fn__1607000013_A]()) }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_forms_fn__1607000015_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_forms_fn__1607000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_forms_fn__1607000015_A_invoke, New: A_arbace_a2g_world_read_forms_fn__1607000015_A_new, Get: A_arbace_a2g_world_read_forms_fn__1607000015_A_get}

var A_arbace_a2g_world_read_forms_fn__1607000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_forms$fn__1607000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_read_forms_A_class, Simple: "fn__1607000015", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_forms_fn__1607000015_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_forms_fn__1607000015_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_forms_fn__1607000015_A_InstanceOf; i.Init = A_arbace_a2g_world_read_forms_fn__1607000015_A_Init; i.Table = A_arbace_a2g_world_read_forms_fn__1607000015_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_forms_fn__1607000015_A_class, reflect.TypeFor[A_arbace_a2g_world_read_forms_fn__1607000015_A]()) }

func A_arbace_a2g_world_read_variants_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_variants_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_read_variants_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_variants_A_New()}; return nil }

func A_arbace_a2g_world_read_variants_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_variants_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_variants_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_variants_A_invoke, New: A_arbace_a2g_world_read_variants_A_new, Get: A_arbace_a2g_world_read_variants_A_get}

var A_arbace_a2g_world_read_variants_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_variants", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "read_variants", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_variants_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_variants_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_variants_A_InstanceOf; i.Init = A_arbace_a2g_world_read_variants_A_Init; i.Table = A_arbace_a2g_world_read_variants_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_variants_A_class, reflect.TypeFor[A_arbace_a2g_world_read_variants_A]()) }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_variants_fn__1607000144_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_variants_fn__1607000144_A_New()}; return nil }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_variants_fn__1607000144_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_variants_fn__1607000144_A_invoke, New: A_arbace_a2g_world_read_variants_fn__1607000144_A_new, Get: A_arbace_a2g_world_read_variants_fn__1607000144_A_get}

var A_arbace_a2g_world_read_variants_fn__1607000144_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_variants$fn__1607000144", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_read_variants_A_class, Simple: "fn__1607000144", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_variants_fn__1607000144_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_variants_fn__1607000144_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_variants_fn__1607000144_A_InstanceOf; i.Init = A_arbace_a2g_world_read_variants_fn__1607000144_A_Init; i.Table = A_arbace_a2g_world_read_variants_fn__1607000144_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_variants_fn__1607000144_A_class, reflect.TypeFor[A_arbace_a2g_world_read_variants_fn__1607000144_A]()) }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class)}; return nil }

var A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_invoke, New: A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_new, Get: A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_get}

var A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$read_variants$fn__1607000144$fn__1607000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_read_variants_fn__1607000144_A_class, Simple: "fn__1607000145", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_class.Info(); i.IsInstance = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_InstanceOf; i.Init = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_Init; i.Table = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_members; jrt.RegisterGoType(A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_class, reflect.TypeFor[A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A]()) }

func A_arbace_a2g_world_source_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_A_New()}; return nil }

func A_arbace_a2g_world_source_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_A_invoke, New: A_arbace_a2g_world_source_files_A_new, Get: A_arbace_a2g_world_source_files_A_get}

var A_arbace_a2g_world_source_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "source_files", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_A_Init; i.Table = A_arbace_a2g_world_source_files_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_A]()) }

func A_arbace_a2g_world_source_files_fn__1607000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_fn__1607000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_fn__1607000062_A_New()}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_fn__1607000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_fn__1607000062_A_invoke, New: A_arbace_a2g_world_source_files_fn__1607000062_A_new, Get: A_arbace_a2g_world_source_files_fn__1607000062_A_get}

var A_arbace_a2g_world_source_files_fn__1607000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$fn__1607000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_source_files_A_class, Simple: "fn__1607000062", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_fn__1607000062_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_fn__1607000062_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_fn__1607000062_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_fn__1607000062_A_Init; i.Table = A_arbace_a2g_world_source_files_fn__1607000062_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_fn__1607000062_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_fn__1607000062_A]()) }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_New()}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_invoke, New: A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_new, Get: A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_get}

var A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$fn__1607000062$fn__1607000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_source_files_fn__1607000062_A_class, Simple: "fn__1607000063", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_Init; i.Table = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A]()) }

func A_arbace_a2g_world_source_files_fn__1607000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_fn__1607000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_fn__1607000066_A_New()}; return nil }

func A_arbace_a2g_world_source_files_fn__1607000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_fn__1607000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_fn__1607000066_A_invoke, New: A_arbace_a2g_world_source_files_fn__1607000066_A_new, Get: A_arbace_a2g_world_source_files_fn__1607000066_A_get}

var A_arbace_a2g_world_source_files_fn__1607000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$fn__1607000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_source_files_A_class, Simple: "fn__1607000066", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_fn__1607000066_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_fn__1607000066_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_fn__1607000066_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_fn__1607000066_A_Init; i.Table = A_arbace_a2g_world_source_files_fn__1607000066_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_fn__1607000066_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_fn__1607000066_A]()) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_invoke, New: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_new, Get: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_get}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$iter__1607000068__1607000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_source_files_A_class, Simple: "iter__1607000068__1607000074", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_Init; i.Table = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A]()) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_invoke, New: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_new, Get: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_get}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class, Simple: "fn__1607000075", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_Init; i.Table = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A]()) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_New()}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_invoke, New: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_new, Get: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_get}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class, Simple: "iter__1607000070__1607000076", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_Init; i.Table = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A]()) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_invoke, New: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_new, Get: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_get}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class, Simple: "fn__1607000077", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_Init; i.Table = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A]()) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class)}; return nil }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_invoke, New: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_new, Get: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_get}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077$fn__1607000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class, Simple: "fn__1607000078", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_class.Info(); i.IsInstance = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_InstanceOf; i.Init = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_Init; i.Table = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_members; jrt.RegisterGoType(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_class, reflect.TypeFor[A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A]()) }

func A_arbace_a2g_world_top_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_top_names_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_top_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_top_names_A_New()}; return nil }

func A_arbace_a2g_world_top_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_top_names_A_fn_class)}; return nil }

var A_arbace_a2g_world_top_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_top_names_A_invoke, New: A_arbace_a2g_world_top_names_A_new, Get: A_arbace_a2g_world_top_names_A_get}

var A_arbace_a2g_world_top_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$top_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "top_names", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_top_names_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_top_names_A_class.Info(); i.IsInstance = A_arbace_a2g_world_top_names_A_InstanceOf; i.Init = A_arbace_a2g_world_top_names_A_Init; i.Table = A_arbace_a2g_world_top_names_A_members; jrt.RegisterGoType(A_arbace_a2g_world_top_names_A_class, reflect.TypeFor[A_arbace_a2g_world_top_names_A]()) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_New_O(args[0])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class)}; return nil }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_invoke, New: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_new, Get: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_get}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$top_names$iter__1607000040__1607000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_world_top_names_A_class, Simple: "iter__1607000040__1607000044", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class.Info(); i.IsInstance = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_InstanceOf; i.Init = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_Init; i.Table = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_members; jrt.RegisterGoType(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class, reflect.TypeFor[A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A]()) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class)}; return nil }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_invoke, New: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_new, Get: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_get}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class, Simple: "fn__1607000045", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class.Info(); i.IsInstance = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_InstanceOf; i.Init = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_Init; i.Table = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_members; jrt.RegisterGoType(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class, reflect.TypeFor[A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A]()) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class)}; return nil }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_invoke, New: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_new, Get: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_get}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045$fn__1607000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class, Simple: "fn__1607000046", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_class.Info(); i.IsInstance = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_InstanceOf; i.Init = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_Init; i.Table = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_members; jrt.RegisterGoType(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_class, reflect.TypeFor[A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A]()) }

func A_arbace_a2g_world_with_world_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_world_with_world_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_world_with_world_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world_with_world_A_New()}; return nil }

func A_arbace_a2g_world_with_world_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_world_with_world_A_fn_class)}; return nil }

var A_arbace_a2g_world_with_world_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_world_with_world_A_invoke, New: A_arbace_a2g_world_with_world_A_new, Get: A_arbace_a2g_world_with_world_A_get}

var A_arbace_a2g_world_with_world_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world$with_world", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_a2g_world_A_class, Simple: "with_world", Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world_with_world_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world_with_world_A_class.Info(); i.IsInstance = A_arbace_a2g_world_with_world_A_InstanceOf; i.Init = A_arbace_a2g_world_with_world_A_Init; i.Table = A_arbace_a2g_world_with_world_A_members; jrt.RegisterGoType(A_arbace_a2g_world_with_world_A_class, reflect.TypeFor[A_arbace_a2g_world_with_world_A]()) }

func A_arbace_a2g_world__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_world__init_A_Load__O(); case 1: return A_arbace_a2g_world__init_A_Unit0__O(); case 2: return A_arbace_a2g_world__init_A_Unit1__O(); case 3: return A_arbace_a2g_world__init_A_Unit10__O(); case 4: return A_arbace_a2g_world__init_A_Unit11__O(); case 5: return A_arbace_a2g_world__init_A_Unit12__O(); case 6: return A_arbace_a2g_world__init_A_Unit13__O(); case 7: return A_arbace_a2g_world__init_A_Unit14__O(); case 8: return A_arbace_a2g_world__init_A_Unit15__O(); case 9: return A_arbace_a2g_world__init_A_Unit16__O(); case 10: return A_arbace_a2g_world__init_A_Unit17__O(); case 11: return A_arbace_a2g_world__init_A_Unit18__O(); case 12: return A_arbace_a2g_world__init_A_Unit19__O(); case 13: return A_arbace_a2g_world__init_A_Unit2__O(); case 14: return A_arbace_a2g_world__init_A_Unit20__O(); case 15: return A_arbace_a2g_world__init_A_Unit21__O(); case 16: return A_arbace_a2g_world__init_A_Unit22__O(); case 17: return A_arbace_a2g_world__init_A_Unit3__O(); case 18: return A_arbace_a2g_world__init_A_Unit4__O(); case 19: return A_arbace_a2g_world__init_A_Unit5__O(); case 20: return A_arbace_a2g_world__init_A_Unit6__O(); case 21: return A_arbace_a2g_world__init_A_Unit7__O(); case 22: return A_arbace_a2g_world__init_A_Unit8__O(); case 23: return A_arbace_a2g_world__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_world__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_world__init_A_New()}; return nil }

var A_arbace_a2g_world__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_world__init_A_invoke, New: A_arbace_a2g_world__init_A_new}

var A_arbace_a2g_world__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.world__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_world.A_arbace_a2g_world__init_A", Source: "world.ae"})

func init() { i := A_arbace_a2g_world__init_A_class.Info(); i.IsInstance = A_arbace_a2g_world__init_A_InstanceOf; i.Init = A_arbace_a2g_world__init_A_Init; i.Table = A_arbace_a2g_world__init_A_members; jrt.RegisterGoType(A_arbace_a2g_world__init_A_class, reflect.TypeFor[A_arbace_a2g_world__init_A]()) }
