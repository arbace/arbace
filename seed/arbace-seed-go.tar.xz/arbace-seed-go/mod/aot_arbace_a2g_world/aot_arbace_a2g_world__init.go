//line aot_arbace_a2g_world__init.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_world__init_A_Unit0__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_world__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world__init_A_const_1) }
//line :1:1
func A_arbace_a2g_world__init_A_Unit1__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_world__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_world__init_A_Unit2__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_Init(); tmp2 = A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_world__init_A_Unit3__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_world__init_A_const_1)).Equals_O__Z(A_arbace_a2g_world__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_world_eval1607000008_fn__1607000009_A_Init(); tmp2 = A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_world__init_A_Load__O() any { A_arbace_a2g_world__init_A_Init(); A_arbace_a2g_world__init_A_Unit0__O(); A_arbace_a2g_world__init_A_Unit1__O(); A_arbace_a2g_world__init_A_Unit2__O(); A_arbace_a2g_world__init_A_Unit3__O(); A_arbace_a2g_world__init_A_Unit4__O(); A_arbace_a2g_world__init_A_Unit5__O(); A_arbace_a2g_world__init_A_Unit6__O(); A_arbace_a2g_world__init_A_Unit7__O(); A_arbace_a2g_world__init_A_Unit8__O(); A_arbace_a2g_world__init_A_Unit9__O(); A_arbace_a2g_world__init_A_Unit10__O(); A_arbace_a2g_world__init_A_Unit11__O(); A_arbace_a2g_world__init_A_Unit12__O(); A_arbace_a2g_world__init_A_Unit13__O(); A_arbace_a2g_world__init_A_Unit14__O(); A_arbace_a2g_world__init_A_Unit15__O(); A_arbace_a2g_world__init_A_Unit16__O(); A_arbace_a2g_world__init_A_Unit17__O(); A_arbace_a2g_world__init_A_Unit18__O(); A_arbace_a2g_world__init_A_Unit19__O(); A_arbace_a2g_world__init_A_Unit20__O(); A_arbace_a2g_world__init_A_Unit21__O(); A_arbace_a2g_world__init_A_Unit22__O(); return nil }











func A_arbace_a2g_world__init_A_Unit4__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_4; var tmp2 any = A_arbace_a2g_world_read_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_read_forms_A_Init(); tmp3 = A_arbace_a2g_world_read_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_5)); return A_arbace_a2g_world__init_A_const_4.Ref() }




func A_arbace_a2g_world__init_A_Unit5__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_6; var tmp2 any = A_arbace_a2g_world_class_form_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_class_form_QMARK__A_Init(); tmp3 = A_arbace_a2g_world_class_form_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_7)); return A_arbace_a2g_world__init_A_const_6.Ref() }

func A_arbace_a2g_world__init_A_Unit6__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_8; var tmp2 any = A_arbace_a2g_world_class_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_class_forms_A_Init(); tmp3 = A_arbace_a2g_world_class_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_9)); return A_arbace_a2g_world__init_A_const_8.Ref() }





func A_arbace_a2g_world__init_A_Unit7__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_10; var tmp2 any = A_arbace_a2g_world_ns_of_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_ns_of_forms_A_Init(); tmp3 = A_arbace_a2g_world_ns_of_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_11)); return A_arbace_a2g_world__init_A_const_10.Ref() }



func A_arbace_a2g_world__init_A_Unit8__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_12; var tmp2 any = A_arbace_a2g_world_top_names_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_top_names_A_Init(); tmp3 = A_arbace_a2g_world_top_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_13)); return A_arbace_a2g_world__init_A_const_12.Ref() }











func A_arbace_a2g_world__init_A_Unit9__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_14; var tmp2 any = A_arbace_a2g_world_source_files_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_source_files_A_Init(); tmp3 = A_arbace_a2g_world_source_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_15)); return A_arbace_a2g_world__init_A_const_14.Ref() }


















func A_arbace_a2g_world__init_A_Unit10__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_16; var tmp2 any = A_arbace_a2g_world_head_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_head_name_A_Init(); tmp3 = A_arbace_a2g_world_head_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_17)); return A_arbace_a2g_world__init_A_const_16.Ref() }

func A_arbace_a2g_world__init_A_Unit11__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_18; var tmp2 any = A_arbace_a2g_world_param_key_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_param_key_A_Init(); tmp3 = A_arbace_a2g_world_param_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_19)); return A_arbace_a2g_world__init_A_const_18.Ref() }


























func A_arbace_a2g_world__init_A_Unit12__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(94, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_20; var tmp2 any = A_arbace_a2g_world_cut_key_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_cut_key_A_Init(); tmp3 = A_arbace_a2g_world_cut_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_21)); return A_arbace_a2g_world__init_A_const_20.Ref() }







func A_arbace_a2g_world__init_A_Unit13__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_22; var tmp2 any = A_arbace_a2g_world_class_parts_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_class_parts_A_Init(); tmp3 = A_arbace_a2g_world_class_parts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_23)); return A_arbace_a2g_world__init_A_const_22.Ref() }







func A_arbace_a2g_world__init_A_Unit14__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(110, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_24; var tmp2 any = A_arbace_a2g_world_apply_variant_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_apply_variant_A_Init(); tmp3 = A_arbace_a2g_world_apply_variant_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_25)); return A_arbace_a2g_world__init_A_const_24.Ref() }














































func A_arbace_a2g_world__init_A_Unit15__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(157, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_26; var tmp2 any = A_arbace_a2g_world_read_variants_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_read_variants_A_Init(); tmp3 = A_arbace_a2g_world_read_variants_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_27)); return A_arbace_a2g_world__init_A_const_26.Ref() }




















func A_arbace_a2g_world__init_A_Unit16__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_28; var tmp2 any = A_arbace_a2g_world_new_unit_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_new_unit_A_Init(); tmp3 = A_arbace_a2g_world_new_unit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_29)); return A_arbace_a2g_world__init_A_const_28.Ref() }



func A_arbace_a2g_world__init_A_Unit17__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); jrt.NN(A_arbace_a2g_world__init_A_const_30).BindRoot_O__V(A_arbace_a2g_world__init_A_const_31); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_32)); return A_arbace_a2g_world__init_A_const_30.Ref() }




func A_arbace_a2g_world__init_A_Unit18__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(187, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_33; var tmp2 any = A_arbace_a2g_world_id_space_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_id_space_A_Init(); tmp3 = A_arbace_a2g_world_id_space_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_34)); return A_arbace_a2g_world__init_A_const_33.Ref() }




func A_arbace_a2g_world__init_A_Unit19__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(192, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_35; var tmp2 any = A_arbace_a2g_world_load_world_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_load_world_A_Init(); tmp3 = A_arbace_a2g_world_load_world_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_36)); return A_arbace_a2g_world__init_A_const_35.Ref() }





















































































































func A_arbace_a2g_world__init_A_Unit20__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(310, 1); var tmp1 *lang.Var = A_arbace_a2g_world__init_A_const_37; var tmp2 any = A_arbace_a2g_world_with_world_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_world_with_world_A_Init(); tmp3 = A_arbace_a2g_world_with_world_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_a2g_world__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_world__init_A_const_38)); return A_arbace_a2g_world__init_A_const_37.Ref() }
//line :310:1
func A_arbace_a2g_world__init_A_Unit21__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(310, 1); jrt.NN(A_arbace_a2g_world__init_A_const_37).SetMacro__V(); return nil }
//line :310:1
func A_arbace_a2g_world__init_A_Unit22__O() any { A_arbace_a2g_world__init_A_Init(); lang.Compiler_AOT_At_I_I__V(310, 1); return A_arbace_a2g_world__init_A_const_37.Ref() }







type A_arbace_a2g_world__init_A struct{ jrt.Object }

var A_arbace_a2g_world__init_A_const_0 *lang.Var

var A_arbace_a2g_world__init_A_const_1 any

var A_arbace_a2g_world__init_A_const_2 any

var A_arbace_a2g_world__init_A_const_3 any

var A_arbace_a2g_world__init_A_const_4 *lang.Var

var A_arbace_a2g_world__init_A_const_5 any

var A_arbace_a2g_world__init_A_const_6 *lang.Var

var A_arbace_a2g_world__init_A_const_7 any

var A_arbace_a2g_world__init_A_const_8 *lang.Var

var A_arbace_a2g_world__init_A_const_9 any

var A_arbace_a2g_world__init_A_const_10 *lang.Var

var A_arbace_a2g_world__init_A_const_11 any

var A_arbace_a2g_world__init_A_const_12 *lang.Var

var A_arbace_a2g_world__init_A_const_13 any

var A_arbace_a2g_world__init_A_const_14 *lang.Var

var A_arbace_a2g_world__init_A_const_15 any

var A_arbace_a2g_world__init_A_const_16 *lang.Var

var A_arbace_a2g_world__init_A_const_17 any

var A_arbace_a2g_world__init_A_const_18 *lang.Var

var A_arbace_a2g_world__init_A_const_19 any

var A_arbace_a2g_world__init_A_const_20 *lang.Var

var A_arbace_a2g_world__init_A_const_21 any

var A_arbace_a2g_world__init_A_const_22 *lang.Var

var A_arbace_a2g_world__init_A_const_23 any

var A_arbace_a2g_world__init_A_const_24 *lang.Var

var A_arbace_a2g_world__init_A_const_25 any

var A_arbace_a2g_world__init_A_const_26 *lang.Var

var A_arbace_a2g_world__init_A_const_27 any

var A_arbace_a2g_world__init_A_const_28 *lang.Var

var A_arbace_a2g_world__init_A_const_29 any

var A_arbace_a2g_world__init_A_const_30 *lang.Var

var A_arbace_a2g_world__init_A_const_31 any

var A_arbace_a2g_world__init_A_const_32 any

var A_arbace_a2g_world__init_A_const_33 *lang.Var

var A_arbace_a2g_world__init_A_const_34 any

var A_arbace_a2g_world__init_A_const_35 *lang.Var

var A_arbace_a2g_world__init_A_const_36 any

var A_arbace_a2g_world__init_A_const_37 *lang.Var

var A_arbace_a2g_world__init_A_const_38 any

var A_arbace_a2g_world__init_A_init jrt.ClassInit

func A_arbace_a2g_world__init_A_Init() { if !A_arbace_a2g_world__init_A_init.Done() { A_arbace_a2g_world__init_A_init.Run(A_arbace_a2g_world__init_A_clinit) } }

func A_arbace_a2g_world__init_A_clinit() { A_arbace_a2g_world__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_158); A_arbace_a2g_world__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25))); A_arbace_a2g_world__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25)); A_arbace_a2g_world__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_world__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_23, Lit_80); A_arbace_a2g_world__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_316).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_23, Lit_48); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_world__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_316).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_23, Lit_68); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_world__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_23, Lit_121); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_world__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_23, Lit_152); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_world__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_321).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_322, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_23, Lit_149); A_arbace_a2g_world__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_323, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_23, Lit_83); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_world__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_316).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_23, Lit_97); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_world__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_316).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_324, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_23, Lit_114); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_world__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_325).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_23, Lit_104); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_world__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_326).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_327, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_23, Lit_117); A_arbace_a2g_world__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_326).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_328).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_326).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_328).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_329).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_330).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_331).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_332, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(110).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_23, Lit_134); A_arbace_a2g_world__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_333, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_23, Lit_140); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_world__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_23, Lit_156); A_arbace_a2g_world__init_A_const_31 = jrt.Long_ValueOf_J__Long(100000).Ref(); A_arbace_a2g_world__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_334)); A_arbace_a2g_world__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_23, Lit_155); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_320).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_world__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_335, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(187).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_23, Lit_336); A_arbace_a2g_world__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_337).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_338).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_339, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)); A_arbace_a2g_world__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_23, Lit_340); A_arbace_a2g_world__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_315).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_338).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_343, lang.RT_Keyword_String_String__Keyword(nil, Lit_317).Ref(), jrt.Integer_ValueOf_I__Integer(310).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_318).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_319)) }

func A_arbace_a2g_world__init_A_New() *A_arbace_a2g_world__init_A { A_arbace_a2g_world__init_A_Init(); t := &A_arbace_a2g_world__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world__init_A) Ctor() {}

func (t *A_arbace_a2g_world__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world__init_A_class }

func (t *A_arbace_a2g_world__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world__init_A); return ok }

func A_arbace_a2g_world__init_A_Cast(x any) *A_arbace_a2g_world__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world__init_A_class)) }; return v }
