//line aot_arbace_a2g_world.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New() *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_world_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_2); lang.IFn_Cast(A_arbace_a2g_world_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_3, A_arbace_a2g_world_A_const_4, A_arbace_a2g_world_A_const_5, A_arbace_a2g_world_A_const_6, A_arbace_a2g_world_A_const_7, A_arbace_a2g_world_A_const_8, A_arbace_a2g_world_A_const_9, A_arbace_a2g_world_A_const_10); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_21)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp5 != nil { panic(tmp5) }; return tmp3 }
//line :1:1
func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New() *A_arbace_a2g_world_eval1607000008_fn__1607000009_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000008_fn__1607000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_15), A_arbace_a2g_world_A_const_13.GetRawRoot__O(), A_arbace_a2g_world_A_const_14) }















func A_arbace_a2g_world_read_forms_A_New() *A_arbace_a2g_world_read_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_21; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_17.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_22.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_read_forms_fn__1607000013_A_New(); var tmp9 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class = fncls__1d; tmp9 = fncls__1d } else { tmp9 = fncls__1 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(r__2); var tmp13 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class = fncls__2d; tmp13 = fncls__2d } else { tmp13 = fncls__2 }; tmp1 = tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)))) }
//line :19:1
		return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :17:1
		if tmp14 != nil { panic(tmp14) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp15 != nil { panic(tmp15) }; return tmp1 }


func A_arbace_a2g_world_read_forms_fn__1607000013_A_New() *A_arbace_a2g_world_read_forms_fn__1607000013_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Invoke_O_O__O(self, p1__1607000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_23.GetRawRoot__O()).Invoke_O_O__O(p1__1607000012_SHARP___1, A_arbace_a2g_world_A_const_24) }
//line :20:1
func A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(p0 any) *A_arbace_a2g_world_read_forms_fn__1607000015_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_27, t.F_r) }

func A_arbace_a2g_world_class_form_QMARK__A_New() *A_arbace_a2g_world_class_form_QMARK__A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_class_forms_A_New() *A_arbace_a2g_world_class_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_a2g_world_class_forms_A) Ctor() {}
//line :24:1
func (t *A_arbace_a2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class; if
											fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_New() *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Invoke_O_O__O(self, s__1607000020__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_New_O_O(self, s__1607000020__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Ctor_O_O(c__iter__1607000019, c__s__1607000020 any) { t.F_iter__1607000019 = c__iter__1607000019; t.F_s__1607000020 = c__s__1607000020 }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Invoke_O__O(self any) any { { var s__1607000020__1 any; var t_ any = t.F_s__1607000020; t.F_s__1607000020 = nil; s__1607000020__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000020__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(f__4)
															if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_a2g_world_A_const_44; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__4))).Ref() } else { tmp6 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp6) { tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(f__4) } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :25:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1607000019); return lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000020__1))) } else { s__1607000020__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000020__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_New() *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Invoke_O_O__O(self, s__1607000022__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_New_O_O(self, s__1607000022__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Ctor_O_O(c__iter__1607000021, c__s__1607000022 any) { t.F_iter__1607000021 = c__iter__1607000021; t.F_s__1607000022 = c__s__1607000022 }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Invoke_O__O(self any) any { { var s__1607000022__1 any; var t_ any = t.F_s__1607000022; t.F_s__1607000022 = nil; s__1607000022__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000022__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000022__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000022__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000022__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000024__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_New_O_I_O(b__1607000024__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000021); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000024__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000022__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000024__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000022__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000021); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000022__3))) } else { s__1607000022__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000022__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Ctor_O_I_O(c__b__1607000024 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000024 = c__b__1607000024; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Invoke_O__O(self any) any { { var i__1607000023__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000023__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000023__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(f__2)) { lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000024, f__2); i__1607000023__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000023__1); continue L1 } else { i__1607000023__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000023__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_ns_of_forms_A_New() *A_arbace_a2g_world_ns_of_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_New(); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class; if
											fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; f__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__0)); if
											jrt.A2g_Truth(f__2) { var n__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(n__3)) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(n__3) } else { return n__3 } } else { return nil } }
//line :31:1
func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_New() *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_fn__1607000037_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Ctor() {}
//line :31:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Invoke_O_O__O(self, p1__1607000036_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_79, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_world_top_names_A_New() *A_arbace_a2g_world_top_names_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_world_top_names_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_New_O(nsname__0); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class; if


	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()).Invoke_O__O(forms__1)) }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_New_O(p0 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Invoke_O_O__O(self, s__1607000041__1 any) any { var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_New_O_O_O(self, t.F_nsname, s__1607000041__1); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Ctor_O_O_O(c__iter__1607000040, c__nsname, c__s__1607000041 any) { t.F_iter__1607000040 = c__iter__1607000040; t.F_nsname = c__nsname; t.F_s__1607000041 = c__s__1607000041 }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Invoke_O__O(self any) any { { var s__1607000041__1 any; var t_ any = t.F_s__1607000041; t.F_s__1607000041 = nil; s__1607000041__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000041__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000041__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000041__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000041__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000043__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_New_O_O_I_O(b__1607000043__6, t.F_nsname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000040); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000043__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000041__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000043__6), nil) } } else { var cf__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000041__3); var vec__1607000051__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__4); var seq__1607000052__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000051__5); var first__1607000053__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000052__6); var seq__1607000052__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000052__6); var nm__9 any = first__1607000053__7; var more__10 any = seq__1607000052__8; var more__11 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(more__10))) { more__11 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(more__10) } else { more__11 = more__10 }
//line :37:1
	var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_49; var pkg__12 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(more__11))); var s__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(nm__9); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()); var tmp6 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(pkg__12)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(pkg__12))) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(pkg__12), Lit_95, Lit_94), nil)) } else { tmp8 = nil }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), s__13)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O__O(s__13, Lit_95)) {
		tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(s__13, Lit_95, Lit_94) } else {
//line :42:1
			if A_arbace_a2g_world_A_const_55 != nil {

				tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_95, Lit_94), nil, s__13)).Ref() } else {
//line :42:1
					tmp6 = nil } } }
//line :37:1
	var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1607000040); return tmp5.Invoke_O_O__O(tmp6, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000041__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Ctor_O_O_I_O(c__b__1607000043, c__nsname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000043 = c__b__1607000043; t.F_nsname = c__nsname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Invoke_O__O(self any) any { { var i__1607000042__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000042__1)); var vec__1607000047__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__2); var seq__1607000048__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000047__3); var first__1607000049__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000048__4); var seq__1607000048__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000048__4); var nm__7 any = first__1607000049__5; var more__8 any = seq__1607000048__6; var more__9 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(more__8))) { more__9 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(more__8) } else { more__9 = more__8 }
//line :37:1
	var tmp2 *lang.Keyword = A_arbace_a2g_world_A_const_49; var pkg__10 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(more__9))); var s__11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(nm__7); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()); var tmp4 any = t.F_b__1607000043; var tmp5 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(pkg__10)) { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(pkg__10))) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(pkg__10), Lit_95, Lit_94), nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), s__11)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_95)) {
		tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(s__11, Lit_95, Lit_94) } else {
//line :42:1
			if A_arbace_a2g_world_A_const_55 != nil {

				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_95, Lit_94), nil, s__11)).Ref() } else {
//line :42:1
					tmp5 = nil } } }
//line :37:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1607000042__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000042__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_source_files_A_New() *A_arbace_a2g_world_source_files_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_a2g_world_source_files_A) Ctor() {}
//line :46:1
func (t *A_arbace_a2g_world_source_files_A) Invoke_O_O__O(self, p__1607000059__0 any) any { var map__1607000060__2 any = p__1607000059__0; var map__1607000060__3 any; if lang.ISeq_InstanceOf(map__1607000060__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000060__2)) { map__1607000060__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000060__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000060__2)) { map__1607000060__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000060__2) } else { lang.PersistentArrayMap_Init(); map__1607000060__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000060__3 = map__1607000060__2 }; var root__4 any = lang.RT_Get_O_O__O(map__1607000060__3, A_arbace_a2g_world_A_const_59); var dirs__5 any = lang.RT_Get_O_O__O(map__1607000060__3, A_arbace_a2g_world_A_const_60); var tree__6 any = lang.RT_Get_O_O__O(map__1607000060__3, A_arbace_a2g_world_A_const_61); var files__7 any = lang.RT_Get_O_O__O(map__1607000060__3, A_arbace_a2g_world_A_const_62); if



	jrt.A2g_Truth(files__7) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_63.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_65.GetRawRoot__O(), files__7) } else {
//line :50:1
			if jrt.A2g_Truth(tree__6) {




				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_50.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_source_files_fn__1607000062_A_New(); var tmp5 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class
//line :54:1
				if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class = fncls__13d; tmp5 = fncls__13d } else { tmp5 = fncls__13 }
				var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_source_files_fn__1607000066_A_New(); var tmp9 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class
//line :53:1
				if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class = fncls__14d; tmp9 = fncls__14d } else { tmp9 = fncls__14
				}
				return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O__O(root__4))))) } else {
//line :50:1
					if A_arbace_a2g_world_A_const_55 != nil {








						var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_world_A_const_50.GetRawRoot__O(); var tmp12 any; var iter__1927001039__auto____8 any; var tmp13 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_New_O(root__4); var tmp14 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class
//line :56:1
						if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class = fncls__19d; tmp14 = fncls__19d } else { tmp14 = fncls__19 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						return tmp10.Invoke_O_O__O(tmp11, tmp12) } else {
//line :50:1
							return nil } } } }


func A_arbace_a2g_world_source_files_fn__1607000066_A_New() *A_arbace_a2g_world_source_files_fn__1607000066_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000066_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Ctor() {}
//line :53:1
func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Invoke_O_O__O(self, p1__1607000057_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1607000057_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { return lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1607000057_SHARP___1)).GetName__String().Ref(), Lit_101) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
func A_arbace_a2g_world_source_files_fn__1607000062_A_New() *A_arbace_a2g_world_source_files_fn__1607000062_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000062_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Invoke_O_O__O(self, p1__1607000058_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_67.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(p1__1607000058_SHARP___1)) }
//line :54:1
func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_New() *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Invoke_O_O__O(self, f__1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(f__1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_a2g_world_A_const_68; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__1))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_New_O(p0 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Invoke_O_O__O(self, s__1607000069__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_New_O_O_O(s__1607000069__1, self, t.F_root); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Ctor_O_O_O(c__s__1607000069, c__iter__1607000068, c__root any) { t.F_s__1607000069 = c__s__1607000069; t.F_iter__1607000068 = c__iter__1607000068; t.F_root = c__root }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Invoke_O__O(self any) any { { var s__1607000069__1 any; var t_ any = t.F_s__1607000069; t.F_s__1607000069 = nil; s__1607000069__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000069__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_New(); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_root, d__4))).ListFiles__File1().Ref())); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000068); return lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000069__1))) } else { s__1607000069__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000069__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_New() *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Ctor() {}
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Invoke_O_O__O(self, s__1607000071__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_New_O_O(s__1607000071__1, self); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Ctor_O_O(c__s__1607000071, c__iter__1607000070 any) { t.F_s__1607000071 = c__s__1607000071; t.F_iter__1607000070 = c__iter__1607000070 }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Invoke_O__O(self any) any { { var s__1607000071__1 any; var t_ any = t.F_s__1607000071; t.F_s__1607000071 = nil; s__1607000071__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000071__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000071__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000071__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000071__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000073__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_New_O_I_O(b__1607000073__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000070); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000073__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000071__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000073__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000071__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																				if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_101) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :56:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1607000070); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000071__3))) } else { s__1607000071__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000071__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Ctor_O_I_O(c__b__1607000073 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000073 = c__b__1607000073; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Invoke_O__O(self any) any { { var i__1607000072__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000072__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																						if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_101) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :56:1
	if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000073, f__2); i__1607000072__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000072__1); continue L1 } else { i__1607000072__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000072__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_head_name_A_New() *A_arbace_a2g_world_head_name_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_head_name_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_world_head_name_A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_a2g_world_param_key_A_New() *A_arbace_a2g_world_param_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_a2g_world_param_key_A) Ctor() {}
//line :67:1
func (t *A_arbace_a2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(f__0); var G__1607000088__3_ any = h__2; switch



	lang.Util_Hash_O__I(G__1607000088__3_) >> 13 & 15 { case 5: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_19) { var nm__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_29.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any = A_arbace_a2g_world_A_const_73; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(nm__4)) }; case 6: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_80) { var params__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_48.GetRawRoot__O(); var tmp5 any = A_arbace_a2g_world_param_key_fn__1607000089_A_New_O(f__0); var tmp6 *jrt.Class
		var fncls__21 /*line :71:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class












		if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class = fncls__21d; tmp6 = fncls__21d } else { tmp6 = fncls__21 }; params__4 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()))
//line :71:1
		var tmp7 any = A_arbace_a2g_world_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_world_param_key_fn__1607000091_A_New(); var tmp10 *jrt.Class
		var fncls__22 /*line :71:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class
















		if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class = fncls__22d; tmp10 = fncls__22d } else { tmp10 = fncls__22 }
//line :71:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(params__4))) }; case 7: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_12) { var tmp11 any = A_arbace_a2g_world_A_const_81; return lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(f__0))) }; case 10: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_4) { var tmp12 any = A_arbace_a2g_world_A_const_83; var tmp13 any; var tmp14 *lang.Keyword = A_arbace_a2g_world_A_const_84; var or__1927000174__auto____4 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0))


















			if jrt.A2g_Truth(or__1927000174__auto____4) { tmp13 = or__1927000174__auto____4 } else { tmp13 = A_arbace_a2g_world_A_const_85 }
//line :71:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13) }; case 13: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_83) { var vec__1607000094__4 any = f__0; var seq__1607000095__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000094__4); var first__1607000096__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000095__5); var seq__1607000095__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000095__5); var ___8 any = first__1607000096__6; var first__1607000096__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000095__7); var seq__1607000095__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000095__7); var nm__11 any = first__1607000096__9; var more__12 any = seq__1607000095__10; var more__13 any; var tmp15 any = A_arbace_a2g_world_param_key_fn__1607000097_A_New_O(more__12); var tmp16 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class; _ = ___8



				if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class = fncls__23d; tmp16 = fncls__23d } else { tmp16 = fncls__23 }; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :71:1
				var params__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_48.GetRawRoot__O(), more__13)); var tmp17 *lang.Keyword = A_arbace_a2g_world_A_const_82; var static__15 bool = lang.RT_BooleanCast_O__Z(tmp17.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11))); var ps__16 any









				if static__15 { ps__16 = params__14 } else { ps__16 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(params__14) }
//line :71:1
				var tmp18 any = A_arbace_a2g_world_A_const_86; var tmp19 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(nm__11); var tmp20 any = jrt.Boolean_ValueOf_Z__Boolean(static__15).Ref(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_a2g_world_param_key_fn__1607000099_A_New(); var tmp23 *jrt.Class
				var fncls__25 /*line :71:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class










				if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class = fncls__25d; tmp23 = fncls__25d } else { tmp23 = fncls__25 }
//line :71:1
				return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp18, tmp19, tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), ps__16)) }; case 14: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_86) { var vec__1607000102__4 any = f__0; var seq__1607000103__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000102__4); var first__1607000104__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000103__5); var seq__1607000103__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000103__5); var ___8_2 any = first__1607000104__6; var first__1607000104__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000103__7); var seq__1607000103__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000103__7); var nm__11_2 any = first__1607000104__9; var more__12_2 any = seq__1607000103__10; var more__13_2 any; var tmp24 any = A_arbace_a2g_world_param_key_fn__1607000105_A_New_O(more__12_2); var tmp25 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class; _ = ___8_2



					if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class = fncls__24d; tmp25 = fncls__24d } else { tmp25 = fncls__24 }; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil).Invoke__O()
//line :71:1
					var params__14_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_48.GetRawRoot__O(), more__13_2)); var tmp26 *lang.Keyword = A_arbace_a2g_world_A_const_82; var static__15_2 bool = lang.RT_BooleanCast_O__Z(tmp26.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11_2))); var ps__16_2 any









					if static__15_2 { ps__16_2 = params__14_2 } else { ps__16_2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(params__14_2) }
//line :71:1
					var tmp27 any = A_arbace_a2g_world_A_const_86; var tmp28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(nm__11_2); var tmp29 any = jrt.Boolean_ValueOf_Z__Boolean(static__15_2).Ref(); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_a2g_world_param_key_fn__1607000107_A_New(); var tmp32 *jrt.Class
					var fncls__26 /*line :71:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class










					if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class = fncls__26d; tmp32 = fncls__26d } else { tmp32 = fncls__26 }
//line :71:1
					return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp27, tmp28, tmp29, tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), ps__16_2)) }; default:}; return nil }



func A_arbace_a2g_world_param_key_fn__1607000097_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000097_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000097_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :76:1
			if A_arbace_a2g_world_A_const_55 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :76:1
					return nil } } } } }; /*line :75:1*/panic("a2g: unreachable") }
//line :75:1
func A_arbace_a2g_world_param_key_fn__1607000105_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000105_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000105_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :76:1
			if A_arbace_a2g_world_A_const_55 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :76:1
					return nil } } } } }; /*line :75:1*/panic("a2g: unreachable") }






func A_arbace_a2g_world_param_key_fn__1607000099_A_New() *A_arbace_a2g_world_param_key_fn__1607000099_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000099_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Ctor() {}
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Invoke_O_O__O(self, p1__1607000086_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000100__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000086_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000100__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(G__1607000100__2_) } }
//line :82:1
func A_arbace_a2g_world_param_key_fn__1607000107_A_New() *A_arbace_a2g_world_param_key_fn__1607000107_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000107_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Ctor() {}
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Invoke_O_O__O(self, p1__1607000086_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000108__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000086_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000108__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(G__1607000108__2_) } }

func A_arbace_a2g_world_param_key_fn__1607000089_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000089_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000089_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :84:1
func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Invoke_O__O(self any) any { { var xs__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; xs__1 = tmp1.Invoke_O__O(tmp2); var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp3 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :85:1
			if A_arbace_a2g_world_A_const_55 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :85:1
					return nil } } } } }; /*line :84:1*/panic("a2g: unreachable") }



func A_arbace_a2g_world_param_key_fn__1607000091_A_New() *A_arbace_a2g_world_param_key_fn__1607000091_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000091_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Ctor() {}
//line :88:1
func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Invoke_O_O__O(self, p1__1607000087_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000092__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000087_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000092__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(G__1607000092__2_) } }





func A_arbace_a2g_world_cut_key_A_New() *A_arbace_a2g_world_cut_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_cut_key_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_a2g_world_cut_key_A) Ctor() {}
//line :94:1
func (t *A_arbace_a2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(x__0)
	if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_19, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :95:1
	if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :95:1
			var tmp2 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(x__0)


			if jrt.A2g_Truth(and__1927000168__auto____2_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp2 = and__1927000168__auto____2_2 }
//line :95:1
			if jrt.A2g_Truth(tmp2) { var tmp3 any = A_arbace_a2g_world_A_const_83; var tmp4 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(x__0)


				if jrt.A2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = A_arbace_a2g_world_A_const_85 }
//line :95:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(x__0))) {



					return lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_89, x__0)) } else {
//line :95:1
						if A_arbace_a2g_world_A_const_55 != nil { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())))) } else { return nil
						}
					}
				}
		}
}

func A_arbace_a2g_world_class_parts_A_New() *A_arbace_a2g_world_class_parts_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_parts_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_a2g_world_class_parts_A) Ctor() {}
//line :102:1
func (t *A_arbace_a2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__1607000112__2 any = cf__0; var seq__1607000113__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000112__2); var first__1607000114__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000113__3); var seq__1607000113__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000113__3); var dc__6 any = first__1607000114__4; var first__1607000114__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000113__5); var seq__1607000113__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000113__5); var nm__9 any = first__1607000114__7; var more__10 any = seq__1607000113__8; var vec__1607000115__11 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(more__10))) { vec__1607000115__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(more__10)), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(more__10)) } else { var tmp1 *lang.PersistentVector; lang.PersistentVector_Init(); tmp1 = lang.PersistentVector_EMPTY; vec__1607000115__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp1.Ref(), more__10) }; var comps__12 any = /*line :102:1*/lang.RT_Nth_O_I_O__O(vec__1607000115__11, lang.RT_IntCast_J__I(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O(vec__1607000115__11, lang.RT_IntCast_J__I(1), nil); var vec__1607000118__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(more__13); var opts__15 any = lang.RT_Nth_O_I_O__O(vec__1607000118__14, lang.RT_IntCast_J__I(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O(vec__1607000118__14, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9), comps__12, lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_93.GetRawRoot__O(), opts__15)), lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(members__16)) }







func A_arbace_a2g_world_apply_variant_A_New() *A_arbace_a2g_world_apply_variant_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__1607000124__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_94.GetRawRoot__O()).Invoke_O__O(cf__0); var head__7 any = lang.RT_Nth_O_I_O__O(vec__1607000124__6, lang.RT_IntCast_J__I(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O(vec__1607000124__6, lang.RT_IntCast_J__I(1), nil); var members__9 any; var n__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_97); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_apply_variant_fn__1607000127_A_New_O(n__9); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class; if










	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; members__9 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), members__8); var counts__10 any = /*line :110:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_102); var members__11 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_apply_variant_fn__1607000129_A_New_O(counts__10); var tmp6 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class; if
















	fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class = fncls__32d; tmp6 = fncls__32d } else { tmp6 = fncls__32 }; members__11 = /*line :126:1*/tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), members__9, vforms__1); var members__12 any; if

















	jrt.A2g_Truth(variants_of__3) {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000138_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp9 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class = fncls__33d; tmp9 = fncls__33d } else { tmp9 = fncls__33 }; members__12 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), members__11) } else {
//line :144:1
			members__12 = members__11 }; return /*line :110:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_111.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_112.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(head__7, members__12)), lang.RT_Meta_O__IPersistentMap(cf__0)), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(counts__10)) }
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	return lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()).Invoke_O_O_O_O_O__O(cf__0, vforms__1, nil, nil, nil)
}



func A_arbace_a2g_world_apply_variant_fn__1607000127_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000127_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000127_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :121:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Invoke_O_O__O(self, m__1 any) any { if lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(m__1)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_98.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_99.GetRawRoot__O(); var tmp3 any = A_arbace_a2g_world_A_const_84; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp5 any = t.F_n; return tmp1.Invoke_O_O_O_O__O(m__1, tmp2, tmp3, tmp4.Invoke_O_O__O(tmp5, A_arbace_a2g_world_A_const_101.GetRawRoot__O())) } else {
//line :121:1
		return m__1 } }





func A_arbace_a2g_world_apply_variant_fn__1607000129_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :127:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__1607000130__3_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(vf__2); switch
													lang.Util_Hash_O__I(G__1607000130__3_) { case 96417: if lang.Util_Equiv_O_O__Z(G__1607000130__3_, Lit_5) {







		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp2 any = t.F_counts; var tmp3 any = A_arbace_a2g_world_A_const_104.GetRawRoot__O(); var tmp4 any = A_arbace_a2g_world_A_const_105; tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_a2g_world_A_const_101.GetRawRoot__O()); return lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(ms__1, lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(vf__2)) }
//line :128:1
	case 98882: if lang.Util_Equiv_O_O__Z(G__1607000130__3_, Lit_6) { var k__4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_103.GetRawRoot__O()); var tmp6 any


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(vf__2))) { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(vf__2) } else { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(vf__2) }; k__4 = tmp5.Invoke_O__O(tmp6)
//line :128:1
		var hit__5 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_67.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_New_O(k__4); var tmp9 *jrt.Class
		var fncls__29 /*line :128:1*/*jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class



		if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class = fncls__29d; tmp9 = fncls__29d } else { tmp9 = fncls__29 }; hit__5 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ms__1)
		if jrt.A2g_Truth(hit__5) { } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp11 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(vf__2)))).Ref(); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10.Invoke_O_O__O(tmp11, tmp12.Ref())))) }
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp14 any = t.F_counts; var tmp15 any = A_arbace_a2g_world_A_const_104.GetRawRoot__O(); var tmp16 any = A_arbace_a2g_world_A_const_106; tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, A_arbace_a2g_world_A_const_101.GetRawRoot__O())
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_New_O(k__4); var tmp20 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class = fncls__30d; tmp20 = fncls__30d } else { tmp20 = fncls__30 }; return tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), ms__1)) }
//line :128:1
	default:}; var k__4_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(vf__2); var i__5 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_107.GetRawRoot__O()); var tmp23 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_New_O(k__4_2); var tmp24 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class; if









	fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class = fncls__31d; tmp24 = fncls__31d } else { tmp24 = fncls__31 }; i__5 = tmp21.Invoke_O__O(tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), ms__1)); if
	jrt.A2g_Truth(i__5) { } else { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp26 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp25.Invoke_O_O__O(tmp26, tmp27.Ref())))) }; var tmp28 lang.IFn =
	lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp29 any = t.F_counts; var tmp30 any = A_arbace_a2g_world_A_const_104.GetRawRoot__O(); var tmp31 any = A_arbace_a2g_world_A_const_108; tmp28.Invoke_O_O_O_O__O(tmp29, tmp30, tmp31, A_arbace_a2g_world_A_const_101.GetRawRoot__O()); return /*line :141:1*/ lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(ms__1, i__5, vf__2) }
//line :132:1
func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A{}; t.Ctor_O(p0); return t }
//line :132:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :132:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Invoke_O_O__O(self, p1__1607000122_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(p1__1607000122_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :135:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Invoke_O_O__O(self, p1__1607000123_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(p1__1607000123_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :138:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(m__2)) { return i__1 } else { return nil } }






func A_arbace_a2g_world_apply_variant_fn__1607000138_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_apply_variant_fn__1607000138_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000138_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Invoke_O_O__O(self, m__1 any) any {
	if lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(m__1)) { var tmp1 any = t.F_prefix; var nn__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, tmp1, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_45.GetRawRoot__O()).Invoke_O__O(m__1)))).Ref(); var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__1607000139__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()); var tmp3 any
		var or__1927000174__auto____4 any = vfs__3

		if jrt.A2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY.Ref() }; vec__1607000139__4 = tmp2.Invoke_O_O_O_O_O__O(m__1, tmp3, nn__2, t.F_variants_of, t.F_applied)
//line :146:1
		var m2__5 any = lang.RT_Nth_O_I_O__O(vec__1607000139__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1607000139__4, lang.RT_IntCast_J__I(1), nil)



		if jrt.A2g_Truth(vfs__3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp5 any = t.F_applied; tmp4.Invoke_O_O_O_O__O(tmp5, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), nn__2, c__6) }
//line :146:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_a2g_world_read_variants_A_New() *A_arbace_a2g_world_read_variants_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_a2g_world_read_variants_A) Ctor() {}
//line :157:1
func (t *A_arbace_a2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000144_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O__O(tmp4, tmp5.Ref(), files__0) }
//line :163:1
func A_arbace_a2g_world_read_variants_fn__1607000144_A_New() *A_arbace_a2g_world_read_variants_fn__1607000144_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000144_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(f__2); var nsname__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(forms__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_New_O(nsname__4); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class; if


	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1, forms__3) }
//line :166:1
func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_New_O(p0 any) *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :166:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__2)
	if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_93, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :167:1
	if jrt.A2g_Truth(tmp1) { var vec__1607000146__3 any = fm__2; var seq__1607000147__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(vec__1607000146__3); var first__1607000148__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000147__4); var seq__1607000147__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000147__4); var ___7 any = first__1607000148__5; var first__1607000148__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1607000147__6); var seq__1607000147__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__1607000147__6); var cls__10 any = first__1607000148__8; var members__11 any = seq__1607000147__9; var n__12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_95, Lit_94), nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(cls__10))).Ref(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_104.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_114.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_115.GetRawRoot__O(); var tmp5 *lang.PersistentVector; _ = ___7



		lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp2.Invoke_O_O_O_O__O(acc__1, n__12, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), members__11) } else {
//line :167:1
			var tmp6 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__2)




			if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_96, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp6 = and__1927000168__auto____3_2 }
//line :167:1
			if jrt.A2g_Truth(tmp6) {





				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_104.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_A_const_116; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_114.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_world_A_const_115.GetRawRoot__O(); var tmp11 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; return tmp7.Invoke_O_O_O_O__O(acc__1, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Ref()), lang.IFn_Cast(A_arbace_a2g_world_A_const_63.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(fm__2))) } else {
//line :167:1
					if A_arbace_a2g_world_A_const_55 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_a2g_world_new_unit_A_New() *A_arbace_a2g_world_new_unit_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_new_unit_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_a2g_world_new_unit_A) Ctor() {}
//line :178:1
func (t *A_arbace_a2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_a2g_world_A_const_117; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp2.Invoke_O__O(tmp3.Ref()); var tmp5 any = A_arbace_a2g_world_A_const_118; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 any = A_arbace_a2g_world_A_const_119; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 any = A_arbace_a2g_world_A_const_120; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 any = A_arbace_a2g_world_A_const_121; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp19 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp19 = lang.PersistentHashSet_EMPTY; var tmp20 any = tmp18.Invoke_O__O(tmp19.Ref()); var tmp21 any = A_arbace_a2g_world_A_const_122; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 any = A_arbace_a2g_world_A_const_123; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp12, tmp13, tmp16, tmp17, tmp20, tmp21, tmp24, tmp25, tmp26.Invoke_O__O(tmp27.Ref()))) }








func A_arbace_a2g_world_id_space_A_New() *A_arbace_a2g_world_id_space_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_id_space_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_a2g_world_id_space_A) Ctor() {}
//line :187:1
func (t *A_arbace_a2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_93.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_124))).GetField_String__Field(Lit_22)).Get_O__O(nil)
//line :187:1
	return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }




func A_arbace_a2g_world_load_world_A_New() *A_arbace_a2g_world_load_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_a2g_world_load_world_A) Ctor() {}
//line :192:1
func (t *A_arbace_a2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__1607000155__1 any) any { var map__1607000156__3 any = p__1607000155__1; var map__1607000156__4 any; if lang.ISeq_InstanceOf(map__1607000156__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { map__1607000156__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000156__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { map__1607000156__4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000156__3) } else { lang.PersistentArrayMap_Init(); map__1607000156__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000156__4 = map__1607000156__3 }; var variant_files__5 any = lang.RT_Get_O_O__O(map__1607000156__4, A_arbace_a2g_world_A_const_125); var variants__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_126.GetRawRoot__O()).Invoke_O__O(variant_files__5); var erased__7 any; var tmp1 any = A_arbace_a2g_world_A_const_116; var tmp2 *lang.PersistentHashSet;






	lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; erased__7 = lang.RT_Get_O_O_O__O(variants__6, tmp1, tmp2.Ref()); var variants__8 any = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_127.GetRawRoot__O()).Invoke_O_O__O(variants__6, A_arbace_a2g_world_A_const_116); var applied__9 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap;








	lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; applied__9 = tmp3.Invoke_O__O(tmp4.Ref()); var files__10 any = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_141.GetRawRoot__O(), inputs__0)); var parsed__11 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke__O(); var tmp7 any = A_arbace_a2g_world_load_world_fn__1607000158_A_New(); var tmp8 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class; if











	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class = fncls__38d; tmp8 = fncls__38d } else { tmp8 = fncls__38 }; parsed__11 = tmp5.Invoke_O_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), files__10); var tops__12 any; var tmp9 lang.IFn = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_129.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000161_A_New(); var tmp12 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class; if












	fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class = fncls__39d; tmp12 = fncls__39d } else { tmp12 = fncls__39 }; tops__12 = tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), parsed__11)); var top_of__13 any; var tmp13 any = /*line :192:1*/A_arbace_a2g_world_load_world_top_of__1607000165_A_New(); var tmp14 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class; if













	fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class = fncls__36d; tmp14 = fncls__36d } else { tmp14 = fncls__36 }; top_of__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var from_source__14 any; var tmp15 any = /*line :192:1*/A_arbace_a2g_world_load_world_from_source__1607000167_A_New_O_O(tops__12, top_of__13); var tmp16 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class; if














	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class = fncls__37d; tmp16 = fncls__37d } else { tmp16 = fncls__37 }; from_source__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var cs__15 any; var tmp17 lang.IFn = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp18 *lang.PersistentArrayMap;















	lang.PersistentArrayMap_Init(); tmp18 = lang.PersistentArrayMap_EMPTY; cs__15 = tmp17.Invoke_O__O(tmp18.Ref()); var unit__16 any = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_132.GetRawRoot__O()).Invoke__O(); var failed__17 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp20 *lang.PersistentVector;

















	lang.PersistentVector_Init(); tmp20 = lang.PersistentVector_EMPTY; failed__17 = tmp19.Invoke_O__O(tmp20.Ref());
	lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_187, cs__15, A_arbace_a2g_world_A_const_188, unit__16, A_arbace_a2g_world_A_const_189, from_source__14)); var tmp21 any = A_arbace_a2g_world_load_world_fn__1607000169_A_New_O_O_O_O_O(parsed__11, variants__8, failed__17, applied__9, unit__16); var tmp22 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class = fncls__74d; tmp22 = fncls__74d } else { tmp22 = fncls__74 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O(); var seq_1607000316__18 any = /*line :192:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_190.GetRawRoot__O()).Invoke_O__O(variants__8)); var chunk_1607000317__19 any; var count_1607000318__20 int64 = 0; var i_1607000319__21 int64 = 0; L1: for {












































































































		if lang.Numbers_Lt_J_J__Z(i_1607000319__21, count_1607000318__20) { var n__22 any = lang.Indexed_Cast(chunk_1607000317__19).Nth_I__O(lang.RT_IntCast_J__I(i_1607000319__21)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__9), n__22))) {
			lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(failed__17, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__22, Lit_28))
//line :301:1
			seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, lang.Numbers_Unchecked_inc_J__J(i_1607000319__21); continue L1 } else { seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, lang.Numbers_Unchecked_inc_J__J(i_1607000319__21); continue L1 } } else { var temp__1927000414__auto____22 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000316__18); if jrt.A2g_Truth(temp__1927000414__auto____22) { var seq_1607000316__23 any = temp__1927000414__auto____22; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23)) { var c__1927000678__auto____24 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23); seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), c__1927000678__auto____24, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__24 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__9), n__24))) {
				lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(failed__17, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__24, Lit_28))
//line :301:1
				seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), nil, 0, 0; continue L1 } else { seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), nil, 0, 0; continue L1 } } } }
//line :192:1
		break L1 }; var tmp23 any = A_arbace_a2g_world_A_const_133; var tmp24 any = A_arbace_a2g_world_A_const_134; var tmp25 any = A_arbace_a2g_world_A_const_135; var tmp26 any = A_arbace_a2g_world_A_const_62; var tmp27 any = A_arbace_a2g_world_A_const_136; var tmp28 any = A_arbace_a2g_world_A_const_137; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_115.GetRawRoot__O()); var tmp30 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp30 = lang.PersistentArrayMap_EMPTY; var tmp31 any = tmp30.Ref(); var tmp32 any; var iter__1927001039__auto____18 any; var tmp33 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_New(); var tmp34 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class; if
















































































































	fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class = fncls__79d; tmp34 = fncls__79d } else { tmp34 = fncls__79 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); tmp32 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(parsed__11); var tmp35 any = /*line :192:1*/tmp29.Invoke_O_O__O(tmp31, tmp32); var tmp36 any = A_arbace_a2g_world_A_const_138; var tmp37 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_191.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_31.GetRawRoot__O(), A_arbace_a2g_world_A_const_45.GetRawRoot__O()), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(failed__17))); var tmp38 any = A_arbace_a2g_world_A_const_139; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23, cs__15, tmp24, unit__16, tmp25, from_source__14, tmp26, files__10, tmp27, tops__12, tmp28, tmp35, tmp36, tmp37, tmp38, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__9), A_arbace_a2g_world_A_const_140, erased__7)) }











func A_arbace_a2g_world_load_world_fn__1607000158_A_New() *A_arbace_a2g_world_load_world_fn__1607000158_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000158_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Ctor() {}
//line :204:1
func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any = A_arbace_a2g_world_A_const_143; var tmp2 any = A_arbace_a2g_world_A_const_144; var tmp3 any = A_arbace_a2g_world_A_const_145; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, f__1, tmp2, forms__2, tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(forms__2))) }
func A_arbace_a2g_world_load_world_fn__1607000161_A_New() *A_arbace_a2g_world_load_world_fn__1607000161_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000161_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Ctor() {}
//line :205:1
func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Invoke_O_O__O(self, p__1607000160__1 any) any { var map__1607000162__2 any = p__1607000160__1; var map__1607000162__3 any; if lang.ISeq_InstanceOf(map__1607000162__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000162__2)) { map__1607000162__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000162__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000162__2)) { map__1607000162__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000162__2) } else { lang.PersistentArrayMap_Init(); map__1607000162__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000162__3 = map__1607000162__2 }; var ns__4 any = lang.RT_Get_O_O__O(map__1607000162__3, A_arbace_a2g_world_A_const_145); var forms__5 any = lang.RT_Get_O_O__O(map__1607000162__3, A_arbace_a2g_world_A_const_144); if jrt.A2g_Truth(ns__4) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()).Invoke_O_O__O(ns__4, forms__5) } else { return nil } }
func A_arbace_a2g_world_load_world_top_of__1607000165_A_New() *A_arbace_a2g_world_load_world_top_of__1607000165_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_of__1607000165_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Ctor() {}
//line :206:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_13); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__1 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_130.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_85; return tmp1.Invoke_O_O_O__O(n__1, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }
func A_arbace_a2g_world_load_world_from_source__1607000167_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_from_source__1607000167_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_from_source__1607000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :207:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()); var tmp2 any = t.F_tops; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1)) }



func A_arbace_a2g_world_load_world_fn__1607000169_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000169_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :211:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Ctor_O_O_O_O_O(c__parsed, c__variants, c__failed, c__applied, c__unit any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied; t.F_unit = c__unit }
//line :211:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Invoke_O__O(self any) any { var tmp1 any; tmp69 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()






	if jrt.A2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3
		jrt.ThreadLocal_Cast(space__4).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_150.GetRawRoot__O()))) }
//line :211:1
	var seq_1607000170__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_parsed








	t.F_parsed = nil; tmp3 = t_; seq_1607000170__3 = tmp2.Invoke_O__O(tmp3)
//line :211:1
	var chunk_1607000171__4 any; var count_1607000172__5 int64 = 0; var i_1607000173__6 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z(i_1607000173__6, count_1607000172__5) { var map__1607000174__7 any = lang.Indexed_Cast(chunk_1607000171__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000173__6)); var map__1607000174__8 any; if lang.ISeq_InstanceOf(map__1607000174__7) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000174__7)) { map__1607000174__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000174__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000174__7)) { map__1607000174__8 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000174__7) } else { lang.PersistentArrayMap_Init(); map__1607000174__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000174__8 = map__1607000174__7 }; var file__9 any = lang.RT_Get_O_O__O(map__1607000174__8, A_arbace_a2g_world_A_const_143); var forms__10 any = lang.RT_Get_O_O__O(map__1607000174__8, A_arbace_a2g_world_A_const_144); var ns__11 any = lang.RT_Get_O_O__O(map__1607000174__8, A_arbace_a2g_world_A_const_145); if jrt.A2g_Truth(ns__11) {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_A_const_151; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, A_arbace_a2g_world_A_const_151.Get__O())); var tmp6 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_New_O_O_O_O_O_O(forms__10, t.F_variants, t.F_failed, file__9, t.F_applied, ns__11); var tmp7 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class = fncls__45d; tmp7 = fncls__45d } else { tmp7 = fncls__45 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :220:1
			seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, lang.Numbers_Unchecked_inc_J__J(i_1607000173__6); continue L1 } else { seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, lang.Numbers_Unchecked_inc_J__J(i_1607000173__6); continue L1 } } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000170__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000170__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8); seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__1607000200__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8); var map__1607000200__10 any; if lang.ISeq_InstanceOf(map__1607000200__9) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000200__9)) { map__1607000200__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000200__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000200__9)) { map__1607000200__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000200__9) } else { lang.PersistentArrayMap_Init(); map__1607000200__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000200__10 = map__1607000200__9 }; var file__11 any = lang.RT_Get_O_O__O(map__1607000200__10, A_arbace_a2g_world_A_const_143); var forms__12 any = lang.RT_Get_O_O__O(map__1607000200__10, A_arbace_a2g_world_A_const_144); var ns__13 any = lang.RT_Get_O_O__O(map__1607000200__10, A_arbace_a2g_world_A_const_145); if jrt.A2g_Truth(ns__13) {
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_world_A_const_151; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, A_arbace_a2g_world_A_const_151.Get__O())); var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_New_O_O_O_O_O_O(forms__12, t.F_variants, t.F_failed, file__11, t.F_applied, ns__13); var tmp11 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class = fncls__50d; tmp11 = fncls__50d } else { tmp11 = fncls__50 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :220:1
				seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), nil, 0, 0; continue L1 } else { seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), nil, 0, 0; continue L1 } } } }
//line :211:1
		break L1 }; var names__3 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()); var tmp13 *lang.Keyword = A_arbace_a2g_world_A_const_117; var tmp14 any; var t__2 any = t.F_unit


























	t.F_unit = nil; tmp14 = t__2; names__3 = tmp12.Invoke_O__O(tmp13.Invoke_O__O(tmp14))
//line :211:1
	var t__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref()); var laps__5 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp16 *lang.PersistentVector




























	lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; laps__5 = tmp15.Invoke_O__O(tmp16.Ref())
//line :211:1
	var lap__6 any; var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_New_O_O(t__4, laps__5); var tmp18 *jrt.Class
	var fncls__40 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class





























	if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class = fncls__40d; tmp18 = fncls__40d } else { tmp18 = fncls__40 }; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)
	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_173)
//line :211:1
	var seq_1607000228__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(names__3); var chunk_1607000229__8 any; var count_1607000230__9 int64 = 0; var i_1607000231__10 int64 = 0; L2: for {































		if lang.Numbers_Lt_J_J__Z(i_1607000231__10, count_1607000230__9) { var n__11 any = lang.Indexed_Cast(chunk_1607000229__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000231__10)); var tmp19 *lang.Keyword = A_arbace_a2g_world_A_const_174; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__11)))) {
			var tmp20 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_New_O_O(n__11, t.F_failed); var tmp21 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class = fncls__54d; tmp21 = fncls__54d } else { tmp21 = fncls__54 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O()
//line :243:1
			seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, lang.Numbers_Unchecked_inc_J__J(i_1607000231__10); continue L2 } else { seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, lang.Numbers_Unchecked_inc_J__J(i_1607000231__10); continue L2 } } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000228__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1607000228__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12); seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var n__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12); var tmp22 *lang.Keyword = A_arbace_a2g_world_A_const_174; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__13)))) {
				var tmp23 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_New_O_O(n__13, t.F_failed); var tmp24 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class = fncls__55d; tmp24 = fncls__55d } else { tmp24 = fncls__55 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()
//line :243:1
				seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), nil, 0, 0; continue L2 } else { seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), nil, 0, 0; continue L2 } } } }
//line :211:1
		break L2
	}
































	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_176)
//line :211:1
	var seq_1607000236__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(names__3); var chunk_1607000237__8 any; var count_1607000238__9 int64 = 0; var i_1607000239__10 int64 = 0; L3: for {


































		if lang.Numbers_Lt_J_J__Z(i_1607000239__10, count_1607000238__9) { var n__11_2 any = lang.Indexed_Cast(chunk_1607000237__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000239__10)); var tmp25 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_New_O_O(n__11_2, t.F_failed); var tmp26 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class
			if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class = fncls__56d; tmp26 = fncls__56d } else { tmp26 = fncls__56 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O()
//line :246:1
			seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, lang.Numbers_Unchecked_inc_J__J(i_1607000239__10); continue L3 } else { var temp__1927000414__auto____11_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000236__7); if jrt.A2g_Truth(temp__1927000414__auto____11_2) { var seq_1607000236__12 any = temp__1927000414__auto____11_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000236__12)) { var c__1927000678__auto____13_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000236__12); seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000236__12), c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var n__13_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000236__12); var tmp27 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_New_O_O(n__13_2, t.F_failed); var tmp28 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class
				if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class = fncls__57d; tmp28 = fncls__57d } else { tmp28 = fncls__57 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O()
//line :246:1
				seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000236__12), nil, 0, 0; continue L3 } } }
//line :211:1
		break L3
	}



































	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_178)
//line :211:1
	var seq_1607000244__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_179.Invoke_O__O(names__3)); var chunk_1607000245__8 any; var count_1607000246__9 int64 = 0; var i_1607000247__10 int64 = 0; L4: for {





































		if lang.Numbers_Lt_J_J__Z(i_1607000247__10, count_1607000246__9) { var n__11_3 any = lang.Indexed_Cast(chunk_1607000245__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000247__10)); var tmp29 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_New_O_O(n__11_3, t.F_failed); var tmp30 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class
			if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class = fncls__58d; tmp30 = fncls__58d } else { tmp30 = fncls__58 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil).Invoke__O()
//line :249:1
			seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, lang.Numbers_Unchecked_inc_J__J(i_1607000247__10); continue L4 } else { var temp__1927000414__auto____11_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000244__7); if jrt.A2g_Truth(temp__1927000414__auto____11_3) { var seq_1607000244__12 any = temp__1927000414__auto____11_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000244__12)) { var c__1927000678__auto____13_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000244__12); seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000244__12), c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var n__13_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000244__12); var tmp31 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_New_O_O(n__13_3, t.F_failed); var tmp32 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class
				if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class = fncls__59d; tmp32 = fncls__59d } else { tmp32 = fncls__59 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :249:1
				seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000244__12), nil, 0, 0; continue L4 } } }
//line :211:1
		break L4
	}






































	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_181)
//line :211:1
	var seq_1607000252__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(names__3); var chunk_1607000253__8 any; var count_1607000254__9 int64 = 0; var i_1607000255__10 int64 = 0; L5: for {








































		if lang.Numbers_Lt_J_J__Z(i_1607000255__10, count_1607000254__9) { var n__11_4 any = lang.Indexed_Cast(chunk_1607000253__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000255__10)); var tmp33 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_New_O_O(n__11_4, t.F_failed); var tmp34 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class
			if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class = fncls__60d; tmp34 = fncls__60d } else { tmp34 = fncls__60 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O()
//line :252:1
			seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, lang.Numbers_Unchecked_inc_J__J(i_1607000255__10); continue L5 } else { var temp__1927000414__auto____11_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000252__7); if jrt.A2g_Truth(temp__1927000414__auto____11_4) { var seq_1607000252__12 any = temp__1927000414__auto____11_4; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000252__12)) { var c__1927000678__auto____13_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000252__12); seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000252__12), c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var n__13_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000252__12); var tmp35 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_New_O_O(n__13_4, t.F_failed); var tmp36 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class
				if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class = fncls__61d; tmp36 = fncls__61d } else { tmp36 = fncls__61 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O()
//line :252:1
				seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000252__12), nil, 0, 0; continue L5 } } }
//line :211:1
		break L5 }; var analyze_BANG___7 any; var tmp37 any = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_New_O(t.F_failed); var tmp38 *jrt.Class
	var fncls__51 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class














































	if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class = fncls__51d; tmp38 = fncls__51d } else { tmp38 = fncls__51 }; analyze_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil)
//line :211:1
	var compiled_QMARK___8 any; var tmp39 any = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_New(); var tmp40 *jrt.Class
	var fncls__52 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class

























































	if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class = fncls__52d; tmp40 = fncls__52d } else { tmp40 = fncls__52 }; compiled_QMARK___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil)
//line :211:1
	var rt_space__9 any; var G__1607000265__9_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()


























































	if lang.Util_Identical_O_O__Z(G__1607000265__9_, nil) { rt_space__9 = nil } else { rt_space__9 = jrt.ThreadLocal_Cast(G__1607000265__9_).Get__O() }
//line :211:1
	var runtime__10 any




























































	if jrt.A2g_Truth(rt_space__9) {
		var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_172.GetRawRoot__O()); var tmp42 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_New_O_O_O_O(rt_space__9, names__3, compiled_QMARK___8, analyze_BANG___7); var tmp43 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class = fncls__62d; tmp43 = fncls__62d } else { tmp43 = fncls__62 }; runtime__10 = tmp41.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil)) } else {



			lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke_O_O__O(analyze_BANG___7, lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()).Invoke_O_O__O(compiled_QMARK___8, names__3))
//line :272:1
			runtime__10 = nil }
//line :211:1
	var names__11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O_O__O(compiled_QMARK___8, names__3); var tops_QMARK___12 any; var tmp44 any = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_New(); var tmp45 *jrt.Class
	var fncls__53 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class








































































	if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class = fncls__53d; tmp45 = fncls__53d } else { tmp45 = fncls__53 }; tops_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil)
//line :211:1
	var groups__13 any; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()); var tmp48 any; var iter__1927001039__auto____13 any; var tmp49 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_New_O(tops_QMARK___12); var tmp50 *jrt.Class
	var fncls__65 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class









































































	if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class = fncls__65d; tmp50 = fncls__65d } else { tmp50 = fncls__65 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil); tmp48 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(names__11); groups__13 = tmp46.Invoke_O__O(tmp47.Invoke_O__O(tmp48))
//line :211:1
	var top_groups__14 any; var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp52 any; var iter__1927001039__auto____14 any; var tmp53 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_New_O(tops_QMARK___12); var tmp54 *jrt.Class
	var fncls__68 /*line :211:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class










































































	if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class = fncls__68d; tmp54 = fncls__68d } else { tmp54 = fncls__68 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil); tmp52 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(names__11); top_groups__14 = tmp51.Invoke_O__O(tmp52)
//line :211:1
	var temp__1927000408__auto____15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()











































































	if jrt.A2g_Truth(temp__1927000408__auto____15) { var space__16 any = temp__1927000408__auto____15; var seq_1607000290__17 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(groups__13, top_groups__14)); var chunk_1607000291__18 any; var count_1607000292__19 int64 = 0; var i_1607000293__20 int64 = 0; L6: for {
		if lang.Numbers_Lt_J_J__Z(i_1607000293__20, count_1607000292__19) { var gs__21 any = lang.Indexed_Cast(chunk_1607000291__18).Nth_I__O(lang.RT_IntCast_J__I(i_1607000293__20)); var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()); var tmp56 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke__O(); var tmp57 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_New_O_O(analyze_BANG___7, space__16); var tmp58 *jrt.Class
			var fncls__69 /*line :288:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class

			if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class = fncls__69d; tmp58 = fncls__69d } else { tmp58 = fncls__69 }
//line :289:1
			tmp55.Invoke_O_O_O__O(tmp56, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil), gs__21)
//line :288:1
			seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, lang.Numbers_Unchecked_inc_J__J(i_1607000293__20); continue L6 } else { var temp__1927000414__auto____21 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000290__17); if jrt.A2g_Truth(temp__1927000414__auto____21) { var seq_1607000290__22 any = temp__1927000414__auto____21; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000290__22)) { var c__1927000678__auto____23 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000290__22); seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000290__22), c__1927000678__auto____23, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var gs__23 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000290__22); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()); var tmp60 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke__O(); var tmp61 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_New_O_O(analyze_BANG___7, space__16); var tmp62 *jrt.Class
				var fncls__70 /*line :288:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class

				if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class = fncls__70d; tmp62 = fncls__70d } else { tmp62 = fncls__70 }
//line :289:1
				tmp59.Invoke_O_O_O__O(tmp60, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp61, tmp62, nil), gs__23)
//line :288:1
				seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000290__22), nil, 0, 0; continue L6 } } }
//line :287:1
		break L6 } } else {







			lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke_O_O__O(analyze_BANG___7, names__11) }
	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_184)
//line :211:1
	var G__1607000298__15_ any = runtime__10





















































































	if lang.Util_Identical_O_O__Z(G__1607000298__15_, nil) { } else { lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(G__1607000298__15_) }
//line :211:1
	var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()






















































































	if jrt.A2g_Truth(temp__1927000414__auto____15) { var space__16_2 any = temp__1927000414__auto____15; jrt.ThreadLocal_Cast(space__16_2).Remove__V() }
	lang.IFn_Cast(lap__6).Invoke_O__O(A_arbace_a2g_world_A_const_185)
	var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_148.GetRawRoot__O()); var tmp64 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_49, nil); var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_186.GetRawRoot__O()); var tmp66 any; var iter__1927001039__auto____9 any; var tmp67 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_New(); var tmp68 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class = fncls__73d; tmp68 = fncls__73d } else { tmp68 = fncls__73 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp67, tmp68, nil); tmp66 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(laps__5)); tmp1 = tmp63.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp64, jrt.RefArrayOf(jrt.Object_class, nil, tmp65.Invoke_O_O__O(Lit_50, tmp66))).Ref()) }; return nil }(); /*line :211:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp69 != nil { panic(tmp69) }; return tmp1 }









func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Ctor_O_O_O_O_O_O(c__forms, c__variants, c__failed, c__file, c__applied, c__ns any) { t.F_forms = c__forms; t.F_variants = c__variants; t.F_failed = c__failed; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000177__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(t.F_forms); var chunk_1607000178__4 any; var count_1607000179__5 int64 = 0; var i_1607000180__6 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z(i_1607000180__6, count_1607000179__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000178__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000180__6)); var tmp2 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__7)
														if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_152); tmp2 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }
//line :222:1
		if jrt.A2g_Truth(tmp2) {

			lang.IFn_Cast(A_arbace_a2g_world_A_const_154.GetRawRoot__O()).Invoke_O__O(fm__7)
//line :222:1
			seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, lang.Numbers_Unchecked_inc_J__J(i_1607000180__6); continue L1 } else { seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, lang.Numbers_Unchecked_inc_J__J(i_1607000180__6); continue L1 } } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000177__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000177__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8); seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8); var tmp4 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__9)
				if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_153); tmp4 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp4 = and__1927000168__auto____11 } } else { tmp4 = and__1927000168__auto____10 }
//line :222:1
				if jrt.A2g_Truth(tmp4) {

					lang.IFn_Cast(A_arbace_a2g_world_A_const_154.GetRawRoot__O()).Invoke_O__O(fm__9)
//line :222:1
					seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), nil, 0, 0; continue L1 } else { seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), nil, 0, 0; continue L1 } } } }
//line :221:1
	break L1 }; var nsobj__3 any = A_arbace_a2g_world_A_const_151.Get__O(); var seq_1607000181__4 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()); var tmp8 any; var t_ any = t.F_forms




	t.F_forms = nil; tmp8 = t_; seq_1607000181__4 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(tmp8))
//line :221:1
	var chunk_1607000182__5 any; var count_1607000183__6 int64 = 0; var i_1607000184__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000184__7, count_1607000183__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000182__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000184__7)); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__8); var tmp10 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class
			if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class = fncls__42d; tmp10 = fncls__42d } else { tmp10 = fncls__42 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :226:1
			seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, lang.Numbers_Unchecked_inc_J__J(i_1607000184__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000181__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000181__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000181__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000181__9); seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000181__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000181__9); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, cf__10, t.F_ns); var tmp12 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class
				if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class = fncls__44d; tmp12 = fncls__44d } else { tmp12 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :226:1
				seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000181__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :221:1
		break L2 } }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp13 != nil { panic(tmp13) }; return tmp1 }
//line :221:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Ctor_O_O_O_O_O_O(c__forms, c__variants, c__failed, c__file, c__applied, c__ns any) { t.F_forms = c__forms; t.F_variants = c__variants; t.F_failed = c__failed; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000203__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(t.F_forms); var chunk_1607000204__4 any; var count_1607000205__5 int64 = 0; var i_1607000206__6 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z(i_1607000206__6, count_1607000205__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000204__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000206__6)); var tmp2 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__7)
														if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_163); tmp2 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }
//line :222:1
		if jrt.A2g_Truth(tmp2) {

			lang.IFn_Cast(A_arbace_a2g_world_A_const_154.GetRawRoot__O()).Invoke_O__O(fm__7)
//line :222:1
			seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, lang.Numbers_Unchecked_inc_J__J(i_1607000206__6); continue L1 } else { seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, lang.Numbers_Unchecked_inc_J__J(i_1607000206__6); continue L1 } } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000203__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000203__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8); seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8); var tmp4 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_28.GetRawRoot__O()).Invoke_O__O(fm__9)
				if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_164); tmp4 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp4 = and__1927000168__auto____11 } } else { tmp4 = and__1927000168__auto____10 }
//line :222:1
				if jrt.A2g_Truth(tmp4) {

					lang.IFn_Cast(A_arbace_a2g_world_A_const_154.GetRawRoot__O()).Invoke_O__O(fm__9)
//line :222:1
					seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), nil, 0, 0; continue L1 } else { seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), nil, 0, 0; continue L1 } } } }
//line :221:1
	break L1 }; var nsobj__3 any = A_arbace_a2g_world_A_const_151.Get__O(); var seq_1607000207__4 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()); var tmp8 any; var t_ any = t.F_forms




	t.F_forms = nil; tmp8 = t_; seq_1607000207__4 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(tmp8))
//line :221:1
	var chunk_1607000208__5 any; var count_1607000209__6 int64 = 0; var i_1607000210__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000210__7, count_1607000209__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000208__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000210__7)); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__8); var tmp10 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class
			if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class = fncls__47d; tmp10 = fncls__47d } else { tmp10 = fncls__47 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :226:1
			seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, lang.Numbers_Unchecked_inc_J__J(i_1607000210__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000207__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000207__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000207__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000207__9); seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1607000207__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1607000207__9); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__10); var tmp12 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class
				if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class = fncls__49d; tmp12 = fncls__49d } else { tmp12 = fncls__49 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :226:1
				seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1607000207__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :221:1
		break L2 } }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp13 != nil { panic(tmp13) }; return tmp1 }





func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
															t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000186__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class = fncls__41d; tmp11 = fncls__41d } else { tmp11 = fncls__41 }; vec__1607000186__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000186__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000186__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_155.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_145, t.F_nsobj, A_arbace_a2g_world_A_const_158, A_arbace_a2g_world_A_const_159)), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_161, pc__9) } }; return nil }(); if /*line :227:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__cf, c__ns any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_cf = c__cf; t.F_ns = c__ns }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
															t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000193__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class = fncls__43d; tmp11 = fncls__43d } else { tmp11 = fncls__43 }; vec__1607000193__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000193__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000193__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_155.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_145, t.F_nsobj, A_arbace_a2g_world_A_const_158, A_arbace_a2g_world_A_const_159)), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_162, pc__9) } }; return nil }(); if /*line :227:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
															t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000212__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class = fncls__46d; tmp11 = fncls__46d } else { tmp11 = fncls__46 }; vec__1607000212__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000212__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000212__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_155.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_145, t.F_nsobj, A_arbace_a2g_world_A_const_158, A_arbace_a2g_world_A_const_159)), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_165, pc__9) } }; return nil }(); if /*line :227:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
															t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000219__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_109.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class = fncls__48d; tmp11 = fncls__48d } else { tmp11 = fncls__48 }; vec__1607000219__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000219__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000219__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_155.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_145, t.F_nsobj, A_arbace_a2g_world_A_const_158, A_arbace_a2g_world_A_const_159)), lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_166, pc__9) } }; return nil }(); if /*line :227:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }










func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :241:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp2 any = t.F_laps; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D(lang.Numbers_Minus_J_O__Number(x__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_t)), 1.0e7)), 100.0)).Ref())); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_147.GetRawRoot__O()); var tmp4 any = t.F_t; return tmp3.Invoke_O_O__O(tmp4, jrt.Long_ValueOf_J__Long(x__2).Ref()) }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_175.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :244:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_175.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_177.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_64, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :247:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_177.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_64, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_180.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :250:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_180.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A{}; t.Ctor_O_O(p0, p1); return t }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_182.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :253:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A{}; t.Ctor_O_O(p0, p1); return t }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_182.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }




func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_168.GetRawRoot__O()).Invoke_O__O(n__1)
//line :258:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_169; var tmp5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp6 any = A_arbace_a2g_world_A_const_99.GetRawRoot__O()
		var tmp7 any = A_arbace_a2g_world_A_const_170

		tmp3.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, e__4.GetMessage__String().Ref())
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp9 any = t.F_failed; var tmp10 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_52, nil, nil); var tmp12 any = e__4.GetMessage__String().Ref(); var tmp13 *jrt.String; var G__1607000261__8_ any = e__4.GetCause__Throwable(); var G__1607000261__9_ any
		if lang.Util_Identical_O_O__Z(G__1607000261__8_, nil) { G__1607000261__9_ = nil } else { G__1607000261__9_ = jrt.Throwable_Cast(G__1607000261__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z(G__1607000261__9_, nil) { tmp13 = nil } else { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_53, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1607000261__9_)) }
//line :262:1
		tmp1 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref())).Ref())) } }; return tmp1 }






func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Ctor() {}
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_171.GetRawRoot__O()).Invoke_O__O(n__1) }



func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :273:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Ctor_O_O_O_O(c__rt_space, c__names, c__compiled_QMARK_, c__analyze_BANG_ any) { t.F_rt_space = c__rt_space; t.F_names = c__names; t.F_compiled_QMARK_ = c__compiled_QMARK_; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :273:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Invoke_O__O(self any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()); var tmp2 any; var t_ any = t.F_rt_space; t.F_rt_space = nil; tmp2 = t_; tmp1.Set_O__V(tmp2)
//line :273:1
	var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()); var tmp8 any; var t__3 any = t.F_compiled_QMARK_; t.F_compiled_QMARK_ = nil; tmp8 = t__3; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_names; t.F_names = nil; tmp10 = t__4; tmp3 = tmp4.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp9, tmp10)) }
//line :273:1
		return nil
	}()

	jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_149.GetRawRoot__O()).Invoke__O()).Remove__V()
//line :273:1
	if tmp11 != nil { panic(tmp11) }; return tmp3
}









func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Ctor() {}
//line :284:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O__O(n__1, Lit_13)) }
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Invoke_O_O__O(self, s__1607000271__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_New_O_O_O(t.F_tops_QMARK_, s__1607000271__1, self); var tmp2 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class = fncls__64d; tmp2 = fncls__64d } else { tmp2 = fncls__64 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000271, c__iter__1607000270 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000271 = c__s__1607000271; t.F_iter__1607000270 = c__iter__1607000270 }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Invoke_O__O(self any) any { { var s__1607000271__1 any; var t_ any = t.F_s__1607000271; t.F_s__1607000271 = nil; s__1607000271__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000271__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000271__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000271__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000271__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000273__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_New_O_O_I_O(b__1607000273__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class = fncls__63d; tmp2 = fncls__63d } else { tmp2 = fncls__63 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000270); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000273__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000271__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000273__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000271__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000270); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000271__3))) } else { s__1607000271__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000271__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :285:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Ctor_O_O_I_O(c__b__1607000273, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000273 = c__b__1607000273; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Invoke_O__O(self any) any { { var i__1607000272__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000272__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000272__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1607000273; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000272__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000272__1); continue L1 } else { i__1607000272__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000272__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Invoke_O_O__O(self, s__1607000281__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(t.F_tops_QMARK_, s__1607000281__1, self); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :286:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000281, c__iter__1607000280 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000281 = c__s__1607000281; t.F_iter__1607000280 = c__iter__1607000280 }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Invoke_O__O(self any) any { { var s__1607000281__1 any; var t_ any = t.F_s__1607000281; t.F_s__1607000281 = nil; s__1607000281__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000281__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000281__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000281__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000283__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(b__1607000283__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000283__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000283__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { s__1607000281__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :286:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Ctor_O_O_I_O(c__b__1607000283, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000283 = c__b__1607000283; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Invoke_O__O(self any) any { { var i__1607000282__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000282__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000282__1)); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1607000283; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } else { i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Ctor_O_O(c__analyze_BANG_, c__space any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_space = c__space }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_150.GetRawRoot__O())))
//line :290:1
	var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1)
//line :290:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :290:1
	if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :290:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Ctor_O_O(c__analyze_BANG_, c__space any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_space = c__space }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_150.GetRawRoot__O())))
//line :290:1
	var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1)
//line :290:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :290:1
	if tmp3 != nil { panic(tmp3) }; return tmp2
}








func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Ctor() {}
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Invoke_O_O__O(self, s__1607000300__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_New_O_O(s__1607000300__1, self); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :300:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Ctor_O_O(c__s__1607000300, c__iter__1607000299 any) { t.F_s__1607000300 = c__s__1607000300; t.F_iter__1607000299 = c__iter__1607000299 }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Invoke_O__O(self any) any { { var s__1607000300__1 any; var t_ any = t.F_s__1607000300; t.F_s__1607000300 = nil; s__1607000300__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000300__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000300__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000300__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000300__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000302__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_New_O_I_O(b__1607000302__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000299); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000302__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000300__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000302__6), nil) } } else { var vec__1607000310__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000300__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1607000310__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1607000310__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000299); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(k__5), nil, v__6)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000300__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :300:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Ctor_O_I_O(c__b__1607000302 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000302 = c__b__1607000302; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Invoke_O__O(self any) any { { var i__1607000301__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000301__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1607000306__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000301__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1607000306__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1607000306__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1607000302; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref()); i__1607000301__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000301__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_New() *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Ctor() {}
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Invoke_O_O__O(self, s__1607000321__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_New_O_O(s__1607000321__1, self); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Ctor_O_O(c__s__1607000321, c__iter__1607000320 any) { t.F_s__1607000321 = c__s__1607000321; t.F_iter__1607000320 = c__iter__1607000320 }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Invoke_O__O(self any) any { { var s__1607000321__1 any; var t_ any = t.F_s__1607000321; t.F_s__1607000321 = nil; s__1607000321__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000321__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__1607000328__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var map__1607000328__5 any; if lang.ISeq_InstanceOf(map__1607000328__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1607000328__4)) { map__1607000328__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(map__1607000328__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000328__4)) { map__1607000328__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1607000328__4) } else { lang.PersistentArrayMap_Init(); map__1607000328__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000328__5 = map__1607000328__4 }; var file__6 any = lang.RT_Get_O_O__O(map__1607000328__5, A_arbace_a2g_world_A_const_143); var ns__7 any = lang.RT_Get_O_O__O(map__1607000328__5, A_arbace_a2g_world_A_const_145); var forms__8 any = lang.RT_Get_O_O__O(map__1607000328__5, A_arbace_a2g_world_A_const_144); if jrt.A2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_New_O(file__6); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_146.GetRawRoot__O()).Invoke_O_O__O(ns__7, forms__8))); if jrt.A2g_Truth(fs__1927001036__auto____10) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000320); return lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____10, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000321__1))) } else { s__1607000321__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000321__1); continue L1 } } else { s__1607000321__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000321__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_New_O(p0 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Invoke_O_O__O(self, s__1607000323__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_New_O_O_O(s__1607000323__1, self, t.F_file); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Ctor_O_O_O(c__s__1607000323, c__iter__1607000322, c__file any) { t.F_s__1607000323 = c__s__1607000323; t.F_iter__1607000322 = c__iter__1607000322; t.F_file = c__file }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Invoke_O__O(self any) any { { var s__1607000323__1 any; var t_ any = t.F_s__1607000323; t.F_s__1607000323 = nil; s__1607000323__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000323__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000323__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000323__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000323__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000325__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_New_O_O_I_O(b__1607000325__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000322); return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000325__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1607000323__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1607000325__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1607000323__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000322); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(t.F_file)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000323__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Ctor_O_O_I_O(c__b__1607000325, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000325 = c__b__1607000325; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Invoke_O__O(self any) any { { var i__1607000324__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000324__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000324__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1607000325; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()).Invoke_O__O(t.F_file))); i__1607000324__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000324__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_with_world_A_New() *A_arbace_a2g_world_with_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_with_world_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_a2g_world_with_world_A) Ctor() {}
//line :310:1
func (t *A_arbace_a2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_192), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_111.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_193.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_194), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(w__2))))), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_195), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_111.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_193.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_196), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_133), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_194)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_197), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_134), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_194)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_198), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_135), lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_194)))))))), body__3))))) }












































































































































































































































































type A_arbace_a2g_world_A struct{ jrt.Object }

var A_arbace_a2g_world_A_const_pool *jrt.RefArray

var A_arbace_a2g_world_A_const_0 *lang.Var

var A_arbace_a2g_world_A_const_1 *lang.Var

var A_arbace_a2g_world_A_const_2 any

var A_arbace_a2g_world_A_const_3 any

var A_arbace_a2g_world_A_const_4 any

var A_arbace_a2g_world_A_const_5 any

var A_arbace_a2g_world_A_const_6 any

var A_arbace_a2g_world_A_const_7 any

var A_arbace_a2g_world_A_const_8 any

var A_arbace_a2g_world_A_const_9 any

var A_arbace_a2g_world_A_const_10 any

var A_arbace_a2g_world_A_const_11 *lang.Var

var A_arbace_a2g_world_A_const_12 *lang.Var

var A_arbace_a2g_world_A_const_13 *lang.Var

var A_arbace_a2g_world_A_const_14 any

var A_arbace_a2g_world_A_const_15 *lang.Var

var A_arbace_a2g_world_A_const_16 *lang.Var

var A_arbace_a2g_world_A_const_17 *lang.Var

var A_arbace_a2g_world_A_const_18 *lang.Var

var A_arbace_a2g_world_A_const_19 *lang.Var

var A_arbace_a2g_world_A_const_20 *lang.Var

var A_arbace_a2g_world_A_const_21 *lang.Var

var A_arbace_a2g_world_A_const_22 *lang.Var

var A_arbace_a2g_world_A_const_23 *lang.Var

var A_arbace_a2g_world_A_const_24 *lang.Keyword

var A_arbace_a2g_world_A_const_25 *lang.Var

var A_arbace_a2g_world_A_const_26 *lang.Var

var A_arbace_a2g_world_A_const_27 any

var A_arbace_a2g_world_A_const_28 *lang.Var

var A_arbace_a2g_world_A_const_29 *lang.Var

var A_arbace_a2g_world_A_const_30 *lang.Var

var A_arbace_a2g_world_A_const_31 *lang.Var

var A_arbace_a2g_world_A_const_32 *lang.Var

var A_arbace_a2g_world_A_const_33 *lang.Var

var A_arbace_a2g_world_A_const_34 *lang.Var

var A_arbace_a2g_world_A_const_35 *lang.Var

var A_arbace_a2g_world_A_const_36 *lang.Var

var A_arbace_a2g_world_A_const_37 *lang.Var

var A_arbace_a2g_world_A_const_38 *lang.Var

var A_arbace_a2g_world_A_const_39 *lang.Var

var A_arbace_a2g_world_A_const_40 *lang.Var

var A_arbace_a2g_world_A_const_41 *lang.Var

var A_arbace_a2g_world_A_const_42 *lang.Var

var A_arbace_a2g_world_A_const_43 *lang.Var

var A_arbace_a2g_world_A_const_44 any

var A_arbace_a2g_world_A_const_45 *lang.Var

var A_arbace_a2g_world_A_const_46 *lang.Var

var A_arbace_a2g_world_A_const_47 *lang.Var

var A_arbace_a2g_world_A_const_48 *lang.Var

var A_arbace_a2g_world_A_const_49 *lang.Keyword

var A_arbace_a2g_world_A_const_50 *lang.Var

var A_arbace_a2g_world_A_const_51 *lang.Var

var A_arbace_a2g_world_A_const_52 *lang.Var

var A_arbace_a2g_world_A_const_53 *lang.Var

var A_arbace_a2g_world_A_const_54 *lang.Var

var A_arbace_a2g_world_A_const_55 *lang.Keyword

var A_arbace_a2g_world_A_const_56 *lang.Var

var A_arbace_a2g_world_A_const_57 *lang.Var

var A_arbace_a2g_world_A_const_58 *lang.Var

var A_arbace_a2g_world_A_const_59 *lang.Keyword

var A_arbace_a2g_world_A_const_60 *lang.Keyword

var A_arbace_a2g_world_A_const_61 *lang.Keyword

var A_arbace_a2g_world_A_const_62 *lang.Keyword

var A_arbace_a2g_world_A_const_63 *lang.Var

var A_arbace_a2g_world_A_const_64 *lang.Var

var A_arbace_a2g_world_A_const_65 *lang.Var

var A_arbace_a2g_world_A_const_66 *lang.Var

var A_arbace_a2g_world_A_const_67 *lang.Var

var A_arbace_a2g_world_A_const_68 any

var A_arbace_a2g_world_A_const_69 *lang.Var

var A_arbace_a2g_world_A_const_70 *lang.Var

var A_arbace_a2g_world_A_const_71 *lang.Var

var A_arbace_a2g_world_A_const_72 *lang.Var

var A_arbace_a2g_world_A_const_73 *lang.Keyword

var A_arbace_a2g_world_A_const_74 *lang.Var

var A_arbace_a2g_world_A_const_75 *lang.Keyword

var A_arbace_a2g_world_A_const_76 *lang.Var

var A_arbace_a2g_world_A_const_77 any

var A_arbace_a2g_world_A_const_78 *lang.Keyword

var A_arbace_a2g_world_A_const_79 *lang.Var

var A_arbace_a2g_world_A_const_80 *lang.Keyword

var A_arbace_a2g_world_A_const_81 *lang.Keyword

var A_arbace_a2g_world_A_const_82 *lang.Keyword

var A_arbace_a2g_world_A_const_83 *lang.Keyword

var A_arbace_a2g_world_A_const_84 *lang.Keyword

var A_arbace_a2g_world_A_const_85 any

var A_arbace_a2g_world_A_const_86 *lang.Keyword

var A_arbace_a2g_world_A_const_87 *lang.Var

var A_arbace_a2g_world_A_const_88 *lang.Var

var A_arbace_a2g_world_A_const_89 any

var A_arbace_a2g_world_A_const_90 *lang.Var

var A_arbace_a2g_world_A_const_91 *lang.Var

var A_arbace_a2g_world_A_const_92 *lang.Var

var A_arbace_a2g_world_A_const_93 *lang.Var

var A_arbace_a2g_world_A_const_94 *lang.Var

var A_arbace_a2g_world_A_const_95 *lang.Var

var A_arbace_a2g_world_A_const_96 *lang.Var

var A_arbace_a2g_world_A_const_97 any

var A_arbace_a2g_world_A_const_98 *lang.Var

var A_arbace_a2g_world_A_const_99 *lang.Var

var A_arbace_a2g_world_A_const_100 *lang.Var

var A_arbace_a2g_world_A_const_101 *lang.Var

var A_arbace_a2g_world_A_const_102 any

var A_arbace_a2g_world_A_const_103 *lang.Var

var A_arbace_a2g_world_A_const_104 *lang.Var

var A_arbace_a2g_world_A_const_105 *lang.Keyword

var A_arbace_a2g_world_A_const_106 *lang.Keyword

var A_arbace_a2g_world_A_const_107 *lang.Var

var A_arbace_a2g_world_A_const_108 *lang.Keyword

var A_arbace_a2g_world_A_const_109 *lang.Var

var A_arbace_a2g_world_A_const_110 *lang.Var

var A_arbace_a2g_world_A_const_111 *lang.Var

var A_arbace_a2g_world_A_const_112 *lang.Var

var A_arbace_a2g_world_A_const_113 *lang.Var

var A_arbace_a2g_world_A_const_114 *lang.Var

var A_arbace_a2g_world_A_const_115 *lang.Var

var A_arbace_a2g_world_A_const_116 *lang.Keyword

var A_arbace_a2g_world_A_const_117 *lang.Keyword

var A_arbace_a2g_world_A_const_118 *lang.Keyword

var A_arbace_a2g_world_A_const_119 *lang.Keyword

var A_arbace_a2g_world_A_const_120 *lang.Keyword

var A_arbace_a2g_world_A_const_121 *lang.Keyword

var A_arbace_a2g_world_A_const_122 *lang.Keyword

var A_arbace_a2g_world_A_const_123 *lang.Keyword

var A_arbace_a2g_world_A_const_124 *jrt.Class

var A_arbace_a2g_world_A_const_125 *lang.Keyword

var A_arbace_a2g_world_A_const_126 *lang.Var

var A_arbace_a2g_world_A_const_127 *lang.Var

var A_arbace_a2g_world_A_const_128 *lang.Var

var A_arbace_a2g_world_A_const_129 *lang.Var

var A_arbace_a2g_world_A_const_130 *lang.Var

var A_arbace_a2g_world_A_const_131 *lang.Var

var A_arbace_a2g_world_A_const_132 *lang.Var

var A_arbace_a2g_world_A_const_133 *lang.Keyword

var A_arbace_a2g_world_A_const_134 *lang.Keyword

var A_arbace_a2g_world_A_const_135 *lang.Keyword

var A_arbace_a2g_world_A_const_136 *lang.Keyword

var A_arbace_a2g_world_A_const_137 *lang.Keyword

var A_arbace_a2g_world_A_const_138 *lang.Keyword

var A_arbace_a2g_world_A_const_139 *lang.Keyword

var A_arbace_a2g_world_A_const_140 *lang.Keyword

var A_arbace_a2g_world_A_const_141 *lang.Var

var A_arbace_a2g_world_A_const_142 *lang.Var

var A_arbace_a2g_world_A_const_143 *lang.Keyword

var A_arbace_a2g_world_A_const_144 *lang.Keyword

var A_arbace_a2g_world_A_const_145 *lang.Keyword

var A_arbace_a2g_world_A_const_146 *lang.Var

var A_arbace_a2g_world_A_const_147 *lang.Var

var A_arbace_a2g_world_A_const_148 *lang.Var

var A_arbace_a2g_world_A_const_149 *lang.Var

var A_arbace_a2g_world_A_const_150 *lang.Var

var A_arbace_a2g_world_A_const_151 *lang.Var

var A_arbace_a2g_world_A_const_152 any

var A_arbace_a2g_world_A_const_153 any

var A_arbace_a2g_world_A_const_154 *lang.Var

var A_arbace_a2g_world_A_const_155 *lang.Var

var A_arbace_a2g_world_A_const_156 *lang.Var

var A_arbace_a2g_world_A_const_157 *lang.Var

var A_arbace_a2g_world_A_const_158 *lang.Keyword

var A_arbace_a2g_world_A_const_159 *lang.Keyword

var A_arbace_a2g_world_A_const_160 *lang.Var

var A_arbace_a2g_world_A_const_161 any

var A_arbace_a2g_world_A_const_162 any

var A_arbace_a2g_world_A_const_163 any

var A_arbace_a2g_world_A_const_164 any

var A_arbace_a2g_world_A_const_165 any

var A_arbace_a2g_world_A_const_166 any

var A_arbace_a2g_world_A_const_167 *lang.Var

var A_arbace_a2g_world_A_const_168 *lang.Var

var A_arbace_a2g_world_A_const_169 *lang.Keyword

var A_arbace_a2g_world_A_const_170 *lang.Keyword

var A_arbace_a2g_world_A_const_171 *lang.Var

var A_arbace_a2g_world_A_const_172 *lang.Var

var A_arbace_a2g_world_A_const_173 *lang.Keyword

var A_arbace_a2g_world_A_const_174 *lang.Keyword

var A_arbace_a2g_world_A_const_175 *lang.Var

var A_arbace_a2g_world_A_const_176 *lang.Keyword

var A_arbace_a2g_world_A_const_177 *lang.Var

var A_arbace_a2g_world_A_const_178 *lang.Keyword

var A_arbace_a2g_world_A_const_179 *lang.Var

var A_arbace_a2g_world_A_const_180 *lang.Var

var A_arbace_a2g_world_A_const_181 *lang.Keyword

var A_arbace_a2g_world_A_const_182 *lang.Var

var A_arbace_a2g_world_A_const_183 *lang.Var

var A_arbace_a2g_world_A_const_184 *lang.Keyword

var A_arbace_a2g_world_A_const_185 *lang.Keyword

var A_arbace_a2g_world_A_const_186 *lang.Var

var A_arbace_a2g_world_A_const_187 *lang.Var

var A_arbace_a2g_world_A_const_188 *lang.Var

var A_arbace_a2g_world_A_const_189 *lang.Var

var A_arbace_a2g_world_A_const_190 *lang.Var

var A_arbace_a2g_world_A_const_191 *lang.Var

var A_arbace_a2g_world_A_const_192 any

var A_arbace_a2g_world_A_const_193 *lang.Var

var A_arbace_a2g_world_A_const_194 any

var A_arbace_a2g_world_A_const_195 any

var A_arbace_a2g_world_A_const_196 any

var A_arbace_a2g_world_A_const_197 any

var A_arbace_a2g_world_A_const_198 any

var A_arbace_a2g_world_A_init jrt.ClassInit

func A_arbace_a2g_world_A_Init() { if !A_arbace_a2g_world_A_init.Done() { A_arbace_a2g_world_A_init.Run(A_arbace_a2g_world_A_clinit) } }

func A_arbace_a2g_world_A_clinit() { A_arbace_a2g_world_A_clinit_p0(); A_arbace_a2g_world_A_clinit_p1(); A_arbace_a2g_world_A_clinit_p2(); A_arbace_a2g_world_A_clinit_p3(); A_arbace_a2g_world_A_clinit_p4(); A_arbace_a2g_world_A_clinit_p5(); A_arbace_a2g_world_A_clinit_p6(); A_arbace_a2g_world_A_clinit_p7(); A_arbace_a2g_world_A_clinit_p8(); A_arbace_a2g_world_A_clinit_p9(); A_arbace_a2g_world_A_clinit_p10(); A_arbace_a2g_world_A_clinit_p11(); A_arbace_a2g_world_A_clinit_p12(); A_arbace_a2g_world_A_clinit_p13(); A_arbace_a2g_world_A_clinit_p14(); A_arbace_a2g_world_A_clinit_p15(); A_arbace_a2g_world_A_clinit_p16() }

func A_arbace_a2g_world_A_clinit_p0() { A_arbace_a2g_world_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 280); A_arbace_a2g_world_A_const_0 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[81]); A_arbace_a2g_world_A_const_1 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[82]); A_arbace_a2g_world_A_const_2 = A_arbace_a2g_world_A_const_pool.A[83]; A_arbace_a2g_world_A_const_3 = A_arbace_a2g_world_A_const_pool.A[84]; A_arbace_a2g_world_A_const_4 = A_arbace_a2g_world_A_const_pool.A[85]; A_arbace_a2g_world_A_const_5 = A_arbace_a2g_world_A_const_pool.A[86]; A_arbace_a2g_world_A_const_6 = A_arbace_a2g_world_A_const_pool.A[87]; A_arbace_a2g_world_A_const_7 = A_arbace_a2g_world_A_const_pool.A[88]; A_arbace_a2g_world_A_const_8 = A_arbace_a2g_world_A_const_pool.A[89]; A_arbace_a2g_world_A_const_9 = A_arbace_a2g_world_A_const_pool.A[90]; A_arbace_a2g_world_A_const_10 = A_arbace_a2g_world_A_const_pool.A[91]; A_arbace_a2g_world_A_const_11 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[92]); A_arbace_a2g_world_A_const_12 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[93]) }

func A_arbace_a2g_world_A_clinit_p1() { A_arbace_a2g_world_A_const_13 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[94]); A_arbace_a2g_world_A_const_14 = A_arbace_a2g_world_A_const_pool.A[95]; A_arbace_a2g_world_A_const_15 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[96]); A_arbace_a2g_world_A_const_16 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[97]); A_arbace_a2g_world_A_const_17 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[98]); A_arbace_a2g_world_A_const_18 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[99]); A_arbace_a2g_world_A_const_19 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[100]); A_arbace_a2g_world_A_const_20 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[101]); A_arbace_a2g_world_A_const_21 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[102]); A_arbace_a2g_world_A_const_22 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[103]); A_arbace_a2g_world_A_const_23 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[104]); A_arbace_a2g_world_A_const_24 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[105]) }

func A_arbace_a2g_world_A_clinit_p2() { A_arbace_a2g_world_A_const_25 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[106]); A_arbace_a2g_world_A_const_26 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[107]); A_arbace_a2g_world_A_const_27 = A_arbace_a2g_world_A_const_pool.A[108]; A_arbace_a2g_world_A_const_28 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[109]); A_arbace_a2g_world_A_const_29 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[110]); A_arbace_a2g_world_A_const_30 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[111]); A_arbace_a2g_world_A_const_31 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[112]); A_arbace_a2g_world_A_const_32 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[113]); A_arbace_a2g_world_A_const_33 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[114]); A_arbace_a2g_world_A_const_34 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[115]); A_arbace_a2g_world_A_const_35 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[116]); A_arbace_a2g_world_A_const_36 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[117]) }

func A_arbace_a2g_world_A_clinit_p3() { A_arbace_a2g_world_A_const_37 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[118]); A_arbace_a2g_world_A_const_38 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[119]); A_arbace_a2g_world_A_const_39 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[120]); A_arbace_a2g_world_A_const_40 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[121]); A_arbace_a2g_world_A_const_41 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[122]); A_arbace_a2g_world_A_const_42 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[123]); A_arbace_a2g_world_A_const_43 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[124]); A_arbace_a2g_world_A_const_44 = A_arbace_a2g_world_A_const_pool.A[125]; A_arbace_a2g_world_A_const_45 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[126]); A_arbace_a2g_world_A_const_46 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[127]); A_arbace_a2g_world_A_const_47 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[128]); A_arbace_a2g_world_A_const_48 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[129]) }

func A_arbace_a2g_world_A_clinit_p4() { A_arbace_a2g_world_A_const_49 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[130]); A_arbace_a2g_world_A_const_50 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[131]); A_arbace_a2g_world_A_const_51 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[132]); A_arbace_a2g_world_A_const_52 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[133]); A_arbace_a2g_world_A_const_53 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[134]); A_arbace_a2g_world_A_const_54 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[135]); A_arbace_a2g_world_A_const_55 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[136]); A_arbace_a2g_world_A_const_56 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[137]); A_arbace_a2g_world_A_const_57 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[138]); A_arbace_a2g_world_A_const_58 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[139]); A_arbace_a2g_world_A_const_59 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[140]); A_arbace_a2g_world_A_const_60 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[141]) }

func A_arbace_a2g_world_A_clinit_p5() { A_arbace_a2g_world_A_const_61 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[142]); A_arbace_a2g_world_A_const_62 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[143]); A_arbace_a2g_world_A_const_63 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[144]); A_arbace_a2g_world_A_const_64 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[145]); A_arbace_a2g_world_A_const_65 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[146]); A_arbace_a2g_world_A_const_66 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[147]); A_arbace_a2g_world_A_const_67 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[148]); A_arbace_a2g_world_A_const_68 = A_arbace_a2g_world_A_const_pool.A[149]; A_arbace_a2g_world_A_const_69 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[150]); A_arbace_a2g_world_A_const_70 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[151]); A_arbace_a2g_world_A_const_71 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[152]); A_arbace_a2g_world_A_const_72 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[153]) }

func A_arbace_a2g_world_A_clinit_p6() { A_arbace_a2g_world_A_const_73 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[154]); A_arbace_a2g_world_A_const_74 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[155]); A_arbace_a2g_world_A_const_75 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[156]); A_arbace_a2g_world_A_const_76 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[157]); A_arbace_a2g_world_A_const_77 = A_arbace_a2g_world_A_const_pool.A[158]; A_arbace_a2g_world_A_const_78 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[159]); A_arbace_a2g_world_A_const_79 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[160]); A_arbace_a2g_world_A_const_80 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[161]); A_arbace_a2g_world_A_const_81 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[162]); A_arbace_a2g_world_A_const_82 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[163]); A_arbace_a2g_world_A_const_83 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[164]); A_arbace_a2g_world_A_const_84 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[165]) }

func A_arbace_a2g_world_A_clinit_p7() { A_arbace_a2g_world_A_const_85 = A_arbace_a2g_world_A_const_pool.A[166]; A_arbace_a2g_world_A_const_86 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[167]); A_arbace_a2g_world_A_const_87 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[168]); A_arbace_a2g_world_A_const_88 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[169]); A_arbace_a2g_world_A_const_89 = A_arbace_a2g_world_A_const_pool.A[170]; A_arbace_a2g_world_A_const_90 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[171]); A_arbace_a2g_world_A_const_91 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[172]); A_arbace_a2g_world_A_const_92 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[173]); A_arbace_a2g_world_A_const_93 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[174]); A_arbace_a2g_world_A_const_94 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[175]); A_arbace_a2g_world_A_const_95 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[176]); A_arbace_a2g_world_A_const_96 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[177]) }

func A_arbace_a2g_world_A_clinit_p8() { A_arbace_a2g_world_A_const_97 = A_arbace_a2g_world_A_const_pool.A[178]; A_arbace_a2g_world_A_const_98 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[179]); A_arbace_a2g_world_A_const_99 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[180]); A_arbace_a2g_world_A_const_100 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[181]); A_arbace_a2g_world_A_const_101 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[182]); A_arbace_a2g_world_A_const_102 = A_arbace_a2g_world_A_const_pool.A[183]; A_arbace_a2g_world_A_const_103 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[184]); A_arbace_a2g_world_A_const_104 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[185]); A_arbace_a2g_world_A_const_105 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[186]); A_arbace_a2g_world_A_const_106 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[187]); A_arbace_a2g_world_A_const_107 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[188]); A_arbace_a2g_world_A_const_108 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[189]) }

func A_arbace_a2g_world_A_clinit_p9() { A_arbace_a2g_world_A_const_109 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[190]); A_arbace_a2g_world_A_const_110 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[191]); A_arbace_a2g_world_A_const_111 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[192]); A_arbace_a2g_world_A_const_112 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[193]); A_arbace_a2g_world_A_const_113 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[194]); A_arbace_a2g_world_A_const_114 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[195]); A_arbace_a2g_world_A_const_115 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[196]); A_arbace_a2g_world_A_const_116 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[197]); A_arbace_a2g_world_A_const_117 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[198]); A_arbace_a2g_world_A_const_118 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[199]); A_arbace_a2g_world_A_const_119 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[200]); A_arbace_a2g_world_A_const_120 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[201]) }

func A_arbace_a2g_world_A_clinit_p10() { A_arbace_a2g_world_A_const_121 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[202]); A_arbace_a2g_world_A_const_122 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[203]); A_arbace_a2g_world_A_const_123 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[204]); A_arbace_a2g_world_A_const_124 = jrt.Class_Cast(A_arbace_a2g_world_A_const_pool.A[205]); A_arbace_a2g_world_A_const_125 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[206]); A_arbace_a2g_world_A_const_126 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[207]); A_arbace_a2g_world_A_const_127 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[208]); A_arbace_a2g_world_A_const_128 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[209]); A_arbace_a2g_world_A_const_129 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[210]); A_arbace_a2g_world_A_const_130 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[211]); A_arbace_a2g_world_A_const_131 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[212]); A_arbace_a2g_world_A_const_132 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[213]) }

func A_arbace_a2g_world_A_clinit_p11() { A_arbace_a2g_world_A_const_133 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[214]); A_arbace_a2g_world_A_const_134 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[215]); A_arbace_a2g_world_A_const_135 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[216]); A_arbace_a2g_world_A_const_136 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[217]); A_arbace_a2g_world_A_const_137 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[218]); A_arbace_a2g_world_A_const_138 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[219]); A_arbace_a2g_world_A_const_139 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[220]); A_arbace_a2g_world_A_const_140 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[221]); A_arbace_a2g_world_A_const_141 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[222]); A_arbace_a2g_world_A_const_142 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[223]); A_arbace_a2g_world_A_const_143 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[224]); A_arbace_a2g_world_A_const_144 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[225]) }

func A_arbace_a2g_world_A_clinit_p12() { A_arbace_a2g_world_A_const_145 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[226]); A_arbace_a2g_world_A_const_146 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[227]); A_arbace_a2g_world_A_const_147 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[228]); A_arbace_a2g_world_A_const_148 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[229]); A_arbace_a2g_world_A_const_149 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[230]); A_arbace_a2g_world_A_const_150 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[231]); A_arbace_a2g_world_A_const_151 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[232]); A_arbace_a2g_world_A_const_152 = A_arbace_a2g_world_A_const_pool.A[233]; A_arbace_a2g_world_A_const_153 = A_arbace_a2g_world_A_const_pool.A[234]; A_arbace_a2g_world_A_const_154 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[235]); A_arbace_a2g_world_A_const_155 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[236]); A_arbace_a2g_world_A_const_156 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[237]) }

func A_arbace_a2g_world_A_clinit_p13() { A_arbace_a2g_world_A_const_157 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[238]); A_arbace_a2g_world_A_const_158 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[239]); A_arbace_a2g_world_A_const_159 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[240]); A_arbace_a2g_world_A_const_160 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[241]); A_arbace_a2g_world_A_const_161 = A_arbace_a2g_world_A_const_pool.A[242]; A_arbace_a2g_world_A_const_162 = A_arbace_a2g_world_A_const_pool.A[243]; A_arbace_a2g_world_A_const_163 = A_arbace_a2g_world_A_const_pool.A[244]; A_arbace_a2g_world_A_const_164 = A_arbace_a2g_world_A_const_pool.A[245]; A_arbace_a2g_world_A_const_165 = A_arbace_a2g_world_A_const_pool.A[246]; A_arbace_a2g_world_A_const_166 = A_arbace_a2g_world_A_const_pool.A[247]; A_arbace_a2g_world_A_const_167 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[248]); A_arbace_a2g_world_A_const_168 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[249]); A_arbace_a2g_world_A_const_169 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[250]) }

func A_arbace_a2g_world_A_clinit_p14() { A_arbace_a2g_world_A_const_170 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[251]); A_arbace_a2g_world_A_const_171 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[252]); A_arbace_a2g_world_A_const_172 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[253]); A_arbace_a2g_world_A_const_173 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[254]); A_arbace_a2g_world_A_const_174 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[255]); A_arbace_a2g_world_A_const_175 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[256]); A_arbace_a2g_world_A_const_176 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[257]); A_arbace_a2g_world_A_const_177 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[258]); A_arbace_a2g_world_A_const_178 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[259]); A_arbace_a2g_world_A_const_179 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[260]); A_arbace_a2g_world_A_const_180 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[261]); A_arbace_a2g_world_A_const_181 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[262]) }

func A_arbace_a2g_world_A_clinit_p15() { A_arbace_a2g_world_A_const_182 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[263]); A_arbace_a2g_world_A_const_183 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[264]); A_arbace_a2g_world_A_const_184 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[265]); A_arbace_a2g_world_A_const_185 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[266]); A_arbace_a2g_world_A_const_186 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[267]); A_arbace_a2g_world_A_const_187 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[268]); A_arbace_a2g_world_A_const_188 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[269]); A_arbace_a2g_world_A_const_189 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[270]); A_arbace_a2g_world_A_const_190 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[271]); A_arbace_a2g_world_A_const_191 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[272]); A_arbace_a2g_world_A_const_192 = A_arbace_a2g_world_A_const_pool.A[273]; A_arbace_a2g_world_A_const_193 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[274]) }

func A_arbace_a2g_world_A_clinit_p16() { A_arbace_a2g_world_A_const_194 = A_arbace_a2g_world_A_const_pool.A[275]; A_arbace_a2g_world_A_const_195 = A_arbace_a2g_world_A_const_pool.A[276]; A_arbace_a2g_world_A_const_196 = A_arbace_a2g_world_A_const_pool.A[277]; A_arbace_a2g_world_A_const_197 = A_arbace_a2g_world_A_const_pool.A[278]; A_arbace_a2g_world_A_const_198 = A_arbace_a2g_world_A_const_pool.A[279] }

func A_arbace_a2g_world_A_New() *A_arbace_a2g_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_A) Ctor() {}

func (t *A_arbace_a2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_A_class }

func (t *A_arbace_a2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_A); return ok }

func A_arbace_a2g_world_A_Cast(x any) *A_arbace_a2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_apply_variant_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000127_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000129_A struct{ a2g_header uint64; F_counts any }

var A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000138_A struct{ a2g_header uint64; F_variants_of, F_prefix, F_applied any }

var A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_form_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A struct{ a2g_header uint64; F_iter__1607000019, F_s__1607000020 any }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A struct{ a2g_header uint64; F_iter__1607000021, F_s__1607000022 any }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A struct{ a2g_header uint64; F_b__1607000024 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_parts_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_parts_A_fn_class *jrt.Class



type A_arbace_a2g_world_cut_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_cut_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000004_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000004_A_New() *A_arbace_a2g_world_eval1607000004_A { t := &A_arbace_a2g_world_eval1607000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000004_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000004_A_class }

func (t *A_arbace_a2g_world_eval1607000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000004_A); return ok }

func A_arbace_a2g_world_eval1607000004_A_Cast(x any) *A_arbace_a2g_world_eval1607000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000004_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000008_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000008_A_New() *A_arbace_a2g_world_eval1607000008_A { t := &A_arbace_a2g_world_eval1607000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000008_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000008_A_class }

func (t *A_arbace_a2g_world_eval1607000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000008_A); return ok }

func A_arbace_a2g_world_eval1607000008_A_Cast(x any) *A_arbace_a2g_world_eval1607000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000008_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000008_fn__1607000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class *jrt.Class



type A_arbace_a2g_world_head_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_head_name_A_fn_class *jrt.Class



type A_arbace_a2g_world_id_space_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_id_space_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000158_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000161_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_A struct{ a2g_header uint64; F_parsed, F_variants, F_failed, F_applied, F_unit any }

var A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A struct{ a2g_header uint64; F_forms, F_variants, F_failed, F_file, F_applied, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_file, F_applied, F_cf, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A struct{ a2g_header uint64; F_forms, F_variants, F_failed, F_file, F_applied, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A struct{ a2g_header uint64; F_rt_space, F_names, F_compiled_QMARK_, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A struct{ a2g_header uint64; F_analyze_BANG_, F_space any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A struct{ a2g_header uint64; F_analyze_BANG_, F_space any }

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A struct{ a2g_header uint64; F_tops_QMARK_, F_s__1607000271, F_iter__1607000270 any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A struct{ a2g_header uint64; F_b__1607000273, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A struct{ a2g_header uint64; F_tops_QMARK_, F_s__1607000281, F_iter__1607000280 any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A struct{ a2g_header uint64; F_b__1607000283, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A struct{ a2g_header uint64; F_s__1607000300, F_iter__1607000299 any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A struct{ a2g_header uint64; F_b__1607000302 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A struct{ a2g_header uint64; F_t, F_laps any }

var A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_from_source__1607000167_A struct{ a2g_header uint64; F_tops, F_top_of any }

var A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A struct{ a2g_header uint64; F_s__1607000321, F_iter__1607000320 any }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A struct{ a2g_header uint64; F_file any }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A struct{ a2g_header uint64; F_s__1607000323, F_iter__1607000322, F_file any }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A struct{ a2g_header uint64; F_b__1607000325, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_of__1607000165_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class *jrt.Class



type A_arbace_a2g_world_new_unit_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_new_unit_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_fn__1607000037_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000089_A struct{ a2g_header uint64; F_f any }

var A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000091_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000097_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000099_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000105_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000107_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000013_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000015_A struct{ a2g_header uint64; F_r any }

var A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000144_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000062_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000066_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A struct{ a2g_header uint64; F_root any }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A struct{ a2g_header uint64; F_s__1607000069, F_iter__1607000068, F_root any }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A struct{ a2g_header uint64; F_s__1607000071, F_iter__1607000070 any }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A struct{ a2g_header uint64; F_b__1607000073 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_top_names_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A struct{ a2g_header uint64; F_iter__1607000040, F_nsname, F_s__1607000041 any }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A struct{ a2g_header uint64; F_b__1607000043, F_nsname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class *jrt.Class



type A_arbace_a2g_world_with_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_with_world_A_fn_class *jrt.Class
