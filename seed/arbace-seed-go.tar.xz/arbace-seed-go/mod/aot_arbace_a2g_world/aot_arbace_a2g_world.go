//line aot_arbace_a2g_world.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New() *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_world_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_2); lang.IFn_Cast(A_arbace_a2g_world_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_3, A_arbace_a2g_world_A_const_4, A_arbace_a2g_world_A_const_5, A_arbace_a2g_world_A_const_6, A_arbace_a2g_world_A_const_7, A_arbace_a2g_world_A_const_8, A_arbace_a2g_world_A_const_9, A_arbace_a2g_world_A_const_10); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_21)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp5 != nil { panic(tmp5) }; return tmp3 }
//line :1:1
func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New() *A_arbace_a2g_world_eval1607000008_fn__1607000009_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000008_fn__1607000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_15), A_arbace_a2g_world_A_const_13.GetRawRoot__O(), A_arbace_a2g_world_A_const_14) }















func A_arbace_a2g_world_read_forms_A_New() *A_arbace_a2g_world_read_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_21; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_17.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_22.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_read_forms_fn__1607000013_A_New(); var tmp9 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class = fncls__1d; tmp9 = fncls__1d } else { tmp9 = fncls__1 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(r__2); var tmp13 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class = fncls__2d; tmp13 = fncls__2d } else { tmp13 = fncls__2 }; tmp1 = tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)))) }
//line :19:1
		return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :17:1
		if tmp14 != nil { panic(tmp14) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp15 != nil { panic(tmp15) }; return tmp1 }


func A_arbace_a2g_world_read_forms_fn__1607000013_A_New() *A_arbace_a2g_world_read_forms_fn__1607000013_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Invoke_O_O__O(self, p1__1607000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_23.GetRawRoot__O()).Invoke_O_O__O(p1__1607000012_SHARP___1, A_arbace_a2g_world_A_const_24) }
//line :20:1
func A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(p0 any) *A_arbace_a2g_world_read_forms_fn__1607000015_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_27, t.F_r) }

func A_arbace_a2g_world_first_form_A_New() *A_arbace_a2g_world_first_form_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_first_form_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_a2g_world_first_form_A) Ctor() {}
//line :22:1
func (t *A_arbace_a2g_world_first_form_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_21; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :22:1
		{ var x__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_28, r__2)





			if lang.Util_Equiv_O_O__Z(x__7, A_arbace_a2g_world_A_const_24) { tmp1 = nil } else { tmp1 = x__7 } }
//line :26:1
		return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :22:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :22:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_a2g_world_class_form_QMARK__A_New() *A_arbace_a2g_world_class_form_QMARK__A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_class_forms_A_New() *A_arbace_a2g_world_class_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_a2g_world_class_forms_A) Ctor() {}
//line :32:1
func (t *A_arbace_a2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class; if
											fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_New() *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A) Invoke_O_O__O(self, s__1607000021__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_New_O_O(self, s__1607000021__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A) Ctor_O_O(c__iter__1607000020, c__s__1607000021 any) { t.F_iter__1607000020 = c__iter__1607000020; t.F_s__1607000021 = c__s__1607000021 }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A) Invoke_O__O(self any) any { { var s__1607000021__1 any; var t_ any = t.F_s__1607000021; t.F_s__1607000021 = nil; s__1607000021__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000021__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__4)
															if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_a2g_world_A_const_45; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__4))).Ref() } else { tmp6 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp6) { tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(f__4) } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :33:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1607000020); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000021__1))) } else { s__1607000021__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000021__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_New() *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A) Invoke_O_O__O(self, s__1607000023__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_New_O_O(self, s__1607000023__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A) Ctor_O_O(c__iter__1607000022, c__s__1607000023 any) { t.F_iter__1607000022 = c__iter__1607000022; t.F_s__1607000023 = c__s__1607000023 }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A) Invoke_O__O(self any) any { { var s__1607000023__1 any; var t_ any = t.F_s__1607000023; t.F_s__1607000023 = nil; s__1607000023__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000023__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000023__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000023__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000025__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_New_O_I_O(b__1607000025__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000022); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000025__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000023__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000025__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000022); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000023__3))) } else { s__1607000023__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A) Ctor_O_I_O(c__b__1607000025 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000025 = c__b__1607000025; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A) Invoke_O__O(self any) any { { var i__1607000024__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000024__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000024__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__2)) { lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000025, f__2); i__1607000024__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000024__1); continue L1 } else { i__1607000024__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000024__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_continued_QMARK__A_New() *A_arbace_a2g_world_continued_QMARK__A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_continued_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_a2g_world_continued_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_a2g_world_continued_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_a2g_world_A_const_46; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_join_continued_A_New() *A_arbace_a2g_world_join_continued_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_a2g_world_join_continued_A) Ctor() {}
//line :40:1
func (t *A_arbace_a2g_world_join_continued_A) Invoke_O_O__O(self, ps__0 any) any { var conts__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;








	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A_New(); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ps__0); conts__2 = tmp1.Invoke_O_O__O(tmp3, tmp4); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(conts__2)) { return ps__0 } else { var claimed__3 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp8 *lang.PersistentHashSet

		lang.PersistentHashSet_Init(); tmp8 = lang.PersistentHashSet_EMPTY; claimed__3 = tmp7.Invoke_O__O(tmp8.Ref())
//line :51:1
		var ps__4 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_world_join_continued_fn__1607000057_A_New_O_O(claimed__3, conts__2); var tmp11 *jrt.Class
		var fncls__19 /*line :51:1*/*jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_A_fn_class


		if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_world_join_continued_fn__1607000057_A_fn_class = fncls__19d; tmp11 = fncls__19d } else { tmp11 = fncls__19 }; ps__4 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), ps__0)
//line :51:1
		var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_77.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(claimed__3), lang.IFn_Cast(A_arbace_a2g_world_A_const_78.GetRawRoot__O()).Invoke_O__O(conts__2)))

















		if jrt.A2g_Truth(temp__1927000414__auto____5) { var u__6 any = temp__1927000414__auto____5; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()); var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_80.GetRawRoot__O()).Invoke_O__O(u__6)))).Ref(); var tmp14 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp14 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp12.Invoke_O_O__O(tmp13, tmp14.Ref())))) }
//line :51:1
		return ps__4 } }
//line :49:1
func A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A_New() *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A) Ctor() {}
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A) Invoke_O_O__O(self, s__1607000040__1 any) any { var tmp1 any = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A_New_O_O(self, s__1607000040__1); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A) Ctor_O_O(c__iter__1607000039, c__s__1607000040 any) { t.F_iter__1607000039 = c__iter__1607000039; t.F_s__1607000040 = c__s__1607000040 }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A) Invoke_O__O(self any) any { { var s__1607000040__1 any; var t_ any = t.F_s__1607000040; t.F_s__1607000040 = nil; s__1607000040__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000040__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__1607000047__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var map__1607000047__5 any; if lang.ISeq_InstanceOf(map__1607000047__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000047__4)) { map__1607000047__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000047__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000047__4)) { map__1607000047__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000047__4) } else { lang.PersistentArrayMap_Init(); map__1607000047__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000047__5 = map__1607000047__4 }; var forms__6 any = lang.RT_Get_O_O__O(map__1607000047__5, A_arbace_a2g_world_A_const_53); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A_New(); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(forms__6)); if jrt.A2g_Truth(fs__1927001036__auto____8) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000039); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000040__1))) } else { s__1607000040__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000040__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :49:1
func A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A_New() *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A) Ctor() {}
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A) Invoke_O_O__O(self, s__1607000042__1 any) any { var tmp1 any = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A_New_O_O(self, s__1607000042__1); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :49:1
func A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A) Ctor_O_O(c__iter__1607000041, c__s__1607000042 any) { t.F_iter__1607000041 = c__iter__1607000041; t.F_s__1607000042 = c__s__1607000042 }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A) Invoke_O__O(self any) any { { var s__1607000042__1 any; var t_ any = t.F_s__1607000042; t.F_s__1607000042 = nil; s__1607000042__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000042__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000042__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000042__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000042__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000044__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A_New_O_I_O(b__1607000044__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000041); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000044__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000042__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000044__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000042__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000041); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(f__4, lang.RT_IntCast_J__I(1))), lang.RT_Nth_O_I__O(f__4, lang.RT_IntCast_J__I(2))), lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_57, f__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000042__3))) } else { s__1607000042__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000042__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :49:1
func A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A) Ctor_O_I_O(c__b__1607000044 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000044 = c__b__1607000044; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :49:1
func (t *A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A) Invoke_O__O(self any) any { { var i__1607000043__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000043__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000044; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(f__2, lang.RT_IntCast_J__I(1))), lang.RT_Nth_O_I__O(f__2, lang.RT_IntCast_J__I(2))), lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_57, f__2))); i__1607000043__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000043__1); continue L1 } else { i__1607000043__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000043__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_join_continued_fn__1607000057_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_join_continued_fn__1607000057_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :54:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :54:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_53; var tmp3 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A_New_O_O(t.F_claimed, t.F_conts); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A_fn_class
	if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }
//line :55:1
	return tmp1.Invoke_O_O_O__O(p__1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :56:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A) Invoke_O_O__O(self, forms__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A_New_O_O(t.F_claimed, t.F_conts); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__1); return tmp1.Invoke_O__O(tmp2) }
//line :57:1
func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A) Ctor_O_O(c__claimed, c__conts any) { t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A) Invoke_O_O__O(self, s__1607000060__1 any) any { var tmp1 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A_New_O_O_O_O(self, s__1607000060__1, t.F_claimed, t.F_conts); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :57:1
func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A) Ctor_O_O_O_O(c__iter__1607000059, c__s__1607000060, c__claimed, c__conts any) { t.F_iter__1607000059 = c__iter__1607000059; t.F_s__1607000060 = c__s__1607000060; t.F_claimed = c__claimed; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A) Invoke_O__O(self any) any { { var s__1607000060__1 any; var t_ any = t.F_s__1607000060; t.F_s__1607000060 = nil; s__1607000060__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000060__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000060__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000060__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000060__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000062__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A_New_O_O_I_O_O(b__1607000062__6, t.F_claimed, size__1927001038__auto____5, c__1927001037__auto____4, t.F_conts); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000059); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000062__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000060__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000062__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000060__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O__O(f__4))) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()); var tmp5 any; var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__4)
																			if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp6 *lang.Keyword = A_arbace_a2g_world_A_const_61; temp__1927000408__auto____5 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__4)) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; var c__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(f__4)); var ks__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A_New_O(c__7); var tmp9 *jrt.Class
																				var fncls__15 /*line :58:1*/*jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A_fn_class

		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A_fn_class = fncls__15d; tmp9 = fncls__15d } else { tmp9 = fncls__15 }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_world_A_const_67; ks__8 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), tmp10.Invoke_O_O__O(tmp11, lang.Numbers_Inc_O__Number(n__6)))
//line :58:1
		var seq_1607000075__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(ks__8); var chunk_1607000076__10 any; var count_1607000077__11 int64 = 0; var i_1607000078__12 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z(i_1607000078__12, count_1607000077__11) { var k__13 any = lang.Indexed_Cast(chunk_1607000076__10).Nth_I__O(lang.RT_IntCast_J__I(i_1607000078__12)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, k__13))) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s5:a2g: ns7:: part ns4: of ns23: missing (aot/continue)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(k__13), nil, n__6, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_71, c__7)))))); seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, i_1607000078__12 = seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, lang.Numbers_Unchecked_inc_J__J(i_1607000078__12); continue L2 } else { seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, i_1607000078__12 = seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, lang.Numbers_Unchecked_inc_J__J(i_1607000078__12); continue L2 } } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000075__9); if jrt.A2g_Truth(temp__1927000414__auto____13) { var seq_1607000075__14 any = temp__1927000414__auto____13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14); seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, i_1607000078__12 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var k__15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, k__15))) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s5:a2g: ns7:: part ns4: of ns23: missing (aot/continue)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, c__7, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(k__15), nil, n__6, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_71, c__7)))))); seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, i_1607000078__12 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14), nil, 0, 0; continue L2 } else { seq_1607000075__9, chunk_1607000076__10, count_1607000077__11, i_1607000078__12 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000075__14), nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp13 any = t.F_claimed; tmp12.Invoke_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_47.GetRawRoot__O(), ks__8)
		tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_63.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_74.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(f__4, lang.IFn_Cast(A_arbace_a2g_world_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__8))), lang.IFn_Cast(A_arbace_a2g_world_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(f__4), A_arbace_a2g_world_A_const_61))) } else {
//line :58:1
			tmp5 = f__4 }
//line :57:1
	var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1607000059); return tmp4.Invoke_O_O__O(tmp5, tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000060__3))) } else { s__1607000060__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000060__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :57:1
func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A) Ctor_O_O_I_O_O(c__b__1607000062, c__claimed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__conts any) { t.F_b__1607000062 = c__b__1607000062; t.F_claimed = c__claimed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_conts = c__conts }
//line :57:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A) Invoke_O__O(self any) any { { var i__1607000061__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000061__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O__O(f__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000062; var tmp4 any; var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__2)
																					if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp5 *lang.Keyword = A_arbace_a2g_world_A_const_61; temp__1927000408__auto____3 = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__2)) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; var c__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(f__2)); var ks__6 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A_New_O(c__5); var tmp8 *jrt.Class
																						var fncls__13 /*line :58:1*/*jrt.Class = A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A_fn_class

		if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A_fn_class = fncls__13d; tmp8 = fncls__13d } else { tmp8 = fncls__13 }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_world_A_const_67; ks__6 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), tmp9.Invoke_O_O__O(tmp10, lang.Numbers_Inc_O__Number(n__4)))
//line :58:1
		var seq_1607000068__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(ks__6); var chunk_1607000069__8 any; var count_1607000070__9 int64 = 0; var i_1607000071__10 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z(i_1607000071__10, count_1607000070__9) { var k__11 any = lang.Indexed_Cast(chunk_1607000069__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000071__10)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, k__11))) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s5:a2g: ns7:: part ns4: of ns23: missing (aot/continue)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(k__11), nil, n__4, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_71, c__5)))))); seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, i_1607000071__10 = seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, lang.Numbers_Unchecked_inc_J__J(i_1607000071__10); continue L2 } else { seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, i_1607000071__10 = seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, lang.Numbers_Unchecked_inc_J__J(i_1607000071__10); continue L2 } } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000068__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1607000068__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12); seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, i_1607000071__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var k__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, k__13))) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s5:a2g: ns7:: part ns4: of ns23: missing (aot/continue)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, c__5, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(k__13), nil, n__4, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_71, c__5)))))); seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, i_1607000071__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12), nil, 0, 0; continue L2 } else { seq_1607000068__7, chunk_1607000069__8, count_1607000070__9, i_1607000071__10 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000068__12), nil, 0, 0; continue L2 } } } }
//line :58:1
			break L2
		}




		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp12 any = t.F_claimed; tmp11.Invoke_O_O_O__O(tmp12, A_arbace_a2g_world_A_const_47.GetRawRoot__O(), ks__6)
		tmp4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_63.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_74.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(f__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t.F_conts, ks__6))), lang.IFn_Cast(A_arbace_a2g_world_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Meta_O__IPersistentMap(f__2), A_arbace_a2g_world_A_const_61))) } else {
//line :58:1
			tmp4 = f__2 }
//line :57:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1607000061__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000061__1); continue L1 } else { i__1607000061__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000061__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A_New_O(p0 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A) Invoke_O_O__O(self, p1__1607000038_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_c, p1__1607000038_SHARP___1) }
//line :60:1
func A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A_New_O(p0 any) *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :60:1
func (t *A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A) Invoke_O_O__O(self, p1__1607000038_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_c, p1__1607000038_SHARP___1) }












func A_arbace_a2g_world_ns_of_forms_A_New() *A_arbace_a2g_world_ns_of_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Ctor() {}
//line :73:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_ns_of_forms_fn__1607000085_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_world_ns_of_forms_fn__1607000085_A_fn_class; if
											fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_a2g_world_ns_of_forms_fn__1607000085_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; f__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__0)); if
											jrt.A2g_Truth(f__2) { var n__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(n__3)) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(n__3) } else { return n__3 } } else { return nil } }
//line :74:1
func A_arbace_a2g_world_ns_of_forms_fn__1607000085_A_New() *A_arbace_a2g_world_ns_of_forms_fn__1607000085_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_fn__1607000085_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000085_A) Ctor() {}
//line :74:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000085_A) Invoke_O_O__O(self, p1__1607000084_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(p1__1607000084_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(p1__1607000084_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_104, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(p1__1607000084_SHARP___1)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_world_top_names_A_New() *A_arbace_a2g_world_top_names_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_a2g_world_top_names_A) Ctor() {}
//line :77:1
func (t *A_arbace_a2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A_New_O(nsname__0); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A_fn_class; if


	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(forms__1)) }
//line :80:1
func A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A_New_O(p0 any) *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A) Invoke_O_O__O(self, s__1607000089__1 any) any { var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A_New_O_O_O(self, t.F_nsname, s__1607000089__1); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A) Ctor_O_O_O(c__iter__1607000088, c__nsname, c__s__1607000089 any) { t.F_iter__1607000088 = c__iter__1607000088; t.F_nsname = c__nsname; t.F_s__1607000089 = c__s__1607000089 }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A) Invoke_O__O(self any) any { { var s__1607000089__1 any; var t_ any = t.F_s__1607000089; t.F_s__1607000089 = nil; s__1607000089__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000089__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000089__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000091__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A_New_O_O_I_O(b__1607000091__6, t.F_nsname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000088); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000089__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000091__6), nil) } } else { var cf__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000089__3); var vec__1607000099__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__4); var seq__1607000100__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000099__5); var first__1607000101__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000100__6); var seq__1607000100__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000100__6); var nm__9 any = first__1607000101__7; var more__10 any = seq__1607000100__8; var more__11 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_82.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10))) { more__11 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__10) } else { more__11 = more__10 }
//line :80:1
	var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_83; var pkg__12 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_84.GetRawRoot__O()).Invoke_O__O(more__11))); var s__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(nm__9); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()); var tmp6 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_85.GetRawRoot__O()).Invoke_O__O(pkg__12)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(pkg__12))) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_122), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(pkg__12), Lit_123, Lit_122), nil)) } else { tmp8 = nil }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), s__13)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O_O__O(s__13, Lit_123)) {
		tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(s__13, Lit_123, Lit_122) } else {
//line :85:1
			if A_arbace_a2g_world_A_const_88 != nil {

				tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_122, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_123, Lit_122), nil, s__13)).Ref() } else {
//line :85:1
					tmp6 = nil } } }
//line :80:1
	var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1607000088); return tmp5.Invoke_O_O__O(tmp6, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000089__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :80:1
func A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A) Ctor_O_O_I_O(c__b__1607000091, c__nsname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000091 = c__b__1607000091; t.F_nsname = c__nsname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A) Invoke_O__O(self any) any { { var i__1607000090__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000090__1)); var vec__1607000095__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__2); var seq__1607000096__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000095__3); var first__1607000097__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000096__4); var seq__1607000096__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000096__4); var nm__7 any = first__1607000097__5; var more__8 any = seq__1607000096__6; var more__9 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_82.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__8))) { more__9 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__8) } else { more__9 = more__8 }
//line :80:1
	var tmp2 *lang.Keyword = A_arbace_a2g_world_A_const_83; var pkg__10 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_84.GetRawRoot__O()).Invoke_O__O(more__9))); var s__11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(nm__7); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp4 any = t.F_b__1607000091; var tmp5 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_85.GetRawRoot__O()).Invoke_O__O(pkg__10)) { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(pkg__10))) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_122), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(pkg__10), Lit_123, Lit_122), nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), s__11)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_123)) {
		tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(s__11, Lit_123, Lit_122) } else {
//line :85:1
			if A_arbace_a2g_world_A_const_88 != nil {

				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_122, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_123, Lit_122), nil, s__11)).Ref() } else {
//line :85:1
					tmp5 = nil } } }
//line :80:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1607000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000090__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_source_files_A_New() *A_arbace_a2g_world_source_files_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_a2g_world_source_files_A) Ctor() {}
//line :89:1
func (t *A_arbace_a2g_world_source_files_A) Invoke_O_O__O(self, p__1607000107__0 any) any { var map__1607000108__2 any = p__1607000107__0; var map__1607000108__3 any; if lang.ISeq_InstanceOf(map__1607000108__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000108__2)) { map__1607000108__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000108__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000108__2)) { map__1607000108__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000108__2) } else { lang.PersistentArrayMap_Init(); map__1607000108__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000108__3 = map__1607000108__2 }; var root__4 any = lang.RT_Get_O_O__O(map__1607000108__3, A_arbace_a2g_world_A_const_91); var dirs__5 any = lang.RT_Get_O_O__O(map__1607000108__3, A_arbace_a2g_world_A_const_92); var tree__6 any = lang.RT_Get_O_O__O(map__1607000108__3, A_arbace_a2g_world_A_const_93); var files__7 any = lang.RT_Get_O_O__O(map__1607000108__3, A_arbace_a2g_world_A_const_94); if



	jrt.A2g_Truth(files__7) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_96.GetRawRoot__O(), files__7) } else {
//line :93:1
			if jrt.A2g_Truth(tree__6) {






				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_56.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_source_files_fn__1607000110_A_New(); var tmp5 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000110_A_fn_class
//line :99:1
				if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_a2g_world_source_files_fn__1607000110_A_fn_class = fncls__24d; tmp5 = fncls__24d } else { tmp5 = fncls__24 }
				var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_source_files_fn__1607000112_A_New(); var tmp9 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000112_A_fn_class
//line :96:1
				if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_a2g_world_source_files_fn__1607000112_A_fn_class = fncls__25d; tmp9 = fncls__25d } else { tmp9 = fncls__25
				}


				return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()).Invoke_O__O(root__4))))) } else {
//line :93:1
					if A_arbace_a2g_world_A_const_88 != nil {










						var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_world_A_const_56.GetRawRoot__O(); var tmp12 any; var iter__1927001039__auto____8 any; var tmp13 any = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A_New_O(root__4); var tmp14 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A_fn_class
//line :101:1
						if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A_fn_class = fncls__30d; tmp14 = fncls__30d } else { tmp14 = fncls__30 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						return tmp10.Invoke_O_O__O(tmp11, tmp12) } else {
//line :93:1
							return nil } } } }


func A_arbace_a2g_world_source_files_fn__1607000112_A_New() *A_arbace_a2g_world_source_files_fn__1607000112_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000112_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_a2g_world_source_files_fn__1607000112_A) Ctor() {}
//line :96:1
func (t *A_arbace_a2g_world_source_files_fn__1607000112_A) Invoke_O_O__O(self, p1__1607000105_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1607000105_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { return lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1607000105_SHARP___1)).GetName__String().Ref(), Lit_128) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }


func A_arbace_a2g_world_source_files_fn__1607000110_A_New() *A_arbace_a2g_world_source_files_fn__1607000110_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000110_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_a2g_world_source_files_fn__1607000110_A) Ctor() {}
//line :99:1
func (t *A_arbace_a2g_world_source_files_fn__1607000110_A) Invoke_O_O__O(self, p1__1607000106_SHARP___1 any) any { var f__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_97.GetRawRoot__O()).Invoke_O__O(p1__1607000106_SHARP___1); var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_a2g_world_A_const_98; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__2))).Ref() } else { return and__1927000168__auto____3 } }

func A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A_New_O(p0 any) *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A) Invoke_O_O__O(self, s__1607000115__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A_New_O_O_O(s__1607000115__1, self, t.F_root); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A) Ctor_O_O_O(c__s__1607000115, c__iter__1607000114, c__root any) { t.F_s__1607000115 = c__s__1607000115; t.F_iter__1607000114 = c__iter__1607000114; t.F_root = c__root }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A) Invoke_O__O(self any) any { { var s__1607000115__1 any; var t_ any = t.F_s__1607000115; t.F_s__1607000115 = nil; s__1607000115__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000115__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A_New(); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()).Invoke_O_O__O(t.F_root, d__4))).ListFiles__File1().Ref())); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000114); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000115__1))) } else { s__1607000115__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000115__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :101:1
func A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A_New() *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A) Ctor() {}
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A) Invoke_O_O__O(self, s__1607000117__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A_New_O_O(s__1607000117__1, self); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :101:1
func A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A{}; t.Ctor_O_O(p0, p1); return t }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A) Ctor_O_O(c__s__1607000117, c__iter__1607000116 any) { t.F_s__1607000117 = c__s__1607000117; t.F_iter__1607000116 = c__iter__1607000116 }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A) Invoke_O__O(self any) any { { var s__1607000117__1 any; var t_ any = t.F_s__1607000117; t.F_s__1607000117 = nil; s__1607000117__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000117__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000117__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000117__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000117__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000119__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A_New_O_I_O(b__1607000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000116); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000119__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000117__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000119__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000117__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																				if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_128) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :101:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1607000116); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000117__3))) } else { s__1607000117__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000117__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :101:1
func A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A) Ctor_O_I_O(c__b__1607000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000119 = c__b__1607000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :101:1
func (t *A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A) Invoke_O__O(self any) any { { var i__1607000118__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000118__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																						if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_128) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :101:1
	if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000119, f__2); i__1607000118__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000118__1); continue L1 } else { i__1607000118__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000118__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_head_name_A_New() *A_arbace_a2g_world_head_name_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_head_name_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_world_head_name_A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_a2g_world_param_key_A_New() *A_arbace_a2g_world_param_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_a2g_world_param_key_A) Ctor() {}
//line :112:1
func (t *A_arbace_a2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(f__0); var G__1607000134__3_ any = h__2; switch



	lang.Util_Hash_O__I(G__1607000134__3_) >> 13 & 15 { case 5: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_19) { var nm__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_30.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any = A_arbace_a2g_world_A_const_102; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__4)) }; case 6: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_105) { var params__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_82.GetRawRoot__O(); var tmp5 any = A_arbace_a2g_world_param_key_fn__1607000135_A_New_O(f__0); var tmp6 *jrt.Class
		var fncls__32 /*line :116:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000135_A_fn_class












		if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_a2g_world_param_key_fn__1607000135_A_fn_class = fncls__32d; tmp6 = fncls__32d } else { tmp6 = fncls__32 }; params__4 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()))
//line :116:1
		var tmp7 any = A_arbace_a2g_world_A_const_105; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_world_param_key_fn__1607000137_A_New(); var tmp10 *jrt.Class
		var fncls__33 /*line :116:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000137_A_fn_class
















		if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_a2g_world_param_key_fn__1607000137_A_fn_class = fncls__33d; tmp10 = fncls__33d } else { tmp10 = fncls__33 }
//line :116:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__4))) }; case 7: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_12) { var tmp11 any = A_arbace_a2g_world_A_const_71; return lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(f__0))) }; case 10: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_4) { var tmp12 any = A_arbace_a2g_world_A_const_108; var tmp13 any; var tmp14 *lang.Keyword = A_arbace_a2g_world_A_const_109; var or__1927000174__auto____4 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0))


















			if jrt.A2g_Truth(or__1927000174__auto____4) { tmp13 = or__1927000174__auto____4 } else { tmp13 = A_arbace_a2g_world_A_const_110 }
//line :116:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13) }; case 13: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_108) { var vec__1607000140__4 any = f__0; var seq__1607000141__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000140__4); var first__1607000142__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000141__5); var seq__1607000141__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000141__5); var ___8 any = first__1607000142__6; var first__1607000142__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000141__7); var seq__1607000141__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000141__7); var nm__11 any = first__1607000142__9; var more__12 any = seq__1607000141__10; var more__13 any; var tmp15 any = A_arbace_a2g_world_param_key_fn__1607000143_A_New_O(more__12); var tmp16 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000143_A_fn_class; _ = ___8



				if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_a2g_world_param_key_fn__1607000143_A_fn_class = fncls__34d; tmp16 = fncls__34d } else { tmp16 = fncls__34 }; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :116:1
				var params__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_82.GetRawRoot__O(), more__13)); var tmp17 *lang.Keyword = A_arbace_a2g_world_A_const_107; var static__15 bool = lang.RT_BooleanCast_O__Z(tmp17.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11))); var ps__16 any









				if static__15 { ps__16 = params__14 } else { ps__16 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__14) }
//line :116:1
				var tmp18 any = A_arbace_a2g_world_A_const_111; var tmp19 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__11); var tmp20 any = jrt.Boolean_ValueOf_Z__Boolean(static__15).Ref(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp22 any = A_arbace_a2g_world_param_key_fn__1607000145_A_New(); var tmp23 *jrt.Class
				var fncls__36 /*line :116:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000145_A_fn_class










				if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_a2g_world_param_key_fn__1607000145_A_fn_class = fncls__36d; tmp23 = fncls__36d } else { tmp23 = fncls__36 }
//line :116:1
				return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp18, tmp19, tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), ps__16)) }; case 14: if lang.Util_Equiv_O_O__Z(G__1607000134__3_, Lit_111) { var vec__1607000148__4 any = f__0; var seq__1607000149__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000148__4); var first__1607000150__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000149__5); var seq__1607000149__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000149__5); var ___8_2 any = first__1607000150__6; var first__1607000150__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000149__7); var seq__1607000149__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000149__7); var nm__11_2 any = first__1607000150__9; var more__12_2 any = seq__1607000149__10; var more__13_2 any; var tmp24 any = A_arbace_a2g_world_param_key_fn__1607000151_A_New_O(more__12_2); var tmp25 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000151_A_fn_class; _ = ___8_2



					if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_a2g_world_param_key_fn__1607000151_A_fn_class = fncls__35d; tmp25 = fncls__35d } else { tmp25 = fncls__35 }; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil).Invoke__O()
//line :116:1
					var params__14_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_82.GetRawRoot__O(), more__13_2)); var tmp26 *lang.Keyword = A_arbace_a2g_world_A_const_107; var static__15_2 bool = lang.RT_BooleanCast_O__Z(tmp26.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11_2))); var ps__16_2 any









					if static__15_2 { ps__16_2 = params__14_2 } else { ps__16_2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__14_2) }
//line :116:1
					var tmp27 any = A_arbace_a2g_world_A_const_111; var tmp28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__11_2); var tmp29 any = jrt.Boolean_ValueOf_Z__Boolean(static__15_2).Ref(); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp31 any = A_arbace_a2g_world_param_key_fn__1607000153_A_New(); var tmp32 *jrt.Class
					var fncls__37 /*line :116:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000153_A_fn_class










					if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_a2g_world_param_key_fn__1607000153_A_fn_class = fncls__37d; tmp32 = fncls__37d } else { tmp32 = fncls__37 }
//line :116:1
					return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp27, tmp28, tmp29, tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), ps__16_2)) }; default:}; return nil }



func A_arbace_a2g_world_param_key_fn__1607000143_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000143_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000143_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_a2g_world_param_key_fn__1607000143_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_a2g_world_param_key_fn__1607000143_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_103; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_104, xs__1), acc__2; continue L1 } else {
//line :121:1
			if A_arbace_a2g_world_A_const_88 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :121:1
					return nil } } } } }; /*line :120:1*/panic("a2g: unreachable") }
//line :120:1
func A_arbace_a2g_world_param_key_fn__1607000151_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000151_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000151_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_a2g_world_param_key_fn__1607000151_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :120:1
func (t *A_arbace_a2g_world_param_key_fn__1607000151_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_103; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_104, xs__1), acc__2; continue L1 } else {
//line :121:1
			if A_arbace_a2g_world_A_const_88 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :121:1
					return nil } } } } }; /*line :120:1*/panic("a2g: unreachable") }






func A_arbace_a2g_world_param_key_fn__1607000145_A_New() *A_arbace_a2g_world_param_key_fn__1607000145_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000145_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_a2g_world_param_key_fn__1607000145_A) Ctor() {}
//line :127:1
func (t *A_arbace_a2g_world_param_key_fn__1607000145_A) Invoke_O_O__O(self, p1__1607000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_106; var G__1607000146__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000132_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000146__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(G__1607000146__2_) } }
//line :127:1
func A_arbace_a2g_world_param_key_fn__1607000153_A_New() *A_arbace_a2g_world_param_key_fn__1607000153_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000153_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_a2g_world_param_key_fn__1607000153_A) Ctor() {}
//line :127:1
func (t *A_arbace_a2g_world_param_key_fn__1607000153_A) Invoke_O_O__O(self, p1__1607000132_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_106; var G__1607000154__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000132_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000154__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(G__1607000154__2_) } }

func A_arbace_a2g_world_param_key_fn__1607000135_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000135_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000135_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_a2g_world_param_key_fn__1607000135_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :129:1
func (t *A_arbace_a2g_world_param_key_fn__1607000135_A) Invoke_O__O(self any) any { { var xs__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; xs__1 = tmp1.Invoke_O__O(tmp2); var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp3 any = A_arbace_a2g_world_A_const_103; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_104, xs__1), acc__2; continue L1 } else {
//line :130:1
			if A_arbace_a2g_world_A_const_88 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :130:1
					return nil } } } } }; /*line :129:1*/panic("a2g: unreachable") }



func A_arbace_a2g_world_param_key_fn__1607000137_A_New() *A_arbace_a2g_world_param_key_fn__1607000137_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000137_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_a2g_world_param_key_fn__1607000137_A) Ctor() {}
//line :133:1
func (t *A_arbace_a2g_world_param_key_fn__1607000137_A) Invoke_O_O__O(self, p1__1607000133_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_106; var G__1607000138__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000133_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000138__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(G__1607000138__2_) } }





func A_arbace_a2g_world_cut_key_A_New() *A_arbace_a2g_world_cut_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_cut_key_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_a2g_world_cut_key_A) Ctor() {}
//line :139:1
func (t *A_arbace_a2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(x__0)
	if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_19, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :140:1
	if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :140:1
			var tmp2 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(x__0)


			if jrt.A2g_Truth(and__1927000168__auto____2_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp2 = and__1927000168__auto____2_2 }
//line :140:1
			if jrt.A2g_Truth(tmp2) { var tmp3 any = A_arbace_a2g_world_A_const_108; var tmp4 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(x__0)


				if jrt.A2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = A_arbace_a2g_world_A_const_110 }
//line :140:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(x__0))) {



					return lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_113, x__0)) } else {
//line :140:1
						if A_arbace_a2g_world_A_const_88 != nil { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())))) } else { return nil
						}
					}
				}
		}
}

func A_arbace_a2g_world_class_parts_A_New() *A_arbace_a2g_world_class_parts_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_parts_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_a2g_world_class_parts_A) Ctor() {}
//line :147:1
func (t *A_arbace_a2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__1607000158__2 any = cf__0; var seq__1607000159__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000158__2); var first__1607000160__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000159__3); var seq__1607000159__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000159__3); var dc__6 any = first__1607000160__4; var first__1607000160__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000159__5); var seq__1607000159__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000159__5); var nm__9 any = first__1607000160__7; var more__10 any = seq__1607000159__8; var vec__1607000161__11 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_82.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10))) { vec__1607000161__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__10)) } else { var tmp1 *lang.PersistentVector; lang.PersistentVector_Init(); tmp1 = lang.PersistentVector_EMPTY; vec__1607000161__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp1.Ref(), more__10) }; var comps__12 any = /*line :147:1*/lang.RT_Nth_O_I_O__O(vec__1607000161__11, lang.RT_IntCast_J__I(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O(vec__1607000161__11, lang.RT_IntCast_J__I(1), nil); var vec__1607000164__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_84.GetRawRoot__O()).Invoke_O__O(more__13); var opts__15 any = lang.RT_Nth_O_I_O__O(vec__1607000164__14, lang.RT_IntCast_J__I(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O(vec__1607000164__14, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9), comps__12, lang.IFn_Cast(A_arbace_a2g_world_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_114.GetRawRoot__O(), opts__15)), lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(members__16)) }







func A_arbace_a2g_world_apply_variant_A_New() *A_arbace_a2g_world_apply_variant_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_a2g_world_apply_variant_A) Ctor() {}
//line :155:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__1607000170__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_115.GetRawRoot__O()).Invoke_O__O(cf__0); var head__7 any = lang.RT_Nth_O_I_O__O(vec__1607000170__6, lang.RT_IntCast_J__I(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O(vec__1607000170__6, lang.RT_IntCast_J__I(1), nil); var members__9 any; var n__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_117); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_apply_variant_fn__1607000173_A_New_O(n__9); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000173_A_fn_class; if










	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_a2g_world_apply_variant_fn__1607000173_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; members__9 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), members__8); var counts__10 any = /*line :155:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_121); var members__11 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_apply_variant_fn__1607000175_A_New_O(counts__10); var tmp6 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000175_A_fn_class; if
















	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_a2g_world_apply_variant_fn__1607000175_A_fn_class = fncls__43d; tmp6 = fncls__43d } else { tmp6 = fncls__43 }; members__11 = /*line :171:1*/tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), members__9, vforms__1); var members__12 any; if

















	jrt.A2g_Truth(variants_of__3) {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000184_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp9 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000184_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_a2g_world_apply_variant_fn__1607000184_A_fn_class = fncls__44d; tmp9 = fncls__44d } else { tmp9 = fncls__44 }; members__12 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), members__11) } else {
//line :189:1
			members__12 = members__11 }; return /*line :155:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_63.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_74.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(head__7, members__12)), lang.RT_Meta_O__IPersistentMap(cf__0)), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(counts__10)) }
//line :155:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	return lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()).Invoke_O_O_O_O_O__O(cf__0, vforms__1, nil, nil, nil)
}



func A_arbace_a2g_world_apply_variant_fn__1607000173_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000173_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000173_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000173_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :166:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000173_A) Invoke_O_O__O(self, m__1 any) any { if lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(m__1)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_118.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_119.GetRawRoot__O(); var tmp3 any = A_arbace_a2g_world_A_const_109; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp5 any = t.F_n; return tmp1.Invoke_O_O_O_O__O(m__1, tmp2, tmp3, tmp4.Invoke_O_O__O(tmp5, A_arbace_a2g_world_A_const_120.GetRawRoot__O())) } else {
//line :166:1
		return m__1 } }





func A_arbace_a2g_world_apply_variant_fn__1607000175_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000175_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000175_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :172:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__1607000176__3_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(vf__2); switch
													lang.Util_Hash_O__I(G__1607000176__3_) { case 96417: if lang.Util_Equiv_O_O__Z(G__1607000176__3_, Lit_5) {







		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp2 any = t.F_counts; var tmp3 any = A_arbace_a2g_world_A_const_58.GetRawRoot__O(); var tmp4 any = A_arbace_a2g_world_A_const_124; tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_a2g_world_A_const_120.GetRawRoot__O()); return lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(ms__1, lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(vf__2)) }
//line :173:1
	case 98882: if lang.Util_Equiv_O_O__Z(G__1607000176__3_, Lit_6) { var k__4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_122.GetRawRoot__O()); var tmp6 any


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(vf__2))) { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(vf__2) } else { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(vf__2) }; k__4 = tmp5.Invoke_O__O(tmp6)
//line :173:1
		var hit__5 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_123.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A_New_O(k__4); var tmp9 *jrt.Class
		var fncls__40 /*line :173:1*/*jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A_fn_class



		if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A_fn_class = fncls__40d; tmp9 = fncls__40d } else { tmp9 = fncls__40 }; hit__5 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ms__1)
		if jrt.A2g_Truth(hit__5) { } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()); var tmp11 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(vf__2)))).Ref(); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10.Invoke_O_O__O(tmp11, tmp12.Ref())))) }
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp14 any = t.F_counts; var tmp15 any = A_arbace_a2g_world_A_const_58.GetRawRoot__O(); var tmp16 any = A_arbace_a2g_world_A_const_125; tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, A_arbace_a2g_world_A_const_120.GetRawRoot__O())
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_77.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A_New_O(k__4); var tmp20 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A_fn_class = fncls__41d; tmp20 = fncls__41d } else { tmp20 = fncls__41 }; return tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), ms__1)) }
//line :173:1
	default:}; var k__4_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(vf__2); var i__5 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_126.GetRawRoot__O()); var tmp23 any = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A_New_O(k__4_2); var tmp24 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A_fn_class; if









	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A_fn_class = fncls__42d; tmp24 = fncls__42d } else { tmp24 = fncls__42 }; i__5 = tmp21.Invoke_O__O(tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), ms__1)); if
	jrt.A2g_Truth(i__5) { } else { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()); var tmp26 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp25.Invoke_O_O__O(tmp26, tmp27.Ref())))) }; var tmp28 lang.IFn =
	lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp29 any = t.F_counts; var tmp30 any = A_arbace_a2g_world_A_const_58.GetRawRoot__O(); var tmp31 any = A_arbace_a2g_world_A_const_127; tmp28.Invoke_O_O_O_O__O(tmp29, tmp30, tmp31, A_arbace_a2g_world_A_const_120.GetRawRoot__O()); return /*line :186:1*/ lang.IFn_Cast(A_arbace_a2g_world_A_const_119.GetRawRoot__O()).Invoke_O_O_O__O(ms__1, i__5, vf__2) }
//line :177:1
func A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :177:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A) Invoke_O_O__O(self, p1__1607000168_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(p1__1607000168_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :180:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A) Invoke_O_O__O(self, p1__1607000169_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(p1__1607000169_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :183:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O__O(m__2)) { return i__1 } else { return nil } }






func A_arbace_a2g_world_apply_variant_fn__1607000184_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_apply_variant_fn__1607000184_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000184_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000184_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :190:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000184_A) Invoke_O_O__O(self, m__1 any) any {
	if lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(m__1)) { var tmp1 any = t.F_prefix; var nn__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, tmp1, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O__O(m__1)))).Ref(); var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__1607000185__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()); var tmp3 any
		var or__1927000174__auto____4 any = vfs__3

		if jrt.A2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY.Ref() }; vec__1607000185__4 = tmp2.Invoke_O_O_O_O_O__O(m__1, tmp3, nn__2, t.F_variants_of, t.F_applied)
//line :191:1
		var m2__5 any = lang.RT_Nth_O_I_O__O(vec__1607000185__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1607000185__4, lang.RT_IntCast_J__I(1), nil)



		if jrt.A2g_Truth(vfs__3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp5 any = t.F_applied; tmp4.Invoke_O_O_O_O__O(tmp5, A_arbace_a2g_world_A_const_119.GetRawRoot__O(), nn__2, c__6) }
//line :191:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_a2g_world_read_variants_A_New() *A_arbace_a2g_world_read_variants_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_a2g_world_read_variants_A) Ctor() {}
//line :202:1
func (t *A_arbace_a2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000190_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000190_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_a2g_world_read_variants_fn__1607000190_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O__O(tmp4, tmp5.Ref(), files__0) }
//line :208:1
func A_arbace_a2g_world_read_variants_fn__1607000190_A_New() *A_arbace_a2g_world_read_variants_fn__1607000190_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000190_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000190_A) Ctor() {}
//line :208:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000190_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_129.GetRawRoot__O()).Invoke_O__O(f__2); var nsname__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_130.GetRawRoot__O()).Invoke_O__O(forms__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A_New_O(nsname__4); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A_fn_class; if


	fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1, forms__3) }
//line :211:1
func A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A_New_O(p0 any) *A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A{}; t.Ctor_O(p0); return t }
//line :211:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :211:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__2)
	if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_121, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :212:1
	if jrt.A2g_Truth(tmp1) { var vec__1607000192__3 any = fm__2; var seq__1607000193__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000192__3); var first__1607000194__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000193__4); var seq__1607000193__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000193__4); var ___7 any = first__1607000194__5; var first__1607000194__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000193__6); var seq__1607000193__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq__1607000193__6); var cls__10 any = first__1607000194__8; var members__11 any = seq__1607000193__9; var n__12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_122, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_123, Lit_122), nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(cls__10))).Ref(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_47.GetRawRoot__O(); var tmp5 *lang.PersistentVector; _ = ___7



		lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp2.Invoke_O_O_O_O__O(acc__1, n__12, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), members__11) } else {
//line :212:1
			var tmp6 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__2)




			if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_124, lang.IFn_Cast(A_arbace_a2g_world_A_const_101.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp6 = and__1927000168__auto____3_2 }
//line :212:1
			if jrt.A2g_Truth(tmp6) {





				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_A_const_132; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_world_A_const_47.GetRawRoot__O(); var tmp11 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; return tmp7.Invoke_O_O_O_O__O(acc__1, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Ref()), lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_56.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(fm__2))) } else {
//line :212:1
					if A_arbace_a2g_world_A_const_88 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_a2g_world_new_unit_A_New() *A_arbace_a2g_world_new_unit_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_new_unit_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_a2g_world_new_unit_A) Ctor() {}
//line :223:1
func (t *A_arbace_a2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_a2g_world_A_const_133; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp2.Invoke_O__O(tmp3.Ref()); var tmp5 any = A_arbace_a2g_world_A_const_134; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 any = A_arbace_a2g_world_A_const_135; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 any = A_arbace_a2g_world_A_const_136; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 any = A_arbace_a2g_world_A_const_137; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp19 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp19 = lang.PersistentHashSet_EMPTY; var tmp20 any = tmp18.Invoke_O__O(tmp19.Ref()); var tmp21 any = A_arbace_a2g_world_A_const_138; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 any = A_arbace_a2g_world_A_const_139; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp12, tmp13, tmp16, tmp17, tmp20, tmp21, tmp24, tmp25, tmp26.Invoke_O__O(tmp27.Ref()))) }








func A_arbace_a2g_world_id_space_A_New() *A_arbace_a2g_world_id_space_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_id_space_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_a2g_world_id_space_A) Ctor() {}
//line :232:1
func (t *A_arbace_a2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_140))).GetField_String__Field(Lit_22)).Get_O__O(nil)
//line :232:1
	return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_a2g_world_parse_member_classes_A_New() *A_arbace_a2g_world_parse_member_classes_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_parse_member_classes_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_a2g_world_parse_member_classes_A) Ctor() {}
//line :240:1
func (t *A_arbace_a2g_world_parse_member_classes_A) Invoke_O_O__O(self, pc__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A_New_O(pc__0); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_a2g_world_A_const_144.Invoke_O__O(pc__0)); return tmp1.Invoke_O__O(tmp2) }
//line :246:1
func A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A_New_O(p0 any) *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A) Invoke_O_O__O(self, s__1607000201__1 any) any { var tmp1 any = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A_New_O_O_O(s__1607000201__1, self, t.F_pc); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :246:1
func A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A) Ctor_O_O_O(c__s__1607000201, c__iter__1607000200, c__pc any) { t.F_s__1607000201 = c__s__1607000201; t.F_iter__1607000200 = c__iter__1607000200; t.F_pc = c__pc }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A) Invoke_O__O(self any) any { { var s__1607000201__1 any; var t_ any = t.F_s__1607000201; t.F_s__1607000201 = nil; s__1607000201__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000201__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000201__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000201__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000201__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000203__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A_New_O_O_I_O(b__1607000203__6, t.F_pc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000200); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000203__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000201__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000203__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000201__3); var tmp4 any = A_arbace_a2g_world_A_const_71; if lang.Util_Equiv_O_O__Z(tmp4, A_arbace_a2g_world_A_const_141.Invoke_O__O(m__4)) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()); var tmp6 lang.IPersistentMap; var tmp7 any = A_arbace_a2g_world_A_const_146; var mpc__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, A_arbace_a2g_world_A_const_146.Invoke_O__O(t.F_pc), A_arbace_a2g_world_A_const_147, A_arbace_a2g_world_A_const_148, A_arbace_a2g_world_A_const_149, t.F_pc)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_150.Invoke_O__O(m__4))); var tmp8 any = A_arbace_a2g_world_A_const_143; var tmp9 any = A_arbace_a2g_world_A_const_144; tmp6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, mpc__5, tmp9, lang.IFn_Cast(A_arbace_a2g_world_A_const_145.GetRawRoot__O()).Invoke_O__O(mpc__5))); var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1607000200); return tmp5.Invoke_O_O__O(tmp6, tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000201__3))) } else { s__1607000201__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000201__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :246:1
func A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A) Ctor_O_O_I_O(c__b__1607000203, c__pc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000203 = c__b__1607000203; t.F_pc = c__pc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :246:1
func (t *A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A) Invoke_O__O(self any) any { { var i__1607000202__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000202__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000202__1)); var tmp2 any = A_arbace_a2g_world_A_const_71; if lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_world_A_const_141.Invoke_O__O(m__2)) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp4 any = t.F_b__1607000203; var tmp5 lang.IPersistentMap; var tmp6 any = A_arbace_a2g_world_A_const_146; var mpc__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, A_arbace_a2g_world_A_const_146.Invoke_O__O(t.F_pc), A_arbace_a2g_world_A_const_147, A_arbace_a2g_world_A_const_148, A_arbace_a2g_world_A_const_149, t.F_pc)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_150.Invoke_O__O(m__2))); var tmp7 any = A_arbace_a2g_world_A_const_143; var tmp8 any = A_arbace_a2g_world_A_const_144; tmp5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, mpc__3, tmp8, lang.IFn_Cast(A_arbace_a2g_world_A_const_145.GetRawRoot__O()).Invoke_O__O(mpc__3))); tmp3.Invoke_O_O__O(tmp4, tmp5); i__1607000202__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000202__1); continue L1 } else { i__1607000202__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000202__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_world_levels_A_New() *A_arbace_a2g_world_levels_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_levels_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_a2g_world_levels_A) Ctor() {}
//line :250:1
func (t *A_arbace_a2g_world_levels_A) Invoke_O_O_O__O(self, names__0, deps__1 any) any { var in__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_151.GetRawRoot__O()).Invoke_O__O(names__0); var memo__4 any = jrt.HashMap_New(); var lvl__5 any; var tmp1 any = A_arbace_a2g_world_levels_lvl__1607000211_A_New_O_O_O(in__3, deps__1, memo__4); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_a2g_world_levels_lvl__1607000211_A_fn_class; if






	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_world_levels_lvl__1607000211_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; lvl__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return /*line :263:1*/ lang.IFn_Cast(A_arbace_a2g_world_A_const_153.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_154.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_155.GetRawRoot__O()).Invoke_O_O__O(lvl__5, names__0))) }
//line :257:1
func A_arbace_a2g_world_levels_lvl__1607000211_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_levels_lvl__1607000211_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_levels_lvl__1607000211_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_a2g_world_levels_lvl__1607000211_A) Ctor_O_O_O(c__in, c__deps, c__memo any) { t.F_in = c__in; t.F_deps = c__deps; t.F_memo = c__memo }
//line :257:1
func (t *A_arbace_a2g_world_levels_lvl__1607000211_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any = jrt.HashMap_Cast(t.F_memo).Get_O__O(n__1); if
											jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
												jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, A_arbace_a2g_world_A_const_110)
//line :258:1
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_152.GetRawRoot__O(); var tmp3 any = A_arbace_a2g_world_A_const_117; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_81.GetRawRoot__O()); var tmp5 any = t.F_in; var l__3 any = lang.Numbers_Inc_O__Number(tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O__O(self, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(t.F_deps).Invoke_O__O(n__1)))))


		jrt.HashMap_Cast(t.F_memo).Put_O_O__O(n__1, l__3)
//line :258:1
		return l__3 } }






func A_arbace_a2g_world_supers_of_A_New() *A_arbace_a2g_world_supers_of_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_supers_of_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_a2g_world_supers_of_A) Ctor() {}
//line :265:1
func (t *A_arbace_a2g_world_supers_of_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__0); return /*line :268:1*/ lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_157.Invoke_O__O(d__2), A_arbace_a2g_world_A_const_158.Invoke_O__O(d__2)) }

func A_arbace_a2g_world_par_levels_A_New() *A_arbace_a2g_world_par_levels_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_par_levels_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_a2g_world_par_levels_A) Ctor() {}
//line :270:1
func (t *A_arbace_a2g_world_par_levels_A) Invoke_O_O_O_O__O(self, names__0, deps__1, f__2 any) any { { var seq_1607000215__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_159.GetRawRoot__O()).Invoke_O_O__O(names__0, deps__1)); var chunk_1607000216__5 any; var count_1607000217__6 int64 = 0; var i_1607000218__7 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z(i_1607000218__7, count_1607000217__6) { var l__8 any = lang.Indexed_Cast(chunk_1607000216__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000218__7))
		lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(), f__2, l__8)
//line :273:1
		seq_1607000215__4, chunk_1607000216__5, count_1607000217__6, i_1607000218__7 = seq_1607000215__4, chunk_1607000216__5, count_1607000217__6, lang.Numbers_Unchecked_inc_J__J(i_1607000218__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000215__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000215__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000215__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000215__9); seq_1607000215__4, chunk_1607000216__5, count_1607000217__6, i_1607000218__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000215__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var l__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000215__9)
			lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(), f__2, l__10)
//line :273:1
			seq_1607000215__4, chunk_1607000216__5, count_1607000217__6, i_1607000218__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000215__9), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :270:1*/panic("a2g: unreachable") }





func A_arbace_a2g_world_load_world_A_New() *A_arbace_a2g_world_load_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_a2g_world_load_world_A) Ctor() {}
//line :276:1
func (t *A_arbace_a2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__1607000223__1 any) any { var map__1607000224__3 any = p__1607000223__1; var map__1607000224__4 any; if lang.ISeq_InstanceOf(map__1607000224__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000224__3)) { map__1607000224__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000224__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000224__3)) { map__1607000224__4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000224__3) } else { lang.PersistentArrayMap_Init(); map__1607000224__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000224__4 = map__1607000224__3 }; var variant_files__5 any = lang.RT_Get_O_O__O(map__1607000224__4, A_arbace_a2g_world_A_const_162); var late_inputs__6 any = lang.RT_Get_O_O__O(map__1607000224__4, A_arbace_a2g_world_A_const_163); var wait__7 any = lang.RT_Get_O_O__O(map__1607000224__4, A_arbace_a2g_world_A_const_164); var variants__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_165.GetRawRoot__O()).Invoke_O__O(variant_files__5); var erased__9 any; var tmp1 any = A_arbace_a2g_world_A_const_132; var tmp2 *lang.PersistentHashSet;














	lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; erased__9 = lang.RT_Get_O_O_O__O(variants__8, tmp1, tmp2.Ref()); var variants__10 any = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(variants__8, A_arbace_a2g_world_A_const_132); var applied__11 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap;
















	lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; applied__11 = tmp3.Invoke_O__O(tmp4.Ref()); var parse__12 any; var tmp5 any = /*line :276:1*/A_arbace_a2g_world_load_world_parse__1607000226_A_New(); var tmp6 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000226_A_fn_class; if




















	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_a2g_world_load_world_parse__1607000226_A_fn_class = fncls__53d; tmp6 = fncls__53d } else { tmp6 = fncls__53 }; parse__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var parsed__13 any = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(parse__12).Invoke_O__O(inputs__0)); var top_set__14 any; var tmp7 any = A_arbace_a2g_world_load_world_top_set__1607000232_A_New(); var tmp8 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_a2g_world_load_world_top_set__1607000232_A_fn_class; if



























	fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_a2g_world_load_world_top_set__1607000232_A_fn_class = fncls__55d; tmp8 = fncls__55d } else { tmp8 = fncls__55 }; top_set__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tops__15 any = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(top_set__14).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13))); var top_of__16 any; var tmp9 any = A_arbace_a2g_world_load_world_top_of__1607000239_A_New(); var tmp10 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_a2g_world_load_world_top_of__1607000239_A_fn_class; if





























	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_a2g_world_load_world_top_of__1607000239_A_fn_class = fncls__56d; tmp10 = fncls__56d } else { tmp10 = fncls__56 }; top_of__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var from_source__17 any; var tmp11 any = /*line :276:1*/A_arbace_a2g_world_load_world_from_source__1607000241_A_New_O_O(tops__15, top_of__16); var tmp12 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_a2g_world_load_world_from_source__1607000241_A_fn_class; if






























	fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_a2g_world_load_world_from_source__1607000241_A_fn_class = fncls__57d; tmp12 = fncls__57d } else { tmp12 = fncls__57 }; from_source__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var cs__18 any; var tmp13 lang.IFn = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp14 *lang.PersistentArrayMap;































	lang.PersistentArrayMap_Init(); tmp14 = lang.PersistentArrayMap_EMPTY; cs__18 = tmp13.Invoke_O__O(tmp14.Ref()); var unit__19 any = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_171.GetRawRoot__O()).Invoke__O(); var failed__20 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp16 *lang.PersistentVector;

































	lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; failed__20 = tmp15.Invoke_O__O(tmp16.Ref());
	lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_223, cs__18, A_arbace_a2g_world_A_const_211, unit__19, A_arbace_a2g_world_A_const_224, from_source__17)); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000243_A_New_O_O_O_O_O_O_O_O_O_O(parsed__13, variants__10, parse__12, failed__20, top_set__14, wait__7, tops__15, unit__19, applied__11, late_inputs__6); var tmp18 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_a2g_world_load_world_fn__1607000243_A_fn_class = fncls__97d; tmp18 = fncls__97d } else { tmp18 = fncls__97 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O(); var seq_1607000415__21 any = /*line :276:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_78.GetRawRoot__O()).Invoke_O__O(variants__10)); var chunk_1607000416__22 any; var count_1607000417__23 int64 = 0; var i_1607000418__24 int64 = 0; L1: for {
























































































































































































		if lang.Numbers_Lt_J_J__Z(i_1607000418__24, count_1607000417__23) { var n__25 any = lang.Indexed_Cast(chunk_1607000416__22).Nth_I__O(lang.RT_IntCast_J__I(i_1607000418__24)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), n__25))) {
			lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()).Invoke_O_O_O__O(failed__20, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__25, Lit_42))
//line :461:1
			seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, i_1607000418__24 = seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, lang.Numbers_Unchecked_inc_J__J(i_1607000418__24); continue L1 } else { seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, i_1607000418__24 = seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, lang.Numbers_Unchecked_inc_J__J(i_1607000418__24); continue L1 } } else { var temp__1927000414__auto____25 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000415__21); if jrt.A2g_Truth(temp__1927000414__auto____25) { var seq_1607000415__26 any = temp__1927000414__auto____25; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26)) { var c__1927000678__auto____27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26); seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, i_1607000418__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26), c__1927000678__auto____27, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), n__27))) {
				lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()).Invoke_O_O_O__O(failed__20, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__27, Lit_42))
//line :461:1
				seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, i_1607000418__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26), nil, 0, 0; continue L1 } else { seq_1607000415__21, chunk_1607000416__22, count_1607000417__23, i_1607000418__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000415__26), nil, 0, 0; continue L1 } } } }
//line :276:1
		break L1 }; var tmp19 any = A_arbace_a2g_world_A_const_172; var tmp20 any = A_arbace_a2g_world_A_const_173; var tmp21 any = A_arbace_a2g_world_A_const_174; var tmp22 any = A_arbace_a2g_world_A_const_94; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_50.GetRawRoot__O()); var tmp24 any = A_arbace_a2g_world_A_const_168; var tmp25 any = tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13)); var tmp26 any = A_arbace_a2g_world_A_const_175; var tmp27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(tops__15); var tmp28 any = A_arbace_a2g_world_A_const_176; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp30 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp30 = lang.PersistentArrayMap_EMPTY; var tmp31 any = tmp30.Ref(); var tmp32 any; var iter__1927001039__auto____21 any; var tmp33 any = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A_New(); var tmp34 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A_fn_class; if




























































































































































































	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A_fn_class = fncls__102d; tmp34 = fncls__102d } else { tmp34 = fncls__102 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); tmp32 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13)); var tmp35 any = /*line :276:1*/tmp29.Invoke_O_O__O(tmp31, tmp32); var tmp36 any = A_arbace_a2g_world_A_const_177; var tmp37 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_225.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_32.GetRawRoot__O(), A_arbace_a2g_world_A_const_64.GetRawRoot__O()), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(failed__20))); var tmp38 any = A_arbace_a2g_world_A_const_178; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, cs__18, tmp20, unit__19, tmp21, from_source__17, tmp22, tmp25, tmp26, tmp27, tmp28, tmp35, tmp36, tmp37, tmp38, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), A_arbace_a2g_world_A_const_179, erased__9)) }




















func A_arbace_a2g_world_load_world_parse__1607000226_A_New() *A_arbace_a2g_world_load_world_parse__1607000226_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000226_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_A) Ctor() {}
//line :297:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_A) Invoke_O_O__O(self, ins__1 any) any { var fs__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_167.GetRawRoot__O(), ins__1)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_166.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(); var tmp4 any = A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A_New(); var tmp5 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A_fn_class; if


	fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A_fn_class = fncls__51d; tmp5 = fncls__51d } else { tmp5 = fncls__51 }; var tmp6 any = /*line :299:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A_New_O(fs__2); var tmp9 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A_fn_class; if


	fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A_fn_class = fncls__52d; tmp9 = fncls__52d } else { tmp9 = fncls__52 }; return /*line :299:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp6, fs__2, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(fs__2)).Ref())))) }
func A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A_New() *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A) Ctor() {}
//line :300:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_129.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any = A_arbace_a2g_world_A_const_168; var tmp2 any = A_arbace_a2g_world_A_const_53; var tmp3 any = A_arbace_a2g_world_A_const_146; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, f__1, tmp2, forms__2, tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_130.GetRawRoot__O()).Invoke_O__O(forms__2))) }

func A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A_New_O(p0 any) *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :302:1
func (t *A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A) Invoke_O_O__O(self, p1__1607000220_SHARP___1 any) any { var tmp1 any = t.F_fs; return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(p1__1607000220_SHARP___1))))).Length__J())).Ref() }

func A_arbace_a2g_world_load_world_top_set__1607000232_A_New() *A_arbace_a2g_world_load_world_top_set__1607000232_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_set__1607000232_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000232_A) Ctor() {}
//line :304:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000232_A) Invoke_O_O__O(self, ps__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_151.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ps__1)) }
//line :304:1
func A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A_New() *A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A) Ctor() {}
//line :304:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A) Invoke_O_O__O(self, p__1607000233__1 any) any { var map__1607000235__2 any = p__1607000233__1; var map__1607000235__3 any; if lang.ISeq_InstanceOf(map__1607000235__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000235__2)) { map__1607000235__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000235__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000235__2)) { map__1607000235__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000235__2) } else { lang.PersistentArrayMap_Init(); map__1607000235__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000235__3 = map__1607000235__2 }; var ns__4 any = lang.RT_Get_O_O__O(map__1607000235__3, A_arbace_a2g_world_A_const_146); var forms__5 any = lang.RT_Get_O_O__O(map__1607000235__3, A_arbace_a2g_world_A_const_53); if jrt.A2g_Truth(ns__4) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O_O__O(ns__4, forms__5) } else { return nil } }

func A_arbace_a2g_world_load_world_top_of__1607000239_A_New() *A_arbace_a2g_world_load_world_top_of__1607000239_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_of__1607000239_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000239_A) Ctor() {}
//line :306:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000239_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_13); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__1 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_170.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_110; return tmp1.Invoke_O_O_O__O(n__1, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }
func A_arbace_a2g_world_load_world_from_source__1607000241_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_from_source__1607000241_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_from_source__1607000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :307:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000241_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :307:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000241_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_69.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_tops), lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1)) }



func A_arbace_a2g_world_load_world_fn__1607000243_A_New_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 any) *A_arbace_a2g_world_load_world_fn__1607000243_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :311:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_A) Ctor_O_O_O_O_O_O_O_O_O_O(c__parsed, c__variants, c__parse, c__failed, c__top_set, c__wait, c__tops, c__unit, c__applied, c__late_inputs any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_parse = c__parse; t.F_failed = c__failed; t.F_top_set = c__top_set; t.F_wait = c__wait; t.F_tops = c__tops; t.F_unit = c__unit; t.F_applied = c__applied; t.F_late_inputs = c__late_inputs }
//line :311:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp68 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O()






	if jrt.A2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3
		jrt.ThreadLocal_Cast(space__4).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_209.GetRawRoot__O()))) }
//line :311:1
	var t__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref()); var laps__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()); var tmp3 *lang.PersistentVector









	lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; laps__4 = tmp2.Invoke_O__O(tmp3.Ref())
//line :311:1
	var lap__5 any; var tmp4 any = A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A_New_O_O(t__3, laps__4); var tmp5 *jrt.Class
	var fncls__58 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A_fn_class










	if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A_fn_class = fncls__58d; tmp5 = fncls__58d } else { tmp5 = fncls__58 }; lap__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :311:1
	var enter_BANG___6 any; var tmp6 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A_New_O_O_O(t.F_variants, t.F_failed, t.F_applied); var tmp7 *jrt.Class
	var fncls__68 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A_fn_class
















	if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A_fn_class = fncls__68d; tmp7 = fncls__68d } else { tmp7 = fncls__68 }; enter_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :311:1
	var resolve_BANG___7 any; var tmp8 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A_New_O_O(t.F_failed, lap__5); var tmp9 *jrt.Class
	var fncls__75 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A_fn_class





















































	if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A_fn_class = fncls__75d; tmp9 = fncls__75d } else { tmp9 = fncls__75 }; resolve_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :311:1
	var analyze_BANG___8 any; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A_New_O(t.F_failed); var tmp11 *jrt.Class
	var fncls__76 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A_fn_class






































































	if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A_fn_class = fncls__76d; tmp11 = fncls__76d } else { tmp11 = fncls__76 }; analyze_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :311:1
	var ___9 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_parsed)); var names1__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_133.Invoke_O__O(t.F_unit)); var ___11 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names1__10); var rt_start__12 any; var G__1607000326__12_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O(); var G__1607000326__13_ any; _ = ___9; _ = ___11























































































	if lang.Util_Identical_O_O__Z(G__1607000326__12_, nil) { G__1607000326__13_ = nil } else { G__1607000326__13_ = jrt.ThreadLocal_Cast(G__1607000326__12_).Get__O() }; if lang.Util_Identical_O_O__Z(G__1607000326__13_, nil) { rt_start__12 = nil } else { rt_start__12 = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.AtomicInteger_Cast(G__1607000326__13_)).Get__I()).Ref() }
//line :311:1
	var rt_order__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(names1__10); var runtime__14 any

























































































	if jrt.A2g_Truth(rt_start__12) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_206.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A_New_O_O_O_O_O(rt_order__13, analyze_BANG___8, t.F_unit, rt_start__12, names1__10); var tmp14 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A_fn_class = fncls__79d; tmp14 = fncls__79d } else { tmp14 = fncls__79 }; runtime__14 = tmp12.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)) } else {





			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_world_A_const_211; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_a2g_world_A_const_119.GetRawRoot__O()).Invoke_O_O_O__O(t.F_unit, A_arbace_a2g_world_A_const_133, rt_order__13))); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A_New_O_O(analyze_BANG___8, names1__10); var tmp18 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A_fn_class = fncls__80d; tmp18 = fncls__80d } else { tmp18 = fncls__80 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :401:1
			runtime__14 = nil }
//line :311:1
	var ___15 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_212); var ___16 any; _ = ___15; _ = ___16


































































































	if jrt.A2g_Truth(t.F_wait) { var tmp19 any; var t_ any = t.F_wait; t.F_wait = nil; tmp19 = t_; ___16 = lang.IFn_Cast(tmp19).Invoke__O() } else { ___16 = nil }
//line :311:1
	var ___17 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_164); var parsed2__18 any; var tmp20 any; var t__2 any = t.F_parse; _ = ___17




































































































	t.F_parse = nil; tmp20 = t__2; var tmp21 lang.IFn = lang.IFn_Cast(tmp20); var tmp22 any; var t__4 any = t.F_late_inputs; t.F_late_inputs = nil; tmp22 = t__4; parsed2__18 = tmp21.Invoke_O__O(tmp22)
//line :311:1
	var ___19 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_213); var ___20 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp24 any; var t__5 any = t.F_tops; _ = ___19; _ = ___20






































































































	t.F_tops = nil; tmp24 = t__5; var tmp25 any = tmp24; var tmp26 any = A_arbace_a2g_world_A_const_47.GetRawRoot__O(); var tmp27 any; var t__6 any = t.F_top_set; t.F_top_set = nil; tmp27 = t__6; ___20 = tmp23.Invoke_O_O_O__O(tmp25, tmp26, lang.IFn_Cast(tmp27).Invoke_O__O(parsed2__18))
//line :311:1
	var ___21 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp29 any; var t__7 any = t.F_parsed; _ = ___21







































































































	t.F_parsed = nil; tmp29 = t__7; ___21 = tmp28.Invoke_O_O_O__O(tmp29, A_arbace_a2g_world_A_const_47.GetRawRoot__O(), parsed2__18)
//line :311:1
	var ___22 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(parsed2__18); var names2__23 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(names1__10)).Ref(), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_133.Invoke_O__O(t.F_unit)))); var ___24 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names2__23); var tops_QMARK___25 any; var tmp30 any = A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A_New(); var tmp31 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A_fn_class; _ = ___22; _ = ___24




















































































































	if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A_fn_class = fncls__77d; tmp31 = fncls__77d } else { tmp31 = fncls__77 }; tops_QMARK___25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil)
//line :311:1
	var holder_QMARK___26 any; var tmp32 any = A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A_New_O(tops_QMARK___25); var tmp33 *jrt.Class
	var fncls__78 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A_fn_class





















































































































	if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A_fn_class = fncls__78d; tmp33 = fncls__78d } else { tmp33 = fncls__78 }; holder_QMARK___26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil)
//line :311:1
	var groups__27 any; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()); var tmp36 any; var iter__1927001039__auto____27 any; var tmp37 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A_New_O_O(tops_QMARK___25, holder_QMARK___26); var tmp38 *jrt.Class
	var fncls__83 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A_fn_class






















































































































	if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A_fn_class = fncls__83d; tmp38 = fncls__83d } else { tmp38 = fncls__83 }; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(names2__23); var tmp39 any = tmp36; var tmp40 any; var iter__1927001039__auto____27_2 any; var tmp41 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A_New_O(tops_QMARK___25); var tmp42 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A_fn_class
	if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A_fn_class = fncls__86d; tmp42 = fncls__86d } else { tmp42 = fncls__86 }; iter__1927001039__auto____27_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); tmp40 = lang.IFn_Cast(iter__1927001039__auto____27_2).Invoke_O__O(names2__23)
//line :430:1
	groups__27 = tmp34.Invoke_O__O(tmp35.Invoke_O_O__O(tmp39, tmp40))
//line :311:1
	var top_groups__28 any; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()); var tmp44 any; var iter__1927001039__auto____28 any; var tmp45 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A_New_O(holder_QMARK___26); var tmp46 *jrt.Class
	var fncls__89 /*line :311:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A_fn_class
























































































































	if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A_fn_class = fncls__89d; tmp46 = fncls__89d } else { tmp46 = fncls__89 }; iter__1927001039__auto____28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil); tmp44 = lang.IFn_Cast(iter__1927001039__auto____28).Invoke_O__O(names2__23); top_groups__28 = tmp43.Invoke_O__O(tmp44)
//line :311:1
	var temp__1927000408__auto____29 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O()

























































































































	if jrt.A2g_Truth(temp__1927000408__auto____29) { var space__30 any = temp__1927000408__auto____29; var seq_1607000365__31 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(groups__27, top_groups__28)); var chunk_1607000366__32 any; var count_1607000367__33 int64 = 0; var i_1607000368__34 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1607000368__34, count_1607000367__33) { var gs__35 any = lang.Indexed_Cast(chunk_1607000366__32).Nth_I__O(lang.RT_IntCast_J__I(i_1607000368__34)); var t0__36 int64 = jrt.System_NanoTime__J(); var rs__37 any; var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp48 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(); var tmp49 any = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A_New_O_O(space__30, analyze_BANG___8); var tmp50 *jrt.Class
			var fncls__91 /*line :434:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A_fn_class


			if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A_fn_class = fncls__91d; tmp50 = fncls__91d } else { tmp50 = fncls__91 }
//line :436:1
			rs__37 = tmp47.Invoke_O_O_O__O(tmp48, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil), gs__35)







			if jrt.System_Getenv_String__String(Lit_56) != nil {
				lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_57, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(rs__37)).Ref(), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t0__36), 1.0e9)).Ref(), jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_215.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_64.GetRawRoot__O(), rs__37)))).Ref()))
//line :444:1
				var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_216.GetRawRoot__O()); var tmp52 any = A_arbace_a2g_world_A_const_217; var seq_1607000373__38 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(tmp51.Invoke_O_O__O(tmp52, lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_218.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_219.GetRawRoot__O(), A_arbace_a2g_world_A_const_64.GetRawRoot__O()), rs__37))); var chunk_1607000374__39 any; var count_1607000375__40 int64 = 0; var i_1607000376__41 int64 = 0; L2: for {


					if lang.Numbers_Lt_J_J__Z(i_1607000376__41, count_1607000375__40) { var vec__1607000377__42 any = lang.Indexed_Cast(chunk_1607000374__39).Nth_I__O(lang.RT_IntCast_J__I(i_1607000376__41)); var n__43 any = lang.RT_Nth_O_I_O__O(vec__1607000377__42, lang.RT_IntCast_J__I(0), nil); var d__44 any = lang.RT_Nth_O_I_O__O(vec__1607000377__42, lang.RT_IntCast_J__I(1), nil)
						lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O__O(Lit_58, d__44, n__43))
//line :447:1
						seq_1607000373__38, chunk_1607000374__39, count_1607000375__40, i_1607000376__41 = seq_1607000373__38, chunk_1607000374__39, count_1607000375__40, lang.Numbers_Unchecked_inc_J__J(i_1607000376__41); continue L2 } else { var temp__1927000414__auto____42 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000373__38); if jrt.A2g_Truth(temp__1927000414__auto____42) { var seq_1607000373__43 any = temp__1927000414__auto____42; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000373__43)) { var c__1927000678__auto____44 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000373__43); seq_1607000373__38, chunk_1607000374__39, count_1607000375__40, i_1607000376__41 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000373__43), c__1927000678__auto____44, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____44))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1607000380__44 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000373__43); var n__45 any = lang.RT_Nth_O_I_O__O(vec__1607000380__44, lang.RT_IntCast_J__I(0), nil); var d__46 any = lang.RT_Nth_O_I_O__O(vec__1607000380__44, lang.RT_IntCast_J__I(1), nil)
							lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O__O(Lit_58, d__46, n__45))
//line :447:1
							seq_1607000373__38, chunk_1607000374__39, count_1607000375__40, i_1607000376__41 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000373__43), nil, 0, 0; continue L2 } } }
//line :444:1
					break L2 } }
//line :434:1
			seq_1607000365__31, chunk_1607000366__32, count_1607000367__33, i_1607000368__34 = seq_1607000365__31, chunk_1607000366__32, count_1607000367__33, lang.Numbers_Unchecked_inc_J__J(i_1607000368__34); continue L1 } else { var temp__1927000414__auto____35 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000365__31); if jrt.A2g_Truth(temp__1927000414__auto____35) { var seq_1607000365__36 any = temp__1927000414__auto____35; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000365__36)) { var c__1927000678__auto____37 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000365__36); seq_1607000365__31, chunk_1607000366__32, count_1607000367__33, i_1607000368__34 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000365__36), c__1927000678__auto____37, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____37))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var gs__37 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000365__36); var t0__38 int64 = jrt.System_NanoTime__J(); var rs__39 any; var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp54 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(); var tmp55 any = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A_New_O_O(space__30, analyze_BANG___8); var tmp56 *jrt.Class
				var fncls__93 /*line :434:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A_fn_class


				if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A_fn_class = fncls__93d; tmp56 = fncls__93d } else { tmp56 = fncls__93 }
//line :436:1
				rs__39 = tmp53.Invoke_O_O_O__O(tmp54, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil), gs__37)







				if jrt.System_Getenv_String__String(Lit_56) != nil {
					lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_57, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(rs__39)).Ref(), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t0__38), 1.0e9)).Ref(), jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_215.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_64.GetRawRoot__O(), rs__39)))).Ref()))
//line :444:1
					var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_216.GetRawRoot__O()); var tmp58 any = A_arbace_a2g_world_A_const_217; var seq_1607000387__40 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(tmp57.Invoke_O_O__O(tmp58, lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_218.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_219.GetRawRoot__O(), A_arbace_a2g_world_A_const_64.GetRawRoot__O()), rs__39))); var chunk_1607000388__41 any; var count_1607000389__42 int64 = 0; var i_1607000390__43 int64 = 0; L3: for {


						if lang.Numbers_Lt_J_J__Z(i_1607000390__43, count_1607000389__42) { var vec__1607000391__44 any = lang.Indexed_Cast(chunk_1607000388__41).Nth_I__O(lang.RT_IntCast_J__I(i_1607000390__43)); var n__45_2 any = lang.RT_Nth_O_I_O__O(vec__1607000391__44, lang.RT_IntCast_J__I(0), nil); var d__46_2 any = lang.RT_Nth_O_I_O__O(vec__1607000391__44, lang.RT_IntCast_J__I(1), nil)
							lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O__O(Lit_58, d__46_2, n__45_2))
//line :447:1
							seq_1607000387__40, chunk_1607000388__41, count_1607000389__42, i_1607000390__43 = seq_1607000387__40, chunk_1607000388__41, count_1607000389__42, lang.Numbers_Unchecked_inc_J__J(i_1607000390__43); continue L3 } else { var temp__1927000414__auto____44 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000387__40); if jrt.A2g_Truth(temp__1927000414__auto____44) { var seq_1607000387__45 any = temp__1927000414__auto____44; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000387__45)) { var c__1927000678__auto____46 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000387__45); seq_1607000387__40, chunk_1607000388__41, count_1607000389__42, i_1607000390__43 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000387__45), c__1927000678__auto____46, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____46))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1607000394__46 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000387__45); var n__47 any = lang.RT_Nth_O_I_O__O(vec__1607000394__46, lang.RT_IntCast_J__I(0), nil); var d__48 any = lang.RT_Nth_O_I_O__O(vec__1607000394__46, lang.RT_IntCast_J__I(1), nil)
								lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_214.GetRawRoot__O()).Invoke_O_O_O__O(Lit_58, d__48, n__47))
//line :447:1
								seq_1607000387__40, chunk_1607000388__41, count_1607000389__42, i_1607000390__43 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000387__45), nil, 0, 0; continue L3 } } }
//line :444:1
						break L3 } }
//line :434:1
				seq_1607000365__31, chunk_1607000366__32, count_1607000367__33, i_1607000368__34 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000365__36), nil, 0, 0; continue L1 } } }
//line :433:1
		break L1 } } else {
















			lang.IFn_Cast(A_arbace_a2g_world_A_const_210.GetRawRoot__O()).Invoke_O_O__O(analyze_BANG___8, names2__23) }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_220)
//line :311:1
	var G__1607000397__29_ any = runtime__14












































































































































	if lang.Util_Identical_O_O__Z(G__1607000397__29_, nil) { } else { lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(G__1607000397__29_) }
//line :311:1
	var main__29 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_133.Invoke_O__O(t.F_unit)); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_180.GetRawRoot__O()); var tmp60 *lang.Keyword = A_arbace_a2g_world_A_const_133; var tmp61 any; var t__8 any = t.F_unit
















































































































































	t.F_unit = nil; tmp61 = t__8; tmp59.Invoke_O_O__O(tmp60.Invoke_O__O(tmp61), lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(names1__10, names2__23, lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(names1__10)).Ref(), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(rt_order__13)), lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(lang.RT_Count_O__I(names1__10)), int64(lang.RT_Count_O__I(names2__23)))).Ref(), main__29))))
//line :311:1
	var temp__1927000414__auto____29 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O()


















































































































































	if jrt.A2g_Truth(temp__1927000414__auto____29) { var space__30_2 any = temp__1927000414__auto____29; jrt.ThreadLocal_Cast(space__30_2).Remove__V() }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_221)
	var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_208.GetRawRoot__O()); var tmp63 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_60, nil); var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_222.GetRawRoot__O()); var tmp65 any; var iter__1927001039__auto____31 any; var tmp66 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A_New(); var tmp67 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A_fn_class = fncls__96d; tmp67 = fncls__96d } else { tmp67 = fncls__96 }; iter__1927001039__auto____31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp66, tmp67, nil); tmp65 = lang.IFn_Cast(iter__1927001039__auto____31).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(laps__4)); tmp1 = tmp62.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp63, jrt.RefArrayOf(jrt.Object_class, nil, tmp64.Invoke_O_O__O(Lit_61, tmp65))).Ref()) }; return nil }(); /*line :311:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp68 != nil { panic(tmp68) }; return tmp1 }










func A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :322:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :322:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp2 any = t.F_laps; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D(lang.Numbers_Minus_J_O__Number(x__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_t)), 1.0e7)), 100.0)).Ref())); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_180.GetRawRoot__O()); var tmp4 any = t.F_t; return tmp3.Invoke_O_O__O(tmp4, jrt.Long_ValueOf_J__Long(x__2).Ref()) }





func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :328:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A) Ctor_O_O_O(c__variants, c__failed, c__applied any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied }
//line :328:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A) Invoke_O_O__O(self, ps__1 any) any { { var units__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A_fn_class
															if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; units__2 = tmp1.Invoke_O_O_O__O(tmp4, tmp5.Ref(), ps__1)
//line :328:1
	var parsed__3 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_160.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_161.GetRawRoot__O()).Invoke__O(); var tmp8 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A_New_O_O(t.F_variants, t.F_applied); var tmp9 *jrt.Class
	var fncls__65 /*line :328:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A_fn_class











	if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A_fn_class = fncls__65d; tmp9 = fncls__65d } else { tmp9 = fncls__65 }
//line :339:1
	parsed__3 = tmp6.Invoke_O_O_O__O(tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), units__2)
//line :328:1
	var seq_1607000279__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_world_A_const_65.GetRawRoot__O(), units__2, parsed__3)); var chunk_1607000280__5 any; var count_1607000281__6 int64 = 0; var i_1607000282__7 int64 = 0; L1: for {























		if lang.Numbers_Lt_J_J__Z(i_1607000282__7, count_1607000281__6) { var vec__1607000283__8 any = lang.Indexed_Cast(chunk_1607000280__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000282__7)); var vec__1607000286__9 any = lang.RT_Nth_O_I_O__O(vec__1607000283__8, lang.RT_IntCast_J__I(0), nil); var file__10 any = lang.RT_Nth_O_I_O__O(vec__1607000286__9, lang.RT_IntCast_J__I(0), nil); var map__1607000289__11 any = lang.RT_Nth_O_I_O__O(vec__1607000283__8, lang.RT_IntCast_J__I(1), nil); var map__1607000289__12 any; if lang.ISeq_InstanceOf(map__1607000289__11) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000289__11)) { map__1607000289__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000289__11), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000289__11)) { map__1607000289__12 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000289__11) } else { lang.PersistentArrayMap_Init(); map__1607000289__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000289__12 = map__1607000289__11 }; var pc__13 any = lang.RT_Get_O_O__O(map__1607000289__12, A_arbace_a2g_world_A_const_181); var nsobj__14 any = lang.RT_Get_O_O__O(map__1607000289__12, A_arbace_a2g_world_A_const_182); var members__15 any = lang.RT_Get_O_O__O(map__1607000289__12, A_arbace_a2g_world_A_const_144); var error__16 any = lang.RT_Get_O_O__O(map__1607000289__12, A_arbace_a2g_world_A_const_183)
			if jrt.A2g_Truth(error__16) {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp11 any = t.F_failed; tmp10.Invoke_O_O_O__O(tmp11, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), error__16) } else {
					var tmp12 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A_New_O_O_O_O_O(nsobj__14, pc__13, t.F_failed, members__15, file__10); var tmp13 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A_fn_class = fncls__66d; tmp13 = fncls__66d } else { tmp13 = fncls__66 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O() }
//line :352:1
			seq_1607000279__4, chunk_1607000280__5, count_1607000281__6, i_1607000282__7 = seq_1607000279__4, chunk_1607000280__5, count_1607000281__6, lang.Numbers_Unchecked_inc_J__J(i_1607000282__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000279__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000279__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000279__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000279__9); seq_1607000279__4, chunk_1607000280__5, count_1607000281__6, i_1607000282__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000279__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1607000293__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000279__9); var vec__1607000296__11 any = lang.RT_Nth_O_I_O__O(vec__1607000293__10, lang.RT_IntCast_J__I(0), nil); var file__12 any = lang.RT_Nth_O_I_O__O(vec__1607000296__11, lang.RT_IntCast_J__I(0), nil); var map__1607000299__13 any = lang.RT_Nth_O_I_O__O(vec__1607000293__10, lang.RT_IntCast_J__I(1), nil); var map__1607000299__14 any; if lang.ISeq_InstanceOf(map__1607000299__13) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000299__13)) { map__1607000299__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000299__13), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000299__13)) { map__1607000299__14 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000299__13) } else { lang.PersistentArrayMap_Init(); map__1607000299__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000299__14 = map__1607000299__13 }; var pc__15 any = lang.RT_Get_O_O__O(map__1607000299__14, A_arbace_a2g_world_A_const_181); var nsobj__16 any = lang.RT_Get_O_O__O(map__1607000299__14, A_arbace_a2g_world_A_const_182); var members__17 any = lang.RT_Get_O_O__O(map__1607000299__14, A_arbace_a2g_world_A_const_144); var error__18 any = lang.RT_Get_O_O__O(map__1607000299__14, A_arbace_a2g_world_A_const_183)
				if jrt.A2g_Truth(error__18) {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp15 any = t.F_failed; tmp14.Invoke_O_O_O__O(tmp15, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), error__18) } else {
						var tmp16 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A_New_O_O_O_O_O(nsobj__16, pc__15, members__17, t.F_failed, file__12); var tmp17 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A_fn_class = fncls__67d; tmp17 = fncls__67d } else { tmp17 = fncls__67 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O() }
//line :352:1
				seq_1607000279__4, chunk_1607000280__5, count_1607000281__6, i_1607000282__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000279__9), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :328:1*/panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A_New() *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A) Ctor() {}
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A) Invoke_O_O_O__O(self, acc__1, p__1607000247__2 any) any { var map__1607000249__3 any = p__1607000247__2; var map__1607000249__4 any; if lang.ISeq_InstanceOf(map__1607000249__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000249__3)) { map__1607000249__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000249__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000249__3)) { map__1607000249__4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000249__3) } else { lang.PersistentArrayMap_Init(); map__1607000249__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000249__4 = map__1607000249__3 }; var file__5 any = lang.RT_Get_O_O__O(map__1607000249__4, A_arbace_a2g_world_A_const_168); var forms__6 any = lang.RT_Get_O_O__O(map__1607000249__4, A_arbace_a2g_world_A_const_53); var ns__7 any = lang.RT_Get_O_O__O(map__1607000249__4, A_arbace_a2g_world_A_const_146); if
																			jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(ns__7)) { return acc__1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_184; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_a2g_world_A_const_184.Get__O()))
//line :330:1
		var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000251__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(forms__6); var chunk_1607000252__11 any; var count_1607000253__12 int64 = 0; var i_1607000254__13 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z(i_1607000254__13, count_1607000253__12) { var fm__14 any = lang.Indexed_Cast(chunk_1607000252__11).Nth_I__O(lang.RT_IntCast_J__I(i_1607000254__13)); var tmp4 any; var and__1927000168__auto____15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__14)
				if jrt.A2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__14)); if jrt.A2g_Truth(and__1927000168__auto____16) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_185); tmp4 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__14))) } else { tmp4 = and__1927000168__auto____16 } } else { tmp4 = and__1927000168__auto____15 }
//line :333:1
				if jrt.A2g_Truth(tmp4) {

					lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()).Invoke_O__O(fm__14)
//line :333:1
					seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, i_1607000254__13 = seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, lang.Numbers_Unchecked_inc_J__J(i_1607000254__13); continue L1 } else { seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, i_1607000254__13 = seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, lang.Numbers_Unchecked_inc_J__J(i_1607000254__13); continue L1 } } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000251__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_1607000251__15 any = temp__1927000414__auto____14; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15); seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, i_1607000254__13 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__16 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15); var tmp6 any; var and__1927000168__auto____17 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__16)
						if jrt.A2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__16)); if jrt.A2g_Truth(and__1927000168__auto____18) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_186); tmp6 = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__16))) } else { tmp6 = and__1927000168__auto____18 } } else { tmp6 = and__1927000168__auto____17 }
//line :333:1
						if jrt.A2g_Truth(tmp6) {

							lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()).Invoke_O__O(fm__16)
//line :333:1
							seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, i_1607000254__13 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15), nil, 0, 0; continue L1 } else { seq_1607000251__10, chunk_1607000252__11, count_1607000253__12, i_1607000254__13 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000251__15), nil, 0, 0; continue L1 } } } }
//line :330:1
			break L1 }; var nsobj__10 any = A_arbace_a2g_world_A_const_184.Get__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____11 any; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A_New_O_O_O(nsobj__10, file__5, ns__7); var tmp11 *jrt.Class
			var fncls__61 /*line :330:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A_fn_class






			if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A_fn_class = fncls__61d; tmp11 = fncls__61d } else { tmp11 = fncls__61 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(forms__6)); tmp3 = tmp8.Invoke_O_O__O(acc__1, tmp9) }; return nil }()
//line :332:1
		lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :330:1
		if tmp12 != nil { panic(tmp12) }; return tmp3 } }






func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A) Ctor_O_O_O(c__nsobj, c__file, c__ns any) { t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A) Invoke_O_O__O(self, s__1607000256__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A_New_O_O_O_O_O(s__1607000256__1, self, t.F_nsobj, t.F_file, t.F_ns); var tmp2 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A_fn_class = fncls__60d; tmp2 = fncls__60d } else { tmp2 = fncls__60 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A) Ctor_O_O_O_O_O(c__s__1607000256, c__iter__1607000255, c__nsobj, c__file, c__ns any) { t.F_s__1607000256 = c__s__1607000256; t.F_iter__1607000255 = c__iter__1607000255; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A) Invoke_O__O(self any) any { { var s__1607000256__1 any; var t_ any = t.F_s__1607000256; t.F_s__1607000256 = nil; s__1607000256__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000256__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000256__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000256__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000256__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000258__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A_New_O_O_O_I_O_O(t.F_nsobj, b__1607000258__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4, t.F_ns); var tmp2 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A_fn_class = fncls__59d; tmp2 = fncls__59d } else { tmp2 = fncls__59 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000255); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000258__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000256__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000258__6), nil) } } else { var cf__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000256__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000255); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000256__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :337:1
func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A) Ctor_O_O_O_I_O_O(c__nsobj, c__b__1607000258, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__ns any) { t.F_nsobj = c__nsobj; t.F_b__1607000258 = c__b__1607000258; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_ns = c__ns }
//line :337:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A) Invoke_O__O(self any) any { { var i__1607000257__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000257__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000257__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000258; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O_O_O__IPersistentVector(t.F_file, t.F_ns, t.F_nsobj, cf__2)); i__1607000257__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000257__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A{}; t.Ctor_O_O(p0, p1); return t }
//line :340:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A) Ctor_O_O(c__variants, c__applied any) { t.F_variants = c__variants; t.F_applied = c__applied }
//line :340:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A) Invoke_O_O__O(self, p__1607000266__1 any) any { var vec__1607000268__2 any = p__1607000266__1; var file__3 any = lang.RT_Nth_O_I_O__O(vec__1607000268__2, lang.RT_IntCast_J__I(0), nil); var ns__4 any = lang.RT_Nth_O_I_O__O(vec__1607000268__2, lang.RT_IntCast_J__I(1), nil); var nsobj__5 any = lang.RT_Nth_O_I_O__O(vec__1607000268__2, lang.RT_IntCast_J__I(2), nil); var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000268__2, lang.RT_IntCast_J__I(3), nil); var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O_O__O(ns__4, lang.Tuple_Create_O__IPersistentVector(cf__6))); var vfs__10 any = lang.RT_Get_O_O__O(t.F_variants, n__9); var vec__1607000271__11 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_128.GetRawRoot__O()); var tmp3 any
																		var or__1927000174__auto____11 any = vfs__10


	if jrt.A2g_Truth(or__1927000174__auto____11) { tmp3 = or__1927000174__auto____11 } else { lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY.Ref() }; var tmp4 any = tmp3; var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A_New_O(t.F_variants); var tmp6 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A_fn_class = fncls__64d; tmp6 = fncls__64d } else { tmp6 = fncls__64 }; vec__1607000271__11 = tmp2.Invoke_O_O_O_O_O__O(cf__6, tmp4, n__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), t.F_applied)
//line :340:1
	var cf__12 any = lang.RT_Nth_O_I_O__O(vec__1607000271__11, lang.RT_IntCast_J__I(0), nil); var counts__13 any = lang.RT_Nth_O_I_O__O(vec__1607000271__11, lang.RT_IntCast_J__I(1), nil); var ___14 any; _ = ___14




	if jrt.A2g_Truth(vfs__10) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp8 any = t.F_applied; ___14 = tmp7.Invoke_O_O_O_O__O(tmp8, A_arbace_a2g_world_A_const_119.GetRawRoot__O(), n__9, counts__13) } else { ___14 = nil }
//line :340:1
	var pc__15 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_146, nsobj__5, A_arbace_a2g_world_A_const_147, A_arbace_a2g_world_A_const_188)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__12)); var tmp9 any = A_arbace_a2g_world_A_const_181; var tmp10 any = A_arbace_a2g_world_A_const_182; var tmp11 any = A_arbace_a2g_world_A_const_144; var tmp12 any = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A_New_O(pc__15); var tmp13 *jrt.Class
	var fncls__63 /*line :340:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A_fn_class







	if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A_fn_class = fncls__63d; tmp13 = fncls__63d } else { tmp13 = fncls__63 }
//line :340:1
	tmp1 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, pc__15, tmp10, nsobj__5, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O())) }; return nil }(); if tmp14 != nil { if true { var e__9 jrt.Throwable_I = tmp14; var tmp15 any = A_arbace_a2g_world_A_const_183; tmp1 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(file__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__9.GetMessage__String().Ref())).Ref()))) } }; return tmp1 }



func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A{}; t.Ctor_O(p0); return t }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A) Invoke_O_O__O(self, p1__1607000221_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000221_SHARP___1) }



func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A{}; t.Ctor_O(p0); return t }
//line :348:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A) Ctor_O(c__pc any) { t.F_pc = c__pc }
//line :348:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_145.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_pc; t.F_pc = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; tmp1 = nil } }; return tmp1 }






func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__failed, c__members, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_failed = c__failed; t.F_members = c__members; t.F_file = c__file }
//line :355:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_190.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; tmp4 = t_; if jrt.A2g_Truth(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, t.F_pc))) { tmp1 = nil } else {
																	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_189.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_world_A_const_147; var tmp7 any = A_arbace_a2g_world_A_const_188; var tmp8 any = A_arbace_a2g_world_A_const_191; var tmp9 any; var t__2 any = t.F_members; t.F_members = nil; tmp9 = t__2; var tmp10 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9)); var tmp11 any; var t__3 any = t.F_pc; t.F_pc = nil; tmp11 = t__3; tmp1 = tmp5.Invoke_O_O__O(tmp10, tmp11) } }
//line :355:1
	return nil }(); if tmp12 != nil { if true { var e__3 jrt.Throwable_I = tmp12; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp14 any; var t__4 any = t.F_failed



		t.F_failed = nil; tmp14 = t__4; var tmp15 any = tmp14; var tmp16 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()); var tmp18 any; var t__5 any = t.F_file; t.F_file = nil; tmp18 = t__5; tmp1 = tmp13.Invoke_O_O_O__O(tmp15, tmp16, lang.Tuple_Create_O_O__IPersistentVector(tmp17.Invoke_O__O(tmp18), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :355:1
func A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :355:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A) Ctor_O_O_O_O_O(c__nsobj, c__pc, c__members, c__failed, c__file any) { t.F_nsobj = c__nsobj; t.F_pc = c__pc; t.F_members = c__members; t.F_failed = c__failed; t.F_file = c__file }
//line :355:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_190.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_nsobj; t.F_nsobj = nil; tmp4 = t_; if jrt.A2g_Truth(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, t.F_pc))) { tmp1 = nil } else {
																	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_189.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_world_A_const_147; var tmp7 any = A_arbace_a2g_world_A_const_188; var tmp8 any = A_arbace_a2g_world_A_const_191; var tmp9 any; var t__2 any = t.F_members; t.F_members = nil; tmp9 = t__2; var tmp10 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9)); var tmp11 any; var t__3 any = t.F_pc; t.F_pc = nil; tmp11 = t__3; tmp1 = tmp5.Invoke_O_O__O(tmp10, tmp11) } }
//line :355:1
	return nil }(); if tmp12 != nil { if true { var e__3 jrt.Throwable_I = tmp12; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp14 any; var t__4 any = t.F_failed



		t.F_failed = nil; tmp14 = t__4; var tmp15 any = tmp14; var tmp16 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()); var tmp18 any; var t__5 any = t.F_file; t.F_file = nil; tmp18 = t__5; tmp1 = tmp13.Invoke_O_O_O__O(tmp15, tmp16, lang.Tuple_Create_O_O__IPersistentVector(tmp17.Invoke_O__O(tmp18), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }





func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A) Ctor_O_O(c__failed, c__lap any) { t.F_failed = c__failed; t.F_lap = c__lap }
//line :365:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A) Invoke_O_O__O(self, names__1 any) any {
	lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_193)
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_192.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A_New_O(t.F_failed); var tmp6 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A_fn_class
		if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A_fn_class = fncls__70d; tmp6 = fncls__70d } else { tmp6 = fncls__70 }
//line :367:1
		tmp1.Invoke_O_O_O__O(names__1, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))



		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_196)
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_192.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_A_const_197.GetRawRoot__O(); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A_New_O(t.F_failed); var tmp10 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A_fn_class
		if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A_fn_class = fncls__71d; tmp10 = fncls__71d } else { tmp10 = fncls__71 }
//line :372:1
		tmp7.Invoke_O_O_O__O(names__1, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))


		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_144)
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_192.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_world_A_const_197.GetRawRoot__O(); var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A_New_O(t.F_failed); var tmp14 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A_fn_class
		if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A_fn_class = fncls__72d; tmp14 = fncls__72d } else { tmp14 = fncls__72 }
//line :376:1
		tmp11.Invoke_O_O_O__O(names__1, tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil))


		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_200)
//line :365:1
		var seq_1607000314__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(names__1); var chunk_1607000315__3 any; var count_1607000316__4 int64 = 0; var i_1607000317__5 int64 = 0; L1: for {














			if lang.Numbers_Lt_J_J__Z(i_1607000317__5, count_1607000316__4) { var n__6 any = lang.Indexed_Cast(chunk_1607000315__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000317__5)); var tmp15 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A_New_O_O(n__6, t.F_failed); var tmp16 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A_fn_class
				if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A_fn_class = fncls__73d; tmp16 = fncls__73d } else { tmp16 = fncls__73 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :380:1
				seq_1607000314__2, chunk_1607000315__3, count_1607000316__4, i_1607000317__5 = seq_1607000314__2, chunk_1607000315__3, count_1607000316__4, lang.Numbers_Unchecked_inc_J__J(i_1607000317__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000314__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1607000314__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000314__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000314__7); seq_1607000314__2, chunk_1607000315__3, count_1607000316__4, i_1607000317__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000314__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000314__7); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A_New_O_O(n__8, t.F_failed); var tmp18 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A_fn_class
					if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A_fn_class = fncls__74d; tmp18 = fncls__74d } else { tmp18 = fncls__74 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :380:1
					seq_1607000314__2, chunk_1607000315__3, count_1607000316__4, i_1607000317__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1607000314__7), nil, 0, 0; continue L1 } } else { return nil } } } }
//line :365:1
	panic("a2g: unreachable")
}
func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A_New() *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A) Ctor() {}
//line :367:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A) Invoke_O_O__O(self, p1__1607000222_SHARP___1 any) any { var G__1607000306__2_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(p1__1607000222_SHARP___1); var G__1607000306__3_ any; if lang.Util_Identical_O_O__Z(G__1607000306__2_, nil) { G__1607000306__3_ = nil } else { G__1607000306__3_ = A_arbace_a2g_world_A_const_149.Invoke_O__O(G__1607000306__2_) }; if lang.Util_Identical_O_O__Z(G__1607000306__3_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O__O(G__1607000306__3_) } }
func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :368:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A) Invoke_O_O__O(self, n__1 any) any {
	var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_194; if jrt.A2g_Truth(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__1))) { return nil } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_195.GetRawRoot__O()).Invoke_O__O(n__1)
//line :369:1
		return nil }(); if tmp3 != nil { if true { var e__4 jrt.Throwable_I = tmp3; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp5 any = t.F_failed
			tmp2 = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_92, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref())) } }
//line :369:1
		return tmp2
	}
}

func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A{}; t.Ctor_O(p0); return t }
//line :373:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :373:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_198.GetRawRoot__O()).Invoke_O__O(n__1)
//line :373:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp4 any = t.F_failed
		tmp1 = tmp3.Invoke_O_O_O__O(tmp4, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_93, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :377:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_199.GetRawRoot__O()).Invoke_O__O(n__1)
//line :377:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp4 any = t.F_failed
		tmp1 = tmp3.Invoke_O_O_O__O(tmp4, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__4.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_201.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :381:1
func A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A{}; t.Ctor_O_O(p0, p1); return t }
//line :381:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :381:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_201.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
func A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A{}; t.Ctor_O(p0); return t }
//line :382:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :382:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_202.GetRawRoot__O()).Invoke_O__O(n__1)
//line :382:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_203; var tmp5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp6 any = A_arbace_a2g_world_A_const_119.GetRawRoot__O()
		var tmp7 any = A_arbace_a2g_world_A_const_204

		tmp3.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, e__4.GetMessage__String().Ref())
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()); var tmp9 any = t.F_failed; var tmp10 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, nil); var tmp12 any = e__4.GetMessage__String().Ref(); var tmp13 *jrt.String; var G__1607000324__8_ any = e__4.GetCause__Throwable(); var G__1607000324__9_ any
		if lang.Util_Identical_O_O__Z(G__1607000324__8_, nil) { G__1607000324__9_ = nil } else { G__1607000324__9_ = jrt.Throwable_Cast(G__1607000324__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z(G__1607000324__9_, nil) { tmp13 = nil } else { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_64, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1607000324__9_)) }
//line :386:1
		tmp1 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref())).Ref())) } }; return tmp1 }















func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :402:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A) Ctor_O_O_O_O_O(c__rt_order, c__analyze_BANG_, c__unit, c__rt_start, c__names1 any) { t.F_rt_order = c__rt_order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit; t.F_rt_start = c__rt_start; t.F_names1 = c__names1 }
//line :402:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A) Invoke_O__O(self any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O()); var tmp2 any; var t_ any = t.F_rt_start; t.F_rt_start = nil; tmp2 = t_; tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(tmp2)))
//line :402:1
	var tmp3 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_world_A_const_211; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_119.GetRawRoot__O()); var tmp8 any; var t__2 any = t.F_unit; t.F_unit = nil; tmp8 = t__2; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_A_const_133; var tmp11 any; var t__3 any = t.F_rt_order; t.F_rt_order = nil; tmp11 = t__3; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O_O__O(tmp9, tmp10, tmp11))); tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_210.GetRawRoot__O()); var tmp13 any; var t__4 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp13 = t__4; var tmp14 any = tmp13; var tmp15 any; var t__5 any = t.F_names1; t.F_names1 = nil; tmp15 = t__5; tmp3 = tmp12.Invoke_O_O__O(tmp14, tmp15) }
//line :404:1
			return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :402:1
			if tmp16 != nil { panic(tmp16) } }; return nil
	}()


	jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_205.GetRawRoot__O()).Invoke__O()).Remove__V()
//line :402:1
	if tmp17 != nil { panic(tmp17) }; return tmp3
}




func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :408:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A) Ctor_O_O(c__analyze_BANG_, c__names1 any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_names1 = c__names1 }
//line :408:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_210.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_names1; t.F_names1 = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }



















func A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A_New() *A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A) Ctor() {}
//line :428:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O_O__O(n__1, Lit_13)) }
func A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A{}; t.Ctor_O(p0); return t }
//line :429:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :429:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A) Invoke_O_O__O(self, n__1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_207; return lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(n__1))) } else { return and__1927000168__auto____2 } }
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A{}; t.Ctor_O_O(p0, p1); return t }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A) Ctor_O_O(c__tops_QMARK_, c__holder_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_holder_QMARK_ = c__holder_QMARK_ }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A) Invoke_O_O__O(self, s__1607000336__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A_New_O_O_O_O(s__1607000336__1, t.F_tops_QMARK_, self, t.F_holder_QMARK_); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :430:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A) Ctor_O_O_O_O(c__s__1607000336, c__tops_QMARK_, c__iter__1607000335, c__holder_QMARK_ any) { t.F_s__1607000336 = c__s__1607000336; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_iter__1607000335 = c__iter__1607000335; t.F_holder_QMARK_ = c__holder_QMARK_ }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A) Invoke_O__O(self any) any { { var s__1607000336__1 any; var t_ any = t.F_s__1607000336; t.F_s__1607000336 = nil; s__1607000336__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000336__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000336__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000336__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000336__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000338__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A_New_O_O_O_I_O(t.F_tops_QMARK_, b__1607000338__6, t.F_holder_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000335); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000338__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000336__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000338__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000336__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_holder_QMARK_).Invoke_O__O(n__4)) } else { tmp4 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1607000335); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000336__3))) } else { s__1607000336__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000336__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :430:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A) Ctor_O_O_O_I_O(c__tops_QMARK_, c__b__1607000338, c__holder_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_b__1607000338 = c__b__1607000338; t.F_holder_QMARK_ = c__holder_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :430:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A) Invoke_O__O(self any) any { { var i__1607000337__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000337__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000337__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_holder_QMARK_).Invoke_O__O(n__2)) } else { tmp2 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp4 any = t.F_b__1607000338; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000337__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000337__1); continue L1 } else { i__1607000337__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000337__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A{}; t.Ctor_O(p0); return t }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A) Invoke_O_O__O(self, s__1607000346__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A_New_O_O_O(s__1607000346__1, self, t.F_tops_QMARK_); var tmp2 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A_fn_class = fncls__85d; tmp2 = fncls__85d } else { tmp2 = fncls__85 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :431:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A) Ctor_O_O_O(c__s__1607000346, c__iter__1607000345, c__tops_QMARK_ any) { t.F_s__1607000346 = c__s__1607000346; t.F_iter__1607000345 = c__iter__1607000345; t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A) Invoke_O__O(self any) any { { var s__1607000346__1 any; var t_ any = t.F_s__1607000346; t.F_s__1607000346 = nil; s__1607000346__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000346__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000346__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000346__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000346__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000348__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A_New_O_O_I_O(t.F_tops_QMARK_, b__1607000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000345); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000348__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000346__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000348__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000346__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000345); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000346__3))) } else { s__1607000346__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000346__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :431:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A) Ctor_O_O_I_O(c__tops_QMARK_, c__b__1607000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_b__1607000348 = c__b__1607000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :431:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A) Invoke_O__O(self any) any { { var i__1607000347__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000347__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000348; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000347__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000347__1); continue L1 } else { i__1607000347__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000347__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A{}; t.Ctor_O(p0); return t }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A) Ctor_O(c__holder_QMARK_ any) { t.F_holder_QMARK_ = c__holder_QMARK_ }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A) Invoke_O_O__O(self, s__1607000356__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A_New_O_O_O(s__1607000356__1, self, t.F_holder_QMARK_); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :432:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A) Ctor_O_O_O(c__s__1607000356, c__iter__1607000355, c__holder_QMARK_ any) { t.F_s__1607000356 = c__s__1607000356; t.F_iter__1607000355 = c__iter__1607000355; t.F_holder_QMARK_ = c__holder_QMARK_ }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A) Invoke_O__O(self any) any { { var s__1607000356__1 any; var t_ any = t.F_s__1607000356; t.F_s__1607000356 = nil; s__1607000356__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000356__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000356__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000356__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000356__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000358__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A_New_O_O_I_O(b__1607000358__6, t.F_holder_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A_fn_class = fncls__87d; tmp2 = fncls__87d } else { tmp2 = fncls__87 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000355); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000358__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000356__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000358__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000356__3); if jrt.A2g_Truth(lang.IFn_Cast(t.F_holder_QMARK_).Invoke_O__O(n__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000355); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000356__3))) } else { s__1607000356__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000356__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :432:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A) Ctor_O_O_I_O(c__b__1607000358, c__holder_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000358 = c__b__1607000358; t.F_holder_QMARK_ = c__holder_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :432:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A) Invoke_O__O(self any) any { { var i__1607000357__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000357__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000357__1)); if jrt.A2g_Truth(lang.IFn_Cast(t.F_holder_QMARK_).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000358; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000357__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000357__1); continue L1 } else { i__1607000357__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000357__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A{}; t.Ctor_O_O(p0, p1); return t }
//line :437:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A) Ctor_O_O(c__space, c__analyze_BANG_ any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :437:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space);

	tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_209.GetRawRoot__O()))); var tmp2 any =
	A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A_New_O_O_O(g__1, t.F_space, t.F_analyze_BANG_); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); return /*line :437:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(g__1), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref()) }
//line :437:1
func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A{}; t.Ctor_O_O(p0, p1); return t }
//line :437:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A) Ctor_O_O(c__space, c__analyze_BANG_ any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :437:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A) Invoke_O_O__O(self, g__1 any) any { var s__2 int64 = jrt.System_NanoTime__J(); var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space);

	tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_209.GetRawRoot__O()))); var tmp2 any =
	A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A_New_O_O_O(g__1, t.F_space, t.F_analyze_BANG_); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); return /*line :437:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(g__1), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), s__2), 1.0e9)).Ref()) }


func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :440:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A) Ctor_O_O_O(c__g, c__space, c__analyze_BANG_ any) { t.F_g = c__g; t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :440:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_210.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_g; t.F_g = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); var tmp7 any; var t__3 any = t.F_space; t.F_space = nil; tmp7 = t__3; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :440:1
func A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :440:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A) Ctor_O_O_O(c__g, c__space, c__analyze_BANG_ any) { t.F_g = c__g; t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :440:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_210.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_g; t.F_g = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); var tmp7 any; var t__3 any = t.F_space; t.F_space = nil; tmp7 = t__3; jrt.ThreadLocal_Cast(tmp7).Remove__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }



















func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A_New() *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A{}; t.Ctor(); return t }
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A) Ctor() {}
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A) Invoke_O_O__O(self, s__1607000399__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A_New_O_O(s__1607000399__1, self); var tmp2 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A_fn_class = fncls__95d; tmp2 = fncls__95d } else { tmp2 = fncls__95 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :460:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A{}; t.Ctor_O_O(p0, p1); return t }
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A) Ctor_O_O(c__s__1607000399, c__iter__1607000398 any) { t.F_s__1607000399 = c__s__1607000399; t.F_iter__1607000398 = c__iter__1607000398 }
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A) Invoke_O__O(self any) any { { var s__1607000399__1 any; var t_ any = t.F_s__1607000399; t.F_s__1607000399 = nil; s__1607000399__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000399__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000399__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000399__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000399__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000401__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A_New_O_I_O(b__1607000401__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000398); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000401__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000399__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000401__6), nil) } } else { var vec__1607000409__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000399__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1607000409__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1607000409__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000398); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(k__5), nil, v__6)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000399__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :460:1
func A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A) Ctor_O_I_O(c__b__1607000401 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000401 = c__b__1607000401; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :460:1
func (t *A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A) Invoke_O__O(self any) any { { var i__1607000400__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000400__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1607000405__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000400__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1607000405__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1607000405__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000401; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref()); i__1607000400__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000400__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A_New() *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A) Ctor() {}
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A) Invoke_O_O__O(self, s__1607000420__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A_New_O_O(s__1607000420__1, self); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :465:1
func A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A{}; t.Ctor_O_O(p0, p1); return t }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A) Ctor_O_O(c__s__1607000420, c__iter__1607000419 any) { t.F_s__1607000420 = c__s__1607000420; t.F_iter__1607000419 = c__iter__1607000419 }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A) Invoke_O__O(self any) any { { var s__1607000420__1 any; var t_ any = t.F_s__1607000420; t.F_s__1607000420 = nil; s__1607000420__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000420__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__1607000427__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var map__1607000427__5 any; if lang.ISeq_InstanceOf(map__1607000427__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1607000427__4)) { map__1607000427__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(map__1607000427__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000427__4)) { map__1607000427__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000427__4) } else { lang.PersistentArrayMap_Init(); map__1607000427__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000427__5 = map__1607000427__4 }; var file__6 any = lang.RT_Get_O_O__O(map__1607000427__5, A_arbace_a2g_world_A_const_168); var ns__7 any = lang.RT_Get_O_O__O(map__1607000427__5, A_arbace_a2g_world_A_const_146); var forms__8 any = lang.RT_Get_O_O__O(map__1607000427__5, A_arbace_a2g_world_A_const_53); if jrt.A2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A_New_O(file__6); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O_O__O(ns__7, forms__8))); if jrt.A2g_Truth(fs__1927001036__auto____10) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000419); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____10, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000420__1))) } else { s__1607000420__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000420__1); continue L1 } } else { s__1607000420__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000420__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :465:1
func A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A_New_O(p0 any) *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A{}; t.Ctor_O(p0); return t }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A) Invoke_O_O__O(self, s__1607000422__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A_New_O_O_O(s__1607000422__1, self, t.F_file); var tmp2 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A_fn_class = fncls__99d; tmp2 = fncls__99d } else { tmp2 = fncls__99 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :465:1
func A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A) Ctor_O_O_O(c__s__1607000422, c__iter__1607000421, c__file any) { t.F_s__1607000422 = c__s__1607000422; t.F_iter__1607000421 = c__iter__1607000421; t.F_file = c__file }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A) Invoke_O__O(self any) any { { var s__1607000422__1 any; var t_ any = t.F_s__1607000422; t.F_s__1607000422 = nil; s__1607000422__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000422__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000422__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000422__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000422__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000424__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A_New_O_O_I_O(b__1607000424__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A_fn_class = fncls__98d; tmp2 = fncls__98d } else { tmp2 = fncls__98 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000421); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000424__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000422__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000424__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000422__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000421); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_file)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000422__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :465:1
func A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A) Ctor_O_O_I_O(c__b__1607000424, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000424 = c__b__1607000424; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :465:1
func (t *A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A) Invoke_O__O(self any) any { { var i__1607000423__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000423__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000423__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000424; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_file))); i__1607000423__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000423__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_with_world_A_New() *A_arbace_a2g_world_with_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_with_world_A{}; t.Ctor(); return t }
//line :470:1
func (t *A_arbace_a2g_world_with_world_A) Ctor() {}
//line :470:1
func (t *A_arbace_a2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_226), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_65.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_227), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(w__2))))), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_228), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_65.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_229), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_172), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_227)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_230), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_173), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_227)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_231), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_174), lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_227)))))))), body__3))))) }
































































































































































































































































































type A_arbace_a2g_world_A struct{ jrt.Object }

var A_arbace_a2g_world_A_const_pool *jrt.RefArray

var A_arbace_a2g_world_A_const_0 *lang.Var

var A_arbace_a2g_world_A_const_1 *lang.Var

var A_arbace_a2g_world_A_const_2 any

var A_arbace_a2g_world_A_const_3 any

var A_arbace_a2g_world_A_const_4 any

var A_arbace_a2g_world_A_const_5 any

var A_arbace_a2g_world_A_const_6 any

var A_arbace_a2g_world_A_const_7 any

var A_arbace_a2g_world_A_const_8 any

var A_arbace_a2g_world_A_const_9 any

var A_arbace_a2g_world_A_const_10 any

var A_arbace_a2g_world_A_const_11 *lang.Var

var A_arbace_a2g_world_A_const_12 *lang.Var

var A_arbace_a2g_world_A_const_13 *lang.Var

var A_arbace_a2g_world_A_const_14 any

var A_arbace_a2g_world_A_const_15 *lang.Var

var A_arbace_a2g_world_A_const_16 *lang.Var

var A_arbace_a2g_world_A_const_17 *lang.Var

var A_arbace_a2g_world_A_const_18 *lang.Var

var A_arbace_a2g_world_A_const_19 *lang.Var

var A_arbace_a2g_world_A_const_20 *lang.Var

var A_arbace_a2g_world_A_const_21 *lang.Var

var A_arbace_a2g_world_A_const_22 *lang.Var

var A_arbace_a2g_world_A_const_23 *lang.Var

var A_arbace_a2g_world_A_const_24 *lang.Keyword

var A_arbace_a2g_world_A_const_25 *lang.Var

var A_arbace_a2g_world_A_const_26 *lang.Var

var A_arbace_a2g_world_A_const_27 any

var A_arbace_a2g_world_A_const_28 any

var A_arbace_a2g_world_A_const_29 *lang.Var

var A_arbace_a2g_world_A_const_30 *lang.Var

var A_arbace_a2g_world_A_const_31 *lang.Var

var A_arbace_a2g_world_A_const_32 *lang.Var

var A_arbace_a2g_world_A_const_33 *lang.Var

var A_arbace_a2g_world_A_const_34 *lang.Var

var A_arbace_a2g_world_A_const_35 *lang.Var

var A_arbace_a2g_world_A_const_36 *lang.Var

var A_arbace_a2g_world_A_const_37 *lang.Var

var A_arbace_a2g_world_A_const_38 *lang.Var

var A_arbace_a2g_world_A_const_39 *lang.Var

var A_arbace_a2g_world_A_const_40 *lang.Var

var A_arbace_a2g_world_A_const_41 *lang.Var

var A_arbace_a2g_world_A_const_42 *lang.Var

var A_arbace_a2g_world_A_const_43 *lang.Var

var A_arbace_a2g_world_A_const_44 *lang.Var

var A_arbace_a2g_world_A_const_45 any

var A_arbace_a2g_world_A_const_46 any

var A_arbace_a2g_world_A_const_47 *lang.Var

var A_arbace_a2g_world_A_const_48 *lang.Var

var A_arbace_a2g_world_A_const_49 *lang.Var

var A_arbace_a2g_world_A_const_50 *lang.Var

var A_arbace_a2g_world_A_const_51 *lang.Var

var A_arbace_a2g_world_A_const_52 *lang.Var

var A_arbace_a2g_world_A_const_53 *lang.Keyword

var A_arbace_a2g_world_A_const_54 *lang.Var

var A_arbace_a2g_world_A_const_55 *lang.Var

var A_arbace_a2g_world_A_const_56 *lang.Var

var A_arbace_a2g_world_A_const_57 any

var A_arbace_a2g_world_A_const_58 *lang.Var

var A_arbace_a2g_world_A_const_59 *lang.Var

var A_arbace_a2g_world_A_const_60 *lang.Var

var A_arbace_a2g_world_A_const_61 *lang.Keyword

var A_arbace_a2g_world_A_const_62 *lang.Var

var A_arbace_a2g_world_A_const_63 *lang.Var

var A_arbace_a2g_world_A_const_64 *lang.Var

var A_arbace_a2g_world_A_const_65 *lang.Var

var A_arbace_a2g_world_A_const_66 *lang.Var

var A_arbace_a2g_world_A_const_67 any

var A_arbace_a2g_world_A_const_68 *lang.Var

var A_arbace_a2g_world_A_const_69 *lang.Var

var A_arbace_a2g_world_A_const_70 *lang.Var

var A_arbace_a2g_world_A_const_71 *lang.Keyword

var A_arbace_a2g_world_A_const_72 *lang.Var

var A_arbace_a2g_world_A_const_73 *lang.Var

var A_arbace_a2g_world_A_const_74 *lang.Var

var A_arbace_a2g_world_A_const_75 *lang.Var

var A_arbace_a2g_world_A_const_76 *lang.Var

var A_arbace_a2g_world_A_const_77 *lang.Var

var A_arbace_a2g_world_A_const_78 *lang.Var

var A_arbace_a2g_world_A_const_79 *lang.Var

var A_arbace_a2g_world_A_const_80 *lang.Var

var A_arbace_a2g_world_A_const_81 *lang.Var

var A_arbace_a2g_world_A_const_82 *lang.Var

var A_arbace_a2g_world_A_const_83 *lang.Keyword

var A_arbace_a2g_world_A_const_84 *lang.Var

var A_arbace_a2g_world_A_const_85 *lang.Var

var A_arbace_a2g_world_A_const_86 *lang.Var

var A_arbace_a2g_world_A_const_87 *lang.Var

var A_arbace_a2g_world_A_const_88 *lang.Keyword

var A_arbace_a2g_world_A_const_89 *lang.Var

var A_arbace_a2g_world_A_const_90 *lang.Var

var A_arbace_a2g_world_A_const_91 *lang.Keyword

var A_arbace_a2g_world_A_const_92 *lang.Keyword

var A_arbace_a2g_world_A_const_93 *lang.Keyword

var A_arbace_a2g_world_A_const_94 *lang.Keyword

var A_arbace_a2g_world_A_const_95 *lang.Var

var A_arbace_a2g_world_A_const_96 *lang.Var

var A_arbace_a2g_world_A_const_97 *lang.Var

var A_arbace_a2g_world_A_const_98 any

var A_arbace_a2g_world_A_const_99 *lang.Var

var A_arbace_a2g_world_A_const_100 *lang.Var

var A_arbace_a2g_world_A_const_101 *lang.Var

var A_arbace_a2g_world_A_const_102 *lang.Keyword

var A_arbace_a2g_world_A_const_103 *lang.Keyword

var A_arbace_a2g_world_A_const_104 any

var A_arbace_a2g_world_A_const_105 *lang.Keyword

var A_arbace_a2g_world_A_const_106 *lang.Keyword

var A_arbace_a2g_world_A_const_107 *lang.Keyword

var A_arbace_a2g_world_A_const_108 *lang.Keyword

var A_arbace_a2g_world_A_const_109 *lang.Keyword

var A_arbace_a2g_world_A_const_110 any

var A_arbace_a2g_world_A_const_111 *lang.Keyword

var A_arbace_a2g_world_A_const_112 *lang.Var

var A_arbace_a2g_world_A_const_113 any

var A_arbace_a2g_world_A_const_114 *lang.Var

var A_arbace_a2g_world_A_const_115 *lang.Var

var A_arbace_a2g_world_A_const_116 *lang.Var

var A_arbace_a2g_world_A_const_117 any

var A_arbace_a2g_world_A_const_118 *lang.Var

var A_arbace_a2g_world_A_const_119 *lang.Var

var A_arbace_a2g_world_A_const_120 *lang.Var

var A_arbace_a2g_world_A_const_121 any

var A_arbace_a2g_world_A_const_122 *lang.Var

var A_arbace_a2g_world_A_const_123 *lang.Var

var A_arbace_a2g_world_A_const_124 *lang.Keyword

var A_arbace_a2g_world_A_const_125 *lang.Keyword

var A_arbace_a2g_world_A_const_126 *lang.Var

var A_arbace_a2g_world_A_const_127 *lang.Keyword

var A_arbace_a2g_world_A_const_128 *lang.Var

var A_arbace_a2g_world_A_const_129 *lang.Var

var A_arbace_a2g_world_A_const_130 *lang.Var

var A_arbace_a2g_world_A_const_131 *lang.Var

var A_arbace_a2g_world_A_const_132 *lang.Keyword

var A_arbace_a2g_world_A_const_133 *lang.Keyword

var A_arbace_a2g_world_A_const_134 *lang.Keyword

var A_arbace_a2g_world_A_const_135 *lang.Keyword

var A_arbace_a2g_world_A_const_136 *lang.Keyword

var A_arbace_a2g_world_A_const_137 *lang.Keyword

var A_arbace_a2g_world_A_const_138 *lang.Keyword

var A_arbace_a2g_world_A_const_139 *lang.Keyword

var A_arbace_a2g_world_A_const_140 *jrt.Class

var A_arbace_a2g_world_A_const_141 *lang.Keyword

var A_arbace_a2g_world_A_const_142 *lang.Var

var A_arbace_a2g_world_A_const_143 *lang.Keyword

var A_arbace_a2g_world_A_const_144 *lang.Keyword

var A_arbace_a2g_world_A_const_145 *lang.Var

var A_arbace_a2g_world_A_const_146 *lang.Keyword

var A_arbace_a2g_world_A_const_147 *lang.Keyword

var A_arbace_a2g_world_A_const_148 *lang.Keyword

var A_arbace_a2g_world_A_const_149 *lang.Keyword

var A_arbace_a2g_world_A_const_150 *lang.Keyword

var A_arbace_a2g_world_A_const_151 *lang.Var

var A_arbace_a2g_world_A_const_152 *lang.Var

var A_arbace_a2g_world_A_const_153 *lang.Var

var A_arbace_a2g_world_A_const_154 *lang.Var

var A_arbace_a2g_world_A_const_155 *lang.Var

var A_arbace_a2g_world_A_const_156 *lang.Var

var A_arbace_a2g_world_A_const_157 *lang.Keyword

var A_arbace_a2g_world_A_const_158 *lang.Keyword

var A_arbace_a2g_world_A_const_159 *lang.Var

var A_arbace_a2g_world_A_const_160 *lang.Var

var A_arbace_a2g_world_A_const_161 *lang.Var

var A_arbace_a2g_world_A_const_162 *lang.Keyword

var A_arbace_a2g_world_A_const_163 *lang.Keyword

var A_arbace_a2g_world_A_const_164 *lang.Keyword

var A_arbace_a2g_world_A_const_165 *lang.Var

var A_arbace_a2g_world_A_const_166 *lang.Var

var A_arbace_a2g_world_A_const_167 *lang.Var

var A_arbace_a2g_world_A_const_168 *lang.Keyword

var A_arbace_a2g_world_A_const_169 *lang.Var

var A_arbace_a2g_world_A_const_170 *lang.Var

var A_arbace_a2g_world_A_const_171 *lang.Var

var A_arbace_a2g_world_A_const_172 *lang.Keyword

var A_arbace_a2g_world_A_const_173 *lang.Keyword

var A_arbace_a2g_world_A_const_174 *lang.Keyword

var A_arbace_a2g_world_A_const_175 *lang.Keyword

var A_arbace_a2g_world_A_const_176 *lang.Keyword

var A_arbace_a2g_world_A_const_177 *lang.Keyword

var A_arbace_a2g_world_A_const_178 *lang.Keyword

var A_arbace_a2g_world_A_const_179 *lang.Keyword

var A_arbace_a2g_world_A_const_180 *lang.Var

var A_arbace_a2g_world_A_const_181 *lang.Keyword

var A_arbace_a2g_world_A_const_182 *lang.Keyword

var A_arbace_a2g_world_A_const_183 *lang.Keyword

var A_arbace_a2g_world_A_const_184 *lang.Var

var A_arbace_a2g_world_A_const_185 any

var A_arbace_a2g_world_A_const_186 any

var A_arbace_a2g_world_A_const_187 *lang.Var

var A_arbace_a2g_world_A_const_188 *lang.Keyword

var A_arbace_a2g_world_A_const_189 *lang.Var

var A_arbace_a2g_world_A_const_190 *lang.Var

var A_arbace_a2g_world_A_const_191 *lang.Keyword

var A_arbace_a2g_world_A_const_192 *lang.Var

var A_arbace_a2g_world_A_const_193 *lang.Keyword

var A_arbace_a2g_world_A_const_194 *lang.Keyword

var A_arbace_a2g_world_A_const_195 *lang.Var

var A_arbace_a2g_world_A_const_196 *lang.Keyword

var A_arbace_a2g_world_A_const_197 *lang.Var

var A_arbace_a2g_world_A_const_198 *lang.Var

var A_arbace_a2g_world_A_const_199 *lang.Var

var A_arbace_a2g_world_A_const_200 *lang.Keyword

var A_arbace_a2g_world_A_const_201 *lang.Var

var A_arbace_a2g_world_A_const_202 *lang.Var

var A_arbace_a2g_world_A_const_203 *lang.Keyword

var A_arbace_a2g_world_A_const_204 *lang.Keyword

var A_arbace_a2g_world_A_const_205 *lang.Var

var A_arbace_a2g_world_A_const_206 *lang.Var

var A_arbace_a2g_world_A_const_207 *lang.Keyword

var A_arbace_a2g_world_A_const_208 *lang.Var

var A_arbace_a2g_world_A_const_209 *lang.Var

var A_arbace_a2g_world_A_const_210 *lang.Var

var A_arbace_a2g_world_A_const_211 *lang.Var

var A_arbace_a2g_world_A_const_212 *lang.Keyword

var A_arbace_a2g_world_A_const_213 *lang.Keyword

var A_arbace_a2g_world_A_const_214 *lang.Var

var A_arbace_a2g_world_A_const_215 *lang.Var

var A_arbace_a2g_world_A_const_216 *lang.Var

var A_arbace_a2g_world_A_const_217 any

var A_arbace_a2g_world_A_const_218 *lang.Var

var A_arbace_a2g_world_A_const_219 *lang.Var

var A_arbace_a2g_world_A_const_220 *lang.Keyword

var A_arbace_a2g_world_A_const_221 *lang.Keyword

var A_arbace_a2g_world_A_const_222 *lang.Var

var A_arbace_a2g_world_A_const_223 *lang.Var

var A_arbace_a2g_world_A_const_224 *lang.Var

var A_arbace_a2g_world_A_const_225 *lang.Var

var A_arbace_a2g_world_A_const_226 any

var A_arbace_a2g_world_A_const_227 any

var A_arbace_a2g_world_A_const_228 any

var A_arbace_a2g_world_A_const_229 any

var A_arbace_a2g_world_A_const_230 any

var A_arbace_a2g_world_A_const_231 any

var A_arbace_a2g_world_A_init jrt.ClassInit

func A_arbace_a2g_world_A_Init() { if !A_arbace_a2g_world_A_init.Done() { A_arbace_a2g_world_A_init.Run(A_arbace_a2g_world_A_clinit) } }

func A_arbace_a2g_world_A_clinit() { A_arbace_a2g_world_A_clinit_p0(); A_arbace_a2g_world_A_clinit_p1(); A_arbace_a2g_world_A_clinit_p2(); A_arbace_a2g_world_A_clinit_p3(); A_arbace_a2g_world_A_clinit_p4(); A_arbace_a2g_world_A_clinit_p5(); A_arbace_a2g_world_A_clinit_p6(); A_arbace_a2g_world_A_clinit_p7(); A_arbace_a2g_world_A_clinit_p8(); A_arbace_a2g_world_A_clinit_p9(); A_arbace_a2g_world_A_clinit_p10(); A_arbace_a2g_world_A_clinit_p11(); A_arbace_a2g_world_A_clinit_p12(); A_arbace_a2g_world_A_clinit_p13(); A_arbace_a2g_world_A_clinit_p14(); A_arbace_a2g_world_A_clinit_p15(); A_arbace_a2g_world_A_clinit_p16(); A_arbace_a2g_world_A_clinit_p17(); A_arbace_a2g_world_A_clinit_p18(); A_arbace_a2g_world_A_clinit_p19() }

func A_arbace_a2g_world_A_clinit_p0() { A_arbace_a2g_world_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 331); A_arbace_a2g_world_A_const_0 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[99]); A_arbace_a2g_world_A_const_1 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[100]); A_arbace_a2g_world_A_const_2 = A_arbace_a2g_world_A_const_pool.A[101]; A_arbace_a2g_world_A_const_3 = A_arbace_a2g_world_A_const_pool.A[102]; A_arbace_a2g_world_A_const_4 = A_arbace_a2g_world_A_const_pool.A[103]; A_arbace_a2g_world_A_const_5 = A_arbace_a2g_world_A_const_pool.A[104]; A_arbace_a2g_world_A_const_6 = A_arbace_a2g_world_A_const_pool.A[105]; A_arbace_a2g_world_A_const_7 = A_arbace_a2g_world_A_const_pool.A[106]; A_arbace_a2g_world_A_const_8 = A_arbace_a2g_world_A_const_pool.A[107]; A_arbace_a2g_world_A_const_9 = A_arbace_a2g_world_A_const_pool.A[108]; A_arbace_a2g_world_A_const_10 = A_arbace_a2g_world_A_const_pool.A[109]; A_arbace_a2g_world_A_const_11 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[110]); A_arbace_a2g_world_A_const_12 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[111]) }

func A_arbace_a2g_world_A_clinit_p1() { A_arbace_a2g_world_A_const_13 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[112]); A_arbace_a2g_world_A_const_14 = A_arbace_a2g_world_A_const_pool.A[113]; A_arbace_a2g_world_A_const_15 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[114]); A_arbace_a2g_world_A_const_16 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[115]); A_arbace_a2g_world_A_const_17 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[116]); A_arbace_a2g_world_A_const_18 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[117]); A_arbace_a2g_world_A_const_19 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[118]); A_arbace_a2g_world_A_const_20 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[119]); A_arbace_a2g_world_A_const_21 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[120]); A_arbace_a2g_world_A_const_22 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[121]); A_arbace_a2g_world_A_const_23 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[122]); A_arbace_a2g_world_A_const_24 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[123]) }

func A_arbace_a2g_world_A_clinit_p2() { A_arbace_a2g_world_A_const_25 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[124]); A_arbace_a2g_world_A_const_26 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[125]); A_arbace_a2g_world_A_const_27 = A_arbace_a2g_world_A_const_pool.A[126]; A_arbace_a2g_world_A_const_28 = A_arbace_a2g_world_A_const_pool.A[127]; A_arbace_a2g_world_A_const_29 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[128]); A_arbace_a2g_world_A_const_30 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[129]); A_arbace_a2g_world_A_const_31 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[130]); A_arbace_a2g_world_A_const_32 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[131]); A_arbace_a2g_world_A_const_33 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[132]); A_arbace_a2g_world_A_const_34 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[133]); A_arbace_a2g_world_A_const_35 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[134]); A_arbace_a2g_world_A_const_36 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[135]) }

func A_arbace_a2g_world_A_clinit_p3() { A_arbace_a2g_world_A_const_37 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[136]); A_arbace_a2g_world_A_const_38 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[137]); A_arbace_a2g_world_A_const_39 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[138]); A_arbace_a2g_world_A_const_40 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[139]); A_arbace_a2g_world_A_const_41 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[140]); A_arbace_a2g_world_A_const_42 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[141]); A_arbace_a2g_world_A_const_43 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[142]); A_arbace_a2g_world_A_const_44 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[143]); A_arbace_a2g_world_A_const_45 = A_arbace_a2g_world_A_const_pool.A[144]; A_arbace_a2g_world_A_const_46 = A_arbace_a2g_world_A_const_pool.A[145]; A_arbace_a2g_world_A_const_47 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[146]); A_arbace_a2g_world_A_const_48 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[147]) }

func A_arbace_a2g_world_A_clinit_p4() { A_arbace_a2g_world_A_const_49 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[148]); A_arbace_a2g_world_A_const_50 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[149]); A_arbace_a2g_world_A_const_51 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[150]); A_arbace_a2g_world_A_const_52 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[151]); A_arbace_a2g_world_A_const_53 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[152]); A_arbace_a2g_world_A_const_54 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[153]); A_arbace_a2g_world_A_const_55 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[154]); A_arbace_a2g_world_A_const_56 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[155]); A_arbace_a2g_world_A_const_57 = A_arbace_a2g_world_A_const_pool.A[156]; A_arbace_a2g_world_A_const_58 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[157]); A_arbace_a2g_world_A_const_59 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[158]); A_arbace_a2g_world_A_const_60 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[159]) }

func A_arbace_a2g_world_A_clinit_p5() { A_arbace_a2g_world_A_const_61 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[160]); A_arbace_a2g_world_A_const_62 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[161]); A_arbace_a2g_world_A_const_63 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[162]); A_arbace_a2g_world_A_const_64 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[163]); A_arbace_a2g_world_A_const_65 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[164]); A_arbace_a2g_world_A_const_66 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[165]); A_arbace_a2g_world_A_const_67 = A_arbace_a2g_world_A_const_pool.A[166]; A_arbace_a2g_world_A_const_68 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[167]); A_arbace_a2g_world_A_const_69 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[168]); A_arbace_a2g_world_A_const_70 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[169]); A_arbace_a2g_world_A_const_71 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[170]); A_arbace_a2g_world_A_const_72 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[171]) }

func A_arbace_a2g_world_A_clinit_p6() { A_arbace_a2g_world_A_const_73 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[172]); A_arbace_a2g_world_A_const_74 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[173]); A_arbace_a2g_world_A_const_75 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[174]); A_arbace_a2g_world_A_const_76 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[175]); A_arbace_a2g_world_A_const_77 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[176]); A_arbace_a2g_world_A_const_78 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[177]); A_arbace_a2g_world_A_const_79 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[178]); A_arbace_a2g_world_A_const_80 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[179]); A_arbace_a2g_world_A_const_81 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[180]); A_arbace_a2g_world_A_const_82 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[181]); A_arbace_a2g_world_A_const_83 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[182]); A_arbace_a2g_world_A_const_84 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[183]) }

func A_arbace_a2g_world_A_clinit_p7() { A_arbace_a2g_world_A_const_85 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[184]); A_arbace_a2g_world_A_const_86 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[185]); A_arbace_a2g_world_A_const_87 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[186]); A_arbace_a2g_world_A_const_88 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[187]); A_arbace_a2g_world_A_const_89 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[188]); A_arbace_a2g_world_A_const_90 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[189]); A_arbace_a2g_world_A_const_91 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[190]); A_arbace_a2g_world_A_const_92 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[191]); A_arbace_a2g_world_A_const_93 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[192]); A_arbace_a2g_world_A_const_94 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[193]); A_arbace_a2g_world_A_const_95 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[194]); A_arbace_a2g_world_A_const_96 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[195]) }

func A_arbace_a2g_world_A_clinit_p8() { A_arbace_a2g_world_A_const_97 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[196]); A_arbace_a2g_world_A_const_98 = A_arbace_a2g_world_A_const_pool.A[197]; A_arbace_a2g_world_A_const_99 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[198]); A_arbace_a2g_world_A_const_100 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[199]); A_arbace_a2g_world_A_const_101 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[200]); A_arbace_a2g_world_A_const_102 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[201]); A_arbace_a2g_world_A_const_103 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[202]); A_arbace_a2g_world_A_const_104 = A_arbace_a2g_world_A_const_pool.A[203]; A_arbace_a2g_world_A_const_105 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[204]); A_arbace_a2g_world_A_const_106 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[205]); A_arbace_a2g_world_A_const_107 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[206]); A_arbace_a2g_world_A_const_108 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[207]) }

func A_arbace_a2g_world_A_clinit_p9() { A_arbace_a2g_world_A_const_109 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[208]); A_arbace_a2g_world_A_const_110 = A_arbace_a2g_world_A_const_pool.A[209]; A_arbace_a2g_world_A_const_111 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[210]); A_arbace_a2g_world_A_const_112 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[211]); A_arbace_a2g_world_A_const_113 = A_arbace_a2g_world_A_const_pool.A[212]; A_arbace_a2g_world_A_const_114 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[213]); A_arbace_a2g_world_A_const_115 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[214]); A_arbace_a2g_world_A_const_116 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[215]); A_arbace_a2g_world_A_const_117 = A_arbace_a2g_world_A_const_pool.A[216]; A_arbace_a2g_world_A_const_118 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[217]); A_arbace_a2g_world_A_const_119 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[218]); A_arbace_a2g_world_A_const_120 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[219]); A_arbace_a2g_world_A_const_121 = A_arbace_a2g_world_A_const_pool.A[220] }

func A_arbace_a2g_world_A_clinit_p10() { A_arbace_a2g_world_A_const_122 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[221]); A_arbace_a2g_world_A_const_123 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[222]); A_arbace_a2g_world_A_const_124 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[223]); A_arbace_a2g_world_A_const_125 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[224]); A_arbace_a2g_world_A_const_126 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[225]); A_arbace_a2g_world_A_const_127 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[226]); A_arbace_a2g_world_A_const_128 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[227]); A_arbace_a2g_world_A_const_129 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[228]); A_arbace_a2g_world_A_const_130 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[229]); A_arbace_a2g_world_A_const_131 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[230]); A_arbace_a2g_world_A_const_132 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[231]); A_arbace_a2g_world_A_const_133 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[232]) }

func A_arbace_a2g_world_A_clinit_p11() { A_arbace_a2g_world_A_const_134 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[233]); A_arbace_a2g_world_A_const_135 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[234]); A_arbace_a2g_world_A_const_136 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[235]); A_arbace_a2g_world_A_const_137 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[236]); A_arbace_a2g_world_A_const_138 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[237]); A_arbace_a2g_world_A_const_139 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[238]); A_arbace_a2g_world_A_const_140 = jrt.Class_Cast(A_arbace_a2g_world_A_const_pool.A[239]); A_arbace_a2g_world_A_const_141 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[240]); A_arbace_a2g_world_A_const_142 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[241]); A_arbace_a2g_world_A_const_143 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[242]); A_arbace_a2g_world_A_const_144 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[243]); A_arbace_a2g_world_A_const_145 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[244]) }

func A_arbace_a2g_world_A_clinit_p12() { A_arbace_a2g_world_A_const_146 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[245]); A_arbace_a2g_world_A_const_147 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[246]); A_arbace_a2g_world_A_const_148 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[247]); A_arbace_a2g_world_A_const_149 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[248]); A_arbace_a2g_world_A_const_150 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[249]); A_arbace_a2g_world_A_const_151 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[250]); A_arbace_a2g_world_A_const_152 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[251]); A_arbace_a2g_world_A_const_153 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[252]); A_arbace_a2g_world_A_const_154 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[253]); A_arbace_a2g_world_A_const_155 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[254]); A_arbace_a2g_world_A_const_156 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[255]); A_arbace_a2g_world_A_const_157 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[256]) }

func A_arbace_a2g_world_A_clinit_p13() { A_arbace_a2g_world_A_const_158 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[257]); A_arbace_a2g_world_A_const_159 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[258]); A_arbace_a2g_world_A_const_160 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[259]); A_arbace_a2g_world_A_const_161 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[260]); A_arbace_a2g_world_A_const_162 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[261]); A_arbace_a2g_world_A_const_163 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[262]); A_arbace_a2g_world_A_const_164 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[263]); A_arbace_a2g_world_A_const_165 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[264]); A_arbace_a2g_world_A_const_166 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[265]); A_arbace_a2g_world_A_const_167 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[266]); A_arbace_a2g_world_A_const_168 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[267]); A_arbace_a2g_world_A_const_169 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[268]) }

func A_arbace_a2g_world_A_clinit_p14() { A_arbace_a2g_world_A_const_170 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[269]); A_arbace_a2g_world_A_const_171 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[270]); A_arbace_a2g_world_A_const_172 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[271]); A_arbace_a2g_world_A_const_173 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[272]); A_arbace_a2g_world_A_const_174 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[273]); A_arbace_a2g_world_A_const_175 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[274]); A_arbace_a2g_world_A_const_176 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[275]); A_arbace_a2g_world_A_const_177 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[276]); A_arbace_a2g_world_A_const_178 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[277]); A_arbace_a2g_world_A_const_179 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[278]); A_arbace_a2g_world_A_const_180 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[279]); A_arbace_a2g_world_A_const_181 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[280]) }

func A_arbace_a2g_world_A_clinit_p15() { A_arbace_a2g_world_A_const_182 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[281]); A_arbace_a2g_world_A_const_183 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[282]); A_arbace_a2g_world_A_const_184 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[283]); A_arbace_a2g_world_A_const_185 = A_arbace_a2g_world_A_const_pool.A[284]; A_arbace_a2g_world_A_const_186 = A_arbace_a2g_world_A_const_pool.A[285]; A_arbace_a2g_world_A_const_187 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[286]); A_arbace_a2g_world_A_const_188 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[287]); A_arbace_a2g_world_A_const_189 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[288]); A_arbace_a2g_world_A_const_190 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[289]); A_arbace_a2g_world_A_const_191 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[290]); A_arbace_a2g_world_A_const_192 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[291]); A_arbace_a2g_world_A_const_193 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[292]) }

func A_arbace_a2g_world_A_clinit_p16() { A_arbace_a2g_world_A_const_194 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[293]); A_arbace_a2g_world_A_const_195 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[294]); A_arbace_a2g_world_A_const_196 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[295]); A_arbace_a2g_world_A_const_197 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[296]); A_arbace_a2g_world_A_const_198 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[297]); A_arbace_a2g_world_A_const_199 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[298]); A_arbace_a2g_world_A_const_200 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[299]); A_arbace_a2g_world_A_const_201 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[300]); A_arbace_a2g_world_A_const_202 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[301]); A_arbace_a2g_world_A_const_203 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[302]); A_arbace_a2g_world_A_const_204 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[303]); A_arbace_a2g_world_A_const_205 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[304]) }

func A_arbace_a2g_world_A_clinit_p17() { A_arbace_a2g_world_A_const_206 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[305]); A_arbace_a2g_world_A_const_207 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[306]); A_arbace_a2g_world_A_const_208 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[307]); A_arbace_a2g_world_A_const_209 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[308]); A_arbace_a2g_world_A_const_210 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[309]); A_arbace_a2g_world_A_const_211 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[310]); A_arbace_a2g_world_A_const_212 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[311]); A_arbace_a2g_world_A_const_213 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[312]); A_arbace_a2g_world_A_const_214 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[313]); A_arbace_a2g_world_A_const_215 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[314]); A_arbace_a2g_world_A_const_216 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[315]); A_arbace_a2g_world_A_const_217 = A_arbace_a2g_world_A_const_pool.A[316] }

func A_arbace_a2g_world_A_clinit_p18() { A_arbace_a2g_world_A_const_218 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[317]); A_arbace_a2g_world_A_const_219 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[318]); A_arbace_a2g_world_A_const_220 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[319]); A_arbace_a2g_world_A_const_221 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[320]); A_arbace_a2g_world_A_const_222 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[321]); A_arbace_a2g_world_A_const_223 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[322]); A_arbace_a2g_world_A_const_224 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[323]); A_arbace_a2g_world_A_const_225 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[324]); A_arbace_a2g_world_A_const_226 = A_arbace_a2g_world_A_const_pool.A[325]; A_arbace_a2g_world_A_const_227 = A_arbace_a2g_world_A_const_pool.A[326]; A_arbace_a2g_world_A_const_228 = A_arbace_a2g_world_A_const_pool.A[327]; A_arbace_a2g_world_A_const_229 = A_arbace_a2g_world_A_const_pool.A[328]; A_arbace_a2g_world_A_const_230 = A_arbace_a2g_world_A_const_pool.A[329] }

func A_arbace_a2g_world_A_clinit_p19() { A_arbace_a2g_world_A_const_231 = A_arbace_a2g_world_A_const_pool.A[330] }

func A_arbace_a2g_world_A_New() *A_arbace_a2g_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_A) Ctor() {}

func (t *A_arbace_a2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_A_class }

func (t *A_arbace_a2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_A); return ok }

func A_arbace_a2g_world_A_Cast(x any) *A_arbace_a2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_apply_variant_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000173_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_world_apply_variant_fn__1607000173_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000175_A struct{ a2g_header uint64; F_counts any }

var A_arbace_a2g_world_apply_variant_fn__1607000175_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000177_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000179_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000175_fn__1607000181_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000184_A struct{ a2g_header uint64; F_variants_of, F_prefix, F_applied any }

var A_arbace_a2g_world_apply_variant_fn__1607000184_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_form_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A struct{ a2g_header uint64; F_iter__1607000020, F_s__1607000021 any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A struct{ a2g_header uint64; F_iter__1607000022, F_s__1607000023 any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A struct{ a2g_header uint64; F_b__1607000025 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_parts_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_parts_A_fn_class *jrt.Class



type A_arbace_a2g_world_continued_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_world_continued_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_world_cut_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_cut_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000004_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000004_A_New() *A_arbace_a2g_world_eval1607000004_A { t := &A_arbace_a2g_world_eval1607000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000004_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000004_A_class }

func (t *A_arbace_a2g_world_eval1607000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000004_A); return ok }

func A_arbace_a2g_world_eval1607000004_A_Cast(x any) *A_arbace_a2g_world_eval1607000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000004_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000008_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000008_A_New() *A_arbace_a2g_world_eval1607000008_A { t := &A_arbace_a2g_world_eval1607000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000008_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000008_A_class }

func (t *A_arbace_a2g_world_eval1607000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000008_A); return ok }

func A_arbace_a2g_world_eval1607000008_A_Cast(x any) *A_arbace_a2g_world_eval1607000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000008_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000008_fn__1607000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class *jrt.Class



type A_arbace_a2g_world_first_form_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_first_form_A_fn_class *jrt.Class



type A_arbace_a2g_world_head_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_head_name_A_fn_class *jrt.Class



type A_arbace_a2g_world_id_space_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_id_space_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_join_continued_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_A struct{ a2g_header uint64; F_claimed, F_conts any }

var A_arbace_a2g_world_join_continued_fn__1607000057_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A struct{ a2g_header uint64; F_claimed, F_conts any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A struct{ a2g_header uint64; F_claimed, F_conts any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A struct{ a2g_header uint64; F_iter__1607000059, F_s__1607000060, F_claimed, F_conts any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A struct{ a2g_header uint64; F_b__1607000062, F_claimed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_conts any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A struct{ a2g_header uint64; F_c any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000065_fn__1607000066_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A struct{ a2g_header uint64; F_c any }

var A_arbace_a2g_world_join_continued_fn__1607000057_fn__1607000058_iter__1607000059__1607000063_fn__1607000064_fn__1607000073_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A struct{ a2g_header uint64; F_iter__1607000039, F_s__1607000040 any }

var A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A struct{ a2g_header uint64; F_iter__1607000041, F_s__1607000042 any }

var A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_A_fn_class *jrt.Class



type A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A struct{ a2g_header uint64; F_b__1607000044 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_join_continued_iter__1607000039__1607000045_fn__1607000046_iter__1607000041__1607000049_fn__1607000050_fn__1607000051_A_fn_class *jrt.Class



type A_arbace_a2g_world_levels_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_levels_A_fn_class *jrt.Class



type A_arbace_a2g_world_levels_lvl__1607000211_A struct{ a2g_header uint64; F_in, F_deps, F_memo any }

var A_arbace_a2g_world_levels_lvl__1607000211_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_A struct{ a2g_header uint64; F_parsed, F_variants, F_parse, F_failed, F_top_set, F_wait, F_tops, F_unit, F_applied, F_late_inputs any }

var A_arbace_a2g_world_load_world_fn__1607000243_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_analyze_BANG___1607000323_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A struct{ a2g_header uint64; F_variants, F_failed, F_applied any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A struct{ a2g_header uint64; F_nsobj, F_file, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A struct{ a2g_header uint64; F_s__1607000256, F_iter__1607000255, F_nsobj, F_file, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A struct{ a2g_header uint64; F_nsobj, F_b__1607000258, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000248_iter__1607000255__1607000259_fn__1607000260_fn__1607000261_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A struct{ a2g_header uint64; F_variants, F_applied any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000274_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A struct{ a2g_header uint64; F_pc any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000267_fn__1607000276_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A struct{ a2g_header uint64; F_nsobj, F_pc, F_failed, F_members, F_file any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000291_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A struct{ a2g_header uint64; F_nsobj, F_pc, F_members, F_failed, F_file any }

var A_arbace_a2g_world_load_world_fn__1607000243_enter_BANG___1607000246_fn__1607000301_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A struct{ a2g_header uint64; F_rt_order, F_analyze_BANG_, F_unit, F_rt_start, F_names1 any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000327_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A struct{ a2g_header uint64; F_analyze_BANG_, F_names1 any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000329_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A struct{ a2g_header uint64; F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A struct{ a2g_header uint64; F_g, F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000369_fn__1607000370_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A struct{ a2g_header uint64; F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A struct{ a2g_header uint64; F_g, F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_fn__1607000383_fn__1607000384_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_holder_QMARK___1607000333_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A struct{ a2g_header uint64; F_tops_QMARK_, F_holder_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A struct{ a2g_header uint64; F_s__1607000336, F_tops_QMARK_, F_iter__1607000335, F_holder_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A struct{ a2g_header uint64; F_tops_QMARK_, F_b__1607000338, F_holder_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000335__1607000339_fn__1607000340_fn__1607000341_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A struct{ a2g_header uint64; F_s__1607000346, F_iter__1607000345, F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A struct{ a2g_header uint64; F_tops_QMARK_, F_b__1607000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000345__1607000349_fn__1607000350_fn__1607000351_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A struct{ a2g_header uint64; F_holder_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A struct{ a2g_header uint64; F_s__1607000356, F_iter__1607000355, F_holder_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A struct{ a2g_header uint64; F_b__1607000358, F_holder_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000355__1607000359_fn__1607000360_fn__1607000361_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A struct{ a2g_header uint64; F_s__1607000399, F_iter__1607000398 any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A struct{ a2g_header uint64; F_b__1607000401 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000243_iter__1607000398__1607000402_fn__1607000403_fn__1607000404_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A struct{ a2g_header uint64; F_t, F_laps any }

var A_arbace_a2g_world_load_world_fn__1607000243_lap__1607000244_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A struct{ a2g_header uint64; F_failed, F_lap any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000305_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000308_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000310_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000312_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000318_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000243_resolve_BANG___1607000304_fn__1607000320_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000243_tops_QMARK___1607000331_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_from_source__1607000241_A struct{ a2g_header uint64; F_tops, F_top_of any }

var A_arbace_a2g_world_load_world_from_source__1607000241_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_iter__1607000419__1607000425_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A struct{ a2g_header uint64; F_s__1607000420, F_iter__1607000419 any }

var A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A struct{ a2g_header uint64; F_file any }

var A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A struct{ a2g_header uint64; F_s__1607000422, F_iter__1607000421, F_file any }

var A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A struct{ a2g_header uint64; F_b__1607000424, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_iter__1607000419__1607000425_fn__1607000426_iter__1607000421__1607000429_fn__1607000430_fn__1607000431_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000226_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_parse__1607000226_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000227_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A struct{ a2g_header uint64; F_fs any }

var A_arbace_a2g_world_load_world_parse__1607000226_fn__1607000229_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_of__1607000239_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_of__1607000239_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_set__1607000232_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_set__1607000232_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_set__1607000232_fn__1607000234_A_fn_class *jrt.Class



type A_arbace_a2g_world_new_unit_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_new_unit_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_fn__1607000085_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_fn__1607000085_A_fn_class *jrt.Class



type A_arbace_a2g_world_par_levels_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_par_levels_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000135_A struct{ a2g_header uint64; F_f any }

var A_arbace_a2g_world_param_key_fn__1607000135_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000137_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000137_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000143_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000143_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000145_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000145_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000151_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000151_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000153_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000153_A_fn_class *jrt.Class



type A_arbace_a2g_world_parse_member_classes_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_parse_member_classes_A_fn_class *jrt.Class



type A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A struct{ a2g_header uint64; F_pc any }

var A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_A_fn_class *jrt.Class



type A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A struct{ a2g_header uint64; F_s__1607000201, F_iter__1607000200, F_pc any }

var A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_A_fn_class *jrt.Class



type A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A struct{ a2g_header uint64; F_b__1607000203, F_pc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_parse_member_classes_iter__1607000200__1607000204_fn__1607000205_fn__1607000206_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000013_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000015_A struct{ a2g_header uint64; F_r any }

var A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000190_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_fn__1607000190_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_read_variants_fn__1607000190_fn__1607000191_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000110_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000110_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000112_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000112_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A struct{ a2g_header uint64; F_root any }

var A_arbace_a2g_world_source_files_iter__1607000114__1607000120_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A struct{ a2g_header uint64; F_s__1607000115, F_iter__1607000114, F_root any }

var A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A struct{ a2g_header uint64; F_s__1607000117, F_iter__1607000116 any }

var A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A struct{ a2g_header uint64; F_b__1607000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_source_files_iter__1607000114__1607000120_fn__1607000121_iter__1607000116__1607000122_fn__1607000123_fn__1607000124_A_fn_class *jrt.Class



type A_arbace_a2g_world_supers_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_supers_of_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_top_names_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_top_names_iter__1607000088__1607000092_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A struct{ a2g_header uint64; F_iter__1607000088, F_nsname, F_s__1607000089 any }

var A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A struct{ a2g_header uint64; F_b__1607000091, F_nsname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_top_names_iter__1607000088__1607000092_fn__1607000093_fn__1607000094_A_fn_class *jrt.Class



type A_arbace_a2g_world_with_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_with_world_A_fn_class *jrt.Class
