//line aot_arbace_a2g_world.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New() *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A { A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_Init(); t := &A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_7; var tmp18 any = tmp17; var tmp19 any; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_8; var tmp20 any = tmp19; var tmp21 any; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_9; var tmp22 any = tmp21; var tmp23 any; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_10; tmp8.Invoke_O_O_O_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp22, tmp23); var tmp24 *lang.Var; lang.RT_Init(); tmp24 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp24).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_219)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp25 != nil { panic(tmp25) }; return tmp3 }
//line :1:1
func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New() *A_arbace_a2g_world_eval1607000008_fn__1607000009_A { A_arbace_a2g_world_eval1607000008_fn__1607000009_A_Init(); t := &A_arbace_a2g_world_eval1607000008_fn__1607000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_15; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_13; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_14; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }















func A_arbace_a2g_world_read_forms_A_New() *A_arbace_a2g_world_read_forms_A { A_arbace_a2g_world_read_forms_A_Init(); t := &A_arbace_a2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_16; r__2 = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0))); var tmp2 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_20; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_21; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, tmp9.Ref())); tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_17; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_a2g_world_read_forms_fn__1607000013_A_New(); var tmp15 *jrt.Class; A_arbace_a2g_world_read_forms_fn__1607000013_A_Init(); tmp15 = A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class; var tmp16 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_25; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(r__2); var tmp20 *jrt.Class; A_arbace_a2g_world_read_forms_fn__1607000015_A_Init(); tmp20 = A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class; tmp2 = tmp11.Invoke_O__O(tmp13.Invoke_O_O__O(tmp16, tmp18.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)))) }
//line :19:1
		return nil }(); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_18; lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke__O()
//line :17:1
		if tmp21 != nil { panic(tmp21) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp23 != nil { panic(tmp23) }; return tmp2 }


func A_arbace_a2g_world_read_forms_fn__1607000013_A_New() *A_arbace_a2g_world_read_forms_fn__1607000013_A { A_arbace_a2g_world_read_forms_fn__1607000013_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Invoke_O_O__O(self, p1__1607000012_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_24; return tmp2.Invoke_O_O__O(p1__1607000012_SHARP___1, tmp3.Ref()) }
//line :20:1
func A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(p0 any) *A_arbace_a2g_world_read_forms_fn__1607000015_A { A_arbace_a2g_world_read_forms_fn__1607000015_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_26; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_27; return tmp2.Invoke_O_O__O(tmp3, t.F_r) }

func A_arbace_a2g_world_class_form_QMARK__A_New() *A_arbace_a2g_world_class_form_QMARK__A { A_arbace_a2g_world_class_form_QMARK__A_Init(); t := &A_arbace_a2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_29; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_206, tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(f__0)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_class_forms_A_New() *A_arbace_a2g_world_class_forms_A { A_arbace_a2g_world_class_forms_A_Init(); t := &A_arbace_a2g_world_class_forms_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_a2g_world_class_forms_A) Ctor() {}
//line :24:1
func (t *A_arbace_a2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_New(); var tmp2 *jrt.Class;
											A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_Init(); tmp2 = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_New() *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Invoke_O_O__O(self, s__1607000020__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_New_O_O(self, s__1607000020__1); var tmp2 *jrt.Class; A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_Init(); tmp2 = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Ctor_O_O(c__iter__1607000019, c__s__1607000020 any) { t.F_iter__1607000019 = c__iter__1607000019; t.F_s__1607000020 = c__s__1607000020 }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Invoke_O__O(self any) any { { var s__1607000020__1 any; var t_ any = t.F_s__1607000020; t.F_s__1607000020 = nil; s__1607000020__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000020__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; f__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp3 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_Init(); tmp4 = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____6 any; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp8 any; var tmp9 any; var and__1927000168__auto____6 any; var tmp10 *lang.Var
															A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(f__4); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp11 any; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_44; var tmp12 any = tmp11; var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_31; tmp9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(f__4))).Ref() } else { tmp9 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp9) { var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_42; tmp8 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(f__4) } else { tmp8 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :25:1
	fs__1927001036__auto____6 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(tmp8)); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_43; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__1607000019); var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_42; return tmp16.Invoke_O_O__O(fs__1927001036__auto____6, tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(s__1607000020__1))) } else { var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_42; s__1607000020__1 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(s__1607000020__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_New() *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Invoke_O_O__O(self, s__1607000022__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_New_O_O(self, s__1607000022__1); var tmp2 *jrt.Class; A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_Init(); tmp2 = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Ctor_O_O(c__iter__1607000021, c__s__1607000022 any) { t.F_iter__1607000021 = c__iter__1607000021; t.F_s__1607000022 = c__s__1607000022 }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Invoke_O__O(self any) any { { var s__1607000022__1 any; var t_ any = t.F_s__1607000022; t.F_s__1607000022 = nil; s__1607000022__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000022__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000022__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000022__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000022__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000024__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000024__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_New_O_I_O(b__1607000024__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_Init(); tmp6 = A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000024__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000021); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000022__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000024__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000022__3); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_39; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1607000021); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_42; return tmp19.Invoke_O_O__O(f__4, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__1607000022__3))) } else { var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_42; s__1607000022__1 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1607000022__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :25:1
func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Ctor_O_I_O(c__b__1607000024 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000024 = c__b__1607000024; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :25:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Invoke_O__O(self any) any { { var i__1607000023__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000023__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000023__1)); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_37; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000024, f__2); i__1607000023__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000023__1); continue L1 } else { i__1607000023__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000023__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_ns_of_forms_A_New() *A_arbace_a2g_world_ns_of_forms_A { A_arbace_a2g_world_ns_of_forms_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var tmp1 *lang.Var;
											A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_46; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_Init(); tmp6 = A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class; f__2 = tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), forms__0)); if
											jrt.A2g_Truth(f__2) { var n__3 any; var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_45; n__3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(f__2); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__3)) { var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_45; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(n__3) } else { return n__3 } } else { return nil } }
//line :31:1
func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_New() *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A { A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_fn__1607000037_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Ctor() {}
//line :31:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Invoke_O_O__O(self, p1__1607000036_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_29; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_158, tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(p1__1607000036_SHARP___1)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_world_top_names_A_New() *A_arbace_a2g_world_top_names_A { A_arbace_a2g_world_top_names_A_Init(); t := &A_arbace_a2g_world_top_names_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_world_top_names_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_New_O(nsname__0); var tmp2 *jrt.Class;


	A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_Init(); tmp2 = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_57; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(forms__1)) }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_New_O(p0 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Invoke_O_O__O(self, s__1607000041__1 any) any { var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_New_O_O_O(self, t.F_nsname, s__1607000041__1); var tmp2 *jrt.Class; A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_Init(); tmp2 = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Ctor_O_O_O(c__iter__1607000040, c__nsname, c__s__1607000041 any) { t.F_iter__1607000040 = c__iter__1607000040; t.F_nsname = c__nsname; t.F_s__1607000041 = c__s__1607000041 }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Invoke_O__O(self any) any { { var s__1607000041__1 any; var t_ any = t.F_s__1607000041; t.F_s__1607000041 = nil; s__1607000041__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000041__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000041__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000041__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000041__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000043__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000043__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_New_O_O_I_O(b__1607000043__6, t.F_nsname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_Init(); tmp6 = A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000043__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000040); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000041__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000043__6), nil) } } else { var cf__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; cf__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000041__3); var vec__1607000051__5 any; var tmp17 *lang.Var
														A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_42; vec__1607000051__5 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(cf__4)
//line :37:1
	var seq__1607000052__6 any; var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_32; seq__1607000052__6 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(vec__1607000051__5); var first__1607000053__7 any; var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_31; first__1607000053__7 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq__1607000052__6); var seq__1607000052__8 any; var tmp20 *lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_47; seq__1607000052__8 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq__1607000052__6); var nm__9 any = first__1607000053__7; var more__10 any = seq__1607000052__8; var more__11 any; var tmp21 *lang.Var

	A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_48; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_31; if jrt.A2g_Truth(tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(more__10))) { var tmp24 *lang.Var; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_42; more__11 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(more__10) } else { more__11 = more__10 }
//line :37:1
	var pkg__12 any; var tmp25 *lang.Keyword


	A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_49; var tmp26 *lang.Keyword = tmp25; var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_31; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_51; pkg__12 = jrt.NN(tmp26).Invoke_O__O(tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(more__11)))
//line :37:1
	var s__13 any; var tmp30 *lang.Var



	A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_50; s__13 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(nm__9)
//line :37:1
	var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_39; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; var tmp34 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp34 = A_arbace_a2g_world_A_const_52; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(pkg__12)) { var tmp35 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp36 *jrt.String; var tmp37 *lang.Var; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_32; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_50; if jrt.A2g_Truth(tmp38.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(pkg__12))) { var tmp40 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_298); var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_53; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_50; tmp36 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp40, jrt.RefArrayOf(jrt.Object_class, tmp42.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(pkg__12), Lit_299, Lit_298), nil)) } else { tmp36 = nil }; tmp33 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp35, jrt.RefArrayOf(jrt.Object_class, tmp36.Ref(), s__13)).Ref() } else { var tmp44 *lang.Var; A_arbace_a2g_world_A_Init(); tmp44 = A_arbace_a2g_world_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O__O(s__13, Lit_299)) {
		var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_53; tmp33 = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O_O_O__O(s__13, Lit_299, Lit_298) } else {
//line :42:1
			var tmp46 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp46 = A_arbace_a2g_world_A_const_55; if tmp46 != nil {

				var tmp47 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_298, nil); var tmp48 *lang.Var; A_arbace_a2g_world_A_Init(); tmp48 = A_arbace_a2g_world_A_const_53; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_a2g_world_A_Init(); tmp50 = A_arbace_a2g_world_A_const_56; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_a2g_world_A_Init(); tmp52 = A_arbace_a2g_world_A_const_30; tmp33 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp47, jrt.RefArrayOf(jrt.Object_class, tmp49.Invoke_O_O_O__O(tmp51.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_299, Lit_298), nil, s__13)).Ref() } else {
//line :42:1
					tmp33 = nil } } }
//line :37:1
	var tmp53 any = tmp33; var tmp54 lang.IFn = lang.IFn_Cast(t.F_iter__1607000040); var tmp55 *lang.Var; A_arbace_a2g_world_A_Init(); tmp55 = A_arbace_a2g_world_A_const_42; return tmp32.Invoke_O_O__O(tmp53, tmp54.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(s__1607000041__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :37:1
func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Ctor_O_O_I_O(c__b__1607000043, c__nsname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000043 = c__b__1607000043; t.F_nsname = c__nsname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :37:1
func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Invoke_O__O(self any) any { { var i__1607000042__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000042__1)); var vec__1607000047__3 any; var tmp2 *lang.Var
																A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_42; vec__1607000047__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(cf__2)
//line :37:1
	var seq__1607000048__4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_32; seq__1607000048__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(vec__1607000047__3); var first__1607000049__5 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; first__1607000049__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1607000048__4); var seq__1607000048__6 any; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_47; seq__1607000048__6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1607000048__4); var nm__7 any = first__1607000049__5; var more__8 any = seq__1607000048__6; var more__9 any; var tmp6 *lang.Var

	A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_48; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_31; if jrt.A2g_Truth(tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(more__8))) { var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_42; more__9 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(more__8) } else { more__9 = more__8 }
//line :37:1
	var pkg__10 any; var tmp10 *lang.Keyword


	A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_49; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_31; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_51; pkg__10 = jrt.NN(tmp11).Invoke_O__O(tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(more__9)))
//line :37:1
	var s__11 any; var tmp15 *lang.Var



	A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_50; s__11 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(nm__7)
//line :37:1
	var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_37; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_b__1607000043; var tmp19 any; var tmp20 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_52; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(pkg__10)) { var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp22 *jrt.String; var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_32; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_50; if jrt.A2g_Truth(tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(pkg__10))) { var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_298); var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_53; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_50; tmp22 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp26, jrt.RefArrayOf(jrt.Object_class, tmp28.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(pkg__10), Lit_299, Lit_298), nil)) } else { tmp22 = nil }; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, tmp22.Ref(), s__11)).Ref() } else { var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_299)) {
		var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_53; tmp19 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O_O__O(s__11, Lit_299, Lit_298) } else {
//line :42:1
			var tmp32 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_55; if tmp32 != nil {

				var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_298, nil); var tmp34 *lang.Var; A_arbace_a2g_world_A_Init(); tmp34 = A_arbace_a2g_world_A_const_53; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_a2g_world_A_Init(); tmp36 = A_arbace_a2g_world_A_const_56; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_a2g_world_A_Init(); tmp38 = A_arbace_a2g_world_A_const_30; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp33, jrt.RefArrayOf(jrt.Object_class, tmp35.Invoke_O_O_O__O(tmp37.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_299, Lit_298), nil, s__11)).Ref() } else {
//line :42:1
					tmp19 = nil } } }
//line :37:1
	tmp17.Invoke_O_O__O(tmp18, tmp19); i__1607000042__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000042__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_source_files_A_New() *A_arbace_a2g_world_source_files_A { A_arbace_a2g_world_source_files_A_Init(); t := &A_arbace_a2g_world_source_files_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_a2g_world_source_files_A) Ctor() {}
//line :46:1
func (t *A_arbace_a2g_world_source_files_A) Invoke_O_O__O(self, p__1607000059__0 any) any { var map__1607000060__2 any = p__1607000059__0; var map__1607000060__3 any; if lang.ISeq_InstanceOf(map__1607000060__2) { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1607000060__2)) { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_58; map__1607000060__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1607000060__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1607000060__2)) { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; map__1607000060__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1607000060__2) } else { lang.PersistentArrayMap_Init(); map__1607000060__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000060__3 = map__1607000060__2 }; var root__4 any; var tmp5 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_59; root__4 = lang.RT_Get_O_O__O(map__1607000060__3, tmp5.Ref()); var dirs__5 any; var tmp6 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_60; dirs__5 = lang.RT_Get_O_O__O(map__1607000060__3, tmp6.Ref()); var tree__6 any; var tmp7 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_61; tree__6 = lang.RT_Get_O_O__O(map__1607000060__3, tmp7.Ref()); var files__7 any; var tmp8 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_62; files__7 = lang.RT_Get_O_O__O(map__1607000060__3, tmp8.Ref()); if



	jrt.A2g_Truth(files__7) {
		var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_63; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_65; return tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), files__7) } else {
//line :50:1
			if jrt.A2g_Truth(tree__6) {




				var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_64; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_50; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_66; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = A_arbace_a2g_world_source_files_fn__1607000062_A_New(); var tmp19 *jrt.Class; A_arbace_a2g_world_source_files_fn__1607000062_A_Init(); tmp19 = A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_46; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_a2g_world_source_files_fn__1607000066_A_New(); var tmp24 *jrt.Class; A_arbace_a2g_world_source_files_fn__1607000066_A_Init(); tmp24 = A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_71; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_65; return tmp13.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(tmp20, tmp22.Invoke_O_O__O(tmp25, tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(root__4))))) } else {
//line :50:1
					var tmp29 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_55; if tmp29 != nil {








						var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_50; var tmp33 any = jrt.NN(tmp32).GetRawRoot__O(); var tmp34 any; var iter__1927001039__auto____8 any; var tmp35 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_New_O(root__4); var tmp36 *jrt.Class
//line :56:1
						A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_Init(); tmp36 = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); tmp34 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						return tmp31.Invoke_O_O__O(tmp33, tmp34) } else {
//line :50:1
							return nil } } } }


func A_arbace_a2g_world_source_files_fn__1607000066_A_New() *A_arbace_a2g_world_source_files_fn__1607000066_A { A_arbace_a2g_world_source_files_fn__1607000066_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000066_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Ctor() {}
//line :53:1
func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Invoke_O_O__O(self, p1__1607000057_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1607000057_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_70; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1607000057_SHARP___1)).GetName__String().Ref(), Lit_304) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
func A_arbace_a2g_world_source_files_fn__1607000062_A_New() *A_arbace_a2g_world_source_files_fn__1607000062_A { A_arbace_a2g_world_source_files_fn__1607000062_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000062_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Invoke_O_O__O(self, p1__1607000058_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_67; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_Init(); tmp4 = A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_69; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p1__1607000058_SHARP___1)) }
//line :54:1
func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_New() *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A { A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Invoke_O_O__O(self, f__1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 any; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_68; var tmp3 any = tmp2; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(f__1))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_New_O(p0 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Invoke_O_O__O(self, s__1607000069__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_New_O_O_O(s__1607000069__1, self, t.F_root); var tmp2 *jrt.Class; A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_Init(); tmp2 = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Ctor_O_O_O(c__s__1607000069, c__iter__1607000068, c__root any) { t.F_s__1607000069 = c__s__1607000069; t.F_iter__1607000068 = c__iter__1607000068; t.F_root = c__root }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Invoke_O__O(self any) any { { var s__1607000069__1 any; var t_ any = t.F_s__1607000069; t.F_s__1607000069 = nil; s__1607000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000069__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; d__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp3 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_Init(); tmp4 = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____6 any; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_65; fs__1927001036__auto____6 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(jrt.NN(jrt.File_Cast(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(t.F_root, d__4))).ListFiles__File1().Ref())); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_43; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000068); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_42; return tmp10.Invoke_O_O__O(fs__1927001036__auto____6, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000069__1))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_42; s__1607000069__1 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(s__1607000069__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_New() *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Ctor() {}
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Invoke_O_O__O(self, s__1607000071__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_New_O_O(s__1607000071__1, self); var tmp2 *jrt.Class; A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_Init(); tmp2 = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Ctor_O_O(c__s__1607000071, c__iter__1607000070 any) { t.F_s__1607000071 = c__s__1607000071; t.F_iter__1607000070 = c__iter__1607000070 }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Invoke_O__O(self any) any { { var s__1607000071__1 any; var t_ any = t.F_s__1607000071; t.F_s__1607000071 = nil; s__1607000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000071__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000071__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000071__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000071__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000073__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000073__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_New_O_I_O(b__1607000073__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_Init(); tmp6 = A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000073__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000070); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000071__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000073__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000071__3); var tmp17 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																				if and__1927000168__auto____5 { var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_70; tmp17 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_304) } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :56:1
	if jrt.A2g_Truth(tmp17) { var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_39; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1607000070); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_42; return tmp20.Invoke_O_O__O(f__4, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1607000071__3))) } else { var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_42; s__1607000071__1 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1607000071__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :56:1
func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Ctor_O_I_O(c__b__1607000073 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000073 = c__b__1607000073; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :56:1
func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Invoke_O__O(self any) any { { var i__1607000072__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000072__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																						if and__1927000168__auto____3 { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_70; tmp2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_304) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :56:1
	if jrt.A2g_Truth(tmp2) { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_37; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000073, f__2); i__1607000072__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000072__1); continue L1 } else { i__1607000072__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000072__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_head_name_A_New() *A_arbace_a2g_world_head_name_A { A_arbace_a2g_world_head_name_A_Init(); t := &A_arbace_a2g_world_head_name_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_world_head_name_A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_31; tmp1 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_30; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_31; return tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_a2g_world_param_key_A_New() *A_arbace_a2g_world_param_key_A { A_arbace_a2g_world_param_key_A_Init(); t := &A_arbace_a2g_world_param_key_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_a2g_world_param_key_A) Ctor() {}
//line :67:1
func (t *A_arbace_a2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_72; h__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0); var G__1607000088__3_ any = h__2; switch
	lang.Util_Hash_O__I(G__1607000088__3_) >> 13 & 15 { case 5: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_84) { var nm__4 any; var tmp2 *lang.Var

















		A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_46; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_29; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_42; nm__4 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(f__0)))
//line :71:1
		var tmp9 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_73; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_30; return lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(nm__4)) }; case 6: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_284) { var params__4 any; var tmp12 *lang.Var












			A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_31; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_46; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_48; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 any = A_arbace_a2g_world_param_key_fn__1607000089_A_New_O(f__0); var tmp19 *jrt.Class; A_arbace_a2g_world_param_key_fn__1607000089_A_Init(); tmp19 = A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class; params__4 = tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O()))
//line :71:1
			var tmp20 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_78; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_79; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = A_arbace_a2g_world_param_key_fn__1607000091_A_New(); var tmp25 *jrt.Class; A_arbace_a2g_world_param_key_fn__1607000091_A_Init(); tmp25 = A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class; var tmp26 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_42; return lang.Tuple_Create_O_O__IPersistentVector(tmp21, tmp23.Invoke_O_O__O(tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(params__4))) }; case 7: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_206) { var tmp28 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_81; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_30; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_45; return lang.Tuple_Create_O_O__IPersistentVector(tmp29, tmp31.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(f__0))) }; case 10: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_93) { var tmp33 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_83; var tmp34 any = tmp33.Ref(); var tmp35 any; var or__1927000174__auto____4 any; var tmp36 *lang.Keyword


















				A_arbace_a2g_world_A_Init(); tmp36 = A_arbace_a2g_world_A_const_84; var tmp37 *lang.Keyword = tmp36; or__1927000174__auto____4 = jrt.NN(tmp37).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp35 = or__1927000174__auto____4 } else { A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_85 }
//line :71:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp34, tmp35) }; case 13: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_99) { var vec__1607000094__4 any = f__0; var seq__1607000095__5 any; var tmp38 *lang.Var

					A_arbace_a2g_world_A_Init(); tmp38 = A_arbace_a2g_world_A_const_32; seq__1607000095__5 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(vec__1607000094__4)
//line :71:1
					var first__1607000096__6 any; var tmp39 *lang.Var

					A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_31; first__1607000096__6 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq__1607000095__5)
//line :71:1
					var seq__1607000095__7 any; var tmp40 *lang.Var

					A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_47; seq__1607000095__7 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq__1607000095__5)
//line :71:1
					var ___8 any = first__1607000096__6; var first__1607000096__9 any; var tmp41 *lang.Var; _ = ___8

					A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_31; first__1607000096__9 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq__1607000095__7)
//line :71:1
					var seq__1607000095__10 any; var tmp42 *lang.Var

					A_arbace_a2g_world_A_Init(); tmp42 = A_arbace_a2g_world_A_const_47; seq__1607000095__10 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq__1607000095__7)
//line :71:1
					var nm__11 any = first__1607000096__9; var more__12 any = seq__1607000095__10; var more__13 any; var tmp43 any = A_arbace_a2g_world_param_key_fn__1607000097_A_New_O(more__12); var tmp44 *jrt.Class



					A_arbace_a2g_world_param_key_fn__1607000097_A_Init(); tmp44 = A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil).Invoke__O()
//line :71:1
					var params__14 any; var tmp45 *lang.Var







					A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_31; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_46; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_a2g_world_A_Init(); tmp49 = A_arbace_a2g_world_A_const_48; params__14 = tmp46.Invoke_O__O(tmp48.Invoke_O_O__O(jrt.NN(tmp49).GetRawRoot__O(), more__13))
//line :71:1
					var static__15 bool; var tmp50 *lang.Keyword








					A_arbace_a2g_world_A_Init(); tmp50 = A_arbace_a2g_world_A_const_82; var tmp51 *lang.Keyword = tmp50; static__15 = lang.RT_BooleanCast_O__Z(jrt.NN(tmp51).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11)))
//line :71:1
					var ps__16 any









					if static__15 { ps__16 = params__14 } else { var tmp52 *lang.Var; A_arbace_a2g_world_A_Init(); tmp52 = A_arbace_a2g_world_A_const_42; ps__16 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(params__14) }
//line :71:1
					var tmp53 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp53 = A_arbace_a2g_world_A_const_86; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_a2g_world_A_Init(); tmp55 = A_arbace_a2g_world_A_const_30; var tmp56 any = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(nm__11); var tmp57 any = jrt.Boolean_ValueOf_Z__Boolean(static__15).Ref(); var tmp58 *lang.Var; A_arbace_a2g_world_A_Init(); tmp58 = A_arbace_a2g_world_A_const_79; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any = A_arbace_a2g_world_param_key_fn__1607000099_A_New(); var tmp61 *jrt.Class; A_arbace_a2g_world_param_key_fn__1607000099_A_Init(); tmp61 = A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp54, tmp56, tmp57, tmp59.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil), ps__16)) }; case 14: if lang.Util_Equiv_O_O__Z(G__1607000088__3_, Lit_96) { var vec__1607000102__4 any = f__0; var seq__1607000103__5 any; var tmp62 *lang.Var

						A_arbace_a2g_world_A_Init(); tmp62 = A_arbace_a2g_world_A_const_32; seq__1607000103__5 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(vec__1607000102__4)
//line :71:1
						var first__1607000104__6 any; var tmp63 *lang.Var

						A_arbace_a2g_world_A_Init(); tmp63 = A_arbace_a2g_world_A_const_31; first__1607000104__6 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq__1607000103__5)
//line :71:1
						var seq__1607000103__7 any; var tmp64 *lang.Var

						A_arbace_a2g_world_A_Init(); tmp64 = A_arbace_a2g_world_A_const_47; seq__1607000103__7 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(seq__1607000103__5)
//line :71:1
						var ___8_2 any = first__1607000104__6; var first__1607000104__9 any; var tmp65 *lang.Var; _ = ___8_2

						A_arbace_a2g_world_A_Init(); tmp65 = A_arbace_a2g_world_A_const_31; first__1607000104__9 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(seq__1607000103__7)
//line :71:1
						var seq__1607000103__10 any; var tmp66 *lang.Var

						A_arbace_a2g_world_A_Init(); tmp66 = A_arbace_a2g_world_A_const_47; seq__1607000103__10 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq__1607000103__7)
//line :71:1
						var nm__11_2 any = first__1607000104__9; var more__12_2 any = seq__1607000103__10; var more__13_2 any; var tmp67 any = A_arbace_a2g_world_param_key_fn__1607000105_A_New_O(more__12_2); var tmp68 *jrt.Class



						A_arbace_a2g_world_param_key_fn__1607000105_A_Init(); tmp68 = A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp67, tmp68, nil).Invoke__O()
//line :71:1
						var params__14_2 any; var tmp69 *lang.Var







						A_arbace_a2g_world_A_Init(); tmp69 = A_arbace_a2g_world_A_const_31; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_a2g_world_A_Init(); tmp71 = A_arbace_a2g_world_A_const_46; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_a2g_world_A_Init(); tmp73 = A_arbace_a2g_world_A_const_48; params__14_2 = tmp70.Invoke_O__O(tmp72.Invoke_O_O__O(jrt.NN(tmp73).GetRawRoot__O(), more__13_2))
//line :71:1
						var static__15_2 bool; var tmp74 *lang.Keyword








						A_arbace_a2g_world_A_Init(); tmp74 = A_arbace_a2g_world_A_const_82; var tmp75 *lang.Keyword = tmp74; static__15_2 = lang.RT_BooleanCast_O__Z(jrt.NN(tmp75).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11_2)))
//line :71:1
						var ps__16_2 any









						if static__15_2 { ps__16_2 = params__14_2 } else { var tmp76 *lang.Var; A_arbace_a2g_world_A_Init(); tmp76 = A_arbace_a2g_world_A_const_42; ps__16_2 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(params__14_2) }
//line :71:1
						var tmp77 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp77 = A_arbace_a2g_world_A_const_86; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_a2g_world_A_Init(); tmp79 = A_arbace_a2g_world_A_const_30; var tmp80 any = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(nm__11_2); var tmp81 any = jrt.Boolean_ValueOf_Z__Boolean(static__15_2).Ref(); var tmp82 *lang.Var; A_arbace_a2g_world_A_Init(); tmp82 = A_arbace_a2g_world_A_const_79; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any = A_arbace_a2g_world_param_key_fn__1607000107_A_New(); var tmp85 *jrt.Class; A_arbace_a2g_world_param_key_fn__1607000107_A_Init(); tmp85 = A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp78, tmp80, tmp81, tmp83.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil), ps__16_2)) }; default:}; return nil }



func A_arbace_a2g_world_param_key_fn__1607000097_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000097_A { A_arbace_a2g_world_param_key_fn__1607000097_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000097_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_74; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp2 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_75; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(xs__1)) {
												var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_76; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_77; xs__1, acc__2 = tmp6.Invoke_O_O__O(tmp7, xs__1), acc__2; continue L1 } else {
//line :76:1
			var tmp8 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_55; if tmp8 != nil {

				var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_42; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(xs__1); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_13; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_31; xs__1, acc__2 = tmp10, tmp12.Invoke_O_O__O(acc__2, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :76:1
					return nil } } } } }; /*line :75:1*/panic("a2g: unreachable") }
//line :75:1
func A_arbace_a2g_world_param_key_fn__1607000105_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000105_A { A_arbace_a2g_world_param_key_fn__1607000105_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000105_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :75:1
func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_74; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp2 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_75; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(xs__1)) {
												var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_76; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_77; xs__1, acc__2 = tmp6.Invoke_O_O__O(tmp7, xs__1), acc__2; continue L1 } else {
//line :76:1
			var tmp8 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_55; if tmp8 != nil {

				var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_42; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(xs__1); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_13; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_31; xs__1, acc__2 = tmp10, tmp12.Invoke_O_O__O(acc__2, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :76:1
					return nil } } } } }; /*line :75:1*/panic("a2g: unreachable") }






func A_arbace_a2g_world_param_key_fn__1607000099_A_New() *A_arbace_a2g_world_param_key_fn__1607000099_A { A_arbace_a2g_world_param_key_fn__1607000099_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000099_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Ctor() {}
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Invoke_O_O__O(self, p1__1607000086_SHARP___1 any) any { var G__1607000100__2_ any; var tmp1 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_80; var tmp2 *lang.Keyword = tmp1; G__1607000100__2_ = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000086_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000100__2_, nil) { return nil } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_50; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(G__1607000100__2_) } }
//line :82:1
func A_arbace_a2g_world_param_key_fn__1607000107_A_New() *A_arbace_a2g_world_param_key_fn__1607000107_A { A_arbace_a2g_world_param_key_fn__1607000107_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000107_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Ctor() {}
//line :82:1
func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Invoke_O_O__O(self, p1__1607000086_SHARP___1 any) any { var G__1607000108__2_ any; var tmp1 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_80; var tmp2 *lang.Keyword = tmp1; G__1607000108__2_ = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000086_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000108__2_, nil) { return nil } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_50; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(G__1607000108__2_) } }

func A_arbace_a2g_world_param_key_fn__1607000089_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000089_A { A_arbace_a2g_world_param_key_fn__1607000089_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000089_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :84:1
func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Invoke_O__O(self any) any { { var xs__1 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_42; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; xs__1 = tmp2.Invoke_O__O(tmp3); var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_74; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp5 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_75; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; if lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(xs__1)) {
												var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_76; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_77; xs__1, acc__2 = tmp9.Invoke_O_O__O(tmp10, xs__1), acc__2; continue L1 } else {
//line :85:1
			var tmp11 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_55; if tmp11 != nil {

				var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_42; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(xs__1); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_13; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; xs__1, acc__2 = tmp13, tmp15.Invoke_O_O__O(acc__2, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :85:1
					return nil } } } } }; /*line :84:1*/panic("a2g: unreachable") }



func A_arbace_a2g_world_param_key_fn__1607000091_A_New() *A_arbace_a2g_world_param_key_fn__1607000091_A { A_arbace_a2g_world_param_key_fn__1607000091_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000091_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Ctor() {}
//line :88:1
func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Invoke_O_O__O(self, p1__1607000087_SHARP___1 any) any { var G__1607000092__2_ any; var tmp1 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_80; var tmp2 *lang.Keyword = tmp1; G__1607000092__2_ = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000087_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000092__2_, nil) { return nil } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_50; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(G__1607000092__2_) } }





func A_arbace_a2g_world_cut_key_A_New() *A_arbace_a2g_world_cut_key_A { A_arbace_a2g_world_cut_key_A_Init(); t := &A_arbace_a2g_world_cut_key_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_a2g_world_cut_key_A) Ctor() {}
//line :94:1
func (t *A_arbace_a2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var
	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_72; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_84, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :95:1
	if jrt.A2g_Truth(tmp1) {
		var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_87; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :95:1
			var tmp5 any; var and__1927000168__auto____2_2 any; var tmp6 *lang.Var


			A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_72; tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_93, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp5 = and__1927000168__auto____2_2 }
//line :95:1
			if jrt.A2g_Truth(tmp5) { var tmp8 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_83; var tmp9 any = tmp8.Ref(); var tmp10 any; var or__1927000174__auto____2 any; var tmp11 *lang.Var


				A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_45; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp10 = or__1927000174__auto____2 } else { A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_85 }
//line :95:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10) } else { var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_29; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_31; if jrt.A2g_Truth(tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0))) {



					var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_87; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_39; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_89; return tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp19, x__0)) } else {
//line :95:1
						var tmp20 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_55; if tmp20 != nil { var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_88; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_217, nil); var tmp24 *lang.Var; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_90; var tmp25 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp26 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp26 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp22.Invoke_O_O__O(tmp25, tmp26.Ref())))) } else { return nil
						}
					}
				}
		}
}

func A_arbace_a2g_world_class_parts_A_New() *A_arbace_a2g_world_class_parts_A { A_arbace_a2g_world_class_parts_A_Init(); t := &A_arbace_a2g_world_class_parts_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_a2g_world_class_parts_A) Ctor() {}
//line :102:1
func (t *A_arbace_a2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__1607000112__2 any = cf__0; var seq__1607000113__3 any; var tmp1 *lang.Var;


	A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; seq__1607000113__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1607000112__2); var first__1607000114__4 any; var tmp2 /*line :102:1*/*lang.Var;


	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; first__1607000114__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1607000113__3); var seq__1607000113__5 any; var tmp3 /*line :102:1*/*lang.Var;


	A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_47; seq__1607000113__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1607000113__3); var dc__6 any = first__1607000114__4; var first__1607000114__7 any; var tmp4 /*line :102:1*/*lang.Var;


	A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; first__1607000114__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1607000113__5); var seq__1607000113__8 any; var tmp5 /*line :102:1*/*lang.Var;


	A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_47; seq__1607000113__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1607000113__5); var nm__9 any = first__1607000114__7; var more__10 any = seq__1607000113__8; var vec__1607000115__11 any; var tmp6 /*line :102:1*/*lang.Var;



	A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_48; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_31; if jrt.A2g_Truth(tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(more__10))) { var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_31; var tmp10 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(more__10)); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_42; vec__1607000115__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(more__10)) } else { var tmp12 *lang.PersistentVector; lang.PersistentVector_Init(); tmp12 = lang.PersistentVector_EMPTY; vec__1607000115__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp12.Ref(), more__10) }; var comps__12 any = /*line :102:1*/lang.RT_Nth_O_I_O__O(vec__1607000115__11, lang.RT_IntCast_J__I(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O(vec__1607000115__11, lang.RT_IntCast_J__I(1), nil); var vec__1607000118__14 any; var tmp13 *lang.Var;




	A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_51; vec__1607000118__14 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(more__13); var opts__15 any = /*line :102:1*/lang.RT_Nth_O_I_O__O(vec__1607000118__14, lang.RT_IntCast_J__I(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O(vec__1607000118__14, lang.RT_IntCast_J__I(1), nil); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_43; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_92; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_93; var tmp20 any = tmp15.Invoke_O_O_O__O(tmp16, comps__12, tmp18.Invoke_O_O__O(jrt.NN(tmp19).GetRawRoot__O(), opts__15)); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_91; return lang.Tuple_Create_O_O__IPersistentVector(tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(members__16)) }







func A_arbace_a2g_world_apply_variant_A_New() *A_arbace_a2g_world_apply_variant_A { A_arbace_a2g_world_apply_variant_A_Init(); t := &A_arbace_a2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__1607000124__6 any; var tmp1 *lang.Var;







	A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_94; vec__1607000124__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(cf__0); var head__7 any = /*line :110:1*/lang.RT_Nth_O_I_O__O(vec__1607000124__6, lang.RT_IntCast_J__I(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O(vec__1607000124__6, lang.RT_IntCast_J__I(1), nil); var members__9 any; var n__9 any; var tmp2 *lang.Var;









	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_95; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_97; n__9 = tmp3.Invoke_O__O(tmp4); var tmp5 /*line :121:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_79; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_a2g_world_apply_variant_fn__1607000127_A_New_O(n__9); var tmp8 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000127_A_Init(); tmp8 = A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class; members__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), members__8); var counts__10 any; var tmp9 /*line :110:1*/*lang.Var;














	A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_95; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_102; counts__10 = tmp10.Invoke_O__O(tmp11); var members__11 any; var tmp12 /*line :110:1*/*lang.Var;















	A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_96; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_a2g_world_apply_variant_fn__1607000129_A_New_O(counts__10); var tmp15 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000129_A_Init(); tmp15 = A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class; members__11 = tmp13.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), members__9, vforms__1); var members__12 any; if

















	jrt.A2g_Truth(variants_of__3) {
		var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_79; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = A_arbace_a2g_world_apply_variant_fn__1607000138_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp19 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000138_A_Init(); tmp19 = A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class; members__12 = tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), members__11) } else {
//line :144:1
			members__12 = members__11 }; var tmp20 /*line :110:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_110; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_111; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_112; var tmp25 any = jrt.NN(tmp24).GetRawRoot__O(); var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_43; var tmp27 any = tmp21.Invoke_O_O__O(tmp23.Invoke_O_O__O(tmp25, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(head__7, members__12)), lang.RT_Meta_O__IPersistentMap(cf__0)); var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_12; return lang.Tuple_Create_O_O__IPersistentVector(tmp27, lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(counts__10)) }
//line :110:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_109; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O__O(cf__0, vforms__1, nil, nil, nil)
}



func A_arbace_a2g_world_apply_variant_fn__1607000127_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000127_A { A_arbace_a2g_world_apply_variant_fn__1607000127_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000127_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :121:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_72; if lang.Util_Equiv_O_O__Z(Lit_93, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(m__1)) {
												var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_98; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_99; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_84; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_100; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = t.F_n; var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_101; return tmp3.Invoke_O_O_O_O__O(m__1, tmp5, tmp7, tmp9.Invoke_O_O__O(tmp10, jrt.NN(tmp11).GetRawRoot__O())) } else {
//line :121:1
		return m__1 } }





func A_arbace_a2g_world_apply_variant_fn__1607000129_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_A { A_arbace_a2g_world_apply_variant_fn__1607000129_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :127:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__1607000130__3_ any; var tmp1 *lang.Var;
													A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_72; G__1607000130__3_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vf__2); switch lang.Util_Hash_O__I(G__1607000130__3_) { case 96417: if lang.Util_Equiv_O_O__Z(G__1607000130__3_, Lit_199) {







		var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_100; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_counts; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_104; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_105; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_101; tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp8, jrt.NN(tmp9).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_13; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_45; return tmp11.Invoke_O_O__O(ms__1, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(vf__2)) }
//line :128:1
	case 98882: if lang.Util_Equiv_O_O__Z(G__1607000130__3_, Lit_112) { var k__4 any; var tmp13 *lang.Var


		A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_103; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_29; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_45; if jrt.A2g_Truth(tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(vf__2))) { var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_42; tmp15 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(vf__2) } else { var tmp20 *lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_45; tmp15 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(vf__2) }; k__4 = tmp14.Invoke_O__O(tmp15)
//line :128:1
		var hit__5 any; var tmp21 *lang.Var



		A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_67; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_New_O(k__4); var tmp24 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_Init(); tmp24 = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class; hit__5 = tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), ms__1)
		if jrt.A2g_Truth(hit__5) { } else { var tmp25 *lang.Var; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_88; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_200, nil); var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_90; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_45; var tmp31 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, tmp29.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(vf__2)))).Ref(); var tmp32 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp32 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp26.Invoke_O_O__O(tmp31, tmp32.Ref())))) }
		var tmp33 *lang.Var; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_100; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any = t.F_counts; var tmp36 *lang.Var; A_arbace_a2g_world_A_Init(); tmp36 = A_arbace_a2g_world_A_const_104; var tmp37 any = jrt.NN(tmp36).GetRawRoot__O(); var tmp38 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp38 = A_arbace_a2g_world_A_const_106; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Var; A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_101; tmp34.Invoke_O_O_O_O__O(tmp35, tmp37, tmp39, jrt.NN(tmp40).GetRawRoot__O())
		var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_91; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_66; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_New_O(k__4); var tmp46 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_Init(); tmp46 = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class; return tmp42.Invoke_O__O(tmp44.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil), ms__1)) }
//line :128:1
	default:}; var k__4_2 any; var tmp47 *lang.Var;








	A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_87; k__4_2 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(vf__2); var i__5 any; var tmp48 /*line :128:1*/*lang.Var;









	A_arbace_a2g_world_A_Init(); tmp48 = A_arbace_a2g_world_A_const_31; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_a2g_world_A_Init(); tmp50 = A_arbace_a2g_world_A_const_107; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_New_O(k__4_2); var tmp53 *jrt.Class; A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_Init(); tmp53 = A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class; i__5 = tmp49.Invoke_O__O(tmp51.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil), ms__1)); if
	jrt.A2g_Truth(i__5) { } else { var tmp54 *lang.Var; A_arbace_a2g_world_A_Init(); tmp54 = A_arbace_a2g_world_A_const_88; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_201, nil); var tmp57 *lang.Var; A_arbace_a2g_world_A_Init(); tmp57 = A_arbace_a2g_world_A_const_90; var tmp58 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp56, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var tmp59 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp59 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp55.Invoke_O_O__O(tmp58, tmp59.Ref())))) }; var tmp60 /*line :140:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp60 = A_arbace_a2g_world_A_const_100; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 any = t.F_counts; var tmp63 *lang.Var; A_arbace_a2g_world_A_Init(); tmp63 = A_arbace_a2g_world_A_const_104; var tmp64 any = jrt.NN(tmp63).GetRawRoot__O(); var tmp65 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp65 = A_arbace_a2g_world_A_const_108; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_a2g_world_A_Init(); tmp67 = A_arbace_a2g_world_A_const_101; tmp61.Invoke_O_O_O_O__O(tmp62, tmp64, tmp66, jrt.NN(tmp67).GetRawRoot__O()); var tmp68 /*line :141:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp68 = A_arbace_a2g_world_A_const_99; return lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O_O_O__O(ms__1, i__5, vf__2) }
//line :132:1
func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A{}; t.Ctor_O(p0); return t }
//line :132:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :132:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Invoke_O_O__O(self, p1__1607000122_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__1607000122_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :135:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Invoke_O_O__O(self, p1__1607000123_SHARP___1 any) any { var tmp1 any = t.F_k; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__1607000123_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :138:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_87; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(m__2)) { return i__1 } else { return nil } }






func A_arbace_a2g_world_apply_variant_fn__1607000138_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_apply_variant_fn__1607000138_A { A_arbace_a2g_world_apply_variant_fn__1607000138_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000138_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_72; if lang.Util_Equiv_O_O__Z(Lit_206, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(m__1)) { var nn__2 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_207, nil); var tmp3 any = t.F_prefix; var tmp4 *lang.Var
		A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_30; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_45; nn__2 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(m__1)))).Ref()
//line :146:1
		var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__1607000139__4 any; var tmp7 *lang.Var


		A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_109; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var or__1927000174__auto____4 any = vfs__3; if jrt.A2g_Truth(or__1927000174__auto____4) { tmp9 = or__1927000174__auto____4 } else { lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY.Ref() }; vec__1607000139__4 = tmp8.Invoke_O_O_O_O_O__O(m__1, tmp9, nn__2, t.F_variants_of, t.F_applied)
//line :146:1
		var m2__5 any = lang.RT_Nth_O_I_O__O(vec__1607000139__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1607000139__4, lang.RT_IntCast_J__I(1), nil)



		if jrt.A2g_Truth(vfs__3) { var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_100; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_applied; var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_99; tmp11.Invoke_O_O_O_O__O(tmp12, jrt.NN(tmp13).GetRawRoot__O(), nn__2, c__6) }
//line :146:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_a2g_world_read_variants_A_New() *A_arbace_a2g_world_read_variants_A { A_arbace_a2g_world_read_variants_A_Init(); t := &A_arbace_a2g_world_read_variants_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_a2g_world_read_variants_A) Ctor() {}
//line :157:1
func (t *A_arbace_a2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_read_variants_fn__1607000144_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_world_read_variants_fn__1607000144_A_Init(); tmp4 = A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O_O__O(tmp5, tmp6.Ref(), files__0) }
//line :163:1
func A_arbace_a2g_world_read_variants_fn__1607000144_A_New() *A_arbace_a2g_world_read_variants_fn__1607000144_A { A_arbace_a2g_world_read_variants_fn__1607000144_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000144_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any; var tmp1 *lang.Var;
													A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_69; forms__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__2); var nsname__4 any; var tmp2 /*line :163:1*/*lang.Var;

	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_113; nsname__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(forms__3); var tmp3 /*line :166:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_96; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_New_O(nsname__4); var tmp6 *jrt.Class; A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_Init(); tmp6 = A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), acc__1, forms__3) }
//line :166:1
func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_New_O(p0 any) *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A { A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :166:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var
	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(fm__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_72; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_297, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :167:1
	if jrt.A2g_Truth(tmp1) { var vec__1607000146__3 any = fm__2; var seq__1607000147__4 any; var tmp4 *lang.Var

		A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_32; seq__1607000147__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(vec__1607000146__3)
//line :167:1
		var first__1607000148__5 any; var tmp5 *lang.Var

		A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_31; first__1607000148__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1607000147__4)
//line :167:1
		var seq__1607000147__6 any; var tmp6 *lang.Var

		A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_47; seq__1607000147__6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__1607000147__4)
//line :167:1
		var ___7 any = first__1607000148__5; var first__1607000148__8 any; var tmp7 *lang.Var; _ = ___7

		A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; first__1607000148__8 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1607000147__6)
//line :167:1
		var seq__1607000147__9 any; var tmp8 *lang.Var

		A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_47; seq__1607000147__9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1607000147__6)
//line :167:1
		var cls__10 any = first__1607000148__8; var members__11 any = seq__1607000147__9; var n__12 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_298, nil); var tmp10 *lang.Var


		A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_53; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_56; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_30; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_299, Lit_298); var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_30; n__12 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp15, nil, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(cls__10))).Ref()
		var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_104; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_114; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_115; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.PersistentVector; lang.PersistentVector_Init(); tmp23 = lang.PersistentVector_EMPTY; return tmp18.Invoke_O_O_O_O__O(acc__1, n__12, tmp20.Invoke_O_O__O(tmp22, tmp23.Ref()), members__11) } else {
//line :167:1
			var tmp24 any; var and__1927000168__auto____3_2 any; var tmp25 *lang.Var




			A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____3_2 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(fm__2); if jrt.A2g_Truth(and__1927000168__auto____3_2) { var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_72; tmp24 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_124, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp24 = and__1927000168__auto____3_2 }
//line :167:1
			if jrt.A2g_Truth(tmp24) {





				var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_104; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_116; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_114; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_115; var tmp34 any = jrt.NN(tmp33).GetRawRoot__O(); var tmp35 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp35 = lang.PersistentHashSet_EMPTY; var tmp36 any = tmp32.Invoke_O_O__O(tmp34, tmp35.Ref()); var tmp37 *lang.Var; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_63; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_50; var tmp40 any = jrt.NN(tmp39).GetRawRoot__O(); var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_42; return tmp28.Invoke_O_O_O_O__O(acc__1, tmp30, tmp36, tmp38.Invoke_O_O__O(tmp40, lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(fm__2))) } else {
//line :167:1
					var tmp42 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp42 = A_arbace_a2g_world_A_const_55; if tmp42 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_a2g_world_new_unit_A_New() *A_arbace_a2g_world_new_unit_A { A_arbace_a2g_world_new_unit_A_Init(); t := &A_arbace_a2g_world_new_unit_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_a2g_world_new_unit_A) Ctor() {}
//line :178:1
func (t *A_arbace_a2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_117; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_95; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_118; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_95; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_119; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_95; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp17 = lang.PersistentArrayMap_EMPTY; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_120; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_95; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_121; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_95; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp29 = lang.PersistentHashSet_EMPTY; var tmp30 any = tmp28.Invoke_O__O(tmp29.Ref()); var tmp31 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_122; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Var; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_95; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp35 = lang.PersistentArrayMap_EMPTY; var tmp36 any = tmp34.Invoke_O__O(tmp35.Ref()); var tmp37 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_123; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Var; A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_95; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp41 = lang.PersistentArrayMap_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp6, tmp8, tmp12, tmp14, tmp18, tmp20, tmp24, tmp26, tmp30, tmp32, tmp36, tmp38, tmp40.Invoke_O__O(tmp41.Ref()))) }








func A_arbace_a2g_world_id_space_A_New() *A_arbace_a2g_world_id_space_A { A_arbace_a2g_world_id_space_A_Init(); t := &A_arbace_a2g_world_id_space_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_a2g_world_id_space_A) Ctor() {}
//line :187:1
func (t *A_arbace_a2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	{ var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_93; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.Class; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_124; tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(tmp3.Invoke_O__O(tmp4.Ref()))).GetField_String__Field(Lit_223)).Get_O__O(nil) }
//line :187:1
	return nil }(); if tmp5 != nil { if true { var ___3 jrt.Throwable_I = tmp5; _ = ___3; tmp1 = nil } }; return tmp1 }




func A_arbace_a2g_world_load_world_A_New() *A_arbace_a2g_world_load_world_A { A_arbace_a2g_world_load_world_A_Init(); t := &A_arbace_a2g_world_load_world_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_a2g_world_load_world_A) Ctor() {}
//line :192:1
func (t *A_arbace_a2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__1607000155__1 any) any { var map__1607000156__3 any = p__1607000155__1; var map__1607000156__4 any; if lang.ISeq_InstanceOf(map__1607000156__3) { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_58; map__1607000156__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1607000156__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; map__1607000156__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1607000156__3) } else { lang.PersistentArrayMap_Init(); map__1607000156__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000156__4 = map__1607000156__3 }; var variant_files__5 any; var tmp5 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_125; variant_files__5 = lang.RT_Get_O_O__O(map__1607000156__4, tmp5.Ref()); var variants__6 any; var tmp6 *lang.Var;





	A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_126; variants__6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(variant_files__5); var erased__7 any; var tmp7 /*line :192:1*/*lang.Keyword;






	A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_116; var tmp8 any = tmp7.Ref(); var tmp9 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp9 = lang.PersistentHashSet_EMPTY; erased__7 = lang.RT_Get_O_O_O__O(variants__6, tmp8, tmp9.Ref()); var variants__8 any; var tmp10 /*line :192:1*/*lang.Var;







	A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_127; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_116; variants__8 = tmp11.Invoke_O_O__O(variants__6, tmp12.Ref()); var applied__9 any; var tmp13 /*line :192:1*/*lang.Var;








	A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_95; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; applied__9 = tmp14.Invoke_O__O(tmp15.Ref()); var files__10 any; var tmp16 /*line :192:1*/*lang.Var;









	A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_91; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_92; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_141; files__10 = tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(jrt.NN(tmp20).GetRawRoot__O(), inputs__0)); var parsed__11 any; var tmp21 /*line :192:1*/*lang.Var;











	A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_128; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_142; var tmp24 any = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke__O(); var tmp25 any = A_arbace_a2g_world_load_world_fn__1607000158_A_New(); var tmp26 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000158_A_Init(); tmp26 = A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class; parsed__11 = tmp22.Invoke_O_O_O__O(tmp24, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), files__10); var tops__12 any; var tmp27 /*line :192:1*/*lang.Var;












	A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_129; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_92; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_a2g_world_load_world_fn__1607000161_A_New(); var tmp32 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000161_A_Init(); tmp32 = A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class; tops__12 = tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), parsed__11)); var top_of__13 any; var tmp33 any = /*line :192:1*/A_arbace_a2g_world_load_world_top_of__1607000165_A_New(); var tmp34 *jrt.Class;













	A_arbace_a2g_world_load_world_top_of__1607000165_A_Init(); tmp34 = A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class; top_of__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var from_source__14 any; var tmp35 any = /*line :192:1*/A_arbace_a2g_world_load_world_from_source__1607000167_A_New_O_O(tops__12, top_of__13); var tmp36 *jrt.Class;














	A_arbace_a2g_world_load_world_from_source__1607000167_A_Init(); tmp36 = A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class; from_source__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); var cs__15 any; var tmp37 /*line :192:1*/*lang.Var;















	A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_95; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp39 = lang.PersistentArrayMap_EMPTY; cs__15 = tmp38.Invoke_O__O(tmp39.Ref()); var unit__16 any; var tmp40 /*line :192:1*/*lang.Var;
















	A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_132; unit__16 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke__O(); var failed__17 any; var tmp41 /*line :192:1*/*lang.Var;

















	A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_95; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.PersistentVector; lang.PersistentVector_Init(); tmp43 = lang.PersistentVector_EMPTY; failed__17 = tmp42.Invoke_O__O(tmp43.Ref()); var tmp44 /*line :211:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp44 = A_arbace_a2g_world_A_const_19; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_a2g_world_A_Init(); tmp46 = A_arbace_a2g_world_A_const_20; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_a2g_world_A_Init(); tmp48 = A_arbace_a2g_world_A_const_187; var tmp49 any = tmp48.Ref(); var tmp50 *lang.Var; A_arbace_a2g_world_A_Init(); tmp50 = A_arbace_a2g_world_A_const_188; var tmp51 any = tmp50.Ref(); var tmp52 *lang.Var; A_arbace_a2g_world_A_Init(); tmp52 = A_arbace_a2g_world_A_const_189; tmp45.Invoke_O__O(tmp47.Invoke_O_O_O_O_O_O__O(tmp49, cs__15, tmp51, unit__16, tmp52.Ref(), from_source__14)); var tmp53 any = A_arbace_a2g_world_load_world_fn__1607000169_A_New_O_O_O_O_O(parsed__11, variants__8, failed__17, applied__9, unit__16); var tmp54 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_A_Init(); tmp54 = A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O(); var seq_1607000316__18 any; var tmp55 /*line :192:1*/*lang.Var;












































































































	A_arbace_a2g_world_A_Init(); tmp55 = A_arbace_a2g_world_A_const_32; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_a2g_world_A_Init(); tmp57 = A_arbace_a2g_world_A_const_190; seq_1607000316__18 = tmp56.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(variants__8)); var chunk_1607000317__19 any; var count_1607000318__20 int64 = 0; var i_1607000319__21 int64 = 0; L1:
//line :192:1
	for {












































































































		if lang.Numbers_Lt_J_J__Z(i_1607000319__21, count_1607000318__20) { var n__22 any = lang.Indexed_Cast(chunk_1607000317__19).Nth_I__O(lang.RT_IntCast_J__I(i_1607000319__21)); var tmp58 *lang.Var; A_arbace_a2g_world_A_Init(); tmp58 = A_arbace_a2g_world_A_const_167; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_a2g_world_A_Init(); tmp60 = A_arbace_a2g_world_A_const_131; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_a2g_world_A_Init(); tmp62 = A_arbace_a2g_world_A_const_12; if jrt.A2g_Truth(tmp59.Invoke_O__O(tmp61.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(applied__9), n__22))) {
			var tmp63 *lang.Var; A_arbace_a2g_world_A_Init(); tmp63 = A_arbace_a2g_world_A_const_100; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_a2g_world_A_Init(); tmp65 = A_arbace_a2g_world_A_const_13; tmp64.Invoke_O_O_O__O(failed__17, jrt.NN(tmp65).GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__22, Lit_225))
//line :301:1
			seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, lang.Numbers_Unchecked_inc_J__J(i_1607000319__21); continue L1 } else { seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, lang.Numbers_Unchecked_inc_J__J(i_1607000319__21); continue L1 } } else { var temp__1927000414__auto____22 any; var tmp66 *lang.Var; A_arbace_a2g_world_A_Init(); tmp66 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____22 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq_1607000316__18); if jrt.A2g_Truth(temp__1927000414__auto____22) { var seq_1607000316__23 any = temp__1927000414__auto____22; var tmp67 *lang.Var; A_arbace_a2g_world_A_Init(); tmp67 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23)) { var c__1927000678__auto____24 any; var tmp68 *lang.Var; A_arbace_a2g_world_A_Init(); tmp68 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____24 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23); var tmp69 *lang.Var; A_arbace_a2g_world_A_Init(); tmp69 = A_arbace_a2g_world_A_const_41; seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), c__1927000678__auto____24, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__24 any; var tmp70 *lang.Var; A_arbace_a2g_world_A_Init(); tmp70 = A_arbace_a2g_world_A_const_31; n__24 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23); var tmp71 *lang.Var; A_arbace_a2g_world_A_Init(); tmp71 = A_arbace_a2g_world_A_const_167; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_a2g_world_A_Init(); tmp73 = A_arbace_a2g_world_A_const_131; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_a2g_world_A_Init(); tmp75 = A_arbace_a2g_world_A_const_12; if jrt.A2g_Truth(tmp72.Invoke_O__O(tmp74.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(applied__9), n__24))) {
				var tmp76 *lang.Var; A_arbace_a2g_world_A_Init(); tmp76 = A_arbace_a2g_world_A_const_100; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 *lang.Var; A_arbace_a2g_world_A_Init(); tmp78 = A_arbace_a2g_world_A_const_13; tmp77.Invoke_O_O_O__O(failed__17, jrt.NN(tmp78).GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__24, Lit_225))
//line :301:1
				var tmp79 *lang.Var; A_arbace_a2g_world_A_Init(); tmp79 = A_arbace_a2g_world_A_const_47; seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), nil, 0, 0; continue L1 } else { var tmp80 *lang.Var; A_arbace_a2g_world_A_Init(); tmp80 = A_arbace_a2g_world_A_const_47; seq_1607000316__18, chunk_1607000317__19, count_1607000318__20, i_1607000319__21 = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_1607000316__23), nil, 0, 0; continue L1 } } } }
//line :192:1
		break L1 }; var tmp81 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp81 = A_arbace_a2g_world_A_const_133; var tmp82 any = tmp81.Ref(); var tmp83 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp83 = A_arbace_a2g_world_A_const_134; var tmp84 any = tmp83.Ref(); var tmp85 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp85 = A_arbace_a2g_world_A_const_135; var tmp86 any = tmp85.Ref(); var tmp87 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp87 = A_arbace_a2g_world_A_const_62; var tmp88 any = tmp87.Ref(); var tmp89 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp89 = A_arbace_a2g_world_A_const_136; var tmp90 any = tmp89.Ref(); var tmp91 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp91 = A_arbace_a2g_world_A_const_137; var tmp92 any = tmp91.Ref(); var tmp93 *lang.Var; A_arbace_a2g_world_A_Init(); tmp93 = A_arbace_a2g_world_A_const_115; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp95 = lang.PersistentArrayMap_EMPTY; var tmp96 any = tmp95.Ref(); var tmp97 any; var iter__1927001039__auto____18 any; var tmp98 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_New(); var tmp99 *jrt.Class;
















































































































	A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_Init(); tmp99 = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil); tmp97 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(parsed__11); var tmp100 any = /*line :192:1*/tmp94.Invoke_O_O__O(tmp96, tmp97); var tmp101 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp101 = A_arbace_a2g_world_A_const_138; var tmp102 any = tmp101.Ref(); var tmp103 *lang.Var; A_arbace_a2g_world_A_Init(); tmp103 = A_arbace_a2g_world_A_const_91; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.Var; A_arbace_a2g_world_A_Init(); tmp105 = A_arbace_a2g_world_A_const_64; var tmp106 lang.IFn = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()); var tmp107 *lang.Var; A_arbace_a2g_world_A_Init(); tmp107 = A_arbace_a2g_world_A_const_191; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Var; A_arbace_a2g_world_A_Init(); tmp109 = A_arbace_a2g_world_A_const_31; var tmp110 any = jrt.NN(tmp109).GetRawRoot__O(); var tmp111 *lang.Var; A_arbace_a2g_world_A_Init(); tmp111 = A_arbace_a2g_world_A_const_45; var tmp112 any = tmp108.Invoke_O_O__O(tmp110, jrt.NN(tmp111).GetRawRoot__O()); var tmp113 *lang.Var; A_arbace_a2g_world_A_Init(); tmp113 = A_arbace_a2g_world_A_const_12; var tmp114 any = tmp104.Invoke_O__O(tmp106.Invoke_O_O__O(tmp112, lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()).Invoke_O__O(failed__17))); var tmp115 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp115 = A_arbace_a2g_world_A_const_139; var tmp116 any = tmp115.Ref(); var tmp117 *lang.Var; A_arbace_a2g_world_A_Init(); tmp117 = A_arbace_a2g_world_A_const_12; var tmp118 any = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(applied__9); var tmp119 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp119 = A_arbace_a2g_world_A_const_140; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, cs__15, tmp84, unit__16, tmp86, from_source__14, tmp88, files__10, tmp90, tops__12, tmp92, tmp100, tmp102, tmp114, tmp116, tmp118, tmp119.Ref(), erased__7)) }











func A_arbace_a2g_world_load_world_fn__1607000158_A_New() *A_arbace_a2g_world_load_world_fn__1607000158_A { A_arbace_a2g_world_load_world_fn__1607000158_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000158_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Ctor() {}
//line :204:1
func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_69; forms__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__1); var tmp2 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_143; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_144; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_145; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_113; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, f__1, tmp5, forms__2, tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(forms__2))) }
func A_arbace_a2g_world_load_world_fn__1607000161_A_New() *A_arbace_a2g_world_load_world_fn__1607000161_A { A_arbace_a2g_world_load_world_fn__1607000161_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000161_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Ctor() {}
//line :205:1
func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Invoke_O_O__O(self, p__1607000160__1 any) any { var map__1607000162__2 any = p__1607000160__1; var map__1607000162__3 any; if lang.ISeq_InstanceOf(map__1607000162__2) { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1607000162__2)) { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_58; map__1607000162__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1607000162__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1607000162__2)) { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_31; map__1607000162__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1607000162__2) } else { lang.PersistentArrayMap_Init(); map__1607000162__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000162__3 = map__1607000162__2 }; var ns__4 any; var tmp5 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_145; ns__4 = lang.RT_Get_O_O__O(map__1607000162__3, tmp5.Ref()); var forms__5 any; var tmp6 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_144; forms__5 = lang.RT_Get_O_O__O(map__1607000162__3, tmp6.Ref()); if jrt.A2g_Truth(ns__4) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_146; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(ns__4, forms__5) } else { return nil } }
func A_arbace_a2g_world_load_world_top_of__1607000165_A_New() *A_arbace_a2g_world_load_world_top_of__1607000165_A { A_arbace_a2g_world_load_world_top_of__1607000165_A_Init(); t := &A_arbace_a2g_world_load_world_top_of__1607000165_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Ctor() {}
//line :206:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_207); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__1 } else { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_130; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_85; var tmp4 any = tmp3; return tmp2.Invoke_O_O_O__O(n__1, tmp4, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }
func A_arbace_a2g_world_load_world_from_source__1607000167_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_from_source__1607000167_A { A_arbace_a2g_world_load_world_from_source__1607000167_A_Init(); t := &A_arbace_a2g_world_load_world_from_source__1607000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :207:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_131; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_tops; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1)) }



func A_arbace_a2g_world_load_world_fn__1607000169_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000169_A { A_arbace_a2g_world_load_world_fn__1607000169_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :211:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Ctor_O_O_O_O_O(c__parsed, c__variants, c__failed, c__applied, c__unit any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied; t.F_unit = c__unit }
//line :211:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Invoke_O__O(self any) any { var tmp1 any; tmp187 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any; var tmp2 *lang.Var






	A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_149; temp__1927000414__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke__O(); if jrt.A2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3; var tmp3 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(space__4); var tmp4 *lang.Var
		A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_150; tmp3.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(jrt.NN(tmp4).GetRawRoot__O()))) }
//line :211:1
	var seq_1607000170__3 any; var tmp5 *lang.Var








	A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; var t_ any = t.F_parsed; t.F_parsed = nil; tmp7 = t_; seq_1607000170__3 = tmp6.Invoke_O__O(tmp7)
//line :211:1
	var chunk_1607000171__4 any; var count_1607000172__5 int64 = 0; var i_1607000173__6 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z(i_1607000173__6, count_1607000172__5) { var map__1607000174__7 any = lang.Indexed_Cast(chunk_1607000171__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000173__6)); var map__1607000174__8 any; if lang.ISeq_InstanceOf(map__1607000174__7) { var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(map__1607000174__7)) { var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_58; map__1607000174__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__1607000174__7), jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__1607000174__7)) { var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_31; map__1607000174__8 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(map__1607000174__7) } else { lang.PersistentArrayMap_Init(); map__1607000174__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000174__8 = map__1607000174__7 }; var file__9 any; var tmp12 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_143; file__9 = lang.RT_Get_O_O__O(map__1607000174__8, tmp12.Ref()); var forms__10 any; var tmp13 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_144; forms__10 = lang.RT_Get_O_O__O(map__1607000174__8, tmp13.Ref()); var ns__11 any; var tmp14 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_145; ns__11 = lang.RT_Get_O_O__O(map__1607000174__8, tmp14.Ref()); if jrt.A2g_Truth(ns__11) {
			var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_19; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_20; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_151; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_151; tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp20, jrt.NN(tmp21).Get__O())); var tmp22 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_New_O_O_O_O_O_O(forms__10, t.F_variants, t.F_failed, file__9, t.F_applied, ns__11); var tmp23 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_Init(); tmp23 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil).Invoke__O()
//line :220:1
			seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, lang.Numbers_Unchecked_inc_J__J(i_1607000173__6); continue L1 } else { seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, lang.Numbers_Unchecked_inc_J__J(i_1607000173__6); continue L1 } } else { var temp__1927000414__auto____7 any; var tmp24 *lang.Var; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_1607000170__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000170__8 any = temp__1927000414__auto____7; var tmp25 *lang.Var; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8)) { var c__1927000678__auto____9 any; var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8); var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_41; seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__1607000200__9 any; var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_31; map__1607000200__9 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8); var map__1607000200__10 any; if lang.ISeq_InstanceOf(map__1607000200__9) { var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(map__1607000200__9)) { var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_58; map__1607000200__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(map__1607000200__9), jrt.Object_class.ArrayClass())).Ref() } else { var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(map__1607000200__9)) { var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_31; map__1607000200__10 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(map__1607000200__9) } else { lang.PersistentArrayMap_Init(); map__1607000200__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000200__10 = map__1607000200__9 }; var file__11 any; var tmp33 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_143; file__11 = lang.RT_Get_O_O__O(map__1607000200__10, tmp33.Ref()); var forms__12 any; var tmp34 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp34 = A_arbace_a2g_world_A_const_144; forms__12 = lang.RT_Get_O_O__O(map__1607000200__10, tmp34.Ref()); var ns__13 any; var tmp35 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_145; ns__13 = lang.RT_Get_O_O__O(map__1607000200__10, tmp35.Ref()); if jrt.A2g_Truth(ns__13) {
				var tmp36 *lang.Var; A_arbace_a2g_world_A_Init(); tmp36 = A_arbace_a2g_world_A_const_19; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_a2g_world_A_Init(); tmp38 = A_arbace_a2g_world_A_const_20; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_151; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Var; A_arbace_a2g_world_A_Init(); tmp42 = A_arbace_a2g_world_A_const_151; tmp37.Invoke_O__O(tmp39.Invoke_O_O__O(tmp41, jrt.NN(tmp42).Get__O())); var tmp43 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_New_O_O_O_O_O_O(forms__12, t.F_variants, t.F_failed, file__11, t.F_applied, ns__13); var tmp44 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_Init(); tmp44 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil).Invoke__O()
//line :220:1
				var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_47; seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), nil, 0, 0; continue L1 } else { var tmp46 *lang.Var; A_arbace_a2g_world_A_Init(); tmp46 = A_arbace_a2g_world_A_const_47; seq_1607000170__3, chunk_1607000171__4, count_1607000172__5, i_1607000173__6 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(seq_1607000170__8), nil, 0, 0; continue L1 } } } }
//line :211:1
		break L1 }; var names__3 any; var tmp47 *lang.Var


























	A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_12; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp49 = A_arbace_a2g_world_A_const_117; var tmp50 *lang.Keyword = tmp49; var tmp51 any; var t__2 any = t.F_unit; t.F_unit = nil; tmp51 = t__2; names__3 = tmp48.Invoke_O__O(jrt.NN(tmp50).Invoke_O__O(tmp51))
//line :211:1
	var t__4 any; var tmp52 *lang.Var



























	A_arbace_a2g_world_A_Init(); tmp52 = A_arbace_a2g_world_A_const_95; t__4 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref())
//line :211:1
	var laps__5 any; var tmp53 *lang.Var




























	A_arbace_a2g_world_A_Init(); tmp53 = A_arbace_a2g_world_A_const_95; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.PersistentVector; lang.PersistentVector_Init(); tmp55 = lang.PersistentVector_EMPTY; laps__5 = tmp54.Invoke_O__O(tmp55.Ref())
//line :211:1
	var lap__6 any; var tmp56 any = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_New_O_O(t__4, laps__5); var tmp57 *jrt.Class





























	A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_Init(); tmp57 = A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil)
	var tmp58 lang.IFn = lang.IFn_Cast(lap__6); var tmp59 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp59 = A_arbace_a2g_world_A_const_173; tmp58.Invoke_O__O(tmp59.Ref())
//line :211:1
	var seq_1607000228__7 any; var tmp60 *lang.Var































	A_arbace_a2g_world_A_Init(); tmp60 = A_arbace_a2g_world_A_const_32; seq_1607000228__7 = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(names__3)
//line :211:1
	var chunk_1607000229__8 any; var count_1607000230__9 int64 = 0; var i_1607000231__10 int64 = 0; L2: for {































		if lang.Numbers_Lt_J_J__Z(i_1607000231__10, count_1607000230__9) { var n__11 any = lang.Indexed_Cast(chunk_1607000229__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000231__10)); var tmp61 *lang.Var; A_arbace_a2g_world_A_Init(); tmp61 = A_arbace_a2g_world_A_const_167; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp63 = A_arbace_a2g_world_A_const_174; var tmp64 *lang.Keyword = tmp63; var tmp65 *lang.Var; A_arbace_a2g_world_A_Init(); tmp65 = A_arbace_a2g_world_A_const_156; if jrt.A2g_Truth(tmp62.Invoke_O__O(jrt.NN(tmp64).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(n__11)))) {
			var tmp66 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_New_O_O(n__11, t.F_failed); var tmp67 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_Init(); tmp67 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp66, tmp67, nil).Invoke__O()
//line :243:1
			seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, lang.Numbers_Unchecked_inc_J__J(i_1607000231__10); continue L2 } else { seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, lang.Numbers_Unchecked_inc_J__J(i_1607000231__10); continue L2 } } else { var temp__1927000414__auto____11 any; var tmp68 *lang.Var; A_arbace_a2g_world_A_Init(); tmp68 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_1607000228__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1607000228__12 any = temp__1927000414__auto____11; var tmp69 *lang.Var; A_arbace_a2g_world_A_Init(); tmp69 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12)) { var c__1927000678__auto____13 any; var tmp70 *lang.Var; A_arbace_a2g_world_A_Init(); tmp70 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12); var tmp71 *lang.Var; A_arbace_a2g_world_A_Init(); tmp71 = A_arbace_a2g_world_A_const_41; seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var n__13 any; var tmp72 *lang.Var; A_arbace_a2g_world_A_Init(); tmp72 = A_arbace_a2g_world_A_const_31; n__13 = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12); var tmp73 *lang.Var; A_arbace_a2g_world_A_Init(); tmp73 = A_arbace_a2g_world_A_const_167; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp75 = A_arbace_a2g_world_A_const_174; var tmp76 *lang.Keyword = tmp75; var tmp77 *lang.Var; A_arbace_a2g_world_A_Init(); tmp77 = A_arbace_a2g_world_A_const_156; if jrt.A2g_Truth(tmp74.Invoke_O__O(jrt.NN(tmp76).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O__O(n__13)))) {
				var tmp78 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_New_O_O(n__13, t.F_failed); var tmp79 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_Init(); tmp79 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp78, tmp79, nil).Invoke__O()
//line :243:1
				var tmp80 *lang.Var; A_arbace_a2g_world_A_Init(); tmp80 = A_arbace_a2g_world_A_const_47; seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), nil, 0, 0; continue L2 } else { var tmp81 *lang.Var; A_arbace_a2g_world_A_Init(); tmp81 = A_arbace_a2g_world_A_const_47; seq_1607000228__7, chunk_1607000229__8, count_1607000230__9, i_1607000231__10 = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(seq_1607000228__12), nil, 0, 0; continue L2 } } } }
//line :211:1
		break L2
	}
































	var tmp82 lang.IFn = lang.IFn_Cast(lap__6); var tmp83 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp83 = A_arbace_a2g_world_A_const_176; tmp82.Invoke_O__O(tmp83.Ref())
//line :211:1
	var seq_1607000236__7 any; var tmp84 *lang.Var


































	A_arbace_a2g_world_A_Init(); tmp84 = A_arbace_a2g_world_A_const_32; seq_1607000236__7 = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O__O(names__3)
//line :211:1
	var chunk_1607000237__8 any; var count_1607000238__9 int64 = 0; var i_1607000239__10 int64 = 0; L3: for {


































		if lang.Numbers_Lt_J_J__Z(i_1607000239__10, count_1607000238__9) { var n__11_2 any = lang.Indexed_Cast(chunk_1607000237__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000239__10)); var tmp85 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_New_O_O(n__11_2, t.F_failed); var tmp86 *jrt.Class
			A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_Init(); tmp86 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil).Invoke__O()
//line :246:1
			seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, lang.Numbers_Unchecked_inc_J__J(i_1607000239__10); continue L3 } else { var temp__1927000414__auto____11_2 any; var tmp87 *lang.Var; A_arbace_a2g_world_A_Init(); tmp87 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____11_2 = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke_O__O(seq_1607000236__7); if jrt.A2g_Truth(temp__1927000414__auto____11_2) { var seq_1607000236__12 any = temp__1927000414__auto____11_2; var tmp88 *lang.Var; A_arbace_a2g_world_A_Init(); tmp88 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()).Invoke_O__O(seq_1607000236__12)) { var c__1927000678__auto____13_2 any; var tmp89 *lang.Var; A_arbace_a2g_world_A_Init(); tmp89 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____13_2 = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()).Invoke_O__O(seq_1607000236__12); var tmp90 *lang.Var; A_arbace_a2g_world_A_Init(); tmp90 = A_arbace_a2g_world_A_const_41; seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(seq_1607000236__12), c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var n__13_2 any; var tmp91 *lang.Var; A_arbace_a2g_world_A_Init(); tmp91 = A_arbace_a2g_world_A_const_31; n__13_2 = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()).Invoke_O__O(seq_1607000236__12)
				var tmp92 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_New_O_O(n__13_2, t.F_failed); var tmp93 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_Init(); tmp93 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp92, tmp93, nil).Invoke__O()
//line :246:1
				var tmp94 *lang.Var; A_arbace_a2g_world_A_Init(); tmp94 = A_arbace_a2g_world_A_const_47; seq_1607000236__7, chunk_1607000237__8, count_1607000238__9, i_1607000239__10 = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()).Invoke_O__O(seq_1607000236__12), nil, 0, 0; continue L3 } } }
//line :211:1
		break L3
	}



































	var tmp95 lang.IFn = lang.IFn_Cast(lap__6); var tmp96 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp96 = A_arbace_a2g_world_A_const_178; tmp95.Invoke_O__O(tmp96.Ref())
//line :211:1
	var seq_1607000244__7 any; var tmp97 *lang.Var





































	A_arbace_a2g_world_A_Init(); tmp97 = A_arbace_a2g_world_A_const_32; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_a2g_world_A_Init(); tmp99 = A_arbace_a2g_world_A_const_179; seq_1607000244__7 = tmp98.Invoke_O__O(Up_Var_IFn(tmp99).Invoke_O__O(names__3))
//line :211:1
	var chunk_1607000245__8 any; var count_1607000246__9 int64 = 0; var i_1607000247__10 int64 = 0; L4: for {





































		if lang.Numbers_Lt_J_J__Z(i_1607000247__10, count_1607000246__9) { var n__11_3 any = lang.Indexed_Cast(chunk_1607000245__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000247__10)); var tmp100 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_New_O_O(n__11_3, t.F_failed); var tmp101 *jrt.Class
			A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_Init(); tmp101 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp100, tmp101, nil).Invoke__O()
//line :249:1
			seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, lang.Numbers_Unchecked_inc_J__J(i_1607000247__10); continue L4 } else { var temp__1927000414__auto____11_3 any; var tmp102 *lang.Var; A_arbace_a2g_world_A_Init(); tmp102 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____11_3 = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()).Invoke_O__O(seq_1607000244__7); if jrt.A2g_Truth(temp__1927000414__auto____11_3) { var seq_1607000244__12 any = temp__1927000414__auto____11_3; var tmp103 *lang.Var; A_arbace_a2g_world_A_Init(); tmp103 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()).Invoke_O__O(seq_1607000244__12)) { var c__1927000678__auto____13_3 any; var tmp104 *lang.Var; A_arbace_a2g_world_A_Init(); tmp104 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____13_3 = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()).Invoke_O__O(seq_1607000244__12); var tmp105 *lang.Var; A_arbace_a2g_world_A_Init(); tmp105 = A_arbace_a2g_world_A_const_41; seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()).Invoke_O__O(seq_1607000244__12), c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var n__13_3 any; var tmp106 *lang.Var; A_arbace_a2g_world_A_Init(); tmp106 = A_arbace_a2g_world_A_const_31; n__13_3 = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()).Invoke_O__O(seq_1607000244__12)
				var tmp107 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_New_O_O(n__13_3, t.F_failed); var tmp108 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_Init(); tmp108 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp107, tmp108, nil).Invoke__O()
//line :249:1
				var tmp109 *lang.Var; A_arbace_a2g_world_A_Init(); tmp109 = A_arbace_a2g_world_A_const_47; seq_1607000244__7, chunk_1607000245__8, count_1607000246__9, i_1607000247__10 = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke_O__O(seq_1607000244__12), nil, 0, 0; continue L4 } } }
//line :211:1
		break L4
	}






































	var tmp110 lang.IFn = lang.IFn_Cast(lap__6); var tmp111 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp111 = A_arbace_a2g_world_A_const_181; tmp110.Invoke_O__O(tmp111.Ref())
//line :211:1
	var seq_1607000252__7 any; var tmp112 *lang.Var








































	A_arbace_a2g_world_A_Init(); tmp112 = A_arbace_a2g_world_A_const_32; seq_1607000252__7 = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()).Invoke_O__O(names__3)
//line :211:1
	var chunk_1607000253__8 any; var count_1607000254__9 int64 = 0; var i_1607000255__10 int64 = 0; L5: for {








































		if lang.Numbers_Lt_J_J__Z(i_1607000255__10, count_1607000254__9) { var n__11_4 any = lang.Indexed_Cast(chunk_1607000253__8).Nth_I__O(lang.RT_IntCast_J__I(i_1607000255__10)); var tmp113 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_New_O_O(n__11_4, t.F_failed); var tmp114 *jrt.Class
			A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_Init(); tmp114 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp113, tmp114, nil).Invoke__O()
//line :252:1
			seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, lang.Numbers_Unchecked_inc_J__J(i_1607000255__10); continue L5 } else { var temp__1927000414__auto____11_4 any; var tmp115 *lang.Var; A_arbace_a2g_world_A_Init(); tmp115 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____11_4 = lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()).Invoke_O__O(seq_1607000252__7); if jrt.A2g_Truth(temp__1927000414__auto____11_4) { var seq_1607000252__12 any = temp__1927000414__auto____11_4; var tmp116 *lang.Var; A_arbace_a2g_world_A_Init(); tmp116 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()).Invoke_O__O(seq_1607000252__12)) { var c__1927000678__auto____13_4 any; var tmp117 *lang.Var; A_arbace_a2g_world_A_Init(); tmp117 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____13_4 = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(seq_1607000252__12); var tmp118 *lang.Var; A_arbace_a2g_world_A_Init(); tmp118 = A_arbace_a2g_world_A_const_41; seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()).Invoke_O__O(seq_1607000252__12), c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var n__13_4 any; var tmp119 *lang.Var; A_arbace_a2g_world_A_Init(); tmp119 = A_arbace_a2g_world_A_const_31; n__13_4 = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke_O__O(seq_1607000252__12)
				var tmp120 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_New_O_O(n__13_4, t.F_failed); var tmp121 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_Init(); tmp121 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp120, tmp121, nil).Invoke__O()
//line :252:1
				var tmp122 *lang.Var; A_arbace_a2g_world_A_Init(); tmp122 = A_arbace_a2g_world_A_const_47; seq_1607000252__7, chunk_1607000253__8, count_1607000254__9, i_1607000255__10 = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()).Invoke_O__O(seq_1607000252__12), nil, 0, 0; continue L5 } } }
//line :211:1
		break L5 }; var analyze_BANG___7 any; var tmp123 any = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_New_O(t.F_failed); var tmp124 *jrt.Class














































	A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_Init(); tmp124 = A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class; analyze_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp123, tmp124, nil)
//line :211:1
	var compiled_QMARK___8 any; var tmp125 any = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_New(); var tmp126 *jrt.Class

























































	A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_Init(); tmp126 = A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class; compiled_QMARK___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp125, tmp126, nil)
//line :211:1
	var rt_space__9 any; var G__1607000265__9_ any; var tmp127 *lang.Var


























































	A_arbace_a2g_world_A_Init(); tmp127 = A_arbace_a2g_world_A_const_149; G__1607000265__9_ = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()).Invoke__O(); if lang.Util_Identical_O_O__Z(G__1607000265__9_, nil) { rt_space__9 = nil } else { rt_space__9 = jrt.ThreadLocal_Cast(G__1607000265__9_).Get__O() }
//line :211:1
	var runtime__10 any




























































	if jrt.A2g_Truth(rt_space__9) {
		var tmp128 *lang.Var; A_arbace_a2g_world_A_Init(); tmp128 = A_arbace_a2g_world_A_const_172; var tmp129 lang.IFn = lang.IFn_Cast(jrt.NN(tmp128).GetRawRoot__O()); var tmp130 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_New_O_O_O_O(rt_space__9, names__3, compiled_QMARK___8, analyze_BANG___7); var tmp131 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_Init(); tmp131 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class; runtime__10 = tmp129.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp130, tmp131, nil)) } else {



			var tmp132 *lang.Var; A_arbace_a2g_world_A_Init(); tmp132 = A_arbace_a2g_world_A_const_183; var tmp133 lang.IFn = lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()); var tmp134 *lang.Var; A_arbace_a2g_world_A_Init(); tmp134 = A_arbace_a2g_world_A_const_66; tmp133.Invoke_O_O__O(analyze_BANG___7, lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()).Invoke_O_O__O(compiled_QMARK___8, names__3))
//line :272:1
			runtime__10 = nil }
//line :211:1
	var names__11 any; var tmp135 *lang.Var


































































	A_arbace_a2g_world_A_Init(); tmp135 = A_arbace_a2g_world_A_const_46; names__11 = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O_O__O(compiled_QMARK___8, names__3)
//line :211:1
	var tops_QMARK___12 any; var tmp136 any = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_New(); var tmp137 *jrt.Class








































































	A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_Init(); tmp137 = A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class; tops_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp136, tmp137, nil)
//line :211:1
	var groups__13 any; var tmp138 *lang.Var









































































	A_arbace_a2g_world_A_Init(); tmp138 = A_arbace_a2g_world_A_const_91; var tmp139 lang.IFn = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()); var tmp140 *lang.Var; A_arbace_a2g_world_A_Init(); tmp140 = A_arbace_a2g_world_A_const_43; var tmp141 lang.IFn = lang.IFn_Cast(jrt.NN(tmp140).GetRawRoot__O()); var tmp142 any; var iter__1927001039__auto____13 any; var tmp143 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_New_O(tops_QMARK___12); var tmp144 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_Init(); tmp144 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp143, tmp144, nil); tmp142 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(names__11); groups__13 = tmp139.Invoke_O__O(tmp141.Invoke_O__O(tmp142))
//line :211:1
	var top_groups__14 any; var tmp145 *lang.Var










































































	A_arbace_a2g_world_A_Init(); tmp145 = A_arbace_a2g_world_A_const_91; var tmp146 lang.IFn = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()); var tmp147 any; var iter__1927001039__auto____14 any; var tmp148 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_New_O(tops_QMARK___12); var tmp149 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_Init(); tmp149 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp148, tmp149, nil); tmp147 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(names__11); top_groups__14 = tmp146.Invoke_O__O(tmp147)
//line :211:1
	var temp__1927000408__auto____15 any; var tmp150 *lang.Var











































































	A_arbace_a2g_world_A_Init(); tmp150 = A_arbace_a2g_world_A_const_149; temp__1927000408__auto____15 = lang.IFn_Cast(jrt.NN(tmp150).GetRawRoot__O()).Invoke__O(); if jrt.A2g_Truth(temp__1927000408__auto____15) { var space__16 any = temp__1927000408__auto____15; var seq_1607000290__17 any; var tmp151 *lang.Var
		A_arbace_a2g_world_A_Init(); tmp151 = A_arbace_a2g_world_A_const_32; seq_1607000290__17 = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(groups__13, top_groups__14))
//line :287:1
		var chunk_1607000291__18 any; var count_1607000292__19 int64 = 0; var i_1607000293__20 int64 = 0; L6: for {
			if lang.Numbers_Lt_J_J__Z(i_1607000293__20, count_1607000292__19) { var gs__21 any = lang.Indexed_Cast(chunk_1607000291__18).Nth_I__O(lang.RT_IntCast_J__I(i_1607000293__20)); var tmp152 *lang.Var
				A_arbace_a2g_world_A_Init(); tmp152 = A_arbace_a2g_world_A_const_128; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Var; A_arbace_a2g_world_A_Init(); tmp154 = A_arbace_a2g_world_A_const_142; var tmp155 any = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()).Invoke__O(); var tmp156 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_New_O_O(analyze_BANG___7, space__16); var tmp157 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_Init(); tmp157 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class; tmp153.Invoke_O_O_O__O(tmp155, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp156, tmp157, nil), gs__21)
//line :288:1
				seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, lang.Numbers_Unchecked_inc_J__J(i_1607000293__20); continue L6 } else { var temp__1927000414__auto____21 any; var tmp158 *lang.Var; A_arbace_a2g_world_A_Init(); tmp158 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____21 = lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()).Invoke_O__O(seq_1607000290__17); if jrt.A2g_Truth(temp__1927000414__auto____21) { var seq_1607000290__22 any = temp__1927000414__auto____21; var tmp159 *lang.Var; A_arbace_a2g_world_A_Init(); tmp159 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O__O(seq_1607000290__22)) { var c__1927000678__auto____23 any; var tmp160 *lang.Var; A_arbace_a2g_world_A_Init(); tmp160 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____23 = lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()).Invoke_O__O(seq_1607000290__22); var tmp161 *lang.Var; A_arbace_a2g_world_A_Init(); tmp161 = A_arbace_a2g_world_A_const_41; seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(seq_1607000290__22), c__1927000678__auto____23, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var gs__23 any; var tmp162 *lang.Var; A_arbace_a2g_world_A_Init(); tmp162 = A_arbace_a2g_world_A_const_31; gs__23 = lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()).Invoke_O__O(seq_1607000290__22)
					var tmp163 *lang.Var; A_arbace_a2g_world_A_Init(); tmp163 = A_arbace_a2g_world_A_const_128; var tmp164 lang.IFn = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()); var tmp165 *lang.Var; A_arbace_a2g_world_A_Init(); tmp165 = A_arbace_a2g_world_A_const_142; var tmp166 any = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()).Invoke__O(); var tmp167 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_New_O_O(analyze_BANG___7, space__16); var tmp168 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_Init(); tmp168 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class; tmp164.Invoke_O_O_O__O(tmp166, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp167, tmp168, nil), gs__23)
//line :288:1
					var tmp169 *lang.Var; A_arbace_a2g_world_A_Init(); tmp169 = A_arbace_a2g_world_A_const_47; seq_1607000290__17, chunk_1607000291__18, count_1607000292__19, i_1607000293__20 = lang.IFn_Cast(jrt.NN(tmp169).GetRawRoot__O()).Invoke_O__O(seq_1607000290__22), nil, 0, 0; continue L6 } } }
//line :287:1
			break L6 } } else {







				var tmp170 *lang.Var; A_arbace_a2g_world_A_Init(); tmp170 = A_arbace_a2g_world_A_const_183; lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()).Invoke_O_O__O(analyze_BANG___7, names__11) }
	var tmp171 lang.IFn = lang.IFn_Cast(lap__6); var tmp172 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp172 = A_arbace_a2g_world_A_const_184; tmp171.Invoke_O__O(tmp172.Ref())
//line :211:1
	var G__1607000298__15_ any = runtime__10





















































































	if lang.Util_Identical_O_O__Z(G__1607000298__15_, nil) { } else { var tmp173 *lang.Var; A_arbace_a2g_world_A_Init(); tmp173 = A_arbace_a2g_world_A_const_12; lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()).Invoke_O__O(G__1607000298__15_) }
//line :211:1
	var temp__1927000414__auto____15 any; var tmp174 *lang.Var






















































































	A_arbace_a2g_world_A_Init(); tmp174 = A_arbace_a2g_world_A_const_149; temp__1927000414__auto____15 = lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()).Invoke__O(); if jrt.A2g_Truth(temp__1927000414__auto____15) { var space__16_2 any = temp__1927000414__auto____15; jrt.ThreadLocal_Cast(space__16_2).Remove__V() }
	var tmp175 lang.IFn = lang.IFn_Cast(lap__6); var tmp176 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp176 = A_arbace_a2g_world_A_const_185; tmp175.Invoke_O__O(tmp176.Ref())
	var tmp177 *lang.Var; A_arbace_a2g_world_A_Init(); tmp177 = A_arbace_a2g_world_A_const_148; var tmp178 lang.IFn = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()); var tmp179 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_229, nil); var tmp180 *lang.Var; A_arbace_a2g_world_A_Init(); tmp180 = A_arbace_a2g_world_A_const_186; var tmp181 lang.IFn = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()); var tmp182 any; var iter__1927001039__auto____9 any; var tmp183 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_New(); var tmp184 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_Init(); tmp184 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp183, tmp184, nil); var tmp185 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp186 *lang.Var; A_arbace_a2g_world_A_Init(); tmp186 = A_arbace_a2g_world_A_const_12; tmp182 = tmp185.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp186).GetRawRoot__O()).Invoke_O__O(laps__5)); tmp1 = tmp178.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp179, jrt.RefArrayOf(jrt.Object_class, nil, tmp181.Invoke_O_O__O(Lit_230, tmp182))).Ref()) }; return nil }(); var tmp188 /*line :211:1*/*lang.Var; A_arbace_a2g_world_A_Init(); tmp188 = A_arbace_a2g_world_A_const_18; lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()).Invoke__O(); if tmp187 != nil { panic(tmp187) }; return tmp1 }









func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Ctor_O_O_O_O_O_O(c__forms, c__variants, c__failed, c__file, c__applied, c__ns any) { t.F_forms = c__forms; t.F_variants = c__variants; t.F_failed = c__failed; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Invoke_O__O(self any) any { var tmp1 any; tmp48 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000177__3 any; var tmp2 *lang.Var
													A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_32; seq_1607000177__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_forms)
//line :221:1
	var chunk_1607000178__4 any; var count_1607000179__5 int64 = 0; var i_1607000180__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1607000180__6, count_1607000179__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000178__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000180__6)); var tmp3 any; var and__1927000168__auto____8 any; var tmp4 *lang.Var
			A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(fm__7); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____9 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp8 any; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_152; var tmp9 lang.IFn = lang.IFn_Cast(tmp8); var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_30; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_31; tmp3 = tmp9.Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = and__1927000168__auto____8 }
//line :222:1
			if jrt.A2g_Truth(tmp3) {

				var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_154; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(fm__7)
//line :222:1
				seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, lang.Numbers_Unchecked_inc_J__J(i_1607000180__6); continue L1 } else { seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, lang.Numbers_Unchecked_inc_J__J(i_1607000180__6); continue L1 } } else { var temp__1927000414__auto____7 any; var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1607000177__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000177__8 any = temp__1927000414__auto____7; var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8)) { var c__1927000678__auto____9 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_41; seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any; var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_31; fm__9 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8); var tmp19 any; var and__1927000168__auto____10 any; var tmp20 *lang.Var
					A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(fm__9); if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_29; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____11 = tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp24 any; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_153; var tmp25 lang.IFn = lang.IFn_Cast(tmp24); var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_30; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_31; tmp19 = tmp25.Invoke_O__O(tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp19 = and__1927000168__auto____11 } } else { tmp19 = and__1927000168__auto____10 }
//line :222:1
					if jrt.A2g_Truth(tmp19) {

						var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_154; lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(fm__9)
//line :222:1
						var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_47; seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), nil, 0, 0; continue L1 } else { var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_47; seq_1607000177__3, chunk_1607000178__4, count_1607000179__5, i_1607000180__6 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_1607000177__8), nil, 0, 0; continue L1 } } } }
//line :221:1
		break L1 }; var nsobj__3 any; var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_151; nsobj__3 = jrt.NN(tmp32).Get__O(); var seq_1607000181__4 any; var tmp33 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_32; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_57; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; var t_ any = t.F_forms; t.F_forms = nil; tmp37 = t_; seq_1607000181__4 = tmp34.Invoke_O__O(tmp36.Invoke_O__O(tmp37))
//line :221:1
	var chunk_1607000182__5 any; var count_1607000183__6 int64 = 0; var i_1607000184__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000184__7, count_1607000183__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000182__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000184__7)); var tmp38 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__8); var tmp39 *jrt.Class
			A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_Init(); tmp39 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O()
//line :226:1
			seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, lang.Numbers_Unchecked_inc_J__J(i_1607000184__7); continue L2 } else { var temp__1927000414__auto____8 any; var tmp40 *lang.Var; A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1607000181__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000181__9 any = temp__1927000414__auto____8; var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1607000181__9)) { var c__1927000678__auto____10 any; var tmp42 *lang.Var; A_arbace_a2g_world_A_Init(); tmp42 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_1607000181__9); var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_41; seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_1607000181__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any; var tmp44 *lang.Var; A_arbace_a2g_world_A_Init(); tmp44 = A_arbace_a2g_world_A_const_31; cf__10 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1607000181__9)
				var tmp45 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, cf__10, t.F_ns); var tmp46 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_Init(); tmp46 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil).Invoke__O()
//line :226:1
				var tmp47 *lang.Var; A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_47; seq_1607000181__4, chunk_1607000182__5, count_1607000183__6, i_1607000184__7 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(seq_1607000181__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :221:1
		break L2 } }; return nil }(); var tmp49 *lang.Var; A_arbace_a2g_world_A_Init(); tmp49 = A_arbace_a2g_world_A_const_18; lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke__O(); if tmp48 != nil { panic(tmp48) }; return tmp1 }
//line :221:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Ctor_O_O_O_O_O_O(c__forms, c__variants, c__failed, c__file, c__applied, c__ns any) { t.F_forms = c__forms; t.F_variants = c__variants; t.F_failed = c__failed; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns }
//line :221:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Invoke_O__O(self any) any { var tmp1 any; tmp48 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000203__3 any; var tmp2 *lang.Var
													A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_32; seq_1607000203__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_forms)
//line :221:1
	var chunk_1607000204__4 any; var count_1607000205__5 int64 = 0; var i_1607000206__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1607000206__6, count_1607000205__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000204__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000206__6)); var tmp3 any; var and__1927000168__auto____8 any; var tmp4 *lang.Var
			A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(fm__7); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____9 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp8 any; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_163; var tmp9 lang.IFn = lang.IFn_Cast(tmp8); var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_30; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_31; tmp3 = tmp9.Invoke_O__O(tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = and__1927000168__auto____8 }
//line :222:1
			if jrt.A2g_Truth(tmp3) {

				var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_154; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(fm__7)
//line :222:1
				seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, lang.Numbers_Unchecked_inc_J__J(i_1607000206__6); continue L1 } else { seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, lang.Numbers_Unchecked_inc_J__J(i_1607000206__6); continue L1 } } else { var temp__1927000414__auto____7 any; var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1607000203__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000203__8 any = temp__1927000414__auto____7; var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8)) { var c__1927000678__auto____9 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_41; seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any; var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_31; fm__9 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8); var tmp19 any; var and__1927000168__auto____10 any; var tmp20 *lang.Var
					A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_28; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(fm__9); if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_29; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_31; and__1927000168__auto____11 = tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp24 any; A_arbace_a2g_world_A_Init(); tmp24 = A_arbace_a2g_world_A_const_164; var tmp25 lang.IFn = lang.IFn_Cast(tmp24); var tmp26 *lang.Var; A_arbace_a2g_world_A_Init(); tmp26 = A_arbace_a2g_world_A_const_30; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_world_A_Init(); tmp28 = A_arbace_a2g_world_A_const_31; tmp19 = tmp25.Invoke_O__O(tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp19 = and__1927000168__auto____11 } } else { tmp19 = and__1927000168__auto____10 }
//line :222:1
					if jrt.A2g_Truth(tmp19) {

						var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_154; lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(fm__9)
//line :222:1
						var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_47; seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), nil, 0, 0; continue L1 } else { var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_47; seq_1607000203__3, chunk_1607000204__4, count_1607000205__5, i_1607000206__6 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_1607000203__8), nil, 0, 0; continue L1 } } } }
//line :221:1
		break L1 }; var nsobj__3 any; var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_151; nsobj__3 = jrt.NN(tmp32).Get__O(); var seq_1607000207__4 any; var tmp33 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_32; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_57; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; var t_ any = t.F_forms; t.F_forms = nil; tmp37 = t_; seq_1607000207__4 = tmp34.Invoke_O__O(tmp36.Invoke_O__O(tmp37))
//line :221:1
	var chunk_1607000208__5 any; var count_1607000209__6 int64 = 0; var i_1607000210__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000210__7, count_1607000209__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000208__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000210__7)); var tmp38 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__8); var tmp39 *jrt.Class
			A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_Init(); tmp39 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O()
//line :226:1
			seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, lang.Numbers_Unchecked_inc_J__J(i_1607000210__7); continue L2 } else { var temp__1927000414__auto____8 any; var tmp40 *lang.Var; A_arbace_a2g_world_A_Init(); tmp40 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1607000207__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000207__9 any = temp__1927000414__auto____8; var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_1607000207__9)) { var c__1927000678__auto____10 any; var tmp42 *lang.Var; A_arbace_a2g_world_A_Init(); tmp42 = A_arbace_a2g_world_A_const_34; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_1607000207__9); var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_41; seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_1607000207__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any; var tmp44 *lang.Var; A_arbace_a2g_world_A_Init(); tmp44 = A_arbace_a2g_world_A_const_31; cf__10 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1607000207__9)
				var tmp45 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_file, t.F_applied, t.F_ns, cf__10); var tmp46 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_Init(); tmp46 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil).Invoke__O()
//line :226:1
				var tmp47 *lang.Var; A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_47; seq_1607000207__4, chunk_1607000208__5, count_1607000209__6, i_1607000210__7 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(seq_1607000207__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :221:1
		break L2 } }; return nil }(); var tmp49 *lang.Var; A_arbace_a2g_world_A_Init(); tmp49 = A_arbace_a2g_world_A_const_18; lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke__O(); if tmp48 != nil { panic(tmp48) }; return tmp1 }





func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Invoke_O__O(self any) any { var tmp1 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 *lang.Var
															A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_146; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_ns; t.F_ns = nil; tmp6 = t_; n__3 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000186__5 any; var tmp7 *lang.Var


	A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_109; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t__2 any = t.F_cf; t.F_cf = nil; tmp9 = t__2; var tmp10 any = tmp9; var tmp11 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY.Ref() }; var tmp12 any = tmp11; var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_New_O(t.F_variants); var tmp14 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_Init(); tmp14 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class; vec__1607000186__5 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000186__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000186__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_100; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_99; ___8 = tmp16.Invoke_O_O_O_O__O(tmp18, jrt.NN(tmp19).GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any; var tmp20 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_155; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_145; var tmp23 any = tmp22.Ref(); var tmp24 any = t.F_nsobj; var tmp25 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_158; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_159; var tmp28 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp26, tmp27.Ref())); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_42; pc__9 = tmp21.Invoke_O_O__O(tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(cf__6))
	var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_156; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_160; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; var t__4 any = t.F_nsobj; t.F_nsobj = nil; tmp34 = t__4; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, pc__9))) { tmp1 = nil } else {
		var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_157; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_161; tmp1 = tmp36.Invoke_O_O__O(tmp37, pc__9) } }; return nil }(); if /*line :227:1*/ tmp38 != nil { if true { var e__3 jrt.Throwable_I = tmp38; var tmp39 *lang.Var








			A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_100; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var t__5 any = t.F_failed; t.F_failed = nil; tmp41 = t__5; var tmp42 any = tmp41; var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_13; var tmp44 any = jrt.NN(tmp43).GetRawRoot__O(); var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_50; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; var t__6 any = t.F_file; t.F_file = nil; tmp47 = t__6; tmp1 = tmp40.Invoke_O_O_O__O(tmp42, tmp44, lang.Tuple_Create_O_O__IPersistentVector(tmp46.Invoke_O__O(tmp47), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_237, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__cf, c__ns any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_cf = c__cf; t.F_ns = c__ns }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Invoke_O__O(self any) any { var tmp1 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 *lang.Var
															A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_146; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_ns; t.F_ns = nil; tmp6 = t_; n__3 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000193__5 any; var tmp7 *lang.Var


	A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_109; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t__2 any = t.F_cf; t.F_cf = nil; tmp9 = t__2; var tmp10 any = tmp9; var tmp11 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY.Ref() }; var tmp12 any = tmp11; var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_New_O(t.F_variants); var tmp14 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_Init(); tmp14 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class; vec__1607000193__5 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000193__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000193__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_100; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_99; ___8 = tmp16.Invoke_O_O_O_O__O(tmp18, jrt.NN(tmp19).GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any; var tmp20 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_155; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_145; var tmp23 any = tmp22.Ref(); var tmp24 any = t.F_nsobj; var tmp25 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_158; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_159; var tmp28 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp26, tmp27.Ref())); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_42; pc__9 = tmp21.Invoke_O_O__O(tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(cf__6))
	var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_156; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_160; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; var t__4 any = t.F_nsobj; t.F_nsobj = nil; tmp34 = t__4; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, pc__9))) { tmp1 = nil } else {
		var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_157; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_162; tmp1 = tmp36.Invoke_O_O__O(tmp37, pc__9) } }; return nil }(); if /*line :227:1*/ tmp38 != nil { if true { var e__3 jrt.Throwable_I = tmp38; var tmp39 *lang.Var








			A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_100; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var t__5 any = t.F_failed; t.F_failed = nil; tmp41 = t__5; var tmp42 any = tmp41; var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_13; var tmp44 any = jrt.NN(tmp43).GetRawRoot__O(); var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_50; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; var t__6 any = t.F_file; t.F_file = nil; tmp47 = t__6; tmp1 = tmp40.Invoke_O_O_O__O(tmp42, tmp44, lang.Tuple_Create_O_O__IPersistentVector(tmp46.Invoke_O__O(tmp47), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_237, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Invoke_O__O(self any) any { var tmp1 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 *lang.Var
															A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_146; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_ns; t.F_ns = nil; tmp6 = t_; n__3 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000212__5 any; var tmp7 *lang.Var


	A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_109; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t__2 any = t.F_cf; t.F_cf = nil; tmp9 = t__2; var tmp10 any = tmp9; var tmp11 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY.Ref() }; var tmp12 any = tmp11; var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_New_O(t.F_variants); var tmp14 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_Init(); tmp14 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class; vec__1607000212__5 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000212__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000212__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_100; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_99; ___8 = tmp16.Invoke_O_O_O_O__O(tmp18, jrt.NN(tmp19).GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any; var tmp20 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_155; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_145; var tmp23 any = tmp22.Ref(); var tmp24 any = t.F_nsobj; var tmp25 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_158; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_159; var tmp28 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp26, tmp27.Ref())); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_42; pc__9 = tmp21.Invoke_O_O__O(tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(cf__6))
	var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_156; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_160; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; var t__4 any = t.F_nsobj; t.F_nsobj = nil; tmp34 = t__4; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, pc__9))) { tmp1 = nil } else {
		var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_157; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_165; tmp1 = tmp36.Invoke_O_O__O(tmp37, pc__9) } }; return nil }(); if /*line :227:1*/ tmp38 != nil { if true { var e__3 jrt.Throwable_I = tmp38; var tmp39 *lang.Var








			A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_100; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var t__5 any = t.F_failed; t.F_failed = nil; tmp41 = t__5; var tmp42 any = tmp41; var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_13; var tmp44 any = jrt.NN(tmp43).GetRawRoot__O(); var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_50; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; var t__6 any = t.F_file; t.F_file = nil; tmp47 = t__6; tmp1 = tmp40.Invoke_O_O_O__O(tmp42, tmp44, lang.Tuple_Create_O_O__IPersistentVector(tmp46.Invoke_O__O(tmp47), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_237, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :227:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__file, c__applied, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_file = c__file; t.F_applied = c__applied; t.F_ns = c__ns; t.F_cf = c__cf }
//line :227:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Invoke_O__O(self any) any { var tmp1 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 *lang.Var
															A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_146; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_ns; t.F_ns = nil; tmp6 = t_; n__3 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :227:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000219__5 any; var tmp7 *lang.Var


	A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_109; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t__2 any = t.F_cf; t.F_cf = nil; tmp9 = t__2; var tmp10 any = tmp9; var tmp11 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY.Ref() }; var tmp12 any = tmp11; var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_New_O(t.F_variants); var tmp14 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_Init(); tmp14 = A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class; vec__1607000219__5 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), t.F_applied)
//line :227:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000219__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000219__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_100; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp17 = t__3; var tmp18 any = tmp17; var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_99; ___8 = tmp16.Invoke_O_O_O_O__O(tmp18, jrt.NN(tmp19).GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :227:1
	var pc__9 any; var tmp20 *lang.Var




	A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_155; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_145; var tmp23 any = tmp22.Ref(); var tmp24 any = t.F_nsobj; var tmp25 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_158; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_159; var tmp28 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp26, tmp27.Ref())); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_42; pc__9 = tmp21.Invoke_O_O__O(tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(cf__6))
	var tmp30 *lang.Var; A_arbace_a2g_world_A_Init(); tmp30 = A_arbace_a2g_world_A_const_156; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_world_A_Init(); tmp32 = A_arbace_a2g_world_A_const_160; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; var t__4 any = t.F_nsobj; t.F_nsobj = nil; tmp34 = t__4; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, pc__9))) { tmp1 = nil } else {
		var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_157; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_166; tmp1 = tmp36.Invoke_O_O__O(tmp37, pc__9) } }; return nil }(); if /*line :227:1*/ tmp38 != nil { if true { var e__3 jrt.Throwable_I = tmp38; var tmp39 *lang.Var








			A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_100; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var t__5 any = t.F_failed; t.F_failed = nil; tmp41 = t__5; var tmp42 any = tmp41; var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_13; var tmp44 any = jrt.NN(tmp43).GetRawRoot__O(); var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_50; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; var t__6 any = t.F_file; t.F_file = nil; tmp47 = t__6; tmp1 = tmp40.Invoke_O_O_O__O(tmp42, tmp44, lang.Tuple_Create_O_O__IPersistentVector(tmp46.Invoke_O__O(tmp47), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_237, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :230:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :230:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }










func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A { A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :241:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_100; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_laps; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_13; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_12; tmp2.Invoke_O_O_O__O(tmp3, tmp5, lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D(lang.Numbers_Minus_J_O__Number(x__2, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_t)), 1.0e7)), 100.0)).Ref())); var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_147; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_t; return tmp8.Invoke_O_O__O(tmp9, jrt.Long_ValueOf_J__Long(x__2).Ref()) }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_175; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_247, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :244:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A{}; t.Ctor_O_O(p0, p1); return t }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :244:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_175; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_247, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_177; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_250, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :247:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A{}; t.Ctor_O_O(p0, p1); return t }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_177; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_250, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_180; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_253, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :250:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :250:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_180; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_253, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A{}; t.Ctor_O_O(p0, p1); return t }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_182; tmp1 = Up_Var_IFn(tmp2).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_256, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :253:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A{}; t.Ctor_O_O(p0, p1); return t }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :253:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_182; tmp1 = Up_Var_IFn(tmp2).Invoke_O__O(t.F_n) }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_failed; t.F_failed = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_13; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; var t__2 any = t.F_n; t.F_n = nil; tmp10 = t__2; tmp1 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_256, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }




func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A { A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															{ var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_168; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(n__1) }
//line :258:1
	return nil }(); if tmp3 != nil { if true { var e__4 jrt.Throwable_I = tmp3; var tmp4 *lang.Var


		A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_100; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_169; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_156; var tmp9 any = jrt.NN(tmp7).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__1)); var tmp10 *lang.Var; A_arbace_a2g_world_A_Init(); tmp10 = A_arbace_a2g_world_A_const_99; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_170; var tmp13 any = tmp12.Ref(); tmp5.Invoke_O_O_O_O__O(tmp9, tmp11, tmp13, e__4.GetMessage__String().Ref())
		var tmp14 *lang.Var; A_arbace_a2g_world_A_Init(); tmp14 = A_arbace_a2g_world_A_const_100; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = t.F_failed; var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_13; var tmp18 any = jrt.NN(tmp17).GetRawRoot__O(); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_232, nil, nil); var tmp20 any = e__4.GetMessage__String().Ref(); var tmp21 *jrt.String; var G__1607000261__8_ any = e__4.GetCause__Throwable(); var G__1607000261__9_ any
		if lang.Util_Identical_O_O__Z(G__1607000261__8_, nil) { G__1607000261__9_ = nil } else { G__1607000261__9_ = jrt.Throwable_Cast(G__1607000261__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z(G__1607000261__9_, nil) { tmp21 = nil } else { tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_233, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1607000261__9_)) }
//line :262:1
		tmp1 = tmp15.Invoke_O_O_O__O(tmp16, tmp18, lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, tmp21.Ref())).Ref())) } }; return tmp1 }






func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A { A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Ctor() {}
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_171; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__1) }



func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :273:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Ctor_O_O_O_O(c__rt_space, c__names, c__compiled_QMARK_, c__analyze_BANG_ any) { t.F_rt_space = c__rt_space; t.F_names = c__names; t.F_compiled_QMARK_ = c__compiled_QMARK_; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :273:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_149; var tmp2 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O()); var tmp3 any; var t_ any = t.F_rt_space; t.F_rt_space = nil; tmp3 = t_; tmp2.Set_O__V(tmp3)
//line :273:1
	var tmp4 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_183; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp7 = t__2; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; var t__3 any = t.F_compiled_QMARK_; t.F_compiled_QMARK_ = nil; tmp11 = t__3; var tmp12 any = tmp11; var tmp13 any; var t__4 any = t.F_names; t.F_names = nil; tmp13 = t__4; tmp4 = tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(tmp12, tmp13)) }
//line :273:1
		return nil }(); var tmp15 *lang.Var


	A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_149; jrt.ThreadLocal_Cast(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O()).Remove__V()
//line :273:1
	if tmp14 != nil { panic(tmp14) }; return tmp4
}









func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A { A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Ctor() {}
//line :284:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_167; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_54; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(n__1, Lit_207)) }
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Invoke_O_O__O(self, s__1607000271__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_New_O_O_O(t.F_tops_QMARK_, s__1607000271__1, self); var tmp2 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_Init(); tmp2 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000271, c__iter__1607000270 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000271 = c__s__1607000271; t.F_iter__1607000270 = c__iter__1607000270 }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Invoke_O__O(self any) any { { var s__1607000271__1 any; var t_ any = t.F_s__1607000271; t.F_s__1607000271 = nil; s__1607000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000271__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000271__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000271__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000271__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000273__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000273__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_New_O_O_I_O(b__1607000273__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_Init(); tmp6 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000273__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000270); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000271__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000273__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000271__3); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_167; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4))) { var tmp18 *lang.Var; A_arbace_a2g_world_A_Init(); tmp18 = A_arbace_a2g_world_A_const_39; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = lang.Tuple_Create_O__IPersistentVector(n__4); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1607000270); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_42; return tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1607000271__3))) } else { var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_42; s__1607000271__1 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1607000271__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :285:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Ctor_O_O_I_O(c__b__1607000273, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000273 = c__b__1607000273; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Invoke_O__O(self any) any { { var i__1607000272__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000272__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000272__1)); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_167; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2))) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_37; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_b__1607000273; tmp4.Invoke_O_O__O(tmp5, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000272__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000272__1); continue L1 } else { i__1607000272__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000272__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Invoke_O_O__O(self, s__1607000281__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(t.F_tops_QMARK_, s__1607000281__1, self); var tmp2 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_Init(); tmp2 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :286:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000281, c__iter__1607000280 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000281 = c__s__1607000281; t.F_iter__1607000280 = c__iter__1607000280 }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Invoke_O__O(self any) any { { var s__1607000281__1 any; var t_ any = t.F_s__1607000281; t.F_s__1607000281 = nil; s__1607000281__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000281__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000281__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000281__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000281__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000283__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000283__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(b__1607000283__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_Init(); tmp6 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000283__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000283__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000281__3); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_39; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Tuple_Create_O__IPersistentVector(n__4); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_42; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_42; s__1607000281__1 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1607000281__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :286:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Ctor_O_O_I_O(c__b__1607000283, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000283 = c__b__1607000283; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :286:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Invoke_O__O(self any) any { { var i__1607000282__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000282__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000282__1)); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_37; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1607000283; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } else { i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Ctor_O_O(c__analyze_BANG_, c__space any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_space = c__space }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_150; tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(jrt.NN(tmp2).GetRawRoot__O())))
//line :290:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_183; tmp3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1) }
//line :290:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :290:1
	if tmp5 != nil { panic(tmp5) }; return tmp3 }
//line :290:1
func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A{}; t.Ctor_O_O(p0, p1); return t }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Ctor_O_O(c__analyze_BANG_, c__space any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_space = c__space }
//line :290:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_150; tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(jrt.NN(tmp2).GetRawRoot__O())))
//line :290:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_183; tmp3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1) }
//line :290:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :290:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}








func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_New() *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Ctor() {}
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Invoke_O_O__O(self, s__1607000300__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_New_O_O(s__1607000300__1, self); var tmp2 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_Init(); tmp2 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :300:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Ctor_O_O(c__s__1607000300, c__iter__1607000299 any) { t.F_s__1607000300 = c__s__1607000300; t.F_iter__1607000299 = c__iter__1607000299 }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Invoke_O__O(self any) any { { var s__1607000300__1 any; var t_ any = t.F_s__1607000300; t.F_s__1607000300 = nil; s__1607000300__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000300__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000300__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000300__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000300__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000302__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000302__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_New_O_I_O(b__1607000302__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_Init(); tmp6 = A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000302__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000299); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000300__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000302__6), nil) } } else { var vec__1607000310__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; vec__1607000310__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000300__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1607000310__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1607000310__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_39; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_269, nil); var tmp20 *lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_30; var tmp21 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(k__5), nil, v__6)).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1607000299); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_42; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1607000300__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :300:1
func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Ctor_O_I_O(c__b__1607000302 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000302 = c__b__1607000302; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :300:1
func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Invoke_O__O(self any) any { { var i__1607000301__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000301__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1607000306__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000301__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1607000306__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1607000306__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_37; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1607000302; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_269, nil); var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_30; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref()); i__1607000301__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000301__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_New() *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Ctor() {}
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Invoke_O_O__O(self, s__1607000321__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_New_O_O(s__1607000321__1, self); var tmp2 *jrt.Class; A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_Init(); tmp2 = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Ctor_O_O(c__s__1607000321, c__iter__1607000320 any) { t.F_s__1607000321 = c__s__1607000321; t.F_iter__1607000320 = c__iter__1607000320 }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Invoke_O__O(self any) any { { var s__1607000321__1 any; var t_ any = t.F_s__1607000321; t.F_s__1607000321 = nil; s__1607000321__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000321__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__1607000328__4 any; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_31; map__1607000328__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var map__1607000328__5 any; if lang.ISeq_InstanceOf(map__1607000328__4) { var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1607000328__4)) { var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_58; map__1607000328__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1607000328__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1607000328__4)) { var tmp6 *lang.Var; A_arbace_a2g_world_A_Init(); tmp6 = A_arbace_a2g_world_A_const_31; map__1607000328__5 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(map__1607000328__4) } else { lang.PersistentArrayMap_Init(); map__1607000328__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000328__5 = map__1607000328__4 }; var file__6 any; var tmp7 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_143; file__6 = lang.RT_Get_O_O__O(map__1607000328__5, tmp7.Ref()); var ns__7 any; var tmp8 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp8 = A_arbace_a2g_world_A_const_145; ns__7 = lang.RT_Get_O_O__O(map__1607000328__5, tmp8.Ref()); var forms__8 any; var tmp9 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_144; forms__8 = lang.RT_Get_O_O__O(map__1607000328__5, tmp9.Ref()); if jrt.A2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp10 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_New_O(file__6); var tmp11 *jrt.Class; A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_Init(); tmp11 = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var fs__1927001036__auto____10 any; var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_32; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____9); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_146; fs__1927001036__auto____10 = tmp13.Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(ns__7, forms__8))); if jrt.A2g_Truth(fs__1927001036__auto____10) { var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_43; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1607000320); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_42; return tmp17.Invoke_O_O__O(fs__1927001036__auto____10, tmp18.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(s__1607000321__1))) } else { var tmp20 *lang.Var; A_arbace_a2g_world_A_Init(); tmp20 = A_arbace_a2g_world_A_const_42; s__1607000321__1 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(s__1607000321__1); continue L1 } } else { var tmp21 *lang.Var; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_42; s__1607000321__1 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__1607000321__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_New_O(p0 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Invoke_O_O__O(self, s__1607000323__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_New_O_O_O(s__1607000323__1, self, t.F_file); var tmp2 *jrt.Class; A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_Init(); tmp2 = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Ctor_O_O_O(c__s__1607000323, c__iter__1607000322, c__file any) { t.F_s__1607000323 = c__s__1607000323; t.F_iter__1607000322 = c__iter__1607000322; t.F_file = c__file }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Invoke_O__O(self any) any { { var s__1607000323__1 any; var t_ any = t.F_s__1607000323; t.F_s__1607000323 = nil; s__1607000323__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1607000323__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000323__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1607000323__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_34; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1607000323__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000325__6 any; var tmp4 *lang.Var; A_arbace_a2g_world_A_Init(); tmp4 = A_arbace_a2g_world_A_const_35; b__1607000325__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_New_O_O_I_O(b__1607000325__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_Init(); tmp6 = A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_40; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1607000325__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1607000322); var tmp12 *lang.Var; A_arbace_a2g_world_A_Init(); tmp12 = A_arbace_a2g_world_A_const_41; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1607000323__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_40; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1607000325__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_a2g_world_A_Init(); tmp16 = A_arbace_a2g_world_A_const_31; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1607000323__3); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_39; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_50; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(t.F_file)); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1607000322); var tmp22 *lang.Var; A_arbace_a2g_world_A_Init(); tmp22 = A_arbace_a2g_world_A_const_42; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1607000323__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :305:1
func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Ctor_O_O_I_O(c__b__1607000325, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000325 = c__b__1607000325; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :305:1
func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Invoke_O__O(self any) any { { var i__1607000324__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000324__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000324__1)); var tmp2 *lang.Var; A_arbace_a2g_world_A_Init(); tmp2 = A_arbace_a2g_world_A_const_37; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1607000325; var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_50; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_file))); i__1607000324__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000324__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_with_world_A_New() *A_arbace_a2g_world_with_world_A { A_arbace_a2g_world_with_world_A_Init(); t := &A_arbace_a2g_world_with_world_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_a2g_world_with_world_A) Ctor() {}
//line :310:1
func (t *A_arbace_a2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { var tmp1 *lang.Var; A_arbace_a2g_world_A_Init(); tmp1 = A_arbace_a2g_world_A_const_32; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_world_A_Init(); tmp3 = A_arbace_a2g_world_A_const_43; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_world_A_Init(); tmp5 = A_arbace_a2g_world_A_const_112; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_a2g_world_A_Init(); tmp7 = A_arbace_a2g_world_A_const_192; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_a2g_world_A_Init(); tmp9 = A_arbace_a2g_world_A_const_112; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_world_A_Init(); tmp11 = A_arbace_a2g_world_A_const_111; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_world_A_Init(); tmp13 = A_arbace_a2g_world_A_const_193; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_a2g_world_A_Init(); tmp15 = A_arbace_a2g_world_A_const_32; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_world_A_Init(); tmp17 = A_arbace_a2g_world_A_const_43; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_world_A_Init(); tmp19 = A_arbace_a2g_world_A_const_112; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_a2g_world_A_Init(); tmp21 = A_arbace_a2g_world_A_const_194; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_a2g_world_A_Init(); tmp23 = A_arbace_a2g_world_A_const_112; var tmp24 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(w__2))))); var tmp25 *lang.Var; A_arbace_a2g_world_A_Init(); tmp25 = A_arbace_a2g_world_A_const_112; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_a2g_world_A_Init(); tmp27 = A_arbace_a2g_world_A_const_32; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_world_A_Init(); tmp29 = A_arbace_a2g_world_A_const_43; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_a2g_world_A_Init(); tmp31 = A_arbace_a2g_world_A_const_112; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_a2g_world_A_Init(); tmp33 = A_arbace_a2g_world_A_const_195; var tmp34 any = tmp32.Invoke_O__O(tmp33); var tmp35 *lang.Var; A_arbace_a2g_world_A_Init(); tmp35 = A_arbace_a2g_world_A_const_112; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_world_A_Init(); tmp37 = A_arbace_a2g_world_A_const_111; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_a2g_world_A_Init(); tmp39 = A_arbace_a2g_world_A_const_193; var tmp40 any = jrt.NN(tmp39).GetRawRoot__O(); var tmp41 *lang.Var; A_arbace_a2g_world_A_Init(); tmp41 = A_arbace_a2g_world_A_const_32; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_a2g_world_A_Init(); tmp43 = A_arbace_a2g_world_A_const_43; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_a2g_world_A_Init(); tmp45 = A_arbace_a2g_world_A_const_112; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; A_arbace_a2g_world_A_Init(); tmp47 = A_arbace_a2g_world_A_const_196; var tmp48 any = tmp46.Invoke_O__O(tmp47); var tmp49 *lang.Var; A_arbace_a2g_world_A_Init(); tmp49 = A_arbace_a2g_world_A_const_112; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_a2g_world_A_Init(); tmp51 = A_arbace_a2g_world_A_const_32; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Var; A_arbace_a2g_world_A_Init(); tmp53 = A_arbace_a2g_world_A_const_43; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_a2g_world_A_Init(); tmp55 = A_arbace_a2g_world_A_const_112; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp57 = A_arbace_a2g_world_A_const_133; var tmp58 any = tmp56.Invoke_O__O(tmp57.Ref()); var tmp59 *lang.Var; A_arbace_a2g_world_A_Init(); tmp59 = A_arbace_a2g_world_A_const_112; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_a2g_world_A_Init(); tmp61 = A_arbace_a2g_world_A_const_194; var tmp62 any = tmp50.Invoke_O__O(tmp52.Invoke_O__O(tmp54.Invoke_O_O__O(tmp58, tmp60.Invoke_O__O(tmp61)))); var tmp63 *lang.Var; A_arbace_a2g_world_A_Init(); tmp63 = A_arbace_a2g_world_A_const_112; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 any; A_arbace_a2g_world_A_Init(); tmp65 = A_arbace_a2g_world_A_const_197; var tmp66 any = tmp64.Invoke_O__O(tmp65); var tmp67 *lang.Var; A_arbace_a2g_world_A_Init(); tmp67 = A_arbace_a2g_world_A_const_112; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_a2g_world_A_Init(); tmp69 = A_arbace_a2g_world_A_const_32; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_a2g_world_A_Init(); tmp71 = A_arbace_a2g_world_A_const_43; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_a2g_world_A_Init(); tmp73 = A_arbace_a2g_world_A_const_112; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp75 = A_arbace_a2g_world_A_const_134; var tmp76 any = tmp74.Invoke_O__O(tmp75.Ref()); var tmp77 *lang.Var; A_arbace_a2g_world_A_Init(); tmp77 = A_arbace_a2g_world_A_const_112; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 any; A_arbace_a2g_world_A_Init(); tmp79 = A_arbace_a2g_world_A_const_194; var tmp80 any = tmp68.Invoke_O__O(tmp70.Invoke_O__O(tmp72.Invoke_O_O__O(tmp76, tmp78.Invoke_O__O(tmp79)))); var tmp81 *lang.Var; A_arbace_a2g_world_A_Init(); tmp81 = A_arbace_a2g_world_A_const_112; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_a2g_world_A_Init(); tmp83 = A_arbace_a2g_world_A_const_198; var tmp84 any = tmp82.Invoke_O__O(tmp83); var tmp85 *lang.Var; A_arbace_a2g_world_A_Init(); tmp85 = A_arbace_a2g_world_A_const_112; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_a2g_world_A_Init(); tmp87 = A_arbace_a2g_world_A_const_32; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_a2g_world_A_Init(); tmp89 = A_arbace_a2g_world_A_const_43; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Var; A_arbace_a2g_world_A_Init(); tmp91 = A_arbace_a2g_world_A_const_112; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *lang.Keyword; A_arbace_a2g_world_A_Init(); tmp93 = A_arbace_a2g_world_A_const_135; var tmp94 any = tmp92.Invoke_O__O(tmp93.Ref()); var tmp95 *lang.Var; A_arbace_a2g_world_A_Init(); tmp95 = A_arbace_a2g_world_A_const_112; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 any; A_arbace_a2g_world_A_Init(); tmp97 = A_arbace_a2g_world_A_const_194; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp24, tmp26.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O_O_O__O(tmp34, tmp36.Invoke_O__O(tmp38.Invoke_O_O__O(tmp40, tmp42.Invoke_O__O(tmp44.Invoke_O_O_O_O_O_O__O(tmp48, tmp62, tmp66, tmp80, tmp84, tmp86.Invoke_O__O(tmp88.Invoke_O__O(tmp90.Invoke_O_O__O(tmp94, tmp96.Invoke_O__O(tmp97)))))))), body__3))))) }












































































































































































































































































type A_arbace_a2g_world_A struct{ jrt.Object }

var A_arbace_a2g_world_A_const_0 *lang.Var

var A_arbace_a2g_world_A_const_1 *lang.Var

var A_arbace_a2g_world_A_const_2 any

var A_arbace_a2g_world_A_const_3 any

var A_arbace_a2g_world_A_const_4 any

var A_arbace_a2g_world_A_const_5 any

var A_arbace_a2g_world_A_const_6 any

var A_arbace_a2g_world_A_const_7 any

var A_arbace_a2g_world_A_const_8 any

var A_arbace_a2g_world_A_const_9 any

var A_arbace_a2g_world_A_const_10 any

var A_arbace_a2g_world_A_const_11 *lang.Var

var A_arbace_a2g_world_A_const_12 *lang.Var

var A_arbace_a2g_world_A_const_13 *lang.Var

var A_arbace_a2g_world_A_const_14 any

var A_arbace_a2g_world_A_const_15 *lang.Var

var A_arbace_a2g_world_A_const_16 *lang.Var

var A_arbace_a2g_world_A_const_17 *lang.Var

var A_arbace_a2g_world_A_const_18 *lang.Var

var A_arbace_a2g_world_A_const_19 *lang.Var

var A_arbace_a2g_world_A_const_20 *lang.Var

var A_arbace_a2g_world_A_const_21 *lang.Var

var A_arbace_a2g_world_A_const_22 *lang.Var

var A_arbace_a2g_world_A_const_23 *lang.Var

var A_arbace_a2g_world_A_const_24 *lang.Keyword

var A_arbace_a2g_world_A_const_25 *lang.Var

var A_arbace_a2g_world_A_const_26 *lang.Var

var A_arbace_a2g_world_A_const_27 any

var A_arbace_a2g_world_A_const_28 *lang.Var

var A_arbace_a2g_world_A_const_29 *lang.Var

var A_arbace_a2g_world_A_const_30 *lang.Var

var A_arbace_a2g_world_A_const_31 *lang.Var

var A_arbace_a2g_world_A_const_32 *lang.Var

var A_arbace_a2g_world_A_const_33 *lang.Var

var A_arbace_a2g_world_A_const_34 *lang.Var

var A_arbace_a2g_world_A_const_35 *lang.Var

var A_arbace_a2g_world_A_const_36 *lang.Var

var A_arbace_a2g_world_A_const_37 *lang.Var

var A_arbace_a2g_world_A_const_38 *lang.Var

var A_arbace_a2g_world_A_const_39 *lang.Var

var A_arbace_a2g_world_A_const_40 *lang.Var

var A_arbace_a2g_world_A_const_41 *lang.Var

var A_arbace_a2g_world_A_const_42 *lang.Var

var A_arbace_a2g_world_A_const_43 *lang.Var

var A_arbace_a2g_world_A_const_44 any

var A_arbace_a2g_world_A_const_45 *lang.Var

var A_arbace_a2g_world_A_const_46 *lang.Var

var A_arbace_a2g_world_A_const_47 *lang.Var

var A_arbace_a2g_world_A_const_48 *lang.Var

var A_arbace_a2g_world_A_const_49 *lang.Keyword

var A_arbace_a2g_world_A_const_50 *lang.Var

var A_arbace_a2g_world_A_const_51 *lang.Var

var A_arbace_a2g_world_A_const_52 *lang.Var

var A_arbace_a2g_world_A_const_53 *lang.Var

var A_arbace_a2g_world_A_const_54 *lang.Var

var A_arbace_a2g_world_A_const_55 *lang.Keyword

var A_arbace_a2g_world_A_const_56 *lang.Var

var A_arbace_a2g_world_A_const_57 *lang.Var

var A_arbace_a2g_world_A_const_58 *lang.Var

var A_arbace_a2g_world_A_const_59 *lang.Keyword

var A_arbace_a2g_world_A_const_60 *lang.Keyword

var A_arbace_a2g_world_A_const_61 *lang.Keyword

var A_arbace_a2g_world_A_const_62 *lang.Keyword

var A_arbace_a2g_world_A_const_63 *lang.Var

var A_arbace_a2g_world_A_const_64 *lang.Var

var A_arbace_a2g_world_A_const_65 *lang.Var

var A_arbace_a2g_world_A_const_66 *lang.Var

var A_arbace_a2g_world_A_const_67 *lang.Var

var A_arbace_a2g_world_A_const_68 any

var A_arbace_a2g_world_A_const_69 *lang.Var

var A_arbace_a2g_world_A_const_70 *lang.Var

var A_arbace_a2g_world_A_const_71 *lang.Var

var A_arbace_a2g_world_A_const_72 *lang.Var

var A_arbace_a2g_world_A_const_73 *lang.Keyword

var A_arbace_a2g_world_A_const_74 *lang.Var

var A_arbace_a2g_world_A_const_75 *lang.Keyword

var A_arbace_a2g_world_A_const_76 *lang.Var

var A_arbace_a2g_world_A_const_77 any

var A_arbace_a2g_world_A_const_78 *lang.Keyword

var A_arbace_a2g_world_A_const_79 *lang.Var

var A_arbace_a2g_world_A_const_80 *lang.Keyword

var A_arbace_a2g_world_A_const_81 *lang.Keyword

var A_arbace_a2g_world_A_const_82 *lang.Keyword

var A_arbace_a2g_world_A_const_83 *lang.Keyword

var A_arbace_a2g_world_A_const_84 *lang.Keyword

var A_arbace_a2g_world_A_const_85 any

var A_arbace_a2g_world_A_const_86 *lang.Keyword

var A_arbace_a2g_world_A_const_87 *lang.Var

var A_arbace_a2g_world_A_const_88 *lang.Var

var A_arbace_a2g_world_A_const_89 any

var A_arbace_a2g_world_A_const_90 *lang.Var

var A_arbace_a2g_world_A_const_91 *lang.Var

var A_arbace_a2g_world_A_const_92 *lang.Var

var A_arbace_a2g_world_A_const_93 *lang.Var

var A_arbace_a2g_world_A_const_94 *lang.Var

var A_arbace_a2g_world_A_const_95 *lang.Var

var A_arbace_a2g_world_A_const_96 *lang.Var

var A_arbace_a2g_world_A_const_97 any

var A_arbace_a2g_world_A_const_98 *lang.Var

var A_arbace_a2g_world_A_const_99 *lang.Var

var A_arbace_a2g_world_A_const_100 *lang.Var

var A_arbace_a2g_world_A_const_101 *lang.Var

var A_arbace_a2g_world_A_const_102 any

var A_arbace_a2g_world_A_const_103 *lang.Var

var A_arbace_a2g_world_A_const_104 *lang.Var

var A_arbace_a2g_world_A_const_105 *lang.Keyword

var A_arbace_a2g_world_A_const_106 *lang.Keyword

var A_arbace_a2g_world_A_const_107 *lang.Var

var A_arbace_a2g_world_A_const_108 *lang.Keyword

var A_arbace_a2g_world_A_const_109 *lang.Var

var A_arbace_a2g_world_A_const_110 *lang.Var

var A_arbace_a2g_world_A_const_111 *lang.Var

var A_arbace_a2g_world_A_const_112 *lang.Var

var A_arbace_a2g_world_A_const_113 *lang.Var

var A_arbace_a2g_world_A_const_114 *lang.Var

var A_arbace_a2g_world_A_const_115 *lang.Var

var A_arbace_a2g_world_A_const_116 *lang.Keyword

var A_arbace_a2g_world_A_const_117 *lang.Keyword

var A_arbace_a2g_world_A_const_118 *lang.Keyword

var A_arbace_a2g_world_A_const_119 *lang.Keyword

var A_arbace_a2g_world_A_const_120 *lang.Keyword

var A_arbace_a2g_world_A_const_121 *lang.Keyword

var A_arbace_a2g_world_A_const_122 *lang.Keyword

var A_arbace_a2g_world_A_const_123 *lang.Keyword

var A_arbace_a2g_world_A_const_124 *jrt.Class

var A_arbace_a2g_world_A_const_125 *lang.Keyword

var A_arbace_a2g_world_A_const_126 *lang.Var

var A_arbace_a2g_world_A_const_127 *lang.Var

var A_arbace_a2g_world_A_const_128 *lang.Var

var A_arbace_a2g_world_A_const_129 *lang.Var

var A_arbace_a2g_world_A_const_130 *lang.Var

var A_arbace_a2g_world_A_const_131 *lang.Var

var A_arbace_a2g_world_A_const_132 *lang.Var

var A_arbace_a2g_world_A_const_133 *lang.Keyword

var A_arbace_a2g_world_A_const_134 *lang.Keyword

var A_arbace_a2g_world_A_const_135 *lang.Keyword

var A_arbace_a2g_world_A_const_136 *lang.Keyword

var A_arbace_a2g_world_A_const_137 *lang.Keyword

var A_arbace_a2g_world_A_const_138 *lang.Keyword

var A_arbace_a2g_world_A_const_139 *lang.Keyword

var A_arbace_a2g_world_A_const_140 *lang.Keyword

var A_arbace_a2g_world_A_const_141 *lang.Var

var A_arbace_a2g_world_A_const_142 *lang.Var

var A_arbace_a2g_world_A_const_143 *lang.Keyword

var A_arbace_a2g_world_A_const_144 *lang.Keyword

var A_arbace_a2g_world_A_const_145 *lang.Keyword

var A_arbace_a2g_world_A_const_146 *lang.Var

var A_arbace_a2g_world_A_const_147 *lang.Var

var A_arbace_a2g_world_A_const_148 *lang.Var

var A_arbace_a2g_world_A_const_149 *lang.Var

var A_arbace_a2g_world_A_const_150 *lang.Var

var A_arbace_a2g_world_A_const_151 *lang.Var

var A_arbace_a2g_world_A_const_152 any

var A_arbace_a2g_world_A_const_153 any

var A_arbace_a2g_world_A_const_154 *lang.Var

var A_arbace_a2g_world_A_const_155 *lang.Var

var A_arbace_a2g_world_A_const_156 *lang.Var

var A_arbace_a2g_world_A_const_157 *lang.Var

var A_arbace_a2g_world_A_const_158 *lang.Keyword

var A_arbace_a2g_world_A_const_159 *lang.Keyword

var A_arbace_a2g_world_A_const_160 *lang.Var

var A_arbace_a2g_world_A_const_161 any

var A_arbace_a2g_world_A_const_162 any

var A_arbace_a2g_world_A_const_163 any

var A_arbace_a2g_world_A_const_164 any

var A_arbace_a2g_world_A_const_165 any

var A_arbace_a2g_world_A_const_166 any

var A_arbace_a2g_world_A_const_167 *lang.Var

var A_arbace_a2g_world_A_const_168 *lang.Var

var A_arbace_a2g_world_A_const_169 *lang.Keyword

var A_arbace_a2g_world_A_const_170 *lang.Keyword

var A_arbace_a2g_world_A_const_171 *lang.Var

var A_arbace_a2g_world_A_const_172 *lang.Var

var A_arbace_a2g_world_A_const_173 *lang.Keyword

var A_arbace_a2g_world_A_const_174 *lang.Keyword

var A_arbace_a2g_world_A_const_175 *lang.Var

var A_arbace_a2g_world_A_const_176 *lang.Keyword

var A_arbace_a2g_world_A_const_177 *lang.Var

var A_arbace_a2g_world_A_const_178 *lang.Keyword

var A_arbace_a2g_world_A_const_179 *lang.Var

var A_arbace_a2g_world_A_const_180 *lang.Var

var A_arbace_a2g_world_A_const_181 *lang.Keyword

var A_arbace_a2g_world_A_const_182 *lang.Var

var A_arbace_a2g_world_A_const_183 *lang.Var

var A_arbace_a2g_world_A_const_184 *lang.Keyword

var A_arbace_a2g_world_A_const_185 *lang.Keyword

var A_arbace_a2g_world_A_const_186 *lang.Var

var A_arbace_a2g_world_A_const_187 *lang.Var

var A_arbace_a2g_world_A_const_188 *lang.Var

var A_arbace_a2g_world_A_const_189 *lang.Var

var A_arbace_a2g_world_A_const_190 *lang.Var

var A_arbace_a2g_world_A_const_191 *lang.Var

var A_arbace_a2g_world_A_const_192 any

var A_arbace_a2g_world_A_const_193 *lang.Var

var A_arbace_a2g_world_A_const_194 any

var A_arbace_a2g_world_A_const_195 any

var A_arbace_a2g_world_A_const_196 any

var A_arbace_a2g_world_A_const_197 any

var A_arbace_a2g_world_A_const_198 any

var A_arbace_a2g_world_A_init jrt.ClassInit

func A_arbace_a2g_world_A_Init() { if !A_arbace_a2g_world_A_init.Done() { A_arbace_a2g_world_A_init.Run(A_arbace_a2g_world_A_clinit) } }

func A_arbace_a2g_world_A_clinit() { A_arbace_a2g_world_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_world_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_world_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_world_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_world_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_world_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_world_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_world_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_a2g_world_A_const_8 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref()); A_arbace_a2g_world_A_const_9 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref()); A_arbace_a2g_world_A_const_10 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref()); A_arbace_a2g_world_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_world_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_a2g_world_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_a2g_world_A_const_14 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25))); A_arbace_a2g_world_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_a2g_world_A_const_16 = lang.RT_Var_String_String__Var(Lit_6, Lit_27); A_arbace_a2g_world_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_world_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_world_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_world_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_world_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_world_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_world_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_world_A_const_24 = lang.RT_Keyword_String_String__Keyword(Lit_23, Lit_35); A_arbace_a2g_world_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_world_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_world_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_35).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_23, Lit_35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref())); A_arbace_a2g_world_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_world_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_a2g_world_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_a2g_world_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_a2g_world_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_a2g_world_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_a2g_world_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_a2g_world_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_a2g_world_A_const_36 = lang.RT_Var_String_String__Var(Lit_23, Lit_48); A_arbace_a2g_world_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_a2g_world_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_world_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_world_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_a2g_world_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_a2g_world_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_world_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_a2g_world_A_const_44 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(); A_arbace_a2g_world_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_a2g_world_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_world_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_a2g_world_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_a2g_world_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_a2g_world_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_a2g_world_A_const_51 = lang.RT_Var_String_String__Var(Lit_12, Lit_62); A_arbace_a2g_world_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_a2g_world_A_const_53 = lang.RT_Var_String_String__Var(Lit_3, Lit_64); A_arbace_a2g_world_A_const_54 = lang.RT_Var_String_String__Var(Lit_3, Lit_65); A_arbace_a2g_world_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_a2g_world_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_a2g_world_A_const_57 = lang.RT_Var_String_String__Var(Lit_23, Lit_68); A_arbace_a2g_world_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_a2g_world_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_a2g_world_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_a2g_world_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_a2g_world_A_const_62 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_a2g_world_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_a2g_world_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_a2g_world_A_const_65 = lang.RT_Var_String_String__Var(Lit_6, Lit_76); A_arbace_a2g_world_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_a2g_world_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_a2g_world_A_const_68 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); A_arbace_a2g_world_A_const_69 = lang.RT_Var_String_String__Var(Lit_23, Lit_80); A_arbace_a2g_world_A_const_70 = lang.RT_Var_String_String__Var(Lit_3, Lit_81); A_arbace_a2g_world_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_a2g_world_A_const_72 = lang.RT_Var_String_String__Var(Lit_23, Lit_83); A_arbace_a2g_world_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_a2g_world_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_a2g_world_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_a2g_world_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_world_A_const_77 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_a2g_world_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_a2g_world_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_a2g_world_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_90); A_arbace_a2g_world_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_a2g_world_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_a2g_world_A_const_83 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_a2g_world_A_const_84 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_95); A_arbace_a2g_world_A_const_85 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_world_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_a2g_world_A_const_87 = lang.RT_Var_String_String__Var(Lit_23, Lit_97); A_arbace_a2g_world_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_a2g_world_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(); A_arbace_a2g_world_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_a2g_world_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_a2g_world_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_102); A_arbace_a2g_world_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_a2g_world_A_const_94 = lang.RT_Var_String_String__Var(Lit_23, Lit_104); A_arbace_a2g_world_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_a2g_world_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_a2g_world_A_const_97 = jrt.Long_ValueOf_J__Long(-1).Ref(); A_arbace_a2g_world_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_a2g_world_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_a2g_world_A_const_100 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_a2g_world_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_a2g_world_A_const_102 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_111).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_112).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_113).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())); A_arbace_a2g_world_A_const_103 = lang.RT_Var_String_String__Var(Lit_23, Lit_114); A_arbace_a2g_world_A_const_104 = lang.RT_Var_String_String__Var(Lit_0, Lit_115); A_arbace_a2g_world_A_const_105 = lang.RT_Keyword_String_String__Keyword(nil, Lit_113); A_arbace_a2g_world_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_a2g_world_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_a2g_world_A_const_108 = lang.RT_Keyword_String_String__Keyword(nil, Lit_111); A_arbace_a2g_world_A_const_109 = lang.RT_Var_String_String__Var(Lit_23, Lit_117); A_arbace_a2g_world_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_118); A_arbace_a2g_world_A_const_111 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_a2g_world_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_a2g_world_A_const_113 = lang.RT_Var_String_String__Var(Lit_23, Lit_121); A_arbace_a2g_world_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_a2g_world_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_a2g_world_A_const_116 = lang.RT_Keyword_String_String__Keyword(Lit_23, Lit_124); A_arbace_a2g_world_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_125); A_arbace_a2g_world_A_const_118 = lang.RT_Keyword_String_String__Keyword(nil, Lit_126); A_arbace_a2g_world_A_const_119 = lang.RT_Keyword_String_String__Keyword(nil, Lit_127); A_arbace_a2g_world_A_const_120 = lang.RT_Keyword_String_String__Keyword(nil, Lit_128); A_arbace_a2g_world_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_129); A_arbace_a2g_world_A_const_122 = lang.RT_Keyword_String_String__Keyword(nil, Lit_130); A_arbace_a2g_world_A_const_123 = lang.RT_Keyword_String_String__Keyword(nil, Lit_131); A_arbace_a2g_world_A_const_124 = lang.RT_ClassForNameNonLoading_String__Class(Lit_132); A_arbace_a2g_world_A_const_125 = lang.RT_Keyword_String_String__Keyword(nil, Lit_133); A_arbace_a2g_world_A_const_126 = lang.RT_Var_String_String__Var(Lit_23, Lit_134); A_arbace_a2g_world_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_a2g_world_A_const_128 = lang.RT_Var_String_String__Var(Lit_16, Lit_136); A_arbace_a2g_world_A_const_129 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_a2g_world_A_const_130 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_a2g_world_A_const_131 = lang.RT_Var_String_String__Var(Lit_0, Lit_139); A_arbace_a2g_world_A_const_132 = lang.RT_Var_String_String__Var(Lit_23, Lit_140); A_arbace_a2g_world_A_const_133 = lang.RT_Keyword_String_String__Keyword(nil, Lit_141); A_arbace_a2g_world_A_const_134 = lang.RT_Keyword_String_String__Keyword(nil, Lit_142); A_arbace_a2g_world_A_const_135 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); A_arbace_a2g_world_A_const_136 = lang.RT_Keyword_String_String__Keyword(nil, Lit_144); A_arbace_a2g_world_A_const_137 = lang.RT_Keyword_String_String__Keyword(nil, Lit_145); A_arbace_a2g_world_A_const_138 = lang.RT_Keyword_String_String__Keyword(nil, Lit_146); A_arbace_a2g_world_A_const_139 = lang.RT_Keyword_String_String__Keyword(nil, Lit_147); A_arbace_a2g_world_A_const_140 = lang.RT_Keyword_String_String__Keyword(nil, Lit_148); A_arbace_a2g_world_A_const_141 = lang.RT_Var_String_String__Var(Lit_23, Lit_149); A_arbace_a2g_world_A_const_142 = lang.RT_Var_String_String__Var(Lit_16, Lit_150); A_arbace_a2g_world_A_const_143 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_a2g_world_A_const_144 = lang.RT_Keyword_String_String__Keyword(nil, Lit_151); A_arbace_a2g_world_A_const_145 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_a2g_world_A_const_146 = lang.RT_Var_String_String__Var(Lit_23, Lit_152); A_arbace_a2g_world_A_const_147 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_a2g_world_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_154); A_arbace_a2g_world_A_const_149 = lang.RT_Var_String_String__Var(Lit_23, Lit_155); A_arbace_a2g_world_A_const_150 = lang.RT_Var_String_String__Var(Lit_23, Lit_156); A_arbace_a2g_world_A_const_151 = lang.RT_Var_String_String__Var(Lit_0, Lit_157); A_arbace_a2g_world_A_const_152 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_158, Lit_159)).Ref(); A_arbace_a2g_world_A_const_153 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_158, Lit_159)).Ref(); A_arbace_a2g_world_A_const_154 = lang.RT_Var_String_String__Var(Lit_14, Lit_160); A_arbace_a2g_world_A_const_155 = lang.RT_Var_String_String__Var(Lit_12, Lit_161); A_arbace_a2g_world_A_const_156 = lang.RT_Var_String_String__Var(Lit_14, Lit_162); A_arbace_a2g_world_A_const_157 = lang.RT_Var_String_String__Var(Lit_14, Lit_163); A_arbace_a2g_world_A_const_158 = lang.RT_Keyword_String_String__Keyword(nil, Lit_164); A_arbace_a2g_world_A_const_159 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_a2g_world_A_const_160 = lang.RT_Var_String_String__Var(Lit_14, Lit_166); A_arbace_a2g_world_A_const_161 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_165).Ref())); A_arbace_a2g_world_A_const_162 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_165).Ref())); A_arbace_a2g_world_A_const_163 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_158, Lit_159)).Ref(); A_arbace_a2g_world_A_const_164 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_158, Lit_159)).Ref(); A_arbace_a2g_world_A_const_165 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_165).Ref())); A_arbace_a2g_world_A_const_166 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_165).Ref())); A_arbace_a2g_world_A_const_167 = lang.RT_Var_String_String__Var(Lit_0, Lit_167); A_arbace_a2g_world_A_const_168 = lang.RT_Var_String_String__Var(Lit_14, Lit_168); A_arbace_a2g_world_A_const_169 = lang.RT_Keyword_String_String__Keyword(nil, Lit_169); A_arbace_a2g_world_A_const_170 = lang.RT_Keyword_String_String__Keyword(nil, Lit_170); A_arbace_a2g_world_A_const_171 = lang.RT_Var_String_String__Var(Lit_18, Lit_171); A_arbace_a2g_world_A_const_172 = lang.RT_Var_String_String__Var(Lit_0, Lit_172); A_arbace_a2g_world_A_const_173 = lang.RT_Keyword_String_String__Keyword(nil, Lit_173); A_arbace_a2g_world_A_const_174 = lang.RT_Keyword_String_String__Keyword(nil, Lit_174); A_arbace_a2g_world_A_const_175 = lang.RT_Var_String_String__Var(Lit_14, Lit_175); A_arbace_a2g_world_A_const_176 = lang.RT_Keyword_String_String__Keyword(nil, Lit_176); A_arbace_a2g_world_A_const_177 = lang.RT_Var_String_String__Var(Lit_14, Lit_177); A_arbace_a2g_world_A_const_178 = lang.RT_Keyword_String_String__Keyword(nil, Lit_178); A_arbace_a2g_world_A_const_179 = lang.RT_Var_String_String__Var(Lit_14, Lit_179); A_arbace_a2g_world_A_const_180 = lang.RT_Var_String_String__Var(Lit_14, Lit_180); A_arbace_a2g_world_A_const_181 = lang.RT_Keyword_String_String__Keyword(nil, Lit_181); A_arbace_a2g_world_A_const_182 = lang.RT_Var_String_String__Var(Lit_14, Lit_182); A_arbace_a2g_world_A_const_183 = lang.RT_Var_String_String__Var(Lit_0, Lit_183); A_arbace_a2g_world_A_const_184 = lang.RT_Keyword_String_String__Keyword(nil, Lit_184); A_arbace_a2g_world_A_const_185 = lang.RT_Keyword_String_String__Keyword(nil, Lit_185); A_arbace_a2g_world_A_const_186 = lang.RT_Var_String_String__Var(Lit_3, Lit_186); A_arbace_a2g_world_A_const_187 = lang.RT_Var_String_String__Var(Lit_10, Lit_187); A_arbace_a2g_world_A_const_188 = lang.RT_Var_String_String__Var(Lit_14, Lit_188); A_arbace_a2g_world_A_const_189 = lang.RT_Var_String_String__Var(Lit_10, Lit_189); A_arbace_a2g_world_A_const_190 = lang.RT_Var_String_String__Var(Lit_0, Lit_190); A_arbace_a2g_world_A_const_191 = lang.RT_Var_String_String__Var(Lit_0, Lit_191); A_arbace_a2g_world_A_const_192 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_192).Ref(); A_arbace_a2g_world_A_const_193 = lang.RT_Var_String_String__Var(Lit_0, Lit_193); A_arbace_a2g_world_A_const_194 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(); A_arbace_a2g_world_A_const_195 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_195).Ref(); A_arbace_a2g_world_A_const_196 = lang.Symbol_Intern_String_String__Symbol(Lit_10, Lit_187).Ref(); A_arbace_a2g_world_A_const_197 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_188).Ref(); A_arbace_a2g_world_A_const_198 = lang.Symbol_Intern_String_String__Symbol(Lit_10, Lit_189).Ref() }

func A_arbace_a2g_world_A_New() *A_arbace_a2g_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_A) Ctor() {}

func (t *A_arbace_a2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_A_class }

func (t *A_arbace_a2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_A); return ok }

func A_arbace_a2g_world_A_Cast(x any) *A_arbace_a2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_apply_variant_A) Is_Compiler_AOTF5() {}

func (t *A_arbace_a2g_world_apply_variant_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_apply_variant_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_A_Init() { if !A_arbace_a2g_world_apply_variant_A_init.Done() { A_arbace_a2g_world_apply_variant_A_init.Run(A_arbace_a2g_world_apply_variant_A_clinit) } }

func A_arbace_a2g_world_apply_variant_A_clinit() { A_arbace_a2g_world_apply_variant_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_A_class }

func (t *A_arbace_a2g_world_apply_variant_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_A); return ok }

func A_arbace_a2g_world_apply_variant_A_Cast(x any) *A_arbace_a2g_world_apply_variant_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000127_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000127_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000127_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000127_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000127_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000127_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000127_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000127_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000127_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000127_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000129_A struct{ jrt.Object; F_counts any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000129_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000129_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000129_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000129_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000129_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000129_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000129_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000129_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000129_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A struct{ jrt.Object; F_k any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000131_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A struct{ jrt.Object; F_k any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000133_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A struct{ jrt.Object; F_k any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000129_fn__1607000135_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_fn__1607000138_A struct{ jrt.Object; F_variants_of, F_prefix, F_applied any }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class *jrt.Class

var A_arbace_a2g_world_apply_variant_fn__1607000138_A_init jrt.ClassInit

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_Init() { if !A_arbace_a2g_world_apply_variant_fn__1607000138_A_init.Done() { A_arbace_a2g_world_apply_variant_fn__1607000138_A_init.Run(A_arbace_a2g_world_apply_variant_fn__1607000138_A_clinit) } }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_clinit() { A_arbace_a2g_world_apply_variant_fn__1607000138_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_apply_variant_fn__1607000138_A_class }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_apply_variant_fn__1607000138_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000138_A); return ok }

func A_arbace_a2g_world_apply_variant_fn__1607000138_A_Cast(x any) *A_arbace_a2g_world_apply_variant_fn__1607000138_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_apply_variant_fn__1607000138_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_apply_variant_fn__1607000138_A_class)) }; return v }



type A_arbace_a2g_world_class_form_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_world_class_form_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_class_form_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_world_class_form_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_world_class_form_QMARK__A_Init() { if !A_arbace_a2g_world_class_form_QMARK__A_init.Done() { A_arbace_a2g_world_class_form_QMARK__A_init.Run(A_arbace_a2g_world_class_form_QMARK__A_clinit) } }

func A_arbace_a2g_world_class_form_QMARK__A_clinit() { A_arbace_a2g_world_class_form_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_form_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_form_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_form_QMARK__A_class }

func (t *A_arbace_a2g_world_class_form_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_form_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_form_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_form_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_form_QMARK__A); return ok }

func A_arbace_a2g_world_class_form_QMARK__A_Cast(x any) *A_arbace_a2g_world_class_form_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_form_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_form_QMARK__A_class)) }; return v }



type A_arbace_a2g_world_class_forms_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_class_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_class_forms_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_A_Init() { if !A_arbace_a2g_world_class_forms_A_init.Done() { A_arbace_a2g_world_class_forms_A_init.Run(A_arbace_a2g_world_class_forms_A_clinit) } }

func A_arbace_a2g_world_class_forms_A_clinit() { A_arbace_a2g_world_class_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_A_class }

func (t *A_arbace_a2g_world_class_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_A); return ok }

func A_arbace_a2g_world_class_forms_A_Cast(x any) *A_arbace_a2g_world_class_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_A_class)) }; return v }



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_Init() { if !A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_init.Done() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_init.Run(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_clinit) } }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_clinit() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A); return ok }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_Cast(x any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_A_class)) }; return v }



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A struct{ jrt.Object; F_iter__1607000019, F_s__1607000020 any }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_Init() { if !A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_init.Done() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_init.Run(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_clinit) } }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_clinit() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A); return ok }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_Cast(x any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_A_class)) }; return v }



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_Init() { if !A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_init.Done() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_init.Run(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_clinit) } }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_clinit() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A); return ok }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_Cast(x any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_A_class)) }; return v }



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A struct{ jrt.Object; F_iter__1607000021, F_s__1607000022 any }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_Init() { if !A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_init.Done() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_init.Run(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_clinit) } }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_clinit() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A); return ok }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_Cast(x any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_A_class)) }; return v }



type A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A struct{ jrt.Object; F_b__1607000024 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_init jrt.ClassInit

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_Init() { if !A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_init.Done() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_init.Run(A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_clinit) } }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_clinit() { A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_class }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A); return ok }

func A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_Cast(x any) *A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_forms_iter__1607000019__1607000025_fn__1607000026_iter__1607000021__1607000027_fn__1607000028_fn__1607000029_A_class)) }; return v }



type A_arbace_a2g_world_class_parts_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_class_parts_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_class_parts_A_fn_class *jrt.Class

var A_arbace_a2g_world_class_parts_A_init jrt.ClassInit

func A_arbace_a2g_world_class_parts_A_Init() { if !A_arbace_a2g_world_class_parts_A_init.Done() { A_arbace_a2g_world_class_parts_A_init.Run(A_arbace_a2g_world_class_parts_A_clinit) } }

func A_arbace_a2g_world_class_parts_A_clinit() { A_arbace_a2g_world_class_parts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_class_parts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_class_parts_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_class_parts_A_class }

func (t *A_arbace_a2g_world_class_parts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_class_parts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_class_parts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_class_parts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_class_parts_A); return ok }

func A_arbace_a2g_world_class_parts_A_Cast(x any) *A_arbace_a2g_world_class_parts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_class_parts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_class_parts_A_class)) }; return v }



type A_arbace_a2g_world_cut_key_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_cut_key_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_cut_key_A_fn_class *jrt.Class

var A_arbace_a2g_world_cut_key_A_init jrt.ClassInit

func A_arbace_a2g_world_cut_key_A_Init() { if !A_arbace_a2g_world_cut_key_A_init.Done() { A_arbace_a2g_world_cut_key_A_init.Run(A_arbace_a2g_world_cut_key_A_clinit) } }

func A_arbace_a2g_world_cut_key_A_clinit() { A_arbace_a2g_world_cut_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_cut_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_cut_key_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_cut_key_A_class }

func (t *A_arbace_a2g_world_cut_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_cut_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_cut_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_cut_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_cut_key_A); return ok }

func A_arbace_a2g_world_cut_key_A_Cast(x any) *A_arbace_a2g_world_cut_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_cut_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_cut_key_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000004_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000004_A_New() *A_arbace_a2g_world_eval1607000004_A { t := &A_arbace_a2g_world_eval1607000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000004_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000004_A_class }

func (t *A_arbace_a2g_world_eval1607000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000004_A); return ok }

func A_arbace_a2g_world_eval1607000004_A_Cast(x any) *A_arbace_a2g_world_eval1607000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000004_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class *jrt.Class

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_init jrt.ClassInit

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_Init() { if !A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_init.Done() { A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_init.Run(A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_clinit) } }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_clinit() { A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_class }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A); return ok }

func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_Cast(x any) *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000008_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000008_A_New() *A_arbace_a2g_world_eval1607000008_A { t := &A_arbace_a2g_world_eval1607000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000008_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000008_A_class }

func (t *A_arbace_a2g_world_eval1607000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000008_A); return ok }

func A_arbace_a2g_world_eval1607000008_A_Cast(x any) *A_arbace_a2g_world_eval1607000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000008_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000008_fn__1607000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class *jrt.Class

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_init jrt.ClassInit

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_Init() { if !A_arbace_a2g_world_eval1607000008_fn__1607000009_A_init.Done() { A_arbace_a2g_world_eval1607000008_fn__1607000009_A_init.Run(A_arbace_a2g_world_eval1607000008_fn__1607000009_A_clinit) } }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_clinit() { A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000008_fn__1607000009_A_class }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000008_fn__1607000009_A); return ok }

func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_Cast(x any) *A_arbace_a2g_world_eval1607000008_fn__1607000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000008_fn__1607000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000008_fn__1607000009_A_class)) }; return v }



type A_arbace_a2g_world_head_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_head_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_head_name_A_fn_class *jrt.Class

var A_arbace_a2g_world_head_name_A_init jrt.ClassInit

func A_arbace_a2g_world_head_name_A_Init() { if !A_arbace_a2g_world_head_name_A_init.Done() { A_arbace_a2g_world_head_name_A_init.Run(A_arbace_a2g_world_head_name_A_clinit) } }

func A_arbace_a2g_world_head_name_A_clinit() { A_arbace_a2g_world_head_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_head_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_head_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_head_name_A_class }

func (t *A_arbace_a2g_world_head_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_head_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_head_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_head_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_head_name_A); return ok }

func A_arbace_a2g_world_head_name_A_Cast(x any) *A_arbace_a2g_world_head_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_head_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_head_name_A_class)) }; return v }



type A_arbace_a2g_world_id_space_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_id_space_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_id_space_A_fn_class *jrt.Class

var A_arbace_a2g_world_id_space_A_init jrt.ClassInit

func A_arbace_a2g_world_id_space_A_Init() { if !A_arbace_a2g_world_id_space_A_init.Done() { A_arbace_a2g_world_id_space_A_init.Run(A_arbace_a2g_world_id_space_A_clinit) } }

func A_arbace_a2g_world_id_space_A_clinit() { A_arbace_a2g_world_id_space_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_id_space_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_id_space_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_id_space_A_class }

func (t *A_arbace_a2g_world_id_space_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_id_space_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_id_space_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_id_space_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_id_space_A); return ok }

func A_arbace_a2g_world_id_space_A_Cast(x any) *A_arbace_a2g_world_id_space_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_id_space_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_id_space_A_class)) }; return v }



type A_arbace_a2g_world_load_world_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_A) Is_Compiler_AOTR1() {}

var A_arbace_a2g_world_load_world_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_A_Init() { if !A_arbace_a2g_world_load_world_A_init.Done() { A_arbace_a2g_world_load_world_A_init.Run(A_arbace_a2g_world_load_world_A_clinit) } }

func A_arbace_a2g_world_load_world_A_clinit() { A_arbace_a2g_world_load_world_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_a2g_world_load_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_A_class }

func (t *A_arbace_a2g_world_load_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_A); return ok }

func A_arbace_a2g_world_load_world_A_Cast(x any) *A_arbace_a2g_world_load_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000158_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000158_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000158_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000158_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000158_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000158_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000158_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000158_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_226, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000158_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000158_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000158_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000158_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000161_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000161_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000161_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000161_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000161_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000161_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000161_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000161_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_227, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000161_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000161_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000161_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000161_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_A struct{ jrt.Object; F_parsed, F_variants, F_failed, F_applied, F_unit any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A struct{ jrt.Object; F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_analyze_BANG___1607000260_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_compiled_QMARK___1607000263_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A struct{ jrt.Object; F_forms, F_variants, F_failed, F_file, F_applied, F_ns any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A struct{ jrt.Object; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A struct{ jrt.Object; F_variants any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000185_fn__1607000189_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A struct{ jrt.Object; F_variants, F_failed, F_nsobj, F_file, F_applied, F_cf, F_ns any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A struct{ jrt.Object; F_variants any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000176_fn__1607000192_fn__1607000196_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A struct{ jrt.Object; F_forms, F_variants, F_failed, F_file, F_applied, F_ns any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A struct{ jrt.Object; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A struct{ jrt.Object; F_variants any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000211_fn__1607000215_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A struct{ jrt.Object; F_variants, F_failed, F_nsobj, F_file, F_applied, F_ns, F_cf any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A struct{ jrt.Object; F_variants any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000202_fn__1607000218_fn__1607000222_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000232_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000234_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000240_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000242_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000248_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000250_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000256_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A struct{ jrt.Object; F_n, F_failed any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000258_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A struct{ jrt.Object; F_rt_space, F_names, F_compiled_QMARK_, F_analyze_BANG_ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_258, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000266_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A struct{ jrt.Object; F_analyze_BANG_, F_space any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000294_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A struct{ jrt.Object; F_analyze_BANG_, F_space any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_260, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_fn__1607000296_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A struct{ jrt.Object; F_tops_QMARK_ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A struct{ jrt.Object; F_tops_QMARK_, F_s__1607000271, F_iter__1607000270 any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A struct{ jrt.Object; F_b__1607000273, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_263, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000270__1607000274_fn__1607000275_fn__1607000276_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A struct{ jrt.Object; F_tops_QMARK_ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_264, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A struct{ jrt.Object; F_tops_QMARK_, F_s__1607000281, F_iter__1607000280 any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_265, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A struct{ jrt.Object; F_b__1607000283, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_266, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_267, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A struct{ jrt.Object; F_s__1607000300, F_iter__1607000299 any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_268, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A struct{ jrt.Object; F_b__1607000302 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_270, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_iter__1607000299__1607000303_fn__1607000304_fn__1607000305_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A struct{ jrt.Object; F_t, F_laps any }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_271, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_lap__1607000226_A_class)) }; return v }



type A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_Init() { if !A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_init.Done() { A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_init.Run(A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_clinit) } }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_clinit() { A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_class }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A); return ok }

func A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_Cast(x any) *A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_fn__1607000169_tops_QMARK___1607000268_A_class)) }; return v }



type A_arbace_a2g_world_load_world_from_source__1607000167_A struct{ jrt.Object; F_tops, F_top_of any }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_from_source__1607000167_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_from_source__1607000167_A_Init() { if !A_arbace_a2g_world_load_world_from_source__1607000167_A_init.Done() { A_arbace_a2g_world_load_world_from_source__1607000167_A_init.Run(A_arbace_a2g_world_load_world_from_source__1607000167_A_clinit) } }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_clinit() { A_arbace_a2g_world_load_world_from_source__1607000167_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_from_source__1607000167_A_class }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_from_source__1607000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_from_source__1607000167_A); return ok }

func A_arbace_a2g_world_load_world_from_source__1607000167_A_Cast(x any) *A_arbace_a2g_world_load_world_from_source__1607000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_from_source__1607000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_from_source__1607000167_A_class)) }; return v }



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_Init() { if !A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_init.Done() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_init.Run(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_clinit) } }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_clinit() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_274, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A); return ok }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_Cast(x any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_iter__1607000320__1607000326_A_class)) }; return v }



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A struct{ jrt.Object; F_s__1607000321, F_iter__1607000320 any }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_Init() { if !A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_init.Done() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_init.Run(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_clinit) } }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_clinit() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A); return ok }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_Cast(x any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_A_class)) }; return v }



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A struct{ jrt.Object; F_file any }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_Init() { if !A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_init.Done() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_init.Run(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_clinit) } }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_clinit() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_276, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A); return ok }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_Cast(x any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_A_class)) }; return v }



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A struct{ jrt.Object; F_s__1607000323, F_iter__1607000322, F_file any }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_Init() { if !A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_init.Done() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_init.Run(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_clinit) } }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_clinit() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A); return ok }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_Cast(x any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_A_class)) }; return v }



type A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A struct{ jrt.Object; F_b__1607000325, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_Init() { if !A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_init.Done() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_init.Run(A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_clinit) } }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_clinit() { A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_class }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A); return ok }

func A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_Cast(x any) *A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_iter__1607000320__1607000326_fn__1607000327_iter__1607000322__1607000330_fn__1607000331_fn__1607000332_A_class)) }; return v }



type A_arbace_a2g_world_load_world_top_of__1607000165_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class *jrt.Class

var A_arbace_a2g_world_load_world_top_of__1607000165_A_init jrt.ClassInit

func A_arbace_a2g_world_load_world_top_of__1607000165_A_Init() { if !A_arbace_a2g_world_load_world_top_of__1607000165_A_init.Done() { A_arbace_a2g_world_load_world_top_of__1607000165_A_init.Run(A_arbace_a2g_world_load_world_top_of__1607000165_A_clinit) } }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_clinit() { A_arbace_a2g_world_load_world_top_of__1607000165_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_279, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_load_world_top_of__1607000165_A_class }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_load_world_top_of__1607000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_load_world_top_of__1607000165_A); return ok }

func A_arbace_a2g_world_load_world_top_of__1607000165_A_Cast(x any) *A_arbace_a2g_world_load_world_top_of__1607000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_load_world_top_of__1607000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_load_world_top_of__1607000165_A_class)) }; return v }



type A_arbace_a2g_world_new_unit_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_new_unit_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_new_unit_A_fn_class *jrt.Class

var A_arbace_a2g_world_new_unit_A_init jrt.ClassInit

func A_arbace_a2g_world_new_unit_A_Init() { if !A_arbace_a2g_world_new_unit_A_init.Done() { A_arbace_a2g_world_new_unit_A_init.Run(A_arbace_a2g_world_new_unit_A_clinit) } }

func A_arbace_a2g_world_new_unit_A_clinit() { A_arbace_a2g_world_new_unit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_new_unit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_new_unit_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_new_unit_A_class }

func (t *A_arbace_a2g_world_new_unit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_new_unit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_new_unit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_new_unit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_new_unit_A); return ok }

func A_arbace_a2g_world_new_unit_A_Cast(x any) *A_arbace_a2g_world_new_unit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_new_unit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_new_unit_A_class)) }; return v }



type A_arbace_a2g_world_ns_of_forms_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_ns_of_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_ns_of_forms_A_fn_class *jrt.Class

var A_arbace_a2g_world_ns_of_forms_A_init jrt.ClassInit

func A_arbace_a2g_world_ns_of_forms_A_Init() { if !A_arbace_a2g_world_ns_of_forms_A_init.Done() { A_arbace_a2g_world_ns_of_forms_A_init.Run(A_arbace_a2g_world_ns_of_forms_A_clinit) } }

func A_arbace_a2g_world_ns_of_forms_A_clinit() { A_arbace_a2g_world_ns_of_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_281, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_ns_of_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_ns_of_forms_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_ns_of_forms_A_class }

func (t *A_arbace_a2g_world_ns_of_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_ns_of_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_ns_of_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_ns_of_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_ns_of_forms_A); return ok }

func A_arbace_a2g_world_ns_of_forms_A_Cast(x any) *A_arbace_a2g_world_ns_of_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_ns_of_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_ns_of_forms_A_class)) }; return v }



type A_arbace_a2g_world_ns_of_forms_fn__1607000037_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class *jrt.Class

var A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_init jrt.ClassInit

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_Init() { if !A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_init.Done() { A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_init.Run(A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_clinit) } }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_clinit() { A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_class }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_ns_of_forms_fn__1607000037_A); return ok }

func A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_Cast(x any) *A_arbace_a2g_world_ns_of_forms_fn__1607000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_ns_of_forms_fn__1607000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_ns_of_forms_fn__1607000037_A_class)) }; return v }



type A_arbace_a2g_world_param_key_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_param_key_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_param_key_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_A_Init() { if !A_arbace_a2g_world_param_key_A_init.Done() { A_arbace_a2g_world_param_key_A_init.Run(A_arbace_a2g_world_param_key_A_clinit) } }

func A_arbace_a2g_world_param_key_A_clinit() { A_arbace_a2g_world_param_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_A_class }

func (t *A_arbace_a2g_world_param_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_A); return ok }

func A_arbace_a2g_world_param_key_A_Cast(x any) *A_arbace_a2g_world_param_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000089_A struct{ jrt.Object; F_f any }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000089_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000089_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000089_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000089_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000089_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000089_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_285, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000089_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000089_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000089_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000089_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000091_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000091_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000091_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000091_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000091_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000091_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000091_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_286, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000091_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000091_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000091_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000091_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000097_A struct{ jrt.Object; F_more any }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000097_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000097_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000097_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000097_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000097_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000097_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_287, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000097_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000097_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000097_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000097_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000099_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000099_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000099_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000099_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000099_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000099_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000099_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000099_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000099_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000099_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000099_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000099_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000105_A struct{ jrt.Object; F_more any }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000105_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000105_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000105_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000105_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000105_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000105_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000105_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_289, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000105_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000105_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000105_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000105_A_class)) }; return v }



type A_arbace_a2g_world_param_key_fn__1607000107_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class *jrt.Class

var A_arbace_a2g_world_param_key_fn__1607000107_A_init jrt.ClassInit

func A_arbace_a2g_world_param_key_fn__1607000107_A_Init() { if !A_arbace_a2g_world_param_key_fn__1607000107_A_init.Done() { A_arbace_a2g_world_param_key_fn__1607000107_A_init.Run(A_arbace_a2g_world_param_key_fn__1607000107_A_clinit) } }

func A_arbace_a2g_world_param_key_fn__1607000107_A_clinit() { A_arbace_a2g_world_param_key_fn__1607000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_290, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_param_key_fn__1607000107_A_class }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_param_key_fn__1607000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_param_key_fn__1607000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000107_A); return ok }

func A_arbace_a2g_world_param_key_fn__1607000107_A_Cast(x any) *A_arbace_a2g_world_param_key_fn__1607000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_param_key_fn__1607000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_param_key_fn__1607000107_A_class)) }; return v }



type A_arbace_a2g_world_read_forms_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_read_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_read_forms_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_forms_A_init jrt.ClassInit

func A_arbace_a2g_world_read_forms_A_Init() { if !A_arbace_a2g_world_read_forms_A_init.Done() { A_arbace_a2g_world_read_forms_A_init.Run(A_arbace_a2g_world_read_forms_A_clinit) } }

func A_arbace_a2g_world_read_forms_A_clinit() { A_arbace_a2g_world_read_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_291, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_forms_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_forms_A_class }

func (t *A_arbace_a2g_world_read_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_forms_A); return ok }

func A_arbace_a2g_world_read_forms_A_Cast(x any) *A_arbace_a2g_world_read_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_forms_A_class)) }; return v }



type A_arbace_a2g_world_read_forms_fn__1607000013_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_forms_fn__1607000013_A_init jrt.ClassInit

func A_arbace_a2g_world_read_forms_fn__1607000013_A_Init() { if !A_arbace_a2g_world_read_forms_fn__1607000013_A_init.Done() { A_arbace_a2g_world_read_forms_fn__1607000013_A_init.Run(A_arbace_a2g_world_read_forms_fn__1607000013_A_clinit) } }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_clinit() { A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_292, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_forms_fn__1607000013_A_class }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_forms_fn__1607000013_A); return ok }

func A_arbace_a2g_world_read_forms_fn__1607000013_A_Cast(x any) *A_arbace_a2g_world_read_forms_fn__1607000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_forms_fn__1607000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_forms_fn__1607000013_A_class)) }; return v }



type A_arbace_a2g_world_read_forms_fn__1607000015_A struct{ jrt.Object; F_r any }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_forms_fn__1607000015_A_init jrt.ClassInit

func A_arbace_a2g_world_read_forms_fn__1607000015_A_Init() { if !A_arbace_a2g_world_read_forms_fn__1607000015_A_init.Done() { A_arbace_a2g_world_read_forms_fn__1607000015_A_init.Run(A_arbace_a2g_world_read_forms_fn__1607000015_A_clinit) } }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_clinit() { A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_forms_fn__1607000015_A_class }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_forms_fn__1607000015_A); return ok }

func A_arbace_a2g_world_read_forms_fn__1607000015_A_Cast(x any) *A_arbace_a2g_world_read_forms_fn__1607000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_forms_fn__1607000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_forms_fn__1607000015_A_class)) }; return v }



type A_arbace_a2g_world_read_variants_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_read_variants_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_read_variants_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_variants_A_init jrt.ClassInit

func A_arbace_a2g_world_read_variants_A_Init() { if !A_arbace_a2g_world_read_variants_A_init.Done() { A_arbace_a2g_world_read_variants_A_init.Run(A_arbace_a2g_world_read_variants_A_clinit) } }

func A_arbace_a2g_world_read_variants_A_clinit() { A_arbace_a2g_world_read_variants_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_294, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_variants_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_variants_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_variants_A_class }

func (t *A_arbace_a2g_world_read_variants_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_variants_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_variants_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_variants_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_variants_A); return ok }

func A_arbace_a2g_world_read_variants_A_Cast(x any) *A_arbace_a2g_world_read_variants_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_variants_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_variants_A_class)) }; return v }



type A_arbace_a2g_world_read_variants_fn__1607000144_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_variants_fn__1607000144_A_init jrt.ClassInit

func A_arbace_a2g_world_read_variants_fn__1607000144_A_Init() { if !A_arbace_a2g_world_read_variants_fn__1607000144_A_init.Done() { A_arbace_a2g_world_read_variants_fn__1607000144_A_init.Run(A_arbace_a2g_world_read_variants_fn__1607000144_A_clinit) } }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_clinit() { A_arbace_a2g_world_read_variants_fn__1607000144_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_295, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_variants_fn__1607000144_A_class }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_variants_fn__1607000144_A); return ok }

func A_arbace_a2g_world_read_variants_fn__1607000144_A_Cast(x any) *A_arbace_a2g_world_read_variants_fn__1607000144_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_variants_fn__1607000144_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_variants_fn__1607000144_A_class)) }; return v }



type A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A struct{ jrt.Object; F_nsname any }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class *jrt.Class

var A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_init jrt.ClassInit

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_Init() { if !A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_init.Done() { A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_init.Run(A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_clinit) } }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_clinit() { A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_296, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_class }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A); return ok }

func A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_Cast(x any) *A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_read_variants_fn__1607000144_fn__1607000145_A_class)) }; return v }



type A_arbace_a2g_world_source_files_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_source_files_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_A_Init() { if !A_arbace_a2g_world_source_files_A_init.Done() { A_arbace_a2g_world_source_files_A_init.Run(A_arbace_a2g_world_source_files_A_clinit) } }

func A_arbace_a2g_world_source_files_A_clinit() { A_arbace_a2g_world_source_files_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_300, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_A_class }

func (t *A_arbace_a2g_world_source_files_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_A); return ok }

func A_arbace_a2g_world_source_files_A_Cast(x any) *A_arbace_a2g_world_source_files_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_A_class)) }; return v }



type A_arbace_a2g_world_source_files_fn__1607000062_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_fn__1607000062_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_fn__1607000062_A_Init() { if !A_arbace_a2g_world_source_files_fn__1607000062_A_init.Done() { A_arbace_a2g_world_source_files_fn__1607000062_A_init.Run(A_arbace_a2g_world_source_files_fn__1607000062_A_clinit) } }

func A_arbace_a2g_world_source_files_fn__1607000062_A_clinit() { A_arbace_a2g_world_source_files_fn__1607000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_301, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_fn__1607000062_A_class }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_fn__1607000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000062_A); return ok }

func A_arbace_a2g_world_source_files_fn__1607000062_A_Cast(x any) *A_arbace_a2g_world_source_files_fn__1607000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_fn__1607000062_A_class)) }; return v }



type A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_Init() { if !A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_init.Done() { A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_init.Run(A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_clinit) } }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_clinit() { A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_302, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_class }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A); return ok }

func A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_Cast(x any) *A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_fn__1607000062_fn__1607000063_A_class)) }; return v }



type A_arbace_a2g_world_source_files_fn__1607000066_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_fn__1607000066_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_fn__1607000066_A_Init() { if !A_arbace_a2g_world_source_files_fn__1607000066_A_init.Done() { A_arbace_a2g_world_source_files_fn__1607000066_A_init.Run(A_arbace_a2g_world_source_files_fn__1607000066_A_clinit) } }

func A_arbace_a2g_world_source_files_fn__1607000066_A_clinit() { A_arbace_a2g_world_source_files_fn__1607000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_303, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_fn__1607000066_A_class }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_fn__1607000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_fn__1607000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000066_A); return ok }

func A_arbace_a2g_world_source_files_fn__1607000066_A_Cast(x any) *A_arbace_a2g_world_source_files_fn__1607000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_fn__1607000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_fn__1607000066_A_class)) }; return v }



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A struct{ jrt.Object; F_root any }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_Init() { if !A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_init.Done() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_init.Run(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_clinit) } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_clinit() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_305, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A); return ok }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_Cast(x any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_iter__1607000068__1607000074_A_class)) }; return v }



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A struct{ jrt.Object; F_s__1607000069, F_iter__1607000068, F_root any }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_Init() { if !A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_init.Done() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_init.Run(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_clinit) } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_clinit() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_306, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A); return ok }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_Cast(x any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_A_class)) }; return v }



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_Init() { if !A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_init.Done() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_init.Run(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_clinit) } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_clinit() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_307, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A); return ok }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_Cast(x any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_A_class)) }; return v }



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A struct{ jrt.Object; F_s__1607000071, F_iter__1607000070 any }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_Init() { if !A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_init.Done() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_init.Run(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_clinit) } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_clinit() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_308, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A); return ok }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_Cast(x any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_A_class)) }; return v }



type A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A struct{ jrt.Object; F_b__1607000073 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class *jrt.Class

var A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_init jrt.ClassInit

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_Init() { if !A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_init.Done() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_init.Run(A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_clinit) } }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_clinit() { A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_309, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_class }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A); return ok }

func A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_Cast(x any) *A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_source_files_iter__1607000068__1607000074_fn__1607000075_iter__1607000070__1607000076_fn__1607000077_fn__1607000078_A_class)) }; return v }



type A_arbace_a2g_world_top_names_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_top_names_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_world_top_names_A_fn_class *jrt.Class

var A_arbace_a2g_world_top_names_A_init jrt.ClassInit

func A_arbace_a2g_world_top_names_A_Init() { if !A_arbace_a2g_world_top_names_A_init.Done() { A_arbace_a2g_world_top_names_A_init.Run(A_arbace_a2g_world_top_names_A_clinit) } }

func A_arbace_a2g_world_top_names_A_clinit() { A_arbace_a2g_world_top_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_310, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_top_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_top_names_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_top_names_A_class }

func (t *A_arbace_a2g_world_top_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_top_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_top_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_top_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_top_names_A); return ok }

func A_arbace_a2g_world_top_names_A_Cast(x any) *A_arbace_a2g_world_top_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_top_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_top_names_A_class)) }; return v }



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A struct{ jrt.Object; F_nsname any }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class *jrt.Class

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_init jrt.ClassInit

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_Init() { if !A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_init.Done() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_init.Run(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_clinit) } }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_clinit() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_311, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A); return ok }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_Cast(x any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_top_names_iter__1607000040__1607000044_A_class)) }; return v }



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A struct{ jrt.Object; F_iter__1607000040, F_nsname, F_s__1607000041 any }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class *jrt.Class

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_init jrt.ClassInit

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_Init() { if !A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_init.Done() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_init.Run(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_clinit) } }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_clinit() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_312, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A); return ok }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_Cast(x any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_A_class)) }; return v }



type A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A struct{ jrt.Object; F_b__1607000043, F_nsname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class *jrt.Class

var A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_init jrt.ClassInit

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_Init() { if !A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_init.Done() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_init.Run(A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_clinit) } }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_clinit() { A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_313, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_class }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A); return ok }

func A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_Cast(x any) *A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_top_names_iter__1607000040__1607000044_fn__1607000045_fn__1607000046_A_class)) }; return v }



type A_arbace_a2g_world_with_world_A struct{ jrt.Object }

func (t *A_arbace_a2g_world_with_world_A) Is_Compiler_AOTR3() {}

var A_arbace_a2g_world_with_world_A_fn_class *jrt.Class

var A_arbace_a2g_world_with_world_A_init jrt.ClassInit

func A_arbace_a2g_world_with_world_A_Init() { if !A_arbace_a2g_world_with_world_A_init.Done() { A_arbace_a2g_world_with_world_A_init.Run(A_arbace_a2g_world_with_world_A_clinit) } }

func A_arbace_a2g_world_with_world_A_clinit() { A_arbace_a2g_world_with_world_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_314, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_a2g_world_with_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_with_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_with_world_A_class }

func (t *A_arbace_a2g_world_with_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_with_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_with_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_with_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_with_world_A); return ok }

func A_arbace_a2g_world_with_world_A_Cast(x any) *A_arbace_a2g_world_with_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_with_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_with_world_A_class)) }; return v }
