//line aot_arbace_a2g_world.ae:1
package aot_arbace_a2g_world

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_New() *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_world_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_2); lang.IFn_Cast(A_arbace_a2g_world_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_3, A_arbace_a2g_world_A_const_4, A_arbace_a2g_world_A_const_5, A_arbace_a2g_world_A_const_6, A_arbace_a2g_world_A_const_7, A_arbace_a2g_world_A_const_8, A_arbace_a2g_world_A_const_9, A_arbace_a2g_world_A_const_10); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_21)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp5 != nil { panic(tmp5) }; return tmp3 }
//line :1:1
func A_arbace_a2g_world_eval1607000008_fn__1607000009_A_New() *A_arbace_a2g_world_eval1607000008_fn__1607000009_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_eval1607000008_fn__1607000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_world_eval1607000008_fn__1607000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_15), A_arbace_a2g_world_A_const_13.GetRawRoot__O(), A_arbace_a2g_world_A_const_14) }















func A_arbace_a2g_world_read_forms_A_New() *A_arbace_a2g_world_read_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_world_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_21; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_17.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_22.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_read_forms_fn__1607000013_A_New(); var tmp9 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class = fncls__1d; tmp9 = fncls__1d } else { tmp9 = fncls__1 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_25.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(r__2); var tmp13 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class = fncls__2d; tmp13 = fncls__2d } else { tmp13 = fncls__2 }; tmp1 = tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)))) }
//line :19:1
		return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :17:1
		if tmp14 != nil { panic(tmp14) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :17:1*/ tmp15 != nil { panic(tmp15) }; return tmp1 }


func A_arbace_a2g_world_read_forms_fn__1607000013_A_New() *A_arbace_a2g_world_read_forms_fn__1607000013_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000013_A) Invoke_O_O__O(self, p1__1607000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_23.GetRawRoot__O()).Invoke_O_O__O(p1__1607000012_SHARP___1, A_arbace_a2g_world_A_const_24) }
//line :20:1
func A_arbace_a2g_world_read_forms_fn__1607000015_A_New_O(p0 any) *A_arbace_a2g_world_read_forms_fn__1607000015_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_forms_fn__1607000015_A{}; t.Ctor_O(p0); return t }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :20:1
func (t *A_arbace_a2g_world_read_forms_fn__1607000015_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_27, t.F_r) }

func A_arbace_a2g_world_first_form_A_New() *A_arbace_a2g_world_first_form_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_first_form_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_a2g_world_first_form_A) Ctor() {}
//line :22:1
func (t *A_arbace_a2g_world_first_form_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_16.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_21; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :22:1
		{ var x__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_28, r__2)





			if lang.Util_Equiv_O_O__Z(x__7, A_arbace_a2g_world_A_const_24) { tmp1 = nil } else { tmp1 = x__7 } }
//line :26:1
		return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :22:1
		if tmp6 != nil { panic(tmp6) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :22:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_a2g_world_class_form_QMARK__A_New() *A_arbace_a2g_world_class_form_QMARK__A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_form_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_world_class_form_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_world_class_forms_A_New() *A_arbace_a2g_world_class_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_a2g_world_class_forms_A) Ctor() {}
//line :32:1
func (t *A_arbace_a2g_world_class_forms_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class; if
											fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_New() *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A) Invoke_O_O__O(self, s__1607000021__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_New_O_O(self, s__1607000021__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A) Ctor_O_O(c__iter__1607000020, c__s__1607000021 any) { t.F_iter__1607000020 = c__iter__1607000020; t.F_s__1607000021 = c__s__1607000021 }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A) Invoke_O__O(self any) any { { var s__1607000021__1 any; var t_ any = t.F_s__1607000021; t.F_s__1607000021 = nil; s__1607000021__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000021__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__4)
															if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_a2g_world_A_const_45; tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__4))).Ref() } else { tmp6 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp6) { tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(f__4) } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(f__4) }
//line :33:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1607000020); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000021__1))) } else { s__1607000021__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000021__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_New() *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A) Invoke_O_O__O(self, s__1607000023__1 any) any { var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_New_O_O(self, s__1607000023__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A) Ctor_O_O(c__iter__1607000022, c__s__1607000023 any) { t.F_iter__1607000022 = c__iter__1607000022; t.F_s__1607000023 = c__s__1607000023 }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A) Invoke_O__O(self any) any { { var s__1607000023__1 any; var t_ any = t.F_s__1607000023; t.F_s__1607000023 = nil; s__1607000023__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000023__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000023__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000023__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000025__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_New_O_I_O(b__1607000025__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000022); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000025__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000023__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000025__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000022); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000023__3))) } else { s__1607000023__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000023__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :33:1
func A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A) Ctor_O_I_O(c__b__1607000025 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000025 = c__b__1607000025; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :33:1
func (t *A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A) Invoke_O__O(self any) any { { var i__1607000024__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000024__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000024__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_37.GetRawRoot__O()).Invoke_O__O(f__2)) { lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000025, f__2); i__1607000024__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000024__1); continue L1 } else { i__1607000024__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000024__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_ns_of_forms_A_New() *A_arbace_a2g_world_ns_of_forms_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Ctor() {}
//line :38:1
func (t *A_arbace_a2g_world_ns_of_forms_A) Invoke_O_O__O(self, forms__0 any) any { var f__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_ns_of_forms_fn__1607000038_A_New(); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_world_ns_of_forms_fn__1607000038_A_fn_class; if
											fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_a2g_world_ns_of_forms_fn__1607000038_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; f__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__0)); if
											jrt.A2g_Truth(f__2) { var n__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(n__3)) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(n__3) } else { return n__3 } } else { return nil } }
//line :39:1
func A_arbace_a2g_world_ns_of_forms_fn__1607000038_A_New() *A_arbace_a2g_world_ns_of_forms_fn__1607000038_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_ns_of_forms_fn__1607000038_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000038_A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_world_ns_of_forms_fn__1607000038_A) Invoke_O_O__O(self, p1__1607000037_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(p1__1607000037_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(p1__1607000037_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_84, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(p1__1607000037_SHARP___1)))).Ref() } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_world_top_names_A_New() *A_arbace_a2g_world_top_names_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_a2g_world_top_names_A) Ctor() {}
//line :42:1
func (t *A_arbace_a2g_world_top_names_A) Invoke_O_O_O__O(self, nsname__0, forms__1 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A_New_O(nsname__0); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A_fn_class; if


	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()).Invoke_O__O(forms__1)) }
//line :45:1
func A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A_New_O(p0 any) *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A{}; t.Ctor_O(p0); return t }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A) Invoke_O_O__O(self, s__1607000042__1 any) any { var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A_New_O_O_O(self, t.F_nsname, s__1607000042__1); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :45:1
func A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A) Ctor_O_O_O(c__iter__1607000041, c__nsname, c__s__1607000042 any) { t.F_iter__1607000041 = c__iter__1607000041; t.F_nsname = c__nsname; t.F_s__1607000042 = c__s__1607000042 }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A) Invoke_O__O(self any) any { { var s__1607000042__1 any; var t_ any = t.F_s__1607000042; t.F_s__1607000042 = nil; s__1607000042__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000042__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000042__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000042__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000042__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000044__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A_New_O_O_I_O(b__1607000044__6, t.F_nsname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000041); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000044__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000042__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000044__6), nil) } } else { var cf__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000042__3); var vec__1607000052__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__4); var seq__1607000053__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000052__5); var first__1607000054__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000053__6); var seq__1607000053__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000053__6); var nm__9 any = first__1607000054__7; var more__10 any = seq__1607000053__8; var more__11 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10))) { more__11 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__10) } else { more__11 = more__10 }
//line :45:1
	var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_50; var pkg__12 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(more__11))); var s__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(nm__9); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()); var tmp6 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O__O(pkg__12)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(pkg__12))) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(pkg__12), Lit_100, Lit_99), nil)) } else { tmp8 = nil }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), s__13)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(s__13, Lit_100)) {
		tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(s__13, Lit_100, Lit_99) } else {
//line :50:1
			if A_arbace_a2g_world_A_const_56 != nil {

				tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_100, Lit_99), nil, s__13)).Ref() } else {
//line :50:1
					tmp6 = nil } } }
//line :45:1
	var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1607000041); return tmp5.Invoke_O_O__O(tmp6, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000042__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :45:1
func A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A) Ctor_O_O_I_O(c__b__1607000044, c__nsname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000044 = c__b__1607000044; t.F_nsname = c__nsname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A) Invoke_O__O(self any) any { { var i__1607000043__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000043__1)); var vec__1607000048__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__2); var seq__1607000049__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000048__3); var first__1607000050__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000049__4); var seq__1607000049__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000049__4); var nm__7 any = first__1607000050__5; var more__8 any = seq__1607000049__6; var more__9 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__8))) { more__9 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__8) } else { more__9 = more__8 }
//line :45:1
	var tmp2 *lang.Keyword = A_arbace_a2g_world_A_const_50; var pkg__10 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(more__9))); var s__11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(nm__7); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp4 any = t.F_b__1607000044; var tmp5 any




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_53.GetRawRoot__O()).Invoke_O__O(pkg__10)) { var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(pkg__10))) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(pkg__10), Lit_100, Lit_99), nil)) } else { tmp7 = nil }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), s__11)).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_100)) {
		tmp5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(s__11, Lit_100, Lit_99) } else {
//line :50:1
			if A_arbace_a2g_world_A_const_56 != nil {

				tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_100, Lit_99), nil, s__11)).Ref() } else {
//line :50:1
					tmp5 = nil } } }
//line :45:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1607000043__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000043__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_source_files_A_New() *A_arbace_a2g_world_source_files_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_world_source_files_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_world_source_files_A) Invoke_O_O__O(self, p__1607000060__0 any) any { var map__1607000061__2 any = p__1607000060__0; var map__1607000061__3 any; if lang.ISeq_InstanceOf(map__1607000061__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000061__2)) { map__1607000061__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000061__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000061__2)) { map__1607000061__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000061__2) } else { lang.PersistentArrayMap_Init(); map__1607000061__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000061__3 = map__1607000061__2 }; var root__4 any = lang.RT_Get_O_O__O(map__1607000061__3, A_arbace_a2g_world_A_const_60); var dirs__5 any = lang.RT_Get_O_O__O(map__1607000061__3, A_arbace_a2g_world_A_const_61); var tree__6 any = lang.RT_Get_O_O__O(map__1607000061__3, A_arbace_a2g_world_A_const_62); var files__7 any = lang.RT_Get_O_O__O(map__1607000061__3, A_arbace_a2g_world_A_const_63); if



	jrt.A2g_Truth(files__7) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_66.GetRawRoot__O(), files__7) } else {
//line :58:1
			if jrt.A2g_Truth(tree__6) {






				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_51.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_67.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_source_files_fn__1607000063_A_New(); var tmp5 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000063_A_fn_class
//line :64:1
				if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_a2g_world_source_files_fn__1607000063_A_fn_class = fncls__12d; tmp5 = fncls__12d } else { tmp5 = fncls__12 }
				var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_source_files_fn__1607000065_A_New(); var tmp9 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_world_source_files_fn__1607000065_A_fn_class
//line :61:1
				if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_a2g_world_source_files_fn__1607000065_A_fn_class = fncls__13d; tmp9 = fncls__13d } else { tmp9 = fncls__13
				}


				return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()).Invoke_O__O(root__4))))) } else {
//line :58:1
					if A_arbace_a2g_world_A_const_56 != nil {










						var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_world_A_const_51.GetRawRoot__O(); var tmp12 any; var iter__1927001039__auto____8 any; var tmp13 any = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A_New_O(root__4); var tmp14 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A_fn_class
//line :66:1
						if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A_fn_class = fncls__18d; tmp14 = fncls__18d } else { tmp14 = fncls__18 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(dirs__5)


						return tmp10.Invoke_O_O__O(tmp11, tmp12) } else {
//line :58:1
							return nil } } } }


func A_arbace_a2g_world_source_files_fn__1607000065_A_New() *A_arbace_a2g_world_source_files_fn__1607000065_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000065_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_a2g_world_source_files_fn__1607000065_A) Ctor() {}
//line :61:1
func (t *A_arbace_a2g_world_source_files_fn__1607000065_A) Invoke_O_O__O(self, p1__1607000058_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1607000058_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { return lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1607000058_SHARP___1)).GetName__String().Ref(), Lit_105) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }


func A_arbace_a2g_world_source_files_fn__1607000063_A_New() *A_arbace_a2g_world_source_files_fn__1607000063_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_fn__1607000063_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_a2g_world_source_files_fn__1607000063_A) Ctor() {}
//line :64:1
func (t *A_arbace_a2g_world_source_files_fn__1607000063_A) Invoke_O_O__O(self, p1__1607000059_SHARP___1 any) any { var f__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_68.GetRawRoot__O()).Invoke_O__O(p1__1607000059_SHARP___1); var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_a2g_world_A_const_69; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__2))).Ref() } else { return and__1927000168__auto____3 } }

func A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A_New_O(p0 any) *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A) Invoke_O_O__O(self, s__1607000068__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A_New_O_O_O(s__1607000068__1, self, t.F_root); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A) Ctor_O_O_O(c__s__1607000068, c__iter__1607000067, c__root any) { t.F_s__1607000068 = c__s__1607000068; t.F_iter__1607000067 = c__iter__1607000067; t.F_root = c__root }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A) Invoke_O__O(self any) any { { var s__1607000068__1 any; var t_ any = t.F_s__1607000068; t.F_s__1607000068 = nil; s__1607000068__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000068__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A_New(); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()).Invoke_O_O__O(t.F_root, d__4))).ListFiles__File1().Ref())); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000067); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000068__1))) } else { s__1607000068__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000068__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :66:1
func A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A_New() *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A) Ctor() {}
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A) Invoke_O_O__O(self, s__1607000070__1 any) any { var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A_New_O_O(self, s__1607000070__1); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A) Ctor_O_O(c__iter__1607000069, c__s__1607000070 any) { t.F_iter__1607000069 = c__iter__1607000069; t.F_s__1607000070 = c__s__1607000070 }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A) Invoke_O__O(self any) any { { var s__1607000070__1 any; var t_ any = t.F_s__1607000070; t.F_s__1607000070 = nil; s__1607000070__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000070__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000070__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000070__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000070__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000072__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A_New_O_I_O(b__1607000072__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000069); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000072__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000070__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000072__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000070__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
																				if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_105) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :66:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1607000069); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000070__3))) } else { s__1607000070__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000070__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :66:1
func A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A) Ctor_O_I_O(c__b__1607000072 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000072 = c__b__1607000072; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A) Invoke_O__O(self any) any { { var i__1607000071__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000071__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000071__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																						if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_70.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_105) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :66:1
	if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1607000072, f__2); i__1607000071__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000071__1); continue L1 } else { i__1607000071__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000071__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_world_head_name_A_New() *A_arbace_a2g_world_head_name_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_head_name_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_a2g_world_head_name_A) Ctor() {}
//line :75:1
func (t *A_arbace_a2g_world_head_name_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_a2g_world_param_key_A_New() *A_arbace_a2g_world_param_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_a2g_world_param_key_A) Ctor() {}
//line :77:1
func (t *A_arbace_a2g_world_param_key_A) Invoke_O_O__O(self, f__0 any) any { var h__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(f__0); var G__1607000087__3_ any = h__2; switch



	lang.Util_Hash_O__I(G__1607000087__3_) >> 13 & 15 { case 5: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_19) { var nm__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_30.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(f__0))); var tmp1 any = A_arbace_a2g_world_A_const_73; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__4)) }; case 6: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_85) { var params__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_49.GetRawRoot__O(); var tmp5 any = A_arbace_a2g_world_param_key_fn__1607000088_A_New_O(f__0); var tmp6 *jrt.Class
		var fncls__20 /*line :81:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000088_A_fn_class












		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_a2g_world_param_key_fn__1607000088_A_fn_class = fncls__20d; tmp6 = fncls__20d } else { tmp6 = fncls__20 }; params__4 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()))
//line :81:1
		var tmp7 any = A_arbace_a2g_world_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_world_param_key_fn__1607000090_A_New(); var tmp10 *jrt.Class
		var fncls__21 /*line :81:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000090_A_fn_class
















		if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_a2g_world_param_key_fn__1607000090_A_fn_class = fncls__21d; tmp10 = fncls__21d } else { tmp10 = fncls__21 }
//line :81:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__4))) }; case 7: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_12) { var tmp11 any = A_arbace_a2g_world_A_const_81; return lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(f__0))) }; case 10: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_4) { var tmp12 any = A_arbace_a2g_world_A_const_83; var tmp13 any; var tmp14 *lang.Keyword = A_arbace_a2g_world_A_const_84; var or__1927000174__auto____4 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0))


















			if jrt.A2g_Truth(or__1927000174__auto____4) { tmp13 = or__1927000174__auto____4 } else { tmp13 = A_arbace_a2g_world_A_const_85 }
//line :81:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13) }; case 13: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_88) { var vec__1607000093__4 any = f__0; var seq__1607000094__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000093__4); var first__1607000095__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000094__5); var seq__1607000094__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000094__5); var ___8 any = first__1607000095__6; var first__1607000095__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000094__7); var seq__1607000094__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000094__7); var nm__11 any = first__1607000095__9; var more__12 any = seq__1607000094__10; var more__13 any; var tmp15 any = A_arbace_a2g_world_param_key_fn__1607000096_A_New_O(more__12); var tmp16 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000096_A_fn_class; _ = ___8



				if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_a2g_world_param_key_fn__1607000096_A_fn_class = fncls__22d; tmp16 = fncls__22d } else { tmp16 = fncls__22 }; more__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :81:1
				var params__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_49.GetRawRoot__O(), more__13)); var tmp17 *lang.Keyword = A_arbace_a2g_world_A_const_82; var static__15 bool = lang.RT_BooleanCast_O__Z(tmp17.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11))); var ps__16 any









				if static__15 { ps__16 = params__14 } else { ps__16 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__14) }
//line :81:1
				var tmp18 any = A_arbace_a2g_world_A_const_86; var tmp19 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__11); var tmp20 any = jrt.Boolean_ValueOf_Z__Boolean(static__15).Ref(); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_a2g_world_param_key_fn__1607000098_A_New(); var tmp23 *jrt.Class
				var fncls__24 /*line :81:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000098_A_fn_class










				if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_a2g_world_param_key_fn__1607000098_A_fn_class = fncls__24d; tmp23 = fncls__24d } else { tmp23 = fncls__24 }
//line :81:1
				return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp18, tmp19, tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), ps__16)) }; case 14: if lang.Util_Equiv_O_O__Z(G__1607000087__3_, Lit_91) { var vec__1607000101__4 any = f__0; var seq__1607000102__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000101__4); var first__1607000103__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000102__5); var seq__1607000102__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000102__5); var ___8_2 any = first__1607000103__6; var first__1607000103__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000102__7); var seq__1607000102__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000102__7); var nm__11_2 any = first__1607000103__9; var more__12_2 any = seq__1607000102__10; var more__13_2 any; var tmp24 any = A_arbace_a2g_world_param_key_fn__1607000104_A_New_O(more__12_2); var tmp25 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_world_param_key_fn__1607000104_A_fn_class; _ = ___8_2



					if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_a2g_world_param_key_fn__1607000104_A_fn_class = fncls__23d; tmp25 = fncls__23d } else { tmp25 = fncls__23 }; more__13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil).Invoke__O()
//line :81:1
					var params__14_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_49.GetRawRoot__O(), more__13_2)); var tmp26 *lang.Keyword = A_arbace_a2g_world_A_const_82; var static__15_2 bool = lang.RT_BooleanCast_O__Z(tmp26.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11_2))); var ps__16_2 any









					if static__15_2 { ps__16_2 = params__14_2 } else { ps__16_2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(params__14_2) }
//line :81:1
					var tmp27 any = A_arbace_a2g_world_A_const_86; var tmp28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(nm__11_2); var tmp29 any = jrt.Boolean_ValueOf_Z__Boolean(static__15_2).Ref(); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_a2g_world_param_key_fn__1607000106_A_New(); var tmp32 *jrt.Class
					var fncls__25 /*line :81:1*/*jrt.Class = A_arbace_a2g_world_param_key_fn__1607000106_A_fn_class










					if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_a2g_world_param_key_fn__1607000106_A_fn_class = fncls__25d; tmp32 = fncls__25d } else { tmp32 = fncls__25 }
//line :81:1
					return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp27, tmp28, tmp29, tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), ps__16_2)) }; default:}; return nil }



func A_arbace_a2g_world_param_key_fn__1607000096_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000096_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000096_A{}; t.Ctor_O(p0); return t }
//line :85:1
func (t *A_arbace_a2g_world_param_key_fn__1607000096_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :85:1
func (t *A_arbace_a2g_world_param_key_fn__1607000096_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :86:1
			if A_arbace_a2g_world_A_const_56 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :86:1
					return nil } } } } }; /*line :85:1*/panic("a2g: unreachable") }
//line :85:1
func A_arbace_a2g_world_param_key_fn__1607000104_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000104_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000104_A{}; t.Ctor_O(p0); return t }
//line :85:1
func (t *A_arbace_a2g_world_param_key_fn__1607000104_A) Ctor_O(c__more any) { t.F_more = c__more }
//line :85:1
func (t *A_arbace_a2g_world_param_key_fn__1607000104_A) Invoke_O__O(self any) any { { var xs__1 any; var t_ any = t.F_more; t.F_more = nil; xs__1 = t_; var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp1 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :86:1
			if A_arbace_a2g_world_A_const_56 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :86:1
					return nil } } } } }; /*line :85:1*/panic("a2g: unreachable") }






func A_arbace_a2g_world_param_key_fn__1607000098_A_New() *A_arbace_a2g_world_param_key_fn__1607000098_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000098_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_a2g_world_param_key_fn__1607000098_A) Ctor() {}
//line :92:1
func (t *A_arbace_a2g_world_param_key_fn__1607000098_A) Invoke_O_O__O(self, p1__1607000085_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000099__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000085_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000099__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(G__1607000099__2_) } }
//line :92:1
func A_arbace_a2g_world_param_key_fn__1607000106_A_New() *A_arbace_a2g_world_param_key_fn__1607000106_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000106_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_a2g_world_param_key_fn__1607000106_A) Ctor() {}
//line :92:1
func (t *A_arbace_a2g_world_param_key_fn__1607000106_A) Invoke_O_O__O(self, p1__1607000085_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000107__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000085_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000107__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(G__1607000107__2_) } }

func A_arbace_a2g_world_param_key_fn__1607000088_A_New_O(p0 any) *A_arbace_a2g_world_param_key_fn__1607000088_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000088_A{}; t.Ctor_O(p0); return t }
//line :94:1
func (t *A_arbace_a2g_world_param_key_fn__1607000088_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :94:1
func (t *A_arbace_a2g_world_param_key_fn__1607000088_A) Invoke_O__O(self any) any { { var xs__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; xs__1 = tmp1.Invoke_O__O(tmp2); var acc__2 any; lang.PersistentVector_Init(); acc__2 = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_74.GetRawRoot__O()).Invoke_O__O(xs__1)) { return acc__2 } else { var tmp3 any = A_arbace_a2g_world_A_const_75; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)) {
												xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_77, xs__1), acc__2; continue L1 } else {
//line :95:1
			if A_arbace_a2g_world_A_const_56 != nil {

				xs__1, acc__2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__1), lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(acc__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1)); continue L1 } else {
//line :95:1
					return nil } } } } }; /*line :94:1*/panic("a2g: unreachable") }



func A_arbace_a2g_world_param_key_fn__1607000090_A_New() *A_arbace_a2g_world_param_key_fn__1607000090_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_param_key_fn__1607000090_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_a2g_world_param_key_fn__1607000090_A) Ctor() {}
//line :98:1
func (t *A_arbace_a2g_world_param_key_fn__1607000090_A) Invoke_O_O__O(self, p1__1607000086_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_80; var G__1607000091__2_ any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1607000086_SHARP___1)); if lang.Util_Identical_O_O__Z(G__1607000091__2_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(G__1607000091__2_) } }





func A_arbace_a2g_world_cut_key_A_New() *A_arbace_a2g_world_cut_key_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_cut_key_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_a2g_world_cut_key_A) Ctor() {}
//line :104:1
func (t *A_arbace_a2g_world_cut_key_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(x__0)
	if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_19, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :105:1
	if jrt.A2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :105:1
			var tmp2 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(x__0)


			if jrt.A2g_Truth(and__1927000168__auto____2_2) { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(x__0))).Ref() } else { tmp2 = and__1927000168__auto____2_2 }
//line :105:1
			if jrt.A2g_Truth(tmp2) { var tmp3 any = A_arbace_a2g_world_A_const_83; var tmp4 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(x__0)


				if jrt.A2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = A_arbace_a2g_world_A_const_85 }
//line :105:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(x__0))) {



					return lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_89, x__0)) } else {
//line :105:1
						if A_arbace_a2g_world_A_const_56 != nil { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())))) } else { return nil
						}
					}
				}
		}
}

func A_arbace_a2g_world_class_parts_A_New() *A_arbace_a2g_world_class_parts_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_class_parts_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_a2g_world_class_parts_A) Ctor() {}
//line :112:1
func (t *A_arbace_a2g_world_class_parts_A) Invoke_O_O__O(self, cf__0 any) any { var vec__1607000111__2 any = cf__0; var seq__1607000112__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000111__2); var first__1607000113__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000112__3); var seq__1607000112__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000112__3); var dc__6 any = first__1607000113__4; var first__1607000113__7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000112__5); var seq__1607000112__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000112__5); var nm__9 any = first__1607000113__7; var more__10 any = seq__1607000112__8; var vec__1607000114__11 any; if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10))) { vec__1607000114__11 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(more__10)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(more__10)) } else { var tmp1 *lang.PersistentVector; lang.PersistentVector_Init(); tmp1 = lang.PersistentVector_EMPTY; vec__1607000114__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp1.Ref(), more__10) }; var comps__12 any = /*line :112:1*/lang.RT_Nth_O_I_O__O(vec__1607000114__11, lang.RT_IntCast_J__I(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O(vec__1607000114__11, lang.RT_IntCast_J__I(1), nil); var vec__1607000117__14 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_52.GetRawRoot__O()).Invoke_O__O(more__13); var opts__15 any = lang.RT_Nth_O_I_O__O(vec__1607000117__14, lang.RT_IntCast_J__I(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O(vec__1607000117__14, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(dc__6, nm__9), comps__12, lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_93.GetRawRoot__O(), opts__15)), lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(members__16)) }







func A_arbace_a2g_world_apply_variant_A_New() *A_arbace_a2g_world_apply_variant_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_a2g_world_apply_variant_A) Ctor() {}
//line :120:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O_O_O_O__O(self, cf__0, vforms__1, prefix__2, variants_of__3, applied__4 any) any { var vec__1607000123__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_94.GetRawRoot__O()).Invoke_O__O(cf__0); var head__7 any = lang.RT_Nth_O_I_O__O(vec__1607000123__6, lang.RT_IntCast_J__I(0), nil); var members__8 any = lang.RT_Nth_O_I_O__O(vec__1607000123__6, lang.RT_IntCast_J__I(1), nil); var members__9 any; var n__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_97); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_apply_variant_fn__1607000126_A_New_O(n__9); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000126_A_fn_class; if










	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_a2g_world_apply_variant_fn__1607000126_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; members__9 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), members__8); var counts__10 any = /*line :120:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_102); var members__11 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_world_apply_variant_fn__1607000128_A_New_O(counts__10); var tmp6 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000128_A_fn_class; if
















	fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_a2g_world_apply_variant_fn__1607000128_A_fn_class = fncls__31d; tmp6 = fncls__31d } else { tmp6 = fncls__31 }; members__11 = /*line :136:1*/tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), members__9, vforms__1); var members__12 any; if

















	jrt.A2g_Truth(variants_of__3) {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000137_A_New_O_O_O(variants_of__3, prefix__2, applied__4); var tmp9 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000137_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_a2g_world_apply_variant_fn__1607000137_A_fn_class = fncls__32d; tmp9 = fncls__32d } else { tmp9 = fncls__32 }; members__12 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), members__11) } else {
//line :154:1
			members__12 = members__11 }; return /*line :120:1*/ lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_world_A_const_111.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_113.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(head__7, members__12)), lang.RT_Meta_O__IPersistentMap(cf__0)), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(counts__10)) }
//line :120:1
func (t *A_arbace_a2g_world_apply_variant_A) Invoke_O_O_O__O(self, cf__0, vforms__1 any) any {





	return lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()).Invoke_O_O_O_O_O__O(cf__0, vforms__1, nil, nil, nil)
}



func A_arbace_a2g_world_apply_variant_fn__1607000126_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000126_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000126_A{}; t.Ctor_O(p0); return t }
//line :131:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000126_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :131:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000126_A) Invoke_O_O__O(self, m__1 any) any { if lang.Util_Equiv_O_O__Z(Lit_4, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(m__1)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_98.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_99.GetRawRoot__O(); var tmp3 any = A_arbace_a2g_world_A_const_84; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp5 any = t.F_n; return tmp1.Invoke_O_O_O_O__O(m__1, tmp2, tmp3, tmp4.Invoke_O_O__O(tmp5, A_arbace_a2g_world_A_const_101.GetRawRoot__O())) } else {
//line :131:1
		return m__1 } }





func A_arbace_a2g_world_apply_variant_fn__1607000128_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000128_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000128_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_A) Ctor_O(c__counts any) { t.F_counts = c__counts }
//line :137:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_A) Invoke_O_O_O__O(self, ms__1, vf__2 any) any { var G__1607000129__3_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(vf__2); switch
													lang.Util_Hash_O__I(G__1607000129__3_) { case 96417: if lang.Util_Equiv_O_O__Z(G__1607000129__3_, Lit_5) {







		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp2 any = t.F_counts; var tmp3 any = A_arbace_a2g_world_A_const_105.GetRawRoot__O(); var tmp4 any = A_arbace_a2g_world_A_const_106; tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_a2g_world_A_const_101.GetRawRoot__O()); return lang.IFn_Cast(A_arbace_a2g_world_A_const_13.GetRawRoot__O()).Invoke_O_O__O(ms__1, lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(vf__2)) }
//line :138:1
	case 98882: if lang.Util_Equiv_O_O__Z(G__1607000129__3_, Lit_6) { var k__4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_103.GetRawRoot__O()); var tmp6 any


		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(vf__2))) { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(vf__2) } else { tmp6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(vf__2) }; k__4 = tmp5.Invoke_O__O(tmp6)
//line :138:1
		var hit__5 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_104.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A_New_O(k__4); var tmp9 *jrt.Class
		var fncls__28 /*line :138:1*/*jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A_fn_class



		if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A_fn_class = fncls__28d; tmp9 = fncls__28d } else { tmp9 = fncls__28 }; hit__5 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ms__1)
		if jrt.A2g_Truth(hit__5) { } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp11 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(vf__2)))).Ref(); var tmp12 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp12 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp10.Invoke_O_O__O(tmp11, tmp12.Ref())))) }
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp14 any = t.F_counts; var tmp15 any = A_arbace_a2g_world_A_const_105.GetRawRoot__O(); var tmp16 any = A_arbace_a2g_world_A_const_107; tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, A_arbace_a2g_world_A_const_101.GetRawRoot__O())
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_67.GetRawRoot__O()); var tmp19 any = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A_New_O(k__4); var tmp20 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A_fn_class = fncls__29d; tmp20 = fncls__29d } else { tmp20 = fncls__29 }; return tmp17.Invoke_O__O(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), ms__1)) }
//line :138:1
	default:}; var k__4_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(vf__2); var i__5 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_108.GetRawRoot__O()); var tmp23 any = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A_New_O(k__4_2); var tmp24 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A_fn_class; if









	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A_fn_class = fncls__30d; tmp24 = fncls__30d } else { tmp24 = fncls__30 }; i__5 = tmp21.Invoke_O__O(tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), ms__1)); if
	jrt.A2g_Truth(i__5) { } else { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_88.GetRawRoot__O()); var tmp26 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_90.GetRawRoot__O()).Invoke_O__O(k__4_2))).Ref(); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp25.Invoke_O_O__O(tmp26, tmp27.Ref())))) }; var tmp28 lang.IFn =
	lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp29 any = t.F_counts; var tmp30 any = A_arbace_a2g_world_A_const_105.GetRawRoot__O(); var tmp31 any = A_arbace_a2g_world_A_const_109; tmp28.Invoke_O_O_O_O__O(tmp29, tmp30, tmp31, A_arbace_a2g_world_A_const_101.GetRawRoot__O()); return /*line :151:1*/ lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(ms__1, i__5, vf__2) }
//line :142:1
func A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :142:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A) Invoke_O_O__O(self, p1__1607000121_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(p1__1607000121_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :145:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A) Invoke_O_O__O(self, p1__1607000122_SHARP___1 any) any { var tmp1 any = t.F_k; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(p1__1607000122_SHARP___1))).Ref() }


func A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A_New_O(p0 any) *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A{}; t.Ctor_O(p0); return t }
//line :148:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :148:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A) Invoke_O_O_O__O(self, i__1, m__2 any) any { var tmp1 any = t.F_k; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_a2g_world_A_const_87.GetRawRoot__O()).Invoke_O__O(m__2)) { return i__1 } else { return nil } }






func A_arbace_a2g_world_apply_variant_fn__1607000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_apply_variant_fn__1607000137_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_apply_variant_fn__1607000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :155:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000137_A) Ctor_O_O_O(c__variants_of, c__prefix, c__applied any) { t.F_variants_of = c__variants_of; t.F_prefix = c__prefix; t.F_applied = c__applied }
//line :155:1
func (t *A_arbace_a2g_world_apply_variant_fn__1607000137_A) Invoke_O_O__O(self, m__1 any) any {
	if lang.Util_Equiv_O_O__Z(Lit_12, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(m__1)) { var tmp1 any = t.F_prefix; var nn__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, tmp1, nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_46.GetRawRoot__O()).Invoke_O__O(m__1)))).Ref(); var vfs__3 any = lang.IFn_Cast(t.F_variants_of).Invoke_O__O(nn__2); var vec__1607000138__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()); var tmp3 any
		var or__1927000174__auto____4 any = vfs__3

		if jrt.A2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY.Ref() }; vec__1607000138__4 = tmp2.Invoke_O_O_O_O_O__O(m__1, tmp3, nn__2, t.F_variants_of, t.F_applied)
//line :156:1
		var m2__5 any = lang.RT_Nth_O_I_O__O(vec__1607000138__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1607000138__4, lang.RT_IntCast_J__I(1), nil)



		if jrt.A2g_Truth(vfs__3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp5 any = t.F_applied; tmp4.Invoke_O_O_O_O__O(tmp5, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), nn__2, c__6) }
//line :156:1
		return m2__5 } else { return m__1
		}
}








func A_arbace_a2g_world_read_variants_A_New() *A_arbace_a2g_world_read_variants_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_a2g_world_read_variants_A) Ctor() {}
//line :167:1
func (t *A_arbace_a2g_world_read_variants_A) Invoke_O_O__O(self, files__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000143_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000143_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_a2g_world_read_variants_fn__1607000143_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O__O(tmp4, tmp5.Ref(), files__0) }
//line :173:1
func A_arbace_a2g_world_read_variants_fn__1607000143_A_New() *A_arbace_a2g_world_read_variants_fn__1607000143_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000143_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000143_A) Ctor() {}
//line :173:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000143_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any { var forms__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_114.GetRawRoot__O()).Invoke_O__O(f__2); var nsname__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_115.GetRawRoot__O()).Invoke_O__O(forms__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A_New_O(nsname__4); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A_fn_class; if


	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1, forms__3) }
//line :176:1
func A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A_New_O(p0 any) *A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A) Ctor_O(c__nsname any) { t.F_nsname = c__nsname }
//line :176:1
func (t *A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A) Invoke_O_O_O__O(self, acc__1, fm__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__2)
	if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_98, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp1 = and__1927000168__auto____3 }
//line :177:1
	if jrt.A2g_Truth(tmp1) { var vec__1607000145__3 any = fm__2; var seq__1607000146__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(vec__1607000145__3); var first__1607000147__5 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000146__4); var seq__1607000146__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000146__4); var ___7 any = first__1607000147__5; var first__1607000147__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq__1607000146__6); var seq__1607000146__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq__1607000146__6); var cls__10 any = first__1607000147__8; var members__11 any = seq__1607000146__9; var n__12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_54.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(t.F_nsname)), Lit_100, Lit_99), nil, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(cls__10))).Ref(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_105.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_world_A_const_117.GetRawRoot__O(); var tmp5 *lang.PersistentVector; _ = ___7



		lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp2.Invoke_O_O_O_O__O(acc__1, n__12, tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()), members__11) } else {
//line :177:1
			var tmp6 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__2)




			if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_101, lang.IFn_Cast(A_arbace_a2g_world_A_const_72.GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp6 = and__1927000168__auto____3_2 }
//line :177:1
			if jrt.A2g_Truth(tmp6) {





				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_105.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_world_A_const_118; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_116.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_world_A_const_117.GetRawRoot__O(); var tmp11 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp11 = lang.PersistentHashSet_EMPTY; return tmp7.Invoke_O_O_O_O__O(acc__1, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Ref()), lang.IFn_Cast(A_arbace_a2g_world_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_51.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(fm__2))) } else {
//line :177:1
					if A_arbace_a2g_world_A_const_56 != nil { return acc__1 } else { return nil
					}
				}
		}
}






func A_arbace_a2g_world_new_unit_A_New() *A_arbace_a2g_world_new_unit_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_new_unit_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_a2g_world_new_unit_A) Ctor() {}
//line :188:1
func (t *A_arbace_a2g_world_new_unit_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_a2g_world_A_const_119; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp2.Invoke_O__O(tmp3.Ref()); var tmp5 any = A_arbace_a2g_world_A_const_120; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 any = A_arbace_a2g_world_A_const_121; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 any = A_arbace_a2g_world_A_const_122; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 any = A_arbace_a2g_world_A_const_123; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp19 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp19 = lang.PersistentHashSet_EMPTY; var tmp20 any = tmp18.Invoke_O__O(tmp19.Ref()); var tmp21 any = A_arbace_a2g_world_A_const_124; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 any = A_arbace_a2g_world_A_const_125; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp12, tmp13, tmp16, tmp17, tmp20, tmp21, tmp24, tmp25, tmp26.Invoke_O__O(tmp27.Ref()))) }








func A_arbace_a2g_world_id_space_A_New() *A_arbace_a2g_world_id_space_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_id_space_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_a2g_world_id_space_A) Ctor() {}
//line :197:1
func (t *A_arbace_a2g_world_id_space_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	tmp1 = jrt.NN(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_93.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_126))).GetField_String__Field(Lit_22)).Get_O__O(nil)
//line :197:1
	return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }




func A_arbace_a2g_world_load_world_A_New() *A_arbace_a2g_world_load_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_a2g_world_load_world_A) Ctor() {}
//line :202:1
func (t *A_arbace_a2g_world_load_world_A) DoInvoke_O_O_O__O(self, inputs__0, p__1607000155__1 any) any { var map__1607000156__3 any = p__1607000155__1; var map__1607000156__4 any; if lang.ISeq_InstanceOf(map__1607000156__3) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { map__1607000156__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000156__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000156__3)) { map__1607000156__4 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000156__3) } else { lang.PersistentArrayMap_Init(); map__1607000156__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000156__4 = map__1607000156__3 }; var variant_files__5 any = lang.RT_Get_O_O__O(map__1607000156__4, A_arbace_a2g_world_A_const_127); var late_inputs__6 any = lang.RT_Get_O_O__O(map__1607000156__4, A_arbace_a2g_world_A_const_128); var wait__7 any = lang.RT_Get_O_O__O(map__1607000156__4, A_arbace_a2g_world_A_const_129); var variants__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_130.GetRawRoot__O()).Invoke_O__O(variant_files__5); var erased__9 any; var tmp1 any = A_arbace_a2g_world_A_const_118; var tmp2 *lang.PersistentHashSet;














	lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; erased__9 = lang.RT_Get_O_O_O__O(variants__8, tmp1, tmp2.Ref()); var variants__10 any = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_131.GetRawRoot__O()).Invoke_O_O__O(variants__8, A_arbace_a2g_world_A_const_118); var applied__11 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap;
















	lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; applied__11 = tmp3.Invoke_O__O(tmp4.Ref()); var parse__12 any; var tmp5 any = /*line :202:1*/A_arbace_a2g_world_load_world_parse__1607000158_A_New(); var tmp6 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000158_A_fn_class; if



















	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_world_load_world_parse__1607000158_A_fn_class = fncls__37d; tmp6 = fncls__37d } else { tmp6 = fncls__37 }; parse__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var parsed__13 any = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(parse__12).Invoke_O__O(inputs__0)); var top_set__14 any; var tmp7 any = A_arbace_a2g_world_load_world_top_set__1607000164_A_New(); var tmp8 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_a2g_world_load_world_top_set__1607000164_A_fn_class; if

























	fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_world_load_world_top_set__1607000164_A_fn_class = fncls__39d; tmp8 = fncls__39d } else { tmp8 = fncls__39 }; top_set__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tops__15 any = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(top_set__14).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13))); var top_of__16 any; var tmp9 any = A_arbace_a2g_world_load_world_top_of__1607000171_A_New(); var tmp10 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_a2g_world_load_world_top_of__1607000171_A_fn_class; if



























	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_world_load_world_top_of__1607000171_A_fn_class = fncls__40d; tmp10 = fncls__40d } else { tmp10 = fncls__40 }; top_of__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var from_source__17 any; var tmp11 any = /*line :202:1*/A_arbace_a2g_world_load_world_from_source__1607000173_A_New_O_O(tops__15, top_of__16); var tmp12 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_world_load_world_from_source__1607000173_A_fn_class; if




























	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_world_load_world_from_source__1607000173_A_fn_class = fncls__41d; tmp12 = fncls__41d } else { tmp12 = fncls__41 }; from_source__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var cs__18 any; var tmp13 lang.IFn = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp14 *lang.PersistentArrayMap;





























	lang.PersistentArrayMap_Init(); tmp14 = lang.PersistentArrayMap_EMPTY; cs__18 = tmp13.Invoke_O__O(tmp14.Ref()); var unit__19 any = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_143.GetRawRoot__O()).Invoke__O(); var failed__20 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp16 *lang.PersistentVector;































	lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; failed__20 = tmp15.Invoke_O__O(tmp16.Ref());
	lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_a2g_world_A_const_194, cs__18, A_arbace_a2g_world_A_const_188, unit__19, A_arbace_a2g_world_A_const_195, from_source__17)); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000175_A_New_O_O_O_O_O_O_O_O_O_O(parsed__13, variants__10, parse__12, failed__20, top_set__14, wait__7, tops__15, unit__19, applied__11, late_inputs__6); var tmp18 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_world_load_world_fn__1607000175_A_fn_class = fncls__78d; tmp18 = fncls__78d } else { tmp18 = fncls__78 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O(); var seq_1607000326__21 any = /*line :202:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_196.GetRawRoot__O()).Invoke_O__O(variants__10)); var chunk_1607000327__22 any; var count_1607000328__23 int64 = 0; var i_1607000329__24 int64 = 0; L1: for {














































































































































		if lang.Numbers_Lt_J_J__Z(i_1607000329__24, count_1607000328__23) { var n__25 any = lang.Indexed_Cast(chunk_1607000327__22).Nth_I__O(lang.RT_IntCast_J__I(i_1607000329__24)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), n__25))) {
			lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(failed__20, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__25, Lit_28))
//line :345:1
			seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, i_1607000329__24 = seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, lang.Numbers_Unchecked_inc_J__J(i_1607000329__24); continue L1 } else { seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, i_1607000329__24 = seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, lang.Numbers_Unchecked_inc_J__J(i_1607000329__24); continue L1 } } else { var temp__1927000414__auto____25 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000326__21); if jrt.A2g_Truth(temp__1927000414__auto____25) { var seq_1607000326__26 any = temp__1927000414__auto____25; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26)) { var c__1927000678__auto____27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26); seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, i_1607000329__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26), c__1927000678__auto____27, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), n__27))) {
				lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()).Invoke_O_O_O__O(failed__20, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(n__27, Lit_28))
//line :345:1
				seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, i_1607000329__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26), nil, 0, 0; continue L1 } else { seq_1607000326__21, chunk_1607000327__22, count_1607000328__23, i_1607000329__24 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000326__26), nil, 0, 0; continue L1 } } } }
//line :202:1
		break L1 }; var tmp19 any = A_arbace_a2g_world_A_const_144; var tmp20 any = A_arbace_a2g_world_A_const_145; var tmp21 any = A_arbace_a2g_world_A_const_146; var tmp22 any = A_arbace_a2g_world_A_const_63; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_79.GetRawRoot__O()); var tmp24 any = A_arbace_a2g_world_A_const_135; var tmp25 any = tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13)); var tmp26 any = A_arbace_a2g_world_A_const_147; var tmp27 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(tops__15); var tmp28 any = A_arbace_a2g_world_A_const_148; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_117.GetRawRoot__O()); var tmp30 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp30 = lang.PersistentArrayMap_EMPTY; var tmp31 any = tmp30.Ref(); var tmp32 any; var iter__1927001039__auto____21 any; var tmp33 any = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A_New(); var tmp34 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A_fn_class; if


















































































































































	fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A_fn_class = fncls__83d; tmp34 = fncls__83d } else { tmp34 = fncls__83 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); tmp32 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(parsed__13)); var tmp35 any = /*line :202:1*/tmp29.Invoke_O_O__O(tmp31, tmp32); var tmp36 any = A_arbace_a2g_world_A_const_149; var tmp37 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_197.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_32.GetRawRoot__O(), A_arbace_a2g_world_A_const_46.GetRawRoot__O()), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(failed__20))); var tmp38 any = A_arbace_a2g_world_A_const_150; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, cs__18, tmp20, unit__19, tmp21, from_source__17, tmp22, tmp25, tmp26, tmp27, tmp28, tmp35, tmp36, tmp37, tmp38, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(applied__11), A_arbace_a2g_world_A_const_151, erased__9)) }



















func A_arbace_a2g_world_load_world_parse__1607000158_A_New() *A_arbace_a2g_world_load_world_parse__1607000158_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000158_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_A) Ctor() {}
//line :222:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_A) Invoke_O_O__O(self, ins__1 any) any { var fs__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_133.GetRawRoot__O(), ins__1)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_132.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_134.GetRawRoot__O()).Invoke__O(); var tmp3 any = A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A_New(); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A_fn_class; if

	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_65.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A_New_O(fs__2); var tmp8 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A_fn_class; if

	fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A_fn_class = fncls__36d; tmp8 = fncls__36d } else { tmp8 = fncls__36 }; return /*line :224:1*/ tmp1.Invoke_O_O_O_O__O(tmp2, tmp5, fs__2, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_a2g_world_A_const_138.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(fs__2)).Ref()))) }
//line :224:1
func A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A_New() *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A) Ctor() {}
//line :224:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A) Invoke_O_O__O(self, f__1 any) any { var forms__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_114.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any = A_arbace_a2g_world_A_const_135; var tmp2 any = A_arbace_a2g_world_A_const_136; var tmp3 any = A_arbace_a2g_world_A_const_137; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, f__1, tmp2, forms__2, tmp3, lang.IFn_Cast(A_arbace_a2g_world_A_const_115.GetRawRoot__O()).Invoke_O__O(forms__2))) }

func A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A_New_O(p0 any) *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A{}; t.Ctor_O(p0); return t }
//line :226:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :226:1
func (t *A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A) Invoke_O_O__O(self, p1__1607000153_SHARP___1 any) any { var tmp1 any = t.F_fs; return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(p1__1607000153_SHARP___1))))).Length__J())).Ref() }

func A_arbace_a2g_world_load_world_top_set__1607000164_A_New() *A_arbace_a2g_world_load_world_top_set__1607000164_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_set__1607000164_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000164_A) Ctor() {}
//line :228:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000164_A) Invoke_O_O__O(self, ps__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_139.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_92.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A_New(); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ps__1)) }
//line :228:1
func A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A_New() *A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A) Ctor() {}
//line :228:1
func (t *A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A) Invoke_O_O__O(self, p__1607000165__1 any) any { var map__1607000167__2 any = p__1607000165__1; var map__1607000167__3 any; if lang.ISeq_InstanceOf(map__1607000167__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000167__2)) { map__1607000167__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000167__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000167__2)) { map__1607000167__3 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000167__2) } else { lang.PersistentArrayMap_Init(); map__1607000167__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000167__3 = map__1607000167__2 }; var ns__4 any = lang.RT_Get_O_O__O(map__1607000167__3, A_arbace_a2g_world_A_const_137); var forms__5 any = lang.RT_Get_O_O__O(map__1607000167__3, A_arbace_a2g_world_A_const_136); if jrt.A2g_Truth(ns__4) { return lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()).Invoke_O_O__O(ns__4, forms__5) } else { return nil } }

func A_arbace_a2g_world_load_world_top_of__1607000171_A_New() *A_arbace_a2g_world_load_world_top_of__1607000171_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_top_of__1607000171_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000171_A) Ctor() {}
//line :230:1
func (t *A_arbace_a2g_world_load_world_top_of__1607000171_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).IndexOf_String__I(Lit_13); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__1 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_85; return tmp1.Invoke_O_O_O__O(n__1, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }
func A_arbace_a2g_world_load_world_from_source__1607000173_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_from_source__1607000173_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_from_source__1607000173_A{}; t.Ctor_O_O(p0, p1); return t }
//line :231:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000173_A) Ctor_O_O(c__tops, c__top_of any) { t.F_tops = c__tops; t.F_top_of = c__top_of }
//line :231:1
func (t *A_arbace_a2g_world_load_world_from_source__1607000173_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_142.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_tops), lang.IFn_Cast(t.F_top_of).Invoke_O__O(n__1)) }



func A_arbace_a2g_world_load_world_fn__1607000175_A_New_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 any) *A_arbace_a2g_world_load_world_fn__1607000175_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :235:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_A) Ctor_O_O_O_O_O_O_O_O_O_O(c__parsed, c__variants, c__parse, c__failed, c__top_set, c__wait, c__tops, c__unit, c__applied, c__late_inputs any) { t.F_parsed = c__parsed; t.F_variants = c__variants; t.F_parse = c__parse; t.F_failed = c__failed; t.F_top_set = c__top_set; t.F_wait = c__wait; t.F_tops = c__tops; t.F_unit = c__unit; t.F_applied = c__applied; t.F_late_inputs = c__late_inputs }
//line :235:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_A) Invoke_O__O(self any) any { var tmp1 any; tmp57 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O()






	if jrt.A2g_Truth(temp__1927000414__auto____3) { var space__4 any = temp__1927000414__auto____3
		jrt.ThreadLocal_Cast(space__4).Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_186.GetRawRoot__O()))) }
//line :235:1
	var t__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref()); var laps__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()); var tmp3 *lang.PersistentVector









	lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; laps__4 = tmp2.Invoke_O__O(tmp3.Ref())
//line :235:1
	var lap__5 any; var tmp4 any = A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A_New_O_O(t__3, laps__4); var tmp5 *jrt.Class
	var fncls__42 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A_fn_class










	if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A_fn_class = fncls__42d; tmp5 = fncls__42d } else { tmp5 = fncls__42 }; lap__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :235:1
	var enter_BANG___6 any; var tmp6 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A_New_O_O_O(t.F_variants, t.F_failed, t.F_applied); var tmp7 *jrt.Class
	var fncls__53 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A_fn_class











	if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A_fn_class = fncls__53d; tmp7 = fncls__53d } else { tmp7 = fncls__53 }; enter_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :235:1
	var resolve_BANG___7 any; var tmp8 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A_New_O_O(t.F_failed, lap__5); var tmp9 *jrt.Class
	var fncls__62 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A_fn_class






























	if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A_fn_class = fncls__62d; tmp9 = fncls__62d } else { tmp9 = fncls__62 }; resolve_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :235:1
	var analyze_BANG___8 any; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A_New_O(t.F_failed); var tmp11 *jrt.Class
	var fncls__63 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A_fn_class











































	if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A_fn_class = fncls__63d; tmp11 = fncls__63d } else { tmp11 = fncls__63 }; analyze_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :235:1
	var ___9 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_parsed)); var names1__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_119.Invoke_O__O(t.F_unit)); var ___11 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names1__10); var rt_start__12 any; var G__1607000273__12_ any = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O(); var G__1607000273__13_ any; _ = ___9; _ = ___11




























































	if lang.Util_Identical_O_O__Z(G__1607000273__12_, nil) { G__1607000273__13_ = nil } else { G__1607000273__13_ = jrt.ThreadLocal_Cast(G__1607000273__12_).Get__O() }; if lang.Util_Identical_O_O__Z(G__1607000273__13_, nil) { rt_start__12 = nil } else { rt_start__12 = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.AtomicInteger_Cast(G__1607000273__13_)).Get__I()).Ref() }
//line :235:1
	var rt_order__13 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_95.GetRawRoot__O()).Invoke_O__O(names1__10); var runtime__14 any






























































	if jrt.A2g_Truth(rt_start__12) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_184.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A_New_O_O_O_O_O(rt_order__13, analyze_BANG___8, t.F_unit, rt_start__12, names1__10); var tmp14 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A_fn_class = fncls__65d; tmp14 = fncls__65d } else { tmp14 = fncls__65 }; runtime__14 = tmp12.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)) } else {





			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_world_A_const_188; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(t.F_unit, A_arbace_a2g_world_A_const_119, rt_order__13))); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A_New_O_O(analyze_BANG___8, names1__10); var tmp18 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A_fn_class = fncls__66d; tmp18 = fncls__66d } else { tmp18 = fncls__66 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :298:1
			runtime__14 = nil }
//line :235:1
	var ___15 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_189); var ___16 any; _ = ___15; _ = ___16







































































	if jrt.A2g_Truth(t.F_wait) { var tmp19 any; var t_ any = t.F_wait; t.F_wait = nil; tmp19 = t_; ___16 = lang.IFn_Cast(tmp19).Invoke__O() } else { ___16 = nil }
//line :235:1
	var ___17 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_129); var parsed2__18 any; var tmp20 any; var t__2 any = t.F_parse; _ = ___17









































































	t.F_parse = nil; tmp20 = t__2; var tmp21 lang.IFn = lang.IFn_Cast(tmp20); var tmp22 any; var t__4 any = t.F_late_inputs; t.F_late_inputs = nil; tmp22 = t__4; parsed2__18 = tmp21.Invoke_O__O(tmp22)
//line :235:1
	var ___19 any = lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_190); var ___20 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp24 any; var t__5 any = t.F_tops; _ = ___19; _ = ___20











































































	t.F_tops = nil; tmp24 = t__5; var tmp25 any = tmp24; var tmp26 any = A_arbace_a2g_world_A_const_117.GetRawRoot__O(); var tmp27 any; var t__6 any = t.F_top_set; t.F_top_set = nil; tmp27 = t__6; ___20 = tmp23.Invoke_O_O_O__O(tmp25, tmp26, lang.IFn_Cast(tmp27).Invoke_O__O(parsed2__18))
//line :235:1
	var ___21 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp29 any; var t__7 any = t.F_parsed; _ = ___21












































































	t.F_parsed = nil; tmp29 = t__7; ___21 = tmp28.Invoke_O_O_O__O(tmp29, A_arbace_a2g_world_A_const_117.GetRawRoot__O(), parsed2__18)
//line :235:1
	var ___22 any = lang.IFn_Cast(enter_BANG___6).Invoke_O__O(parsed2__18); var names2__23 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(names1__10)).Ref(), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_119.Invoke_O__O(t.F_unit)))); var ___24 any = lang.IFn_Cast(resolve_BANG___7).Invoke_O__O(names2__23); var tops_QMARK___25 any; var tmp30 any = A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A_New(); var tmp31 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A_fn_class; _ = ___22; _ = ___24























































































	if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A_fn_class = fncls__64d; tmp31 = fncls__64d } else { tmp31 = fncls__64 }; tops_QMARK___25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil)
//line :235:1
	var groups__26 any; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp33 any; var iter__1927001039__auto____26 any; var tmp34 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A_New_O(tops_QMARK___25); var tmp35 *jrt.Class
	var fncls__69 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A_fn_class
























































































	if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A_fn_class = fncls__69d; tmp35 = fncls__69d } else { tmp35 = fncls__69 }; iter__1927001039__auto____26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); tmp33 = lang.IFn_Cast(iter__1927001039__auto____26).Invoke_O__O(names2__23); groups__26 = tmp32.Invoke_O__O(tmp33)
//line :235:1
	var top_groups__27 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()); var tmp37 any; var iter__1927001039__auto____27 any; var tmp38 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A_New_O(tops_QMARK___25); var tmp39 *jrt.Class
	var fncls__72 /*line :235:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A_fn_class

























































































	if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A_fn_class = fncls__72d; tmp39 = fncls__72d } else { tmp39 = fncls__72 }; iter__1927001039__auto____27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); tmp37 = lang.IFn_Cast(iter__1927001039__auto____27).Invoke_O__O(names2__23); top_groups__27 = tmp36.Invoke_O__O(tmp37)
//line :235:1
	var temp__1927000408__auto____28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O()


























































































	if jrt.A2g_Truth(temp__1927000408__auto____28) { var space__29 any = temp__1927000408__auto____28; var seq_1607000300__30 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(groups__26, top_groups__27)); var chunk_1607000301__31 any; var count_1607000302__32 int64 = 0; var i_1607000303__33 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1607000303__33, count_1607000302__32) { var gs__34 any = lang.Indexed_Cast(chunk_1607000301__31).Nth_I__O(lang.RT_IntCast_J__I(i_1607000303__33)); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_132.GetRawRoot__O()); var tmp41 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_134.GetRawRoot__O()).Invoke__O(); var tmp42 any = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A_New_O_O(space__29, analyze_BANG___8); var tmp43 *jrt.Class
			var fncls__73 /*line :327:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A_fn_class

			if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A_fn_class = fncls__73d; tmp43 = fncls__73d } else { tmp43 = fncls__73 }
//line :328:1
			tmp40.Invoke_O_O_O__O(tmp41, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil), gs__34)
//line :327:1
			seq_1607000300__30, chunk_1607000301__31, count_1607000302__32, i_1607000303__33 = seq_1607000300__30, chunk_1607000301__31, count_1607000302__32, lang.Numbers_Unchecked_inc_J__J(i_1607000303__33); continue L1 } else { var temp__1927000414__auto____34 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000300__30); if jrt.A2g_Truth(temp__1927000414__auto____34) { var seq_1607000300__35 any = temp__1927000414__auto____34; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000300__35)) { var c__1927000678__auto____36 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000300__35); seq_1607000300__30, chunk_1607000301__31, count_1607000302__32, i_1607000303__33 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000300__35), c__1927000678__auto____36, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____36))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var gs__36 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000300__35); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_132.GetRawRoot__O()); var tmp45 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_134.GetRawRoot__O()).Invoke__O(); var tmp46 any = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A_New_O_O(space__29, analyze_BANG___8); var tmp47 *jrt.Class
				var fncls__74 /*line :327:1*/*jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A_fn_class

				if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A_fn_class = fncls__74d; tmp47 = fncls__74d } else { tmp47 = fncls__74 }
//line :328:1
				tmp44.Invoke_O_O_O__O(tmp45, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil), gs__36)
//line :327:1
				seq_1607000300__30, chunk_1607000301__31, count_1607000302__32, i_1607000303__33 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000300__35), nil, 0, 0; continue L1 } } }
//line :326:1
		break L1 } } else {







			lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()).Invoke_O_O__O(analyze_BANG___8, names2__23) }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_191)
//line :235:1
	var G__1607000308__28_ any = runtime__14




































































































	if lang.Util_Identical_O_O__Z(G__1607000308__28_, nil) { } else { lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(G__1607000308__28_) }
//line :235:1
	var main__28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_119.Invoke_O__O(t.F_unit)); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_152.GetRawRoot__O()); var tmp49 *lang.Keyword = A_arbace_a2g_world_A_const_119; var tmp50 any; var t__8 any = t.F_unit








































































































	t.F_unit = nil; tmp50 = t__8; tmp48.Invoke_O_O__O(tmp49.Invoke_O__O(tmp50), lang.IFn_Cast(A_arbace_a2g_world_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(names1__10, names2__23, lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(names1__10)).Ref(), lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(rt_order__13)), lang.IFn_Cast(A_arbace_a2g_world_A_const_76.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(lang.RT_Count_O__I(names1__10)), int64(lang.RT_Count_O__I(names2__23)))).Ref(), main__28))))
//line :235:1
	var temp__1927000414__auto____28 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O()










































































































	if jrt.A2g_Truth(temp__1927000414__auto____28) { var space__29_2 any = temp__1927000414__auto____28; jrt.ThreadLocal_Cast(space__29_2).Remove__V() }
	lang.IFn_Cast(lap__5).Invoke_O__O(A_arbace_a2g_world_A_const_192)
	var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_185.GetRawRoot__O()); var tmp52 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_193.GetRawRoot__O()); var tmp54 any; var iter__1927001039__auto____30 any; var tmp55 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A_New(); var tmp56 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A_fn_class = fncls__77d; tmp56 = fncls__77d } else { tmp56 = fncls__77 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil); tmp54 = lang.IFn_Cast(iter__1927001039__auto____30).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(laps__4)); tmp1 = tmp51.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp52, jrt.RefArrayOf(jrt.Object_class, nil, tmp53.Invoke_O_O__O(Lit_42, tmp54))).Ref()) }; return nil }(); /*line :235:1*/lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp57 != nil { panic(tmp57) }; return tmp1 }










func A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :246:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A) Ctor_O_O(c__t, c__laps any) { t.F_t = c__t; t.F_laps = c__laps }
//line :246:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp2 any = t.F_laps; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_a2g_world_A_const_13.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(k__1, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D(lang.Numbers_Minus_J_O__Number(x__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_12.GetRawRoot__O()).Invoke_O__O(t.F_t)), 1.0e7)), 100.0)).Ref())); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_152.GetRawRoot__O()); var tmp4 any = t.F_t; return tmp3.Invoke_O_O__O(tmp4, jrt.Long_ValueOf_J__Long(x__2).Ref()) }
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A) Ctor_O_O_O(c__variants, c__failed, c__applied any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied }
//line :247:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A) Invoke_O_O__O(self, ps__1 any) any { { var seq_1607000179__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(ps__1); var chunk_1607000180__3 any; var count_1607000181__4 int64 = 0; var i_1607000182__5 int64 = 0; L1: for {
															if lang.Numbers_Lt_J_J__Z(i_1607000182__5, count_1607000181__4) { var map__1607000183__6 any = lang.Indexed_Cast(chunk_1607000180__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000182__5)); var map__1607000183__7 any; if lang.ISeq_InstanceOf(map__1607000183__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000183__6)) { map__1607000183__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000183__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000183__6)) { map__1607000183__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000183__6) } else { lang.PersistentArrayMap_Init(); map__1607000183__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000183__7 = map__1607000183__6 }; var file__8 any = lang.RT_Get_O_O__O(map__1607000183__7, A_arbace_a2g_world_A_const_135); var forms__9 any = lang.RT_Get_O_O__O(map__1607000183__7, A_arbace_a2g_world_A_const_136); var ns__10 any = lang.RT_Get_O_O__O(map__1607000183__7, A_arbace_a2g_world_A_const_137); if jrt.A2g_Truth(ns__10) {
																var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_world_A_const_153; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_a2g_world_A_const_153.Get__O())); var tmp3 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A_New_O_O_O_O_O_O(t.F_variants, forms__9, t.F_failed, t.F_applied, file__8, ns__10); var tmp4 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A_fn_class = fncls__47d; tmp4 = fncls__47d } else { tmp4 = fncls__47 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :248:1
		seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, i_1607000182__5 = seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, lang.Numbers_Unchecked_inc_J__J(i_1607000182__5); continue L1 } else { seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, i_1607000182__5 = seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, lang.Numbers_Unchecked_inc_J__J(i_1607000182__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000179__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1607000179__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7); seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, i_1607000182__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__1607000209__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7); var map__1607000209__9 any; if lang.ISeq_InstanceOf(map__1607000209__8) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000209__8)) { map__1607000209__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000209__8), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000209__8)) { map__1607000209__9 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000209__8) } else { lang.PersistentArrayMap_Init(); map__1607000209__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000209__9 = map__1607000209__8 }; var file__10 any = lang.RT_Get_O_O__O(map__1607000209__9, A_arbace_a2g_world_A_const_135); var forms__11 any = lang.RT_Get_O_O__O(map__1607000209__9, A_arbace_a2g_world_A_const_136); var ns__12 any = lang.RT_Get_O_O__O(map__1607000209__9, A_arbace_a2g_world_A_const_137); if jrt.A2g_Truth(ns__12) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_world_A_const_153; lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, A_arbace_a2g_world_A_const_153.Get__O())); var tmp7 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A_New_O_O_O_O_O_O(forms__11, t.F_variants, t.F_failed, t.F_applied, file__10, ns__12); var tmp8 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A_fn_class = fncls__52d; tmp8 = fncls__52d } else { tmp8 = fncls__52 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :248:1
			seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, i_1607000182__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7), nil, 0, 0; continue L1 } else { seq_1607000179__2, chunk_1607000180__3, count_1607000181__4, i_1607000182__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000179__7), nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :247:1*/panic("a2g: unreachable") }

func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :249:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A) Ctor_O_O_O_O_O_O(c__variants, c__forms, c__failed, c__applied, c__file, c__ns any) { t.F_variants = c__variants; t.F_forms = c__forms; t.F_failed = c__failed; t.F_applied = c__applied; t.F_file = c__file; t.F_ns = c__ns }
//line :249:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000186__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(t.F_forms); var chunk_1607000187__4 any; var count_1607000188__5 int64 = 0; var i_1607000189__6 int64 = 0; L1: for {
																if lang.Numbers_Lt_J_J__Z(i_1607000189__6, count_1607000188__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000187__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000189__6)); var tmp2 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__7)
																	if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_154); tmp2 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }
//line :250:1
		if jrt.A2g_Truth(tmp2) {

			lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(fm__7)
//line :250:1
			seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, i_1607000189__6 = seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, lang.Numbers_Unchecked_inc_J__J(i_1607000189__6); continue L1 } else { seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, i_1607000189__6 = seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, lang.Numbers_Unchecked_inc_J__J(i_1607000189__6); continue L1 } } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000186__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000186__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8); seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, i_1607000189__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8); var tmp4 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__9)
				if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_155); tmp4 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp4 = and__1927000168__auto____11 } } else { tmp4 = and__1927000168__auto____10 }
//line :250:1
				if jrt.A2g_Truth(tmp4) {

					lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(fm__9)
//line :250:1
					seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, i_1607000189__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8), nil, 0, 0; continue L1 } else { seq_1607000186__3, chunk_1607000187__4, count_1607000188__5, i_1607000189__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000186__8), nil, 0, 0; continue L1 } } } }
//line :249:1
	break L1 }; var nsobj__3 any = A_arbace_a2g_world_A_const_153.Get__O(); var seq_1607000190__4 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()); var tmp8 any; var t_ any = t.F_forms




	t.F_forms = nil; tmp8 = t_; seq_1607000190__4 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(tmp8))
//line :249:1
	var chunk_1607000191__5 any; var count_1607000192__6 int64 = 0; var i_1607000193__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000193__7, count_1607000192__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000191__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000193__7)); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_applied, t.F_file, cf__8, t.F_ns); var tmp10 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A_fn_class
			if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A_fn_class = fncls__44d; tmp10 = fncls__44d } else { tmp10 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :254:1
			seq_1607000190__4, chunk_1607000191__5, count_1607000192__6, i_1607000193__7 = seq_1607000190__4, chunk_1607000191__5, count_1607000192__6, lang.Numbers_Unchecked_inc_J__J(i_1607000193__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000190__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000190__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000190__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000190__9); seq_1607000190__4, chunk_1607000191__5, count_1607000192__6, i_1607000193__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000190__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000190__9); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_applied, t.F_file, cf__10, t.F_ns); var tmp12 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A_fn_class
				if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A_fn_class = fncls__46d; tmp12 = fncls__46d } else { tmp12 = fncls__46 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :254:1
				seq_1607000190__4, chunk_1607000191__5, count_1607000192__6, i_1607000193__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000190__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :249:1
		break L2 } }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp13 != nil { panic(tmp13) }; return tmp1 }
//line :249:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :249:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A) Ctor_O_O_O_O_O_O(c__forms, c__variants, c__failed, c__applied, c__file, c__ns any) { t.F_forms = c__forms; t.F_variants = c__variants; t.F_failed = c__failed; t.F_applied = c__applied; t.F_file = c__file; t.F_ns = c__ns }
//line :249:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A) Invoke_O__O(self any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1607000212__3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(t.F_forms); var chunk_1607000213__4 any; var count_1607000214__5 int64 = 0; var i_1607000215__6 int64 = 0; L1: for {
																if lang.Numbers_Lt_J_J__Z(i_1607000215__6, count_1607000214__5) { var fm__7 any = lang.Indexed_Cast(chunk_1607000213__4).Nth_I__O(lang.RT_IntCast_J__I(i_1607000215__6)); var tmp2 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__7)
																	if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__7)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_165); tmp2 = tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__7))) } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }
//line :250:1
		if jrt.A2g_Truth(tmp2) {

			lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(fm__7)
//line :250:1
			seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, i_1607000215__6 = seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, lang.Numbers_Unchecked_inc_J__J(i_1607000215__6); continue L1 } else { seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, i_1607000215__6 = seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, lang.Numbers_Unchecked_inc_J__J(i_1607000215__6); continue L1 } } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000212__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_1607000212__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8); seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, i_1607000215__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8); var tmp4 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_29.GetRawRoot__O()).Invoke_O__O(fm__9)
				if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__9)); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_166); tmp4 = tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(fm__9))) } else { tmp4 = and__1927000168__auto____11 } } else { tmp4 = and__1927000168__auto____10 }
//line :250:1
				if jrt.A2g_Truth(tmp4) {

					lang.IFn_Cast(A_arbace_a2g_world_A_const_156.GetRawRoot__O()).Invoke_O__O(fm__9)
//line :250:1
					seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, i_1607000215__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8), nil, 0, 0; continue L1 } else { seq_1607000212__3, chunk_1607000213__4, count_1607000214__5, i_1607000215__6 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000212__8), nil, 0, 0; continue L1 } } } }
//line :249:1
	break L1 }; var nsobj__3 any = A_arbace_a2g_world_A_const_153.Get__O(); var seq_1607000216__4 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_58.GetRawRoot__O()); var tmp8 any; var t_ any = t.F_forms




	t.F_forms = nil; tmp8 = t_; seq_1607000216__4 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(tmp8))
//line :249:1
	var chunk_1607000217__5 any; var count_1607000218__6 int64 = 0; var i_1607000219__7 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_1607000219__7, count_1607000218__6) { var cf__8 any = lang.Indexed_Cast(chunk_1607000217__5).Nth_I__O(lang.RT_IntCast_J__I(i_1607000219__7)); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_applied, t.F_file, t.F_ns, cf__8); var tmp10 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A_fn_class
			if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A_fn_class = fncls__49d; tmp10 = fncls__49d } else { tmp10 = fncls__49 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :254:1
			seq_1607000216__4, chunk_1607000217__5, count_1607000218__6, i_1607000219__7 = seq_1607000216__4, chunk_1607000217__5, count_1607000218__6, lang.Numbers_Unchecked_inc_J__J(i_1607000219__7); continue L2 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000216__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1607000216__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000216__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000216__9); seq_1607000216__4, chunk_1607000217__5, count_1607000218__6, i_1607000219__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000216__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cf__10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000216__9); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A_New_O_O_O_O_O_O_O(t.F_variants, t.F_failed, nsobj__3, t.F_applied, t.F_file, cf__10, t.F_ns); var tmp12 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A_fn_class
				if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A_fn_class = fncls__51d; tmp12 = fncls__51d } else { tmp12 = fncls__51 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :254:1
				seq_1607000216__4, chunk_1607000217__5, count_1607000218__6, i_1607000219__7 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000216__9), nil, 0, 0; continue L2 } } else { tmp1 = nil } }
//line :249:1
		break L2 } }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp13 != nil { panic(tmp13) }; return tmp1 }





func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__applied, c__file, c__cf, c__ns any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_applied = c__applied; t.F_file = c__file; t.F_cf = c__cf; t.F_ns = c__ns }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
																		t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :255:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000195__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A_fn_class = fncls__43d; tmp11 = fncls__43d } else { tmp11 = fncls__43 }; vec__1607000195__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :255:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000195__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000195__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :255:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_137, t.F_nsobj, A_arbace_a2g_world_A_const_160, A_arbace_a2g_world_A_const_161)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_162.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_159.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_163, pc__9) } }; return nil }(); if /*line :255:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :255:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__applied, c__file, c__cf, c__ns any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_applied = c__applied; t.F_file = c__file; t.F_cf = c__cf; t.F_ns = c__ns }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
																		t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :255:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000202__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A_fn_class = fncls__45d; tmp11 = fncls__45d } else { tmp11 = fncls__45 }; vec__1607000202__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :255:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000202__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000202__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :255:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_137, t.F_nsobj, A_arbace_a2g_world_A_const_160, A_arbace_a2g_world_A_const_161)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_162.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_159.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_164, pc__9) } }; return nil }(); if /*line :255:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :255:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__applied, c__file, c__ns, c__cf any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_applied = c__applied; t.F_file = c__file; t.F_ns = c__ns; t.F_cf = c__cf }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
																		t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :255:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000221__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A_fn_class = fncls__48d; tmp11 = fncls__48d } else { tmp11 = fncls__48 }; vec__1607000221__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :255:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000221__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000221__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :255:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_137, t.F_nsobj, A_arbace_a2g_world_A_const_160, A_arbace_a2g_world_A_const_161)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_162.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_159.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_167, pc__9) } }; return nil }(); if /*line :255:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :255:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A) Ctor_O_O_O_O_O_O_O(c__variants, c__failed, c__nsobj, c__applied, c__file, c__cf, c__ns any) { t.F_variants = c__variants; t.F_failed = c__failed; t.F_nsobj = c__nsobj; t.F_applied = c__applied; t.F_file = c__file; t.F_cf = c__cf; t.F_ns = c__ns }
//line :255:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A) Invoke_O__O(self any) any { var tmp1 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var n__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns
																		t.F_ns = nil; tmp4 = t_; n__3 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(t.F_cf)))
//line :255:1
	var vfs__4 any = lang.RT_Get_O_O__O(t.F_variants, n__3); var vec__1607000228__5 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_110.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cf


	t.F_cf = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var or__1927000174__auto____5 any = vfs__4; if jrt.A2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY.Ref() }; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A_New_O(t.F_variants); var tmp11 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A_fn_class = fncls__50d; tmp11 = fncls__50d } else { tmp11 = fncls__50 }; vec__1607000228__5 = tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, n__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), t.F_applied)
//line :255:1
	var cf__6 any = lang.RT_Nth_O_I_O__O(vec__1607000228__5, lang.RT_IntCast_J__I(0), nil); var counts__7 any = lang.RT_Nth_O_I_O__O(vec__1607000228__5, lang.RT_IntCast_J__I(1), nil); var ___8 any; _ = ___8



	if jrt.A2g_Truth(vfs__4) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_applied; t.F_applied = nil; tmp13 = t__3; ___8 = tmp12.Invoke_O_O_O_O__O(tmp13, A_arbace_a2g_world_A_const_99.GetRawRoot__O(), n__3, counts__7) } else { ___8 = nil }
//line :255:1
	var pc__9 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_157.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_world_A_const_137, t.F_nsobj, A_arbace_a2g_world_A_const_160, A_arbace_a2g_world_A_const_161)), lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(cf__6)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_162.GetRawRoot__O()); var tmp16 any; var t__4 any = t.F_nsobj





	t.F_nsobj = nil; tmp16 = t__4; if jrt.A2g_Truth(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, pc__9))) { tmp1 = nil } else {
		tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_159.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_168, pc__9) } }; return nil }(); if /*line :255:1*/ tmp17 != nil { if true { var e__3 jrt.Throwable_I = tmp17; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp19 any; var t__5 any = t.F_failed








			t.F_failed = nil; tmp19 = t__5; var tmp20 any = tmp19; var tmp21 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()); var tmp23 any; var t__6 any = t.F_file; t.F_file = nil; tmp23 = t__6; tmp1 = tmp18.Invoke_O_O_O__O(tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(tmp22.Invoke_O__O(tmp23), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :258:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :258:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :258:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }
//line :258:1
func A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A{}; t.Ctor_O(p0); return t }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A) Ctor_O(c__variants any) { t.F_variants = c__variants }
//line :258:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A) Invoke_O_O__O(self, p1__1607000154_SHARP___1 any) any { return lang.RT_Get_O_O__O(t.F_variants, p1__1607000154_SHARP___1) }







func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A{}; t.Ctor_O_O(p0, p1); return t }
//line :266:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A) Ctor_O_O(c__failed, c__lap any) { t.F_failed = c__failed; t.F_lap = c__lap }
//line :266:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A) Invoke_O_O__O(self, names__1 any) any {
	lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_170)
//line :266:1
	{ var seq_1607000237__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(names__1); var chunk_1607000238__3 any; var count_1607000239__4 int64 = 0; var i_1607000240__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z(i_1607000240__5, count_1607000239__4) { var n__6 any = lang.Indexed_Cast(chunk_1607000238__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000240__5)); var tmp1 *lang.Keyword = A_arbace_a2g_world_A_const_171; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()).Invoke_O__O(n__6)))) {
			var tmp2 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A_New_O_O(n__6, t.F_failed); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :268:1
			seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, i_1607000240__5 = seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, lang.Numbers_Unchecked_inc_J__J(i_1607000240__5); continue L1 } else { seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, i_1607000240__5 = seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, lang.Numbers_Unchecked_inc_J__J(i_1607000240__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000237__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1607000237__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7); seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, i_1607000240__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__8 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7); var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_171; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()).Invoke_O__O(n__8)))) {
				var tmp5 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A_New_O_O(n__8, t.F_failed); var tmp6 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A_fn_class = fncls__55d; tmp6 = fncls__55d } else { tmp6 = fncls__55 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :268:1
				seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, i_1607000240__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7), nil, 0, 0; continue L1 } else { seq_1607000237__2, chunk_1607000238__3, count_1607000239__4, i_1607000240__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000237__7), nil, 0, 0; continue L1 } } } }
//line :266:1
		break L1
	}


		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_173)
//line :266:1
		var seq_1607000245__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(names__1); var chunk_1607000246__3 any; var count_1607000247__4 int64 = 0; var i_1607000248__5 int64 = 0; L2: for {




			if lang.Numbers_Lt_J_J__Z(i_1607000248__5, count_1607000247__4) { var n__6_2 any = lang.Indexed_Cast(chunk_1607000246__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000248__5)); var tmp7 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A_New_O_O(n__6_2, t.F_failed); var tmp8 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A_fn_class
				if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A_fn_class = fncls__56d; tmp8 = fncls__56d } else { tmp8 = fncls__56 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :271:1
				seq_1607000245__2, chunk_1607000246__3, count_1607000247__4, i_1607000248__5 = seq_1607000245__2, chunk_1607000246__3, count_1607000247__4, lang.Numbers_Unchecked_inc_J__J(i_1607000248__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000245__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_1607000245__7 any = temp__1927000414__auto____6_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000245__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000245__7); seq_1607000245__2, chunk_1607000246__3, count_1607000247__4, i_1607000248__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000245__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var n__8_2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000245__7); var tmp9 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A_New_O_O(n__8_2, t.F_failed); var tmp10 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A_fn_class
					if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A_fn_class = fncls__57d; tmp10 = fncls__57d } else { tmp10 = fncls__57 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :271:1
					seq_1607000245__2, chunk_1607000246__3, count_1607000247__4, i_1607000248__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000245__7), nil, 0, 0; continue L2 } } }
//line :266:1
			break L2
		}





		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_175)
//line :266:1
		var seq_1607000253__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_176.Invoke_O__O(names__1)); var chunk_1607000254__3 any; var count_1607000255__4 int64 = 0; var i_1607000256__5 int64 = 0; L3: for {







			if lang.Numbers_Lt_J_J__Z(i_1607000256__5, count_1607000255__4) { var n__6_3 any = lang.Indexed_Cast(chunk_1607000254__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000256__5)); var tmp11 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A_New_O_O(n__6_3, t.F_failed); var tmp12 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A_fn_class
				if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A_fn_class = fncls__58d; tmp12 = fncls__58d } else { tmp12 = fncls__58 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :274:1
				seq_1607000253__2, chunk_1607000254__3, count_1607000255__4, i_1607000256__5 = seq_1607000253__2, chunk_1607000254__3, count_1607000255__4, lang.Numbers_Unchecked_inc_J__J(i_1607000256__5); continue L3 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000253__2); if jrt.A2g_Truth(temp__1927000414__auto____6_3) { var seq_1607000253__7 any = temp__1927000414__auto____6_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000253__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000253__7); seq_1607000253__2, chunk_1607000254__3, count_1607000255__4, i_1607000256__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000253__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var n__8_3 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000253__7); var tmp13 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A_New_O_O(n__8_3, t.F_failed); var tmp14 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A_fn_class
					if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A_fn_class = fncls__59d; tmp14 = fncls__59d } else { tmp14 = fncls__59 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
//line :274:1
					seq_1607000253__2, chunk_1607000254__3, count_1607000255__4, i_1607000256__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000253__7), nil, 0, 0; continue L3 } } }
//line :266:1
			break L3
		}








		lang.IFn_Cast(t.F_lap).Invoke_O__O(A_arbace_a2g_world_A_const_178)
//line :266:1
		var seq_1607000261__2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(names__1); var chunk_1607000262__3 any; var count_1607000263__4 int64 = 0; var i_1607000264__5 int64 = 0; L4: for {










			if lang.Numbers_Lt_J_J__Z(i_1607000264__5, count_1607000263__4) { var n__6_4 any = lang.Indexed_Cast(chunk_1607000262__3).Nth_I__O(lang.RT_IntCast_J__I(i_1607000264__5)); var tmp15 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A_New_O_O(n__6_4, t.F_failed); var tmp16 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A_fn_class
				if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A_fn_class = fncls__60d; tmp16 = fncls__60d } else { tmp16 = fncls__60 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :277:1
				seq_1607000261__2, chunk_1607000262__3, count_1607000263__4, i_1607000264__5 = seq_1607000261__2, chunk_1607000262__3, count_1607000263__4, lang.Numbers_Unchecked_inc_J__J(i_1607000264__5); continue L4 } else { var temp__1927000414__auto____6_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1607000261__2); if jrt.A2g_Truth(temp__1927000414__auto____6_4) { var seq_1607000261__7 any = temp__1927000414__auto____6_4; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1607000261__7)) { var c__1927000678__auto____8_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1607000261__7); seq_1607000261__2, chunk_1607000262__3, count_1607000263__4, i_1607000264__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(seq_1607000261__7), c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var n__8_4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1607000261__7); var tmp17 any = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A_New_O_O(n__8_4, t.F_failed); var tmp18 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A_fn_class
					if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A_fn_class = fncls__61d; tmp18 = fncls__61d } else { tmp18 = fncls__61 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :277:1
					seq_1607000261__2, chunk_1607000262__3, count_1607000263__4, i_1607000264__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1607000261__7), nil, 0, 0; continue L4 } } else { return nil } } } }
//line :266:1
	panic("a2g: unreachable")
}

func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A{}; t.Ctor_O_O(p0, p1); return t }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_172.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :269:1
func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :269:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_172.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A{}; t.Ctor_O_O(p0, p1); return t }
//line :272:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :272:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_174.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :272:1
func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :272:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :272:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_174.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A{}; t.Ctor_O_O(p0, p1); return t }
//line :275:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :275:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_177.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :275:1
func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A{}; t.Ctor_O_O(p0, p1); return t }
//line :275:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :275:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_177.GetRawRoot__O()).Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }


func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :278:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_179.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
//line :278:1
func A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A{}; t.Ctor_O_O(p0, p1); return t }
//line :278:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A) Ctor_O_O(c__n, c__failed any) { t.F_n = c__n; t.F_failed = c__failed }
//line :278:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = A_arbace_a2g_world_A_const_179.Invoke_O__O(t.F_n); return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_failed; t.F_failed = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp7 any; var t__2 any = t.F_n; t.F_n = nil; tmp7 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }
func A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A{}; t.Ctor_O(p0); return t }
//line :279:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A) Ctor_O(c__failed any) { t.F_failed = c__failed }
//line :279:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
															tmp1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_180.GetRawRoot__O()).Invoke_O__O(n__1)
//line :279:1
	return nil }(); if tmp2 != nil { if true { var e__4 jrt.Throwable_I = tmp2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp4 *lang.Keyword = A_arbace_a2g_world_A_const_181; var tmp5 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_158.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp6 any = A_arbace_a2g_world_A_const_99.GetRawRoot__O()
		var tmp7 any = A_arbace_a2g_world_A_const_182

		tmp3.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, e__4.GetMessage__String().Ref())
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_100.GetRawRoot__O()); var tmp9 any = t.F_failed; var tmp10 any = A_arbace_a2g_world_A_const_13.GetRawRoot__O(); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, nil); var tmp12 any = e__4.GetMessage__String().Ref(); var tmp13 *jrt.String; var G__1607000271__8_ any = e__4.GetCause__Throwable(); var G__1607000271__9_ any
		if lang.Util_Identical_O_O__Z(G__1607000271__8_, nil) { G__1607000271__9_ = nil } else { G__1607000271__9_ = jrt.Throwable_Cast(G__1607000271__8_).GetMessage__String().Ref() }; if lang.Util_Identical_O_O__Z(G__1607000271__9_, nil) { tmp13 = nil } else { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1607000271__9_)) }
//line :283:1
		tmp1 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.Tuple_Create_O_O__IPersistentVector(n__1, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref())).Ref())) } }; return tmp1 }















func A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :299:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A) Ctor_O_O_O_O_O(c__rt_order, c__analyze_BANG_, c__unit, c__rt_start, c__names1 any) { t.F_rt_order = c__rt_order; t.F_analyze_BANG_ = c__analyze_BANG_; t.F_unit = c__unit; t.F_rt_start = c__rt_start; t.F_names1 = c__names1 }
//line :299:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A) Invoke_O__O(self any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O()); var tmp2 any; var t_ any = t.F_rt_start; t.F_rt_start = nil; tmp2 = t_; tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(tmp2)))
//line :299:1
	var tmp3 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_19.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_20.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_world_A_const_188; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_99.GetRawRoot__O()); var tmp8 any; var t__2 any = t.F_unit; t.F_unit = nil; tmp8 = t__2; var tmp9 any = tmp8; var tmp10 any = A_arbace_a2g_world_A_const_119; var tmp11 any; var t__3 any = t.F_rt_order; t.F_rt_order = nil; tmp11 = t__3; tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O_O__O(tmp9, tmp10, tmp11))); tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()); var tmp13 any; var t__4 any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp13 = t__4; var tmp14 any = tmp13; var tmp15 any; var t__5 any = t.F_names1; t.F_names1 = nil; tmp15 = t__5; tmp3 = tmp12.Invoke_O_O__O(tmp14, tmp15) }
//line :301:1
			return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O()
//line :299:1
			if tmp16 != nil { panic(tmp16) } }; return nil
	}()


	jrt.ThreadLocal_Cast(lang.IFn_Cast(A_arbace_a2g_world_A_const_183.GetRawRoot__O()).Invoke__O()).Remove__V()
//line :299:1
	if tmp17 != nil { panic(tmp17) }; return tmp3
}




func A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A) Ctor_O_O(c__analyze_BANG_, c__names1 any) { t.F_analyze_BANG_ = c__analyze_BANG_; t.F_names1 = c__names1 }
//line :305:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_analyze_BANG_; t.F_analyze_BANG_ = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_names1; t.F_names1 = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_world_A_const_18.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }

















func A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A_New() *A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A) Ctor() {}
//line :323:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A) Invoke_O_O__O(self, n__1 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_55.GetRawRoot__O()).Invoke_O_O__O(n__1, Lit_13)) }
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A{}; t.Ctor_O(p0); return t }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A) Invoke_O_O__O(self, s__1607000281__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(t.F_tops_QMARK_, s__1607000281__1, self); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :324:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000281, c__iter__1607000280 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000281 = c__s__1607000281; t.F_iter__1607000280 = c__iter__1607000280 }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A) Invoke_O__O(self any) any { { var s__1607000281__1 any; var t_ any = t.F_s__1607000281; t.F_s__1607000281 = nil; s__1607000281__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000281__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000281__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000281__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000283__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(b__1607000283__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000283__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000283__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000280); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000281__3))) } else { s__1607000281__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000281__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :324:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Ctor_O_O_I_O(c__b__1607000283, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000283 = c__b__1607000283; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :324:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A) Invoke_O__O(self any) any { { var i__1607000282__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000282__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000282__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_169.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000283; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } else { i__1607000282__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000282__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A_New_O(p0 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A) Ctor_O(c__tops_QMARK_ any) { t.F_tops_QMARK_ = c__tops_QMARK_ }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A) Invoke_O_O__O(self, s__1607000291__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A_New_O_O_O(t.F_tops_QMARK_, s__1607000291__1, self); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :325:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A) Ctor_O_O_O(c__tops_QMARK_, c__s__1607000291, c__iter__1607000290 any) { t.F_tops_QMARK_ = c__tops_QMARK_; t.F_s__1607000291 = c__s__1607000291; t.F_iter__1607000290 = c__iter__1607000290 }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A) Invoke_O__O(self any) any { { var s__1607000291__1 any; var t_ any = t.F_s__1607000291; t.F_s__1607000291 = nil; s__1607000291__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000291__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000291__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000291__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000291__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000293__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A_New_O_O_I_O(b__1607000293__6, t.F_tops_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A_fn_class = fncls__70d; tmp2 = fncls__70d } else { tmp2 = fncls__70 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000290); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000293__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000291__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000293__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000291__3); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__4)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000290); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(n__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000291__3))) } else { s__1607000291__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000291__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :325:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A) Ctor_O_O_I_O(c__b__1607000293, c__tops_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000293 = c__b__1607000293; t.F_tops_QMARK_ = c__tops_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :325:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A) Invoke_O__O(self any) any { { var i__1607000292__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000292__1)); if jrt.A2g_Truth(lang.IFn_Cast(t.F_tops_QMARK_).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000293; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O__IPersistentVector(n__2)); i__1607000292__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000292__1); continue L1 } else { i__1607000292__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000292__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A) Ctor_O_O(c__space, c__analyze_BANG_ any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_186.GetRawRoot__O())))
//line :329:1
	var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1)
//line :329:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :329:1
	if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :329:1
func A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A) Ctor_O_O(c__space, c__analyze_BANG_ any) { t.F_space = c__space; t.F_analyze_BANG_ = c__analyze_BANG_ }
//line :329:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A) Invoke_O_O__O(self, g__1 any) any {
	var tmp1 jrt.ThreadLocal_I = jrt.ThreadLocal_Cast(t.F_space); tmp1.Set_O__V(jrt.AtomicInteger_New_I(lang.RT_IntCast_O__I(A_arbace_a2g_world_A_const_186.GetRawRoot__O())))
//line :329:1
	var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp2 = lang.IFn_Cast(A_arbace_a2g_world_A_const_187.GetRawRoot__O()).Invoke_O_O__O(t.F_analyze_BANG_, g__1)
//line :329:1
		return nil
	}()
	jrt.ThreadLocal_Cast(t.F_space).Remove__V()
//line :329:1
	if tmp3 != nil { panic(tmp3) }; return tmp2
}













func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A_New() *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A) Ctor() {}
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A) Invoke_O_O__O(self, s__1607000310__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A_New_O_O(s__1607000310__1, self); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :344:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A{}; t.Ctor_O_O(p0, p1); return t }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A) Ctor_O_O(c__s__1607000310, c__iter__1607000309 any) { t.F_s__1607000310 = c__s__1607000310; t.F_iter__1607000309 = c__iter__1607000309 }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A) Invoke_O__O(self any) any { { var s__1607000310__1 any; var t_ any = t.F_s__1607000310; t.F_s__1607000310 = nil; s__1607000310__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000310__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000310__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000310__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000310__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000312__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A_New_O_I_O(b__1607000312__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000309); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000312__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000310__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000312__6), nil) } } else { var vec__1607000320__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000310__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1607000320__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1607000320__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000309); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(k__5), nil, v__6)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000310__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :344:1
func A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A) Ctor_O_I_O(c__b__1607000312 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000312 = c__b__1607000312; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :344:1
func (t *A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A) Invoke_O__O(self any) any { { var i__1607000311__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000311__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1607000316__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000311__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1607000316__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1607000316__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000312; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_world_A_const_31.GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref()); i__1607000311__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000311__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A_New() *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A) Ctor() {}
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A) Invoke_O_O__O(self, s__1607000331__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A_New_O_O(self, s__1607000331__1); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A_New_O_O(p0, p1 any) *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A) Ctor_O_O(c__iter__1607000330, c__s__1607000331 any) { t.F_iter__1607000330 = c__iter__1607000330; t.F_s__1607000331 = c__s__1607000331 }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A) Invoke_O__O(self any) any { { var s__1607000331__1 any; var t_ any = t.F_s__1607000331; t.F_s__1607000331 = nil; s__1607000331__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000331__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__1607000338__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var map__1607000338__5 any; if lang.ISeq_InstanceOf(map__1607000338__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_48.GetRawRoot__O()).Invoke_O__O(map__1607000338__4)) { map__1607000338__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_world_A_const_59.GetRawRoot__O()).Invoke_O__O(map__1607000338__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(map__1607000338__4)) { map__1607000338__5 = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1607000338__4) } else { lang.PersistentArrayMap_Init(); map__1607000338__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1607000338__5 = map__1607000338__4 }; var file__6 any = lang.RT_Get_O_O__O(map__1607000338__5, A_arbace_a2g_world_A_const_135); var ns__7 any = lang.RT_Get_O_O__O(map__1607000338__5, A_arbace_a2g_world_A_const_137); var forms__8 any = lang.RT_Get_O_O__O(map__1607000338__5, A_arbace_a2g_world_A_const_136); if jrt.A2g_Truth(ns__7) { var iterys__1927001035__auto____9 any; var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A_New_O(file__6); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____10 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_140.GetRawRoot__O()).Invoke_O_O__O(ns__7, forms__8))); if jrt.A2g_Truth(fs__1927001036__auto____10) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000330); return lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____10, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000331__1))) } else { s__1607000331__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000331__1); continue L1 } } else { s__1607000331__1 = lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000331__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :349:1
func A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A_New_O(p0 any) *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A) Ctor_O(c__file any) { t.F_file = c__file }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A) Invoke_O_O__O(self, s__1607000333__1 any) any { var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A_New_O_O_O(s__1607000333__1, self, t.F_file); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A) Ctor_O_O_O(c__s__1607000333, c__iter__1607000332, c__file any) { t.F_s__1607000333 = c__s__1607000333; t.F_iter__1607000332 = c__iter__1607000332; t.F_file = c__file }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A) Invoke_O__O(self any) any { { var s__1607000333__1 any; var t_ any = t.F_s__1607000333; t.F_s__1607000333 = nil; s__1607000333__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1607000333__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1607000333__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_world_A_const_34.GetRawRoot__O()).Invoke_O__O(s__1607000333__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1607000333__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1607000335__6 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A_New_O_O_I_O(b__1607000335__6, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1607000332); return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000335__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1607000333__3))) } else { return lang.IFn_Cast(A_arbace_a2g_world_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1607000335__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_world_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1607000333__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1607000332); return lang.IFn_Cast(A_arbace_a2g_world_A_const_40.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_file)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1607000333__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :349:1
func A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A) Ctor_O_O_I_O(c__b__1607000335, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1607000335 = c__b__1607000335; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A) Invoke_O__O(self any) any { { var i__1607000334__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1607000334__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1607000334__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_world_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_b__1607000335; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.IFn_Cast(A_arbace_a2g_world_A_const_51.GetRawRoot__O()).Invoke_O__O(t.F_file))); i__1607000334__1 = lang.Numbers_Unchecked_inc_J__J(i__1607000334__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_world_with_world_A_New() *A_arbace_a2g_world_with_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_with_world_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_a2g_world_with_world_A) Ctor() {}
//line :354:1
func (t *A_arbace_a2g_world_with_world_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, w__2, body__3 any) any { return lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_198), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_199.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_200), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(w__2))))), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_201), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_112.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_world_A_const_199.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_202), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_144), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_200)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_203), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_145), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_200)))), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_204), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_146), lang.IFn_Cast(A_arbace_a2g_world_A_const_113.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_world_A_const_200)))))))), body__3))))) }






























































































































































































































































type A_arbace_a2g_world_A struct{ jrt.Object }

var A_arbace_a2g_world_A_const_pool *jrt.RefArray

var A_arbace_a2g_world_A_const_0 *lang.Var

var A_arbace_a2g_world_A_const_1 *lang.Var

var A_arbace_a2g_world_A_const_2 any

var A_arbace_a2g_world_A_const_3 any

var A_arbace_a2g_world_A_const_4 any

var A_arbace_a2g_world_A_const_5 any

var A_arbace_a2g_world_A_const_6 any

var A_arbace_a2g_world_A_const_7 any

var A_arbace_a2g_world_A_const_8 any

var A_arbace_a2g_world_A_const_9 any

var A_arbace_a2g_world_A_const_10 any

var A_arbace_a2g_world_A_const_11 *lang.Var

var A_arbace_a2g_world_A_const_12 *lang.Var

var A_arbace_a2g_world_A_const_13 *lang.Var

var A_arbace_a2g_world_A_const_14 any

var A_arbace_a2g_world_A_const_15 *lang.Var

var A_arbace_a2g_world_A_const_16 *lang.Var

var A_arbace_a2g_world_A_const_17 *lang.Var

var A_arbace_a2g_world_A_const_18 *lang.Var

var A_arbace_a2g_world_A_const_19 *lang.Var

var A_arbace_a2g_world_A_const_20 *lang.Var

var A_arbace_a2g_world_A_const_21 *lang.Var

var A_arbace_a2g_world_A_const_22 *lang.Var

var A_arbace_a2g_world_A_const_23 *lang.Var

var A_arbace_a2g_world_A_const_24 *lang.Keyword

var A_arbace_a2g_world_A_const_25 *lang.Var

var A_arbace_a2g_world_A_const_26 *lang.Var

var A_arbace_a2g_world_A_const_27 any

var A_arbace_a2g_world_A_const_28 any

var A_arbace_a2g_world_A_const_29 *lang.Var

var A_arbace_a2g_world_A_const_30 *lang.Var

var A_arbace_a2g_world_A_const_31 *lang.Var

var A_arbace_a2g_world_A_const_32 *lang.Var

var A_arbace_a2g_world_A_const_33 *lang.Var

var A_arbace_a2g_world_A_const_34 *lang.Var

var A_arbace_a2g_world_A_const_35 *lang.Var

var A_arbace_a2g_world_A_const_36 *lang.Var

var A_arbace_a2g_world_A_const_37 *lang.Var

var A_arbace_a2g_world_A_const_38 *lang.Var

var A_arbace_a2g_world_A_const_39 *lang.Var

var A_arbace_a2g_world_A_const_40 *lang.Var

var A_arbace_a2g_world_A_const_41 *lang.Var

var A_arbace_a2g_world_A_const_42 *lang.Var

var A_arbace_a2g_world_A_const_43 *lang.Var

var A_arbace_a2g_world_A_const_44 *lang.Var

var A_arbace_a2g_world_A_const_45 any

var A_arbace_a2g_world_A_const_46 *lang.Var

var A_arbace_a2g_world_A_const_47 *lang.Var

var A_arbace_a2g_world_A_const_48 *lang.Var

var A_arbace_a2g_world_A_const_49 *lang.Var

var A_arbace_a2g_world_A_const_50 *lang.Keyword

var A_arbace_a2g_world_A_const_51 *lang.Var

var A_arbace_a2g_world_A_const_52 *lang.Var

var A_arbace_a2g_world_A_const_53 *lang.Var

var A_arbace_a2g_world_A_const_54 *lang.Var

var A_arbace_a2g_world_A_const_55 *lang.Var

var A_arbace_a2g_world_A_const_56 *lang.Keyword

var A_arbace_a2g_world_A_const_57 *lang.Var

var A_arbace_a2g_world_A_const_58 *lang.Var

var A_arbace_a2g_world_A_const_59 *lang.Var

var A_arbace_a2g_world_A_const_60 *lang.Keyword

var A_arbace_a2g_world_A_const_61 *lang.Keyword

var A_arbace_a2g_world_A_const_62 *lang.Keyword

var A_arbace_a2g_world_A_const_63 *lang.Keyword

var A_arbace_a2g_world_A_const_64 *lang.Var

var A_arbace_a2g_world_A_const_65 *lang.Var

var A_arbace_a2g_world_A_const_66 *lang.Var

var A_arbace_a2g_world_A_const_67 *lang.Var

var A_arbace_a2g_world_A_const_68 *lang.Var

var A_arbace_a2g_world_A_const_69 any

var A_arbace_a2g_world_A_const_70 *lang.Var

var A_arbace_a2g_world_A_const_71 *lang.Var

var A_arbace_a2g_world_A_const_72 *lang.Var

var A_arbace_a2g_world_A_const_73 *lang.Keyword

var A_arbace_a2g_world_A_const_74 *lang.Var

var A_arbace_a2g_world_A_const_75 *lang.Keyword

var A_arbace_a2g_world_A_const_76 *lang.Var

var A_arbace_a2g_world_A_const_77 any

var A_arbace_a2g_world_A_const_78 *lang.Keyword

var A_arbace_a2g_world_A_const_79 *lang.Var

var A_arbace_a2g_world_A_const_80 *lang.Keyword

var A_arbace_a2g_world_A_const_81 *lang.Keyword

var A_arbace_a2g_world_A_const_82 *lang.Keyword

var A_arbace_a2g_world_A_const_83 *lang.Keyword

var A_arbace_a2g_world_A_const_84 *lang.Keyword

var A_arbace_a2g_world_A_const_85 any

var A_arbace_a2g_world_A_const_86 *lang.Keyword

var A_arbace_a2g_world_A_const_87 *lang.Var

var A_arbace_a2g_world_A_const_88 *lang.Var

var A_arbace_a2g_world_A_const_89 any

var A_arbace_a2g_world_A_const_90 *lang.Var

var A_arbace_a2g_world_A_const_91 *lang.Var

var A_arbace_a2g_world_A_const_92 *lang.Var

var A_arbace_a2g_world_A_const_93 *lang.Var

var A_arbace_a2g_world_A_const_94 *lang.Var

var A_arbace_a2g_world_A_const_95 *lang.Var

var A_arbace_a2g_world_A_const_96 *lang.Var

var A_arbace_a2g_world_A_const_97 any

var A_arbace_a2g_world_A_const_98 *lang.Var

var A_arbace_a2g_world_A_const_99 *lang.Var

var A_arbace_a2g_world_A_const_100 *lang.Var

var A_arbace_a2g_world_A_const_101 *lang.Var

var A_arbace_a2g_world_A_const_102 any

var A_arbace_a2g_world_A_const_103 *lang.Var

var A_arbace_a2g_world_A_const_104 *lang.Var

var A_arbace_a2g_world_A_const_105 *lang.Var

var A_arbace_a2g_world_A_const_106 *lang.Keyword

var A_arbace_a2g_world_A_const_107 *lang.Keyword

var A_arbace_a2g_world_A_const_108 *lang.Var

var A_arbace_a2g_world_A_const_109 *lang.Keyword

var A_arbace_a2g_world_A_const_110 *lang.Var

var A_arbace_a2g_world_A_const_111 *lang.Var

var A_arbace_a2g_world_A_const_112 *lang.Var

var A_arbace_a2g_world_A_const_113 *lang.Var

var A_arbace_a2g_world_A_const_114 *lang.Var

var A_arbace_a2g_world_A_const_115 *lang.Var

var A_arbace_a2g_world_A_const_116 *lang.Var

var A_arbace_a2g_world_A_const_117 *lang.Var

var A_arbace_a2g_world_A_const_118 *lang.Keyword

var A_arbace_a2g_world_A_const_119 *lang.Keyword

var A_arbace_a2g_world_A_const_120 *lang.Keyword

var A_arbace_a2g_world_A_const_121 *lang.Keyword

var A_arbace_a2g_world_A_const_122 *lang.Keyword

var A_arbace_a2g_world_A_const_123 *lang.Keyword

var A_arbace_a2g_world_A_const_124 *lang.Keyword

var A_arbace_a2g_world_A_const_125 *lang.Keyword

var A_arbace_a2g_world_A_const_126 *jrt.Class

var A_arbace_a2g_world_A_const_127 *lang.Keyword

var A_arbace_a2g_world_A_const_128 *lang.Keyword

var A_arbace_a2g_world_A_const_129 *lang.Keyword

var A_arbace_a2g_world_A_const_130 *lang.Var

var A_arbace_a2g_world_A_const_131 *lang.Var

var A_arbace_a2g_world_A_const_132 *lang.Var

var A_arbace_a2g_world_A_const_133 *lang.Var

var A_arbace_a2g_world_A_const_134 *lang.Var

var A_arbace_a2g_world_A_const_135 *lang.Keyword

var A_arbace_a2g_world_A_const_136 *lang.Keyword

var A_arbace_a2g_world_A_const_137 *lang.Keyword

var A_arbace_a2g_world_A_const_138 *lang.Var

var A_arbace_a2g_world_A_const_139 *lang.Var

var A_arbace_a2g_world_A_const_140 *lang.Var

var A_arbace_a2g_world_A_const_141 *lang.Var

var A_arbace_a2g_world_A_const_142 *lang.Var

var A_arbace_a2g_world_A_const_143 *lang.Var

var A_arbace_a2g_world_A_const_144 *lang.Keyword

var A_arbace_a2g_world_A_const_145 *lang.Keyword

var A_arbace_a2g_world_A_const_146 *lang.Keyword

var A_arbace_a2g_world_A_const_147 *lang.Keyword

var A_arbace_a2g_world_A_const_148 *lang.Keyword

var A_arbace_a2g_world_A_const_149 *lang.Keyword

var A_arbace_a2g_world_A_const_150 *lang.Keyword

var A_arbace_a2g_world_A_const_151 *lang.Keyword

var A_arbace_a2g_world_A_const_152 *lang.Var

var A_arbace_a2g_world_A_const_153 *lang.Var

var A_arbace_a2g_world_A_const_154 any

var A_arbace_a2g_world_A_const_155 any

var A_arbace_a2g_world_A_const_156 *lang.Var

var A_arbace_a2g_world_A_const_157 *lang.Var

var A_arbace_a2g_world_A_const_158 *lang.Var

var A_arbace_a2g_world_A_const_159 *lang.Var

var A_arbace_a2g_world_A_const_160 *lang.Keyword

var A_arbace_a2g_world_A_const_161 *lang.Keyword

var A_arbace_a2g_world_A_const_162 *lang.Var

var A_arbace_a2g_world_A_const_163 any

var A_arbace_a2g_world_A_const_164 any

var A_arbace_a2g_world_A_const_165 any

var A_arbace_a2g_world_A_const_166 any

var A_arbace_a2g_world_A_const_167 any

var A_arbace_a2g_world_A_const_168 any

var A_arbace_a2g_world_A_const_169 *lang.Var

var A_arbace_a2g_world_A_const_170 *lang.Keyword

var A_arbace_a2g_world_A_const_171 *lang.Keyword

var A_arbace_a2g_world_A_const_172 *lang.Var

var A_arbace_a2g_world_A_const_173 *lang.Keyword

var A_arbace_a2g_world_A_const_174 *lang.Var

var A_arbace_a2g_world_A_const_175 *lang.Keyword

var A_arbace_a2g_world_A_const_176 *lang.Var

var A_arbace_a2g_world_A_const_177 *lang.Var

var A_arbace_a2g_world_A_const_178 *lang.Keyword

var A_arbace_a2g_world_A_const_179 *lang.Var

var A_arbace_a2g_world_A_const_180 *lang.Var

var A_arbace_a2g_world_A_const_181 *lang.Keyword

var A_arbace_a2g_world_A_const_182 *lang.Keyword

var A_arbace_a2g_world_A_const_183 *lang.Var

var A_arbace_a2g_world_A_const_184 *lang.Var

var A_arbace_a2g_world_A_const_185 *lang.Var

var A_arbace_a2g_world_A_const_186 *lang.Var

var A_arbace_a2g_world_A_const_187 *lang.Var

var A_arbace_a2g_world_A_const_188 *lang.Var

var A_arbace_a2g_world_A_const_189 *lang.Keyword

var A_arbace_a2g_world_A_const_190 *lang.Keyword

var A_arbace_a2g_world_A_const_191 *lang.Keyword

var A_arbace_a2g_world_A_const_192 *lang.Keyword

var A_arbace_a2g_world_A_const_193 *lang.Var

var A_arbace_a2g_world_A_const_194 *lang.Var

var A_arbace_a2g_world_A_const_195 *lang.Var

var A_arbace_a2g_world_A_const_196 *lang.Var

var A_arbace_a2g_world_A_const_197 *lang.Var

var A_arbace_a2g_world_A_const_198 any

var A_arbace_a2g_world_A_const_199 *lang.Var

var A_arbace_a2g_world_A_const_200 any

var A_arbace_a2g_world_A_const_201 any

var A_arbace_a2g_world_A_const_202 any

var A_arbace_a2g_world_A_const_203 any

var A_arbace_a2g_world_A_const_204 any

var A_arbace_a2g_world_A_init jrt.ClassInit

func A_arbace_a2g_world_A_Init() { if !A_arbace_a2g_world_A_init.Done() { A_arbace_a2g_world_A_init.Run(A_arbace_a2g_world_A_clinit) } }

func A_arbace_a2g_world_A_clinit() { A_arbace_a2g_world_A_clinit_p0(); A_arbace_a2g_world_A_clinit_p1(); A_arbace_a2g_world_A_clinit_p2(); A_arbace_a2g_world_A_clinit_p3(); A_arbace_a2g_world_A_clinit_p4(); A_arbace_a2g_world_A_clinit_p5(); A_arbace_a2g_world_A_clinit_p6(); A_arbace_a2g_world_A_clinit_p7(); A_arbace_a2g_world_A_clinit_p8(); A_arbace_a2g_world_A_clinit_p9(); A_arbace_a2g_world_A_clinit_p10(); A_arbace_a2g_world_A_clinit_p11(); A_arbace_a2g_world_A_clinit_p12(); A_arbace_a2g_world_A_clinit_p13(); A_arbace_a2g_world_A_clinit_p14(); A_arbace_a2g_world_A_clinit_p15(); A_arbace_a2g_world_A_clinit_p16() }

func A_arbace_a2g_world_A_clinit_p0() { A_arbace_a2g_world_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 290); A_arbace_a2g_world_A_const_0 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[85]); A_arbace_a2g_world_A_const_1 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[86]); A_arbace_a2g_world_A_const_2 = A_arbace_a2g_world_A_const_pool.A[87]; A_arbace_a2g_world_A_const_3 = A_arbace_a2g_world_A_const_pool.A[88]; A_arbace_a2g_world_A_const_4 = A_arbace_a2g_world_A_const_pool.A[89]; A_arbace_a2g_world_A_const_5 = A_arbace_a2g_world_A_const_pool.A[90]; A_arbace_a2g_world_A_const_6 = A_arbace_a2g_world_A_const_pool.A[91]; A_arbace_a2g_world_A_const_7 = A_arbace_a2g_world_A_const_pool.A[92]; A_arbace_a2g_world_A_const_8 = A_arbace_a2g_world_A_const_pool.A[93]; A_arbace_a2g_world_A_const_9 = A_arbace_a2g_world_A_const_pool.A[94]; A_arbace_a2g_world_A_const_10 = A_arbace_a2g_world_A_const_pool.A[95]; A_arbace_a2g_world_A_const_11 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[96]); A_arbace_a2g_world_A_const_12 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[97]) }

func A_arbace_a2g_world_A_clinit_p1() { A_arbace_a2g_world_A_const_13 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[98]); A_arbace_a2g_world_A_const_14 = A_arbace_a2g_world_A_const_pool.A[99]; A_arbace_a2g_world_A_const_15 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[100]); A_arbace_a2g_world_A_const_16 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[101]); A_arbace_a2g_world_A_const_17 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[102]); A_arbace_a2g_world_A_const_18 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[103]); A_arbace_a2g_world_A_const_19 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[104]); A_arbace_a2g_world_A_const_20 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[105]); A_arbace_a2g_world_A_const_21 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[106]); A_arbace_a2g_world_A_const_22 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[107]); A_arbace_a2g_world_A_const_23 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[108]); A_arbace_a2g_world_A_const_24 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[109]) }

func A_arbace_a2g_world_A_clinit_p2() { A_arbace_a2g_world_A_const_25 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[110]); A_arbace_a2g_world_A_const_26 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[111]); A_arbace_a2g_world_A_const_27 = A_arbace_a2g_world_A_const_pool.A[112]; A_arbace_a2g_world_A_const_28 = A_arbace_a2g_world_A_const_pool.A[113]; A_arbace_a2g_world_A_const_29 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[114]); A_arbace_a2g_world_A_const_30 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[115]); A_arbace_a2g_world_A_const_31 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[116]); A_arbace_a2g_world_A_const_32 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[117]); A_arbace_a2g_world_A_const_33 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[118]); A_arbace_a2g_world_A_const_34 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[119]); A_arbace_a2g_world_A_const_35 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[120]); A_arbace_a2g_world_A_const_36 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[121]) }

func A_arbace_a2g_world_A_clinit_p3() { A_arbace_a2g_world_A_const_37 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[122]); A_arbace_a2g_world_A_const_38 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[123]); A_arbace_a2g_world_A_const_39 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[124]); A_arbace_a2g_world_A_const_40 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[125]); A_arbace_a2g_world_A_const_41 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[126]); A_arbace_a2g_world_A_const_42 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[127]); A_arbace_a2g_world_A_const_43 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[128]); A_arbace_a2g_world_A_const_44 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[129]); A_arbace_a2g_world_A_const_45 = A_arbace_a2g_world_A_const_pool.A[130]; A_arbace_a2g_world_A_const_46 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[131]); A_arbace_a2g_world_A_const_47 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[132]); A_arbace_a2g_world_A_const_48 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[133]) }

func A_arbace_a2g_world_A_clinit_p4() { A_arbace_a2g_world_A_const_49 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[134]); A_arbace_a2g_world_A_const_50 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[135]); A_arbace_a2g_world_A_const_51 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[136]); A_arbace_a2g_world_A_const_52 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[137]); A_arbace_a2g_world_A_const_53 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[138]); A_arbace_a2g_world_A_const_54 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[139]); A_arbace_a2g_world_A_const_55 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[140]); A_arbace_a2g_world_A_const_56 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[141]); A_arbace_a2g_world_A_const_57 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[142]); A_arbace_a2g_world_A_const_58 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[143]); A_arbace_a2g_world_A_const_59 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[144]); A_arbace_a2g_world_A_const_60 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[145]) }

func A_arbace_a2g_world_A_clinit_p5() { A_arbace_a2g_world_A_const_61 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[146]); A_arbace_a2g_world_A_const_62 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[147]); A_arbace_a2g_world_A_const_63 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[148]); A_arbace_a2g_world_A_const_64 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[149]); A_arbace_a2g_world_A_const_65 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[150]); A_arbace_a2g_world_A_const_66 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[151]); A_arbace_a2g_world_A_const_67 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[152]); A_arbace_a2g_world_A_const_68 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[153]); A_arbace_a2g_world_A_const_69 = A_arbace_a2g_world_A_const_pool.A[154]; A_arbace_a2g_world_A_const_70 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[155]); A_arbace_a2g_world_A_const_71 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[156]); A_arbace_a2g_world_A_const_72 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[157]) }

func A_arbace_a2g_world_A_clinit_p6() { A_arbace_a2g_world_A_const_73 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[158]); A_arbace_a2g_world_A_const_74 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[159]); A_arbace_a2g_world_A_const_75 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[160]); A_arbace_a2g_world_A_const_76 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[161]); A_arbace_a2g_world_A_const_77 = A_arbace_a2g_world_A_const_pool.A[162]; A_arbace_a2g_world_A_const_78 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[163]); A_arbace_a2g_world_A_const_79 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[164]); A_arbace_a2g_world_A_const_80 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[165]); A_arbace_a2g_world_A_const_81 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[166]); A_arbace_a2g_world_A_const_82 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[167]); A_arbace_a2g_world_A_const_83 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[168]); A_arbace_a2g_world_A_const_84 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[169]) }

func A_arbace_a2g_world_A_clinit_p7() { A_arbace_a2g_world_A_const_85 = A_arbace_a2g_world_A_const_pool.A[170]; A_arbace_a2g_world_A_const_86 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[171]); A_arbace_a2g_world_A_const_87 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[172]); A_arbace_a2g_world_A_const_88 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[173]); A_arbace_a2g_world_A_const_89 = A_arbace_a2g_world_A_const_pool.A[174]; A_arbace_a2g_world_A_const_90 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[175]); A_arbace_a2g_world_A_const_91 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[176]); A_arbace_a2g_world_A_const_92 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[177]); A_arbace_a2g_world_A_const_93 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[178]); A_arbace_a2g_world_A_const_94 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[179]); A_arbace_a2g_world_A_const_95 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[180]); A_arbace_a2g_world_A_const_96 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[181]) }

func A_arbace_a2g_world_A_clinit_p8() { A_arbace_a2g_world_A_const_97 = A_arbace_a2g_world_A_const_pool.A[182]; A_arbace_a2g_world_A_const_98 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[183]); A_arbace_a2g_world_A_const_99 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[184]); A_arbace_a2g_world_A_const_100 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[185]); A_arbace_a2g_world_A_const_101 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[186]); A_arbace_a2g_world_A_const_102 = A_arbace_a2g_world_A_const_pool.A[187]; A_arbace_a2g_world_A_const_103 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[188]); A_arbace_a2g_world_A_const_104 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[189]); A_arbace_a2g_world_A_const_105 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[190]); A_arbace_a2g_world_A_const_106 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[191]); A_arbace_a2g_world_A_const_107 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[192]); A_arbace_a2g_world_A_const_108 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[193]) }

func A_arbace_a2g_world_A_clinit_p9() { A_arbace_a2g_world_A_const_109 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[194]); A_arbace_a2g_world_A_const_110 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[195]); A_arbace_a2g_world_A_const_111 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[196]); A_arbace_a2g_world_A_const_112 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[197]); A_arbace_a2g_world_A_const_113 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[198]); A_arbace_a2g_world_A_const_114 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[199]); A_arbace_a2g_world_A_const_115 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[200]); A_arbace_a2g_world_A_const_116 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[201]); A_arbace_a2g_world_A_const_117 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[202]); A_arbace_a2g_world_A_const_118 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[203]); A_arbace_a2g_world_A_const_119 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[204]); A_arbace_a2g_world_A_const_120 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[205]) }

func A_arbace_a2g_world_A_clinit_p10() { A_arbace_a2g_world_A_const_121 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[206]); A_arbace_a2g_world_A_const_122 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[207]); A_arbace_a2g_world_A_const_123 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[208]); A_arbace_a2g_world_A_const_124 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[209]); A_arbace_a2g_world_A_const_125 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[210]); A_arbace_a2g_world_A_const_126 = jrt.Class_Cast(A_arbace_a2g_world_A_const_pool.A[211]); A_arbace_a2g_world_A_const_127 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[212]); A_arbace_a2g_world_A_const_128 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[213]); A_arbace_a2g_world_A_const_129 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[214]); A_arbace_a2g_world_A_const_130 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[215]); A_arbace_a2g_world_A_const_131 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[216]); A_arbace_a2g_world_A_const_132 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[217]) }

func A_arbace_a2g_world_A_clinit_p11() { A_arbace_a2g_world_A_const_133 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[218]); A_arbace_a2g_world_A_const_134 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[219]); A_arbace_a2g_world_A_const_135 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[220]); A_arbace_a2g_world_A_const_136 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[221]); A_arbace_a2g_world_A_const_137 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[222]); A_arbace_a2g_world_A_const_138 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[223]); A_arbace_a2g_world_A_const_139 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[224]); A_arbace_a2g_world_A_const_140 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[225]); A_arbace_a2g_world_A_const_141 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[226]); A_arbace_a2g_world_A_const_142 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[227]); A_arbace_a2g_world_A_const_143 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[228]); A_arbace_a2g_world_A_const_144 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[229]) }

func A_arbace_a2g_world_A_clinit_p12() { A_arbace_a2g_world_A_const_145 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[230]); A_arbace_a2g_world_A_const_146 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[231]); A_arbace_a2g_world_A_const_147 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[232]); A_arbace_a2g_world_A_const_148 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[233]); A_arbace_a2g_world_A_const_149 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[234]); A_arbace_a2g_world_A_const_150 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[235]); A_arbace_a2g_world_A_const_151 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[236]); A_arbace_a2g_world_A_const_152 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[237]); A_arbace_a2g_world_A_const_153 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[238]); A_arbace_a2g_world_A_const_154 = A_arbace_a2g_world_A_const_pool.A[239]; A_arbace_a2g_world_A_const_155 = A_arbace_a2g_world_A_const_pool.A[240]; A_arbace_a2g_world_A_const_156 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[241]) }

func A_arbace_a2g_world_A_clinit_p13() { A_arbace_a2g_world_A_const_157 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[242]); A_arbace_a2g_world_A_const_158 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[243]); A_arbace_a2g_world_A_const_159 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[244]); A_arbace_a2g_world_A_const_160 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[245]); A_arbace_a2g_world_A_const_161 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[246]); A_arbace_a2g_world_A_const_162 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[247]); A_arbace_a2g_world_A_const_163 = A_arbace_a2g_world_A_const_pool.A[248]; A_arbace_a2g_world_A_const_164 = A_arbace_a2g_world_A_const_pool.A[249]; A_arbace_a2g_world_A_const_165 = A_arbace_a2g_world_A_const_pool.A[250]; A_arbace_a2g_world_A_const_166 = A_arbace_a2g_world_A_const_pool.A[251]; A_arbace_a2g_world_A_const_167 = A_arbace_a2g_world_A_const_pool.A[252]; A_arbace_a2g_world_A_const_168 = A_arbace_a2g_world_A_const_pool.A[253]; A_arbace_a2g_world_A_const_169 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[254]) }

func A_arbace_a2g_world_A_clinit_p14() { A_arbace_a2g_world_A_const_170 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[255]); A_arbace_a2g_world_A_const_171 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[256]); A_arbace_a2g_world_A_const_172 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[257]); A_arbace_a2g_world_A_const_173 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[258]); A_arbace_a2g_world_A_const_174 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[259]); A_arbace_a2g_world_A_const_175 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[260]); A_arbace_a2g_world_A_const_176 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[261]); A_arbace_a2g_world_A_const_177 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[262]); A_arbace_a2g_world_A_const_178 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[263]); A_arbace_a2g_world_A_const_179 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[264]); A_arbace_a2g_world_A_const_180 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[265]); A_arbace_a2g_world_A_const_181 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[266]) }

func A_arbace_a2g_world_A_clinit_p15() { A_arbace_a2g_world_A_const_182 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[267]); A_arbace_a2g_world_A_const_183 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[268]); A_arbace_a2g_world_A_const_184 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[269]); A_arbace_a2g_world_A_const_185 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[270]); A_arbace_a2g_world_A_const_186 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[271]); A_arbace_a2g_world_A_const_187 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[272]); A_arbace_a2g_world_A_const_188 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[273]); A_arbace_a2g_world_A_const_189 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[274]); A_arbace_a2g_world_A_const_190 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[275]); A_arbace_a2g_world_A_const_191 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[276]); A_arbace_a2g_world_A_const_192 = lang.Keyword_Cast(A_arbace_a2g_world_A_const_pool.A[277]); A_arbace_a2g_world_A_const_193 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[278]) }

func A_arbace_a2g_world_A_clinit_p16() { A_arbace_a2g_world_A_const_194 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[279]); A_arbace_a2g_world_A_const_195 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[280]); A_arbace_a2g_world_A_const_196 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[281]); A_arbace_a2g_world_A_const_197 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[282]); A_arbace_a2g_world_A_const_198 = A_arbace_a2g_world_A_const_pool.A[283]; A_arbace_a2g_world_A_const_199 = lang.Var_Cast(A_arbace_a2g_world_A_const_pool.A[284]); A_arbace_a2g_world_A_const_200 = A_arbace_a2g_world_A_const_pool.A[285]; A_arbace_a2g_world_A_const_201 = A_arbace_a2g_world_A_const_pool.A[286]; A_arbace_a2g_world_A_const_202 = A_arbace_a2g_world_A_const_pool.A[287]; A_arbace_a2g_world_A_const_203 = A_arbace_a2g_world_A_const_pool.A[288]; A_arbace_a2g_world_A_const_204 = A_arbace_a2g_world_A_const_pool.A[289] }

func A_arbace_a2g_world_A_New() *A_arbace_a2g_world_A { A_arbace_a2g_world_A_Init(); t := &A_arbace_a2g_world_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_A) Ctor() {}

func (t *A_arbace_a2g_world_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_A_class }

func (t *A_arbace_a2g_world_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_A); return ok }

func A_arbace_a2g_world_A_Cast(x any) *A_arbace_a2g_world_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_A_class)) }; return v }



type A_arbace_a2g_world_apply_variant_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_apply_variant_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000126_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_world_apply_variant_fn__1607000126_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000128_A struct{ a2g_header uint64; F_counts any }

var A_arbace_a2g_world_apply_variant_fn__1607000128_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000130_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000132_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A struct{ a2g_header uint64; F_k any }

var A_arbace_a2g_world_apply_variant_fn__1607000128_fn__1607000134_A_fn_class *jrt.Class



type A_arbace_a2g_world_apply_variant_fn__1607000137_A struct{ a2g_header uint64; F_variants_of, F_prefix, F_applied any }

var A_arbace_a2g_world_apply_variant_fn__1607000137_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_form_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A struct{ a2g_header uint64; F_iter__1607000020, F_s__1607000021 any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A struct{ a2g_header uint64; F_iter__1607000022, F_s__1607000023 any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A struct{ a2g_header uint64; F_b__1607000025 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_class_forms_iter__1607000020__1607000026_fn__1607000027_iter__1607000022__1607000028_fn__1607000029_fn__1607000030_A_fn_class *jrt.Class



type A_arbace_a2g_world_class_parts_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_class_parts_A_fn_class *jrt.Class



type A_arbace_a2g_world_cut_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_cut_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000004_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000004_A_New() *A_arbace_a2g_world_eval1607000004_A { t := &A_arbace_a2g_world_eval1607000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000004_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000004_A_class }

func (t *A_arbace_a2g_world_eval1607000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000004_A); return ok }

func A_arbace_a2g_world_eval1607000004_A_Cast(x any) *A_arbace_a2g_world_eval1607000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000004_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000004_loading__1927001464__auto____1607000005_A_fn_class *jrt.Class



type A_arbace_a2g_world_eval1607000008_A struct{ jrt.Object }

func A_arbace_a2g_world_eval1607000008_A_New() *A_arbace_a2g_world_eval1607000008_A { t := &A_arbace_a2g_world_eval1607000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_world_eval1607000008_A) Ctor() {}

func (t *A_arbace_a2g_world_eval1607000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_world_eval1607000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_world_eval1607000008_A_class }

func (t *A_arbace_a2g_world_eval1607000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_world_eval1607000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_world_eval1607000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_world_eval1607000008_A); return ok }

func A_arbace_a2g_world_eval1607000008_A_Cast(x any) *A_arbace_a2g_world_eval1607000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_world_eval1607000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_world_eval1607000008_A_class)) }; return v }



type A_arbace_a2g_world_eval1607000008_fn__1607000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_eval1607000008_fn__1607000009_A_fn_class *jrt.Class



type A_arbace_a2g_world_first_form_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_first_form_A_fn_class *jrt.Class



type A_arbace_a2g_world_head_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_head_name_A_fn_class *jrt.Class



type A_arbace_a2g_world_id_space_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_id_space_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_A struct{ a2g_header uint64; F_parsed, F_variants, F_parse, F_failed, F_top_set, F_wait, F_tops, F_unit, F_applied, F_late_inputs any }

var A_arbace_a2g_world_load_world_fn__1607000175_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A struct{ a2g_header uint64; F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_analyze_BANG___1607000270_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A struct{ a2g_header uint64; F_variants, F_failed, F_applied any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A struct{ a2g_header uint64; F_variants, F_forms, F_failed, F_applied, F_file, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_applied, F_file, F_cf, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000194_fn__1607000198_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_applied, F_file, F_cf, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000185_fn__1607000201_fn__1607000205_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A struct{ a2g_header uint64; F_forms, F_variants, F_failed, F_applied, F_file, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_applied, F_file, F_ns, F_cf any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000220_fn__1607000224_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A struct{ a2g_header uint64; F_variants, F_failed, F_nsobj, F_applied, F_file, F_cf, F_ns any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A struct{ a2g_header uint64; F_variants any }

var A_arbace_a2g_world_load_world_fn__1607000175_enter_BANG___1607000178_fn__1607000211_fn__1607000227_fn__1607000231_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A struct{ a2g_header uint64; F_rt_order, F_analyze_BANG_, F_unit, F_rt_start, F_names1 any }

var A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000274_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A struct{ a2g_header uint64; F_analyze_BANG_, F_names1 any }

var A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000276_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A struct{ a2g_header uint64; F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000304_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A struct{ a2g_header uint64; F_space, F_analyze_BANG_ any }

var A_arbace_a2g_world_load_world_fn__1607000175_fn__1607000306_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A struct{ a2g_header uint64; F_tops_QMARK_, F_s__1607000281, F_iter__1607000280 any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A struct{ a2g_header uint64; F_b__1607000283, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000280__1607000284_fn__1607000285_fn__1607000286_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A struct{ a2g_header uint64; F_tops_QMARK_ any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A struct{ a2g_header uint64; F_tops_QMARK_, F_s__1607000291, F_iter__1607000290 any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A struct{ a2g_header uint64; F_b__1607000293, F_tops_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000290__1607000294_fn__1607000295_fn__1607000296_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A struct{ a2g_header uint64; F_s__1607000310, F_iter__1607000309 any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A struct{ a2g_header uint64; F_b__1607000312 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_fn__1607000175_iter__1607000309__1607000313_fn__1607000314_fn__1607000315_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A struct{ a2g_header uint64; F_t, F_laps any }

var A_arbace_a2g_world_load_world_fn__1607000175_lap__1607000176_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A struct{ a2g_header uint64; F_failed, F_lap any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000241_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000243_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000249_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000251_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000257_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000259_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000265_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A struct{ a2g_header uint64; F_n, F_failed any }

var A_arbace_a2g_world_load_world_fn__1607000175_resolve_BANG___1607000236_fn__1607000267_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_fn__1607000175_tops_QMARK___1607000278_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_from_source__1607000173_A struct{ a2g_header uint64; F_tops, F_top_of any }

var A_arbace_a2g_world_load_world_from_source__1607000173_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_iter__1607000330__1607000336_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A struct{ a2g_header uint64; F_iter__1607000330, F_s__1607000331 any }

var A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A struct{ a2g_header uint64; F_file any }

var A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A struct{ a2g_header uint64; F_s__1607000333, F_iter__1607000332, F_file any }

var A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A struct{ a2g_header uint64; F_b__1607000335, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_load_world_iter__1607000330__1607000336_fn__1607000337_iter__1607000332__1607000340_fn__1607000341_fn__1607000342_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000158_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_parse__1607000158_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000159_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A struct{ a2g_header uint64; F_fs any }

var A_arbace_a2g_world_load_world_parse__1607000158_fn__1607000161_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_of__1607000171_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_of__1607000171_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_set__1607000164_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_set__1607000164_A_fn_class *jrt.Class



type A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_load_world_top_set__1607000164_fn__1607000166_A_fn_class *jrt.Class



type A_arbace_a2g_world_new_unit_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_new_unit_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_ns_of_forms_fn__1607000038_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_ns_of_forms_fn__1607000038_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000088_A struct{ a2g_header uint64; F_f any }

var A_arbace_a2g_world_param_key_fn__1607000088_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000090_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000090_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000096_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000096_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000098_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000098_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000104_A struct{ a2g_header uint64; F_more any }

var A_arbace_a2g_world_param_key_fn__1607000104_A_fn_class *jrt.Class



type A_arbace_a2g_world_param_key_fn__1607000106_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_param_key_fn__1607000106_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000013_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_forms_fn__1607000013_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_forms_fn__1607000015_A struct{ a2g_header uint64; F_r any }

var A_arbace_a2g_world_read_forms_fn__1607000015_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000143_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_read_variants_fn__1607000143_A_fn_class *jrt.Class



type A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_read_variants_fn__1607000143_fn__1607000144_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000063_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000063_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_fn__1607000065_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_fn__1607000065_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A struct{ a2g_header uint64; F_root any }

var A_arbace_a2g_world_source_files_iter__1607000067__1607000073_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A struct{ a2g_header uint64; F_s__1607000068, F_iter__1607000067, F_root any }

var A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A struct{ a2g_header uint64; F_iter__1607000069, F_s__1607000070 any }

var A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_A_fn_class *jrt.Class



type A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A struct{ a2g_header uint64; F_b__1607000072 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_source_files_iter__1607000067__1607000073_fn__1607000074_iter__1607000069__1607000075_fn__1607000076_fn__1607000077_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_top_names_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A struct{ a2g_header uint64; F_nsname any }

var A_arbace_a2g_world_top_names_iter__1607000041__1607000045_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A struct{ a2g_header uint64; F_iter__1607000041, F_nsname, F_s__1607000042 any }

var A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_A_fn_class *jrt.Class



type A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A struct{ a2g_header uint64; F_b__1607000044, F_nsname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_world_top_names_iter__1607000041__1607000045_fn__1607000046_fn__1607000047_A_fn_class *jrt.Class



type A_arbace_a2g_world_with_world_A struct{ a2g_header uint64 }

var A_arbace_a2g_world_with_world_A_fn_class *jrt.Class
