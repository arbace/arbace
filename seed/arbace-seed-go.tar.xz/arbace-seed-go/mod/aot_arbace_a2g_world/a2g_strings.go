//line a2g_strings.ae:1
package aot_arbace_a2g_world

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_7 *jrt.String = jrt.Intern("io")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_9 *jrt.String = jrt.Intern("t")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_11 *jrt.String = jrt.Intern("env")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.parse")

var Lit_13 *jrt.String = jrt.Intern("p")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_15 *jrt.String = jrt.Intern("a")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_17 *jrt.String = jrt.Intern("m")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_19 *jrt.String = jrt.Intern("nm")

var Lit_20 *jrt.String = jrt.Intern("commute")

var Lit_21 *jrt.String = jrt.Intern("deref")

var Lit_22 *jrt.String = jrt.Intern("conj")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.world")

var Lit_24 *jrt.String = jrt.Intern("doc")

var Lit_25 *jrt.String = jrt.Intern("a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).")

var Lit_26 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_27 *jrt.String = jrt.Intern("reader")

var Lit_28 *jrt.String = jrt.Intern("doall")

var Lit_29 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_30 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_31 *jrt.String = jrt.Intern("hash-map")

var Lit_32 *jrt.String = jrt.Intern("*read-eval*")

var Lit_33 *jrt.String = jrt.Intern("take-while")

var Lit_34 *jrt.String = jrt.Intern("not=")

var Lit_35 *jrt.String = jrt.Intern("eof")

var Lit_36 *jrt.String = jrt.Intern("repeatedly")

var Lit_37 *jrt.String = jrt.Intern("read")

var Lit_38 *jrt.String = jrt.Intern("read-cond")

var Lit_39 *jrt.String = jrt.Intern("allow")

var Lit_40 *jrt.String = jrt.Intern("seq?")

var Lit_41 *jrt.String = jrt.Intern("symbol?")

var Lit_42 *jrt.String = jrt.Intern("name")

var Lit_43 *jrt.String = jrt.Intern("first")

var Lit_44 *jrt.String = jrt.Intern("seq")

var Lit_45 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_46 *jrt.String = jrt.Intern("chunk-first")

var Lit_47 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_48 *jrt.String = jrt.Intern("class-form?")

var Lit_49 *jrt.String = jrt.Intern("chunk-append")

var Lit_50 *jrt.String = jrt.Intern("chunk-cons")

var Lit_51 *jrt.String = jrt.Intern("cons")

var Lit_52 *jrt.String = jrt.Intern("chunk")

var Lit_53 *jrt.String = jrt.Intern("chunk-rest")

var Lit_54 *jrt.String = jrt.Intern("rest")

var Lit_55 *jrt.String = jrt.Intern("concat")

var Lit_56 *jrt.String = jrt.Intern("do")

var Lit_57 *jrt.String = jrt.Intern("second")

var Lit_58 *jrt.String = jrt.Intern("filter")

var Lit_59 *jrt.String = jrt.Intern("next")

var Lit_60 *jrt.String = jrt.Intern("vector?")

var Lit_61 *jrt.String = jrt.Intern("package")

var Lit_62 *jrt.String = jrt.Intern("split-options")

var Lit_63 *jrt.String = jrt.Intern("some?")

var Lit_64 *jrt.String = jrt.Intern("replace")

var Lit_65 *jrt.String = jrt.Intern("includes?")

var Lit_66 *jrt.String = jrt.Intern("else")

var Lit_67 *jrt.String = jrt.Intern("munge")

var Lit_68 *jrt.String = jrt.Intern("class-forms")

var Lit_69 *jrt.String = jrt.Intern("to-array")

var Lit_70 *jrt.String = jrt.Intern("root")

var Lit_71 *jrt.String = jrt.Intern("dirs")

var Lit_72 *jrt.String = jrt.Intern("tree")

var Lit_73 *jrt.String = jrt.Intern("files")

var Lit_74 *jrt.String = jrt.Intern("map")

var Lit_75 *jrt.String = jrt.Intern("sort-by")

var Lit_76 *jrt.String = jrt.Intern("file")

var Lit_77 *jrt.String = jrt.Intern("remove")

var Lit_78 *jrt.String = jrt.Intern("some")

var Lit_79 *jrt.String = jrt.Intern("ns")

var Lit_80 *jrt.String = jrt.Intern("read-forms")

var Lit_81 *jrt.String = jrt.Intern("ends-with?")

var Lit_82 *jrt.String = jrt.Intern("file-seq")

var Lit_83 *jrt.String = jrt.Intern("head-name")

var Lit_84 *jrt.String = jrt.Intern("field")

var Lit_85 *jrt.String = jrt.Intern("empty?")

var Lit_86 *jrt.String = jrt.Intern("throws")

var Lit_87 *jrt.String = jrt.Intern("drop")

var Lit_88 *jrt.String = jrt.Intern("ctor")

var Lit_89 *jrt.String = jrt.Intern("mapv")

var Lit_90 *jrt.String = jrt.Intern("tag")

var Lit_91 *jrt.String = jrt.Intern("class")

var Lit_92 *jrt.String = jrt.Intern("static")

var Lit_93 *jrt.String = jrt.Intern("static-initializer")

var Lit_94 *jrt.String = jrt.Intern("a2g")

var Lit_95 *jrt.String = jrt.Intern("nth")

var Lit_96 *jrt.String = jrt.Intern("method")

var Lit_97 *jrt.String = jrt.Intern("param-key")

var Lit_98 *jrt.String = jrt.Intern("ex-info")

var Lit_99 *jrt.String = jrt.Intern("a2g-cut-method")

var Lit_100 *jrt.String = jrt.Intern("pr-str")

var Lit_101 *jrt.String = jrt.Intern("vec")

var Lit_102 *jrt.String = jrt.Intern("mapcat")

var Lit_103 *jrt.String = jrt.Intern("identity")

var Lit_104 *jrt.String = jrt.Intern("class-parts")

var Lit_105 *jrt.String = jrt.Intern("atom")

var Lit_106 *jrt.String = jrt.Intern("reduce")

var Lit_107 *jrt.String = jrt.Intern("vary-meta")

var Lit_108 *jrt.String = jrt.Intern("assoc")

var Lit_109 *jrt.String = jrt.Intern("swap!")

var Lit_110 *jrt.String = jrt.Intern("inc")

var Lit_111 *jrt.String = jrt.Intern("replaced")

var Lit_112 *jrt.String = jrt.Intern("cut")

var Lit_113 *jrt.String = jrt.Intern("added")

var Lit_114 *jrt.String = jrt.Intern("cut-key")

var Lit_115 *jrt.String = jrt.Intern("update")

var Lit_116 *jrt.String = jrt.Intern("keep-indexed")

var Lit_117 *jrt.String = jrt.Intern("apply-variant")

var Lit_118 *jrt.String = jrt.Intern("with-meta")

var Lit_119 *jrt.String = jrt.Intern("apply")

var Lit_120 *jrt.String = jrt.Intern("list")

var Lit_121 *jrt.String = jrt.Intern("ns-of-forms")

var Lit_122 *jrt.String = jrt.Intern("fnil")

var Lit_123 *jrt.String = jrt.Intern("into")

var Lit_124 *jrt.String = jrt.Intern("erase")

var Lit_125 *jrt.String = jrt.Intern("order")

var Lit_126 *jrt.String = jrt.Intern("counters")

var Lit_127 *jrt.String = jrt.Intern("switch-maps")

var Lit_128 *jrt.String = jrt.Intern("switch-holders")

var Lit_129 *jrt.String = jrt.Intern("source-tried")

var Lit_130 *jrt.String = jrt.Intern("assert-holders")

var Lit_131 *jrt.String = jrt.Intern("holder-first")

var Lit_132 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_133 *jrt.String = jrt.Intern("variant-files")

var Lit_134 *jrt.String = jrt.Intern("read-variants")

var Lit_135 *jrt.String = jrt.Intern("dissoc")

var Lit_136 *jrt.String = jrt.Intern("par-mapv")

var Lit_137 *jrt.String = jrt.Intern("set")

var Lit_138 *jrt.String = jrt.Intern("subs")

var Lit_139 *jrt.String = jrt.Intern("contains?")

var Lit_140 *jrt.String = jrt.Intern("new-unit")

var Lit_141 *jrt.String = jrt.Intern("compile-set")

var Lit_142 *jrt.String = jrt.Intern("unit")

var Lit_143 *jrt.String = jrt.Intern("from-source")

var Lit_144 *jrt.String = jrt.Intern("tops")

var Lit_145 *jrt.String = jrt.Intern("source-of")

var Lit_146 *jrt.String = jrt.Intern("failed")

var Lit_147 *jrt.String = jrt.Intern("variants")

var Lit_148 *jrt.String = jrt.Intern("erased")

var Lit_149 *jrt.String = jrt.Intern("source-files")

var Lit_150 *jrt.String = jrt.Intern("jobs")

var Lit_151 *jrt.String = jrt.Intern("forms")

var Lit_152 *jrt.String = jrt.Intern("top-names")

var Lit_153 *jrt.String = jrt.Intern("reset!")

var Lit_154 *jrt.String = jrt.Intern("println")

var Lit_155 *jrt.String = jrt.Intern("id-space")

var Lit_156 *jrt.String = jrt.Intern("analysis-id-base")

var Lit_157 *jrt.String = jrt.Intern("*ns*")

var Lit_158 *jrt.String = jrt.Intern("in-ns")

var Lit_159 *jrt.String = jrt.Intern("import")

var Lit_160 *jrt.String = jrt.Intern("eval-ns-form!")

var Lit_161 *jrt.String = jrt.Intern("parse-class")

var Lit_162 *jrt.String = jrt.Intern("decl")

var Lit_163 *jrt.String = jrt.Intern("declare-class!")

var Lit_164 *jrt.String = jrt.Intern("nesting")

var Lit_165 *jrt.String = jrt.Intern("top")

var Lit_166 *jrt.String = jrt.Intern("top-name")

var Lit_167 *jrt.String = jrt.Intern("not")

var Lit_168 *jrt.String = jrt.Intern("analyze-class!")

var Lit_169 *jrt.String = jrt.Intern("state")

var Lit_170 *jrt.String = jrt.Intern("analysis-failed")

var Lit_171 *jrt.String = jrt.Intern("compiled-class?")

var Lit_172 *jrt.String = jrt.Intern("future-call")

var Lit_173 *jrt.String = jrt.Intern("declare")

var Lit_174 *jrt.String = jrt.Intern("headers-done")

var Lit_175 *jrt.String = jrt.Intern("resolve-header!")

var Lit_176 *jrt.String = jrt.Intern("headers")

var Lit_177 *jrt.String = jrt.Intern("resolve-members!")

var Lit_178 *jrt.String = jrt.Intern("members")

var Lit_179 *jrt.String = jrt.Intern("supertypes-first")

var Lit_180 *jrt.String = jrt.Intern("add-bridges!")

var Lit_181 *jrt.String = jrt.Intern("bridges")

var Lit_182 *jrt.String = jrt.Intern("mark-enum-abstract!")

var Lit_183 *jrt.String = jrt.Intern("run!")

var Lit_184 *jrt.String = jrt.Intern("analysis-compiled")

var Lit_185 *jrt.String = jrt.Intern("analysis-runtime")

var Lit_186 *jrt.String = jrt.Intern("join")

var Lit_187 *jrt.String = jrt.Intern("*compile-set*")

var Lit_188 *jrt.String = jrt.Intern("*unit*")

var Lit_189 *jrt.String = jrt.Intern("*from-source*")

var Lit_190 *jrt.String = jrt.Intern("keys")

var Lit_191 *jrt.String = jrt.Intern("juxt")

var Lit_192 *jrt.String = jrt.Intern("let")

var Lit_193 *jrt.String = jrt.Intern("vector")

var Lit_194 *jrt.String = jrt.Intern("w__1607000339__auto__")

var Lit_195 *jrt.String = jrt.Intern("binding")

var Lit_196 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant")

var Lit_197 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000127")

var Lit_198 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129")

var Lit_199 *jrt.String = jrt.Intern("add")

var Lit_200 *jrt.String = jrt.Intern("a2g: variant cuts no member: ")

var Lit_201 *jrt.String = jrt.Intern("a2g: variant replaces no member: ")

var Lit_202 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000131")

var Lit_203 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000133")

var Lit_204 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000135")

var Lit_205 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000138")

var Lit_206 *jrt.String = jrt.Intern("defclass")

var Lit_207 *jrt.String = jrt.Intern("$")

var Lit_208 *jrt.String = jrt.Intern("arbace.a2g.world$class_form_QMARK_")

var Lit_209 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms")

var Lit_210 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025")

var Lit_211 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026")

var Lit_212 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027")

var Lit_213 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028")

var Lit_214 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028$fn__1607000029")

var Lit_215 *jrt.String = jrt.Intern("arbace.a2g.world$class_parts")

var Lit_216 *jrt.String = jrt.Intern("arbace.a2g.world$cut_key")

var Lit_217 *jrt.String = jrt.Intern("a2g: bad a2g/cut ")

var Lit_218 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000004$loading__1927001464__auto____1607000005")

var Lit_219 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_220 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000008$fn__1607000009")

var Lit_221 *jrt.String = jrt.Intern("arbace.a2g.world$head_name")

var Lit_222 *jrt.String = jrt.Intern("arbace.a2g.world$id_space")

var Lit_223 *jrt.String = jrt.Intern("ID_SPACE")

var Lit_224 *jrt.String = jrt.Intern("arbace.a2g.world$load_world")

var Lit_225 *jrt.String = jrt.Intern("a variant for a class not in the inputs")

var Lit_226 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000158")

var Lit_227 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000161")

var Lit_228 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169")

var Lit_229 *jrt.String = jrt.Intern("a2g: load (s): ")

var Lit_230 *jrt.String = jrt.Intern(", ")

var Lit_231 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$analyze_BANG___1607000260")

var Lit_232 *jrt.String = jrt.Intern("analysis: ")

var Lit_233 *jrt.String = jrt.Intern(" / ")

var Lit_234 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$compiled_QMARK___1607000263")

var Lit_235 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176")

var Lit_236 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185")

var Lit_237 *jrt.String = jrt.Intern("parse: ")

var Lit_238 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185$fn__1607000189")

var Lit_239 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192")

var Lit_240 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192$fn__1607000196")

var Lit_241 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202")

var Lit_242 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211")

var Lit_243 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211$fn__1607000215")

var Lit_244 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218")

var Lit_245 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218$fn__1607000222")

var Lit_246 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000232")

var Lit_247 *jrt.String = jrt.Intern("header: ")

var Lit_248 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000234")

var Lit_249 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000240")

var Lit_250 *jrt.String = jrt.Intern("members: ")

var Lit_251 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000242")

var Lit_252 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000248")

var Lit_253 *jrt.String = jrt.Intern("bridges: ")

var Lit_254 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000250")

var Lit_255 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000256")

var Lit_256 *jrt.String = jrt.Intern("enum: ")

var Lit_257 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000258")

var Lit_258 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000266")

var Lit_259 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000294")

var Lit_260 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000296")

var Lit_261 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274")

var Lit_262 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275")

var Lit_263 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275$fn__1607000276")

var Lit_264 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284")

var Lit_265 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285")

var Lit_266 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285$fn__1607000286")

var Lit_267 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303")

var Lit_268 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304")

var Lit_269 *jrt.String = jrt.Intern(" ")

var Lit_270 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304$fn__1607000305")

var Lit_271 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$lap__1607000226")

var Lit_272 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$tops_QMARK___1607000268")

var Lit_273 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$from_source__1607000167")

var Lit_274 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326")

var Lit_275 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327")

var Lit_276 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330")

var Lit_277 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331")

var Lit_278 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331$fn__1607000332")

var Lit_279 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$top_of__1607000165")

var Lit_280 *jrt.String = jrt.Intern("arbace.a2g.world$new_unit")

var Lit_281 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms")

var Lit_282 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms$fn__1607000037")

var Lit_283 *jrt.String = jrt.Intern("arbace.a2g.world$param_key")

var Lit_284 *jrt.String = jrt.Intern("constructor")

var Lit_285 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000089")

var Lit_286 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000091")

var Lit_287 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000097")

var Lit_288 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000099")

var Lit_289 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000105")

var Lit_290 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000107")

var Lit_291 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms")

var Lit_292 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000013")

var Lit_293 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000015")

var Lit_294 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants")

var Lit_295 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000144")

var Lit_296 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000144$fn__1607000145")

var Lit_297 *jrt.String = jrt.Intern("variant")

var Lit_298 *jrt.String = jrt.Intern("/")

var Lit_299 *jrt.String = jrt.Intern(".")

var Lit_300 *jrt.String = jrt.Intern("arbace.a2g.world$source_files")

var Lit_301 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000062")

var Lit_302 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000062$fn__1607000063")

var Lit_303 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000066")

var Lit_304 *jrt.String = jrt.Intern(".ae")

var Lit_305 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074")

var Lit_306 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075")

var Lit_307 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076")

var Lit_308 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077")

var Lit_309 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077$fn__1607000078")

var Lit_310 *jrt.String = jrt.Intern("arbace.a2g.world$top_names")

var Lit_311 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044")

var Lit_312 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045")

var Lit_313 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045$fn__1607000046")

var Lit_314 *jrt.String = jrt.Intern("arbace.a2g.world$with_world")

var Lit_315 *jrt.String = jrt.Intern("arglists")

var Lit_316 *jrt.String = jrt.Intern("f")

var Lit_317 *jrt.String = jrt.Intern("line")

var Lit_318 *jrt.String = jrt.Intern("column")

var Lit_319 *jrt.String = jrt.Intern("arbace/a2g/world.ae")

var Lit_320 *jrt.String = jrt.Intern("private")

var Lit_321 *jrt.String = jrt.Intern("nsname")

var Lit_322 *jrt.String = jrt.Intern("The internal names of the top-level classes of a file's class forms.")

var Lit_323 *jrt.String = jrt.Intern("The class forms files of an input: {:root dir :dirs [subdir...]} or {:root dir :tree true}\n  (every .ae under root but package files holding ns forms).")

var Lit_324 *jrt.String = jrt.Intern("A method's or constructor's identity in a variant: kind, name, static, parameter tags.")

var Lit_325 *jrt.String = jrt.Intern("x")

var Lit_326 *jrt.String = jrt.Intern("cf")

var Lit_327 *jrt.String = jrt.Intern("[head members] of a defclass form: head is defclass, name, components, options.")

var Lit_328 *jrt.String = jrt.Intern("vforms")

var Lit_329 *jrt.String = jrt.Intern("prefix")

var Lit_330 *jrt.String = jrt.Intern("variants-of")

var Lit_331 *jrt.String = jrt.Intern("applied")

var Lit_332 *jrt.String = jrt.Intern("Class form cf with the variant's members applied: replaced, cut, added. Returns [cf'\n  counts]. With variants-of (a function of a nested class's simple name, giving its variant\n  members or nil) and applied (an atom of {name counts}), the variants of nested classes\n  (a2g/variant Outer$Inner ...) are applied to the nested class forms too, recursively, and\n  recorded in applied under their names (proposed amendment B1).")

var Lit_333 *jrt.String = jrt.Intern("{internal-name [member-form ...]} of the variant files; a nested class's variant is named\n  by its binary name, (a2g/variant Compiler$ObjExpr ...). The prefixes of the packages a\n  variant file erases, (a2g/erase \"p/\"), are under the key ::erase (amendment E2; the Go\n  build erased ASM, arbace/asm/, until it left main on 2026-10-12).")

var Lit_334 *jrt.String = jrt.Intern("Where each task of the analysis starts its id space (RT.ID_SPACE, SA143): a round value well\n  above what loading a2g takes, as main's id-floor (SA13).")

var Lit_335 *jrt.String = jrt.Intern("The runtime's per-thread id space (RT.ID_SPACE, SA143), or nil on a host without it.")

var Lit_336 *jrt.String = jrt.Intern("load-world")

var Lit_337 *jrt.String = jrt.Intern("inputs")

var Lit_338 *jrt.String = jrt.Intern("&")

var Lit_339 *jrt.String = jrt.Intern("Reads, enters and analyzes the class forms of the inputs, each {:root :dirs|:tree|:files},\n  with the Go-build variants of the variant files applied. Returns the world:\n  {:compile-set atom :unit unit :from-source pred :files [...] :tops #{} :failed [[class\n  msg]...] :variants {class counts}}. Run translation inside (with-world w ...).")

var Lit_340 *jrt.String = jrt.Intern("with-world")

var Lit_341 *jrt.String = jrt.Intern("w")

var Lit_342 *jrt.String = jrt.Intern("body")

var Lit_343 *jrt.String = jrt.Intern("Runs body with the world's class environment bound (analyzer and env functions see it).")
