//line a2g_strings.ae:1
package aot_arbace_a2g_world

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmkn3,docks16,arbace.a2g.world3,eofkn3,eofkn9,read-condkn5,allowyn2,dokn7,packagekn4,elsekn4,rootkn4,dirskn4,treekn5,filesyn2,nskn5,fieldkn6,throwskn4,ctorkn3,tagkn5,classkn6,statickn18,static-initializerks3,a2g3,nthkn6,methodyn14,a2g-cut-methodkn8,replacedkn3,cutkn5,addedks16,arbace.a2g.world5,erasekn5,orderkn8,counterskn11,switch-mapskn14,switch-holderskn12,source-triedkn14,assert-holderskn12,holder-firstkn13,variant-fileskn11,compile-setkn4,unitkn11,from-sourcekn4,topskn9,source-ofkn6,failedkn8,variantskn6,erasedkn4,filekn5,formskn2,nskn7,nestingkn3,topkn5,statekn15,analysis-failedkn7,declarekn12,headers-donekn7,headerskn7,memberskn7,bridgeskn17,analysis-compiledkn16,analysis-runtimeys11,arbace.core3,letyn21,w__1607000339__auto__ys11,arbace.core7,bindingys18,arbace.classes.env13,*compile-set*ys22,arbace.classes.analyze6,*unit*ys18,arbace.classes.env13,*from-source*v11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.a2g.worldm2,R18,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).v11,arbace.core13,*loaded-libs*v14,arbace.java.io6,readerv11,arbace.core5,doallv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core10,take-whilev11,arbace.core4,not=R19,v11,arbace.core10,repeatedlyv11,arbace.core4,readm4,R20,R19,R21,R22,v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core5,firstv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv16,arbace.a2g.world11,class-form?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core6,concatR23,v11,arbace.core6,secondv11,arbace.core6,filterv11,arbace.core4,nextv11,arbace.core7,vector?R24,v11,arbace.core3,strv20,arbace.classes.parse13,split-optionsv11,arbace.core5,some?v13,arbace.string7,replacev13,arbace.string9,includes?R25,v11,arbace.core5,mungev16,arbace.a2g.world11,class-formsv11,arbace.core8,to-arrayR26,R27,R28,R29,v11,arbace.core3,mapv11,arbace.core7,sort-byv14,arbace.java.io4,filev11,arbace.core6,removev11,arbace.core4,someR30,v16,arbace.a2g.world10,read-formsv13,arbace.string10,ends-with?v11,arbace.core8,file-seqv16,arbace.a2g.world9,head-nameR31,v11,arbace.core6,empty?R32,v11,arbace.core4,dropl2,R33,v11,arbace.core4,mapvR34,R35,R36,R37,R38,l0,R39,v16,arbace.a2g.world9,param-keyv11,arbace.core7,ex-infoR40,v11,arbace.core6,pr-strv11,arbace.core3,vecv11,arbace.core6,mapcatv11,arbace.core8,identityv16,arbace.a2g.world11,class-partsv11,arbace.core4,atomv11,arbace.core6,reducel-1,v11,arbace.core9,vary-metav11,arbace.core5,assocv11,arbace.core5,swap!v11,arbace.core3,incm6,R41,l0,R42,l0,R43,l0,v16,arbace.a2g.world7,cut-keyv11,arbace.core6,updateR43,R42,v11,arbace.core12,keep-indexedR41,v16,arbace.a2g.world13,apply-variantv11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv16,arbace.a2g.world11,ns-of-formsv11,arbace.core4,fnilv11,arbace.core4,intoR44,R45,R46,R47,R48,R49,R50,R51,C14,arbace.lang.RTR52,v16,arbace.a2g.world13,read-variantsv11,arbace.core6,dissocv16,arbace.a2g.model8,par-mapvv11,arbace.core3,setv11,arbace.core4,subsv11,arbace.core9,contains?v16,arbace.a2g.world8,new-unitR53,R54,R55,R56,R57,R58,R59,R60,v16,arbace.a2g.world12,source-filesv16,arbace.a2g.model4,jobsR61,R62,R63,v16,arbace.a2g.world9,top-namesv11,arbace.core6,reset!v11,arbace.core7,printlnv16,arbace.a2g.world8,id-spacev16,arbace.a2g.world16,analysis-id-basev11,arbace.core4,*ns*S2,s5,in-nss6,importS2,s5,in-nss6,importv22,arbace.classes.analyze13,eval-ns-form!v20,arbace.classes.parse11,parse-classv22,arbace.classes.analyze4,declv22,arbace.classes.analyze14,declare-class!R64,R65,v22,arbace.classes.analyze8,top-namem2,R64,R65,m2,R64,R65,S2,s5,in-nss6,importS2,s5,in-nss6,importm2,R64,R65,m2,R64,R65,v11,arbace.core3,notv22,arbace.classes.analyze14,analyze-class!R66,R67,v16,arbace.a2g.names15,compiled-class?v11,arbace.core11,future-callR68,R69,v22,arbace.classes.analyze15,resolve-header!R70,v22,arbace.classes.analyze16,resolve-members!R71,v22,arbace.classes.analyze16,supertypes-firstv22,arbace.classes.analyze12,add-bridges!R72,v22,arbace.classes.analyze19,mark-enum-abstract!v11,arbace.core4,run!R73,R74,v13,arbace.string4,joinv18,arbace.classes.env13,*compile-set*v22,arbace.classes.analyze6,*unit*v18,arbace.classes.env13,*from-source*v11,arbace.core4,keysv11,arbace.core4,juxtR75,v11,arbace.core6,vectorR76,R77,R78,R79,R80,")

var Lit_1 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000127")

var Lit_2 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129")

var Lit_3 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000138")

var Lit_4 *jrt.String = jrt.Intern("static-initializer")

var Lit_5 *jrt.String = jrt.Intern("add")

var Lit_6 *jrt.String = jrt.Intern("cut")

var Lit_7 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000131")

var Lit_8 *jrt.String = jrt.Intern("a2g: variant cuts no member: ")

var Lit_9 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000133")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000129$fn__1607000135")

var Lit_11 *jrt.String = jrt.Intern("a2g: variant replaces no member: ")

var Lit_12 *jrt.String = jrt.Intern("defclass")

var Lit_13 *jrt.String = jrt.Intern("$")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000019__1607000025$fn__1607000026$iter__1607000021__1607000027$fn__1607000028$fn__1607000029")

var Lit_19 *jrt.String = jrt.Intern("field")

var Lit_20 *jrt.String = jrt.Intern("a2g: bad a2g/cut ")

var Lit_21 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_22 *jrt.String = jrt.Intern("ID_SPACE")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000158")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000161")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$top_of__1607000165")

var Lit_26 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$from_source__1607000167")

var Lit_27 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169")

var Lit_28 *jrt.String = jrt.Intern("a variant for a class not in the inputs")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202")

var Lit_32 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$lap__1607000226")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000232")

var Lit_34 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000234")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000240")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000242")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000248")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000250")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000256")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000258")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$analyze_BANG___1607000260")

var Lit_42 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$compiled_QMARK___1607000263")

var Lit_43 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000266")

var Lit_44 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$tops_QMARK___1607000268")

var Lit_45 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274")

var Lit_46 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284")

var Lit_47 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000294")

var Lit_48 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000296")

var Lit_49 *jrt.String = jrt.Intern("a2g: load (s): ")

var Lit_50 *jrt.String = jrt.Intern(", ")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303")

var Lit_52 *jrt.String = jrt.Intern("analysis: ")

var Lit_53 *jrt.String = jrt.Intern(" / ")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185")

var Lit_55 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192")

var Lit_56 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000185$fn__1607000189")

var Lit_57 *jrt.String = jrt.Intern("parse: ")

var Lit_58 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000176$fn__1607000192$fn__1607000196")

var Lit_59 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211")

var Lit_60 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218")

var Lit_61 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000211$fn__1607000215")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$fn__1607000202$fn__1607000218$fn__1607000222")

var Lit_63 *jrt.String = jrt.Intern("header: ")

var Lit_64 *jrt.String = jrt.Intern("members: ")

var Lit_65 *jrt.String = jrt.Intern("bridges: ")

var Lit_66 *jrt.String = jrt.Intern("enum: ")

var Lit_67 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275")

var Lit_68 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000270__1607000274$fn__1607000275$fn__1607000276")

var Lit_69 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285")

var Lit_70 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000280__1607000284$fn__1607000285$fn__1607000286")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000169$iter__1607000299__1607000303$fn__1607000304$fn__1607000305")

var Lit_73 *jrt.String = jrt.Intern(" ")

var Lit_74 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327")

var Lit_75 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330")

var Lit_76 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000320__1607000326$fn__1607000327$iter__1607000322__1607000330$fn__1607000331$fn__1607000332")

var Lit_78 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms$fn__1607000037")

var Lit_79 *jrt.String = jrt.Intern("in-ns")

var Lit_80 *jrt.String = jrt.Intern("constructor")

var Lit_81 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000089")

var Lit_82 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000091")

var Lit_83 *jrt.String = jrt.Intern("a2g-cut-method")

var Lit_84 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000097")

var Lit_85 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000099")

var Lit_86 *jrt.String = jrt.Intern("method")

var Lit_87 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000105")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000107")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000013")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000015")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000144")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000144$fn__1607000145")

var Lit_93 *jrt.String = jrt.Intern("variant")

var Lit_94 *jrt.String = jrt.Intern("/")

var Lit_95 *jrt.String = jrt.Intern(".")

var Lit_96 *jrt.String = jrt.Intern("erase")

var Lit_97 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000062")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000066")

var Lit_99 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074")

var Lit_100 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000062$fn__1607000063")

var Lit_101 *jrt.String = jrt.Intern(".ae")

var Lit_102 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075")

var Lit_103 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076")

var Lit_104 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077")

var Lit_105 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000068__1607000074$fn__1607000075$iter__1607000070__1607000076$fn__1607000077$fn__1607000078")

var Lit_106 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044")

var Lit_107 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045")

var Lit_108 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000040__1607000044$fn__1607000045$fn__1607000046")

var Lit_109 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,fkn4,linekn6,columnkn4,filekn7,privateyn5,formsyn6,nsnamekn4,keysyn4,rootyn4,dirsyn4,treeyn5,filesyn1,xyn2,cfyn6,vformsyn6,prefixyn11,variants-ofyn7,appliedyn6,inputsyn1,&yn13,variant-filesyn1,wyn4,bodyv11,arbace.core5,in-nsMyn16,arbace.a2g.worldm2,R0,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).m2,R0,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).R1,v16,arbace.a2g.world10,read-formsm8,R2,L1,V1,R3,R4,i17,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-form?m10,R7,TR2,L1,V1,R3,R4,i22,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-formsm10,R7,TR2,L1,V1,R8,R4,i24,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,ns-of-formsm10,R7,TR2,L1,V1,R8,R4,i30,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,top-namesm12,R7,TR2,L1,V2,R9,R8,R0,s68,The internal names of the top-level classes of a file's class forms.R4,i34,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world12,source-filesm10,R2,L1,V1,m2,R10,V4,R11,R12,R13,R14,R0,s151,The class forms files of an input: {:root dir :dirs [subdir...]} or {:root dir :tree true}\n  (every .ae under root but package files holding ns forms).R4,i46,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,head-namem10,R7,TR2,L1,V1,R3,R4,i65,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,param-keym12,R7,TR2,L1,V1,R3,R0,s86,A method's or constructor's identity in a variant: kind, name, static, parameter tags.R4,i67,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world7,cut-keym10,R7,TR2,L1,V1,R15,R4,i94,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-partsm12,R7,TR2,L1,V1,R16,R0,s79,[head members] of a defclass form: head is defclass, name, components, options.R4,i102,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world13,apply-variantm10,R2,L2,V2,R16,R17,V5,R16,R17,R18,R19,R20,R0,s422,Class form cf with the variant's members applied: replaced, cut, added. Returns [cf'\n  counts]. With variants-of (a function of a nested class's simple name, giving its variant\n  members or nil) and applied (an atom of {name counts}), the variants of nested classes\n  (a2g/variant Outer$Inner ...) are applied to the nested class forms too, recursively, and\n  recorded in applied under their names (proposed amendment B1).R4,i110,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world13,read-variantsm10,R2,L1,V1,R14,R0,s335,{internal-name [member-form ...]} of the variant files; a nested class's variant is named\n  by its binary name, (a2g/variant Compiler$ObjExpr ...). The prefixes of the packages a\n  variant file erases, (a2g/erase \"p/\"), are under the key ::erase (amendment E2; the Go\n  build erased ASM, arbace/asm/, until it left main on 2026-10-12).R4,i157,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world8,new-unitm10,R7,TR2,L1,V0,R4,i178,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world16,analysis-id-basel100000,m8,R4,i182,R5,i1,R6,s19,arbace/a2g/world.aeR0,s151,Where each task of the analysis starts its id space (RT.ID_SPACE, SA143): a round value well\n  above what loading a2g takes, as main's id-floor (SA13).v16,arbace.a2g.world8,id-spacem12,R7,TR2,L1,V0,R0,s84,The runtime's per-thread id space (RT.ID_SPACE, SA143), or nil on a host without it.R4,i187,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,load-worldm10,R2,L1,V3,R21,R22,m2,R10,V1,R23,R0,s338,Reads, enters and analyzes the class forms of the inputs, each {:root :dirs|:tree|:files},\n  with the Go-build variants of the variant files applied. Returns the world:\n  {:compile-set atom :unit unit :from-source pred :files [...] :tops #{} :failed [[class\n  msg]...] :variants {class counts}}. Run translation inside (with-world w ...).R4,i192,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,with-worldm10,R2,L1,V3,R24,R22,R25,R0,s87,Runs body with the world's class environment bound (analyzer and env functions see it).R4,i310,R5,i1,R6,s19,arbace/a2g/world.ae")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000004$loading__1927001464__auto____1607000005")

var Lit_111 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000008$fn__1607000009")

var Lit_112 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.world$class_form_QMARK_")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.world$top_names")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.world$source_files")

var Lit_118 *jrt.String = jrt.Intern("arbace.a2g.world$head_name")

var Lit_119 *jrt.String = jrt.Intern("arbace.a2g.world$param_key")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.world$cut_key")

var Lit_121 *jrt.String = jrt.Intern("arbace.a2g.world$class_parts")

var Lit_122 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant")

var Lit_123 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.world$new_unit")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.world$id_space")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.world$load_world")

var Lit_127 *jrt.String = jrt.Intern("arbace.a2g.world$with_world")
