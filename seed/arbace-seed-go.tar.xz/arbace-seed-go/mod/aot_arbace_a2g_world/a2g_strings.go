//line a2g_strings.ae:1
package aot_arbace_a2g_world

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmkn3,docks16,arbace.a2g.world3,eofkn3,eofkn9,read-condkn5,allowyn2,doys3,aot8,continuekn5,formsks3,aot5,partskn5,classkn7,packagekn4,elsekn4,rootkn4,dirskn4,treekn5,filesyn2,nskn5,fieldkn6,throwskn4,ctorkn3,tagkn6,statickn18,static-initializerks3,a2g3,nthkn6,methodyn14,a2g-cut-methodkn8,replacedkn3,cutkn5,addedks16,arbace.a2g.world5,erasekn5,orderkn8,counterskn11,switch-mapskn14,switch-holderskn12,source-triedkn14,assert-holderskn12,holder-firstkn4,kindkn6,parsedkn7,memberskn2,nskn7,nestingkn6,memberkn5,outerkn4,formkn5,superkn10,interfaceskn13,variant-fileskn11,late-inputskn4,waitkn4,filekn11,compile-setkn4,unitkn11,from-sourcekn4,topskn9,source-ofkn6,failedkn8,variantskn6,erasedkn2,pckn5,nsobjkn5,errorkn3,topkn14,parsed-memberskn7,declarekn12,headers-donekn7,headerskn7,bridgeskn5,statekn15,analysis-failedkn14,member-classeskn16,analysis-startedkn4,readkn17,analysis-compiledkn16,analysis-runtimeys11,arbace.core3,letyn21,w__1607000438__auto__ys11,arbace.core7,bindingys18,arbace.classes.env13,*compile-set*ys22,arbace.classes.analyze6,*unit*ys18,arbace.classes.env13,*from-source*v11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.a2g.worldm2,R18,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).v11,arbace.core13,*loaded-libs*v14,arbace.java.io6,readerv11,arbace.core5,doallv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core10,take-whilev11,arbace.core4,not=R19,v11,arbace.core10,repeatedlyv11,arbace.core4,readm4,R20,R19,R21,R22,m4,R20,R19,R21,R22,v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core5,firstv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv16,arbace.a2g.world11,class-form?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core6,concatR23,R24,v11,arbace.core4,intov11,arbace.core6,empty?v11,arbace.core4,atomv11,arbace.core4,mapvv11,arbace.core4,nextv11,arbace.core8,to-arrayR25,v16,arbace.a2g.world10,continued?v11,arbace.core4,dropv11,arbace.core3,strl3,v11,arbace.core6,updatev11,arbace.core3,vecv11,arbace.core3,notR26,v11,arbace.core3,mapv11,arbace.core9,with-metav11,arbace.core6,secondv11,arbace.core6,vectorv11,arbace.core5,rangel1,v11,arbace.core5,swap!v11,arbace.core9,contains?v11,arbace.core7,ex-infoR27,v11,arbace.core5,applyv11,arbace.core9,not-emptyv11,arbace.core4,listv11,arbace.core6,mapcatv11,arbace.core6,dissocv11,arbace.core6,removev11,arbace.core4,keysv11,arbace.core6,pr-strv11,arbace.core4,sortv11,arbace.core6,filterv11,arbace.core7,vector?R28,v20,arbace.classes.parse13,split-optionsv11,arbace.core5,some?v13,arbace.string7,replacev13,arbace.string9,includes?R29,v11,arbace.core5,mungev16,arbace.a2g.world11,class-formsR30,R31,R32,R33,v11,arbace.core7,sort-byv14,arbace.java.io4,filev16,arbace.a2g.world10,first-formR34,v13,arbace.string10,ends-with?v11,arbace.core8,file-seqv16,arbace.a2g.world9,head-nameR35,R36,l2,R37,R38,R39,R40,R41,l0,R42,v16,arbace.a2g.world9,param-keyR43,v11,arbace.core8,identityv16,arbace.a2g.world11,class-partsv11,arbace.core6,reducel-1,v11,arbace.core9,vary-metav11,arbace.core5,assocv11,arbace.core3,incm6,R44,l0,R45,l0,R46,l0,v16,arbace.a2g.world7,cut-keyv11,arbace.core4,someR46,R45,v11,arbace.core12,keep-indexedR44,v16,arbace.a2g.world13,apply-variantv16,arbace.a2g.world10,read-formsv16,arbace.a2g.world11,ns-of-formsv11,arbace.core4,fnilR47,R48,R49,R50,R51,R52,R53,R54,C14,arbace.lang.RTR55,v20,arbace.classes.parse11,parse-classR56,R57,v16,arbace.a2g.world20,parse-member-classesR58,R59,R60,R61,R62,v11,arbace.core3,setv11,arbace.core3,maxv11,arbace.core4,valsv11,arbace.core10,sorted-mapv11,arbace.core8,group-byv22,arbace.classes.analyze4,declR63,R64,v16,arbace.a2g.world6,levelsv16,arbace.a2g.model8,par-mapvv16,arbace.a2g.model4,jobsR65,R66,R67,v16,arbace.a2g.world13,read-variantsv16,arbace.a2g.world14,join-continuedv16,arbace.a2g.world12,source-filesR68,v16,arbace.a2g.world9,top-namesv11,arbace.core4,subsv16,arbace.a2g.world8,new-unitR69,R70,R71,R72,R73,R74,R75,R76,v11,arbace.core6,reset!R77,R78,R79,v11,arbace.core4,*ns*S2,s5,in-nss6,importS2,s5,in-nss6,importv22,arbace.classes.analyze13,eval-ns-form!R80,v22,arbace.classes.analyze14,declare-class!v22,arbace.classes.analyze8,top-nameR81,v16,arbace.a2g.world10,par-levelsR82,R83,v22,arbace.classes.analyze15,resolve-header!R84,v16,arbace.a2g.world9,supers-ofv22,arbace.classes.analyze16,resolve-members!v22,arbace.classes.analyze12,add-bridges!R85,v22,arbace.classes.analyze19,mark-enum-abstract!v22,arbace.classes.analyze14,analyze-class!R86,R87,v16,arbace.a2g.world8,id-spacev11,arbace.core11,future-callR88,v11,arbace.core7,printlnv16,arbace.a2g.world16,analysis-id-basev11,arbace.core4,run!v22,arbace.classes.analyze6,*unit*R89,R90,v11,arbace.core6,formatv11,arbace.core1,+v11,arbace.core4,takel10,v11,arbace.core4,compv11,arbace.core1,-R91,R92,v13,arbace.string4,joinv18,arbace.classes.env13,*compile-set*v18,arbace.classes.env13,*from-source*v11,arbace.core4,juxtR93,R94,R95,R96,R97,R98,")

var Lit_1 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000173")

var Lit_2 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000175")

var Lit_3 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000184")

var Lit_4 *jrt.String = jrt.Intern("static-initializer")

var Lit_5 *jrt.String = jrt.Intern("add")

var Lit_6 *jrt.String = jrt.Intern("cut")

var Lit_7 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000175$fn__1607000177")

var Lit_8 *jrt.String = jrt.Intern("a2g: variant cuts no member: ")

var Lit_9 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000175$fn__1607000179")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant$fn__1607000175$fn__1607000181")

var Lit_11 *jrt.String = jrt.Intern("a2g: variant replaces no member: ")

var Lit_12 *jrt.String = jrt.Intern("defclass")

var Lit_13 *jrt.String = jrt.Intern("$")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000020__1607000026")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000020__1607000026$fn__1607000027")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000020__1607000026$fn__1607000027$iter__1607000022__1607000028")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000020__1607000026$fn__1607000027$iter__1607000022__1607000028$fn__1607000029")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms$iter__1607000020__1607000026$fn__1607000027$iter__1607000022__1607000028$fn__1607000029$fn__1607000030")

var Lit_19 *jrt.String = jrt.Intern("field")

var Lit_20 *jrt.String = jrt.Intern("a2g: bad a2g/cut ")

var Lit_21 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_22 *jrt.String = jrt.Intern("ID_SPACE")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$iter__1607000039__1607000045")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057")

var Lit_25 *jrt.String = jrt.Intern("a2g: continuations of no class form: ")

var Lit_26 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058")

var Lit_27 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058$iter__1607000059__1607000063")

var Lit_28 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058$iter__1607000059__1607000063$fn__1607000064")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058$iter__1607000059__1607000063$fn__1607000064$fn__1607000065")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058$iter__1607000059__1607000063$fn__1607000064$fn__1607000073")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$fn__1607000057$fn__1607000058$iter__1607000059__1607000063$fn__1607000064$fn__1607000065$fn__1607000066")

var Lit_32 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$iter__1607000039__1607000045$fn__1607000046")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$iter__1607000039__1607000045$fn__1607000046$iter__1607000041__1607000049")

var Lit_34 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$iter__1607000039__1607000045$fn__1607000046$iter__1607000041__1607000049$fn__1607000050")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued$iter__1607000039__1607000045$fn__1607000046$iter__1607000041__1607000049$fn__1607000050$fn__1607000051")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.world$levels$lvl__1607000211")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$parse__1607000226")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$top_set__1607000232")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$top_of__1607000239")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$from_source__1607000241")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243")

var Lit_42 *jrt.String = jrt.Intern("a variant for a class not in the inputs")

var Lit_43 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000419__1607000425")

var Lit_44 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$lap__1607000244")

var Lit_45 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246")

var Lit_46 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304")

var Lit_47 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$analyze_BANG___1607000323")

var Lit_48 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000327")

var Lit_49 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000329")

var Lit_50 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$tops_QMARK___1607000331")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$holder_QMARK___1607000333")

var Lit_52 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000335__1607000339")

var Lit_53 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000345__1607000349")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000355__1607000359")

var Lit_55 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000369")

var Lit_56 *jrt.String = jrt.Intern("A2G_ANALYSIS_TIMES")

var Lit_57 *jrt.String = jrt.Intern("a2g: analysis group: %d tasks in %.2f s, the tasks %.2f s")

var Lit_58 *jrt.String = jrt.Intern("a2g: analysis time %.3f s %s")

var Lit_59 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000383")

var Lit_60 *jrt.String = jrt.Intern("a2g: load (s): ")

var Lit_61 *jrt.String = jrt.Intern(", ")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000398__1607000402")

var Lit_63 *jrt.String = jrt.Intern("analysis: ")

var Lit_64 *jrt.String = jrt.Intern(" / ")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000248")

var Lit_66 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000267")

var Lit_67 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000291")

var Lit_68 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000301")

var Lit_69 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000248$iter__1607000255__1607000259")

var Lit_70 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000248$iter__1607000255__1607000259$fn__1607000260")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000248$iter__1607000255__1607000259$fn__1607000260$fn__1607000261")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000267$fn__1607000274")

var Lit_73 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$enter_BANG___1607000246$fn__1607000267$fn__1607000276")

var Lit_74 *jrt.String = jrt.Intern("parse: ")

var Lit_75 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000369$fn__1607000370")

var Lit_76 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$fn__1607000383$fn__1607000384")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000335__1607000339$fn__1607000340")

var Lit_78 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000335__1607000339$fn__1607000340$fn__1607000341")

var Lit_79 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000345__1607000349$fn__1607000350")

var Lit_80 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000345__1607000349$fn__1607000350$fn__1607000351")

var Lit_81 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000355__1607000359$fn__1607000360")

var Lit_82 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000355__1607000359$fn__1607000360$fn__1607000361")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000398__1607000402$fn__1607000403")

var Lit_84 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$iter__1607000398__1607000402$fn__1607000403$fn__1607000404")

var Lit_85 *jrt.String = jrt.Intern(" ")

var Lit_86 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000305")

var Lit_87 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000308")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000310")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000312")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000318")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$fn__1607000243$resolve_BANG___1607000304$fn__1607000320")

var Lit_92 *jrt.String = jrt.Intern("header: ")

var Lit_93 *jrt.String = jrt.Intern("members: ")

var Lit_94 *jrt.String = jrt.Intern("bridges: ")

var Lit_95 *jrt.String = jrt.Intern("enum: ")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000419__1607000425$fn__1607000426")

var Lit_97 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000419__1607000425$fn__1607000426$iter__1607000421__1607000429")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000419__1607000425$fn__1607000426$iter__1607000421__1607000429$fn__1607000430")

var Lit_99 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$iter__1607000419__1607000425$fn__1607000426$iter__1607000421__1607000429$fn__1607000430$fn__1607000431")

var Lit_100 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$parse__1607000226$fn__1607000227")

var Lit_101 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$parse__1607000226$fn__1607000229")

var Lit_102 *jrt.String = jrt.Intern("arbace.a2g.world$load_world$top_set__1607000232$fn__1607000234")

var Lit_103 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms$fn__1607000085")

var Lit_104 *jrt.String = jrt.Intern("in-ns")

var Lit_105 *jrt.String = jrt.Intern("constructor")

var Lit_106 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000135")

var Lit_107 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000137")

var Lit_108 *jrt.String = jrt.Intern("a2g-cut-method")

var Lit_109 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000143")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000145")

var Lit_111 *jrt.String = jrt.Intern("method")

var Lit_112 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000151")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.world$param_key$fn__1607000153")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.world$parse_member_classes$iter__1607000200__1607000204")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.world$parse_member_classes$iter__1607000200__1607000204$fn__1607000205")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.world$parse_member_classes$iter__1607000200__1607000204$fn__1607000205$fn__1607000206")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000013")

var Lit_118 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms$fn__1607000015")

var Lit_119 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000190")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants$fn__1607000190$fn__1607000191")

var Lit_121 *jrt.String = jrt.Intern("variant")

var Lit_122 *jrt.String = jrt.Intern("/")

var Lit_123 *jrt.String = jrt.Intern(".")

var Lit_124 *jrt.String = jrt.Intern("erase")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000110")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$fn__1607000112")

var Lit_127 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000114__1607000120")

var Lit_128 *jrt.String = jrt.Intern(".ae")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000114__1607000120$fn__1607000121")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000114__1607000120$fn__1607000121$iter__1607000116__1607000122")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000114__1607000120$fn__1607000121$iter__1607000116__1607000122$fn__1607000123")

var Lit_132 *jrt.String = jrt.Intern("arbace.a2g.world$source_files$iter__1607000114__1607000120$fn__1607000121$iter__1607000116__1607000122$fn__1607000123$fn__1607000124")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000088__1607000092")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000088__1607000092$fn__1607000093")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.world$top_names$iter__1607000088__1607000092$fn__1607000093$fn__1607000094")

var Lit_136 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,fkn4,linekn6,columnkn4,filekn7,privateyn5,formsyn2,psyn6,nsnamekn4,keysyn4,rootyn4,dirsyn4,treeyn5,filesyn1,xyn2,cfyn6,vformsyn6,prefixyn11,variants-ofyn7,appliedyn2,pcyn5,namesyn4,depsyn1,nyn6,inputsyn1,&yn13,variant-filesyn11,late-inputsyn4,waityn1,wyn4,bodyv11,arbace.core5,in-nsMyn16,arbace.a2g.worldm2,R0,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).m2,R0,s451,a2g's input (A2G-SPEC §4.1): class forms files (Arbace's arbace/lang/*.ae, j2a's conversion\n  of the JDK closure under .tmp/jrt/conv) entered into one class environment and analyzed with\n  the class forms compiler's front end exactly as arbace.classes.compiler does before emitting\n  (resolve-header!, resolve-members!, add-bridges!, analyze-class!). Classes taken from source\n  are never resolved by reflection on the running JDK (env/*from-source*).R1,v16,arbace.a2g.world10,read-formsm8,R2,L1,V1,R3,R4,i17,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,first-formm12,R7,TR2,L1,V1,R3,R0,s33,The first form of file f, or nil.R4,i22,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-form?m10,R7,TR2,L1,V1,R3,R4,i30,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-formsm10,R7,TR2,L1,V1,R8,R4,i32,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,continued?m10,R7,TR2,L1,V1,R3,R4,i38,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world14,join-continuedm12,R7,TR2,L1,V1,R9,R0,s570,The read files ps ([{:forms ...}...]) with each class form continued in other files joined:\n  arbace.aot writes a large top-level class form across several files (SA220: one large file\n  bounded the parallel read), the class form with :aot/parts n in its metadata and the rest of\n  its elements in n continuations (aot/continue NAME k element...), k from 1 to n; the\n  continuations' elements appended in that order, the class form as printed whole (but the\n  reader's columns), :aot/parts dropped, the continuations removed. A missing or unclaimed\n  continuation fails.R4,i40,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,ns-of-formsm10,R7,TR2,L1,V1,R8,R4,i73,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,top-namesm12,R7,TR2,L1,V2,R10,R8,R0,s68,The internal names of the top-level classes of a file's class forms.R4,i77,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world12,source-filesm10,R2,L1,V1,m2,R11,V4,R12,R13,R14,R15,R0,s169,The class forms files of an input: {:root dir :dirs [subdir...]} or {:root dir :tree true}\n  (every .ae under root but package files, whose first form is their ns form).R4,i89,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,head-namem10,R7,TR2,L1,V1,R3,R4,i110,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,param-keym12,R7,TR2,L1,V1,R3,R0,s86,A method's or constructor's identity in a variant: kind, name, static, parameter tags.R4,i112,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world7,cut-keym10,R7,TR2,L1,V1,R16,R4,i139,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world11,class-partsm12,R7,TR2,L1,V1,R17,R0,s79,[head members] of a defclass form: head is defclass, name, components, options.R4,i147,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world13,apply-variantm10,R2,L2,V2,R17,R18,V5,R17,R18,R19,R20,R21,R0,s422,Class form cf with the variant's members applied: replaced, cut, added. Returns [cf'\n  counts]. With variants-of (a function of a nested class's simple name, giving its variant\n  members or nil) and applied (an atom of {name counts}), the variants of nested classes\n  (a2g/variant Outer$Inner ...) are applied to the nested class forms too, recursively, and\n  recorded in applied under their names (proposed amendment B1).R4,i155,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world13,read-variantsm10,R2,L1,V1,R15,R0,s335,{internal-name [member-form ...]} of the variant files; a nested class's variant is named\n  by its binary name, (a2g/variant Compiler$ObjExpr ...). The prefixes of the packages a\n  variant file erases, (a2g/erase \"p/\"), are under the key ::erase (amendment E2; the Go\n  build erased ASM, arbace/asm/, until it left main on 2026-10-12).R4,i202,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world8,new-unitm10,R7,TR2,L1,V0,R4,i223,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world16,analysis-id-basel100000,m8,R4,i227,R5,i1,R6,s19,arbace/a2g/world.aeR0,s151,Where each task of the analysis starts its id space (RT.ID_SPACE, SA143): a round value well\n  above what loading a2g takes, as main's id-floor (SA13).v16,arbace.a2g.world8,id-spacem12,R7,TR2,L1,V0,R0,s84,The runtime's per-thread id space (RT.ID_SPACE, SA143), or nil on a host without it.R4,i232,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world20,parse-member-classesm12,R7,TR2,L1,V1,R22,R0,s363,The member classes of parsed class pc, parsed as arbace.classes.analyze/declare-class! parses\n  them (a member class's parse takes only the kind of its outer class), recursively:\n  [{:parsed member-class :members [...]}...] in their order, which declare-class! takes as its\n  ctx's :parsed-members (a host whose declare-class! does not take it parses them again).R4,i240,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world6,levelsm12,R7,TR2,L1,V2,R23,R24,R0,s222,names in levels, a name in a level after those of the names it depends on (deps: a name's\n  names to process first; others ignored), each level in names' order. A cycle (an error the\n  steps report) is cut where it closes.R4,i250,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world9,supers-ofm12,R7,TR2,L1,V1,R25,R0,s52,The direct supertypes of class n in the compilation.R4,i265,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,par-levelsm12,R7,TR2,L1,V3,R23,R24,R3,R0,s81,(f n) for each of names, a level (levels) at a time, a level's names in parallel.R4,i270,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,load-worldm10,R2,L1,V3,R26,R27,m2,R11,V3,R28,R29,R30,R0,s895,Reads, enters and analyzes the class forms of the inputs, each {:root :dirs|:tree|:files},\n  with the Go-build variants of the variant files applied. Returns the world:\n  {:compile-set atom :unit unit :from-source pred :files [...] :tops #{} :failed [[class\n  msg]...] :variants {class counts}}. Run translation inside (with-world w ...).\n\n  In two rounds: the inputs, then the late ones (the compiled namespaces' tree, standalone\n  S6), each entered and resolved (headers, members, bridges) in order; the first round's classes\n  are analyzed on a thread of their own from the end of the first round, the late ones in\n  parallel after the second. Before the second round wait is called (a2g --await: the late\n  input is being written meanwhile; bin/arbace-go starts a2g as the host compiles the\n  namespaces). The rounds are the same with or without the wait: the output does not depend on\n  it.R4,i276,R5,i1,R6,s19,arbace/a2g/world.aev16,arbace.a2g.world10,with-worldm10,R2,L1,V3,R31,R27,R32,R0,s87,Runs body with the world's class environment bound (analyzer and env functions see it).R4,i470,R5,i1,R6,s19,arbace/a2g/world.ae")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000004$loading__1927001464__auto____1607000005")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.world$eval1607000008$fn__1607000009")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.world$read_forms")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.world$first_form")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.world$class_form_QMARK_")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.world$class_forms")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.world$continued_QMARK_")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.world$join_continued")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.world$ns_of_forms")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.world$top_names")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.world$source_files")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.world$head_name")

var Lit_149 *jrt.String = jrt.Intern("arbace.a2g.world$param_key")

var Lit_150 *jrt.String = jrt.Intern("arbace.a2g.world$cut_key")

var Lit_151 *jrt.String = jrt.Intern("arbace.a2g.world$class_parts")

var Lit_152 *jrt.String = jrt.Intern("arbace.a2g.world$apply_variant")

var Lit_153 *jrt.String = jrt.Intern("arbace.a2g.world$read_variants")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.world$new_unit")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.world$id_space")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.world$parse_member_classes")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.world$levels")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.world$supers_of")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.world$par_levels")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.world$load_world")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.world$with_world")
