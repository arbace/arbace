//line j2g_classes.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_go_lit_bytes_form_A_class, Name: "arbace.repr.go.lit$bytes_form", Modifiers: 25, Simple: "bytes_form", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_bytes_form_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_class, Name: "arbace.repr.go.lit$bytes_form$iter__790000088__790000092", Modifiers: 25, Simple: "iter__790000088__790000092", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_bytes_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_class, Name: "arbace.repr.go.lit$bytes_form$iter__790000088__790000092$fn__790000093", Modifiers: 25, Simple: "fn__790000093", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_class, Name: "arbace.repr.go.lit$bytes_form$iter__790000088__790000092$fn__790000093$fn__790000094", Modifiers: 25, Simple: "fn__790000094", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_char_text_A_class, Name: "arbace.repr.go.lit$char_text", Modifiers: 25, Simple: "char_text", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_const_form_A_class, Name: "arbace.repr.go.lit$const_form", Modifiers: 25, Simple: "const_form", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_const_form_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_decimal_text_A_class, Name: "arbace.repr.go.lit$decimal_text", Modifiers: 25, Simple: "decimal_text", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_decimal_text_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_decode_rune_A_class, Name: "arbace.repr.go.lit$decode_rune", Modifiers: 25, Simple: "decode_rune", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_decode_rune_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_decode_rune_b__790000073_A_class, Name: "arbace.repr.go.lit$decode_rune$b__790000073", Modifiers: 25, Simple: "b__790000073", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_decode_rune_b__790000073_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_decode_rune_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_class, Name: "arbace.repr.go.lit$decode_rune$cont_QMARK___790000075", Modifiers: 25, Simple: "cont_QMARK___790000075", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_decode_rune_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_double_exact_text_A_class, Name: "arbace.repr.go.lit$double_exact_text", Modifiers: 25, Simple: "double_exact_text", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_double_exact_text_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_double_lit_A_class, Name: "arbace.repr.go.lit$double_lit", Modifiers: 25, Simple: "double_lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_double_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_class, Name: "arbace.repr.go.lit$eval790000004$loading__1927001464__auto____790000005", Modifiers: 25, Simple: "loading__1927001464__auto____790000005", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_eval790000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_eval790000008_fn__790000009_A_class, Name: "arbace.repr.go.lit$eval790000008$fn__790000009", Modifiers: 25, Simple: "fn__790000009", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000008_fn__790000009_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_eval790000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_class, Name: "arbace.repr.go.lit$eval790000013$__GT_Lit__790000023", Modifiers: 25, Simple: "__GT_Lit__790000023", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_eval790000013_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_class, Name: "arbace.repr.go.lit$eval790000013$map__GT_Lit__790000025", Modifiers: 25, Simple: "map__GT_Lit__790000025", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_eval790000013_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_float_lit_A_class, Name: "arbace.repr.go.lit$float_lit", Modifiers: 25, Simple: "float_lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_float_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_float_text_lit_A_class, Name: "arbace.repr.go.lit$float_text_lit", Modifiers: 25, Simple: "float_text_lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_float_text_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_float_value_A_class, Name: "arbace.repr.go.lit$float_value", Modifiers: 25, Simple: "float_value", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_float_value_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_hex_float_value_A_class, Name: "arbace.repr.go.lit$hex_float_value", Modifiers: 25, Simple: "hex_float_value", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_hex_float_value_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_hexv_A_class, Name: "arbace.repr.go.lit$hexv", Modifiers: 25, Simple: "hexv", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_hexv_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_imag_inner_A_class, Name: "arbace.repr.go.lit$imag_inner", Modifiers: 25, Simple: "imag_inner", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_imag_inner_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_int_lit_A_class, Name: "arbace.repr.go.lit$int_lit", Modifiers: 25, Simple: "int_lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_int_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_integer_lit_A_class, Name: "arbace.repr.go.lit$integer_lit", Modifiers: 25, Simple: "integer_lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_integer_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_integer_text_A_class, Name: "arbace.repr.go.lit$integer_text", Modifiers: 25, Simple: "integer_text", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_integer_text_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_lit_A_class, Name: "arbace.repr.go.lit$lit", Modifiers: 25, Simple: "lit", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_lit_QMARK__A_class, Name: "arbace.repr.go.lit$lit_QMARK_", Modifiers: 25, Simple: "lit_QMARK_", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_num_den_A_class, Name: "arbace.repr.go.lit$num_den", Modifiers: 25, Simple: "num_den", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_num_den_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_pow2_A_class, Name: "arbace.repr.go.lit$pow2", Modifiers: 25, Simple: "pow2", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_pow2_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_pow5_exponent_A_class, Name: "arbace.repr.go.lit$pow5_exponent", Modifiers: 25, Simple: "pow5_exponent", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_pow5_exponent_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_class, Name: "arbace.repr.go.lit$pow5_exponent$fn__790000046", Modifiers: 25, Simple: "fn__790000046", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_pow5_exponent_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_printable_QMARK__A_class, Name: "arbace.repr.go.lit$printable_QMARK_", Modifiers: 25, Simple: "printable_QMARK_", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_printable_QMARK__A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_rational_A_class, Name: "arbace.repr.go.lit$rational", Modifiers: 25, Simple: "rational", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_rational_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_rune_form_A_class, Name: "arbace.repr.go.lit$rune_form", Modifiers: 25, Simple: "rune_form", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_rune_form_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_rune_value_A_class, Name: "arbace.repr.go.lit$rune_value", Modifiers: 25, Simple: "rune_value", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_rune_value_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_string_bytes_A_class, Name: "arbace.repr.go.lit$string_bytes", Modifiers: 25, Simple: "string_bytes", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_bytes_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_string_text_A_class, Name: "arbace.repr.go.lit$string_text", Modifiers: 25, Simple: "string_text", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_terminating_decimal_A_class, Name: "arbace.repr.go.lit$terminating_decimal", Modifiers: 25, Simple: "terminating_decimal", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_terminating_decimal_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_unescape_A_class, Name: "arbace.repr.go.lit$unescape", Modifiers: 25, Simple: "unescape", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_unescape_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_unescape_put_cp__790000066_A_class, Name: "arbace.repr.go.lit$unescape$put_cp__790000066", Modifiers: 25, Simple: "put_cp__790000066", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_unescape_put_cp__790000066_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_unescape_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_untyped_float_form_A_class, Name: "arbace.repr.go.lit$untyped_float_form", Modifiers: 25, Simple: "untyped_float_form", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_untyped_float_form_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_utf8_parts_A_class, Name: "arbace.repr.go.lit$utf8_parts", Modifiers: 25, Simple: "utf8_parts", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_utf8_parts_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_lit_val_rational_A_class, Name: "arbace.repr.go.lit$val_rational", Modifiers: 25, Simple: "val_rational", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_val_rational_A", Source: "lit.ae", Declaring: &A_arbace_repr_go_lit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_go_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_A_New()}; return nil }

var A_arbace_repr_go_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_lit_A_new}

var A_arbace_repr_go_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_A"})

func init() { i := A_arbace_repr_go_lit_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_A_InstanceOf; i.Init = A_arbace_repr_go_lit_A_Init; i.Table = A_arbace_repr_go_lit_A_members }

var A_arbace_repr_go_lit_bytes_form_A_class *jrt.Class

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_class *jrt.Class

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_class *jrt.Class

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_class *jrt.Class

var A_arbace_repr_go_lit_char_text_A_class *jrt.Class

var A_arbace_repr_go_lit_const_form_A_class *jrt.Class

var A_arbace_repr_go_lit_decimal_text_A_class *jrt.Class

var A_arbace_repr_go_lit_decode_rune_A_class *jrt.Class

var A_arbace_repr_go_lit_decode_rune_b__790000073_A_class *jrt.Class

var A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_class *jrt.Class

var A_arbace_repr_go_lit_double_exact_text_A_class *jrt.Class

var A_arbace_repr_go_lit_double_lit_A_class *jrt.Class

func A_arbace_repr_go_lit_eval790000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_eval790000004_A_New()}; return nil }

var A_arbace_repr_go_lit_eval790000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_lit_eval790000004_A_new}

var A_arbace_repr_go_lit_eval790000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit$eval790000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_lit_A_class, Simple: "eval790000004", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000004_A"})

func init() { i := A_arbace_repr_go_lit_eval790000004_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_eval790000004_A_InstanceOf; i.Table = A_arbace_repr_go_lit_eval790000004_A_members }

var A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_class *jrt.Class

func A_arbace_repr_go_lit_eval790000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_eval790000008_A_New()}; return nil }

var A_arbace_repr_go_lit_eval790000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_lit_eval790000008_A_new}

var A_arbace_repr_go_lit_eval790000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit$eval790000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_lit_A_class, Simple: "eval790000008", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000008_A"})

func init() { i := A_arbace_repr_go_lit_eval790000008_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_eval790000008_A_InstanceOf; i.Table = A_arbace_repr_go_lit_eval790000008_A_members }

var A_arbace_repr_go_lit_eval790000008_fn__790000009_A_class *jrt.Class

func A_arbace_repr_go_lit_eval790000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_eval790000013_A_New()}; return nil }

var A_arbace_repr_go_lit_eval790000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_lit_eval790000013_A_new}

var A_arbace_repr_go_lit_eval790000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit$eval790000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_lit_A_class, Simple: "eval790000013", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_eval790000013_A"})

func init() { i := A_arbace_repr_go_lit_eval790000013_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_eval790000013_A_InstanceOf; i.Table = A_arbace_repr_go_lit_eval790000013_A_members }

var A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_class *jrt.Class

var A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_class *jrt.Class

var A_arbace_repr_go_lit_float_lit_A_class *jrt.Class

var A_arbace_repr_go_lit_float_text_lit_A_class *jrt.Class

var A_arbace_repr_go_lit_float_value_A_class *jrt.Class

var A_arbace_repr_go_lit_hex_float_value_A_class *jrt.Class

var A_arbace_repr_go_lit_hexv_A_class *jrt.Class

var A_arbace_repr_go_lit_imag_inner_A_class *jrt.Class

var A_arbace_repr_go_lit_int_lit_A_class *jrt.Class

var A_arbace_repr_go_lit_integer_lit_A_class *jrt.Class

var A_arbace_repr_go_lit_integer_text_A_class *jrt.Class

var A_arbace_repr_go_lit_lit_A_class *jrt.Class

var A_arbace_repr_go_lit_lit_QMARK__A_class *jrt.Class

var A_arbace_repr_go_lit_num_den_A_class *jrt.Class

var A_arbace_repr_go_lit_pow2_A_class *jrt.Class

var A_arbace_repr_go_lit_pow5_exponent_A_class *jrt.Class

var A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_class *jrt.Class

var A_arbace_repr_go_lit_printable_QMARK__A_class *jrt.Class

var A_arbace_repr_go_lit_rational_A_class *jrt.Class

var A_arbace_repr_go_lit_rune_form_A_class *jrt.Class

var A_arbace_repr_go_lit_rune_value_A_class *jrt.Class

var A_arbace_repr_go_lit_string_bytes_A_class *jrt.Class

var A_arbace_repr_go_lit_string_text_A_class *jrt.Class

var A_arbace_repr_go_lit_terminating_decimal_A_class *jrt.Class

var A_arbace_repr_go_lit_unescape_A_class *jrt.Class

var A_arbace_repr_go_lit_unescape_put_cp__790000066_A_class *jrt.Class

var A_arbace_repr_go_lit_untyped_float_form_A_class *jrt.Class

var A_arbace_repr_go_lit_utf8_parts_A_class *jrt.Class

var A_arbace_repr_go_lit_val_rational_A_class *jrt.Class

func A_arbace_repr_go_lit_Lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repr_go_lit_Lit_A).Assoc_O_O__Associative(args[0], args[1]); case 1: return this.(*A_arbace_repr_go_lit_Lit_A).Assoc_O_O__IPersistentMap(args[0], args[1]); case 2: this.(*A_arbace_repr_go_lit_Lit_A).Clear__V(); return nil; case 3: return this.(*A_arbace_repr_go_lit_Lit_A).Cons_O__IPersistentCollection(args[0]); case 4: return this.(*A_arbace_repr_go_lit_Lit_A).ContainsKey_O__Z(args[0]); case 5: return this.(*A_arbace_repr_go_lit_Lit_A).ContainsValue_O__Z(args[0]); case 6: return this.(*A_arbace_repr_go_lit_Lit_A).Count__I(); case 7: return jrt.J2g_RefP(A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(jrt.As[lang.IPersistentMap](args[0]))); case 8: return this.(*A_arbace_repr_go_lit_Lit_A).Empty__IPersistentCollection(); case 9: return this.(*A_arbace_repr_go_lit_Lit_A).EntryAt_O__IMapEntry(args[0]); case 10: return this.(*A_arbace_repr_go_lit_Lit_A).EntrySet__Set(); case 11: return this.(*A_arbace_repr_go_lit_Lit_A).Equals_O__Z(args[0]); case 12: return this.(*A_arbace_repr_go_lit_Lit_A).Equiv_O__Z(args[0]); case 13: return this.(*A_arbace_repr_go_lit_Lit_A).Get_O__O(args[0]); case 14: return A_arbace_repr_go_lit_Lit_A_GetBasis__IPersistentVector(); case 15: return this.(*A_arbace_repr_go_lit_Lit_A).GetLookupThunk_Keyword__ILookupThunk(jrt.As[*lang.Keyword](args[0])); case 16: return this.(*A_arbace_repr_go_lit_Lit_A).HashCode__I(); case 17: return this.(*A_arbace_repr_go_lit_Lit_A).Hasheq__I(); case 18: return this.(*A_arbace_repr_go_lit_Lit_A).IsEmpty__Z(); case 19: return this.(*A_arbace_repr_go_lit_Lit_A).Iterator__Iterator(); case 20: return this.(*A_arbace_repr_go_lit_Lit_A).KeySet__Set(); case 21: return this.(*A_arbace_repr_go_lit_Lit_A).Meta__IPersistentMap(); case 22: return this.(*A_arbace_repr_go_lit_Lit_A).Put_O_O__O(args[0], args[1]); case 23: this.(*A_arbace_repr_go_lit_Lit_A).PutAll_Map__V(jrt.As[jrt.Map](args[0])); return nil; case 24: return this.(*A_arbace_repr_go_lit_Lit_A).Remove_O__O(args[0]); case 25: return this.(*A_arbace_repr_go_lit_Lit_A).Seq__ISeq(); case 26: return this.(*A_arbace_repr_go_lit_Lit_A).Size__I(); case 27: return this.(*A_arbace_repr_go_lit_Lit_A).ValAt_O__O(args[0]); case 28: return this.(*A_arbace_repr_go_lit_Lit_A).ValAt_O_O__O(args[0], args[1]); case 29: return this.(*A_arbace_repr_go_lit_Lit_A).Values__Collection(); case 30: return this.(*A_arbace_repr_go_lit_Lit_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 31: return this.(*A_arbace_repr_go_lit_Lit_A).Without_O__IPersistentMap(args[0])}; return nil }

func A_arbace_repr_go_lit_Lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(args[0], args[1], args[2], args[3], args[4].(int32), args[5].(int32)); case 1: return A_arbace_repr_go_lit_Lit_A_New_O_O(args[0], args[1]); case 2: return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_repr_go_lit_Lit_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_repr_go_lit_Lit_A).F_text; case 1: return o.(*A_arbace_repr_go_lit_Lit_A).F_value; case 2: return o.(*A_arbace_repr_go_lit_Lit_A).F___meta; case 3: return o.(*A_arbace_repr_go_lit_Lit_A).F___extmap}; return nil }

var A_arbace_repr_go_lit_Lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M4161 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.Associative;\nM1 assoc (Ljava.lang.Object;Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nM1 clear ()V\nM1 cons (Ljava.lang.Object;)Larbace.lang.IPersistentCollection;\nM1 containsKey (Ljava.lang.Object;)Z\nM1 containsValue (Ljava.lang.Object;)Z\nM1 count ()I\nM9 create (Larbace.lang.IPersistentMap;)Larbace.repr.go.lit.Lit;\nM1 empty ()Larbace.lang.IPersistentCollection;\nM1 entryAt (Ljava.lang.Object;)Larbace.lang.IMapEntry;\nM1 entrySet ()Ljava.util.Set;\nM1 equals (Ljava.lang.Object;)Z\nM1 equiv (Ljava.lang.Object;)Z\nM1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 getLookupThunk (Larbace.lang.Keyword;)Larbace.lang.ILookupThunk;\nM1 hashCode ()I\nM1 hasheq ()I\nM1 isEmpty ()Z\nM1 iterator ()Ljava.util.Iterator;\nM1 keySet ()Ljava.util.Set;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 put (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 putAll (Ljava.util.Map;)V\nM1 remove (Ljava.lang.Object;)Ljava.lang.Object;\nM1 seq ()Larbace.lang.ISeq;\nM1 size ()I\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 values ()Ljava.util.Collection;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 without (Ljava.lang.Object;)Larbace.lang.IPersistentMap;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;II)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 text Ljava.lang.Object;\nG17 value Ljava.lang.Object;\nG17 __meta Ljava.lang.Object;\nG17 __extmap Ljava.lang.Object;", Invoke: A_arbace_repr_go_lit_Lit_A_invoke, New: A_arbace_repr_go_lit_Lit_A_new, Get: A_arbace_repr_go_lit_Lit_A_get}

var A_arbace_repr_go_lit_Lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit.Lit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IRecord_class, lang.IHashEq_class, lang.IObj_class, lang.ILookup_class, lang.IKeywordLookup_class, lang.IPersistentMap_class, jrt.Map_class, jrt.Serializable_class}, Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_Lit_A", Source: "lit.ae"})

func init() { i := A_arbace_repr_go_lit_Lit_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_Lit_A_InstanceOf; i.Init = A_arbace_repr_go_lit_Lit_A_Init; i.Table = A_arbace_repr_go_lit_Lit_A_members }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repr_go_lit_Lit_reify__790000017_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_repr_go_lit_Lit_reify__790000017_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_repr_go_lit_Lit_reify__790000017_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_repr_go_lit_Lit_reify__790000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_repr_go_lit_Lit_reify__790000017_A_invoke, New: A_arbace_repr_go_lit_Lit_reify__790000017_A_new}

var A_arbace_repr_go_lit_Lit_reify__790000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit.Lit$reify__790000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_repr_go_lit_Lit_A_class, Simple: "reify__790000017", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_Lit_reify__790000017_A", Source: "lit.ae"})

func init() { i := A_arbace_repr_go_lit_Lit_reify__790000017_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_Lit_reify__790000017_A_InstanceOf; i.Table = A_arbace_repr_go_lit_Lit_reify__790000017_A_members }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_repr_go_lit_Lit_reify__790000019_A).Get_O__O(args[0]); case 1: return this.(*A_arbace_repr_go_lit_Lit_reify__790000019_A).Meta__IPersistentMap(); case 2: return this.(*A_arbace_repr_go_lit_Lit_reify__790000019_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_repr_go_lit_Lit_reify__790000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 get (Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_repr_go_lit_Lit_reify__790000019_A_invoke, New: A_arbace_repr_go_lit_Lit_reify__790000019_A_new}

var A_arbace_repr_go_lit_Lit_reify__790000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit.Lit$reify__790000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookupThunk_class, lang.IObj_class}, Declaring: A_arbace_repr_go_lit_Lit_A_class, Simple: "reify__790000019", Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit_Lit_reify__790000019_A", Source: "lit.ae"})

func init() { i := A_arbace_repr_go_lit_Lit_reify__790000019_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit_Lit_reify__790000019_A_InstanceOf; i.Table = A_arbace_repr_go_lit_Lit_reify__790000019_A_members }

func A_arbace_repr_go_lit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_go_lit__init_A_Load__O()}; return nil }

func A_arbace_repr_go_lit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_lit__init_A_New()}; return nil }

var A_arbace_repr_go_lit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_go_lit__init_A_invoke, New: A_arbace_repr_go_lit__init_A_new}

var A_arbace_repr_go_lit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.lit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_lit.A_arbace_repr_go_lit__init_A", Source: "lit.ae"})

func init() { i := A_arbace_repr_go_lit__init_A_class.Info(); i.IsInstance = A_arbace_repr_go_lit__init_A_InstanceOf; i.Init = A_arbace_repr_go_lit__init_A_Init; i.Table = A_arbace_repr_go_lit__init_A_members }
