//line aot_arbace_repr_go_lit_Lit.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(p0, p1, p2, p3 any, p4, p5 int32) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O_O_O_I_I(text, value, __meta, __extmap any, __hash, __hasheq int32) { t.F_text = text; t.F_value = value; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O(text, value any) { t.Ctor_O_O_O_O_I_I(text, value, nil, nil, 0, 0) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O_O_O(text, value, __meta, __extmap any) { t.Ctor_O_O_O_O_I_I(text, value, __meta, __extmap, 0, 0) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_repr_go_lit_Lit_A_Init(); return lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref()) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(m__ lang.IPersistentMap) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_46).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_47).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_46).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_47).Ref()); return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(v__0, v__1, nil, lang.RT_SeqOrElse_O__O_NoInit(m___2), 0, 0) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z_NoInit(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Xor_J_J__J_NoInit(-1282173336, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I_NoInit(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z_NoInit(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I_NoInit(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Equals_O__Z(G__790000012__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z_NoInit(t, G__790000012__1_) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) WithMeta_IPersistentMap__IObj(G__790000012__1_ lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(t.F_text, t.F_value, G__790000012__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__790000021__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I_NoInit(G__790000021__3_) >> 0 & 1 { case 0: if any(G__790000021__3_) == any(A_arbace_repr_go_lit_Lit_A_const_0) { return t.F_text }; case 1: if any(G__790000021__3_) == any(A_arbace_repr_go_lit_Lit_A_const_1) { return t.F_value }; default:}; return lang.RT_Get_O_O_O__O_NoInit(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any; var root_2 any = A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O(); var linked_3 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_4 lang.IFn; if linked_3 == nil { ifn_4 = lang.IFn_Cast(root_2) } else { ifn_4 = nil }; var arg_5 any = t; if linked_3 == nil { gclass__2 = ifn_4.Invoke_O__O(arg_5) } else { gclass__2 = linked_3.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2, arg_5) }; var G__790000016__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__790000016__3_) >> 0 & 1 { case 0: if any(G__790000016__3_) == any(A_arbace_repr_go_lit_Lit_A_const_0) { tmp1 = A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__790000016__3_) == any(A_arbace_repr_go_lit_Lit_A_const_1) { tmp1 = A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(t.F___extmap)))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, Lit_49), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_repr_go_lit_Lit_A_const_3.Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Equiv_O__Z(G__790000012__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(t, G__790000012__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2) } else { var tmp2 any; var root_15 any = A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = t; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_15, arg_18) }; var tmp3 any = tmp2; var tmp4 any; var root_19 any = A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = G__790000012__1_; if linked_20 == nil { tmp4 = ifn_21.Invoke_O__O(arg_22) } else { tmp4 = linked_20.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_19, arg_22) }; if lang.Util_Identical_O_O__Z_NoInit(tmp3, tmp4) { var G__790000012__3_ any = G__790000012__1_; var tmp5 any = t.F_text; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F_text); if and__1927000168__auto____4 { var tmp6 any = t.F_value; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F_value); if and__1927000168__auto____5 { var tmp7 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref()) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { var tmp1 any; var root_23 any = A_arbace_repr_go_lit_Lit_A_const_4.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref(); if linked_24 == nil { tmp1 = ifn_25.Invoke_O__O(arg_26) } else { tmp1 = linked_24.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_23, arg_26) }; return jrt.NN(jrt.Boolean_Cast(tmp1)).BooleanValue__Z() }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z_NoInit(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_32 any = A_arbace_repr_go_lit_Lit_A_const_5.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_27 any = A_arbace_repr_go_lit_Lit_A_const_6.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = lang.Tuple_Create_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_lit_Lit_A_const_0, t.F_text).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_lit_Lit_A_const_1, t.F_value).Ref()); var arg_31 any = t.F___extmap; if linked_28 == nil { arg_35 = ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { arg_35 = linked_28.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) }; if linked_33 == nil { tmp1 = ifn_34.Invoke_O__O(arg_35) } else { tmp1 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; return lang.ISeq_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_repr_go_lit_Lit_A_const_7); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator_NoInit(t.F___extmap)) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__790000012__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_repr_go_lit_Lit_A; var pred__790000014__3 any = A_arbace_repr_go_lit_Lit_A_const_8.GetRawRoot__O(); var expr__790000015__4 any = k__231000086__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__790000014__3).Invoke_O_O__O(A_arbace_repr_go_lit_Lit_A_const_0, expr__790000015__4)) { tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(G__790000012__2_, t.F_value, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__790000014__3).Invoke_O_O__O(A_arbace_repr_go_lit_Lit_A_const_1, expr__790000015__4)) { tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(t.F_text, G__790000012__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_text; var tmp3 any = t.F_value; var tmp4 any = t.F___meta; var tmp5 any; var root_36 any = A_arbace_repr_go_lit_Lit_A_const_9.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t.F___extmap; var arg_40 any = k__231000086__auto____1; var arg_41 any = G__790000012__2_; if linked_37 == nil { tmp5 = ifn_38.Invoke_O_O_O__O(arg_39, arg_40, arg_41) } else { tmp5 = linked_37.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_36, arg_39, arg_40, arg_41) }; tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(tmp2, tmp3, tmp4, tmp5) } }; return Up_A_arbace_repr_go_lit_Lit_A_IPersistentMap(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; var tmp2 any; var root_42 any = A_arbace_repr_go_lit_Lit_A_const_10.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_repr_go_lit_Lit_A_const_11; var arg_46 any = k__231000088__auto____1; if linked_43 == nil { tmp2 = ifn_44.Invoke_O_O__O(arg_45, arg_46) } else { tmp2 = linked_43.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_42, arg_45, arg_46) }; if jrt.J2g_Truth(tmp2) { var root_57 any = A_arbace_repr_go_lit_Lit_A_const_12.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_52 any = A_arbace_repr_go_lit_Lit_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var root_47 any = A_arbace_repr_go_lit_Lit_A_const_14.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_51 any = t; if linked_48 == nil { arg_55 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_55 = linked_48.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; var arg_56 any = t.F___meta; if linked_53 == nil { arg_60 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { arg_60 = linked_53.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; var arg_61 any = k__231000088__auto____1; if linked_58 == nil { tmp1 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { tmp1 = linked_58.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) } } else { var tmp3 any = t.F_text; var tmp4 any = t.F_value; var tmp5 any = t.F___meta; var tmp6 any; var root_67 any = A_arbace_repr_go_lit_Lit_A_const_15.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var root_62 any = A_arbace_repr_go_lit_Lit_A_const_12.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = t.F___extmap; var arg_66 any = k__231000088__auto____1; if linked_63 == nil { arg_70 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_70 = linked_63.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if linked_68 == nil { tmp6 = ifn_69.Invoke_O__O(arg_70) } else { tmp6 = linked_68.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_67, arg_70) }; tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(tmp3, tmp4, tmp5, tmp6) }; return lang.IPersistentMap_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Size__I() int32 { return t.Count__I() }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z_NoInit(0, int64(t.Count__I())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { var tmp1 any; var root_75 any = A_arbace_repr_go_lit_Lit_A_const_16.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)); var arg_79 any; var root_71 any = A_arbace_repr_go_lit_Lit_A_const_17.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = t; if linked_72 == nil { arg_79 = ifn_73.Invoke_O__O(arg_74) } else { arg_79 = linked_72.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_71, arg_74) }; if linked_76 == nil { tmp1 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { tmp1 = linked_76.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) KeySet__Set() jrt.Set { var tmp1 any; var root_84 any = A_arbace_repr_go_lit_Lit_A_const_18.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var root_80 any = A_arbace_repr_go_lit_Lit_A_const_19.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = t; if linked_81 == nil { arg_87 = ifn_82.Invoke_O__O(arg_83) } else { arg_87 = linked_81.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_80, arg_83) }; if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_84, arg_87) }; return jrt.Set_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Values__Collection() jrt.Collection { var tmp1 any; var root_88 any = A_arbace_repr_go_lit_Lit_A_const_17.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = t; if linked_89 == nil { tmp1 = ifn_90.Invoke_O__O(arg_91) } else { tmp1 = linked_89.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_88, arg_91) }; return jrt.Collection_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) EntrySet__Set() jrt.Set { var tmp1 any; var root_92 any = A_arbace_repr_go_lit_Lit_A_const_18.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t; if linked_93 == nil { tmp1 = ifn_94.Invoke_O__O(arg_95) } else { tmp1 = linked_93.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_92, arg_95) }; return jrt.Set_Cast(tmp1) }
//line :13:1
func A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_lit_Lit_reify__790000017_A { t := &A_arbace_repr_go_lit_Lit_reify__790000017_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_7 any; var tmp2 *lang.Var; A_arbace_repr_go_lit_Lit_A_Init(); tmp2 = A_arbace_repr_go_lit_Lit_A_const_2; root_7 = jrt.NN(tmp2).GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = gtarget__1; if linked_8 == nil { tmp1 = ifn_9.Invoke_O__O(arg_10) } else { tmp1 = linked_8.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_7, arg_10) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_repr_go_lit_Lit_A_Cast(gtarget__1).F_text } else { return t } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :13:1
func A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_lit_Lit_reify__790000019_A { t := &A_arbace_repr_go_lit_Lit_reify__790000019_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_11 any; var tmp2 *lang.Var; A_arbace_repr_go_lit_Lit_A_Init(); tmp2 = A_arbace_repr_go_lit_Lit_A_const_2; root_11 = jrt.NN(tmp2).GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = gtarget__1; if linked_12 == nil { tmp1 = ifn_13.Invoke_O__O(arg_14) } else { tmp1 = linked_12.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_11, arg_14) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_repr_go_lit_Lit_A_Cast(gtarget__1).F_value } else { return t } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(m, t.F_gclass) }































































































type A_arbace_repr_go_lit_Lit_A struct{ jrt.Object; F_text, F_value, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_repr_go_lit_Lit_A) Is_IRecord() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IHashEq() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_ILookup() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IKeywordLookup() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IPersistentMap() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Map() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Serializable() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Iterable() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Associative() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Counted() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IPersistentCollection() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Seqable() {}

var A_arbace_repr_go_lit_Lit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit_Lit_A_const_0 *lang.Keyword

var A_arbace_repr_go_lit_Lit_A_const_1 *lang.Keyword

var A_arbace_repr_go_lit_Lit_A_const_2 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_3 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_4 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_5 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_6 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_7 any

var A_arbace_repr_go_lit_Lit_A_const_8 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_9 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_10 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_11 any

var A_arbace_repr_go_lit_Lit_A_const_12 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_13 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_14 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_15 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_16 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_17 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_18 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_19 *lang.Var

var A_arbace_repr_go_lit_Lit_A_init jrt.ClassInit

func A_arbace_repr_go_lit_Lit_A_Init() { if !A_arbace_repr_go_lit_Lit_A_init.Done() { A_arbace_repr_go_lit_Lit_A_init.Run(A_arbace_repr_go_lit_Lit_A_clinit) } }

func A_arbace_repr_go_lit_Lit_A_clinit() { jrt.StartCheck(); A_arbace_repr_go_lit_Lit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_45, 22); A_arbace_repr_go_lit_Lit_A_const_0 = lang.Keyword_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[2]); A_arbace_repr_go_lit_Lit_A_const_1 = lang.Keyword_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[3]); A_arbace_repr_go_lit_Lit_A_const_2 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[4]); A_arbace_repr_go_lit_Lit_A_const_3 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[5]); A_arbace_repr_go_lit_Lit_A_const_4 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[6]); A_arbace_repr_go_lit_Lit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[7]); A_arbace_repr_go_lit_Lit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[8]); A_arbace_repr_go_lit_Lit_A_const_7 = A_arbace_repr_go_lit_Lit_A_const_pool.A[9]; A_arbace_repr_go_lit_Lit_A_const_8 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[10]); A_arbace_repr_go_lit_Lit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[11]); A_arbace_repr_go_lit_Lit_A_const_10 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[12]); A_arbace_repr_go_lit_Lit_A_const_11 = A_arbace_repr_go_lit_Lit_A_const_pool.A[13]; A_arbace_repr_go_lit_Lit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[14]); A_arbace_repr_go_lit_Lit_A_const_13 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[15]); A_arbace_repr_go_lit_Lit_A_const_14 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[16]); A_arbace_repr_go_lit_Lit_A_const_15 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[17]); A_arbace_repr_go_lit_Lit_A_const_16 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[18]); A_arbace_repr_go_lit_Lit_A_const_17 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[19]); A_arbace_repr_go_lit_Lit_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[20]); A_arbace_repr_go_lit_Lit_A_const_19 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[21]) }

func (t *A_arbace_repr_go_lit_Lit_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_repr_go_lit_Lit_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.repr.go.lit.Lit does not define or inherit an implementation of the resolved method 'abstract arbace.lang.IPersistentMap assocEx(java.lang.Object, java.lang.Object)' of interface arbace.lang.IPersistentMap."))) }

func (t *A_arbace_repr_go_lit_Lit_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_repr_go_lit_Lit_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_repr_go_lit_Lit_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_A_class }

func (t *A_arbace_repr_go_lit_Lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_A); return ok }

func A_arbace_repr_go_lit_Lit_A_Cast(x any) *A_arbace_repr_go_lit_Lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_A_class)) }; return v }



type A_arbace_repr_go_lit_Lit_reify__790000017_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_reify__790000017_A_class }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000017_A); return ok }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_Cast(x any) *A_arbace_repr_go_lit_Lit_reify__790000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_reify__790000017_A_class)) }; return v }



type A_arbace_repr_go_lit_Lit_reify__790000019_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_reify__790000019_A_class }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000019_A); return ok }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_Cast(x any) *A_arbace_repr_go_lit_Lit_reify__790000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_reify__790000019_A_class)) }; return v }
