//line aot_arbace_repr_go_lit_Lit.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(p0, p1, p2, p3 any, p4, p5 int32) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O_O_O_I_I(text, value, __meta, __extmap any, __hash, __hasheq int32) { t.F_text = text; t.F_value = value; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O(text, value any) { t.Ctor_O_O_O_O_I_I(text, value, nil, nil, 0, 0) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); t := &A_arbace_repr_go_lit_Lit_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Ctor_O_O_O_O(text, value, __meta, __extmap any) { t.Ctor_O_O_O_O_I_I(text, value, __meta, __extmap, 0, 0) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_repr_go_lit_Lit_A_Init(); return lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref()) }
//line :13:1
func A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(m__ lang.IPersistentMap) *A_arbace_repr_go_lit_Lit_A { A_arbace_repr_go_lit_Lit_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_46).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_47).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_46).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_47).Ref()); return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(v__0, v__1, nil, lang.RT_SeqOrElse_O__O_NoInit(m___2), 0, 0) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z_NoInit(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Xor_J_J__J_NoInit(-1282173336, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I_NoInit(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z_NoInit(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I_NoInit(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Equals_O__Z(G__790000012__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z_NoInit(t, G__790000012__1_) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) WithMeta_IPersistentMap__IObj(G__790000012__1_ lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_A_New_O_O_O_O_I_I(t.F_text, t.F_value, G__790000012__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__790000021__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I_NoInit(G__790000021__3_) >> 0 & 1 { case 0: if any(G__790000021__3_) == any(A_arbace_repr_go_lit_Lit_A_const_0) { return t.F_text }; case 1: if any(G__790000021__3_) == any(A_arbace_repr_go_lit_Lit_A_const_1) { return t.F_value }; default:}; return lang.RT_Get_O_O_O__O_NoInit(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O()).Invoke_O__O(t); var G__790000016__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__790000016__3_) >> 0 & 1 { case 0: if any(G__790000016__3_) == any(A_arbace_repr_go_lit_Lit_A_const_0) { tmp1 = A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__790000016__3_) == any(A_arbace_repr_go_lit_Lit_A_const_1) { tmp1 = A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(t.F___extmap)))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, Lit_49), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_repr_go_lit_Lit_A_const_3.Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Equiv_O__Z(G__790000012__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(t, G__790000012__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2) } else { if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O()).Invoke_O__O(t), lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_2.GetRawRoot__O()).Invoke_O__O(G__790000012__1_)) { var G__790000012__3_ any = G__790000012__1_; var tmp2 any = t.F_text; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F_text); if and__1927000168__auto____4 { var tmp3 any = t.F_value; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F_value); if and__1927000168__auto____5 { var tmp4 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_go_lit_Lit_A_Cast(G__790000012__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref()) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { return jrt.NN(jrt.Boolean_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_4.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref()))).BooleanValue__Z() }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z_NoInit(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Seq__ISeq() lang.ISeq { return lang.ISeq_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_5.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_6.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_lit_Lit_A_const_0, t.F_text).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_repr_go_lit_Lit_A_const_1, t.F_value).Ref()), t.F___extmap))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_repr_go_lit_Lit_A_const_7); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator_NoInit(t.F___extmap)) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__790000012__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_repr_go_lit_Lit_A; var pred__790000014__3 any = A_arbace_repr_go_lit_Lit_A_const_8.GetRawRoot__O(); var expr__790000015__4 any = k__231000086__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__790000014__3).Invoke_O_O__O(A_arbace_repr_go_lit_Lit_A_const_0, expr__790000015__4)) { tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(G__790000012__2_, t.F_value, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__790000014__3).Invoke_O_O__O(A_arbace_repr_go_lit_Lit_A_const_1, expr__790000015__4)) { tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(t.F_text, G__790000012__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_text; var tmp3 any = t.F_value; var tmp4 any = t.F___meta; tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(t.F___extmap, k__231000086__auto____1, G__790000012__2_)) } }; return Up_A_arbace_repr_go_lit_Lit_A_IPersistentMap(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_Lit_A_const_13, k__231000088__auto____1)) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), t), t.F___meta), k__231000088__auto____1) } else { var tmp2 any = t.F_text; var tmp3 any = t.F_value; var tmp4 any = t.F___meta; tmp1 = A_arbace_repr_go_lit_Lit_A_New_O_O_O_O(tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_11.GetRawRoot__O()).Invoke_O_O__O(t.F___extmap, k__231000088__auto____1))) }; return lang.IPersistentMap_Cast(tmp1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Size__I() int32 { return t.Count__I() }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z_NoInit(0, int64(t.Count__I())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { return lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)), lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_17.GetRawRoot__O()).Invoke_O__O(t))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) KeySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_19.GetRawRoot__O()).Invoke_O__O(t))) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) Values__Collection() jrt.Collection { return jrt.Collection_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_17.GetRawRoot__O()).Invoke_O__O(t)) }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_A) EntrySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_Lit_A_const_18.GetRawRoot__O()).Invoke_O__O(t)) }
//line :13:1
func A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_lit_Lit_reify__790000017_A { t := &A_arbace_repr_go_lit_Lit_reify__790000017_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_lit_Lit_A_Init(); tmp1 = A_arbace_repr_go_lit_Lit_A_const_2; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_lit_Lit_A_Cast(gtarget__1).F_text } else { return t } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_reify__790000017_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :13:1
func A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_repr_go_lit_Lit_reify__790000019_A { t := &A_arbace_repr_go_lit_Lit_reify__790000019_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_repr_go_lit_Lit_A_Init(); tmp1 = A_arbace_repr_go_lit_Lit_A_const_2; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_repr_go_lit_Lit_A_Cast(gtarget__1).F_value } else { return t } }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :13:1
func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_repr_go_lit_Lit_reify__790000019_A_New_IPersistentMap_O(m, t.F_gclass) }































































































type A_arbace_repr_go_lit_Lit_A struct{ jrt.Object; F_text, F_value, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_repr_go_lit_Lit_A) Is_IRecord() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IHashEq() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_ILookup() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IKeywordLookup() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IPersistentMap() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Map() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Serializable() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Iterable() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Associative() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Counted() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_IPersistentCollection() {}

func (t *A_arbace_repr_go_lit_Lit_A) Is_Seqable() {}

var A_arbace_repr_go_lit_Lit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit_Lit_A_const_0 *lang.Keyword

var A_arbace_repr_go_lit_Lit_A_const_1 *lang.Keyword

var A_arbace_repr_go_lit_Lit_A_const_2 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_3 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_4 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_5 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_6 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_7 any

var A_arbace_repr_go_lit_Lit_A_const_8 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_9 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_10 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_11 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_12 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_13 any

var A_arbace_repr_go_lit_Lit_A_const_14 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_15 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_16 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_17 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_18 *lang.Var

var A_arbace_repr_go_lit_Lit_A_const_19 *lang.Var

var A_arbace_repr_go_lit_Lit_A_init jrt.ClassInit

func A_arbace_repr_go_lit_Lit_A_Init() { if !A_arbace_repr_go_lit_Lit_A_init.Done() { A_arbace_repr_go_lit_Lit_A_init.Run(A_arbace_repr_go_lit_Lit_A_clinit) } }

func A_arbace_repr_go_lit_Lit_A_clinit() { jrt.StartCheck(); A_arbace_repr_go_lit_Lit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_45, 22); A_arbace_repr_go_lit_Lit_A_const_0 = lang.Keyword_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[2]); A_arbace_repr_go_lit_Lit_A_const_1 = lang.Keyword_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[3]); A_arbace_repr_go_lit_Lit_A_const_2 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[4]); A_arbace_repr_go_lit_Lit_A_const_3 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[5]); A_arbace_repr_go_lit_Lit_A_const_4 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[6]); A_arbace_repr_go_lit_Lit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[7]); A_arbace_repr_go_lit_Lit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[8]); A_arbace_repr_go_lit_Lit_A_const_7 = A_arbace_repr_go_lit_Lit_A_const_pool.A[9]; A_arbace_repr_go_lit_Lit_A_const_8 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[10]); A_arbace_repr_go_lit_Lit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[11]); A_arbace_repr_go_lit_Lit_A_const_10 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[12]); A_arbace_repr_go_lit_Lit_A_const_11 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[13]); A_arbace_repr_go_lit_Lit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[14]); A_arbace_repr_go_lit_Lit_A_const_13 = A_arbace_repr_go_lit_Lit_A_const_pool.A[15]; A_arbace_repr_go_lit_Lit_A_const_14 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[16]); A_arbace_repr_go_lit_Lit_A_const_15 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[17]); A_arbace_repr_go_lit_Lit_A_const_16 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[18]); A_arbace_repr_go_lit_Lit_A_const_17 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[19]); A_arbace_repr_go_lit_Lit_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[20]); A_arbace_repr_go_lit_Lit_A_const_19 = lang.Var_Cast(A_arbace_repr_go_lit_Lit_A_const_pool.A[21]) }

func (t *A_arbace_repr_go_lit_Lit_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_repr_go_lit_Lit_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.repr.go.lit.Lit does not define or inherit an implementation of the resolved method 'abstract arbace.lang.IPersistentMap assocEx(java.lang.Object, java.lang.Object)' of interface arbace.lang.IPersistentMap."))) }

func (t *A_arbace_repr_go_lit_Lit_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_repr_go_lit_Lit_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_repr_go_lit_Lit_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_repr_go_lit_Lit_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_repr_go_lit_Lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_A_class }

func (t *A_arbace_repr_go_lit_Lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_A); return ok }

func A_arbace_repr_go_lit_Lit_A_Cast(x any) *A_arbace_repr_go_lit_Lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_A_class)) }; return v }



type A_arbace_repr_go_lit_Lit_reify__790000017_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_reify__790000017_A_class }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000017_A); return ok }

func A_arbace_repr_go_lit_Lit_reify__790000017_A_Cast(x any) *A_arbace_repr_go_lit_Lit_reify__790000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_reify__790000017_A_class)) }; return v }



type A_arbace_repr_go_lit_Lit_reify__790000019_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_ILookupThunk() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_IObj() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Is_IMeta() {}

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_Lit_reify__790000019_A_class }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_Lit_reify__790000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000019_A); return ok }

func A_arbace_repr_go_lit_Lit_reify__790000019_A_Cast(x any) *A_arbace_repr_go_lit_Lit_reify__790000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_Lit_reify__790000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_Lit_reify__790000019_A_class)) }; return v }
