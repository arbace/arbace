//line aot_arbace_repr_go_lit__init.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_lit__init_A_Unit0__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_lit__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_lit__init_A_Unit1__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_lit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_lit__init_A_Unit2__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_lit__init_A_Unit3__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_lit__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_lit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_lit_eval790000008_fn__790000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_lit_eval790000008_fn__790000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_go_lit_eval790000008_fn__790000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_lit__init_A_Load__O() any { A_arbace_repr_go_lit__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_lit__init_A_Unit0__O(); A_arbace_repr_go_lit__init_A_Unit1__O(); A_arbace_repr_go_lit__init_A_Unit2__O(); A_arbace_repr_go_lit__init_A_Unit3__O(); A_arbace_repr_go_lit__init_A_Unit4__O(); A_arbace_repr_go_lit__init_A_Unit5__O(); A_arbace_repr_go_lit__init_A_Unit6__O(); A_arbace_repr_go_lit__init_A_Unit7__O(); A_arbace_repr_go_lit__init_A_Unit8__O(); A_arbace_repr_go_lit__init_A_Unit9__O(); A_arbace_repr_go_lit__init_A_Unit10__O(); A_arbace_repr_go_lit__init_A_Unit11__O(); A_arbace_repr_go_lit__init_A_Unit12__O(); A_arbace_repr_go_lit__init_A_Unit13__O(); A_arbace_repr_go_lit__init_A_Unit14__O(); A_arbace_repr_go_lit__init_A_Unit15__O(); A_arbace_repr_go_lit__init_A_Unit16__O(); A_arbace_repr_go_lit__init_A_Unit17__O(); A_arbace_repr_go_lit__init_A_Unit18__O(); A_arbace_repr_go_lit__init_A_Unit19__O(); A_arbace_repr_go_lit__init_A_Unit20__O(); A_arbace_repr_go_lit__init_A_Unit21__O(); A_arbace_repr_go_lit__init_A_Unit22__O(); A_arbace_repr_go_lit__init_A_Unit23__O(); A_arbace_repr_go_lit__init_A_Unit24__O(); A_arbace_repr_go_lit__init_A_Unit25__O(); A_arbace_repr_go_lit__init_A_Unit26__O(); A_arbace_repr_go_lit__init_A_Unit27__O(); A_arbace_repr_go_lit__init_A_Unit28__O(); A_arbace_repr_go_lit__init_A_Unit29__O(); A_arbace_repr_go_lit__init_A_Unit30__O(); A_arbace_repr_go_lit__init_A_Unit31__O(); A_arbace_repr_go_lit__init_A_Unit32__O(); A_arbace_repr_go_lit__init_A_Unit33__O(); A_arbace_repr_go_lit__init_A_Unit34__O(); A_arbace_repr_go_lit__init_A_Unit35__O(); A_arbace_repr_go_lit__init_A_Unit36__O(); A_arbace_repr_go_lit__init_A_Unit37__O(); A_arbace_repr_go_lit__init_A_Unit38__O(); A_arbace_repr_go_lit__init_A_Unit39__O(); return nil }







func A_arbace_repr_go_lit__init_A_Unit4__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_6)); var tmp2 *lang.Var = A_arbace_repr_go_lit__init_A_const_7; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_49)); var tmp3 *lang.Var = A_arbace_repr_go_lit__init_A_const_5; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_9)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_5; var tmp5 any = A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_New(); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; tmp4.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp7 *lang.Var = A_arbace_repr_go_lit__init_A_const_7; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_10)); var tmp8 *lang.Var = A_arbace_repr_go_lit__init_A_const_7; var tmp9 any = A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_New(); var tmp10 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_fn_class = fncls__4d; tmp10 = fncls__4d } else { tmp10 = fncls__4 }; tmp8.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); return A_arbace_repr_go_lit__init_A_const_4 }

func A_arbace_repr_go_lit__init_A_Unit5__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_11; var tmp2 any = A_arbace_repr_go_lit_lit_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_lit_lit_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_repr_go_lit_lit_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_12)); return A_arbace_repr_go_lit__init_A_const_11 }

func A_arbace_repr_go_lit__init_A_Unit6__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_13; var tmp2 any = A_arbace_repr_go_lit_lit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_lit_lit_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_repr_go_lit_lit_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_14)); return A_arbace_repr_go_lit__init_A_const_13 }



func A_arbace_repr_go_lit__init_A_Unit7__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_repr_go_lit__init_A_const_15.BindRoot_O__V(A_arbace_repr_go_lit__init_A_const_16); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_17)); return A_arbace_repr_go_lit__init_A_const_15 }



func A_arbace_repr_go_lit__init_A_Unit8__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_18; var tmp2 any = A_arbace_repr_go_lit_printable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_lit_printable_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_repr_go_lit_printable_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_19)); return A_arbace_repr_go_lit__init_A_const_18 }













func A_arbace_repr_go_lit__init_A_Unit9__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_20; var tmp2 any = A_arbace_repr_go_lit_string_text_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_lit_string_text_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_repr_go_lit_string_text_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_21)); return A_arbace_repr_go_lit__init_A_const_20 }























func A_arbace_repr_go_lit__init_A_Unit10__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_22; var tmp2 any = A_arbace_repr_go_lit_char_text_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_lit_char_text_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_repr_go_lit_char_text_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_23)); return A_arbace_repr_go_lit__init_A_const_22 }










func A_arbace_repr_go_lit__init_A_Unit11__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_24; var tmp2 any = A_arbace_repr_go_lit_int_lit_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_lit_int_lit_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_repr_go_lit_int_lit_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_25)); return A_arbace_repr_go_lit__init_A_const_24 }















func A_arbace_repr_go_lit__init_A_Unit12__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_26; var tmp2 any = A_arbace_repr_go_lit_integer_text_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_lit_integer_text_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_repr_go_lit_integer_text_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_27)); return A_arbace_repr_go_lit__init_A_const_26 }





func A_arbace_repr_go_lit__init_A_Unit13__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_28; var tmp2 any = A_arbace_repr_go_lit_integer_lit_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_lit_integer_lit_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_repr_go_lit_integer_lit_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_29)); return A_arbace_repr_go_lit__init_A_const_28 }





func A_arbace_repr_go_lit__init_A_Unit14__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_30; var tmp2 any = A_arbace_repr_go_lit_rational_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_lit_rational_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_go_lit_rational_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_31)); return A_arbace_repr_go_lit__init_A_const_30 }




func A_arbace_repr_go_lit__init_A_Unit15__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_32; var tmp2 any = A_arbace_repr_go_lit_pow2_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_lit_pow2_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_repr_go_lit_pow2_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_33)); return A_arbace_repr_go_lit__init_A_const_32 }

func A_arbace_repr_go_lit__init_A_Unit16__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_34; var tmp2 any = A_arbace_repr_go_lit_pow5_exponent_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_go_lit_pow5_exponent_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_repr_go_lit_pow5_exponent_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_35)); return A_arbace_repr_go_lit__init_A_const_34 }







func A_arbace_repr_go_lit__init_A_Unit17__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_36; var tmp2 any = A_arbace_repr_go_lit_num_den_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_lit_num_den_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_repr_go_lit_num_den_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_37)); return A_arbace_repr_go_lit__init_A_const_36 }




func A_arbace_repr_go_lit__init_A_Unit18__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); A_arbace_repr_go_lit__init_A_const_38.BindRoot_O__V(A_arbace_repr_go_lit__init_A_const_39); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_40)); return A_arbace_repr_go_lit__init_A_const_38 }




func A_arbace_repr_go_lit__init_A_Unit19__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_41; var tmp2 any = A_arbace_repr_go_lit_terminating_decimal_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_go_lit_terminating_decimal_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_repr_go_lit_terminating_decimal_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_42)); return A_arbace_repr_go_lit__init_A_const_41 }











func A_arbace_repr_go_lit__init_A_Unit20__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_43; var tmp2 any = A_arbace_repr_go_lit_double_exact_text_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_go_lit_double_exact_text_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_repr_go_lit_double_exact_text_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_44)); return A_arbace_repr_go_lit__init_A_const_43 }












func A_arbace_repr_go_lit__init_A_Unit21__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_45; var tmp2 any = A_arbace_repr_go_lit_decimal_text_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_lit_decimal_text_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_repr_go_lit_decimal_text_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_46)); return A_arbace_repr_go_lit__init_A_const_45 }





func A_arbace_repr_go_lit__init_A_Unit22__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_47; var tmp2 any = A_arbace_repr_go_lit_float_lit_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_lit_float_lit_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_repr_go_lit_float_lit_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_48)); return A_arbace_repr_go_lit__init_A_const_47 }


















func A_arbace_repr_go_lit__init_A_Unit23__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_49; var tmp2 any = A_arbace_repr_go_lit_exact_double_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_lit_exact_double_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_go_lit_exact_double_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_50)); return A_arbace_repr_go_lit__init_A_const_49 }









func A_arbace_repr_go_lit__init_A_Unit24__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_51; var tmp2 any = A_arbace_repr_go_lit_double_lit_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_lit_double_lit_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_repr_go_lit_double_lit_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_52)); return A_arbace_repr_go_lit__init_A_const_51 }








func A_arbace_repr_go_lit__init_A_Unit25__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_53; var tmp2 any = A_arbace_repr_go_lit_hex_float_value_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_lit_hex_float_value_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_repr_go_lit_hex_float_value_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_54)); return A_arbace_repr_go_lit__init_A_const_53 }
















func A_arbace_repr_go_lit__init_A_Unit26__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_55; var tmp2 any = A_arbace_repr_go_lit_float_value_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_lit_float_value_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_repr_go_lit_float_value_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_56)); return A_arbace_repr_go_lit__init_A_const_55 }








func A_arbace_repr_go_lit__init_A_Unit27__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_57; var tmp2 any = A_arbace_repr_go_lit_float_text_lit_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_go_lit_float_text_lit_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_go_lit_float_text_lit_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_58)); return A_arbace_repr_go_lit__init_A_const_57 }






func A_arbace_repr_go_lit__init_A_Unit28__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_59; var tmp2 any = A_arbace_repr_go_lit_imag_inner_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_repr_go_lit_imag_inner_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_go_lit_imag_inner_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_60)); return A_arbace_repr_go_lit__init_A_const_59 }















func A_arbace_repr_go_lit__init_A_Unit29__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_61; var tmp2 any = A_arbace_repr_go_lit_hexv_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_lit_hexv_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_go_lit_hexv_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_62)); return A_arbace_repr_go_lit__init_A_const_61 }

func A_arbace_repr_go_lit__init_A_Unit30__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_63; var tmp2 any = A_arbace_repr_go_lit_unescape_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_go_lit_unescape_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_go_lit_unescape_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_64)); return A_arbace_repr_go_lit__init_A_const_63 }

































func A_arbace_repr_go_lit__init_A_Unit31__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_65; var tmp2 any = A_arbace_repr_go_lit_string_bytes_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_lit_string_bytes_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_go_lit_string_bytes_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_66)); return A_arbace_repr_go_lit__init_A_const_65 }






func A_arbace_repr_go_lit__init_A_Unit32__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_67; var tmp2 any = A_arbace_repr_go_lit_rune_value_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_lit_rune_value_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_go_lit_rune_value_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_68)); return A_arbace_repr_go_lit__init_A_const_67 }













func A_arbace_repr_go_lit__init_A_Unit33__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(302, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_69; var tmp2 any = A_arbace_repr_go_lit_decode_rune_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_lit_decode_rune_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_go_lit_decode_rune_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_70)); return A_arbace_repr_go_lit__init_A_const_69 }




























func A_arbace_repr_go_lit__init_A_Unit34__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_71; var tmp2 any = A_arbace_repr_go_lit_utf8_parts_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_lit_utf8_parts_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_repr_go_lit_utf8_parts_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_72)); return A_arbace_repr_go_lit__init_A_const_71 }














func A_arbace_repr_go_lit__init_A_Unit35__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_73; var tmp2 any = A_arbace_repr_go_lit_rune_form_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_go_lit_rune_form_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_repr_go_lit_rune_form_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_74)); return A_arbace_repr_go_lit__init_A_const_73 }








func A_arbace_repr_go_lit__init_A_Unit36__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(355, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_75; var tmp2 any = A_arbace_repr_go_lit_bytes_form_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_lit_bytes_form_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_repr_go_lit_bytes_form_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_76)); return A_arbace_repr_go_lit__init_A_const_75 }











func A_arbace_repr_go_lit__init_A_Unit37__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_77; var tmp2 any = A_arbace_repr_go_lit_val_rational_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_lit_val_rational_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_repr_go_lit_val_rational_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_78)); return A_arbace_repr_go_lit__init_A_const_77 }












func A_arbace_repr_go_lit__init_A_Unit38__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(380, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_79; var tmp2 any = A_arbace_repr_go_lit_untyped_float_form_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_go_lit_untyped_float_form_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_go_lit_untyped_float_form_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_80)); return A_arbace_repr_go_lit__init_A_const_79 }








func A_arbace_repr_go_lit__init_A_Unit39__O() any { A_arbace_repr_go_lit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_repr_go_lit__init_A_const_81; var tmp2 any = A_arbace_repr_go_lit_const_form_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_lit_const_form_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_repr_go_lit_const_form_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_lit__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_lit__init_A_const_82)); return A_arbace_repr_go_lit__init_A_const_81 }



type A_arbace_repr_go_lit__init_A struct{ jrt.Object }

var A_arbace_repr_go_lit__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit__init_A_const_0 *lang.Var

var A_arbace_repr_go_lit__init_A_const_1 any

var A_arbace_repr_go_lit__init_A_const_2 any

var A_arbace_repr_go_lit__init_A_const_3 any

var A_arbace_repr_go_lit__init_A_const_4 *jrt.Class

var A_arbace_repr_go_lit__init_A_const_5 *lang.Var

var A_arbace_repr_go_lit__init_A_const_6 any

var A_arbace_repr_go_lit__init_A_const_7 *lang.Var

var A_arbace_repr_go_lit__init_A_const_8 any

var A_arbace_repr_go_lit__init_A_const_9 any

var A_arbace_repr_go_lit__init_A_const_10 any

var A_arbace_repr_go_lit__init_A_const_11 *lang.Var

var A_arbace_repr_go_lit__init_A_const_12 any

var A_arbace_repr_go_lit__init_A_const_13 *lang.Var

var A_arbace_repr_go_lit__init_A_const_14 any

var A_arbace_repr_go_lit__init_A_const_15 *lang.Var

var A_arbace_repr_go_lit__init_A_const_16 any

var A_arbace_repr_go_lit__init_A_const_17 any

var A_arbace_repr_go_lit__init_A_const_18 *lang.Var

var A_arbace_repr_go_lit__init_A_const_19 any

var A_arbace_repr_go_lit__init_A_const_20 *lang.Var

var A_arbace_repr_go_lit__init_A_const_21 any

var A_arbace_repr_go_lit__init_A_const_22 *lang.Var

var A_arbace_repr_go_lit__init_A_const_23 any

var A_arbace_repr_go_lit__init_A_const_24 *lang.Var

var A_arbace_repr_go_lit__init_A_const_25 any

var A_arbace_repr_go_lit__init_A_const_26 *lang.Var

var A_arbace_repr_go_lit__init_A_const_27 any

var A_arbace_repr_go_lit__init_A_const_28 *lang.Var

var A_arbace_repr_go_lit__init_A_const_29 any

var A_arbace_repr_go_lit__init_A_const_30 *lang.Var

var A_arbace_repr_go_lit__init_A_const_31 any

var A_arbace_repr_go_lit__init_A_const_32 *lang.Var

var A_arbace_repr_go_lit__init_A_const_33 any

var A_arbace_repr_go_lit__init_A_const_34 *lang.Var

var A_arbace_repr_go_lit__init_A_const_35 any

var A_arbace_repr_go_lit__init_A_const_36 *lang.Var

var A_arbace_repr_go_lit__init_A_const_37 any

var A_arbace_repr_go_lit__init_A_const_38 *lang.Var

var A_arbace_repr_go_lit__init_A_const_39 any

var A_arbace_repr_go_lit__init_A_const_40 any

var A_arbace_repr_go_lit__init_A_const_41 *lang.Var

var A_arbace_repr_go_lit__init_A_const_42 any

var A_arbace_repr_go_lit__init_A_const_43 *lang.Var

var A_arbace_repr_go_lit__init_A_const_44 any

var A_arbace_repr_go_lit__init_A_const_45 *lang.Var

var A_arbace_repr_go_lit__init_A_const_46 any

var A_arbace_repr_go_lit__init_A_const_47 *lang.Var

var A_arbace_repr_go_lit__init_A_const_48 any

var A_arbace_repr_go_lit__init_A_const_49 *lang.Var

var A_arbace_repr_go_lit__init_A_const_50 any

var A_arbace_repr_go_lit__init_A_const_51 *lang.Var

var A_arbace_repr_go_lit__init_A_const_52 any

var A_arbace_repr_go_lit__init_A_const_53 *lang.Var

var A_arbace_repr_go_lit__init_A_const_54 any

var A_arbace_repr_go_lit__init_A_const_55 *lang.Var

var A_arbace_repr_go_lit__init_A_const_56 any

var A_arbace_repr_go_lit__init_A_const_57 *lang.Var

var A_arbace_repr_go_lit__init_A_const_58 any

var A_arbace_repr_go_lit__init_A_const_59 *lang.Var

var A_arbace_repr_go_lit__init_A_const_60 any

var A_arbace_repr_go_lit__init_A_const_61 *lang.Var

var A_arbace_repr_go_lit__init_A_const_62 any

var A_arbace_repr_go_lit__init_A_const_63 *lang.Var

var A_arbace_repr_go_lit__init_A_const_64 any

var A_arbace_repr_go_lit__init_A_const_65 *lang.Var

var A_arbace_repr_go_lit__init_A_const_66 any

var A_arbace_repr_go_lit__init_A_const_67 *lang.Var

var A_arbace_repr_go_lit__init_A_const_68 any

var A_arbace_repr_go_lit__init_A_const_69 *lang.Var

var A_arbace_repr_go_lit__init_A_const_70 any

var A_arbace_repr_go_lit__init_A_const_71 *lang.Var

var A_arbace_repr_go_lit__init_A_const_72 any

var A_arbace_repr_go_lit__init_A_const_73 *lang.Var

var A_arbace_repr_go_lit__init_A_const_74 any

var A_arbace_repr_go_lit__init_A_const_75 *lang.Var

var A_arbace_repr_go_lit__init_A_const_76 any

var A_arbace_repr_go_lit__init_A_const_77 *lang.Var

var A_arbace_repr_go_lit__init_A_const_78 any

var A_arbace_repr_go_lit__init_A_const_79 *lang.Var

var A_arbace_repr_go_lit__init_A_const_80 any

var A_arbace_repr_go_lit__init_A_const_81 *lang.Var

var A_arbace_repr_go_lit__init_A_const_82 any

var A_arbace_repr_go_lit__init_A_init jrt.ClassInit

func A_arbace_repr_go_lit__init_A_Init() { if !A_arbace_repr_go_lit__init_A_init.Done() { A_arbace_repr_go_lit__init_A_init.Run(A_arbace_repr_go_lit__init_A_clinit) } }

func A_arbace_repr_go_lit__init_A_clinit() { A_arbace_repr_go_lit__init_A_clinit_p0(); A_arbace_repr_go_lit__init_A_clinit_p1(); A_arbace_repr_go_lit__init_A_clinit_p2(); A_arbace_repr_go_lit__init_A_clinit_p3(); A_arbace_repr_go_lit__init_A_clinit_p4(); A_arbace_repr_go_lit__init_A_clinit_p5(); A_arbace_repr_go_lit__init_A_clinit_p6() }

func A_arbace_repr_go_lit__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_lit__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_50, 110); A_arbace_repr_go_lit__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[27]); A_arbace_repr_go_lit__init_A_const_1 = A_arbace_repr_go_lit__init_A_const_pool.A[28]; A_arbace_repr_go_lit__init_A_const_2 = A_arbace_repr_go_lit__init_A_const_pool.A[29]; A_arbace_repr_go_lit__init_A_const_3 = A_arbace_repr_go_lit__init_A_const_pool.A[30]; A_arbace_repr_go_lit__init_A_const_4 = jrt.Class_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[31]); A_arbace_repr_go_lit__init_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[32]); A_arbace_repr_go_lit__init_A_const_6 = A_arbace_repr_go_lit__init_A_const_pool.A[33]; A_arbace_repr_go_lit__init_A_const_7 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[34]); A_arbace_repr_go_lit__init_A_const_8 = A_arbace_repr_go_lit__init_A_const_pool.A[35]; A_arbace_repr_go_lit__init_A_const_9 = A_arbace_repr_go_lit__init_A_const_pool.A[36]; A_arbace_repr_go_lit__init_A_const_10 = A_arbace_repr_go_lit__init_A_const_pool.A[37]; A_arbace_repr_go_lit__init_A_const_11 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[38]); A_arbace_repr_go_lit__init_A_const_12 = A_arbace_repr_go_lit__init_A_const_pool.A[39] }

func A_arbace_repr_go_lit__init_A_clinit_p1() { A_arbace_repr_go_lit__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[40]); A_arbace_repr_go_lit__init_A_const_14 = A_arbace_repr_go_lit__init_A_const_pool.A[41]; A_arbace_repr_go_lit__init_A_const_15 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[42]); A_arbace_repr_go_lit__init_A_const_16 = A_arbace_repr_go_lit__init_A_const_pool.A[43]; A_arbace_repr_go_lit__init_A_const_17 = A_arbace_repr_go_lit__init_A_const_pool.A[44]; A_arbace_repr_go_lit__init_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[45]); A_arbace_repr_go_lit__init_A_const_19 = A_arbace_repr_go_lit__init_A_const_pool.A[46]; A_arbace_repr_go_lit__init_A_const_20 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[47]); A_arbace_repr_go_lit__init_A_const_21 = A_arbace_repr_go_lit__init_A_const_pool.A[48]; A_arbace_repr_go_lit__init_A_const_22 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[49]); A_arbace_repr_go_lit__init_A_const_23 = A_arbace_repr_go_lit__init_A_const_pool.A[50]; A_arbace_repr_go_lit__init_A_const_24 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[51]); A_arbace_repr_go_lit__init_A_const_25 = A_arbace_repr_go_lit__init_A_const_pool.A[52] }

func A_arbace_repr_go_lit__init_A_clinit_p2() { A_arbace_repr_go_lit__init_A_const_26 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[53]); A_arbace_repr_go_lit__init_A_const_27 = A_arbace_repr_go_lit__init_A_const_pool.A[54]; A_arbace_repr_go_lit__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[55]); A_arbace_repr_go_lit__init_A_const_29 = A_arbace_repr_go_lit__init_A_const_pool.A[56]; A_arbace_repr_go_lit__init_A_const_30 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[57]); A_arbace_repr_go_lit__init_A_const_31 = A_arbace_repr_go_lit__init_A_const_pool.A[58]; A_arbace_repr_go_lit__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[59]); A_arbace_repr_go_lit__init_A_const_33 = A_arbace_repr_go_lit__init_A_const_pool.A[60]; A_arbace_repr_go_lit__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[61]); A_arbace_repr_go_lit__init_A_const_35 = A_arbace_repr_go_lit__init_A_const_pool.A[62]; A_arbace_repr_go_lit__init_A_const_36 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[63]); A_arbace_repr_go_lit__init_A_const_37 = A_arbace_repr_go_lit__init_A_const_pool.A[64]; A_arbace_repr_go_lit__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[65]) }

func A_arbace_repr_go_lit__init_A_clinit_p3() { A_arbace_repr_go_lit__init_A_const_39 = A_arbace_repr_go_lit__init_A_const_pool.A[66]; A_arbace_repr_go_lit__init_A_const_40 = A_arbace_repr_go_lit__init_A_const_pool.A[67]; A_arbace_repr_go_lit__init_A_const_41 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[68]); A_arbace_repr_go_lit__init_A_const_42 = A_arbace_repr_go_lit__init_A_const_pool.A[69]; A_arbace_repr_go_lit__init_A_const_43 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[70]); A_arbace_repr_go_lit__init_A_const_44 = A_arbace_repr_go_lit__init_A_const_pool.A[71]; A_arbace_repr_go_lit__init_A_const_45 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[72]); A_arbace_repr_go_lit__init_A_const_46 = A_arbace_repr_go_lit__init_A_const_pool.A[73]; A_arbace_repr_go_lit__init_A_const_47 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[74]); A_arbace_repr_go_lit__init_A_const_48 = A_arbace_repr_go_lit__init_A_const_pool.A[75]; A_arbace_repr_go_lit__init_A_const_49 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[76]); A_arbace_repr_go_lit__init_A_const_50 = A_arbace_repr_go_lit__init_A_const_pool.A[77]; A_arbace_repr_go_lit__init_A_const_51 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[78]); A_arbace_repr_go_lit__init_A_const_52 = A_arbace_repr_go_lit__init_A_const_pool.A[79] }

func A_arbace_repr_go_lit__init_A_clinit_p4() { A_arbace_repr_go_lit__init_A_const_53 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[80]); A_arbace_repr_go_lit__init_A_const_54 = A_arbace_repr_go_lit__init_A_const_pool.A[81]; A_arbace_repr_go_lit__init_A_const_55 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[82]); A_arbace_repr_go_lit__init_A_const_56 = A_arbace_repr_go_lit__init_A_const_pool.A[83]; A_arbace_repr_go_lit__init_A_const_57 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[84]); A_arbace_repr_go_lit__init_A_const_58 = A_arbace_repr_go_lit__init_A_const_pool.A[85]; A_arbace_repr_go_lit__init_A_const_59 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[86]); A_arbace_repr_go_lit__init_A_const_60 = A_arbace_repr_go_lit__init_A_const_pool.A[87]; A_arbace_repr_go_lit__init_A_const_61 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[88]); A_arbace_repr_go_lit__init_A_const_62 = A_arbace_repr_go_lit__init_A_const_pool.A[89]; A_arbace_repr_go_lit__init_A_const_63 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[90]); A_arbace_repr_go_lit__init_A_const_64 = A_arbace_repr_go_lit__init_A_const_pool.A[91]; A_arbace_repr_go_lit__init_A_const_65 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[92]) }

func A_arbace_repr_go_lit__init_A_clinit_p5() { A_arbace_repr_go_lit__init_A_const_66 = A_arbace_repr_go_lit__init_A_const_pool.A[93]; A_arbace_repr_go_lit__init_A_const_67 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[94]); A_arbace_repr_go_lit__init_A_const_68 = A_arbace_repr_go_lit__init_A_const_pool.A[95]; A_arbace_repr_go_lit__init_A_const_69 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[96]); A_arbace_repr_go_lit__init_A_const_70 = A_arbace_repr_go_lit__init_A_const_pool.A[97]; A_arbace_repr_go_lit__init_A_const_71 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[98]); A_arbace_repr_go_lit__init_A_const_72 = A_arbace_repr_go_lit__init_A_const_pool.A[99]; A_arbace_repr_go_lit__init_A_const_73 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[100]); A_arbace_repr_go_lit__init_A_const_74 = A_arbace_repr_go_lit__init_A_const_pool.A[101]; A_arbace_repr_go_lit__init_A_const_75 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[102]); A_arbace_repr_go_lit__init_A_const_76 = A_arbace_repr_go_lit__init_A_const_pool.A[103]; A_arbace_repr_go_lit__init_A_const_77 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[104]); A_arbace_repr_go_lit__init_A_const_78 = A_arbace_repr_go_lit__init_A_const_pool.A[105] }

func A_arbace_repr_go_lit__init_A_clinit_p6() { A_arbace_repr_go_lit__init_A_const_79 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[106]); A_arbace_repr_go_lit__init_A_const_80 = A_arbace_repr_go_lit__init_A_const_pool.A[107]; A_arbace_repr_go_lit__init_A_const_81 = lang.Var_Cast(A_arbace_repr_go_lit__init_A_const_pool.A[108]); A_arbace_repr_go_lit__init_A_const_82 = A_arbace_repr_go_lit__init_A_const_pool.A[109] }

func A_arbace_repr_go_lit__init_A_New() *A_arbace_repr_go_lit__init_A { A_arbace_repr_go_lit__init_A_Init(); t := &A_arbace_repr_go_lit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit__init_A) Ctor() {}

func (t *A_arbace_repr_go_lit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit__init_A_class }

func (t *A_arbace_repr_go_lit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit__init_A); return ok }

func A_arbace_repr_go_lit__init_A_Cast(x any) *A_arbace_repr_go_lit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit__init_A_class)) }; return v }
