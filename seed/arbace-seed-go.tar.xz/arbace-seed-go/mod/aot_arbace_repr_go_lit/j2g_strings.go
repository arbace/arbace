//line j2g_strings.ae:1
package aot_arbace_repr_go_lit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,elsekn12,prefer-ratioyn4,runeyn11,byte-stringkn5,floatkn1,vyn12,binary-floatkn4,boolkn6,stringkn5,byteskn3,intkn7,complexkn13,untyped-floatkn15,untyped-complexkn4,runeyn7,complexv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn18,arbace.repr.go.litm2,R4,s460,Go literals and constant values as Clojure literals (doc/go/SPEC.md §8): integers, exact\n  floats (doubles, BigDecimals, ratios), runes, strings and byte strings, and the\n  representation of constant values (:val, §8.2) from the helper's exact values and go/types'\n  types.\n\n  A literal is a Lit: the text written into the forms and the value the reader reads back.\n  Composite spellings ((rune n), (imaginary x), (byte-string ...), (complex re im)) are lists.v11,arbace.core13,*loaded-libs*v11,arbace.core4,intov18,arbace.repr.go.lit5,->Litv11,arbace.core3,notv11,arbace.core2,<=v11,arbace.core9,contains?l55296,l57343,l65520,l65535,v11,arbace.core3,strv18,arbace.repr.go.lit10,printable?v11,arbace.core6,formatR5,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextv18,arbace.repr.go.lit10,char-namesv13,arbace.string7,replacev13,arbace.string10,lower-casev13,arbace.string12,starts-with?v11,arbace.core6,bigintv18,arbace.repr.go.lit3,litl16,v11,arbace.core4,subsl2,l8,l1,l10,v11,arbace.core10,bigintegerv18,arbace.repr.go.lit12,integer-textl5,v11,arbace.core4,somev11,arbace.core6,ratio?v11,arbace.core9,numeratorv11,arbace.core11,denominatorv18,arbace.repr.go.lit13,pow5-exponentv11,arbace.core11,rationalizev13,arbace.string9,includes?v11,arbace.core8,to-arrayR6,v18,arbace.repr.go.lit17,double-exact-textv18,arbace.repr.go.lit12,decimal-textv18,arbace.repr.go.lit7,num-denv18,arbace.repr.go.lit19,terminating-decimalv18,arbace.repr.go.lit18,max-decimal-lengthC20,java.math.BigDecimalv18,arbace.repr.go.lit9,float-litv13,arbace.string8,index-ofv11,arbace.core6,empty?v18,arbace.repr.go.lit8,rationall0,v18,arbace.repr.go.lit4,pow2v18,arbace.repr.go.lit15,hex-float-valuev18,arbace.repr.go.lit11,float-valuev11,arbace.core10,re-matchesv18,arbace.repr.go.lit7,int-litv18,arbace.repr.go.lit14,float-text-litp6,[0-9]+p8,0[xob].*v11,arbace.core4,not=c34,c39,c85,c92,v18,arbace.repr.go.lit4,hexvc97,c98,c102,c110,c114,c116,c117,c118,c120,v18,arbace.repr.go.lit8,unescapec48,c49,c50,c51,c52,c53,c54,c55,V2,l-1,l1,V2,l-1,l1,V2,l-1,l1,V2,l-1,l1,V2,l-1,l1,l3,l4,v18,arbace.repr.go.lit11,decode-runev11,arbace.core4,listl65535,l55296,l57343,v18,arbace.repr.go.lit9,char-textR7,v18,arbace.repr.go.lit10,utf8-partsv11,arbace.core6,every?v11,arbace.core5,applyv11,arbace.core7,string?v18,arbace.repr.go.lit11,string-textR8,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core8,integer?v11,arbace.core4,seq?R9,v11,arbace.core6,secondv11,arbace.core7,ex-infov11,arbace.core6,pr-strR10,R11,v18,arbace.repr.go.lit11,integer-litv18,arbace.repr.go.lit12,val-rationalv11,arbace.core8,boolean?R12,R13,R14,R15,R16,R17,v18,arbace.repr.go.lit18,untyped-float-formR18,v18,arbace.repr.go.lit10,double-litR19,v18,arbace.repr.go.lit9,rune-formR20,v18,arbace.repr.go.lit10,bytes-formv11,arbace.core3,mapv11,arbace.core14,unchecked-byte")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.lit$bytes_form$iter__790000088__790000092")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.lit$bytes_form$iter__790000088__790000092$fn__790000093")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.lit$bytes_form$iter__790000088__790000092$fn__790000093$fn__790000094")

var Lit_4 *jrt.String = jrt.Intern("0x%02x")

var Lit_5 *jrt.String = jrt.Intern("\\")

var Lit_6 *jrt.String = jrt.Intern("\\u%04x")

var Lit_7 *jrt.String = jrt.Intern("integer constant with value ")

var Lit_8 *jrt.String = jrt.Intern(".")

var Lit_9 *jrt.String = jrt.Intern("E")

var Lit_10 *jrt.String = jrt.Intern(".0")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.lit$decode_rune$b__790000073")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.lit$decode_rune$cont_QMARK___790000075")

var Lit_13 *jrt.String = jrt.Intern("##NaN")

var Lit_14 *jrt.String = jrt.Intern("##Inf")

var Lit_15 *jrt.String = jrt.Intern("##-Inf")

var Lit_16 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_17 *jrt.String = jrt.Intern("java.math.BigInteger")

var Lit_18 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_19 *jrt.String = jrt.Intern("M")

var Lit_20 *jrt.String = jrt.Intern("/")

var Lit_21 *jrt.String = jrt.Intern("0x")

var Lit_22 *jrt.String = jrt.Intern("_")

var Lit_23 *jrt.String = jrt.Intern("")

var Lit_24 *jrt.String = jrt.Intern("p")

var Lit_25 *jrt.String = jrt.Intern("+")

var Lit_26 *jrt.String = jrt.Intern("0o")

var Lit_27 *jrt.String = jrt.Intern("0")

var Lit_28 *jrt.String = jrt.Intern("0b")

var Lit_29 *jrt.String = jrt.Intern("2r")

var Lit_30 *jrt.String = jrt.Intern("N")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.lit$pow5_exponent$fn__790000046")

var Lit_32 *jrt.String = jrt.Intern("0x%X")

var Lit_33 *jrt.String = jrt.Intern("`")

var Lit_34 *jrt.String = jrt.Intern("\r")

var Lit_35 *jrt.String = jrt.Intern("\"")

var Lit_36 *jrt.String = jrt.Intern("\\b")

var Lit_37 *jrt.String = jrt.Intern("\\t")

var Lit_38 *jrt.String = jrt.Intern("\\n")

var Lit_39 *jrt.String = jrt.Intern("\\f")

var Lit_40 *jrt.String = jrt.Intern("\\r")

var Lit_41 *jrt.String = jrt.Intern("\\\"")

var Lit_42 *jrt.String = jrt.Intern("\\\\")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.lit$unescape$put_cp__790000066")

var Lit_44 *jrt.String = jrt.Intern("not a numeric value: ")

var Lit_45 *jrt.String = jrt.Intern("kn4,textkn5,valueR0,R1,v11,arbace.core5,classv11,arbace.core9,imap-consv11,arbace.core3,notv11,arbace.core3,seqv11,arbace.core6,concatV2,R0,R1,v11,arbace.core10,identical?v11,arbace.core5,assocv11,arbace.core9,contains?v11,arbace.core6,dissocv11,arbace.core9,not-emptyS2,R1,R0,v11,arbace.core9,with-metav11,arbace.core4,intov11,arbace.core4,somev11,arbace.core4,valsv11,arbace.core3,setv11,arbace.core4,keys")

var Lit_46 *jrt.String = jrt.Intern("text")

var Lit_47 *jrt.String = jrt.Intern("value")

var Lit_48 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.lit.Lit")

var Lit_50 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn4,textyn5,valueyn20,m__231000174__auto__yn1,xkn7,privateyn2,cpkn3,tagyn6,Stringyn1,vyn10,BigIntegeryn1,nyn20,java.math.BigIntegeryn1,ryn20,java.math.BigDecimalyn10,BigDecimalkn4,keysyn12,prefer-ratioyn5,bytesyn1,iyn1,kv11,arbace.core5,in-nsMyn18,arbace.repr.go.litm2,R0,s460,Go literals and constant values as Clojure literals (doc/go/SPEC.md §8): integers, exact\n  floats (doubles, BigDecimals, ratios), runes, strings and byte strings, and the\n  representation of constant values (:val, §8.2) from the helper's exact values and go/types'\n  types.\n\n  A literal is a Lit: the text written into the forms and the value the reader reads back.\n  Composite spellings ((rune n), (imaginary x), (byte-string ...), (complex re im)) are lists.m2,R0,s460,Go literals and constant values as Clojure literals (doc/go/SPEC.md §8): integers, exact\n  floats (doubles, BigDecimals, ratios), runes, strings and byte strings, and the\n  representation of constant values (:val, §8.2) from the helper's exact values and go/types'\n  types.\n\n  A literal is a Lit: the text written into the forms and the value the reader reads back.\n  Composite spellings ((rune n), (imaginary x), (byte-string ...), (complex re im)) are lists.R1,C22,arbace.repr.go.lit.Litv18,arbace.repr.go.lit5,->Litm8,R2,TR3,i13,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit8,map->Litm8,R2,TR3,i13,R4,i1,R5,s21,arbace/repr/go/lit.aem10,R6,L1,V2,R7,R8,R0,s61,Positional factory function for class arbace.repr.go.lit.Lit.R3,i13,R4,i1,R5,s21,arbace/repr/go/lit.aem10,R6,L1,V1,R9,R0,s92,Factory function for class arbace.repr.go.lit.Lit, taking a map of keywords to field values.R3,i13,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit3,litm8,R6,L1,V2,R7,R8,R3,i15,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit4,lit?m8,R6,L1,V1,R10,R3,i17,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,char-namesm12,c10,s7,newlinec32,s5,spacec9,s3,tabc8,s9,backspacec12,s8,formfeedc13,s6,returnm8,R11,TR3,i21,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,printable?m10,R6,L1,V1,R12,R0,s56,Whether the code point prints as itself in Clojure text.R3,i25,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit11,string-textm10,R6,L1,V1,Myn1,sm2,R13,R14,R0,s37,The Clojure string literal text of s.R3,i39,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit9,char-textm10,R6,L1,V1,R12,R0,s75,Clojure character literal text for the BMP code point cp (not a surrogate).R3,i63,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit7,int-litm10,R6,L1,V1,Myn4,textm2,R13,R14,R0,s126,A Go integer literal's text as a Lit: the radix kept where Clojure has it (0x, 0 octal,\n  2r for binary), underscores dropped.R3,i74,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit12,integer-textm10,R6,L1,V1,R15,R0,s79,Decimal text of an integer value (long or BigInt), as the reader reads it back.R3,i90,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit11,integer-litm8,R6,L1,V1,R15,R3,i96,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit8,rationalm10,R6,L1,V2,Myn3,numm2,R13,R16,Myn3,denm2,R13,R16,R0,s65,An exact rational (Long, BigInt, Ratio) from num/den BigIntegers.R3,i102,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit4,pow2m10,R11,TR6,L1,MV1,R17,m2,R13,R18,R3,i107,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit13,pow5-exponentm12,R11,TR6,L1,V1,Myn1,dm2,R13,R16,R0,s41,k when the odd number d is 5^k, else nil.R3,i109,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit7,num-denm10,R11,TR6,L1,V1,R19,R3,i117,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit18,max-decimal-lengthl80,m10,R11,TR3,i122,R4,i1,R5,s21,arbace/repr/go/lit.aeR0,s115,Above this length a non-integral value with a terminating expansion is written as a\n  ratio, which is then shorter.v18,arbace.repr.go.lit19,terminating-decimalm12,R11,TR6,L1,MV2,Myn3,numm2,R13,R16,Myn3,denm2,R13,R16,m2,R13,R20,R0,s86,The exact BigDecimal of num/den when den has only the prime factors 2 and 5, else nil.R3,i127,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit17,double-exact-textm12,R11,TR6,L1,V1,R15,R0,s135,Double/toString of the value's nearest double when that text denotes exactly the value\n  (a BigDecimal or an exact rational), else nil.R3,i139,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit12,decimal-textm12,R11,TR6,L1,V1,Myn2,bdm2,R13,R21,R0,s89,The text of BigDecimal bd as a float literal: stripped, with a decimal point or exponent.R3,i152,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit9,float-litm10,R6,L2,V1,R15,V2,R15,m2,R22,V1,R23,R0,s362,An exact value v (a BigDecimal, or a rational: Long, BigInt, Ratio) as a float-kind\n  Clojure literal (§8.1): a double when its shortest text denotes v exactly, else a\n  BigDecimal (M) when v has a terminating decimal expansion of reasonable length (always when\n  v is an integer), else a ratio. opts :prefer-ratio (hex floats): a ratio unless v is an\n  integer.R3,i158,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,double-litm10,R6,L1,V1,R19,R0,s79,A typed float value (float32/float64, already rounded): always a double (§8.2).R3,i177,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit15,hex-float-valuem12,R11,TR6,L1,V1,Myn1,tm2,R13,R14,R0,s82,The exact value of a Go hexadecimal float literal (underscores removed): 0xH.Hp±E.R3,i186,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit11,float-valuem10,R6,L1,V1,Myn4,textm2,R13,R14,R0,s100,The exact value of a Go float literal's text: a BigDecimal, or a rational for a\n  hexadecimal float.R3,i203,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit14,float-text-litm10,R6,L1,V1,Myn4,textm2,R13,R14,R0,s113,A Go float literal's text as a Lit (§8.1): hexadecimal floats exact as a ratio (or a\n  BigDecimal when integral).R3,i212,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,imag-innerm10,R6,L1,V1,Myn4,textm2,R13,R14,R0,s169,The literal inside (imaginary x) for a Go imaginary literal's text: an integer for an\n  integer literal (decimal digits are decimal even with a leading 0), else a float.R3,i219,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit4,hexvm10,R11,TR6,L1,V1,Myn1,sm2,R13,R14,R3,i235,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit8,unescapem12,R11,TR6,L1,V1,Myn4,bodym2,R13,R14,R0,s80,Decodes the Go escapes of a literal's body into bytes (a ByteArrayOutputStream).R3,i237,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit12,string-bytesm10,R6,L1,MV1,Myn4,textm2,R13,R14,m2,R13,R24,R0,s68,The bytes of a Go string literal's source text (interpreted or raw).R3,i271,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,rune-valuem10,R6,L1,V1,Myn4,textm2,R13,R14,R0,s50,The code point of a Go rune literal's source text.R3,i278,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit11,decode-runem12,R11,TR6,L1,V3,Myn2,bsm2,R13,R24,R25,R17,R0,s78,Go's utf8.DecodeRune on bs at i: [rune width], rune -1 when invalid (width 1).R3,i292,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,utf8-partsm10,R6,L1,V1,Myn2,bsm2,R13,R24,R0,s89,Splits bytes into maximal valid UTF-8 runs (strings) and single invalid bytes (integers).R3,i321,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit9,rune-formm10,R6,L1,V1,R12,R0,s126,A rune value (code point) as a character Lit, or (rune n) above the Basic Multilingual\n  Plane, in the surrogates or negative.R3,i336,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,bytes-formm10,R6,L1,V1,Myn2,bsm2,R13,R24,R0,s80,Go string bytes as a string Lit, or (byte-string part ...) when not valid UTF-8.R3,i345,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit12,val-rationalm12,R11,TR6,L1,V1,R15,R0,s77,The exact rational of a helper value: an integer, (:float R) or (:float M E).R3,i357,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit18,untyped-float-formm10,R6,L1,V1,R15,R0,s253,An untyped float value of the helper: a float literal (§8.1), or (binary-float M E) for\n  M·2^E when go/types holds it as a big.Float beyond a rational's range (its decimal or ratio\n  would have up to hundreds of millions of digits: proposed amendment).R3,i370,R4,i1,R5,s21,arbace/repr/go/lit.aev18,arbace.repr.go.lit10,const-formm10,R6,L1,V2,R15,R26,R0,s267,The representation (§8.2) of the helper's exact value v at the constant kind k: :bool,\n  :string, :int, :rune, :float, :untyped-float, :complex, :untyped-complex (typed :float and\n  :complex are rounded doubles), or nil when the kind is not known (then v's own kind).R3,i379,R4,i1,R5,s21,arbace/repr/go/lit.ae")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go.lit$eval790000004$loading__1927001464__auto____790000005")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.lit$eval790000008$fn__790000009")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.lit$eval790000013$__GT_Lit__790000023")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.lit$eval790000013$map__GT_Lit__790000025")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.lit$lit")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.lit$lit_QMARK_")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.lit$printable_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.lit$string_text")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.lit$char_text")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.lit$int_lit")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.lit$integer_text")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.lit$integer_lit")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.lit$rational")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.lit$pow2")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.lit$pow5_exponent")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.lit$num_den")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.lit$terminating_decimal")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.lit$double_exact_text")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.lit$decimal_text")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.lit$float_lit")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.lit$double_lit")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.lit$hex_float_value")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.lit$float_value")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.lit$float_text_lit")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.lit$imag_inner")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.lit$hexv")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.lit$unescape")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.lit$string_bytes")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.lit$rune_value")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.lit$decode_rune")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.go.lit$utf8_parts")

var Lit_82 *jrt.String = jrt.Intern("arbace.repr.go.lit$rune_form")

var Lit_83 *jrt.String = jrt.Intern("arbace.repr.go.lit$bytes_form")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.go.lit$val_rational")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.lit$untyped_float_form")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.lit$const_form")
