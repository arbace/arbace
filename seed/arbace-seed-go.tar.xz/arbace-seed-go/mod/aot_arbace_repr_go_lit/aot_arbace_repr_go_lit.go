//line aot_arbace_repr_go_lit.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_New() *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_1); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_lit_eval790000008_fn__790000009_A_New() *A_arbace_repr_go_lit_eval790000008_fn__790000009_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000008_fn__790000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_repr_go_lit_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_repr_go_lit_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(), A_arbace_repr_go_lit_A_const_8) }











func A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_New() *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Invoke_O_O_O__O(self, text__1, value__2 any) any { return A_arbace_repr_go_lit_Lit_A_New_O_O(text__1, value__2) }
//line :13:1
func A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_New() *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var root_19 any = A_arbace_repr_go_lit_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_23 any = m__231000174__auto____1; if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }; return A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(lang.IPersistentMap_Cast(tmp1)).Ref() }

func A_arbace_repr_go_lit_lit_A_New() *A_arbace_repr_go_lit_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Ctor() {}
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Invoke_O_O_O__O(self, text__0, value__1 any) any { var root_24 any = A_arbace_repr_go_lit_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = text__0; var arg_28 any = value__1; if linked_25 == nil { return ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { return linked_25.(*A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A).Invoke_O_O_O__O(root_24, arg_27, arg_28) } }

func A_arbace_repr_go_lit_lit_QMARK__A_New() *A_arbace_repr_go_lit_lit_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(A_arbace_repr_go_lit_Lit_A_InstanceOf(x__0)).Ref() }







func A_arbace_repr_go_lit_printable_QMARK__A_New() *A_arbace_repr_go_lit_printable_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_printable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var t__3 int32 = jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); var root_46 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_48 lang.IFn; if




	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var or__1927000174__auto____4 bool = jrt.Character_IsISOControl_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____4 { arg_49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.Character_IsWhitespace_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____5 { arg_49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.Character_IsSpaceChar_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____6 { arg_49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_13; var or__1927000174__auto____7 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_14); if jrt.J2g_Truth(or__1927000174__auto____7) { arg_49 = or__1927000174__auto____7 } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_lit_A_const_15; var or__1927000174__auto____8 any = tmp3.Invoke_O_O_O__O(tmp4, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_16); if jrt.J2g_Truth(or__1927000174__auto____8) { arg_49 = or__1927000174__auto____8 } else {



		var root_41 any = A_arbace_repr_go_lit_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(0)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(19)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(13)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(14)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(18)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(16)).Ref())); var arg_45 any = jrt.Integer_ValueOf_I__Integer_NoInit(t__3).Ref(); if linked_42 == nil { arg_49 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { arg_49 = linked_42.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) } } } } } }; if /*line :30:1*/ linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_46, arg_49) } }








func A_arbace_repr_go_lit_string_text_A_New() *A_arbace_repr_go_lit_string_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_text_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_go_lit_string_text_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_go_lit_string_text_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_35); var n__3 int32 = jrt.NN(jrt.String_Cast(s__0)).Length__I(); var i__4 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__3)) { var cp__5 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__4)); var w__6 int32 = jrt.Character_CharCount_I__I_NoInit(cp__5); var G__790000031__7_ int32 = lang.RT_IntCast_I__I_NoInit(cp__5)


	L2: switch { default: switch G__790000031__7_ { case 8:





		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_36)
//line :48:1
		break L2; case 9:



		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_37)
//line :48:1
		break L2; case 10:


		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_38)
//line :48:1
		break L2; case 12:






		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_39)
//line :48:1
		break L2; case 13:




		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_40)
//line :48:1
		break L2; case 34:
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_41)
//line :48:1
		break L2; case 92:

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_42)
//line :48:1
		break L2; default:
	}






		var tmp1 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(cp__5), 32)
		if or__1927000174__auto____8 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_55 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_repr_go_lit_printable_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref(); if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*A_arbace_repr_go_lit_printable_QMARK__A).Invoke_O_O__O(root_55, arg_58) } }
//line :56:1
		if jrt.J2g_Truth(tmp1) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).AppendCodePoint_I__StringBuilder(cp__5) } else {
//line :56:1
				if lang.Numbers_Lt_J_J__Z_NoInit(int64(cp__5), 65536) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref()))) } else {
//line :56:1
						if A_arbace_repr_go_lit_A_const_21 != nil { var seq_790000032__8 any; var root_64 any = A_arbace_repr_go_lit_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_66 lang.IFn


							if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = jrt.Character_ToChars_I__C1_NoInit(cp__5).Ref(); if linked_65 == nil { seq_790000032__8 = ifn_66.Invoke_O__O(arg_67) } else { seq_790000032__8 = linked_65.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_64, arg_67) }
//line :56:1
							var chunk_790000033__9 any; var count_790000034__10 int64 = 0; var i_790000035__11 int64 = 0; L3: for {


								if lang.Numbers_Lt_J_J__Z_NoInit(i_790000035__11, count_790000034__10) { var c__12 any = lang.Indexed_Cast(chunk_790000033__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_790000035__11)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__12)).Ref()))); seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = seq_790000032__8, chunk_790000033__9, count_790000034__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_790000035__11); continue L3 } else { var temp__1927000414__auto____12 any; var root_68 any = A_arbace_repr_go_lit_A_const_22.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = seq_790000032__8; if linked_69 == nil { temp__1927000414__auto____12 = ifn_70.Invoke_O__O(arg_71) } else { temp__1927000414__auto____12 = linked_69.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_790000032__13 any = temp__1927000414__auto____12; var tmp2 any; var root_72 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = seq_790000032__13; if linked_73 == nil { tmp2 = ifn_74.Invoke_O__O(arg_75) } else { tmp2 = linked_73.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_72, arg_75) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____14 any; var root_76 any = A_arbace_repr_go_lit_A_const_24.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = seq_790000032__13; if linked_77 == nil { c__1927000678__auto____14 = ifn_78.Invoke_O__O(arg_79) } else { c__1927000678__auto____14 = linked_77.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_76, arg_79) }; var tmp3 any; var root_89 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = seq_790000032__13; if linked_90 == nil { tmp3 = ifn_91.Invoke_O__O(arg_92) } else { tmp3 = linked_90.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_89, arg_92) }; seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = tmp3, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var c__14 any; var root_80 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = seq_790000032__13; if linked_81 == nil { c__14 = ifn_82.Invoke_O__O(arg_83) } else { c__14 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__14)).Ref()))); var tmp4 any; var root_98 any = A_arbace_repr_go_lit_A_const_27.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = seq_790000032__13; if linked_99 == nil { tmp4 = ifn_100.Invoke_O__O(arg_101) } else { tmp4 = linked_99.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_98, arg_101) }; seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = tmp4, nil, 0, 0; continue L3 } } }
//line :56:1
								break L3
							}
						}
					} }}
		i__4 = lang.Numbers_Add_J_J__J_NoInit(i__4, int64(w__6)); continue L1 }
//line :39:1
	break L1 }; var root_50 any =





















	A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_35).Ref(); if linked_51 == nil { return ifn_52.Invoke_O__O(arg_53) } else { return linked_51.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_50, arg_53) } }

func A_arbace_repr_go_lit_char_text_A_New() *A_arbace_repr_go_lit_char_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_char_text_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_repr_go_lit_char_text_A) Ctor() {}
//line :63:1
func (t *A_arbace_repr_go_lit_char_text_A) Invoke_O_O__O(self, cp__0 any) any { var ch__2 uint16 = lang.RT_CharCast_O__C_NoInit(cp__0); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_28.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_28.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref()))).Ref() } else {
//line :67:1
			var tmp1 any; var root_102 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_repr_go_lit_printable_QMARK__A_fn_class); var ifn_104 lang.IFn

			if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = cp__0; if linked_103 == nil { tmp1 = ifn_104.Invoke_O__O(arg_105) } else { tmp1 = linked_103.(*A_arbace_repr_go_lit_printable_QMARK__A).Invoke_O_O__O(root_102, arg_105) }
//line :67:1
			if jrt.J2g_Truth(tmp1) {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())).Ref() } else {
//line :67:1
					if A_arbace_repr_go_lit_A_const_21 != nil {


						return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(cp__0)).Ref()) } else {
//line :67:1
							return nil } } } }






func A_arbace_repr_go_lit_int_lit_A_New() *A_arbace_repr_go_lit_int_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_int_lit_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_repr_go_lit_int_lit_A) Ctor() {}
//line :74:1
func (t *A_arbace_repr_go_lit_int_lit_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_111 any = A_arbace_repr_go_lit_A_const_29.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_113 lang.IFn; if



	linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = text__0; var arg_115 any = Lit_22; var arg_116 any = Lit_23; if linked_112 == nil { t__2 = ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { t__2 = linked_112.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) }; var lower__3 any; var root_117 any = /*line :74:1*/A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_119 lang.IFn; if




	linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = t__2; if linked_118 == nil { lower__3 = ifn_119.Invoke_O__O(arg_120) } else { lower__3 = linked_118.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_117, arg_120) }; var vec__790000038__4 any; var tmp1 any; var root_121 any = /*line :74:1*/A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_123 lang.IFn; if







	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = lower__3; var arg_125 any = Lit_21; if linked_122 == nil { tmp1 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp1 = linked_122.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; if /*line :81:1*/ jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_repr_go_lit_A_const_35; var tmp3 any; var root_154 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_156 lang.IFn
		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = t__2; var arg_158 any = A_arbace_repr_go_lit_A_const_37; if linked_155 == nil { tmp3 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { tmp3 = linked_155.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
//line :81:1
		vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp2, tmp3) } else { var tmp4 any; var root_126 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_128 lang.IFn

			if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = lower__3; var arg_130 any = Lit_26; if linked_127 == nil { tmp4 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { tmp4 = linked_127.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_126, arg_129, arg_130) }
//line :81:1
			if jrt.J2g_Truth(tmp4) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp6 any; var root_159 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_161 lang.IFn

				if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = t__2; var arg_163 any = A_arbace_repr_go_lit_A_const_37; if linked_160 == nil { tmp6 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { tmp6 = linked_160.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }
//line :81:1
				var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); var tmp8 any = A_arbace_repr_go_lit_A_const_38; var tmp9 any; var root_164 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_166 lang.IFn

				if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = t__2; var arg_168 any = A_arbace_repr_go_lit_A_const_37; if linked_165 == nil { tmp9 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { tmp9 = linked_165.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }
//line :81:1
				vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, tmp8, tmp9) } else { var tmp10 any; var root_131 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_133 lang.IFn


					if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = lower__3; var arg_135 any = Lit_28; if linked_132 == nil { tmp10 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp10 = linked_132.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }
//line :81:1
					if jrt.J2g_Truth(tmp10) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil); var tmp12 any; var root_169 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_171 lang.IFn


						if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = t__2; var arg_173 any = A_arbace_repr_go_lit_A_const_37; if linked_170 == nil { tmp12 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { tmp12 = linked_170.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }
//line :81:1
						var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); var tmp14 any = A_arbace_repr_go_lit_A_const_37; var tmp15 any; var root_174 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_176 lang.IFn


						if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__2; var arg_178 any = A_arbace_repr_go_lit_A_const_37; if linked_175 == nil { tmp15 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { tmp15 = linked_175.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }
//line :81:1
						vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp13, tmp14, tmp15) } else { var tmp16 any; var and__1927000168__auto____4 any; var root_136 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_138 lang.IFn



							if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t__2; var arg_140 any = Lit_27; if linked_137 == nil { and__1927000168__auto____4 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { and__1927000168__auto____4 = linked_137.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t__2)), 1)).Ref() } else { tmp16 = and__1927000168__auto____4 }
//line :81:1
							if jrt.J2g_Truth(tmp16) { var tmp17 any = A_arbace_repr_go_lit_A_const_38; var tmp18 any; var root_179 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_181 lang.IFn



								if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__2; var arg_183 any = A_arbace_repr_go_lit_A_const_39; if linked_180 == nil { tmp18 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { tmp18 = linked_180.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }
//line :81:1
								vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp17, tmp18) } else { if A_arbace_repr_go_lit_A_const_21 != nil { vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, A_arbace_repr_go_lit_A_const_40, t__2) } else { vec__790000038__4 = nil } } } } }; var ctext__5 any = /*line :74:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(0), nil); var radix__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(1), nil); var digits__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(2), nil); var v__8 any; var root_141 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_143 lang.IFn; if












	linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__7), lang.RT_IntCast_O__I_NoInit(radix__6)); if linked_142 == nil { v__8 = ifn_143.Invoke_O__O(arg_144) } else { v__8 = linked_142.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_141, arg_144) }; var root_149 any =
	A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = ctext__5; var arg_153 any; var tmp19 any; var root_145 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = v__8; if linked_146 == nil { tmp19 = ifn_147.Invoke_O__O(arg_148) } else { tmp19 = linked_146.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_145, arg_148) }; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(tmp19)).BitLength__I()), 64) { arg_153 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__8)).Ref() } else { arg_153 = v__8 }; if linked_150 == nil { return ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { return linked_150.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_149, arg_152, arg_153) } }

func A_arbace_repr_go_lit_integer_text_A_New() *A_arbace_repr_go_lit_integer_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_text_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_repr_go_lit_integer_text_A) Ctor() {}
//line :90:1
func (t *A_arbace_repr_go_lit_integer_text_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var root_184 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_186 lang.IFn; if


	linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { b__2 = ifn_186.Invoke_O__O(arg_187) } else { b__2 = linked_185.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_184, arg_187) }; if
	lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { var root_188 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref(); if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_188, arg_191) } } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, b__2, nil)).Ref() } }

func A_arbace_repr_go_lit_integer_lit_A_New() *A_arbace_repr_go_lit_integer_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_lit_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var root_192 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_194 lang.IFn; if
										linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { b__2 = ifn_194.Invoke_O__O(arg_195) } else { b__2 = linked_193.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_192, arg_195) }; var root_204 any =
										A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_196 any = A_arbace_repr_go_lit_A_const_41.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_repr_go_lit_integer_text_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = v__0; if linked_197 == nil { arg_207 = ifn_198.Invoke_O__O(arg_199) } else { arg_207 = linked_197.(*A_arbace_repr_go_lit_integer_text_A).Invoke_O_O__O(root_196, arg_199) }; var arg_208 any; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { arg_208 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref() } else { var root_200 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = b__2; if linked_201 == nil { arg_208 = ifn_202.Invoke_O__O(arg_203) } else { arg_208 = linked_201.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_200, arg_203) } }; if linked_205 == nil { return ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { return linked_205.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } }



func A_arbace_repr_go_lit_rational_A_New() *A_arbace_repr_go_lit_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rational_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_repr_go_lit_rational_A) Ctor() {}
//line :102:1
func (t *A_arbace_repr_go_lit_rational_A) Invoke_O_O_O__O(self, num__0, den__1 any) any {


	var tmp1 any; var root_209 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = num__0; if linked_210 == nil { tmp1 = ifn_211.Invoke_O__O(arg_212) } else { tmp1 = linked_210.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_209, arg_212) }; var tmp2 any = tmp1; var tmp3 any; var root_213 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = den__1; if linked_214 == nil { tmp3 = ifn_215.Invoke_O__O(arg_216) } else { tmp3 = linked_214.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_213, arg_216) }; return lang.Numbers_Divide_O_O__Number_NoInit(tmp2, tmp3)
}
func A_arbace_repr_go_lit_pow2_A_New() *A_arbace_repr_go_lit_pow2_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow2_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_lit_pow2_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_lit_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.BigInteger; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 *jrt.BigInteger = tmp1; return jrt.NN(tmp2).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref() }

func A_arbace_repr_go_lit_pow5_exponent_A_New() *A_arbace_repr_go_lit_pow5_exponent_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Invoke_O_O__O(self, d__0 any) any { var guess__2 int64 = lang.RT_LongCast_D__J_NoInit(jrt.Math_Floor_D__D(lang.Numbers_Divide_D_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(d__0)).BitLength__I()), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_37))), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_42))))); var five__3 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var root_223 any = A_arbace_repr_go_lit_A_const_43.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_225 lang.IFn; if




	linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; var tmp1 any = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(d__0, five__3); var tmp2 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class = fncls__222d; tmp2 = fncls__222d } else { tmp2 = fncls__222 }; arg_226 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_227 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(guess__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(guess__2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(guess__2)).Ref()); if linked_224 == nil { return ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { return linked_224.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) } }
//line :114:1
func A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Ctor_O_O(c__d, c__five any) { t.F_d = c__d; t.F_five = c__five }
//line :114:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var na_217 any = k__1; var na_218 int64 = 0; if jrt.Long_InstanceOf(na_217) { var n0_219 int64 = jrt.NN(jrt.Long_Cast(na_217)).LongValue__J(); var n1_220 int64 = na_218; and__1927000168__auto____2 = n0_219 >= n1_220 } else { and__1927000168__auto____2 = lang.Numbers_Gte_O_J__Z_NoInit(na_217, na_218) }; if and__1927000168__auto____2 { var tmp2 any = t.F_d; var tmp3 *jrt.BigInteger = jrt.BigInteger_Cast(t.F_five); tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, jrt.NN(tmp3).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__1)).Ref()) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return k__1 } else { return nil } }


func A_arbace_repr_go_lit_num_den_A_New() *A_arbace_repr_go_lit_num_den_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_num_den_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_repr_go_lit_num_den_A) Ctor() {}
//line :117:1
func (t *A_arbace_repr_go_lit_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 any; var root_228 any = A_arbace_repr_go_lit_A_const_44.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_230 lang.IFn
	if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = r__0; if linked_229 == nil { tmp1 = ifn_230.Invoke_O__O(arg_231) } else { tmp1 = linked_229.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_228, arg_231) }
//line :118:1
	if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_232 any = A_arbace_repr_go_lit_A_const_45.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_234 lang.IFn
		if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = r__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_232, arg_235) }
//line :118:1
		var tmp3 any = tmp2; var tmp4 any; var root_236 any = A_arbace_repr_go_lit_A_const_46.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_238 lang.IFn
		if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = r__0; if linked_237 == nil { tmp4 = ifn_238.Invoke_O__O(arg_239) } else { tmp4 = linked_237.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_236, arg_239) }
//line :118:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if A_arbace_repr_go_lit_A_const_21 != nil { var tmp5 any; var root_240 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_242 lang.IFn

			if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = r__0; if linked_241 == nil { tmp5 = ifn_242.Invoke_O__O(arg_243) } else { tmp5 = linked_241.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_240, arg_243) }
//line :118:1
			var tmp6 any = tmp5; var tmp7 *jrt.BigInteger; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Ref()) } else { return nil
			}
		}
}





func A_arbace_repr_go_lit_terminating_decimal_A_New() *A_arbace_repr_go_lit_terminating_decimal_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_terminating_decimal_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Invoke_O_O_O__O(self, num__0, den__1 any) any { var twos__3 int32 = jrt.NN(jrt.BigInteger_Cast(den__1)).GetLowestSetBit__I(); var temp__1927000414__auto____4 any; var root_244 any = A_arbace_repr_go_lit_A_const_47.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_repr_go_lit_pow5_exponent_A_fn_class); var ifn_246 lang.IFn; if



	linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = jrt.NN(jrt.BigInteger_Cast(den__1)).ShiftRight_I__BigInteger(twos__3).Ref(); if linked_245 == nil { temp__1927000414__auto____4 = ifn_246.Invoke_O__O(arg_247) } else { temp__1927000414__auto____4 = linked_245.(*A_arbace_repr_go_lit_pow5_exponent_A).Invoke_O_O__O(root_244, arg_247) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var fives__5 any = temp__1927000414__auto____4; var scale__6 any = lang.Numbers_Max_J_O__O_NoInit(int64(twos__3), fives__5); var unscaled__7 any; var tmp1 *jrt.BigInteger = jrt.BigInteger_Cast(num__0); var tmp2 jrt.Number_I; var na_248 any = scale__6; var na_249 int64 = int64(twos__3)



		if jrt.Long_InstanceOf(na_248) { var n0_250 int64 = jrt.NN(jrt.Long_Cast(na_248)).LongValue__J(); var n1_251 int64 = na_249; var nr_252 int64 = n0_250 - n1_251; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_251 == -9223372036854775808); if tmp4 { tmp4 = (n0_250^n1_251)&(n0_250^nr_252) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_252)) } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_248, na_249) } } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_248, na_249) }
		var tmp5 *jrt.BigInteger = jrt.NN(tmp1).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp2)); var tmp6 *jrt.BigInteger = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp7 jrt.Number_I; var na_253 any = scale__6; var na_254 any = fives__5; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_253); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_254) }; tmp8 = tmp9; if tmp8 { var n0_255 int64 = jrt.NN(jrt.Long_Cast(na_253)).LongValue__J(); var n1_256 int64 = jrt.NN(jrt.Long_Cast(na_254)).LongValue__J(); var nr_257 int64 = n0_255 - n1_256; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_256 == -9223372036854775808); if tmp11 { tmp11 = (n0_255^n1_256)&(n0_255^nr_257) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_257)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_253, na_254) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_253); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_254) }; tmp12 = tmp13; if tmp12 { var n0_255_2 float64 = jrt.NN(jrt.Double_Cast(na_253)).DoubleValue__D(); var n1_256_2 float64 = jrt.NN(jrt.Double_Cast(na_254)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_255_2 + -n1_256_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_253, na_254) } }; unscaled__7 = jrt.NN(tmp5).Multiply_BigInteger__BigInteger(jrt.NN(tmp6).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp7))).Ref()
//line :131:1
		return jrt.BigDecimal_New_BigInteger_I(jrt.BigInteger_Cast(unscaled__7), lang.RT_IntCast_O__I_NoInit(scale__6)) } else { return nil } }







func A_arbace_repr_go_lit_double_exact_text_A_New() *A_arbace_repr_go_lit_double_exact_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_exact_text_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Invoke_O_O__O(self, v__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(v__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsInfinite_D__Z_NoInit(d__2); if or__1927000174__auto____3 {




	tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsNaN_D__Z_NoInit(d__2) }; if tmp1 { return nil } else { var s__3 any = jrt.Double_ToString_D__String_NoInit(d__2).Ref(); var bd__4 any = jrt.BigDecimal_New_String(jrt.String_Cast(s__3)); var tmp2 bool


		if jrt.BigDecimal_InstanceOf(v__0) {
			tmp2 = lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(bd__4)).CompareTo_BigDecimal__I(jrt.BigDecimal_Cast(v__0)))) } else {
				var tmp3 any; var root_258 any = A_arbace_repr_go_lit_A_const_48.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_rationalize_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = bd__4; if linked_259 == nil { tmp3 = ifn_260.Invoke_O__O(arg_261) } else { tmp3 = linked_259.(*aot_arbace_core.A_arbace_core_rationalize_A).Invoke_O_O__O(root_258, arg_261) }; tmp2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, v__0) }
//line :147:1
		if tmp2 { return s__3 } else { return nil } } }




func A_arbace_repr_go_lit_decimal_text_A_New() *A_arbace_repr_go_lit_decimal_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decimal_text_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Ctor() {}
//line :152:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Invoke_O_O__O(self, bd__0 any) any { var s__2 any; var root_262 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_264 lang.IFn; if


	linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = jrt.NN(jrt.BigDecimal_Cast(bd__0)).StripTrailingZeros__BigDecimal().Ref(); if linked_263 == nil { s__2 = ifn_264.Invoke_O__O(arg_265) } else { s__2 = linked_263.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_262, arg_265) }; var tmp1 any; var or__1927000174__auto____3 any; var root_266 any =
	A_arbace_repr_go_lit_A_const_49.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = s__2; var arg_270 any = Lit_8; if linked_267 == nil { or__1927000174__auto____3 = ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { or__1927000174__auto____3 = linked_267.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_266, arg_269, arg_270) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_271 any = A_arbace_repr_go_lit_A_const_49.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = s__2; var arg_275 any = Lit_9; if linked_272 == nil { tmp1 = ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { tmp1 = linked_272.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_271, arg_274, arg_275) } }; if jrt.J2g_Truth(tmp1) { return s__2 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() } }

func A_arbace_repr_go_lit_float_lit_A_New() *A_arbace_repr_go_lit_float_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_lit_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Ctor() {}
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O_O__O(self, v__0, p__790000053__1 any) any { var map__790000054__3 any = p__790000053__1; var map__790000054__4 any; if lang.ISeq_InstanceOf(map__790000054__3) { var tmp1 any; var root_276 any = A_arbace_repr_go_lit_A_const_27.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = map__790000054__3; if linked_277 == nil { tmp1 = ifn_278.Invoke_O__O(arg_279) } else { tmp1 = linked_277.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_276, arg_279) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_280 any = A_arbace_repr_go_lit_A_const_50.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = map__790000054__3; if linked_281 == nil { tmp2 = ifn_282.Invoke_O__O(arg_283) } else { tmp2 = linked_281.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_280, arg_283) }; map__790000054__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_284 any = A_arbace_repr_go_lit_A_const_22.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = map__790000054__3; if linked_285 == nil { tmp3 = ifn_286.Invoke_O__O(arg_287) } else { tmp3 = linked_285.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(tmp3) { var root_288 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = map__790000054__3; if linked_289 == nil { map__790000054__4 = ifn_290.Invoke_O__O(arg_291) } else { map__790000054__4 = linked_289.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_288, arg_291) } } else { map__790000054__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__790000054__4 = map__790000054__3 }; var prefer_ratio__5 any = lang.RT_Get_O_O__O_NoInit(map__790000054__4, A_arbace_repr_go_lit_A_const_51); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 any; var root_292 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_294 lang.IFn; if







	linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = prefer_ratio__5; if linked_293 == nil { and__1927000168__auto____6 = ifn_294.Invoke_O__O(arg_295) } else { and__1927000168__auto____6 = linked_293.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_296 any = A_arbace_repr_go_lit_A_const_52.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_repr_go_lit_double_exact_text_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = v__0; if linked_297 == nil { temp__1927000408__auto____6 = ifn_298.Invoke_O__O(arg_299) } else { temp__1927000408__auto____6 = linked_297.(*A_arbace_repr_go_lit_double_exact_text_A).Invoke_O_O__O(root_296, arg_299) } } else { temp__1927000408__auto____6 = and__1927000168__auto____6 }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var s__7 any = temp__1927000408__auto____6; var root_300 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_302 lang.IFn
		if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = s__7; var arg_304 any = jrt.Double_ValueOf_D__Double_NoInit(jrt.Double_ParseDouble_String__D_NoInit(jrt.String_Cast(s__7))).Ref(); if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else {
			if jrt.BigDecimal_InstanceOf(v__0) { var s__7_2 any; var root_305 any = A_arbace_repr_go_lit_A_const_53.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, A_arbace_repr_go_lit_decimal_text_A_fn_class); var ifn_307 lang.IFn
				if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = v__0; if linked_306 == nil { s__7_2 = ifn_307.Invoke_O__O(arg_308) } else { s__7_2 = linked_306.(*A_arbace_repr_go_lit_decimal_text_A).Invoke_O_O__O(root_305, arg_308) }; var root_309 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__7_2, nil)).Ref(); var tmp4 *jrt.Class = A_arbace_repr_go_lit_A_const_54; var arg_313 any = lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, s__7_2)); if linked_310 == nil { return ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { return linked_310.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else {
//line :168:1
					var vec__790000056__7 any; var root_314 any = A_arbace_repr_go_lit_A_const_55.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, A_arbace_repr_go_lit_num_den_A_fn_class); var ifn_316 lang.IFn

					if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = v__0; if linked_315 == nil { vec__790000056__7 = ifn_316.Invoke_O__O(arg_317) } else { vec__790000056__7 = linked_315.(*A_arbace_repr_go_lit_num_den_A).Invoke_O_O__O(root_314, arg_317) }
//line :168:1
					var num__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(0), nil); var den__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(1), nil); var integral__10 bool; var tmp5 *jrt.BigInteger


					jrt.BigInteger_Init(); tmp5 = jrt.BigInteger_ONE; integral__10 = lang.Util_Equiv_O_O__Z_NoInit(den__9, tmp5.Ref())
//line :168:1
					var bd__11 any; var tmp6 any
					var and__1927000168__auto____11 any = prefer_ratio__5


					if jrt.J2g_Truth(and__1927000168__auto____11) { var root_318 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(integral__10).Ref(); if linked_319 == nil { tmp6 = ifn_320.Invoke_O__O(arg_321) } else { tmp6 = linked_319.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_318, arg_321) } } else { tmp6 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp6) { bd__11 = nil } else { var root_322 any = A_arbace_repr_go_lit_A_const_56.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_repr_go_lit_terminating_decimal_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = num__8; var arg_326 any = den__9; if linked_323 == nil { bd__11 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { bd__11 = linked_323.(*A_arbace_repr_go_lit_terminating_decimal_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) } }
					var tmp7 any; var and__1927000168__auto____12 any = bd__11; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = integral__10; if or__1927000174__auto____13 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { var tmp8 bool; var na_327 int64; var tmp9 any; var root_329 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = bd__11; if linked_330 == nil { tmp9 = ifn_331.Invoke_O__O(arg_332) } else { tmp9 = linked_330.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_329, arg_332) }; na_327 = int64(lang.RT_Count_O__I_NoInit(tmp9)); var na_328 any = A_arbace_repr_go_lit_A_const_57.GetRawRoot__O(); if jrt.Long_InstanceOf(na_328) { var n0_333 int64 = na_327; var n1_334 int64 = jrt.NN(jrt.Long_Cast(na_328)).LongValue__J(); tmp8 = n0_333 <= n1_334 } else { tmp8 = lang.Numbers_Lte_J_O__Z_NoInit(na_327, na_328) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp8).Ref() } } else { tmp7 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp7) { var s__12 any; var root_336 any = A_arbace_repr_go_lit_A_const_53.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, A_arbace_repr_go_lit_decimal_text_A_fn_class); var ifn_338 lang.IFn
						if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = bd__11; if linked_337 == nil { s__12 = ifn_338.Invoke_O__O(arg_339) } else { s__12 = linked_337.(*A_arbace_repr_go_lit_decimal_text_A).Invoke_O_O__O(root_336, arg_339) }; var root_340 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__12, nil)).Ref(); var tmp10 *jrt.Class = A_arbace_repr_go_lit_A_const_54; var arg_344 any = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, s__12)); if linked_341 == nil { return ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { return linked_341.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) } } else {
							var root_345 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, num__8, nil, den__9)).Ref(); var arg_349 any = v__0; if linked_346 == nil { return ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { return linked_346.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) } } } } }
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O__O(self, v__0 any) any {





	var root_350 any = A_arbace_repr_go_lit_A_const_58.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = v__0; var arg_354 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_351 == nil { return ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { return linked_351.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O_O__O(root_350, arg_353, arg_354)
	}
}










func A_arbace_repr_go_lit_exact_double_A_New() *A_arbace_repr_go_lit_exact_double_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_exact_double_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_repr_go_lit_exact_double_A) Ctor() {}
//line :177:1
func (t *A_arbace_repr_go_lit_exact_double_A) Invoke_O_O__O(self, r__0 any) any {



	var tmp1 any; var root_355 any = A_arbace_repr_go_lit_A_const_44.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = r__0; if linked_356 == nil { tmp1 = ifn_357.Invoke_O__O(arg_358) } else { tmp1 = linked_356.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_355, arg_358) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 any; var root_359 any = A_arbace_repr_go_lit_A_const_45.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = r__0; if linked_360 == nil { tmp3 = ifn_361.Invoke_O__O(arg_362) } else { tmp3 = linked_360.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_359, arg_362) }; var tmp4 *jrt.BigDecimal = jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(tmp3)); var tmp5 any; var root_363 any = A_arbace_repr_go_lit_A_const_46.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = r__0; if linked_364 == nil { tmp5 = ifn_365.Invoke_O__O(arg_366) } else { tmp5 = linked_364.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_363, arg_366) }; tmp2 = jrt.Double_ValueOf_D__Double_NoInit(jrt.NN(tmp4.Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(tmp5)))).DoubleValue__D()).Ref() }
//line :181:1
		return nil }(); if tmp6 != nil { if jrt.ArithmeticException_InstanceOf(tmp6) { var ___4 *jrt.ArithmeticException = jrt.ArithmeticException_Cast(tmp6); _ = ___4


			tmp2 = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__0)).Ref() } else {
//line :181:1
				panic(tmp6) } }; return tmp2 } else {



					return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__0)).Ref()
				} }
func A_arbace_repr_go_lit_double_lit_A_New() *A_arbace_repr_go_lit_double_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_lit_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_repr_go_lit_double_lit_A) Ctor() {}
//line :187:1
func (t *A_arbace_repr_go_lit_double_lit_A) Invoke_O_O__O(self, r__0 any) any { var d__2 any; var root_367 any = A_arbace_repr_go_lit_A_const_59.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_repr_go_lit_exact_double_A_fn_class); var ifn_369 lang.IFn; if


	linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = r__0; if linked_368 == nil { d__2 = ifn_369.Invoke_O__O(arg_370) } else { d__2 = linked_368.(*A_arbace_repr_go_lit_exact_double_A).Invoke_O_O__O(root_367, arg_370) }; var root_373 any =
	A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; if jrt.Double_IsNaN_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)) { arg_376 = Lit_13 } else { if jrt.Double_IsInfinite_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)) {
		var tmp1 bool; var na_371 any = d__2; if jrt.Long_InstanceOf(na_371) { var n0_372 int64 = jrt.NN(jrt.Long_Cast(na_371)).LongValue__J(); tmp1 = n0_372 > 0 } else { if jrt.Double_InstanceOf(na_371) { var n0_372_2 float64 = jrt.NN(jrt.Double_Cast(na_371)).DoubleValue__D(); tmp1 = n0_372_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_371) } }; if tmp1 { arg_376 = Lit_14 } else { arg_376 = Lit_15 } } else {
//line :191:1
			if A_arbace_repr_go_lit_A_const_21 != nil {

				arg_376 = jrt.Double_ToString_D__String_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)).Ref() } else {
//line :191:1
					arg_376 = nil } } }; var arg_377 any = d__2; if linked_374 == nil { return ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { return linked_374.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } }




func A_arbace_repr_go_lit_hex_float_value_A_New() *A_arbace_repr_go_lit_hex_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hex_float_value_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Ctor() {}
//line :196:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Invoke_O_O__O(self, t__0 any) any { var body__2 any; var root_378 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_380 lang.IFn; if


	linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = t__0; var arg_382 any = A_arbace_repr_go_lit_A_const_37; if linked_379 == nil { body__2 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { body__2 = linked_379.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var pi__3 any; var root_387 any = /*line :196:1*/A_arbace_repr_go_lit_A_const_60.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_389 lang.IFn; if



	linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var root_383 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = body__2; if linked_384 == nil { arg_390 = ifn_385.Invoke_O__O(arg_386) } else { arg_390 = linked_384.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_383, arg_386) }; var arg_391 any = Lit_24; if linked_388 == nil { pi__3 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { pi__3 = linked_388.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; var mant__4 any; var root_392 any = /*line :196:1*/A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_394 lang.IFn; if




	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = body__2; var arg_396 any = A_arbace_repr_go_lit_A_const_61; var arg_397 any = pi__3; if linked_393 == nil { mant__4 = ifn_394.Invoke_O_O_O__O(arg_395, arg_396, arg_397) } else { mant__4 = linked_393.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_392, arg_395, arg_396, arg_397) }; var exp__5 int64; var tmp1 any; var root_405 any = /*line :196:1*/A_arbace_repr_go_lit_A_const_29.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_407 lang.IFn; if





	linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any; var root_400 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = body__2; var arg_404 any; var na_398 any = pi__3; if jrt.Long_InstanceOf(na_398) { var n0_399 int64 = jrt.NN(jrt.Long_Cast(na_398)).LongValue__J(); if n0_399 == 9223372036854775807 { arg_404 = lang.Numbers_Inc_O__Number_NoInit(na_398) } else { arg_404 = jrt.Long_ValueOf_J__Long_NoInit(n0_399 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_398) { var n0_399_2 float64 = jrt.NN(jrt.Double_Cast(na_398)).DoubleValue__D(); arg_404 = jrt.Double_ValueOf_D__Double_NoInit(n0_399_2 + 1.0).Ref() } else { arg_404 = lang.Numbers_Inc_O__Number_NoInit(na_398) } }; if linked_401 == nil { arg_408 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { arg_408 = linked_401.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; var arg_409 any = Lit_25; var arg_410 any = Lit_23; if linked_406 == nil { tmp1 = ifn_407.Invoke_O_O_O__O(arg_408, arg_409, arg_410) } else { tmp1 = linked_406.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_405, arg_408, arg_409, arg_410) }; exp__5 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp1)); var dot__6 any; var root_411 any = /*line :196:1*/A_arbace_repr_go_lit_A_const_60.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_413 lang.IFn; if






	linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = mant__4; var arg_415 any = Lit_8; if linked_412 == nil { dot__6 = ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { dot__6 = linked_412.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_411, arg_414, arg_415) }; var int_part__7 any; if
	jrt.J2g_Truth(dot__6) { var root_416 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = mant__4; var arg_420 any = A_arbace_repr_go_lit_A_const_61; var arg_421 any = dot__6; if linked_417 == nil { int_part__7 = ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { int_part__7 = linked_417.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } else { int_part__7 = mant__4 }; var frac__8 any; if
	jrt.J2g_Truth(dot__6) { var root_424 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = mant__4; var arg_428 any; var na_422 any = dot__6; if jrt.Long_InstanceOf(na_422) { var n0_423 int64 = jrt.NN(jrt.Long_Cast(na_422)).LongValue__J(); if n0_423 == 9223372036854775807 { arg_428 = lang.Numbers_Inc_O__Number_NoInit(na_422) } else { arg_428 = jrt.Long_ValueOf_J__Long_NoInit(n0_423 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_422) { var n0_423_2 float64 = jrt.NN(jrt.Double_Cast(na_422)).DoubleValue__D(); arg_428 = jrt.Double_ValueOf_D__Double_NoInit(n0_423_2 + 1.0).Ref() } else { arg_428 = lang.Numbers_Inc_O__Number_NoInit(na_422) } }; if linked_425 == nil { frac__8 = ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { frac__8 = linked_425.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) } } else { frac__8 = Lit_23 }; var digits__9 any = /*line :196:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, int_part__7, frac__8)).Ref(); var m__10 any; var tmp2 any; var root_429 any = A_arbace_repr_go_lit_A_const_62.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_431 lang.IFn; if










	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = digits__9; if linked_430 == nil { tmp2 = ifn_431.Invoke_O__O(arg_432) } else { tmp2 = linked_430.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_429, arg_432) }; if jrt.J2g_Truth(tmp2) { jrt.BigInteger_Init(); m__10 = jrt.BigInteger_ZERO.Ref() } else { m__10 = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__9), lang.RT_IntCast_J__I_NoInit(16)) }; var e__11 int64 = /*line :196:1*/lang.Numbers_Minus_J_J__J_NoInit(exp__5, lang.Numbers_Multiply_J_J__J_NoInit(4, int64(lang.RT_Count_O__I_NoInit(frac__8)))); if












	lang.Numbers_IsNeg_J__Z_NoInit(e__11) {
		var root_437 any = A_arbace_repr_go_lit_A_const_63.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = m__10; var arg_441 any; var root_433 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_go_lit_pow2_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__11)).Ref(); if linked_434 == nil { arg_441 = ifn_435.Invoke_O__O(arg_436) } else { arg_441 = linked_434.(*A_arbace_repr_go_lit_pow2_A).Invoke_O_O__O(root_433, arg_436) }; if linked_438 == nil { return ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { return linked_438.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) } } else {
			var root_442 any = A_arbace_repr_go_lit_A_const_63.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = jrt.NN(jrt.BigInteger_Cast(m__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__11)).Ref(); var arg_446 any; jrt.BigInteger_Init(); arg_446 = jrt.BigInteger_ONE.Ref(); if linked_443 == nil { return ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { return linked_443.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_442, arg_445, arg_446) } } }

func A_arbace_repr_go_lit_float_value_A_New() *A_arbace_repr_go_lit_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_repr_go_lit_float_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_repr_go_lit_float_value_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_447 any = A_arbace_repr_go_lit_A_const_29.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_449 lang.IFn; if



	linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = text__0; var arg_451 any = Lit_22; var arg_452 any = Lit_23; if linked_448 == nil { t__2 = ifn_449.Invoke_O_O_O__O(arg_450, arg_451, arg_452) } else { t__2 = linked_448.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_447, arg_450, arg_451, arg_452) }; var tmp1 any; var root_457 any =
	A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var root_453 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = t__2; if linked_454 == nil { arg_460 = ifn_455.Invoke_O__O(arg_456) } else { arg_460 = linked_454.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_453, arg_456) }; var arg_461 any = Lit_21; if linked_458 == nil { tmp1 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { tmp1 = linked_458.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if jrt.J2g_Truth(tmp1) {
		var root_462 any = A_arbace_repr_go_lit_A_const_65.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_repr_go_lit_hex_float_value_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = t__2; if linked_463 == nil { return ifn_464.Invoke_O__O(arg_465) } else { return linked_463.(*A_arbace_repr_go_lit_hex_float_value_A).Invoke_O_O__O(root_462, arg_465) } } else {
//line :218:1
			return jrt.BigDecimal_New_String(jrt.String_Cast(t__2)) } }



func A_arbace_repr_go_lit_float_text_lit_A_New() *A_arbace_repr_go_lit_float_text_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_text_lit_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Invoke_O_O__O(self, text__0 any) any { var hex__2 any; var root_470 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_472 lang.IFn; if



	linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_466 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = text__0; if linked_467 == nil { arg_473 = ifn_468.Invoke_O__O(arg_469) } else { arg_473 = linked_467.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_466, arg_469) }; var arg_474 any = Lit_21; if linked_471 == nil { hex__2 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { hex__2 = linked_471.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; var root_479 any =
	A_arbace_repr_go_lit_A_const_58.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var root_475 any = A_arbace_repr_go_lit_A_const_66.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_repr_go_lit_float_value_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = text__0; if linked_476 == nil { arg_482 = ifn_477.Invoke_O__O(arg_478) } else { arg_482 = linked_476.(*A_arbace_repr_go_lit_float_value_A).Invoke_O_O__O(root_475, arg_478) }; var arg_483 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_51, hex__2)); if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } }

func A_arbace_repr_go_lit_imag_inner_A_New() *A_arbace_repr_go_lit_imag_inner_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_imag_inner_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Ctor() {}
//line :229:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_490 any = A_arbace_repr_go_lit_A_const_29.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_492 lang.IFn; if



	linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var root_484 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = text__0; var arg_488 any = A_arbace_repr_go_lit_A_const_61; var arg_489 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_485 == nil { arg_493 = ifn_486.Invoke_O_O_O__O(arg_487, arg_488, arg_489) } else { arg_493 = linked_485.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_484, arg_487, arg_488, arg_489) }; var arg_494 any = Lit_22; var arg_495 any = Lit_23; if linked_491 == nil { t__2 = ifn_492.Invoke_O_O_O__O(arg_493, arg_494, arg_495) } else { t__2 = linked_491.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_490, arg_493, arg_494, arg_495) }; var lower__3 any; var root_496 any = /*line :229:1*/A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_498 lang.IFn; if




	linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = t__2; if linked_497 == nil { lower__3 = ifn_498.Invoke_O__O(arg_499) } else { lower__3 = linked_497.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_496, arg_499) }; var tmp1 any; var root_500 any =
	A_arbace_repr_go_lit_A_const_67.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_502 lang.IFn; if
	linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = A_arbace_repr_go_lit_A_const_68; var arg_504 any = t__2; if linked_501 == nil { tmp1 = ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { tmp1 = linked_501.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) }; if /*line :235:1*/ jrt.J2g_Truth(tmp1) { var v__4 any; var root_505 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_507 lang.IFn
		if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = jrt.BigInteger_New_String(jrt.String_Cast(t__2)); if linked_506 == nil { v__4 = ifn_507.Invoke_O__O(arg_508) } else { v__4 = linked_506.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_505, arg_508) }
		var root_517 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_509 any = A_arbace_repr_go_lit_A_const_41.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_repr_go_lit_integer_text_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = v__4; if linked_510 == nil { arg_520 = ifn_511.Invoke_O__O(arg_512) } else { arg_520 = linked_510.(*A_arbace_repr_go_lit_integer_text_A).Invoke_O_O__O(root_509, arg_512) }; var arg_521 any; var tmp2 any; var root_513 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = v__4; if linked_514 == nil { tmp2 = ifn_515.Invoke_O__O(arg_516) } else { tmp2 = linked_514.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_513, arg_516) }; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(tmp2)).BitLength__I()), 64) { arg_521 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__4)).Ref() } else { arg_521 = v__4 }; if linked_518 == nil { return ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { return linked_518.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) } } else {
//line :235:1
			var tmp3 any; var and__1927000168__auto____4 any; var root_522 any = A_arbace_repr_go_lit_A_const_67.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_524 lang.IFn


			if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = A_arbace_repr_go_lit_A_const_69; var arg_526 any = lower__3; if linked_523 == nil { and__1927000168__auto____4 = ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { and__1927000168__auto____4 = linked_523.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_532 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var root_527 any = A_arbace_repr_go_lit_A_const_49.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = lower__3; var arg_531 any = Lit_24; if linked_528 == nil { arg_535 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { arg_535 = linked_528.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }; if linked_533 == nil { and__1927000168__auto____5 = ifn_534.Invoke_O__O(arg_535) } else { and__1927000168__auto____5 = linked_533.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_532, arg_535) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_541 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any; var root_536 any = A_arbace_repr_go_lit_A_const_49.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lower__3; var arg_540 any = Lit_8; if linked_537 == nil { arg_544 = ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { arg_544 = linked_537.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_536, arg_539, arg_540) }; if linked_542 == nil { tmp3 = ifn_543.Invoke_O__O(arg_544) } else { tmp3 = linked_542.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_541, arg_544) } } else {
//line :238:1
					tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :235:1
			if jrt.J2g_Truth(tmp3) {




				var root_545 any = A_arbace_repr_go_lit_A_const_70.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, A_arbace_repr_go_lit_int_lit_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = t__2; if linked_546 == nil { return ifn_547.Invoke_O__O(arg_548) } else { return linked_546.(*A_arbace_repr_go_lit_int_lit_A).Invoke_O_O__O(root_545, arg_548) } } else {
//line :235:1
					if A_arbace_repr_go_lit_A_const_21 != nil {





						var root_549 any = A_arbace_repr_go_lit_A_const_71.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, A_arbace_repr_go_lit_float_text_lit_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = t__2; if linked_550 == nil { return ifn_551.Invoke_O__O(arg_552) } else { return linked_550.(*A_arbace_repr_go_lit_float_text_lit_A).Invoke_O_O__O(root_549, arg_552) } } else {
//line :235:1
							return nil } } } }









func A_arbace_repr_go_lit_hexv_A_New() *A_arbace_repr_go_lit_hexv_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hexv_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_repr_go_lit_hexv_A) Ctor() {}
//line :245:1
func (t *A_arbace_repr_go_lit_hexv_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(s__0), lang.RT_IntCast_J__I_NoInit(16))).Ref() }

func A_arbace_repr_go_lit_unescape_A_New() *A_arbace_repr_go_lit_unescape_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_repr_go_lit_unescape_A) Ctor() {}
//line :247:1
func (t *A_arbace_repr_go_lit_unescape_A) Invoke_O_O__O(self, body__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var n__3 int32 = jrt.NN(jrt.String_Cast(body__0)).Length__I(); var put_cp__4 any; var tmp1 any = A_arbace_repr_go_lit_unescape_put_cp__790000067_A_New_O(out__2); var tmp2 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class; if




	fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class = fncls__553d; tmp2 = fncls__553d } else { tmp2 = fncls__553 }; put_cp__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var i__5 int64 = 0; L1:
//line :247:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(n__3)) { var c__6 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__5)); var tmp3 any; var root_554 any = A_arbace_repr_go_lit_A_const_72.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_556 lang.IFn

			if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = jrt.Character_ValueOf_C__Character_NoInit(c__6).Ref(); var arg_558 any = A_arbace_repr_go_lit_A_const_73; if linked_555 == nil { tmp3 = ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { tmp3 = linked_555.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_554, arg_557, arg_558) }; if jrt.J2g_Truth(tmp3) { var cp__7 int32 = jrt.NN(jrt.String_Cast(body__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__5))

				lang.IFn_Cast(put_cp__4).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(cp__7).Ref())
				i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, int64(jrt.Character_CharCount_I__I_NoInit(cp__7))); continue L1 } else {
//line :258:1
					var e__7 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)))
					var G__790000069__8_ uint16 = e__7



				L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_74) {









					jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(34)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
					break L2 }; case 39: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_75) {








						jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(39)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
						break L2 }; case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_76) {












							var tmp4 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp5 any; var root_566 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var root_560 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = body__0; var arg_564 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_565 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 10)).Ref(); if linked_561 == nil { arg_569 = ifn_562.Invoke_O_O_O__O(arg_563, arg_564, arg_565) } else { arg_569 = linked_561.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_560, arg_563, arg_564, arg_565) }; if linked_567 == nil { tmp5 = ifn_568.Invoke_O__O(arg_569) } else { tmp5 = linked_567.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_566, arg_569) }; tmp4.Invoke_O__O(tmp5); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 10); continue L1
//line :263:1
							break L2 }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_73) {







								jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(92)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
								break L2 }; case 97: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_78) {
									jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(7)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
									break L2 }; case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_79) {

										jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(8)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
										break L2 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_80) {


											jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(12)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
											break L2 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_81) {



												jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
												break L2 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_82) {




													jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(13)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
													break L2 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_83) {





														jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(9)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
														break L2 }; case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_84) {











															var tmp6 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp7 any; var root_576 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var root_570 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = body__0; var arg_574 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_575 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 6)).Ref(); if linked_571 == nil { arg_579 = ifn_572.Invoke_O_O_O__O(arg_573, arg_574, arg_575) } else { arg_579 = linked_571.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_570, arg_573, arg_574, arg_575) }; if linked_577 == nil { tmp7 = ifn_578.Invoke_O__O(arg_579) } else { tmp7 = linked_577.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_576, arg_579) }; tmp6.Invoke_O__O(tmp7); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 6); continue L1
//line :263:1
															break L2 }; case 118: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_85) {






																jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(11)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :263:1
																break L2 }; case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_86) {










																	var tmp8 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp9 any; var root_586 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any; var root_580 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = body__0; var arg_584 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_585 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref(); if linked_581 == nil { arg_589 = ifn_582.Invoke_O_O_O__O(arg_583, arg_584, arg_585) } else { arg_589 = linked_581.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_580, arg_583, arg_584, arg_585) }; if linked_587 == nil { tmp9 = ifn_588.Invoke_O__O(arg_589) } else { tmp9 = linked_587.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_586, arg_589) }; jrt.NN(tmp8).Write_I__V(lang.RT_IntCast_O__I_NoInit(tmp9)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1
//line :263:1
																	break L2 }; default:
				}












					var tmp10 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp11 any; var root_590 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = body__0; var arg_594 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)).Ref(); var arg_595 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref(); if linked_591 == nil { tmp11 = ifn_592.Invoke_O_O_O__O(arg_593, arg_594, arg_595) } else { tmp11 = linked_591.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_590, arg_593, arg_594, arg_595) }; jrt.NN(tmp10).Write_I__V(lang.RT_IntCast_J__I_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp11), lang.RT_IntCast_J__I_NoInit(8))))
					i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1} } }
//line :247:1
		break L1 }; return out__2 }




func A_arbace_repr_go_lit_unescape_put_cp__790000067_A_New_O(p0 any) *A_arbace_repr_go_lit_unescape_put_cp__790000067_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_put_cp__790000067_A{}; t.Ctor_O(p0); return t }
//line :252:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000067_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :252:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000067_A) Invoke_O_O__O(self, cp__1 any) any { var bs__2 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_O__I_NoInit(cp__1))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(t.F_out);

	jrt.NN(tmp1).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))); return nil }


























func A_arbace_repr_go_lit_string_bytes_A_New() *A_arbace_repr_go_lit_string_bytes_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_bytes_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Ctor() {}
//line :281:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Invoke_O_O__O(self, text__0 any) any {


	var tmp1 any; var root_596 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = text__0; var arg_600 any = Lit_33; if linked_597 == nil { tmp1 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { tmp1 = linked_597.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_607 any = A_arbace_repr_go_lit_A_const_29.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var root_601 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = text__0; var arg_605 any = A_arbace_repr_go_lit_A_const_39; var arg_606 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_602 == nil { arg_610 = ifn_603.Invoke_O_O_O__O(arg_604, arg_605, arg_606) } else { arg_610 = linked_602.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_601, arg_604, arg_605, arg_606) }; var arg_611 any = Lit_34; var arg_612 any = Lit_23; if linked_608 == nil { tmp2 = ifn_609.Invoke_O_O_O__O(arg_610, arg_611, arg_612) } else { tmp2 = linked_608.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_607, arg_610, arg_611, arg_612) }; return jrt.NN(jrt.String_Cast(tmp2)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
			var tmp3 any; var root_619 any = A_arbace_repr_go_lit_A_const_87.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_repr_go_lit_unescape_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any; var root_613 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = text__0; var arg_617 any = A_arbace_repr_go_lit_A_const_39; var arg_618 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_614 == nil { arg_622 = ifn_615.Invoke_O_O_O__O(arg_616, arg_617, arg_618) } else { arg_622 = linked_614.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_613, arg_616, arg_617, arg_618) }; if linked_620 == nil { tmp3 = ifn_621.Invoke_O__O(arg_622) } else { tmp3 = linked_620.(*A_arbace_repr_go_lit_unescape_A).Invoke_O_O__O(root_619, arg_622) }; return jrt.NN(jrt.ByteArrayOutputStream_Cast(tmp3)).ToByteArray__B1().Ref()
		} }
func A_arbace_repr_go_lit_rune_value_A_New() *A_arbace_repr_go_lit_rune_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_value_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_repr_go_lit_rune_value_A) Ctor() {}
//line :288:1
func (t *A_arbace_repr_go_lit_rune_value_A) Invoke_O_O__O(self, text__0 any) any { var body__2 any; var root_623 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_625 lang.IFn; if


	linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = text__0; var arg_627 any = A_arbace_repr_go_lit_A_const_39; var arg_628 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_624 == nil { body__2 = ifn_625.Invoke_O_O_O__O(arg_626, arg_627, arg_628) } else { body__2 = linked_624.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_623, arg_626, arg_627, arg_628) }; var tmp1 any; var root_629 any =
	A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = body__2; var arg_633 any = Lit_5; if linked_630 == nil { tmp1 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { tmp1 = linked_630.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; if jrt.J2g_Truth(tmp1) { var G__790000072__3_ uint16 = jrt.NN(jrt.String_Cast(body__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(1))
		switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref()) { case 48: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_88) {



			var tmp2 any; var root_635 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = body__2; var arg_639 any = A_arbace_repr_go_lit_A_const_39; if linked_636 == nil { tmp2 = ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { tmp2 = linked_636.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp2), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 49: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_89) {



			var tmp3 any; var root_640 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = body__2; var arg_644 any = A_arbace_repr_go_lit_A_const_39; if linked_641 == nil { tmp3 = ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { tmp3 = linked_641.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp3), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 50: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_90) {



			var tmp4 any; var root_645 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = body__2; var arg_649 any = A_arbace_repr_go_lit_A_const_39; if linked_646 == nil { tmp4 = ifn_647.Invoke_O_O__O(arg_648, arg_649) } else { tmp4 = linked_646.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_645, arg_648, arg_649) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 51: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_91) {



			var tmp5 any; var root_650 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = body__2; var arg_654 any = A_arbace_repr_go_lit_A_const_39; if linked_651 == nil { tmp5 = ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { tmp5 = linked_651.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp5), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 52: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_92) {



			var tmp6 any; var root_659 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = body__2; var arg_663 any = A_arbace_repr_go_lit_A_const_39; if linked_660 == nil { tmp6 = ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { tmp6 = linked_660.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp6), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_93) {



			var tmp7 any; var root_664 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = body__2; var arg_668 any = A_arbace_repr_go_lit_A_const_39; if linked_665 == nil { tmp7 = ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { tmp7 = linked_665.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp7), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 54: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_94) {



			var tmp8 any; var root_669 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = body__2; var arg_673 any = A_arbace_repr_go_lit_A_const_39; if linked_670 == nil { tmp8 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp8 = linked_670.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp8), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 55: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_95) {



			var tmp9 any; var root_674 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = body__2; var arg_678 any = A_arbace_repr_go_lit_A_const_39; if linked_675 == nil { tmp9 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { tmp9 = linked_675.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp9), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :293:1
		case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_76) {


			var root_684 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var root_679 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = body__2; var arg_683 any = A_arbace_repr_go_lit_A_const_37; if linked_680 == nil { arg_687 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { arg_687 = linked_680.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; if linked_685 == nil { return ifn_686.Invoke_O__O(arg_687) } else { return linked_685.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_684, arg_687) } }
//line :293:1
		case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_84) {

			var root_693 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var root_688 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = body__2; var arg_692 any = A_arbace_repr_go_lit_A_const_37; if linked_689 == nil { arg_696 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_696 = linked_689.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_694 == nil { return ifn_695.Invoke_O__O(arg_696) } else { return linked_694.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_693, arg_696) } }
//line :293:1
		case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_86) {
			var root_702 any = A_arbace_repr_go_lit_A_const_77.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var root_697 any = A_arbace_repr_go_lit_A_const_36.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = body__2; var arg_701 any = A_arbace_repr_go_lit_A_const_37; if linked_698 == nil { arg_705 = ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { arg_705 = linked_698.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) }; if linked_703 == nil { return ifn_704.Invoke_O__O(arg_705) } else { return linked_703.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_702, arg_705) } }
//line :293:1
		default:}; var bs__4 any; var tmp10 any; var root_655 any = A_arbace_repr_go_lit_A_const_87.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, A_arbace_repr_go_lit_unescape_A_fn_class); var ifn_657 lang.IFn




		if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = body__2; if linked_656 == nil { tmp10 = ifn_657.Invoke_O__O(arg_658) } else { tmp10 = linked_656.(*A_arbace_repr_go_lit_unescape_A).Invoke_O_O__O(root_655, arg_658) }; bs__4 = jrt.NN(jrt.ByteArrayOutputStream_Cast(tmp10)).ToByteArray__B1().Ref()
		return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.String_Cast(body__2)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } }

func A_arbace_repr_go_lit_decode_rune_A_New() *A_arbace_repr_go_lit_decode_rune_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Ctor() {}
//line :302:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Invoke_O_O_O_O__O(self, bs__0, i__1, n__2 any) any { var b__4 any; var tmp1 any = A_arbace_repr_go_lit_decode_rune_b__790000074_A_New_O(bs__0); var tmp2 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class; if


	fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class = fncls__706d; tmp2 = fncls__706d } else { tmp2 = fncls__706 }; b__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var cont_QMARK___5 any; var tmp3 any = /*line :302:1*/A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_New_O_O(n__2, b__4); var tmp4 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class; if



	fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class = fncls__717d; tmp4 = fncls__717d } else { tmp4 = fncls__717 }; cont_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var b0__6 any = /*line :302:1*/lang.IFn_Cast(b__4).Invoke_O__O(i__1); var tmp5 bool; var na_718 any = b0__6; var na_719 int64 = 128; if






	jrt.Long_InstanceOf(na_718) { var n0_720 int64 = jrt.NN(jrt.Long_Cast(na_718)).LongValue__J(); var n1_721 int64 = na_719; tmp5 = n0_720 < n1_721 } else { tmp5 = lang.Numbers_Lt_O_J__Z_NoInit(na_718, na_719) }; if tmp5 {
//line :308:1
		return lang.Tuple_Create_O_O__IPersistentVector(b0__6, A_arbace_repr_go_lit_A_const_39) } else { var tmp6 bool
			var na_723 any = b0__6; var na_724 int64 = 194
			if jrt.Long_InstanceOf(na_723) { var n0_725 int64 = jrt.NN(jrt.Long_Cast(na_723)).LongValue__J(); var n1_726 int64 = na_724; tmp6 = n0_725 < n1_726 } else { tmp6 = lang.Numbers_Lt_O_J__Z_NoInit(na_723, na_724) }
//line :308:1
			if tmp6 { return A_arbace_repr_go_lit_A_const_96 } else { var tmp7 bool
				var na_728 any = b0__6
				var na_729 int64 = 224
				if jrt.Long_InstanceOf(na_728) { var n0_730 int64 = jrt.NN(jrt.Long_Cast(na_728)).LongValue__J(); var n1_731 int64 = na_729; tmp7 = n0_730 < n1_731 } else { tmp7 = lang.Numbers_Lt_O_J__Z_NoInit(na_728, na_729) }
//line :308:1
				if tmp7 {


					var tmp8 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp9 jrt.Number_I; var na_777 any = i__1; if jrt.Long_InstanceOf(na_777) { var n0_778 int64 = jrt.NN(jrt.Long_Cast(na_777)).LongValue__J(); if n0_778 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_777) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_778 + 1)) } } else { if jrt.Double_InstanceOf(na_777) { var n0_778_2 float64 = jrt.NN(jrt.Double_Cast(na_777)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_778_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_777) } }; if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) { var tmp10 int64; var na_779 any = b0__6; var na_780 int64 = 31
						if jrt.Long_InstanceOf(na_779) { var n0_781 int64 = jrt.NN(jrt.Long_Cast(na_779)).LongValue__J(); var n1_782 int64 = na_780; tmp10 = n0_781 & n1_782 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_779, na_780) }
//line :311:1
						var tmp11 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp10, 6); var tmp12 int64; var na_784 any; var tmp13 lang.IFn = lang.IFn_Cast(b__4); var tmp14 jrt.Number_I; var na_789 any = i__1
						if jrt.Long_InstanceOf(na_789) { var n0_790 int64 = jrt.NN(jrt.Long_Cast(na_789)).LongValue__J(); if n0_790 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_789) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_790 + 1)) } } else { if jrt.Double_InstanceOf(na_789) { var n0_790_2 float64 = jrt.NN(jrt.Double_Cast(na_789)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_790_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_789) } }; na_784 = tmp13.Invoke_O__O(tmp14); var na_785 int64 = 63; if jrt.Long_InstanceOf(na_784) { var n0_786 int64 = jrt.NN(jrt.Long_Cast(na_784)).LongValue__J(); var n1_787 int64 = na_785; tmp12 = n0_786 & n1_787 } else { tmp12 = lang.Numbers_And_O_J__J_NoInit(na_784, na_785) }
//line :311:1
						return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp11, tmp12)).Ref(), A_arbace_repr_go_lit_A_const_37) } else { return A_arbace_repr_go_lit_A_const_97 } } else {
//line :308:1
							var tmp15 bool
							var na_733 any = b0__6
							var na_734 int64 = 240



							if jrt.Long_InstanceOf(na_733) { var n0_735 int64 = jrt.NN(jrt.Long_Cast(na_733)).LongValue__J(); var n1_736 int64 = na_734; tmp15 = n0_735 < n1_736 } else { tmp15 = lang.Numbers_Lt_O_J__Z_NoInit(na_733, na_734) }
//line :308:1
							if tmp15 { var lo__7 int64; var G__790000078__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)





							L1: switch { default: switch G__790000078__7_ { case 224: lo__7 = 160; break L1; default:}; lo__7 = 128}
//line :308:1
								var hi__8 int64; var G__790000079__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)






							L2: switch { default: switch G__790000079__8_ { case 237: hi__8 = 159; break L2; default:}; hi__8 = 191}
								var tmp16 any; var and__1927000168__auto____9 bool; var na_740 any; var na_742 any = i__1; if jrt.Long_InstanceOf(na_742) { var n0_743 int64 = jrt.NN(jrt.Long_Cast(na_742)).LongValue__J(); if n0_743 == 9223372036854775807 { na_740 = lang.Numbers_Inc_O__Number_NoInit(na_742) } else { na_740 = jrt.Long_ValueOf_J__Long_NoInit(n0_743 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_742) { var n0_743_2 float64 = jrt.NN(jrt.Double_Cast(na_742)).DoubleValue__D(); na_740 = jrt.Double_ValueOf_D__Double_NoInit(n0_743_2 + 1.0).Ref() } else { na_740 = lang.Numbers_Inc_O__Number_NoInit(na_742) } }; var na_741 any = n__2; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_740); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_741) }; tmp17 = tmp18; if tmp17 { var n0_744 int64 = jrt.NN(jrt.Long_Cast(na_740)).LongValue__J(); var n1_745 int64 = jrt.NN(jrt.Long_Cast(na_741)).LongValue__J(); and__1927000168__auto____9 = n0_744 < n1_745 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_740); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_741) }; tmp19 = tmp20; if tmp19 { var n0_744_2 float64 = jrt.NN(jrt.Double_Cast(na_740)).DoubleValue__D(); var n1_745_2 float64 = jrt.NN(jrt.Double_Cast(na_741)).DoubleValue__D(); and__1927000168__auto____9 = n0_744_2 < n1_745_2 } else { and__1927000168__auto____9 = lang.Numbers_Lt_O_O__Z_NoInit(na_740, na_741) } }; if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp22 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(b__4); var tmp24 jrt.Number_I; var na_747 any = i__1; if jrt.Long_InstanceOf(na_747) { var n0_748 int64 = jrt.NN(jrt.Long_Cast(na_747)).LongValue__J(); if n0_748 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_747) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_748 + 1)) } } else { if jrt.Double_InstanceOf(na_747) { var n0_748_2 float64 = jrt.NN(jrt.Double_Cast(na_747)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_748_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_747) } }; and__1927000168__auto____10 = tmp21.Invoke_O_O_O__O(tmp22, tmp23.Invoke_O__O(tmp24), jrt.Long_ValueOf_J__Long_NoInit(hi__8).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp25 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp26 jrt.Number_I; var na_791 any = i__1; var na_792 int64 = 2; if jrt.Long_InstanceOf(na_791) { var n0_793 int64 = jrt.NN(jrt.Long_Cast(na_791)).LongValue__J(); var n1_794 int64 = na_792; var nr_795 int64 = n0_793 + n1_794; if (n0_793^nr_795)&(n1_794^nr_795) >= 0 { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_795)) } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_791, na_792) } } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_791, na_792) }; tmp16 = tmp25.Invoke_O__O(tmp26) } else { tmp16 = and__1927000168__auto____10 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp16) { var tmp27 int64; var na_796 any = b0__6; var na_797 int64 = 15
									if jrt.Long_InstanceOf(na_796) { var n0_798 int64 = jrt.NN(jrt.Long_Cast(na_796)).LongValue__J(); var n1_799 int64 = na_797; tmp27 = n0_798 & n1_799 } else { tmp27 = lang.Numbers_And_O_J__J_NoInit(na_796, na_797) }
//line :316:1
									var tmp28 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp27, 12); var tmp29 int64; var na_801 any; var tmp30 lang.IFn = lang.IFn_Cast(b__4); var tmp31 jrt.Number_I
									var na_811 any = i__1
									if jrt.Long_InstanceOf(na_811) { var n0_812 int64 = jrt.NN(jrt.Long_Cast(na_811)).LongValue__J(); if n0_812 == 9223372036854775807 { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_811) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_812 + 1)) } } else { if jrt.Double_InstanceOf(na_811) { var n0_812_2 float64 = jrt.NN(jrt.Double_Cast(na_811)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_812_2 + 1.0)) } else { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_811) } }; na_801 = tmp30.Invoke_O__O(tmp31); var na_802 int64 = 63; if jrt.Long_InstanceOf(na_801) { var n0_803 int64 = jrt.NN(jrt.Long_Cast(na_801)).LongValue__J(); var n1_804 int64 = na_802; tmp29 = n0_803 & n1_804 } else { tmp29 = lang.Numbers_And_O_J__J_NoInit(na_801, na_802) }
//line :316:1
									var tmp32 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp28, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp29, 6)); var tmp33 int64; var na_806 any; var tmp34 lang.IFn = lang.IFn_Cast(b__4); var tmp35 jrt.Number_I
									var na_813 any = i__1
									var na_814 int64 = 2
									if jrt.Long_InstanceOf(na_813) { var n0_815 int64 = jrt.NN(jrt.Long_Cast(na_813)).LongValue__J(); var n1_816 int64 = na_814; var nr_817 int64 = n0_815 + n1_816; if (n0_815^nr_817)&(n1_816^nr_817) >= 0 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_817)) } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_813, na_814) } } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_813, na_814) }; na_806 = tmp34.Invoke_O__O(tmp35); var na_807 int64 = 63; if jrt.Long_InstanceOf(na_806) { var n0_808 int64 = jrt.NN(jrt.Long_Cast(na_806)).LongValue__J(); var n1_809 int64 = na_807; tmp33 = n0_808 & n1_809 } else { tmp33 = lang.Numbers_And_O_J__J_NoInit(na_806, na_807) }
//line :316:1
									return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp32, tmp33)).Ref(), A_arbace_repr_go_lit_A_const_101) } else { return A_arbace_repr_go_lit_A_const_98 } } else {
//line :308:1
										var tmp36 bool
										var na_755 any = b0__6
										var na_756 int64 = 245










										if jrt.Long_InstanceOf(na_755) { var n0_757 int64 = jrt.NN(jrt.Long_Cast(na_755)).LongValue__J(); var n1_758 int64 = na_756; tmp36 = n0_757 < n1_758 } else { tmp36 = lang.Numbers_Lt_O_J__Z_NoInit(na_755, na_756) }
//line :308:1
										if tmp36 { var lo__7_2 int64; var G__790000080__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)












										L3: switch { default: switch G__790000080__7_ { case 240: lo__7_2 = 144; break L3; default:}; lo__7_2 = 128}
//line :308:1
											var hi__8_2 int64; var G__790000081__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)













										L4: switch { default: switch G__790000081__8_ { case 244: hi__8_2 = 143; break L4; default:}; hi__8_2 = 191}
											var tmp37 any; var and__1927000168__auto____9_2 bool; var na_762 any; var na_764 any = i__1; if jrt.Long_InstanceOf(na_764) { var n0_765 int64 = jrt.NN(jrt.Long_Cast(na_764)).LongValue__J(); if n0_765 == 9223372036854775807 { na_762 = lang.Numbers_Inc_O__Number_NoInit(na_764) } else { na_762 = jrt.Long_ValueOf_J__Long_NoInit(n0_765 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_764) { var n0_765_2 float64 = jrt.NN(jrt.Double_Cast(na_764)).DoubleValue__D(); na_762 = jrt.Double_ValueOf_D__Double_NoInit(n0_765_2 + 1.0).Ref() } else { na_762 = lang.Numbers_Inc_O__Number_NoInit(na_764) } }; var na_763 any = n__2; var tmp38 bool; var tmp39 bool; tmp39 = jrt.Long_InstanceOf(na_762); if tmp39 { tmp39 = jrt.Long_InstanceOf(na_763) }; tmp38 = tmp39; if tmp38 { var n0_766 int64 = jrt.NN(jrt.Long_Cast(na_762)).LongValue__J(); var n1_767 int64 = jrt.NN(jrt.Long_Cast(na_763)).LongValue__J(); and__1927000168__auto____9_2 = n0_766 < n1_767 } else { var tmp40 bool; var tmp41 bool; tmp41 = jrt.Double_InstanceOf(na_762); if tmp41 { tmp41 = jrt.Double_InstanceOf(na_763) }; tmp40 = tmp41; if tmp40 { var n0_766_2 float64 = jrt.NN(jrt.Double_Cast(na_762)).DoubleValue__D(); var n1_767_2 float64 = jrt.NN(jrt.Double_Cast(na_763)).DoubleValue__D(); and__1927000168__auto____9_2 = n0_766_2 < n1_767_2 } else { and__1927000168__auto____9_2 = lang.Numbers_Lt_O_O__Z_NoInit(na_762, na_763) } }; if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp43 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7_2).Ref(); var tmp44 lang.IFn = lang.IFn_Cast(b__4); var tmp45 jrt.Number_I; var na_769 any = i__1; if jrt.Long_InstanceOf(na_769) { var n0_770 int64 = jrt.NN(jrt.Long_Cast(na_769)).LongValue__J(); if n0_770 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_769) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_770 + 1)) } } else { if jrt.Double_InstanceOf(na_769) { var n0_770_2 float64 = jrt.NN(jrt.Double_Cast(na_769)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_770_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_769) } }; and__1927000168__auto____10_2 = tmp42.Invoke_O_O_O__O(tmp43, tmp44.Invoke_O__O(tmp45), jrt.Long_ValueOf_J__Long_NoInit(hi__8_2).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any; var tmp46 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp47 jrt.Number_I; var na_818 any = i__1; var na_819 int64 = 2; if jrt.Long_InstanceOf(na_818) { var n0_820 int64 = jrt.NN(jrt.Long_Cast(na_818)).LongValue__J(); var n1_821 int64 = na_819; var nr_822 int64 = n0_820 + n1_821; if (n0_820^nr_822)&(n1_821^nr_822) >= 0 { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_822)) } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_818, na_819) } } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_818, na_819) }; and__1927000168__auto____11 = tmp46.Invoke_O__O(tmp47); if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp48 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp49 jrt.Number_I; var na_823 any = i__1; var na_824 int64 = 3; if jrt.Long_InstanceOf(na_823) { var n0_825 int64 = jrt.NN(jrt.Long_Cast(na_823)).LongValue__J(); var n1_826 int64 = na_824; var nr_827 int64 = n0_825 + n1_826; if (n0_825^nr_827)&(n1_826^nr_827) >= 0 { tmp49 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_827)) } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_823, na_824) } } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_823, na_824) }; tmp37 = tmp48.Invoke_O__O(tmp49) } else { tmp37 = and__1927000168__auto____11 } } else { tmp37 = and__1927000168__auto____10_2 } } else { tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }; if jrt.J2g_Truth(tmp37) { var tmp50 int64; var na_828 any = b0__6; var na_829 int64 = 7
												if jrt.Long_InstanceOf(na_828) { var n0_830 int64 = jrt.NN(jrt.Long_Cast(na_828)).LongValue__J(); var n1_831 int64 = na_829; tmp50 = n0_830 & n1_831 } else { tmp50 = lang.Numbers_And_O_J__J_NoInit(na_828, na_829) }
//line :323:1
												var tmp51 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp50, 18); var tmp52 int64; var na_833 any; var tmp53 lang.IFn = lang.IFn_Cast(b__4); var tmp54 jrt.Number_I
												var na_848 any = i__1
												if jrt.Long_InstanceOf(na_848) { var n0_849 int64 = jrt.NN(jrt.Long_Cast(na_848)).LongValue__J(); if n0_849 == 9223372036854775807 { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_848) } else { tmp54 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_849 + 1)) } } else { if jrt.Double_InstanceOf(na_848) { var n0_849_2 float64 = jrt.NN(jrt.Double_Cast(na_848)).DoubleValue__D(); tmp54 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_849_2 + 1.0)) } else { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_848) } }; na_833 = tmp53.Invoke_O__O(tmp54); var na_834 int64 = 63; if jrt.Long_InstanceOf(na_833) { var n0_835 int64 = jrt.NN(jrt.Long_Cast(na_833)).LongValue__J(); var n1_836 int64 = na_834; tmp52 = n0_835 & n1_836 } else { tmp52 = lang.Numbers_And_O_J__J_NoInit(na_833, na_834) }
//line :323:1
												var tmp55 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp51, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp52, 12)); var tmp56 int64; var na_838 any; var tmp57 lang.IFn = lang.IFn_Cast(b__4); var tmp58 jrt.Number_I
												var na_850 any = i__1
												var na_851 int64 = 2
												if jrt.Long_InstanceOf(na_850) { var n0_852 int64 = jrt.NN(jrt.Long_Cast(na_850)).LongValue__J(); var n1_853 int64 = na_851; var nr_854 int64 = n0_852 + n1_853; if (n0_852^nr_854)&(n1_853^nr_854) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_854)) } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_850, na_851) } } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_850, na_851) }; na_838 = tmp57.Invoke_O__O(tmp58); var na_839 int64 = 63; if jrt.Long_InstanceOf(na_838) { var n0_840 int64 = jrt.NN(jrt.Long_Cast(na_838)).LongValue__J(); var n1_841 int64 = na_839; tmp56 = n0_840 & n1_841 } else { tmp56 = lang.Numbers_And_O_J__J_NoInit(na_838, na_839) }
//line :323:1
												var tmp59 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp55, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp56, 6)); var tmp60 int64; var na_843 any; var tmp61 lang.IFn = lang.IFn_Cast(b__4); var tmp62 jrt.Number_I
												var na_855 any = i__1
												var na_856 int64 = 3

												if jrt.Long_InstanceOf(na_855) { var n0_857 int64 = jrt.NN(jrt.Long_Cast(na_855)).LongValue__J(); var n1_858 int64 = na_856; var nr_859 int64 = n0_857 + n1_858; if (n0_857^nr_859)&(n1_858^nr_859) >= 0 { tmp62 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_859)) } else { tmp62 = lang.Numbers_Add_O_J__Number_NoInit(na_855, na_856) } } else { tmp62 = lang.Numbers_Add_O_J__Number_NoInit(na_855, na_856) }; na_843 = tmp61.Invoke_O__O(tmp62); var na_844 int64 = 63; if jrt.Long_InstanceOf(na_843) { var n0_845 int64 = jrt.NN(jrt.Long_Cast(na_843)).LongValue__J(); var n1_846 int64 = na_844; tmp60 = n0_845 & n1_846 } else { tmp60 = lang.Numbers_And_O_J__J_NoInit(na_843, na_844) }
//line :323:1
												return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp59, tmp60)).Ref(), A_arbace_repr_go_lit_A_const_102) } else { return A_arbace_repr_go_lit_A_const_99 } } else {
//line :308:1
													if A_arbace_repr_go_lit_A_const_21 != nil { return A_arbace_repr_go_lit_A_const_100 } else { return nil } } } } } } }
//line :305:1
func A_arbace_repr_go_lit_decode_rune_b__790000074_A_New_O(p0 any) *A_arbace_repr_go_lit_decode_rune_b__790000074_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_b__790000074_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000074_A) Ctor_O(c__bs any) { t.F_bs = c__bs }
//line :305:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000074_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(k__1)))))).Ref() }
func A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :306:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A) Ctor_O_O(c__n, c__b any) { t.F_n = c__n; t.F_b = c__b }
//line :306:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A) Invoke_O_O__O(self, k__1 any) any { var and__1927000168__auto____2 bool; var na_707 any = k__1; var na_708 any = t.F_n; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_707); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_708) }; tmp1 = tmp2; if tmp1 { var n0_709 int64 = jrt.NN(jrt.Long_Cast(na_707)).LongValue__J(); var n1_710 int64 = jrt.NN(jrt.Long_Cast(na_708)).LongValue__J(); and__1927000168__auto____2 = n0_709 < n1_710 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_707); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_708) }; tmp3 = tmp4; if tmp3 { var n0_709_2 float64 = jrt.NN(jrt.Double_Cast(na_707)).DoubleValue__D(); var n1_710_2 float64 = jrt.NN(jrt.Double_Cast(na_708)).DoubleValue__D(); and__1927000168__auto____2 = n0_709_2 < n1_710_2 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_O__Z_NoInit(na_707, na_708) } }; if and__1927000168__auto____2 { var tmp5 int64; var na_712 any = lang.IFn_Cast(t.F_b).Invoke_O__O(k__1); var na_713 int64 = 192; if jrt.Long_InstanceOf(na_712) { var n0_714 int64 = jrt.NN(jrt.Long_Cast(na_712)).LongValue__J(); var n1_715 int64 = na_713; tmp5 = n0_714 & n1_715 } else { tmp5 = lang.Numbers_And_O_J__J_NoInit(na_712, na_713) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(128, tmp5)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
























func A_arbace_repr_go_lit_utf8_parts_A_New() *A_arbace_repr_go_lit_utf8_parts_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_utf8_parts_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Ctor() {}
//line :331:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Invoke_O_O__O(self, bs__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass())); var i__3 int64 = 0; var run__4 any = jrt.StringBuilder_New(); var parts__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_J_J__Z_NoInit(i__3, int64(n__2)) {
		if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) { var root_864 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = parts__5; var arg_868 any; var root_860 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = run__4; if linked_861 == nil { arg_868 = ifn_862.Invoke_O__O(arg_863) } else { arg_868 = linked_861.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_860, arg_863) }; if linked_865 == nil { return ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { return linked_865.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) } } else { return parts__5 } } else {
//line :336:1
			var vec__790000083__6 any; var root_869 any = A_arbace_repr_go_lit_A_const_103.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_repr_go_lit_decode_rune_A_fn_class); var ifn_871 lang.IFn

			if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = bs__0; var arg_873 any = jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref(); var arg_874 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref(); if linked_870 == nil { vec__790000083__6 = ifn_871.Invoke_O_O_O__O(arg_872, arg_873, arg_874) } else { vec__790000083__6 = linked_870.(*A_arbace_repr_go_lit_decode_rune_A).Invoke_O_O_O_O__O(root_869, arg_872, arg_873, arg_874) }
//line :336:1
			var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000083__6, lang.RT_IntCast_J__I_NoInit(0), nil); var w__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000083__6, lang.RT_IntCast_J__I_NoInit(1), nil)


			if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(r__7)) {
				var tmp1 int64 = lang.Numbers_Inc_J__J_NoInit(i__3); var tmp2 any = jrt.StringBuilder_New(); var tmp3 any; var G__790000086__9_ any = parts__5; var G__790000086__10_ any
				if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) {
					var root_879 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = G__790000086__9_; var arg_883 any; var root_875 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = run__4; if linked_876 == nil { arg_883 = ifn_877.Invoke_O__O(arg_878) } else { arg_883 = linked_876.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_875, arg_878) }; if linked_880 == nil { G__790000086__10_ = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { G__790000086__10_ = linked_880.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) } } else {
//line :341:1
						G__790000086__10_ = G__790000086__9_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {

							var root_884 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = G__790000086__10_; var arg_888 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__3)))))).Ref(); if linked_885 == nil { tmp3 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp3 = linked_885.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) } } else {
//line :341:1
								tmp3 = G__790000086__10_ }
//line :340:1
				i__3, run__4, parts__5 = tmp1, tmp2, tmp3; continue L1 } else {



					i__3, run__4, parts__5 = lang.Numbers_Add_J_J__J_NoInit(i__3, lang.RT_LongCast_O__J_NoInit(w__8)), jrt.NN(jrt.StringBuilder_Cast(run__4)).AppendCodePoint_I__StringBuilder(lang.RT_IntCast_O__I_NoInit(r__7)).Ref(), parts__5; continue L1 } } } }; /*line :331:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_lit_rune_form_A_New() *A_arbace_repr_go_lit_rune_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_form_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_go_lit_rune_form_A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_go_lit_rune_form_A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var tmp1 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_lit_A_const_61; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_104); if




	jrt.J2g_Truth(and__1927000168__auto____3) { var root_901 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_lit_A_const_105; var arg_904 any = tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_106); if linked_902 == nil { tmp1 = ifn_903.Invoke_O__O(arg_904) } else { tmp1 = linked_902.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_901, arg_904) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var root_909 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var root_905 any = A_arbace_repr_go_lit_A_const_107.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_repr_go_lit_char_text_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_906 == nil { arg_912 = ifn_907.Invoke_O__O(arg_908) } else { arg_912 = linked_906.(*A_arbace_repr_go_lit_char_text_A).Invoke_O_O__O(root_905, arg_908) }; var arg_913 any = jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(cp__2)).Ref(); if linked_910 == nil { return ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { return linked_910.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) } } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_108.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_lit_A_const_109; var tmp8 any; var root_923 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; if lang.Numbers_IsNeg_J__Z_NoInit(cp__2) { var root_914 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_915 == nil { arg_926 = ifn_916.Invoke_O__O(arg_917) } else { arg_926 = linked_915.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_914, arg_917) } } else { arg_926 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_32, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref()) }; var arg_927 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_924 == nil { tmp8 = ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { tmp8 = linked_924.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } }

func A_arbace_repr_go_lit_bytes_form_A_New() *A_arbace_repr_go_lit_bytes_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Ctor() {}
//line :355:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Invoke_O_O__O(self, bs__0 any) any { var parts__2 any; var root_928 any = A_arbace_repr_go_lit_A_const_110.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_repr_go_lit_utf8_parts_A_fn_class); var ifn_930 lang.IFn; if


	linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = bs__0; if linked_929 == nil { parts__2 = ifn_930.Invoke_O__O(arg_931) } else { parts__2 = linked_929.(*A_arbace_repr_go_lit_utf8_parts_A).Invoke_O_O__O(root_928, arg_931) }; var tmp1 any; var root_932 any =
	A_arbace_repr_go_lit_A_const_111.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var arg_936 any = parts__2; if linked_933 == nil { tmp1 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { tmp1 = linked_933.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_932, arg_935, arg_936) }; if jrt.J2g_Truth(tmp1) { var s__3 any; var root_937 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_939 lang.IFn
		if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var arg_941 any = parts__2; if linked_938 == nil { s__3 = ifn_939.Invoke_O_O__O(arg_940, arg_941) } else { s__3 = linked_938.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_937, arg_940, arg_941) }; var root_946 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_942 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = s__3; if linked_943 == nil { arg_949 = ifn_944.Invoke_O__O(arg_945) } else { arg_949 = linked_943.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_942, arg_945) }; var arg_950 any = s__3; if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else {
			var root_1056 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = A_arbace_repr_go_lit_A_const_108.GetRawRoot__O(); var arg_1060 any = A_arbace_repr_go_lit_A_const_115; var arg_1061 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_New(); var tmp3 *jrt.Class; var fncls__1055 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class
			if fncls__1055 == nil { var fncls__1055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class = fncls__1055d; tmp3 = fncls__1055d } else { tmp3 = fncls__1055 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_1061 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(parts__2)
//line :361:1
			if linked_1057 == nil { return ifn_1058.Invoke_O_O_O__O(arg_1059, arg_1060, arg_1061) } else { return linked_1057.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1056, arg_1059, arg_1060, arg_1061) } } }
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_New() *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A) Invoke_O_O__O(self, s__790000090__1 any) any { var tmp1 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_New_O_O(s__790000090__1, self); var tmp2 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class; if fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class = fncls__1054d; tmp2 = fncls__1054d } else { tmp2 = fncls__1054 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :362:1
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A) Ctor_O_O(c__s__790000090, c__iter__790000089 any) { t.F_s__790000090 = c__s__790000090; t.F_iter__790000089 = c__iter__790000089 }
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A) Invoke_O__O(self any) any { { var s__790000090__1 any; var t_ any = t.F_s__790000090; t.F_s__790000090 = nil; s__790000090__1 = t_; for { var temp__1927000414__auto____2 any; var root_951 any = A_arbace_repr_go_lit_A_const_22.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = s__790000090__1; if linked_952 == nil { temp__1927000414__auto____2 = ifn_953.Invoke_O__O(arg_954) } else { temp__1927000414__auto____2 = linked_952.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_951, arg_954) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__790000090__3 any = temp__1927000414__auto____2; var tmp1 any; var root_955 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = s__790000090__3; if linked_956 == nil { tmp1 = ifn_957.Invoke_O__O(arg_958) } else { tmp1 = linked_956.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_955, arg_958) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_959 any = A_arbace_repr_go_lit_A_const_24.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = s__790000090__3; if linked_960 == nil { c__1927001037__auto____4 = ifn_961.Invoke_O__O(arg_962) } else { c__1927001037__auto____4 = linked_960.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_959, arg_962) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__790000092__6 any; var root_963 any = A_arbace_repr_go_lit_A_const_116.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_964 == nil { b__790000092__6 = ifn_965.Invoke_O__O(arg_966) } else { b__790000092__6 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_963, arg_966) }; var tmp2 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__790000092__6); var tmp3 *jrt.Class; var fncls__995 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class; if fncls__995 == nil { var fncls__995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class = fncls__995d; tmp3 = fncls__995d } else { tmp3 = fncls__995 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1004 any = A_arbace_repr_go_lit_A_const_118.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var root_996 any = A_arbace_repr_go_lit_A_const_119.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = b__790000092__6; if linked_997 == nil { arg_1007 = ifn_998.Invoke_O__O(arg_999) } else { arg_1007 = linked_997.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_996, arg_999) }; var arg_1008 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__790000089); var tmp5 any; var root_1000 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = s__790000090__3; if linked_1001 == nil { tmp5 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp5 = linked_1001.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1000, arg_1003) }; arg_1008 = tmp4.Invoke_O__O(tmp5); if linked_1005 == nil { return ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { return linked_1005.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) } } else { var root_1013 any = A_arbace_repr_go_lit_A_const_118.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var root_1009 any = A_arbace_repr_go_lit_A_const_119.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = b__790000092__6; if linked_1010 == nil { arg_1016 = ifn_1011.Invoke_O__O(arg_1012) } else { arg_1016 = linked_1010.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1009, arg_1012) }; var arg_1017 any; if linked_1014 == nil { return ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { return linked_1014.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) } } } else { var p__4 any; var root_1018 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = s__790000090__3; if linked_1019 == nil { p__4 = ifn_1020.Invoke_O__O(arg_1021) } else { p__4 = linked_1019.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1018, arg_1021) }; var root_1049 any = A_arbace_repr_go_lit_A_const_120.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any; var tmp6 any; var root_1022 any = A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1024 lang.IFn
														if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = p__4; if linked_1023 == nil { tmp6 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp6 = linked_1023.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1022, arg_1025) }; if jrt.J2g_Truth(tmp6) { var root_1030 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var root_1026 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = p__4; if linked_1027 == nil { arg_1033 = ifn_1028.Invoke_O__O(arg_1029) } else { arg_1033 = linked_1027.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1026, arg_1029) }; var arg_1034 any = p__4; if linked_1031 == nil { arg_1052 = ifn_1032.Invoke_O_O__O(arg_1033, arg_1034) } else { arg_1052 = linked_1031.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1030, arg_1033, arg_1034) } } else { var root_1040 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref()); var arg_1044 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref(); if linked_1041 == nil { arg_1052 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { arg_1052 = linked_1041.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) } }
//line :362:1
	var arg_1053 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__790000089); var tmp8 any; var root_1045 any = A_arbace_repr_go_lit_A_const_121.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = s__790000090__3; if linked_1046 == nil { tmp8 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp8 = linked_1046.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1045, arg_1048) }; arg_1053 = tmp7.Invoke_O__O(tmp8); if linked_1050 == nil { return ifn_1051.Invoke_O_O__O(arg_1052, arg_1053) } else { return linked_1050.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1049, arg_1052, arg_1053) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :362:1
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__790000092 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__790000092 = c__b__790000092 }
//line :362:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A) Invoke_O__O(self any) any { { var i__790000091__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__790000091__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__790000091__1)); var root_990 any = A_arbace_repr_go_lit_A_const_117.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = t.F_b__790000092; var arg_994 any; var tmp2 any; var root_967 any = A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_969 lang.IFn
																if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = p__2; if linked_968 == nil { tmp2 = ifn_969.Invoke_O__O(arg_970) } else { tmp2 = linked_968.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_967, arg_970) }; if jrt.J2g_Truth(tmp2) { var root_975 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any; var root_971 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = p__2; if linked_972 == nil { arg_978 = ifn_973.Invoke_O__O(arg_974) } else { arg_978 = linked_972.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_971, arg_974) }; var arg_979 any = p__2; if linked_976 == nil { arg_994 = ifn_977.Invoke_O_O__O(arg_978, arg_979) } else { arg_994 = linked_976.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_975, arg_978, arg_979) } } else { var root_985 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref()); var arg_989 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref(); if linked_986 == nil { arg_994 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { arg_994 = linked_986.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_985, arg_988, arg_989) } }
//line :362:1
	if linked_991 == nil { ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { linked_991.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) }; i__790000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__790000091__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_lit_val_rational_A_New() *A_arbace_repr_go_lit_val_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_val_rational_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_repr_go_lit_val_rational_A) Ctor() {}
//line :367:1
func (t *A_arbace_repr_go_lit_val_rational_A) Invoke_O_O__O(self, v__0 any) any {


	var tmp1 any; var root_1062 any = A_arbace_repr_go_lit_A_const_122.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1064 lang.IFn
	if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = v__0; if linked_1063 == nil { tmp1 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp1 = linked_1063.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1062, arg_1065) }
//line :370:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var and__1927000168__auto____2 any; var root_1066 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1068 lang.IFn

		if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = v__0; if linked_1067 == nil { and__1927000168__auto____2 = ifn_1068.Invoke_O__O(arg_1069) } else { and__1927000168__auto____2 = linked_1067.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1066, arg_1069) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp3 any = A_arbace_repr_go_lit_A_const_124; var tmp4 any; var root_1070 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = v__0; if linked_1071 == nil { tmp4 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp4 = linked_1071.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1070, arg_1073) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____3 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp2 = and__1927000168__auto____2 }
//line :370:1
		if jrt.J2g_Truth(tmp2) {

			var root_1074 any = A_arbace_repr_go_lit_A_const_125.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = v__0; if linked_1075 == nil { return ifn_1076.Invoke_O__O(arg_1077) } else { return linked_1075.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1074, arg_1077) } } else {
//line :370:1
				var tmp5 any; var and__1927000168__auto____2_2 any; var root_1078 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1080 lang.IFn


				if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = v__0; if linked_1079 == nil { and__1927000168__auto____2_2 = ifn_1080.Invoke_O__O(arg_1081) } else { and__1927000168__auto____2_2 = linked_1079.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1078, arg_1081) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp6 any = A_arbace_repr_go_lit_A_const_124; var tmp7 any; var root_1082 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = v__0; if linked_1083 == nil { tmp7 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp7 = linked_1083.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1082, arg_1085) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7)).Ref() } else { tmp5 = and__1927000168__auto____2_2 }
//line :370:1
				if jrt.J2g_Truth(tmp5) { var vec__790000100__2 any = v__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(2), nil); var m__6 any; var root_1086 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_1088 lang.IFn; _ = ___3




					if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = m__4; if linked_1087 == nil { m__6 = ifn_1088.Invoke_O__O(arg_1089) } else { m__6 = linked_1087.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_1086, arg_1089) }
//line :370:1
					var e__7 int64 = lang.RT_LongCast_O__J_NoInit(e__5)






					if lang.Numbers_IsNeg_J__Z_NoInit(e__7) { var root_1094 any = A_arbace_repr_go_lit_A_const_63.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = m__6; var arg_1098 any; var root_1090 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, A_arbace_repr_go_lit_pow2_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__7)).Ref(); if linked_1091 == nil { arg_1098 = ifn_1092.Invoke_O__O(arg_1093) } else { arg_1098 = linked_1091.(*A_arbace_repr_go_lit_pow2_A).Invoke_O_O__O(root_1090, arg_1093) }; if linked_1095 == nil { return ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { return linked_1095.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) } } else { var root_1099 any = A_arbace_repr_go_lit_A_const_63.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = jrt.NN(jrt.BigInteger_Cast(m__6)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__7)).Ref(); var arg_1103 any; jrt.BigInteger_Init(); arg_1103 = jrt.BigInteger_ONE.Ref(); if linked_1100 == nil { return ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { return linked_1100.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) } } } else {
//line :370:1
						if A_arbace_repr_go_lit_A_const_21 != nil { var tmp8 any; var root_1108 any = A_arbace_repr_go_lit_A_const_126.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1110 lang.IFn







							if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_127.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var arg_1112 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_128, v__0)); if linked_1109 == nil { tmp8 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { tmp8 = linked_1109.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }
//line :370:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil
							}
					}
			}
	}
}




func A_arbace_repr_go_lit_untyped_float_form_A_New() *A_arbace_repr_go_lit_untyped_float_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_untyped_float_form_A{}; t.Ctor(); return t }
//line :380:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Ctor() {}
//line :380:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Invoke_O_O__O(self, v__0 any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var root_1113 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = v__0; if linked_1114 == nil { and__1927000168__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { and__1927000168__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp2 any = A_arbace_repr_go_lit_A_const_124; var tmp3 any; var root_1117 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = v__0; if linked_1118 == nil { tmp3 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp3 = linked_1118.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1117, arg_1120) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_108.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_lit_A_const_130; var tmp6 any; var root_1129 any = A_arbace_repr_go_lit_A_const_131.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1130 == nil { tmp6 = ifn_1131.Invoke_O__O(arg_1132) } else { tmp6 = linked_1130.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1129, arg_1132) }; var tmp7 any = tmp6; var tmp8 any; var root_1133 any = A_arbace_repr_go_lit_A_const_131.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1134 == nil { tmp8 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp8 = linked_1134.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1133, arg_1136) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp7, tmp8) } else {
			var root_1125 any = A_arbace_repr_go_lit_A_const_58.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var root_1121 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = v__0; if linked_1122 == nil { arg_1128 = ifn_1123.Invoke_O__O(arg_1124) } else { arg_1128 = linked_1122.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1121, arg_1124) }; if linked_1126 == nil { return ifn_1127.Invoke_O__O(arg_1128) } else { return linked_1126.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O__O(root_1125, arg_1128)
			} } }
func A_arbace_repr_go_lit_const_form_A_New() *A_arbace_repr_go_lit_const_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_const_form_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_repr_go_lit_const_form_A) Ctor() {}
//line :389:1
func (t *A_arbace_repr_go_lit_const_form_A) Invoke_O_O_O__O(self, v__0, k__1 any) any { var k__3 any; var or__1927000174__auto____3 any = k__1; if




	jrt.J2g_Truth(or__1927000174__auto____3) { k__3 = or__1927000174__auto____3 } else {
		var tmp1 any; var root_1137 any = A_arbace_repr_go_lit_A_const_132.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_1139 lang.IFn
		if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = v__0; if linked_1138 == nil { tmp1 = ifn_1139.Invoke_O__O(arg_1140) } else { tmp1 = linked_1138.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_1137, arg_1140) }
//line :395:1
		if jrt.J2g_Truth(tmp1) { k__3 = A_arbace_repr_go_lit_A_const_133 } else { var tmp2 any; var root_1141 any = A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1143 lang.IFn

			if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = v__0; if linked_1142 == nil { tmp2 = ifn_1143.Invoke_O__O(arg_1144) } else { tmp2 = linked_1142.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1141, arg_1144) }
//line :395:1
			if jrt.J2g_Truth(tmp2) { k__3 = A_arbace_repr_go_lit_A_const_134 } else { var tmp3 any; var and__1927000168__auto____4 any; var root_1145 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1147 lang.IFn


				if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = v__0; if linked_1146 == nil { and__1927000168__auto____4 = ifn_1147.Invoke_O__O(arg_1148) } else { and__1927000168__auto____4 = linked_1146.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1145, arg_1148) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp4 any = A_arbace_repr_go_lit_A_const_135; var tmp5 any; var root_1149 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = v__0; if linked_1150 == nil { tmp5 = ifn_1151.Invoke_O__O(arg_1152) } else { tmp5 = linked_1150.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1149, arg_1152) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else { tmp3 = and__1927000168__auto____4 }
//line :395:1
				if jrt.J2g_Truth(tmp3) { k__3 = A_arbace_repr_go_lit_A_const_134 } else { var tmp6 any; var root_1153 any = A_arbace_repr_go_lit_A_const_122.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1155 lang.IFn



					if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = v__0; if linked_1154 == nil { tmp6 = ifn_1155.Invoke_O__O(arg_1156) } else { tmp6 = linked_1154.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1153, arg_1156) }
//line :395:1
					if jrt.J2g_Truth(tmp6) { k__3 = A_arbace_repr_go_lit_A_const_136 } else { var tmp7 any; var and__1927000168__auto____4_2 any; var root_1157 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1159 lang.IFn




						if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = v__0; if linked_1158 == nil { and__1927000168__auto____4_2 = ifn_1159.Invoke_O__O(arg_1160) } else { and__1927000168__auto____4_2 = linked_1158.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp8 any = A_arbace_repr_go_lit_A_const_124; var tmp9 any; var root_1161 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = v__0; if linked_1162 == nil { tmp9 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp9 = linked_1162.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1161, arg_1164) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9)).Ref() } else { tmp7 = and__1927000168__auto____4_2 }
//line :395:1
						if jrt.J2g_Truth(tmp7) { k__3 = A_arbace_repr_go_lit_A_const_124 } else { var tmp10 any; var and__1927000168__auto____4_3 any; var root_1165 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1167 lang.IFn





							if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = v__0; if linked_1166 == nil { and__1927000168__auto____4_3 = ifn_1167.Invoke_O__O(arg_1168) } else { and__1927000168__auto____4_3 = linked_1166.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(and__1927000168__auto____4_3) { var tmp11 any = A_arbace_repr_go_lit_A_const_137; var tmp12 any; var root_1169 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = v__0; if linked_1170 == nil { tmp12 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp12 = linked_1170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1169, arg_1172) }; tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp11, tmp12)).Ref() } else { tmp10 = and__1927000168__auto____4_3 }
//line :395:1
							if jrt.J2g_Truth(tmp10) { k__3 = A_arbace_repr_go_lit_A_const_137 } else { k__3 = nil } } } } } } }; var G__790000105__4_ any = k__3; switch






	lang.Util_Hash_O__I_NoInit(G__790000105__4_) >> 7 & 15 { case 0: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_138) {










		var root_1174 any = A_arbace_repr_go_lit_A_const_139.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, A_arbace_repr_go_lit_untyped_float_form_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = v__0; if linked_1175 == nil { return ifn_1176.Invoke_O__O(arg_1177) } else { return linked_1175.(*A_arbace_repr_go_lit_untyped_float_form_A).Invoke_O_O__O(root_1174, arg_1177) } }
//line :402:1
	case 3: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_133) {
		var root_1182 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any; var root_1178 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = v__0; if linked_1179 == nil { arg_1185 = ifn_1180.Invoke_O__O(arg_1181) } else { arg_1185 = linked_1179.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1178, arg_1181) }; var arg_1186 any = v__0; if linked_1183 == nil { return ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { return linked_1183.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) } }
//line :402:1
	case 4: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_140) { var vec__790000106__5 any; var tmp13 any; var and__1927000168__auto____5 any; var root_1187 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1189 lang.IFn












		if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = v__0; if linked_1188 == nil { and__1927000168__auto____5 = ifn_1189.Invoke_O__O(arg_1190) } else { and__1927000168__auto____5 = linked_1188.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1187, arg_1190) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp14 any = A_arbace_repr_go_lit_A_const_137; var tmp15 any; var root_1191 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = v__0; if linked_1192 == nil { tmp15 = ifn_1193.Invoke_O__O(arg_1194) } else { tmp15 = linked_1192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1191, arg_1194) }; tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, tmp15)).Ref() } else { tmp13 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp13) { vec__790000106__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000106__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_61) }
//line :402:1
		var re__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000106__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000106__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000109__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_137) { var tmp16 any; var root_1203 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = re__6; if linked_1204 == nil { tmp16 = ifn_1205.Invoke_O__O(arg_1206) } else { tmp16 = linked_1204.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1203, arg_1206) }; var tmp17 any = tmp16; var tmp18 any; var root_1207 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = im__7; if linked_1208 == nil { tmp18 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp18 = linked_1208.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1207, arg_1210) }; vec__790000109__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18) } else { vec__790000109__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6, im__7) }
//line :402:1
		var re__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000109__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000109__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_137) { f__11 = A_arbace_repr_go_lit_A_const_141.GetRawRoot__O() } else { f__11 = A_arbace_repr_go_lit_A_const_139.GetRawRoot__O() }
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_108.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_lit_A_const_144; return tmp19.Invoke_O_O_O__O(tmp20, lang.IFn_Cast(f__11).Invoke_O__O(re__9), lang.IFn_Cast(f__11).Invoke_O__O(im__10)) }
//line :402:1
	case 5: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_142) {








		var root_1199 any = A_arbace_repr_go_lit_A_const_143.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_repr_go_lit_rune_form_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any; var root_1195 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = v__0; if linked_1196 == nil { arg_1202 = ifn_1197.Invoke_O__O(arg_1198) } else { arg_1202 = linked_1196.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1195, arg_1198) }; if linked_1200 == nil { return ifn_1201.Invoke_O__O(arg_1202) } else { return linked_1200.(*A_arbace_repr_go_lit_rune_form_A).Invoke_O_O__O(root_1199, arg_1202) } }
//line :402:1
	case 8: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_137) { var vec__790000112__5 any; var tmp21 any; var and__1927000168__auto____5_2 any; var root_1211 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1213 lang.IFn












		if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = v__0; if linked_1212 == nil { and__1927000168__auto____5_2 = ifn_1213.Invoke_O__O(arg_1214) } else { and__1927000168__auto____5_2 = linked_1212.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1211, arg_1214) }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { var tmp22 any = A_arbace_repr_go_lit_A_const_137; var tmp23 any; var root_1215 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = v__0; if linked_1216 == nil { tmp23 = ifn_1217.Invoke_O__O(arg_1218) } else { tmp23 = linked_1216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1215, arg_1218) }; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23)).Ref() } else { tmp21 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp21) { vec__790000112__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000112__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_61) }
//line :402:1
		var re__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000112__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000112__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000115__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_137) { var tmp24 any; var root_1227 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = re__6_2; if linked_1228 == nil { tmp24 = ifn_1229.Invoke_O__O(arg_1230) } else { tmp24 = linked_1228.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1227, arg_1230) }; var tmp25 any = tmp24; var tmp26 any; var root_1231 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = im__7_2; if linked_1232 == nil { tmp26 = ifn_1233.Invoke_O__O(arg_1234) } else { tmp26 = linked_1232.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1231, arg_1234) }; vec__790000115__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp25, tmp26) } else { vec__790000115__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6_2, im__7_2) }
//line :402:1
		var re__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000115__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000115__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11_2 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_137) { f__11_2 = A_arbace_repr_go_lit_A_const_141.GetRawRoot__O() } else { f__11_2 = A_arbace_repr_go_lit_A_const_139.GetRawRoot__O() }
		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_108.GetRawRoot__O()); var tmp28 any = A_arbace_repr_go_lit_A_const_144; return tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(f__11_2).Invoke_O__O(re__9_2), lang.IFn_Cast(f__11_2).Invoke_O__O(im__10_2)) }
//line :402:1
	case 9: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_124) {









		var root_1223 any = A_arbace_repr_go_lit_A_const_141.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, A_arbace_repr_go_lit_double_lit_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any; var root_1219 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = v__0; if linked_1220 == nil { arg_1226 = ifn_1221.Invoke_O__O(arg_1222) } else { arg_1226 = linked_1220.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1219, arg_1222) }; if linked_1224 == nil { return ifn_1225.Invoke_O__O(arg_1226) } else { return linked_1224.(*A_arbace_repr_go_lit_double_lit_A).Invoke_O_O__O(root_1223, arg_1226) } }
//line :402:1
	case 12: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_136) { var r__5 any; var root_1235 any = A_arbace_repr_go_lit_A_const_129.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1237 lang.IFn




		if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = v__0; if linked_1236 == nil { r__5 = ifn_1237.Invoke_O__O(arg_1238) } else { r__5 = linked_1236.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1235, arg_1238) }
		var tmp29 any; var root_1239 any = A_arbace_repr_go_lit_A_const_122.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any = r__5; if linked_1240 == nil { tmp29 = ifn_1241.Invoke_O__O(arg_1242) } else { tmp29 = linked_1240.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1239, arg_1242) }; if jrt.J2g_Truth(tmp29) {
			var root_1243 any = A_arbace_repr_go_lit_A_const_131.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = r__5; if linked_1244 == nil { return ifn_1245.Invoke_O__O(arg_1246) } else { return linked_1244.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1243, arg_1246) } } else {
//line :408:1
				var tmp30 any; var root_1251 any = A_arbace_repr_go_lit_A_const_126.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1253 lang.IFn

				if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_127.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var arg_1255 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_128, v__0)); if linked_1252 == nil { tmp30 = ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { tmp30 = linked_1252.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) }
//line :408:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp30))) } }
//line :402:1
	case 15: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_134) {

		var tmp31 any; var root_1256 any = A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = v__0; if linked_1257 == nil { tmp31 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp31 = linked_1257.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(tmp31) {
			var root_1264 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any; var root_1260 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = v__0; if linked_1261 == nil { arg_1267 = ifn_1262.Invoke_O__O(arg_1263) } else { arg_1267 = linked_1261.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1260, arg_1263) }; var arg_1268 any = v__0; if linked_1265 == nil { return ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { return linked_1265.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) } } else {
				var root_1278 any = A_arbace_repr_go_lit_A_const_145.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, A_arbace_repr_go_lit_bytes_form_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any; var tmp32 any; var root_1273 any = A_arbace_repr_go_lit_A_const_146.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = A_arbace_repr_go_lit_A_const_147.GetRawRoot__O(); var arg_1277 any; var root_1269 any = A_arbace_repr_go_lit_A_const_125.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = v__0; if linked_1270 == nil { arg_1277 = ifn_1271.Invoke_O__O(arg_1272) } else { arg_1277 = linked_1270.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1269, arg_1272) }; if linked_1274 == nil { tmp32 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { tmp32 = linked_1274.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; arg_1281 = lang.Numbers_Byte_array_O__B1_NoInit(tmp32).Ref(); if linked_1279 == nil { return ifn_1280.Invoke_O__O(arg_1281) } else { return linked_1279.(*A_arbace_repr_go_lit_bytes_form_A).Invoke_O_O__O(root_1278, arg_1281) } } }
//line :402:1
	default:}; return nil }
//line :400:1
type A_arbace_repr_go_lit_A struct{ jrt.Object }

var A_arbace_repr_go_lit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit_A_const_0 *lang.Var

var A_arbace_repr_go_lit_A_const_1 any

var A_arbace_repr_go_lit_A_const_2 *lang.Var

var A_arbace_repr_go_lit_A_const_3 any

var A_arbace_repr_go_lit_A_const_4 *lang.Var

var A_arbace_repr_go_lit_A_const_5 *lang.Var

var A_arbace_repr_go_lit_A_const_6 *lang.Var

var A_arbace_repr_go_lit_A_const_7 *lang.Var

var A_arbace_repr_go_lit_A_const_8 any

var A_arbace_repr_go_lit_A_const_9 *lang.Var

var A_arbace_repr_go_lit_A_const_10 *lang.Var

var A_arbace_repr_go_lit_A_const_11 *lang.Var

var A_arbace_repr_go_lit_A_const_12 *lang.Var

var A_arbace_repr_go_lit_A_const_13 any

var A_arbace_repr_go_lit_A_const_14 any

var A_arbace_repr_go_lit_A_const_15 any

var A_arbace_repr_go_lit_A_const_16 any

var A_arbace_repr_go_lit_A_const_17 *lang.Var

var A_arbace_repr_go_lit_A_const_18 *lang.Var

var A_arbace_repr_go_lit_A_const_19 *lang.Var

var A_arbace_repr_go_lit_A_const_20 *lang.Var

var A_arbace_repr_go_lit_A_const_21 *lang.Keyword

var A_arbace_repr_go_lit_A_const_22 *lang.Var

var A_arbace_repr_go_lit_A_const_23 *lang.Var

var A_arbace_repr_go_lit_A_const_24 *lang.Var

var A_arbace_repr_go_lit_A_const_25 *lang.Var

var A_arbace_repr_go_lit_A_const_26 *lang.Var

var A_arbace_repr_go_lit_A_const_27 *lang.Var

var A_arbace_repr_go_lit_A_const_28 *lang.Var

var A_arbace_repr_go_lit_A_const_29 *lang.Var

var A_arbace_repr_go_lit_A_const_30 *lang.Var

var A_arbace_repr_go_lit_A_const_31 *lang.Var

var A_arbace_repr_go_lit_A_const_32 *lang.Var

var A_arbace_repr_go_lit_A_const_33 *lang.Var

var A_arbace_repr_go_lit_A_const_34 *lang.Var

var A_arbace_repr_go_lit_A_const_35 any

var A_arbace_repr_go_lit_A_const_36 *lang.Var

var A_arbace_repr_go_lit_A_const_37 any

var A_arbace_repr_go_lit_A_const_38 any

var A_arbace_repr_go_lit_A_const_39 any

var A_arbace_repr_go_lit_A_const_40 any

var A_arbace_repr_go_lit_A_const_41 *lang.Var

var A_arbace_repr_go_lit_A_const_42 any

var A_arbace_repr_go_lit_A_const_43 *lang.Var

var A_arbace_repr_go_lit_A_const_44 *lang.Var

var A_arbace_repr_go_lit_A_const_45 *lang.Var

var A_arbace_repr_go_lit_A_const_46 *lang.Var

var A_arbace_repr_go_lit_A_const_47 *lang.Var

var A_arbace_repr_go_lit_A_const_48 *lang.Var

var A_arbace_repr_go_lit_A_const_49 *lang.Var

var A_arbace_repr_go_lit_A_const_50 *lang.Var

var A_arbace_repr_go_lit_A_const_51 *lang.Keyword

var A_arbace_repr_go_lit_A_const_52 *lang.Var

var A_arbace_repr_go_lit_A_const_53 *lang.Var

var A_arbace_repr_go_lit_A_const_54 *jrt.Class

var A_arbace_repr_go_lit_A_const_55 *lang.Var

var A_arbace_repr_go_lit_A_const_56 *lang.Var

var A_arbace_repr_go_lit_A_const_57 *lang.Var

var A_arbace_repr_go_lit_A_const_58 *lang.Var

var A_arbace_repr_go_lit_A_const_59 *lang.Var

var A_arbace_repr_go_lit_A_const_60 *lang.Var

var A_arbace_repr_go_lit_A_const_61 any

var A_arbace_repr_go_lit_A_const_62 *lang.Var

var A_arbace_repr_go_lit_A_const_63 *lang.Var

var A_arbace_repr_go_lit_A_const_64 *lang.Var

var A_arbace_repr_go_lit_A_const_65 *lang.Var

var A_arbace_repr_go_lit_A_const_66 *lang.Var

var A_arbace_repr_go_lit_A_const_67 *lang.Var

var A_arbace_repr_go_lit_A_const_68 any

var A_arbace_repr_go_lit_A_const_69 any

var A_arbace_repr_go_lit_A_const_70 *lang.Var

var A_arbace_repr_go_lit_A_const_71 *lang.Var

var A_arbace_repr_go_lit_A_const_72 *lang.Var

var A_arbace_repr_go_lit_A_const_73 any

var A_arbace_repr_go_lit_A_const_74 any

var A_arbace_repr_go_lit_A_const_75 any

var A_arbace_repr_go_lit_A_const_76 any

var A_arbace_repr_go_lit_A_const_77 *lang.Var

var A_arbace_repr_go_lit_A_const_78 any

var A_arbace_repr_go_lit_A_const_79 any

var A_arbace_repr_go_lit_A_const_80 any

var A_arbace_repr_go_lit_A_const_81 any

var A_arbace_repr_go_lit_A_const_82 any

var A_arbace_repr_go_lit_A_const_83 any

var A_arbace_repr_go_lit_A_const_84 any

var A_arbace_repr_go_lit_A_const_85 any

var A_arbace_repr_go_lit_A_const_86 any

var A_arbace_repr_go_lit_A_const_87 *lang.Var

var A_arbace_repr_go_lit_A_const_88 any

var A_arbace_repr_go_lit_A_const_89 any

var A_arbace_repr_go_lit_A_const_90 any

var A_arbace_repr_go_lit_A_const_91 any

var A_arbace_repr_go_lit_A_const_92 any

var A_arbace_repr_go_lit_A_const_93 any

var A_arbace_repr_go_lit_A_const_94 any

var A_arbace_repr_go_lit_A_const_95 any

var A_arbace_repr_go_lit_A_const_96 any

var A_arbace_repr_go_lit_A_const_97 any

var A_arbace_repr_go_lit_A_const_98 any

var A_arbace_repr_go_lit_A_const_99 any

var A_arbace_repr_go_lit_A_const_100 any

var A_arbace_repr_go_lit_A_const_101 any

var A_arbace_repr_go_lit_A_const_102 any

var A_arbace_repr_go_lit_A_const_103 *lang.Var

var A_arbace_repr_go_lit_A_const_104 any

var A_arbace_repr_go_lit_A_const_105 any

var A_arbace_repr_go_lit_A_const_106 any

var A_arbace_repr_go_lit_A_const_107 *lang.Var

var A_arbace_repr_go_lit_A_const_108 *lang.Var

var A_arbace_repr_go_lit_A_const_109 any

var A_arbace_repr_go_lit_A_const_110 *lang.Var

var A_arbace_repr_go_lit_A_const_111 *lang.Var

var A_arbace_repr_go_lit_A_const_112 *lang.Var

var A_arbace_repr_go_lit_A_const_113 *lang.Var

var A_arbace_repr_go_lit_A_const_114 *lang.Var

var A_arbace_repr_go_lit_A_const_115 any

var A_arbace_repr_go_lit_A_const_116 *lang.Var

var A_arbace_repr_go_lit_A_const_117 *lang.Var

var A_arbace_repr_go_lit_A_const_118 *lang.Var

var A_arbace_repr_go_lit_A_const_119 *lang.Var

var A_arbace_repr_go_lit_A_const_120 *lang.Var

var A_arbace_repr_go_lit_A_const_121 *lang.Var

var A_arbace_repr_go_lit_A_const_122 *lang.Var

var A_arbace_repr_go_lit_A_const_123 *lang.Var

var A_arbace_repr_go_lit_A_const_124 *lang.Keyword

var A_arbace_repr_go_lit_A_const_125 *lang.Var

var A_arbace_repr_go_lit_A_const_126 *lang.Var

var A_arbace_repr_go_lit_A_const_127 *lang.Var

var A_arbace_repr_go_lit_A_const_128 *lang.Keyword

var A_arbace_repr_go_lit_A_const_129 *lang.Var

var A_arbace_repr_go_lit_A_const_130 any

var A_arbace_repr_go_lit_A_const_131 *lang.Var

var A_arbace_repr_go_lit_A_const_132 *lang.Var

var A_arbace_repr_go_lit_A_const_133 *lang.Keyword

var A_arbace_repr_go_lit_A_const_134 *lang.Keyword

var A_arbace_repr_go_lit_A_const_135 *lang.Keyword

var A_arbace_repr_go_lit_A_const_136 *lang.Keyword

var A_arbace_repr_go_lit_A_const_137 *lang.Keyword

var A_arbace_repr_go_lit_A_const_138 *lang.Keyword

var A_arbace_repr_go_lit_A_const_139 *lang.Var

var A_arbace_repr_go_lit_A_const_140 *lang.Keyword

var A_arbace_repr_go_lit_A_const_141 *lang.Var

var A_arbace_repr_go_lit_A_const_142 *lang.Keyword

var A_arbace_repr_go_lit_A_const_143 *lang.Var

var A_arbace_repr_go_lit_A_const_144 any

var A_arbace_repr_go_lit_A_const_145 *lang.Var

var A_arbace_repr_go_lit_A_const_146 *lang.Var

var A_arbace_repr_go_lit_A_const_147 *lang.Var

var A_arbace_repr_go_lit_A_init jrt.ClassInit

func A_arbace_repr_go_lit_A_Init() { if !A_arbace_repr_go_lit_A_init.Done() { A_arbace_repr_go_lit_A_init.Run(A_arbace_repr_go_lit_A_clinit) } }

func A_arbace_repr_go_lit_A_clinit() { A_arbace_repr_go_lit_A_clinit_p0(); A_arbace_repr_go_lit_A_clinit_p1(); A_arbace_repr_go_lit_A_clinit_p2(); A_arbace_repr_go_lit_A_clinit_p3(); A_arbace_repr_go_lit_A_clinit_p4(); A_arbace_repr_go_lit_A_clinit_p5(); A_arbace_repr_go_lit_A_clinit_p6(); A_arbace_repr_go_lit_A_clinit_p7(); A_arbace_repr_go_lit_A_clinit_p8(); A_arbace_repr_go_lit_A_clinit_p9(); A_arbace_repr_go_lit_A_clinit_p10(); A_arbace_repr_go_lit_A_clinit_p11() }

func A_arbace_repr_go_lit_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_lit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 169); A_arbace_repr_go_lit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[21]); A_arbace_repr_go_lit_A_const_1 = A_arbace_repr_go_lit_A_const_pool.A[22]; A_arbace_repr_go_lit_A_const_2 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[23]); A_arbace_repr_go_lit_A_const_3 = A_arbace_repr_go_lit_A_const_pool.A[24]; A_arbace_repr_go_lit_A_const_4 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[25]); A_arbace_repr_go_lit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[26]); A_arbace_repr_go_lit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[27]); A_arbace_repr_go_lit_A_const_7 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[28]); A_arbace_repr_go_lit_A_const_8 = A_arbace_repr_go_lit_A_const_pool.A[29]; A_arbace_repr_go_lit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[30]); A_arbace_repr_go_lit_A_const_10 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[31]); A_arbace_repr_go_lit_A_const_11 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[32]) }

func A_arbace_repr_go_lit_A_clinit_p1() { A_arbace_repr_go_lit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[33]); A_arbace_repr_go_lit_A_const_13 = A_arbace_repr_go_lit_A_const_pool.A[34]; A_arbace_repr_go_lit_A_const_14 = A_arbace_repr_go_lit_A_const_pool.A[35]; A_arbace_repr_go_lit_A_const_15 = A_arbace_repr_go_lit_A_const_pool.A[36]; A_arbace_repr_go_lit_A_const_16 = A_arbace_repr_go_lit_A_const_pool.A[37]; A_arbace_repr_go_lit_A_const_17 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[38]); A_arbace_repr_go_lit_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[39]); A_arbace_repr_go_lit_A_const_19 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[40]); A_arbace_repr_go_lit_A_const_20 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[41]); A_arbace_repr_go_lit_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[42]); A_arbace_repr_go_lit_A_const_22 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[43]); A_arbace_repr_go_lit_A_const_23 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[44]); A_arbace_repr_go_lit_A_const_24 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[45]) }

func A_arbace_repr_go_lit_A_clinit_p2() { A_arbace_repr_go_lit_A_const_25 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[46]); A_arbace_repr_go_lit_A_const_26 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[47]); A_arbace_repr_go_lit_A_const_27 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[48]); A_arbace_repr_go_lit_A_const_28 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[49]); A_arbace_repr_go_lit_A_const_29 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[50]); A_arbace_repr_go_lit_A_const_30 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[51]); A_arbace_repr_go_lit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[52]); A_arbace_repr_go_lit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[53]); A_arbace_repr_go_lit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[54]); A_arbace_repr_go_lit_A_const_34 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[55]); A_arbace_repr_go_lit_A_const_35 = A_arbace_repr_go_lit_A_const_pool.A[56]; A_arbace_repr_go_lit_A_const_36 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[57]) }

func A_arbace_repr_go_lit_A_clinit_p3() { A_arbace_repr_go_lit_A_const_37 = A_arbace_repr_go_lit_A_const_pool.A[58]; A_arbace_repr_go_lit_A_const_38 = A_arbace_repr_go_lit_A_const_pool.A[59]; A_arbace_repr_go_lit_A_const_39 = A_arbace_repr_go_lit_A_const_pool.A[60]; A_arbace_repr_go_lit_A_const_40 = A_arbace_repr_go_lit_A_const_pool.A[61]; A_arbace_repr_go_lit_A_const_41 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[62]); A_arbace_repr_go_lit_A_const_42 = A_arbace_repr_go_lit_A_const_pool.A[63]; A_arbace_repr_go_lit_A_const_43 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[64]); A_arbace_repr_go_lit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[65]); A_arbace_repr_go_lit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[66]); A_arbace_repr_go_lit_A_const_46 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[67]); A_arbace_repr_go_lit_A_const_47 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[68]); A_arbace_repr_go_lit_A_const_48 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[69]); A_arbace_repr_go_lit_A_const_49 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[70]) }

func A_arbace_repr_go_lit_A_clinit_p4() { A_arbace_repr_go_lit_A_const_50 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[71]); A_arbace_repr_go_lit_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[72]); A_arbace_repr_go_lit_A_const_52 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[73]); A_arbace_repr_go_lit_A_const_53 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[74]); A_arbace_repr_go_lit_A_const_54 = jrt.Class_Cast(A_arbace_repr_go_lit_A_const_pool.A[75]); A_arbace_repr_go_lit_A_const_55 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[76]); A_arbace_repr_go_lit_A_const_56 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[77]); A_arbace_repr_go_lit_A_const_57 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[78]); A_arbace_repr_go_lit_A_const_58 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[79]); A_arbace_repr_go_lit_A_const_59 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[80]); A_arbace_repr_go_lit_A_const_60 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[81]); A_arbace_repr_go_lit_A_const_61 = A_arbace_repr_go_lit_A_const_pool.A[82] }

func A_arbace_repr_go_lit_A_clinit_p5() { A_arbace_repr_go_lit_A_const_62 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[83]); A_arbace_repr_go_lit_A_const_63 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[84]); A_arbace_repr_go_lit_A_const_64 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[85]); A_arbace_repr_go_lit_A_const_65 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[86]); A_arbace_repr_go_lit_A_const_66 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[87]); A_arbace_repr_go_lit_A_const_67 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[88]); A_arbace_repr_go_lit_A_const_68 = A_arbace_repr_go_lit_A_const_pool.A[89]; A_arbace_repr_go_lit_A_const_69 = A_arbace_repr_go_lit_A_const_pool.A[90]; A_arbace_repr_go_lit_A_const_70 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[91]); A_arbace_repr_go_lit_A_const_71 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[92]); A_arbace_repr_go_lit_A_const_72 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[93]); A_arbace_repr_go_lit_A_const_73 = A_arbace_repr_go_lit_A_const_pool.A[94]; A_arbace_repr_go_lit_A_const_74 = A_arbace_repr_go_lit_A_const_pool.A[95] }

func A_arbace_repr_go_lit_A_clinit_p6() { A_arbace_repr_go_lit_A_const_75 = A_arbace_repr_go_lit_A_const_pool.A[96]; A_arbace_repr_go_lit_A_const_76 = A_arbace_repr_go_lit_A_const_pool.A[97]; A_arbace_repr_go_lit_A_const_77 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[98]); A_arbace_repr_go_lit_A_const_78 = A_arbace_repr_go_lit_A_const_pool.A[99]; A_arbace_repr_go_lit_A_const_79 = A_arbace_repr_go_lit_A_const_pool.A[100]; A_arbace_repr_go_lit_A_const_80 = A_arbace_repr_go_lit_A_const_pool.A[101]; A_arbace_repr_go_lit_A_const_81 = A_arbace_repr_go_lit_A_const_pool.A[102]; A_arbace_repr_go_lit_A_const_82 = A_arbace_repr_go_lit_A_const_pool.A[103]; A_arbace_repr_go_lit_A_const_83 = A_arbace_repr_go_lit_A_const_pool.A[104]; A_arbace_repr_go_lit_A_const_84 = A_arbace_repr_go_lit_A_const_pool.A[105]; A_arbace_repr_go_lit_A_const_85 = A_arbace_repr_go_lit_A_const_pool.A[106]; A_arbace_repr_go_lit_A_const_86 = A_arbace_repr_go_lit_A_const_pool.A[107]; A_arbace_repr_go_lit_A_const_87 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[108]); A_arbace_repr_go_lit_A_const_88 = A_arbace_repr_go_lit_A_const_pool.A[109]; A_arbace_repr_go_lit_A_const_89 = A_arbace_repr_go_lit_A_const_pool.A[110] }

func A_arbace_repr_go_lit_A_clinit_p7() { A_arbace_repr_go_lit_A_const_90 = A_arbace_repr_go_lit_A_const_pool.A[111]; A_arbace_repr_go_lit_A_const_91 = A_arbace_repr_go_lit_A_const_pool.A[112]; A_arbace_repr_go_lit_A_const_92 = A_arbace_repr_go_lit_A_const_pool.A[113]; A_arbace_repr_go_lit_A_const_93 = A_arbace_repr_go_lit_A_const_pool.A[114]; A_arbace_repr_go_lit_A_const_94 = A_arbace_repr_go_lit_A_const_pool.A[115]; A_arbace_repr_go_lit_A_const_95 = A_arbace_repr_go_lit_A_const_pool.A[116]; A_arbace_repr_go_lit_A_const_96 = A_arbace_repr_go_lit_A_const_pool.A[117]; A_arbace_repr_go_lit_A_const_97 = A_arbace_repr_go_lit_A_const_pool.A[118]; A_arbace_repr_go_lit_A_const_98 = A_arbace_repr_go_lit_A_const_pool.A[119]; A_arbace_repr_go_lit_A_const_99 = A_arbace_repr_go_lit_A_const_pool.A[120]; A_arbace_repr_go_lit_A_const_100 = A_arbace_repr_go_lit_A_const_pool.A[121]; A_arbace_repr_go_lit_A_const_101 = A_arbace_repr_go_lit_A_const_pool.A[122]; A_arbace_repr_go_lit_A_const_102 = A_arbace_repr_go_lit_A_const_pool.A[123]; A_arbace_repr_go_lit_A_const_103 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[124]); A_arbace_repr_go_lit_A_const_104 = A_arbace_repr_go_lit_A_const_pool.A[125] }

func A_arbace_repr_go_lit_A_clinit_p8() { A_arbace_repr_go_lit_A_const_105 = A_arbace_repr_go_lit_A_const_pool.A[126]; A_arbace_repr_go_lit_A_const_106 = A_arbace_repr_go_lit_A_const_pool.A[127]; A_arbace_repr_go_lit_A_const_107 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[128]); A_arbace_repr_go_lit_A_const_108 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[129]); A_arbace_repr_go_lit_A_const_109 = A_arbace_repr_go_lit_A_const_pool.A[130]; A_arbace_repr_go_lit_A_const_110 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[131]); A_arbace_repr_go_lit_A_const_111 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[132]); A_arbace_repr_go_lit_A_const_112 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[133]); A_arbace_repr_go_lit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[134]); A_arbace_repr_go_lit_A_const_114 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[135]); A_arbace_repr_go_lit_A_const_115 = A_arbace_repr_go_lit_A_const_pool.A[136]; A_arbace_repr_go_lit_A_const_116 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[137]); A_arbace_repr_go_lit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[138]) }

func A_arbace_repr_go_lit_A_clinit_p9() { A_arbace_repr_go_lit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[139]); A_arbace_repr_go_lit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[140]); A_arbace_repr_go_lit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[141]); A_arbace_repr_go_lit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[142]); A_arbace_repr_go_lit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[143]); A_arbace_repr_go_lit_A_const_123 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[144]); A_arbace_repr_go_lit_A_const_124 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[145]); A_arbace_repr_go_lit_A_const_125 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[146]); A_arbace_repr_go_lit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[147]); A_arbace_repr_go_lit_A_const_127 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[148]); A_arbace_repr_go_lit_A_const_128 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[149]); A_arbace_repr_go_lit_A_const_129 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[150]) }

func A_arbace_repr_go_lit_A_clinit_p10() { A_arbace_repr_go_lit_A_const_130 = A_arbace_repr_go_lit_A_const_pool.A[151]; A_arbace_repr_go_lit_A_const_131 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[152]); A_arbace_repr_go_lit_A_const_132 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[153]); A_arbace_repr_go_lit_A_const_133 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[154]); A_arbace_repr_go_lit_A_const_134 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[155]); A_arbace_repr_go_lit_A_const_135 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[156]); A_arbace_repr_go_lit_A_const_136 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[157]); A_arbace_repr_go_lit_A_const_137 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[158]); A_arbace_repr_go_lit_A_const_138 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[159]); A_arbace_repr_go_lit_A_const_139 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[160]); A_arbace_repr_go_lit_A_const_140 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[161]); A_arbace_repr_go_lit_A_const_141 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[162]) }

func A_arbace_repr_go_lit_A_clinit_p11() { A_arbace_repr_go_lit_A_const_142 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[163]); A_arbace_repr_go_lit_A_const_143 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[164]); A_arbace_repr_go_lit_A_const_144 = A_arbace_repr_go_lit_A_const_pool.A[165]; A_arbace_repr_go_lit_A_const_145 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[166]); A_arbace_repr_go_lit_A_const_146 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[167]); A_arbace_repr_go_lit_A_const_147 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[168]) }

func A_arbace_repr_go_lit_A_New() *A_arbace_repr_go_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_A) Ctor() {}

func (t *A_arbace_repr_go_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_A_class }

func (t *A_arbace_repr_go_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_A); return ok }

func A_arbace_repr_go_lit_A_Cast(x any) *A_arbace_repr_go_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_A_class)) }; return v }



type A_arbace_repr_go_lit_bytes_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A struct{ j2g_header uint64; F_s__790000090, F_iter__790000089 any }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__790000092 any }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_char_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_char_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_const_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_const_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decimal_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decimal_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decode_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_b__790000074_A struct{ j2g_header uint64; F_bs any }

var A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A struct{ j2g_header uint64; F_n, F_b any }

var A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_exact_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_exact_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000004_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000004_A_New() *A_arbace_repr_go_lit_eval790000004_A { t := &A_arbace_repr_go_lit_eval790000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000004_A_class }

func (t *A_arbace_repr_go_lit_eval790000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); return ok }

func A_arbace_repr_go_lit_eval790000004_A_Cast(x any) *A_arbace_repr_go_lit_eval790000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000004_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000008_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000008_A_New() *A_arbace_repr_go_lit_eval790000008_A { t := &A_arbace_repr_go_lit_eval790000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000008_A_class }

func (t *A_arbace_repr_go_lit_eval790000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); return ok }

func A_arbace_repr_go_lit_eval790000008_A_Cast(x any) *A_arbace_repr_go_lit_eval790000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000008_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000008_fn__790000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000008_fn__790000009_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000013_A_New() *A_arbace_repr_go_lit_eval790000013_A { t := &A_arbace_repr_go_lit_eval790000013_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000013_A_class }

func (t *A_arbace_repr_go_lit_eval790000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); return ok }

func A_arbace_repr_go_lit_eval790000013_A_Cast(x any) *A_arbace_repr_go_lit_eval790000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000013_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_exact_double_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_exact_double_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_text_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_text_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hex_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hex_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hexv_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hexv_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_imag_inner_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_imag_inner_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_int_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_int_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_num_den_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_num_den_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow2_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow2_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow5_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A struct{ j2g_header uint64; F_d, F_five any }

var A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rational_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_bytes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_bytes_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_terminating_decimal_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_terminating_decimal_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_put_cp__790000067_A struct{ j2g_header uint64; F_out any }

var A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_untyped_float_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_untyped_float_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_utf8_parts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_utf8_parts_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_val_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_val_rational_A_fn_class *jrt.Class
