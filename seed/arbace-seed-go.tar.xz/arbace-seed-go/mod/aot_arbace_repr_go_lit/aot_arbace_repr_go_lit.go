//line aot_arbace_repr_go_lit.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_New() *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_1); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_lit_eval790000008_fn__790000009_A_New() *A_arbace_repr_go_lit_eval790000008_fn__790000009_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000008_fn__790000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_go_lit_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_go_lit_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(), A_arbace_repr_go_lit_A_const_8) }











func A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_New() *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Invoke_O_O_O__O(self, text__1, value__2 any) any { return A_arbace_repr_go_lit_Lit_A_New_O_O(text__1, value__2) }
//line :13:1
func A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_New() *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Invoke_O_O__O(self, m__231000218__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000218__auto____1) { tmp1 = m__231000218__auto____1 } else { var root_19 any = A_arbace_repr_go_lit_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_23 any = m__231000218__auto____1; if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }; return A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(lang.IPersistentMap_Cast(tmp1)).Ref() }

func A_arbace_repr_go_lit_lit_A_New() *A_arbace_repr_go_lit_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Ctor() {}
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Invoke_O_O_O__O(self, text__0, value__1 any) any { var root_24 any = A_arbace_repr_go_lit_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = text__0; var arg_28 any = value__1; if linked_25 == nil { return ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { return linked_25.(*A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A).Invoke_O_O_O__O(root_24, arg_27, arg_28) } }

func A_arbace_repr_go_lit_lit_QMARK__A_New() *A_arbace_repr_go_lit_lit_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(A_arbace_repr_go_lit_Lit_A_InstanceOf(x__0)).Ref() }











func A_arbace_repr_go_lit_printable_QMARK__A_New() *A_arbace_repr_go_lit_printable_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_printable_QMARK__A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Ctor() {}
//line :29:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var or__1927000174__auto____3 bool; var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(cp__2, 33); if and__1927000168__auto____3 {



	or__1927000174__auto____3 = lang.Numbers_Lte_J_J__Z_NoInit(cp__2, 126) } else { or__1927000174__auto____3 = and__1927000168__auto____3 }; if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var t__4 int32 = jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); var root_29 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_31 lang.IFn

		if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any; var or__1927000174__auto____5 bool = jrt.Character_IsISOControl_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____5 { arg_32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.Character_IsWhitespace_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____6 { arg_32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = jrt.Character_IsSpaceChar_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____7 { arg_32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_13; var or__1927000174__auto____8 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_14); if jrt.J2g_Truth(or__1927000174__auto____8) { arg_32 = or__1927000174__auto____8 } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_lit_A_const_15; var or__1927000174__auto____9 any = tmp3.Invoke_O_O_O__O(tmp4, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_16); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_32 = or__1927000174__auto____9 } else {



			var root_45 any = A_arbace_repr_go_lit_A_const_17.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(); var arg_49 any = jrt.Integer_ValueOf_I__Integer_NoInit(t__4).Ref(); if linked_46 == nil { arg_32 = ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { arg_32 = linked_46.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_45, arg_48, arg_49) } } } } } }
//line :35:1
		if linked_30 == nil { return ifn_31.Invoke_O__O(arg_32) } else { return linked_30.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_29, arg_32) } } }





func A_arbace_repr_go_lit_string_text_A_New() *A_arbace_repr_go_lit_string_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_text_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_lit_string_text_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_lit_string_text_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_35); var n__3 int32 = jrt.NN(jrt.String_Cast(s__0)).Length__I(); var i__4 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__3)) { var cp__5 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__4)); var w__6 int32 = jrt.Character_CharCount_I__I_NoInit(cp__5); var G__790000031__7_ int32 = lang.RT_IntCast_I__I_NoInit(cp__5)


	L2: switch { default: switch G__790000031__7_ { case 8:





		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_36)
//line :50:1
		break L2; case 9:



		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_37)
//line :50:1
		break L2; case 10:


		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_38)
//line :50:1
		break L2; case 12:






		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_39)
//line :50:1
		break L2; case 13:




		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_40)
//line :50:1
		break L2; case 34:
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_41)
//line :50:1
		break L2; case 92:

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_42)
//line :50:1
		break L2; default:
	}






		var tmp1 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(cp__5), 32)
		if or__1927000174__auto____8 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_55 any = A_arbace_repr_go_lit_A_const_20.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_repr_go_lit_printable_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref(); if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*A_arbace_repr_go_lit_printable_QMARK__A).Invoke_O_O__O(root_55, arg_58) } }
//line :58:1
		if jrt.J2g_Truth(tmp1) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).AppendCodePoint_I__StringBuilder(cp__5) } else {
//line :58:1
				if lang.Numbers_Lt_J_J__Z_NoInit(int64(cp__5), 65536) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref()))) } else {
//line :58:1
						if A_arbace_repr_go_lit_A_const_22 != nil { var seq_790000032__8 any; var root_64 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_66 lang.IFn


							if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = jrt.Character_ToChars_I__C1_NoInit(cp__5).Ref(); if linked_65 == nil { seq_790000032__8 = ifn_66.Invoke_O__O(arg_67) } else { seq_790000032__8 = linked_65.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_64, arg_67) }
//line :58:1
							var chunk_790000033__9 any; var count_790000034__10 int64 = 0; var i_790000035__11 int64 = 0; L3: for {


								if lang.Numbers_Lt_J_J__Z_NoInit(i_790000035__11, count_790000034__10) { var c__12 any = lang.Indexed_Cast(chunk_790000033__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_790000035__11)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__12)).Ref()))); seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = seq_790000032__8, chunk_790000033__9, count_790000034__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_790000035__11); continue L3 } else { var temp__1927000414__auto____12 any; var root_68 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = seq_790000032__8; if linked_69 == nil { temp__1927000414__auto____12 = ifn_70.Invoke_O__O(arg_71) } else { temp__1927000414__auto____12 = linked_69.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_790000032__13 any = temp__1927000414__auto____12; var tmp2 any; var root_72 any = A_arbace_repr_go_lit_A_const_24.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = seq_790000032__13; if linked_73 == nil { tmp2 = ifn_74.Invoke_O__O(arg_75) } else { tmp2 = linked_73.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_72, arg_75) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____14 any; var root_76 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = seq_790000032__13; if linked_77 == nil { c__1927000678__auto____14 = ifn_78.Invoke_O__O(arg_79) } else { c__1927000678__auto____14 = linked_77.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_76, arg_79) }; var tmp3 any; var root_89 any = A_arbace_repr_go_lit_A_const_27.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = seq_790000032__13; if linked_90 == nil { tmp3 = ifn_91.Invoke_O__O(arg_92) } else { tmp3 = linked_90.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_89, arg_92) }; seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = tmp3, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var c__14 any; var root_80 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = seq_790000032__13; if linked_81 == nil { c__14 = ifn_82.Invoke_O__O(arg_83) } else { c__14 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__14)).Ref()))); var tmp4 any; var root_98 any = A_arbace_repr_go_lit_A_const_28.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = seq_790000032__13; if linked_99 == nil { tmp4 = ifn_100.Invoke_O__O(arg_101) } else { tmp4 = linked_99.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_98, arg_101) }; seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = tmp4, nil, 0, 0; continue L3 } } }
//line :58:1
								break L3
							}
						}
					} }}
		i__4 = lang.Numbers_Add_J_J__J_NoInit(i__4, int64(w__6)); continue L1 }
//line :41:1
	break L1 }; var root_50 any =





















	A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_35).Ref(); if linked_51 == nil { return ifn_52.Invoke_O__O(arg_53) } else { return linked_51.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_50, arg_53) } }

func A_arbace_repr_go_lit_char_text_A_New() *A_arbace_repr_go_lit_char_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_char_text_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_repr_go_lit_char_text_A) Ctor() {}
//line :65:1
func (t *A_arbace_repr_go_lit_char_text_A) Invoke_O_O__O(self, cp__0 any) any { var ch__2 uint16 = lang.RT_CharCast_O__C_NoInit(cp__0); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref()))).Ref() } else {
//line :69:1
			var tmp1 any; var root_102 any = A_arbace_repr_go_lit_A_const_20.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_repr_go_lit_printable_QMARK__A_fn_class); var ifn_104 lang.IFn

			if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = cp__0; if linked_103 == nil { tmp1 = ifn_104.Invoke_O__O(arg_105) } else { tmp1 = linked_103.(*A_arbace_repr_go_lit_printable_QMARK__A).Invoke_O_O__O(root_102, arg_105) }
//line :69:1
			if jrt.J2g_Truth(tmp1) {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())).Ref() } else {
//line :69:1
					if A_arbace_repr_go_lit_A_const_22 != nil {


						return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(cp__0)).Ref()) } else {
//line :69:1
							return nil } } } }






func A_arbace_repr_go_lit_int_lit_A_New() *A_arbace_repr_go_lit_int_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_int_lit_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_repr_go_lit_int_lit_A) Ctor() {}
//line :76:1
func (t *A_arbace_repr_go_lit_int_lit_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_111 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_113 lang.IFn; if



	linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = text__0; var arg_115 any = Lit_22; var arg_116 any = Lit_23; if linked_112 == nil { t__2 = ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { t__2 = linked_112.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) }; var lower__3 any; var root_117 any = /*line :76:1*/A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_119 lang.IFn; if




	linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = t__2; if linked_118 == nil { lower__3 = ifn_119.Invoke_O__O(arg_120) } else { lower__3 = linked_118.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_117, arg_120) }; var vec__790000038__4 any; var tmp1 any; var root_121 any = /*line :76:1*/A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_123 lang.IFn; if







	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = lower__3; var arg_125 any = Lit_21; if linked_122 == nil { tmp1 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp1 = linked_122.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; if /*line :83:1*/ jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_repr_go_lit_A_const_36; var tmp3 any; var root_154 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_156 lang.IFn
		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = t__2; var arg_158 any = A_arbace_repr_go_lit_A_const_38; if linked_155 == nil { tmp3 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { tmp3 = linked_155.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
//line :83:1
		vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp2, tmp3) } else { var tmp4 any; var root_126 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_128 lang.IFn

			if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = lower__3; var arg_130 any = Lit_26; if linked_127 == nil { tmp4 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { tmp4 = linked_127.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_126, arg_129, arg_130) }
//line :83:1
			if jrt.J2g_Truth(tmp4) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp6 any; var root_159 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_161 lang.IFn

				if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = t__2; var arg_163 any = A_arbace_repr_go_lit_A_const_38; if linked_160 == nil { tmp6 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { tmp6 = linked_160.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }
//line :83:1
				var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); var tmp8 any = A_arbace_repr_go_lit_A_const_39; var tmp9 any; var root_164 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_166 lang.IFn

				if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = t__2; var arg_168 any = A_arbace_repr_go_lit_A_const_38; if linked_165 == nil { tmp9 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { tmp9 = linked_165.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }
//line :83:1
				vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, tmp8, tmp9) } else { var tmp10 any; var root_131 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_133 lang.IFn


					if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = lower__3; var arg_135 any = Lit_28; if linked_132 == nil { tmp10 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp10 = linked_132.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }
//line :83:1
					if jrt.J2g_Truth(tmp10) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil); var tmp12 any; var root_169 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_171 lang.IFn


						if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = t__2; var arg_173 any = A_arbace_repr_go_lit_A_const_38; if linked_170 == nil { tmp12 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { tmp12 = linked_170.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }
//line :83:1
						var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref(); var tmp14 any = A_arbace_repr_go_lit_A_const_38; var tmp15 any; var root_174 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_176 lang.IFn


						if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__2; var arg_178 any = A_arbace_repr_go_lit_A_const_38; if linked_175 == nil { tmp15 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { tmp15 = linked_175.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }
//line :83:1
						vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp13, tmp14, tmp15) } else { var tmp16 any; var and__1927000168__auto____4 any; var root_136 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_138 lang.IFn



							if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t__2; var arg_140 any = Lit_27; if linked_137 == nil { and__1927000168__auto____4 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { and__1927000168__auto____4 = linked_137.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t__2)), 1)).Ref() } else { tmp16 = and__1927000168__auto____4 }
//line :83:1
							if jrt.J2g_Truth(tmp16) { var tmp17 any = A_arbace_repr_go_lit_A_const_39; var tmp18 any; var root_179 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_181 lang.IFn



								if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__2; var arg_183 any = A_arbace_repr_go_lit_A_const_40; if linked_180 == nil { tmp18 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { tmp18 = linked_180.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }
//line :83:1
								vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp17, tmp18) } else { if A_arbace_repr_go_lit_A_const_22 != nil { vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, A_arbace_repr_go_lit_A_const_41, t__2) } else { vec__790000038__4 = nil } } } } }; var ctext__5 any = /*line :76:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(0), nil); var radix__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(1), nil); var digits__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(2), nil); var v__8 any; var root_141 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_143 lang.IFn; if












	linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__7), lang.RT_IntCast_O__I_NoInit(radix__6)); if linked_142 == nil { v__8 = ifn_143.Invoke_O__O(arg_144) } else { v__8 = linked_142.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_141, arg_144) }; var root_145 any =
	A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = ctext__5; var arg_149 any; var tmp19 any; var root_150 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = v__8; if linked_151 == nil { tmp19 = ifn_152.Invoke_O__O(arg_153) } else { tmp19 = linked_151.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_150, arg_153) }; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.BigInteger_Cast(tmp19).BitLength__I()), 64) { arg_149 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__8)).Ref() } else { arg_149 = v__8 }; if linked_146 == nil { return ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { return linked_146.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) } }

func A_arbace_repr_go_lit_integer_text_A_New() *A_arbace_repr_go_lit_integer_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_text_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_repr_go_lit_integer_text_A) Ctor() {}
//line :92:1
func (t *A_arbace_repr_go_lit_integer_text_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var root_184 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_186 lang.IFn; if


	linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = v__0; if linked_185 == nil { b__2 = ifn_186.Invoke_O__O(arg_187) } else { b__2 = linked_185.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_184, arg_187) }; if
	lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.BigInteger_Cast(b__2).BitLength__I()), 64) { var root_188 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref(); if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_188, arg_191) } } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, b__2, nil)).Ref() } }

func A_arbace_repr_go_lit_integer_lit_A_New() *A_arbace_repr_go_lit_integer_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_lit_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Ctor() {}
//line :98:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any; var root_192 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_194 lang.IFn; if
										linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = v__0; if linked_193 == nil { b__2 = ifn_194.Invoke_O__O(arg_195) } else { b__2 = linked_193.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_192, arg_195) }; var root_196 any =
										A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var root_201 any = A_arbace_repr_go_lit_A_const_42.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, A_arbace_repr_go_lit_integer_text_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = v__0; if linked_202 == nil { arg_199 = ifn_203.Invoke_O__O(arg_204) } else { arg_199 = linked_202.(*A_arbace_repr_go_lit_integer_text_A).Invoke_O_O__O(root_201, arg_204) }; var arg_200 any; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.BigInteger_Cast(b__2).BitLength__I()), 64) { arg_200 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref() } else { var root_205 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = b__2; if linked_206 == nil { arg_200 = ifn_207.Invoke_O__O(arg_208) } else { arg_200 = linked_206.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_205, arg_208) } }; if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } }



func A_arbace_repr_go_lit_rational_A_New() *A_arbace_repr_go_lit_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rational_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_repr_go_lit_rational_A) Ctor() {}
//line :104:1
func (t *A_arbace_repr_go_lit_rational_A) Invoke_O_O_O__O(self, num__0, den__1 any) any {


	var tmp1 any; var root_209 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = num__0; if linked_210 == nil { tmp1 = ifn_211.Invoke_O__O(arg_212) } else { tmp1 = linked_210.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_209, arg_212) }; var tmp2 any = tmp1; var tmp3 any; var root_213 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = den__1; if linked_214 == nil { tmp3 = ifn_215.Invoke_O__O(arg_216) } else { tmp3 = linked_214.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_213, arg_216) }; return lang.Numbers_Divide_O_O__Number_NoInit(tmp2, tmp3)
}
func A_arbace_repr_go_lit_pow2_A_New() *A_arbace_repr_go_lit_pow2_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow2_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_lit_pow2_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_lit_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 jrt.BigInteger_I = tmp1; return tmp2.ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)) }

func A_arbace_repr_go_lit_pow5_exponent_A_New() *A_arbace_repr_go_lit_pow5_exponent_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Ctor() {}
//line :111:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Invoke_O_O__O(self, d__0 any) any { var guess__2 int64 = lang.RT_LongCast_D__J_NoInit(jrt.Math_Floor_D__D(lang.Numbers_Divide_D_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(int64(jrt.BigInteger_Cast(d__0).BitLength__I()), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_38))), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_43))))); var five__3 any = jrt.BigInteger_ValueOf_J__BigInteger(5); var root_217 any = A_arbace_repr_go_lit_A_const_44.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_219 lang.IFn; if




	linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var fnbody__228 any = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(d__0, five__3); var tmp1 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__228); A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class = fncls__227d; tmp1 = fncls__227d } else { tmp1 = fncls__227 }; arg_220 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__228, tmp1, nil); var arg_221 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(guess__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(guess__2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(guess__2)).Ref()); if linked_218 == nil { return ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { return linked_218.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } }
//line :116:1
func A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :116:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Ctor_O_O(c__d, c__five any) { t.F_d = c__d; t.F_five = c__five }
//line :116:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var na_222 any = k__1; var na_223 int64 = 0; if jrt.Long_InstanceOf(na_222) { var n0_224 int64 = jrt.NN(jrt.Long_Cast(na_222)).LongValue__J(); var n1_225 int64 = na_223; and__1927000168__auto____2 = n0_224 >= n1_225 } else { and__1927000168__auto____2 = lang.Numbers_Gte_O_J__Z_NoInit(na_222, na_223) }; if and__1927000168__auto____2 { var tmp2 any = t.F_d; var tmp3 jrt.BigInteger_I = jrt.BigInteger_Cast(t.F_five); tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3.Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return k__1 } else { return nil } }


func A_arbace_repr_go_lit_num_den_A_New() *A_arbace_repr_go_lit_num_den_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_num_den_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_go_lit_num_den_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_go_lit_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 any; var root_229 any = A_arbace_repr_go_lit_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_231 lang.IFn
	if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = r__0; if linked_230 == nil { tmp1 = ifn_231.Invoke_O__O(arg_232) } else { tmp1 = linked_230.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_229, arg_232) }
//line :120:1
	if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_233 any = A_arbace_repr_go_lit_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_235 lang.IFn
		if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = r__0; if linked_234 == nil { tmp2 = ifn_235.Invoke_O__O(arg_236) } else { tmp2 = linked_234.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_233, arg_236) }
//line :120:1
		var tmp3 any = tmp2; var tmp4 any; var root_237 any = A_arbace_repr_go_lit_A_const_47.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_239 lang.IFn
		if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = r__0; if linked_238 == nil { tmp4 = ifn_239.Invoke_O__O(arg_240) } else { tmp4 = linked_238.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_237, arg_240) }
//line :120:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if A_arbace_repr_go_lit_A_const_22 != nil { var tmp5 any; var root_241 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_243 lang.IFn

			if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = r__0; if linked_242 == nil { tmp5 = ifn_243.Invoke_O__O(arg_244) } else { tmp5 = linked_242.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_241, arg_244) }
//line :120:1
			var tmp6 any = tmp5; var tmp7 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) } else { return nil
			}
		}
}





func A_arbace_repr_go_lit_terminating_decimal_A_New() *A_arbace_repr_go_lit_terminating_decimal_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_terminating_decimal_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Ctor() {}
//line :129:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Invoke_O_O_O__O(self, num__0, den__1 any) any { var twos__3 int32 = jrt.BigInteger_Cast(den__1).GetLowestSetBit__I(); var temp__1927000414__auto____4 any; var root_245 any = A_arbace_repr_go_lit_A_const_48.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_repr_go_lit_pow5_exponent_A_fn_class); var ifn_247 lang.IFn; if



	linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = jrt.BigInteger_Cast(den__1).ShiftRight_I__BigInteger(twos__3); if linked_246 == nil { temp__1927000414__auto____4 = ifn_247.Invoke_O__O(arg_248) } else { temp__1927000414__auto____4 = linked_246.(*A_arbace_repr_go_lit_pow5_exponent_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var fives__5 any = temp__1927000414__auto____4; var scale__6 any = lang.Numbers_Max_J_O__O_NoInit(int64(twos__3), fives__5); var unscaled__7 any; var tmp1 jrt.BigInteger_I = jrt.BigInteger_Cast(num__0); var tmp2 jrt.Number_I; var na_249 any = scale__6; var na_250 int64 = int64(twos__3)



		if jrt.Long_InstanceOf(na_249) { var n0_251 int64 = jrt.NN(jrt.Long_Cast(na_249)).LongValue__J(); var n1_252 int64 = na_250; var nr_253 int64 = n0_251 - n1_252; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_252 == -9223372036854775808); if tmp4 { tmp4 = (n0_251^n1_252)&(n0_251^nr_253) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_253)) } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_249, na_250) } } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_249, na_250) }
		var tmp5 jrt.BigInteger_I = tmp1.ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp2)); var tmp6 jrt.BigInteger_I = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp7 jrt.Number_I; var na_254 any = scale__6; var na_255 any = fives__5; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_254); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_255) }; tmp8 = tmp9; if tmp8 { var n0_256 int64 = jrt.NN(jrt.Long_Cast(na_254)).LongValue__J(); var n1_257 int64 = jrt.NN(jrt.Long_Cast(na_255)).LongValue__J(); var nr_258 int64 = n0_256 - n1_257; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_257 == -9223372036854775808); if tmp11 { tmp11 = (n0_256^n1_257)&(n0_256^nr_258) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_258)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_254, na_255) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_254); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_255) }; tmp12 = tmp13; if tmp12 { var n0_256_2 float64 = jrt.NN(jrt.Double_Cast(na_254)).DoubleValue__D(); var n1_257_2 float64 = jrt.NN(jrt.Double_Cast(na_255)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_256_2 + -n1_257_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_254, na_255) } }; unscaled__7 = tmp5.Multiply_BigInteger__BigInteger(tmp6.Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp7)))
//line :133:1
		return jrt.BigDecimal_New_BigInteger_I(jrt.BigInteger_Cast(unscaled__7), lang.RT_IntCast_O__I_NoInit(scale__6)) } else { return nil } }







func A_arbace_repr_go_lit_double_exact_text_A_New() *A_arbace_repr_go_lit_double_exact_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_exact_text_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Invoke_O_O__O(self, v__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(v__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsInfinite_D__Z_NoInit(d__2); if or__1927000174__auto____3 {




	tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsNaN_D__Z_NoInit(d__2) }; if tmp1 { return nil } else { var s__3 any = jrt.Double_ToString_D__String_NoInit(d__2).Ref(); var bd__4 any = jrt.BigDecimal_New_String(jrt.String_Cast(s__3)); var tmp2 bool


		if jrt.BigDecimal_InstanceOf(v__0) {
			tmp2 = lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(bd__4)).CompareTo_BigDecimal__I(jrt.BigDecimal_Cast(v__0)))) } else {
				var tmp3 any; var root_259 any = A_arbace_repr_go_lit_A_const_49.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_rationalize_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = bd__4; if linked_260 == nil { tmp3 = ifn_261.Invoke_O__O(arg_262) } else { tmp3 = linked_260.(*aot_arbace_core.A_arbace_core_rationalize_A).Invoke_O_O__O(root_259, arg_262) }; tmp2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, v__0) }
//line :149:1
		if tmp2 { return s__3 } else { return nil } } }




func A_arbace_repr_go_lit_decimal_text_A_New() *A_arbace_repr_go_lit_decimal_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decimal_text_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Ctor() {}
//line :154:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Invoke_O_O__O(self, bd__0 any) any { var s__2 any; var root_263 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_265 lang.IFn; if


	linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = jrt.NN(jrt.BigDecimal_Cast(bd__0)).StripTrailingZeros__BigDecimal().Ref(); if linked_264 == nil { s__2 = ifn_265.Invoke_O__O(arg_266) } else { s__2 = linked_264.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_263, arg_266) }; var tmp1 any; var or__1927000174__auto____3 any; var root_267 any =
	A_arbace_repr_go_lit_A_const_50.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = s__2; var arg_271 any = Lit_8; if linked_268 == nil { or__1927000174__auto____3 = ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { or__1927000174__auto____3 = linked_268.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_267, arg_270, arg_271) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_272 any = A_arbace_repr_go_lit_A_const_50.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = s__2; var arg_276 any = Lit_9; if linked_273 == nil { tmp1 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { tmp1 = linked_273.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_272, arg_275, arg_276) } }; if jrt.J2g_Truth(tmp1) { return s__2 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() } }

func A_arbace_repr_go_lit_float_lit_A_New() *A_arbace_repr_go_lit_float_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_lit_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_repr_go_lit_float_lit_A) Ctor() {}
//line :160:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O_O__O(self, v__0, p__790000053__1 any) any { var map__790000054__3 any = p__790000053__1; var map__790000054__4 any; if lang.ISeq_InstanceOf(map__790000054__3) { var tmp1 any; var root_277 any = A_arbace_repr_go_lit_A_const_28.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = map__790000054__3; if linked_278 == nil { tmp1 = ifn_279.Invoke_O__O(arg_280) } else { tmp1 = linked_278.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_281 any = A_arbace_repr_go_lit_A_const_51.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = map__790000054__3; if linked_282 == nil { tmp2 = ifn_283.Invoke_O__O(arg_284) } else { tmp2 = linked_282.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_281, arg_284) }; map__790000054__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_285 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = map__790000054__3; if linked_286 == nil { tmp3 = ifn_287.Invoke_O__O(arg_288) } else { tmp3 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }; if jrt.J2g_Truth(tmp3) { var root_289 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = map__790000054__3; if linked_290 == nil { map__790000054__4 = ifn_291.Invoke_O__O(arg_292) } else { map__790000054__4 = linked_290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_289, arg_292) } } else { map__790000054__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__790000054__4 = map__790000054__3 }; var prefer_ratio__5 any = lang.RT_Get_O_O__O_NoInit(map__790000054__4, A_arbace_repr_go_lit_A_const_52); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 any; var root_293 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_295 lang.IFn; if







	linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = prefer_ratio__5; if linked_294 == nil { and__1927000168__auto____6 = ifn_295.Invoke_O__O(arg_296) } else { and__1927000168__auto____6 = linked_294.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_293, arg_296) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_297 any = A_arbace_repr_go_lit_A_const_53.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, A_arbace_repr_go_lit_double_exact_text_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = v__0; if linked_298 == nil { temp__1927000408__auto____6 = ifn_299.Invoke_O__O(arg_300) } else { temp__1927000408__auto____6 = linked_298.(*A_arbace_repr_go_lit_double_exact_text_A).Invoke_O_O__O(root_297, arg_300) } } else { temp__1927000408__auto____6 = and__1927000168__auto____6 }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var s__7 any = temp__1927000408__auto____6; var root_301 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_303 lang.IFn
		if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = s__7; var arg_305 any = jrt.Double_ValueOf_D__Double_NoInit(jrt.Double_ParseDouble_String__D_NoInit(jrt.String_Cast(s__7))).Ref(); if linked_302 == nil { return ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { return linked_302.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_301, arg_304, arg_305) } } else {
			if jrt.BigDecimal_InstanceOf(v__0) { var s__7_2 any; var root_306 any = A_arbace_repr_go_lit_A_const_54.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_repr_go_lit_decimal_text_A_fn_class); var ifn_308 lang.IFn
				if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = v__0; if linked_307 == nil { s__7_2 = ifn_308.Invoke_O__O(arg_309) } else { s__7_2 = linked_307.(*A_arbace_repr_go_lit_decimal_text_A).Invoke_O_O__O(root_306, arg_309) }; var root_310 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__7_2, nil)).Ref(); var tmp4 *jrt.Class = A_arbace_repr_go_lit_A_const_55; var arg_314 any = lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, s__7_2)); if linked_311 == nil { return ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { return linked_311.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_310, arg_313, arg_314) } } else {
//line :170:1
					var vec__790000056__7 any; var root_315 any = A_arbace_repr_go_lit_A_const_56.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, A_arbace_repr_go_lit_num_den_A_fn_class); var ifn_317 lang.IFn

					if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = v__0; if linked_316 == nil { vec__790000056__7 = ifn_317.Invoke_O__O(arg_318) } else { vec__790000056__7 = linked_316.(*A_arbace_repr_go_lit_num_den_A).Invoke_O_O__O(root_315, arg_318) }
//line :170:1
					var num__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(0), nil); var den__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(1), nil); var integral__10 bool; var tmp5 jrt.BigInteger_I


					jrt.BigInteger_Init(); tmp5 = jrt.BigInteger_ONE; integral__10 = lang.Util_Equiv_O_O__Z_NoInit(den__9, tmp5)
//line :170:1
					var bd__11 any; var tmp6 any
					var and__1927000168__auto____11 any = prefer_ratio__5


					if jrt.J2g_Truth(and__1927000168__auto____11) { var root_319 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(integral__10).Ref(); if linked_320 == nil { tmp6 = ifn_321.Invoke_O__O(arg_322) } else { tmp6 = linked_320.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_319, arg_322) } } else { tmp6 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp6) { bd__11 = nil } else { var root_323 any = A_arbace_repr_go_lit_A_const_57.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, A_arbace_repr_go_lit_terminating_decimal_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = num__8; var arg_327 any = den__9; if linked_324 == nil { bd__11 = ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { bd__11 = linked_324.(*A_arbace_repr_go_lit_terminating_decimal_A).Invoke_O_O_O__O(root_323, arg_326, arg_327) } }
					var tmp7 any; var and__1927000168__auto____12 any = bd__11; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = integral__10; if or__1927000174__auto____13 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { var tmp8 bool; var na_328 int64; var tmp9 any; var root_330 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = bd__11; if linked_331 == nil { tmp9 = ifn_332.Invoke_O__O(arg_333) } else { tmp9 = linked_331.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_330, arg_333) }; na_328 = int64(lang.RT_Count_O__I_NoInit(tmp9)); var na_329 any = A_arbace_repr_go_lit_A_const_58.GetRawRoot__O(); if jrt.Long_InstanceOf(na_329) { var n0_334 int64 = na_328; var n1_335 int64 = jrt.NN(jrt.Long_Cast(na_329)).LongValue__J(); tmp8 = n0_334 <= n1_335 } else { tmp8 = lang.Numbers_Lte_J_O__Z_NoInit(na_328, na_329) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp8).Ref() } } else { tmp7 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp7) { var s__12 any; var root_337 any = A_arbace_repr_go_lit_A_const_54.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, A_arbace_repr_go_lit_decimal_text_A_fn_class); var ifn_339 lang.IFn
						if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = bd__11; if linked_338 == nil { s__12 = ifn_339.Invoke_O__O(arg_340) } else { s__12 = linked_338.(*A_arbace_repr_go_lit_decimal_text_A).Invoke_O_O__O(root_337, arg_340) }; var root_341 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__12, nil)).Ref(); var tmp10 *jrt.Class = A_arbace_repr_go_lit_A_const_55; var arg_345 any = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, s__12)); if linked_342 == nil { return ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { return linked_342.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) } } else {
							var root_346 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, num__8, nil, den__9)).Ref(); var arg_350 any = v__0; if linked_347 == nil { return ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { return linked_347.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) } } } } }
//line :160:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O__O(self, v__0 any) any {





	var root_351 any = A_arbace_repr_go_lit_A_const_59.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = v__0; var arg_355 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_352 == nil { return ifn_353.Invoke_O_O__O(arg_354, arg_355) } else { return linked_352.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O_O__O(root_351, arg_354, arg_355)
	}
}










func A_arbace_repr_go_lit_exact_double_A_New() *A_arbace_repr_go_lit_exact_double_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_exact_double_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_repr_go_lit_exact_double_A) Ctor() {}
//line :179:1
func (t *A_arbace_repr_go_lit_exact_double_A) Invoke_O_O__O(self, r__0 any) any {



	var tmp1 any; var root_356 any = A_arbace_repr_go_lit_A_const_45.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = r__0; if linked_357 == nil { tmp1 = ifn_358.Invoke_O__O(arg_359) } else { tmp1 = linked_357.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 any; var root_360 any = A_arbace_repr_go_lit_A_const_46.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = r__0; if linked_361 == nil { tmp3 = ifn_362.Invoke_O__O(arg_363) } else { tmp3 = linked_361.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_360, arg_363) }; var tmp4 *jrt.BigDecimal = jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(tmp3)); var tmp5 any; var root_364 any = A_arbace_repr_go_lit_A_const_47.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = r__0; if linked_365 == nil { tmp5 = ifn_366.Invoke_O__O(arg_367) } else { tmp5 = linked_365.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_364, arg_367) }; tmp2 = jrt.Double_ValueOf_D__Double_NoInit(jrt.NN(tmp4.Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(tmp5)))).DoubleValue__D()).Ref() }
//line :183:1
		return nil }(); if tmp6 != nil { if jrt.ArithmeticException_InstanceOf(tmp6) { var ___4 *jrt.ArithmeticException = jrt.ArithmeticException_Cast(tmp6); _ = ___4


			tmp2 = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__0)).Ref() } else {
//line :183:1
				panic(tmp6) } }; return tmp2 } else {



					return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__0)).Ref()
				} }
func A_arbace_repr_go_lit_double_lit_A_New() *A_arbace_repr_go_lit_double_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_lit_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_repr_go_lit_double_lit_A) Ctor() {}
//line :189:1
func (t *A_arbace_repr_go_lit_double_lit_A) Invoke_O_O__O(self, r__0 any) any { var d__2 any; var root_368 any = A_arbace_repr_go_lit_A_const_60.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_repr_go_lit_exact_double_A_fn_class); var ifn_370 lang.IFn; if


	linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = r__0; if linked_369 == nil { d__2 = ifn_370.Invoke_O__O(arg_371) } else { d__2 = linked_369.(*A_arbace_repr_go_lit_exact_double_A).Invoke_O_O__O(root_368, arg_371) }; var root_372 any =
	A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; if jrt.Double_IsNaN_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)) { arg_375 = Lit_13 } else { if jrt.Double_IsInfinite_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)) {
		var tmp1 bool; var na_377 any = d__2; if jrt.Long_InstanceOf(na_377) { var n0_378 int64 = jrt.NN(jrt.Long_Cast(na_377)).LongValue__J(); tmp1 = n0_378 > 0 } else { if jrt.Double_InstanceOf(na_377) { var n0_378_2 float64 = jrt.NN(jrt.Double_Cast(na_377)).DoubleValue__D(); tmp1 = n0_378_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_377) } }; if tmp1 { arg_375 = Lit_14 } else { arg_375 = Lit_15 } } else {
//line :193:1
			if A_arbace_repr_go_lit_A_const_22 != nil {

				arg_375 = jrt.Double_ToString_D__String_NoInit(lang.RT_DoubleCast_O__D_NoInit(d__2)).Ref() } else {
//line :193:1
					arg_375 = nil } } }; var arg_376 any = d__2; if linked_373 == nil { return ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { return linked_373.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) } }




func A_arbace_repr_go_lit_hex_float_value_A_New() *A_arbace_repr_go_lit_hex_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hex_float_value_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Ctor() {}
//line :198:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Invoke_O_O__O(self, t__0 any) any { var body__2 any; var root_379 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_381 lang.IFn; if


	linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = t__0; var arg_383 any = A_arbace_repr_go_lit_A_const_38; if linked_380 == nil { body__2 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { body__2 = linked_380.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; var pi__3 any; var root_384 any = /*line :198:1*/A_arbace_repr_go_lit_A_const_61.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_386 lang.IFn; if



	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var root_389 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = body__2; if linked_390 == nil { arg_387 = ifn_391.Invoke_O__O(arg_392) } else { arg_387 = linked_390.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_389, arg_392) }; var arg_388 any = Lit_24; if linked_385 == nil { pi__3 = ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { pi__3 = linked_385.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) }; var mant__4 any; var root_393 any = /*line :198:1*/A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_395 lang.IFn; if




	linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = body__2; var arg_397 any = A_arbace_repr_go_lit_A_const_62; var arg_398 any = pi__3; if linked_394 == nil { mant__4 = ifn_395.Invoke_O_O_O__O(arg_396, arg_397, arg_398) } else { mant__4 = linked_394.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_393, arg_396, arg_397, arg_398) }; var exp__5 int64; var tmp1 any; var root_399 any = /*line :198:1*/A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_401 lang.IFn; if





	linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any; var root_405 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = body__2; var arg_409 any; var na_410 any = pi__3; if jrt.Long_InstanceOf(na_410) { var n0_411 int64 = jrt.NN(jrt.Long_Cast(na_410)).LongValue__J(); if n0_411 == 9223372036854775807 { arg_409 = lang.Numbers_Inc_O__Number_NoInit(na_410) } else { arg_409 = jrt.Long_ValueOf_J__Long_NoInit(n0_411 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_410) { var n0_411_2 float64 = jrt.NN(jrt.Double_Cast(na_410)).DoubleValue__D(); arg_409 = jrt.Double_ValueOf_D__Double_NoInit(n0_411_2 + 1.0).Ref() } else { arg_409 = lang.Numbers_Inc_O__Number_NoInit(na_410) } }; if linked_406 == nil { arg_402 = ifn_407.Invoke_O_O__O(arg_408, arg_409) } else { arg_402 = linked_406.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_405, arg_408, arg_409) }; var arg_403 any = Lit_25; var arg_404 any = Lit_23; if linked_400 == nil { tmp1 = ifn_401.Invoke_O_O_O__O(arg_402, arg_403, arg_404) } else { tmp1 = linked_400.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_399, arg_402, arg_403, arg_404) }; exp__5 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp1)); var dot__6 any; var root_412 any = /*line :198:1*/A_arbace_repr_go_lit_A_const_61.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_414 lang.IFn; if






	linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = mant__4; var arg_416 any = Lit_8; if linked_413 == nil { dot__6 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { dot__6 = linked_413.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }; var int_part__7 any; if
	jrt.J2g_Truth(dot__6) { var root_417 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = mant__4; var arg_421 any = A_arbace_repr_go_lit_A_const_62; var arg_422 any = dot__6; if linked_418 == nil { int_part__7 = ifn_419.Invoke_O_O_O__O(arg_420, arg_421, arg_422) } else { int_part__7 = linked_418.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_417, arg_420, arg_421, arg_422) } } else { int_part__7 = mant__4 }; var frac__8 any; if
	jrt.J2g_Truth(dot__6) { var root_423 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = mant__4; var arg_427 any; var na_428 any = dot__6; if jrt.Long_InstanceOf(na_428) { var n0_429 int64 = jrt.NN(jrt.Long_Cast(na_428)).LongValue__J(); if n0_429 == 9223372036854775807 { arg_427 = lang.Numbers_Inc_O__Number_NoInit(na_428) } else { arg_427 = jrt.Long_ValueOf_J__Long_NoInit(n0_429 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_428) { var n0_429_2 float64 = jrt.NN(jrt.Double_Cast(na_428)).DoubleValue__D(); arg_427 = jrt.Double_ValueOf_D__Double_NoInit(n0_429_2 + 1.0).Ref() } else { arg_427 = lang.Numbers_Inc_O__Number_NoInit(na_428) } }; if linked_424 == nil { frac__8 = ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { frac__8 = linked_424.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_423, arg_426, arg_427) } } else { frac__8 = Lit_23 }; var digits__9 any = /*line :198:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, int_part__7, frac__8)).Ref(); var m__10 any; var tmp2 any; var root_430 any = A_arbace_repr_go_lit_A_const_63.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_432 lang.IFn; if










	linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = digits__9; if linked_431 == nil { tmp2 = ifn_432.Invoke_O__O(arg_433) } else { tmp2 = linked_431.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(tmp2) { jrt.BigInteger_Init(); m__10 = jrt.BigInteger_ZERO } else { m__10 = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__9), lang.RT_IntCast_J__I_NoInit(16)) }; var e__11 int64 = /*line :198:1*/lang.Numbers_Minus_J_J__J_NoInit(exp__5, lang.Numbers_Multiply_J_J__J_NoInit(4, int64(lang.RT_Count_O__I_NoInit(frac__8)))); if












	lang.Numbers_IsNeg_J__Z_NoInit(e__11) {
		var root_434 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = m__10; var arg_438 any; var root_439 any = A_arbace_repr_go_lit_A_const_65.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, A_arbace_repr_go_lit_pow2_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__11)).Ref(); if linked_440 == nil { arg_438 = ifn_441.Invoke_O__O(arg_442) } else { arg_438 = linked_440.(*A_arbace_repr_go_lit_pow2_A).Invoke_O_O__O(root_439, arg_442) }; if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) } } else {
			var root_443 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = jrt.BigInteger_Cast(m__10).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__11)); var arg_447 any; jrt.BigInteger_Init(); arg_447 = jrt.BigInteger_ONE; if linked_444 == nil { return ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { return linked_444.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) } } }

func A_arbace_repr_go_lit_float_value_A_New() *A_arbace_repr_go_lit_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_value_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_repr_go_lit_float_value_A) Ctor() {}
//line :215:1
func (t *A_arbace_repr_go_lit_float_value_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_448 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_450 lang.IFn; if



	linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = text__0; var arg_452 any = Lit_22; var arg_453 any = Lit_23; if linked_449 == nil { t__2 = ifn_450.Invoke_O_O_O__O(arg_451, arg_452, arg_453) } else { t__2 = linked_449.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_448, arg_451, arg_452, arg_453) }; var tmp1 any; var root_454 any =
	A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any; var root_459 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t__2; if linked_460 == nil { arg_457 = ifn_461.Invoke_O__O(arg_462) } else { arg_457 = linked_460.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_459, arg_462) }; var arg_458 any = Lit_21; if linked_455 == nil { tmp1 = ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { tmp1 = linked_455.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }; if jrt.J2g_Truth(tmp1) {
		var root_463 any = A_arbace_repr_go_lit_A_const_66.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_repr_go_lit_hex_float_value_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = t__2; if linked_464 == nil { return ifn_465.Invoke_O__O(arg_466) } else { return linked_464.(*A_arbace_repr_go_lit_hex_float_value_A).Invoke_O_O__O(root_463, arg_466) } } else {
//line :220:1
			return jrt.BigDecimal_New_String(jrt.String_Cast(t__2)) } }



func A_arbace_repr_go_lit_float_text_lit_A_New() *A_arbace_repr_go_lit_float_text_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_text_lit_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Ctor() {}
//line :224:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Invoke_O_O__O(self, text__0 any) any { var hex__2 any; var root_467 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_469 lang.IFn; if



	linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any; var root_472 any = A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = text__0; if linked_473 == nil { arg_470 = ifn_474.Invoke_O__O(arg_475) } else { arg_470 = linked_473.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_472, arg_475) }; var arg_471 any = Lit_21; if linked_468 == nil { hex__2 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { hex__2 = linked_468.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }; var root_476 any =
	A_arbace_repr_go_lit_A_const_59.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_repr_go_lit_A_const_67.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_repr_go_lit_float_value_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = text__0; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*A_arbace_repr_go_lit_float_value_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_52, hex__2)); if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } }

func A_arbace_repr_go_lit_imag_inner_A_New() *A_arbace_repr_go_lit_imag_inner_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_imag_inner_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Ctor() {}
//line :231:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any; var root_485 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_487 lang.IFn; if



	linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var root_491 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = text__0; var arg_495 any = A_arbace_repr_go_lit_A_const_62; var arg_496 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_492 == nil { arg_488 = ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { arg_488 = linked_492.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) }; var arg_489 any = Lit_22; var arg_490 any = Lit_23; if linked_486 == nil { t__2 = ifn_487.Invoke_O_O_O__O(arg_488, arg_489, arg_490) } else { t__2 = linked_486.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_485, arg_488, arg_489, arg_490) }; var lower__3 any; var root_497 any = /*line :231:1*/A_arbace_repr_go_lit_A_const_31.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_499 lang.IFn; if




	linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = t__2; if linked_498 == nil { lower__3 = ifn_499.Invoke_O__O(arg_500) } else { lower__3 = linked_498.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_497, arg_500) }; var tmp1 any; var root_501 any =
	A_arbace_repr_go_lit_A_const_68.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_503 lang.IFn; if
	linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = A_arbace_repr_go_lit_A_const_69; var arg_505 any = t__2; if linked_502 == nil { tmp1 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { tmp1 = linked_502.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; if /*line :237:1*/ jrt.J2g_Truth(tmp1) { var v__4 any; var root_506 any = A_arbace_repr_go_lit_A_const_33.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_508 lang.IFn
		if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = jrt.BigInteger_New_String(jrt.String_Cast(t__2)); if linked_507 == nil { v__4 = ifn_508.Invoke_O__O(arg_509) } else { v__4 = linked_507.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_506, arg_509) }
		var root_510 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any; var root_515 any = A_arbace_repr_go_lit_A_const_42.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, A_arbace_repr_go_lit_integer_text_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = v__4; if linked_516 == nil { arg_513 = ifn_517.Invoke_O__O(arg_518) } else { arg_513 = linked_516.(*A_arbace_repr_go_lit_integer_text_A).Invoke_O_O__O(root_515, arg_518) }; var arg_514 any; var tmp2 any; var root_519 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = v__4; if linked_520 == nil { tmp2 = ifn_521.Invoke_O__O(arg_522) } else { tmp2 = linked_520.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_519, arg_522) }; if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.BigInteger_Cast(tmp2).BitLength__I()), 64) { arg_514 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__4)).Ref() } else { arg_514 = v__4 }; if linked_511 == nil { return ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { return linked_511.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) } } else {
//line :237:1
			var tmp3 any; var and__1927000168__auto____4 any; var root_523 any = A_arbace_repr_go_lit_A_const_68.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_525 lang.IFn


			if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = A_arbace_repr_go_lit_A_const_70; var arg_527 any = lower__3; if linked_524 == nil { and__1927000168__auto____4 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { and__1927000168__auto____4 = linked_524.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_528 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_532 any = A_arbace_repr_go_lit_A_const_50.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = lower__3; var arg_536 any = Lit_24; if linked_533 == nil { arg_531 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { arg_531 = linked_533.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; if linked_529 == nil { and__1927000168__auto____5 = ifn_530.Invoke_O__O(arg_531) } else { and__1927000168__auto____5 = linked_529.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_528, arg_531) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_537 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_541 any = A_arbace_repr_go_lit_A_const_50.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = lower__3; var arg_545 any = Lit_8; if linked_542 == nil { arg_540 = ifn_543.Invoke_O_O__O(arg_544, arg_545) } else { arg_540 = linked_542.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_541, arg_544, arg_545) }; if linked_538 == nil { tmp3 = ifn_539.Invoke_O__O(arg_540) } else { tmp3 = linked_538.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_537, arg_540) } } else {
//line :240:1
					tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :237:1
			if jrt.J2g_Truth(tmp3) {




				var root_546 any = A_arbace_repr_go_lit_A_const_71.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, A_arbace_repr_go_lit_int_lit_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = t__2; if linked_547 == nil { return ifn_548.Invoke_O__O(arg_549) } else { return linked_547.(*A_arbace_repr_go_lit_int_lit_A).Invoke_O_O__O(root_546, arg_549) } } else {
//line :237:1
					if A_arbace_repr_go_lit_A_const_22 != nil {





						var root_550 any = A_arbace_repr_go_lit_A_const_72.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_repr_go_lit_float_text_lit_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = t__2; if linked_551 == nil { return ifn_552.Invoke_O__O(arg_553) } else { return linked_551.(*A_arbace_repr_go_lit_float_text_lit_A).Invoke_O_O__O(root_550, arg_553) } } else {
//line :237:1
							return nil } } } }









func A_arbace_repr_go_lit_hexv_A_New() *A_arbace_repr_go_lit_hexv_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hexv_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_repr_go_lit_hexv_A) Ctor() {}
//line :247:1
func (t *A_arbace_repr_go_lit_hexv_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(s__0), lang.RT_IntCast_J__I_NoInit(16))).Ref() }

func A_arbace_repr_go_lit_unescape_A_New() *A_arbace_repr_go_lit_unescape_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_repr_go_lit_unescape_A) Ctor() {}
//line :249:1
func (t *A_arbace_repr_go_lit_unescape_A) Invoke_O_O__O(self, body__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var n__3 int32 = jrt.NN(jrt.String_Cast(body__0)).Length__I(); var put_cp__4 any; var fnbody__555 any = A_arbace_repr_go_lit_unescape_put_cp__790000067_A_New_O(out__2); var tmp1 *jrt.Class; var fncls__554 *jrt.Class = A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class; if




	fncls__554 == nil { var fncls__554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__555); A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class = fncls__554d; tmp1 = fncls__554d } else { tmp1 = fncls__554 }; put_cp__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__555, tmp1, nil); var i__5 int64 = 0; L1:
//line :249:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(n__3)) { var c__6 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__5)); var tmp2 any; var root_556 any = A_arbace_repr_go_lit_A_const_73.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_558 lang.IFn

			if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = jrt.Character_ValueOf_C__Character_NoInit(c__6).Ref(); var arg_560 any = A_arbace_repr_go_lit_A_const_74; if linked_557 == nil { tmp2 = ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { tmp2 = linked_557.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }; if jrt.J2g_Truth(tmp2) { var cp__7 int32 = jrt.NN(jrt.String_Cast(body__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__5))

				lang.IFn_Cast(put_cp__4).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(cp__7).Ref())
				i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, int64(jrt.Character_CharCount_I__I_NoInit(cp__7))); continue L1 } else {
//line :260:1
					var e__7 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)))
					var G__790000069__8_ uint16 = e__7



				L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_75) {









					jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(34)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
					break L2 }; case 39: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_76) {








						jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(39)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
						break L2 }; case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_77) {












							var tmp3 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp4 any; var root_562 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var root_566 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = body__0; var arg_570 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_571 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 10)).Ref(); if linked_567 == nil { arg_565 = ifn_568.Invoke_O_O_O__O(arg_569, arg_570, arg_571) } else { arg_565 = linked_567.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_566, arg_569, arg_570, arg_571) }; if linked_563 == nil { tmp4 = ifn_564.Invoke_O__O(arg_565) } else { tmp4 = linked_563.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_562, arg_565) }; tmp3.Invoke_O__O(tmp4); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 10); continue L1
//line :265:1
							break L2 }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_74) {







								jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(92)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
								break L2 }; case 97: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_79) {
									jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(7)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
									break L2 }; case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_80) {

										jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(8)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
										break L2 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_81) {


											jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(12)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
											break L2 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_82) {



												jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
												break L2 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_83) {




													jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(13)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
													break L2 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_84) {





														jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(9)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
														break L2 }; case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_85) {











															var tmp5 lang.IFn = lang.IFn_Cast(put_cp__4); var tmp6 any; var root_572 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var root_576 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = body__0; var arg_580 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_581 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 6)).Ref(); if linked_577 == nil { arg_575 = ifn_578.Invoke_O_O_O__O(arg_579, arg_580, arg_581) } else { arg_575 = linked_577.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_576, arg_579, arg_580, arg_581) }; if linked_573 == nil { tmp6 = ifn_574.Invoke_O__O(arg_575) } else { tmp6 = linked_573.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_572, arg_575) }; tmp5.Invoke_O__O(tmp6); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 6); continue L1
//line :265:1
															break L2 }; case 118: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_86) {






																jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(11)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :265:1
																break L2 }; case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000069__8_).Ref(), A_arbace_repr_go_lit_A_const_87) {










																	var tmp7 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp8 any; var root_582 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any; var root_586 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = body__0; var arg_590 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(); var arg_591 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref(); if linked_587 == nil { arg_585 = ifn_588.Invoke_O_O_O__O(arg_589, arg_590, arg_591) } else { arg_585 = linked_587.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_586, arg_589, arg_590, arg_591) }; if linked_583 == nil { tmp8 = ifn_584.Invoke_O__O(arg_585) } else { tmp8 = linked_583.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_582, arg_585) }; tmp7.Write_I__V(lang.RT_IntCast_O__I_NoInit(tmp8)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1
//line :265:1
																	break L2 }; default:
				}












					var tmp9 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp10 any; var root_592 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = body__0; var arg_596 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)).Ref(); var arg_597 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref(); if linked_593 == nil { tmp10 = ifn_594.Invoke_O_O_O__O(arg_595, arg_596, arg_597) } else { tmp10 = linked_593.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_592, arg_595, arg_596, arg_597) }; tmp9.Write_I__V(lang.RT_IntCast_J__I_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp10), lang.RT_IntCast_J__I_NoInit(8))))
					i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1} } }
//line :249:1
		break L1 }; return out__2 }




func A_arbace_repr_go_lit_unescape_put_cp__790000067_A_New_O(p0 any) *A_arbace_repr_go_lit_unescape_put_cp__790000067_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_put_cp__790000067_A{}; t.Ctor_O(p0); return t }
//line :254:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000067_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :254:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000067_A) Invoke_O_O__O(self, cp__1 any) any { var bs__2 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_O__I_NoInit(cp__1))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var tmp1 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(t.F_out);

	tmp1.Write_B1_I_I__V(jrt.ByteArray_Cast(bs__2), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(bs__2))); return nil }


























func A_arbace_repr_go_lit_string_bytes_A_New() *A_arbace_repr_go_lit_string_bytes_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_bytes_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Ctor() {}
//line :283:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Invoke_O_O__O(self, text__0 any) any {


	var tmp1 any; var root_598 any = A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = text__0; var arg_602 any = Lit_33; if linked_599 == nil { tmp1 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { tmp1 = linked_599.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_603 any = A_arbace_repr_go_lit_A_const_30.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var root_609 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = text__0; var arg_613 any = A_arbace_repr_go_lit_A_const_40; var arg_614 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_610 == nil { arg_606 = ifn_611.Invoke_O_O_O__O(arg_612, arg_613, arg_614) } else { arg_606 = linked_610.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_609, arg_612, arg_613, arg_614) }; var arg_607 any = Lit_34; var arg_608 any = Lit_23; if linked_604 == nil { tmp2 = ifn_605.Invoke_O_O_O__O(arg_606, arg_607, arg_608) } else { tmp2 = linked_604.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_603, arg_606, arg_607, arg_608) }; return jrt.NN(jrt.String_Cast(tmp2)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
			var tmp3 any; var root_615 any = A_arbace_repr_go_lit_A_const_88.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_repr_go_lit_unescape_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var root_619 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = text__0; var arg_623 any = A_arbace_repr_go_lit_A_const_40; var arg_624 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_620 == nil { arg_618 = ifn_621.Invoke_O_O_O__O(arg_622, arg_623, arg_624) } else { arg_618 = linked_620.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_619, arg_622, arg_623, arg_624) }; if linked_616 == nil { tmp3 = ifn_617.Invoke_O__O(arg_618) } else { tmp3 = linked_616.(*A_arbace_repr_go_lit_unescape_A).Invoke_O_O__O(root_615, arg_618) }; return jrt.ByteArrayOutputStream_Cast(tmp3).ToByteArray__B1().Ref()
		} }
func A_arbace_repr_go_lit_rune_value_A_New() *A_arbace_repr_go_lit_rune_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_value_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_repr_go_lit_rune_value_A) Ctor() {}
//line :290:1
func (t *A_arbace_repr_go_lit_rune_value_A) Invoke_O_O__O(self, text__0 any) any { var body__2 any; var root_625 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_627 lang.IFn; if


	linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = text__0; var arg_629 any = A_arbace_repr_go_lit_A_const_40; var arg_630 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref(); if linked_626 == nil { body__2 = ifn_627.Invoke_O_O_O__O(arg_628, arg_629, arg_630) } else { body__2 = linked_626.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_625, arg_628, arg_629, arg_630) }; var tmp1 any; var root_631 any =
	A_arbace_repr_go_lit_A_const_32.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = body__2; var arg_635 any = Lit_5; if linked_632 == nil { tmp1 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { tmp1 = linked_632.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }; if jrt.J2g_Truth(tmp1) { var G__790000072__3_ uint16 = jrt.NN(jrt.String_Cast(body__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(1))
		switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref()) { case 48: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_89) {



			var tmp2 any; var root_637 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = body__2; var arg_641 any = A_arbace_repr_go_lit_A_const_40; if linked_638 == nil { tmp2 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { tmp2 = linked_638.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp2), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 49: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_90) {



			var tmp3 any; var root_642 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = body__2; var arg_646 any = A_arbace_repr_go_lit_A_const_40; if linked_643 == nil { tmp3 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { tmp3 = linked_643.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp3), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 50: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_91) {



			var tmp4 any; var root_647 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = body__2; var arg_651 any = A_arbace_repr_go_lit_A_const_40; if linked_648 == nil { tmp4 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { tmp4 = linked_648.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 51: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_92) {



			var tmp5 any; var root_652 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = body__2; var arg_656 any = A_arbace_repr_go_lit_A_const_40; if linked_653 == nil { tmp5 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { tmp5 = linked_653.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp5), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 52: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_93) {



			var tmp6 any; var root_661 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = body__2; var arg_665 any = A_arbace_repr_go_lit_A_const_40; if linked_662 == nil { tmp6 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { tmp6 = linked_662.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp6), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_94) {



			var tmp7 any; var root_666 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = body__2; var arg_670 any = A_arbace_repr_go_lit_A_const_40; if linked_667 == nil { tmp7 = ifn_668.Invoke_O_O__O(arg_669, arg_670) } else { tmp7 = linked_667.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_666, arg_669, arg_670) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp7), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 54: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_95) {



			var tmp8 any; var root_671 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = body__2; var arg_675 any = A_arbace_repr_go_lit_A_const_40; if linked_672 == nil { tmp8 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { tmp8 = linked_672.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp8), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 55: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_96) {



			var tmp9 any; var root_676 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = body__2; var arg_680 any = A_arbace_repr_go_lit_A_const_40; if linked_677 == nil { tmp9 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { tmp9 = linked_677.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp9), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :295:1
		case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_77) {


			var root_681 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any; var root_685 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = body__2; var arg_689 any = A_arbace_repr_go_lit_A_const_38; if linked_686 == nil { arg_684 = ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { arg_684 = linked_686.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_685, arg_688, arg_689) }; if linked_682 == nil { return ifn_683.Invoke_O__O(arg_684) } else { return linked_682.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_681, arg_684) } }
//line :295:1
		case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_85) {

			var root_690 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any; var root_694 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = body__2; var arg_698 any = A_arbace_repr_go_lit_A_const_38; if linked_695 == nil { arg_693 = ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { arg_693 = linked_695.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_694, arg_697, arg_698) }; if linked_691 == nil { return ifn_692.Invoke_O__O(arg_693) } else { return linked_691.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_690, arg_693) } }
//line :295:1
		case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000072__3_).Ref(), A_arbace_repr_go_lit_A_const_87) {
			var root_699 any = A_arbace_repr_go_lit_A_const_78.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, A_arbace_repr_go_lit_hexv_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_repr_go_lit_A_const_37.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = body__2; var arg_707 any = A_arbace_repr_go_lit_A_const_38; if linked_704 == nil { arg_702 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { arg_702 = linked_704.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; if linked_700 == nil { return ifn_701.Invoke_O__O(arg_702) } else { return linked_700.(*A_arbace_repr_go_lit_hexv_A).Invoke_O_O__O(root_699, arg_702) } }
//line :295:1
		default:}; var bs__4 any; var tmp10 any; var root_657 any = A_arbace_repr_go_lit_A_const_88.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_repr_go_lit_unescape_A_fn_class); var ifn_659 lang.IFn




		if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = body__2; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*A_arbace_repr_go_lit_unescape_A).Invoke_O_O__O(root_657, arg_660) }; bs__4 = jrt.ByteArrayOutputStream_Cast(tmp10).ToByteArray__B1().Ref()
		return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(bs__4), lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.String_Cast(body__2)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } }

func A_arbace_repr_go_lit_decode_rune_A_New() *A_arbace_repr_go_lit_decode_rune_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Ctor() {}
//line :304:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Invoke_O_O_O_O__O(self, bs__0, i__1, n__2 any) any { var b__4 any; var fnbody__709 any = A_arbace_repr_go_lit_decode_rune_b__790000074_A_New_O(bs__0); var tmp1 *jrt.Class; var fncls__708 *jrt.Class = A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class; if


	fncls__708 == nil { var fncls__708d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__709); A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class = fncls__708d; tmp1 = fncls__708d } else { tmp1 = fncls__708 }; b__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__709, tmp1, nil); var cont_QMARK___5 any; var fnbody__721 any = /*line :304:1*/A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_New_O_O(n__2, b__4); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class; if



	fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__721); A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; cont_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__721, tmp2, nil); var b0__6 any = /*line :304:1*/lang.IFn_Cast(b__4).Invoke_O__O(i__1); var tmp3 bool; var na_722 any = b0__6; var na_723 int64 = 128; if






	jrt.Long_InstanceOf(na_722) { var n0_724 int64 = jrt.NN(jrt.Long_Cast(na_722)).LongValue__J(); var n1_725 int64 = na_723; tmp3 = n0_724 < n1_725 } else { tmp3 = lang.Numbers_Lt_O_J__Z_NoInit(na_722, na_723) }; if tmp3 {
//line :310:1
		return lang.Tuple_Create_O_O__IPersistentVector(b0__6, A_arbace_repr_go_lit_A_const_40) } else { var tmp4 bool
			var na_727 any = b0__6; var na_728 int64 = 194
			if jrt.Long_InstanceOf(na_727) { var n0_729 int64 = jrt.NN(jrt.Long_Cast(na_727)).LongValue__J(); var n1_730 int64 = na_728; tmp4 = n0_729 < n1_730 } else { tmp4 = lang.Numbers_Lt_O_J__Z_NoInit(na_727, na_728) }
//line :310:1
			if tmp4 { return A_arbace_repr_go_lit_A_const_97 } else { var tmp5 bool
				var na_732 any = b0__6
				var na_733 int64 = 224
				if jrt.Long_InstanceOf(na_732) { var n0_734 int64 = jrt.NN(jrt.Long_Cast(na_732)).LongValue__J(); var n1_735 int64 = na_733; tmp5 = n0_734 < n1_735 } else { tmp5 = lang.Numbers_Lt_O_J__Z_NoInit(na_732, na_733) }
//line :310:1
				if tmp5 {


					var tmp6 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp7 jrt.Number_I; var na_781 any = i__1; if jrt.Long_InstanceOf(na_781) { var n0_782 int64 = jrt.NN(jrt.Long_Cast(na_781)).LongValue__J(); if n0_782 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_781) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_782 + 1)) } } else { if jrt.Double_InstanceOf(na_781) { var n0_782_2 float64 = jrt.NN(jrt.Double_Cast(na_781)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_782_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_781) } }; if jrt.J2g_Truth(tmp6.Invoke_O__O(tmp7)) { var tmp8 int64; var na_783 any = b0__6; var na_784 int64 = 31
						if jrt.Long_InstanceOf(na_783) { var n0_785 int64 = jrt.NN(jrt.Long_Cast(na_783)).LongValue__J(); var n1_786 int64 = na_784; tmp8 = n0_785 & n1_786 } else { tmp8 = lang.Numbers_And_O_J__J_NoInit(na_783, na_784) }
//line :313:1
						var tmp9 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp8, 6); var tmp10 int64; var na_788 any; var tmp11 lang.IFn = lang.IFn_Cast(b__4); var tmp12 jrt.Number_I; var na_793 any = i__1
						if jrt.Long_InstanceOf(na_793) { var n0_794 int64 = jrt.NN(jrt.Long_Cast(na_793)).LongValue__J(); if n0_794 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_793) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_794 + 1)) } } else { if jrt.Double_InstanceOf(na_793) { var n0_794_2 float64 = jrt.NN(jrt.Double_Cast(na_793)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_794_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_793) } }; na_788 = tmp11.Invoke_O__O(tmp12); var na_789 int64 = 63; if jrt.Long_InstanceOf(na_788) { var n0_790 int64 = jrt.NN(jrt.Long_Cast(na_788)).LongValue__J(); var n1_791 int64 = na_789; tmp10 = n0_790 & n1_791 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_788, na_789) }
//line :313:1
						return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp9, tmp10)).Ref(), A_arbace_repr_go_lit_A_const_38) } else { return A_arbace_repr_go_lit_A_const_98 } } else {
//line :310:1
							var tmp13 bool
							var na_737 any = b0__6
							var na_738 int64 = 240



							if jrt.Long_InstanceOf(na_737) { var n0_739 int64 = jrt.NN(jrt.Long_Cast(na_737)).LongValue__J(); var n1_740 int64 = na_738; tmp13 = n0_739 < n1_740 } else { tmp13 = lang.Numbers_Lt_O_J__Z_NoInit(na_737, na_738) }
//line :310:1
							if tmp13 { var lo__7 int64; var tmp14 int32; var G__790000078__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)





							L1: switch { default: switch G__790000078__7_ { case 224: tmp14 = 160; break L1; default:}; tmp14 = 128}
//line :310:1
								lo__7 = int64(tmp14); var hi__8 int64; var tmp15 int32; var G__790000079__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)






							L2: switch { default: switch G__790000079__8_ { case 237: tmp15 = 159; break L2; default:}; tmp15 = 191}
//line :310:1
								hi__8 = int64(tmp15)







								var tmp16 any; var and__1927000168__auto____9 bool; var na_744 any; var na_746 any = i__1; if jrt.Long_InstanceOf(na_746) { var n0_747 int64 = jrt.NN(jrt.Long_Cast(na_746)).LongValue__J(); if n0_747 == 9223372036854775807 { na_744 = lang.Numbers_Inc_O__Number_NoInit(na_746) } else { na_744 = jrt.Long_ValueOf_J__Long_NoInit(n0_747 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_746) { var n0_747_2 float64 = jrt.NN(jrt.Double_Cast(na_746)).DoubleValue__D(); na_744 = jrt.Double_ValueOf_D__Double_NoInit(n0_747_2 + 1.0).Ref() } else { na_744 = lang.Numbers_Inc_O__Number_NoInit(na_746) } }; var na_745 any = n__2; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_744); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_745) }; tmp17 = tmp18; if tmp17 { var n0_748 int64 = jrt.NN(jrt.Long_Cast(na_744)).LongValue__J(); var n1_749 int64 = jrt.NN(jrt.Long_Cast(na_745)).LongValue__J(); and__1927000168__auto____9 = n0_748 < n1_749 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_744); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_745) }; tmp19 = tmp20; if tmp19 { var n0_748_2 float64 = jrt.NN(jrt.Double_Cast(na_744)).DoubleValue__D(); var n1_749_2 float64 = jrt.NN(jrt.Double_Cast(na_745)).DoubleValue__D(); and__1927000168__auto____9 = n0_748_2 < n1_749_2 } else { and__1927000168__auto____9 = lang.Numbers_Lt_O_O__Z_NoInit(na_744, na_745) } }; if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp22 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(b__4); var tmp24 jrt.Number_I; var na_757 any = i__1; if jrt.Long_InstanceOf(na_757) { var n0_758 int64 = jrt.NN(jrt.Long_Cast(na_757)).LongValue__J(); if n0_758 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_757) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_758 + 1)) } } else { if jrt.Double_InstanceOf(na_757) { var n0_758_2 float64 = jrt.NN(jrt.Double_Cast(na_757)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_758_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_757) } }; and__1927000168__auto____10 = tmp21.Invoke_O_O_O__O(tmp22, tmp23.Invoke_O__O(tmp24), jrt.Long_ValueOf_J__Long_NoInit(hi__8).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp25 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp26 jrt.Number_I; var na_795 any = i__1; var na_796 int64 = 2; if jrt.Long_InstanceOf(na_795) { var n0_797 int64 = jrt.NN(jrt.Long_Cast(na_795)).LongValue__J(); var n1_798 int64 = na_796; var nr_799 int64 = n0_797 + n1_798; if (n0_797^nr_799)&(n1_798^nr_799) >= 0 { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_799)) } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_795, na_796) } } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_795, na_796) }; tmp16 = tmp25.Invoke_O__O(tmp26) } else { tmp16 = and__1927000168__auto____10 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp16) { var tmp27 int64; var na_800 any = b0__6; var na_801 int64 = 15
									if jrt.Long_InstanceOf(na_800) { var n0_802 int64 = jrt.NN(jrt.Long_Cast(na_800)).LongValue__J(); var n1_803 int64 = na_801; tmp27 = n0_802 & n1_803 } else { tmp27 = lang.Numbers_And_O_J__J_NoInit(na_800, na_801) }
//line :318:1
									var tmp28 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp27, 12); var tmp29 int64; var na_805 any; var tmp30 lang.IFn = lang.IFn_Cast(b__4); var tmp31 jrt.Number_I
									var na_815 any = i__1
									if jrt.Long_InstanceOf(na_815) { var n0_816 int64 = jrt.NN(jrt.Long_Cast(na_815)).LongValue__J(); if n0_816 == 9223372036854775807 { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_815) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_816 + 1)) } } else { if jrt.Double_InstanceOf(na_815) { var n0_816_2 float64 = jrt.NN(jrt.Double_Cast(na_815)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_816_2 + 1.0)) } else { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_815) } }; na_805 = tmp30.Invoke_O__O(tmp31); var na_806 int64 = 63; if jrt.Long_InstanceOf(na_805) { var n0_807 int64 = jrt.NN(jrt.Long_Cast(na_805)).LongValue__J(); var n1_808 int64 = na_806; tmp29 = n0_807 & n1_808 } else { tmp29 = lang.Numbers_And_O_J__J_NoInit(na_805, na_806) }
//line :318:1
									var tmp32 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp28, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp29, 6)); var tmp33 int64; var na_810 any; var tmp34 lang.IFn = lang.IFn_Cast(b__4); var tmp35 jrt.Number_I
									var na_817 any = i__1
									var na_818 int64 = 2
									if jrt.Long_InstanceOf(na_817) { var n0_819 int64 = jrt.NN(jrt.Long_Cast(na_817)).LongValue__J(); var n1_820 int64 = na_818; var nr_821 int64 = n0_819 + n1_820; if (n0_819^nr_821)&(n1_820^nr_821) >= 0 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_821)) } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_817, na_818) } } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_817, na_818) }; na_810 = tmp34.Invoke_O__O(tmp35); var na_811 int64 = 63; if jrt.Long_InstanceOf(na_810) { var n0_812 int64 = jrt.NN(jrt.Long_Cast(na_810)).LongValue__J(); var n1_813 int64 = na_811; tmp33 = n0_812 & n1_813 } else { tmp33 = lang.Numbers_And_O_J__J_NoInit(na_810, na_811) }
//line :318:1
									return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp32, tmp33)).Ref(), A_arbace_repr_go_lit_A_const_102) } else { return A_arbace_repr_go_lit_A_const_99 } } else {
//line :310:1
										var tmp36 bool
										var na_759 any = b0__6
										var na_760 int64 = 245










										if jrt.Long_InstanceOf(na_759) { var n0_761 int64 = jrt.NN(jrt.Long_Cast(na_759)).LongValue__J(); var n1_762 int64 = na_760; tmp36 = n0_761 < n1_762 } else { tmp36 = lang.Numbers_Lt_O_J__Z_NoInit(na_759, na_760) }
//line :310:1
										if tmp36 { var lo__7_2 int64; var tmp37 int32; var G__790000080__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)












										L3: switch { default: switch G__790000080__7_ { case 240: tmp37 = 144; break L3; default:}; tmp37 = 128}
//line :310:1
											lo__7_2 = int64(tmp37); var hi__8_2 int64; var tmp38 int32; var G__790000081__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)













										L4: switch { default: switch G__790000081__8_ { case 244: tmp38 = 143; break L4; default:}; tmp38 = 191}
//line :310:1
											hi__8_2 = int64(tmp38)














											var tmp39 any; var and__1927000168__auto____9_2 bool; var na_766 any; var na_768 any = i__1; if jrt.Long_InstanceOf(na_768) { var n0_769 int64 = jrt.NN(jrt.Long_Cast(na_768)).LongValue__J(); if n0_769 == 9223372036854775807 { na_766 = lang.Numbers_Inc_O__Number_NoInit(na_768) } else { na_766 = jrt.Long_ValueOf_J__Long_NoInit(n0_769 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_768) { var n0_769_2 float64 = jrt.NN(jrt.Double_Cast(na_768)).DoubleValue__D(); na_766 = jrt.Double_ValueOf_D__Double_NoInit(n0_769_2 + 1.0).Ref() } else { na_766 = lang.Numbers_Inc_O__Number_NoInit(na_768) } }; var na_767 any = n__2; var tmp40 bool; var tmp41 bool; tmp41 = jrt.Long_InstanceOf(na_766); if tmp41 { tmp41 = jrt.Long_InstanceOf(na_767) }; tmp40 = tmp41; if tmp40 { var n0_770 int64 = jrt.NN(jrt.Long_Cast(na_766)).LongValue__J(); var n1_771 int64 = jrt.NN(jrt.Long_Cast(na_767)).LongValue__J(); and__1927000168__auto____9_2 = n0_770 < n1_771 } else { var tmp42 bool; var tmp43 bool; tmp43 = jrt.Double_InstanceOf(na_766); if tmp43 { tmp43 = jrt.Double_InstanceOf(na_767) }; tmp42 = tmp43; if tmp42 { var n0_770_2 float64 = jrt.NN(jrt.Double_Cast(na_766)).DoubleValue__D(); var n1_771_2 float64 = jrt.NN(jrt.Double_Cast(na_767)).DoubleValue__D(); and__1927000168__auto____9_2 = n0_770_2 < n1_771_2 } else { and__1927000168__auto____9_2 = lang.Numbers_Lt_O_O__Z_NoInit(na_766, na_767) } }; if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp45 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7_2).Ref(); var tmp46 lang.IFn = lang.IFn_Cast(b__4); var tmp47 jrt.Number_I; var na_779 any = i__1; if jrt.Long_InstanceOf(na_779) { var n0_780 int64 = jrt.NN(jrt.Long_Cast(na_779)).LongValue__J(); if n0_780 == 9223372036854775807 { tmp47 = lang.Numbers_Inc_O__Number_NoInit(na_779) } else { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_780 + 1)) } } else { if jrt.Double_InstanceOf(na_779) { var n0_780_2 float64 = jrt.NN(jrt.Double_Cast(na_779)).DoubleValue__D(); tmp47 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_780_2 + 1.0)) } else { tmp47 = lang.Numbers_Inc_O__Number_NoInit(na_779) } }; and__1927000168__auto____10_2 = tmp44.Invoke_O_O_O__O(tmp45, tmp46.Invoke_O__O(tmp47), jrt.Long_ValueOf_J__Long_NoInit(hi__8_2).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any; var tmp48 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp49 jrt.Number_I; var na_822 any = i__1; var na_823 int64 = 2; if jrt.Long_InstanceOf(na_822) { var n0_824 int64 = jrt.NN(jrt.Long_Cast(na_822)).LongValue__J(); var n1_825 int64 = na_823; var nr_826 int64 = n0_824 + n1_825; if (n0_824^nr_826)&(n1_825^nr_826) >= 0 { tmp49 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_826)) } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_822, na_823) } } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_822, na_823) }; and__1927000168__auto____11 = tmp48.Invoke_O__O(tmp49); if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp50 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp51 jrt.Number_I; var na_827 any = i__1; var na_828 int64 = 3; if jrt.Long_InstanceOf(na_827) { var n0_829 int64 = jrt.NN(jrt.Long_Cast(na_827)).LongValue__J(); var n1_830 int64 = na_828; var nr_831 int64 = n0_829 + n1_830; if (n0_829^nr_831)&(n1_830^nr_831) >= 0 { tmp51 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_831)) } else { tmp51 = lang.Numbers_Add_O_J__Number_NoInit(na_827, na_828) } } else { tmp51 = lang.Numbers_Add_O_J__Number_NoInit(na_827, na_828) }; tmp39 = tmp50.Invoke_O__O(tmp51) } else { tmp39 = and__1927000168__auto____11 } } else { tmp39 = and__1927000168__auto____10_2 } } else { tmp39 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }; if jrt.J2g_Truth(tmp39) { var tmp52 int64; var na_832 any = b0__6; var na_833 int64 = 7
												if jrt.Long_InstanceOf(na_832) { var n0_834 int64 = jrt.NN(jrt.Long_Cast(na_832)).LongValue__J(); var n1_835 int64 = na_833; tmp52 = n0_834 & n1_835 } else { tmp52 = lang.Numbers_And_O_J__J_NoInit(na_832, na_833) }
//line :325:1
												var tmp53 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp52, 18); var tmp54 int64; var na_837 any; var tmp55 lang.IFn = lang.IFn_Cast(b__4); var tmp56 jrt.Number_I
												var na_852 any = i__1
												if jrt.Long_InstanceOf(na_852) { var n0_853 int64 = jrt.NN(jrt.Long_Cast(na_852)).LongValue__J(); if n0_853 == 9223372036854775807 { tmp56 = lang.Numbers_Inc_O__Number_NoInit(na_852) } else { tmp56 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_853 + 1)) } } else { if jrt.Double_InstanceOf(na_852) { var n0_853_2 float64 = jrt.NN(jrt.Double_Cast(na_852)).DoubleValue__D(); tmp56 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_853_2 + 1.0)) } else { tmp56 = lang.Numbers_Inc_O__Number_NoInit(na_852) } }; na_837 = tmp55.Invoke_O__O(tmp56); var na_838 int64 = 63; if jrt.Long_InstanceOf(na_837) { var n0_839 int64 = jrt.NN(jrt.Long_Cast(na_837)).LongValue__J(); var n1_840 int64 = na_838; tmp54 = n0_839 & n1_840 } else { tmp54 = lang.Numbers_And_O_J__J_NoInit(na_837, na_838) }
//line :325:1
												var tmp57 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp53, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp54, 12)); var tmp58 int64; var na_842 any; var tmp59 lang.IFn = lang.IFn_Cast(b__4); var tmp60 jrt.Number_I
												var na_854 any = i__1
												var na_855 int64 = 2
												if jrt.Long_InstanceOf(na_854) { var n0_856 int64 = jrt.NN(jrt.Long_Cast(na_854)).LongValue__J(); var n1_857 int64 = na_855; var nr_858 int64 = n0_856 + n1_857; if (n0_856^nr_858)&(n1_857^nr_858) >= 0 { tmp60 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_858)) } else { tmp60 = lang.Numbers_Add_O_J__Number_NoInit(na_854, na_855) } } else { tmp60 = lang.Numbers_Add_O_J__Number_NoInit(na_854, na_855) }; na_842 = tmp59.Invoke_O__O(tmp60); var na_843 int64 = 63; if jrt.Long_InstanceOf(na_842) { var n0_844 int64 = jrt.NN(jrt.Long_Cast(na_842)).LongValue__J(); var n1_845 int64 = na_843; tmp58 = n0_844 & n1_845 } else { tmp58 = lang.Numbers_And_O_J__J_NoInit(na_842, na_843) }
//line :325:1
												var tmp61 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp57, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp58, 6)); var tmp62 int64; var na_847 any; var tmp63 lang.IFn = lang.IFn_Cast(b__4); var tmp64 jrt.Number_I
												var na_859 any = i__1
												var na_860 int64 = 3

												if jrt.Long_InstanceOf(na_859) { var n0_861 int64 = jrt.NN(jrt.Long_Cast(na_859)).LongValue__J(); var n1_862 int64 = na_860; var nr_863 int64 = n0_861 + n1_862; if (n0_861^nr_863)&(n1_862^nr_863) >= 0 { tmp64 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_863)) } else { tmp64 = lang.Numbers_Add_O_J__Number_NoInit(na_859, na_860) } } else { tmp64 = lang.Numbers_Add_O_J__Number_NoInit(na_859, na_860) }; na_847 = tmp63.Invoke_O__O(tmp64); var na_848 int64 = 63; if jrt.Long_InstanceOf(na_847) { var n0_849 int64 = jrt.NN(jrt.Long_Cast(na_847)).LongValue__J(); var n1_850 int64 = na_848; tmp62 = n0_849 & n1_850 } else { tmp62 = lang.Numbers_And_O_J__J_NoInit(na_847, na_848) }
//line :325:1
												return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp61, tmp62)).Ref(), A_arbace_repr_go_lit_A_const_103) } else { return A_arbace_repr_go_lit_A_const_100 } } else {
//line :310:1
													if A_arbace_repr_go_lit_A_const_22 != nil { return A_arbace_repr_go_lit_A_const_101 } else { return nil } } } } } } }
//line :307:1
func A_arbace_repr_go_lit_decode_rune_b__790000074_A_New_O(p0 any) *A_arbace_repr_go_lit_decode_rune_b__790000074_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_b__790000074_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000074_A) Ctor_O(c__bs any) { t.F_bs = c__bs }
//line :307:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000074_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *jrt.ByteArray = jrt.ByteArray_Cast(t.F_bs); return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(k__1)))))).Ref() }
func A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :308:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A) Ctor_O_O(c__n, c__b any) { t.F_n = c__n; t.F_b = c__b }
//line :308:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A) Invoke_O_O__O(self, k__1 any) any { var and__1927000168__auto____2 bool; var na_710 any = k__1; var na_711 any = t.F_n; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_710); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_711) }; tmp1 = tmp2; if tmp1 { var n0_712 int64 = jrt.NN(jrt.Long_Cast(na_710)).LongValue__J(); var n1_713 int64 = jrt.NN(jrt.Long_Cast(na_711)).LongValue__J(); and__1927000168__auto____2 = n0_712 < n1_713 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_710); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_711) }; tmp3 = tmp4; if tmp3 { var n0_712_2 float64 = jrt.NN(jrt.Double_Cast(na_710)).DoubleValue__D(); var n1_713_2 float64 = jrt.NN(jrt.Double_Cast(na_711)).DoubleValue__D(); and__1927000168__auto____2 = n0_712_2 < n1_713_2 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_O__Z_NoInit(na_710, na_711) } }; if and__1927000168__auto____2 { var tmp5 int64; var na_715 any = lang.IFn_Cast(t.F_b).Invoke_O__O(k__1); var na_716 int64 = 192; if jrt.Long_InstanceOf(na_715) { var n0_717 int64 = jrt.NN(jrt.Long_Cast(na_715)).LongValue__J(); var n1_718 int64 = na_716; tmp5 = n0_717 & n1_718 } else { tmp5 = lang.Numbers_And_O_J__J_NoInit(na_715, na_716) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(128, tmp5)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
























func A_arbace_repr_go_lit_utf8_parts_A_New() *A_arbace_repr_go_lit_utf8_parts_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_utf8_parts_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Ctor() {}
//line :333:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Invoke_O_O__O(self, bs__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(bs__0)); var i__3 int64 = 0; var run__4 any = jrt.StringBuilder_New(); var parts__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_J_J__Z_NoInit(i__3, int64(n__2)) {
		if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) { var root_864 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = parts__5; var arg_868 any; var root_869 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = run__4; if linked_870 == nil { arg_868 = ifn_871.Invoke_O__O(arg_872) } else { arg_868 = linked_870.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_869, arg_872) }; if linked_865 == nil { return ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { return linked_865.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) } } else { return parts__5 } } else {
//line :338:1
			var vec__790000083__6 any; var root_873 any = A_arbace_repr_go_lit_A_const_104.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, A_arbace_repr_go_lit_decode_rune_A_fn_class); var ifn_875 lang.IFn

			if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = bs__0; var arg_877 any = jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref(); var arg_878 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref(); if linked_874 == nil { vec__790000083__6 = ifn_875.Invoke_O_O_O__O(arg_876, arg_877, arg_878) } else { vec__790000083__6 = linked_874.(*A_arbace_repr_go_lit_decode_rune_A).Invoke_O_O_O_O__O(root_873, arg_876, arg_877, arg_878) }
//line :338:1
			var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000083__6, lang.RT_IntCast_J__I_NoInit(0), nil); var w__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000083__6, lang.RT_IntCast_J__I_NoInit(1), nil)


			if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(r__7)) {
				var tmp1 int64 = lang.Numbers_Inc_J__J_NoInit(i__3); var tmp2 any = jrt.StringBuilder_New(); var tmp3 any; var G__790000086__9_ any = parts__5; var G__790000086__10_ any
				if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) {
					var root_879 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = G__790000086__9_; var arg_883 any; var root_884 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = run__4; if linked_885 == nil { arg_883 = ifn_886.Invoke_O__O(arg_887) } else { arg_883 = linked_885.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_884, arg_887) }; if linked_880 == nil { G__790000086__10_ = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { G__790000086__10_ = linked_880.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) } } else {
//line :343:1
						G__790000086__10_ = G__790000086__9_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {

							var root_888 any = A_arbace_repr_go_lit_A_const_7.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = G__790000086__10_; var arg_892 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(bs__0), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__3)))))).Ref(); if linked_889 == nil { tmp3 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { tmp3 = linked_889.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) } } else {
//line :343:1
								tmp3 = G__790000086__10_ }
//line :342:1
				i__3, run__4, parts__5 = tmp1, tmp2, tmp3; continue L1 } else {



					i__3, run__4, parts__5 = lang.Numbers_Add_J_J__J_NoInit(i__3, lang.RT_LongCast_O__J_NoInit(w__8)), jrt.NN(jrt.StringBuilder_Cast(run__4)).AppendCodePoint_I__StringBuilder(lang.RT_IntCast_O__I_NoInit(r__7)).Ref(), parts__5; continue L1 } } } }; /*line :333:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_lit_rune_form_A_New() *A_arbace_repr_go_lit_rune_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_form_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_repr_go_lit_rune_form_A) Ctor() {}
//line :348:1
func (t *A_arbace_repr_go_lit_rune_form_A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var tmp1 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_lit_A_const_62; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_105); if




	jrt.J2g_Truth(and__1927000168__auto____3) { var root_899 any = A_arbace_repr_go_lit_A_const_11.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_lit_A_const_106; var arg_902 any = tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_107); if linked_900 == nil { tmp1 = ifn_901.Invoke_O__O(arg_902) } else { tmp1 = linked_900.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_899, arg_902) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var root_909 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var root_914 any = A_arbace_repr_go_lit_A_const_108.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_repr_go_lit_char_text_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_915 == nil { arg_912 = ifn_916.Invoke_O__O(arg_917) } else { arg_912 = linked_915.(*A_arbace_repr_go_lit_char_text_A).Invoke_O_O__O(root_914, arg_917) }; var arg_913 any = jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(cp__2)).Ref(); if linked_910 == nil { return ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { return linked_910.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) } } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_109.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_lit_A_const_110; var tmp8 any; var root_918 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; if lang.Numbers_IsNeg_J__Z_NoInit(cp__2) { var root_923 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_924 == nil { arg_921 = ifn_925.Invoke_O__O(arg_926) } else { arg_921 = linked_924.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_923, arg_926) } } else { arg_921 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_32, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref()) }; var arg_922 any = jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(); if linked_919 == nil { tmp8 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { tmp8 = linked_919.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } }

func A_arbace_repr_go_lit_bytes_form_A_New() *A_arbace_repr_go_lit_bytes_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Ctor() {}
//line :357:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Invoke_O_O__O(self, bs__0 any) any { var parts__2 any; var root_932 any = A_arbace_repr_go_lit_A_const_111.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, A_arbace_repr_go_lit_utf8_parts_A_fn_class); var ifn_934 lang.IFn; if


	linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = bs__0; if linked_933 == nil { parts__2 = ifn_934.Invoke_O__O(arg_935) } else { parts__2 = linked_933.(*A_arbace_repr_go_lit_utf8_parts_A).Invoke_O_O__O(root_932, arg_935) }; var tmp1 any; var root_936 any =
	A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var arg_940 any = parts__2; if linked_937 == nil { tmp1 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { tmp1 = linked_937.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; if jrt.J2g_Truth(tmp1) { var s__3 any; var root_941 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_943 lang.IFn
		if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var arg_945 any = parts__2; if linked_942 == nil { s__3 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { s__3 = linked_942.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }; var root_946 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_951 any = A_arbace_repr_go_lit_A_const_115.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = s__3; if linked_952 == nil { arg_949 = ifn_953.Invoke_O__O(arg_954) } else { arg_949 = linked_952.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_951, arg_954) }; var arg_950 any = s__3; if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else {
			var root_955 any = A_arbace_repr_go_lit_A_const_114.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = A_arbace_repr_go_lit_A_const_109.GetRawRoot__O(); var arg_959 any = A_arbace_repr_go_lit_A_const_116; var arg_960 any; var iter__1927001039__auto____3 any; var fnbody__1068 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_New(); var tmp2 *jrt.Class; var fncls__1067 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class
			if fncls__1067 == nil { var fncls__1067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class = fncls__1067d; tmp2 = fncls__1067d } else { tmp2 = fncls__1067 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1068, tmp2, nil); arg_960 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(parts__2)
//line :363:1
			if linked_956 == nil { return ifn_957.Invoke_O_O_O__O(arg_958, arg_959, arg_960) } else { return linked_956.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_955, arg_958, arg_959, arg_960) } } }
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_New() *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A) Ctor() {}
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A) Invoke_O_O__O(self, s__790000090__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1066 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_New_O_O(s__790000090__1, self); var tmp2 *jrt.Class; var fncls__1065 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class; if fncls__1065 == nil { var fncls__1065d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__1066); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class = fncls__1065d; tmp2 = fncls__1065d } else { tmp2 = fncls__1065 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1066, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :364:1
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A) Ctor_O_O(c__s__790000090, c__iter__790000089 any) { t.F_s__790000090 = c__s__790000090; t.F_iter__790000089 = c__iter__790000089 }
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A) Invoke_O__O(self any) any { { var s__790000090__1 any; var t_ any = t.F_s__790000090; t.F_s__790000090 = nil; s__790000090__1 = t_; for { var temp__1927000414__auto____2 any; var root_961 any = A_arbace_repr_go_lit_A_const_23.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = s__790000090__1; if linked_962 == nil { temp__1927000414__auto____2 = ifn_963.Invoke_O__O(arg_964) } else { temp__1927000414__auto____2 = linked_962.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_961, arg_964) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__790000090__3 any = temp__1927000414__auto____2; var tmp1 any; var root_965 any = A_arbace_repr_go_lit_A_const_24.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = s__790000090__3; if linked_966 == nil { tmp1 = ifn_967.Invoke_O__O(arg_968) } else { tmp1 = linked_966.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_965, arg_968) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_969 any = A_arbace_repr_go_lit_A_const_25.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__790000090__3; if linked_970 == nil { c__1927001037__auto____4 = ifn_971.Invoke_O__O(arg_972) } else { c__1927001037__auto____4 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_969, arg_972) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__790000092__6 any; var root_973 any = A_arbace_repr_go_lit_A_const_117.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_974 == nil { b__790000092__6 = ifn_975.Invoke_O__O(arg_976) } else { b__790000092__6 = linked_974.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_973, arg_976) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1006 any = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__790000092__6); var tmp3 *jrt.Class; var fncls__1005 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class; if fncls__1005 == nil { var fncls__1005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__1006); A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class = fncls__1005d; tmp3 = fncls__1005d } else { tmp3 = fncls__1005 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1006, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1007 any = A_arbace_repr_go_lit_A_const_119.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any; var root_1012 any = A_arbace_repr_go_lit_A_const_120.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = b__790000092__6; if linked_1013 == nil { arg_1010 = ifn_1014.Invoke_O__O(arg_1015) } else { arg_1010 = linked_1013.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1012, arg_1015) }; var arg_1011 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__790000089); var tmp5 any; var root_1016 any = A_arbace_repr_go_lit_A_const_27.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__790000090__3; if linked_1017 == nil { tmp5 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp5 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1016, arg_1019) }; arg_1011 = tmp4.Invoke_O__O(tmp5); if linked_1008 == nil { return ifn_1009.Invoke_O_O__O(arg_1010, arg_1011) } else { return linked_1008.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1007, arg_1010, arg_1011) } } else { var root_1020 any = A_arbace_repr_go_lit_A_const_119.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var root_1025 any = A_arbace_repr_go_lit_A_const_120.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = b__790000092__6; if linked_1026 == nil { arg_1023 = ifn_1027.Invoke_O__O(arg_1028) } else { arg_1023 = linked_1026.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1025, arg_1028) }; var arg_1024 any; if linked_1021 == nil { return ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) } } } else { var p__4 any; var root_1029 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = s__790000090__3; if linked_1030 == nil { p__4 = ifn_1031.Invoke_O__O(arg_1032) } else { p__4 = linked_1030.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1029, arg_1032) }; var root_1033 any = A_arbace_repr_go_lit_A_const_121.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any; var tmp6 any; var root_1038 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1040 lang.IFn
														if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = p__4; if linked_1039 == nil { tmp6 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp6 = linked_1039.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1038, arg_1041) }; if jrt.J2g_Truth(tmp6) { var root_1042 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var root_1047 any = A_arbace_repr_go_lit_A_const_115.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = p__4; if linked_1048 == nil { arg_1045 = ifn_1049.Invoke_O__O(arg_1050) } else { arg_1045 = linked_1048.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1047, arg_1050) }; var arg_1046 any = p__4; if linked_1043 == nil { arg_1036 = ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { arg_1036 = linked_1043.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } } else { var root_1051 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref()); var arg_1055 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref(); if linked_1052 == nil { arg_1036 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { arg_1036 = linked_1052.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) } }
//line :364:1
	var arg_1037 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__790000089); var tmp8 any; var root_1061 any = A_arbace_repr_go_lit_A_const_122.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = s__790000090__3; if linked_1062 == nil { tmp8 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp8 = linked_1062.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1061, arg_1064) }; arg_1037 = tmp7.Invoke_O__O(tmp8); if linked_1034 == nil { return ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { return linked_1034.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :364:1
func A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__790000092 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__790000092 = c__b__790000092 }
//line :364:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A) Invoke_O__O(self any) any { { var i__790000091__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__790000091__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__790000091__1)); var root_977 any = A_arbace_repr_go_lit_A_const_118.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = t.F_b__790000092; var arg_981 any; var tmp2 any; var root_982 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_984 lang.IFn
																if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = p__2; if linked_983 == nil { tmp2 = ifn_984.Invoke_O__O(arg_985) } else { tmp2 = linked_983.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_982, arg_985) }; if jrt.J2g_Truth(tmp2) { var root_986 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any; var root_991 any = A_arbace_repr_go_lit_A_const_115.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = p__2; if linked_992 == nil { arg_989 = ifn_993.Invoke_O__O(arg_994) } else { arg_989 = linked_992.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_991, arg_994) }; var arg_990 any = p__2; if linked_987 == nil { arg_981 = ifn_988.Invoke_O_O__O(arg_989, arg_990) } else { arg_981 = linked_987.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_986, arg_989, arg_990) } } else { var root_995 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_21.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref()); var arg_999 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref(); if linked_996 == nil { arg_981 = ifn_997.Invoke_O_O__O(arg_998, arg_999) } else { arg_981 = linked_996.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_995, arg_998, arg_999) } }
//line :364:1
	if linked_978 == nil { ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { linked_978.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }; i__790000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__790000091__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_lit_val_rational_A_New() *A_arbace_repr_go_lit_val_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_val_rational_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_repr_go_lit_val_rational_A) Ctor() {}
//line :369:1
func (t *A_arbace_repr_go_lit_val_rational_A) Invoke_O_O__O(self, v__0 any) any {


	var tmp1 any; var root_1069 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1071 lang.IFn
	if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = v__0; if linked_1070 == nil { tmp1 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp1 = linked_1070.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1069, arg_1072) }
//line :372:1
	if jrt.J2g_Truth(tmp1) { return v__0 } else { var tmp2 any; var and__1927000168__auto____2 any; var root_1073 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1075 lang.IFn

		if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = v__0; if linked_1074 == nil { and__1927000168__auto____2 = ifn_1075.Invoke_O__O(arg_1076) } else { and__1927000168__auto____2 = linked_1074.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1073, arg_1076) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp3 any = A_arbace_repr_go_lit_A_const_125; var tmp4 any; var root_1077 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = v__0; if linked_1078 == nil { tmp4 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp4 = linked_1078.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1077, arg_1080) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____3 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp2 = and__1927000168__auto____2 }
//line :372:1
		if jrt.J2g_Truth(tmp2) {

			var root_1081 any = A_arbace_repr_go_lit_A_const_126.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = v__0; if linked_1082 == nil { return ifn_1083.Invoke_O__O(arg_1084) } else { return linked_1082.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1081, arg_1084) } } else {
//line :372:1
				var tmp5 any; var and__1927000168__auto____2_2 any; var root_1085 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1087 lang.IFn


				if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = v__0; if linked_1086 == nil { and__1927000168__auto____2_2 = ifn_1087.Invoke_O__O(arg_1088) } else { and__1927000168__auto____2_2 = linked_1086.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp6 any = A_arbace_repr_go_lit_A_const_125; var tmp7 any; var root_1089 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = v__0; if linked_1090 == nil { tmp7 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp7 = linked_1090.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1089, arg_1092) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7)).Ref() } else { tmp5 = and__1927000168__auto____2_2 }
//line :372:1
				if jrt.J2g_Truth(tmp5) { var vec__790000100__2 any = v__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000100__2, lang.RT_IntCast_J__I_NoInit(2), nil); var m__6 any; var root_1093 any = A_arbace_repr_go_lit_A_const_35.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_1095 lang.IFn; _ = ___3




					if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = m__4; if linked_1094 == nil { m__6 = ifn_1095.Invoke_O__O(arg_1096) } else { m__6 = linked_1094.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_1093, arg_1096) }
//line :372:1
					var e__7 int64 = lang.RT_LongCast_O__J_NoInit(e__5)






					if lang.Numbers_IsNeg_J__Z_NoInit(e__7) { var root_1097 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = m__6; var arg_1101 any; var root_1102 any = A_arbace_repr_go_lit_A_const_65.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, A_arbace_repr_go_lit_pow2_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__7)).Ref(); if linked_1103 == nil { arg_1101 = ifn_1104.Invoke_O__O(arg_1105) } else { arg_1101 = linked_1103.(*A_arbace_repr_go_lit_pow2_A).Invoke_O_O__O(root_1102, arg_1105) }; if linked_1098 == nil { return ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { return linked_1098.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) } } else { var root_1106 any = A_arbace_repr_go_lit_A_const_64.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, A_arbace_repr_go_lit_rational_A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = jrt.BigInteger_Cast(m__6).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__7)); var arg_1110 any; jrt.BigInteger_Init(); arg_1110 = jrt.BigInteger_ONE; if linked_1107 == nil { return ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { return linked_1107.(*A_arbace_repr_go_lit_rational_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) } } } else {
//line :372:1
						if A_arbace_repr_go_lit_A_const_22 != nil { var tmp8 any; var root_1111 any = A_arbace_repr_go_lit_A_const_127.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1113 lang.IFn







							if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_128.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var arg_1115 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_129, v__0)); if linked_1112 == nil { tmp8 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { tmp8 = linked_1112.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }
//line :372:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil
							}
					}
			}
	}
}




func A_arbace_repr_go_lit_untyped_float_form_A_New() *A_arbace_repr_go_lit_untyped_float_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_untyped_float_form_A{}; t.Ctor(); return t }
//line :382:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Ctor() {}
//line :382:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Invoke_O_O__O(self, v__0 any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var root_1120 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = v__0; if linked_1121 == nil { and__1927000168__auto____2 = ifn_1122.Invoke_O__O(arg_1123) } else { and__1927000168__auto____2 = linked_1121.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1120, arg_1123) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp2 any = A_arbace_repr_go_lit_A_const_125; var tmp3 any; var root_1124 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = v__0; if linked_1125 == nil { tmp3 = ifn_1126.Invoke_O__O(arg_1127) } else { tmp3 = linked_1125.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1124, arg_1127) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_109.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_lit_A_const_131; var tmp6 any; var root_1136 any = A_arbace_repr_go_lit_A_const_132.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1137 == nil { tmp6 = ifn_1138.Invoke_O__O(arg_1139) } else { tmp6 = linked_1137.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1136, arg_1139) }; var tmp7 any = tmp6; var tmp8 any; var root_1140 any = A_arbace_repr_go_lit_A_const_132.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1141 == nil { tmp8 = ifn_1142.Invoke_O__O(arg_1143) } else { tmp8 = linked_1141.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1140, arg_1143) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp7, tmp8) } else {
			var root_1128 any = A_arbace_repr_go_lit_A_const_59.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_repr_go_lit_float_lit_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any; var root_1132 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = v__0; if linked_1133 == nil { arg_1131 = ifn_1134.Invoke_O__O(arg_1135) } else { arg_1131 = linked_1133.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1132, arg_1135) }; if linked_1129 == nil { return ifn_1130.Invoke_O__O(arg_1131) } else { return linked_1129.(*A_arbace_repr_go_lit_float_lit_A).Invoke_O_O__O(root_1128, arg_1131)
			} } }
func A_arbace_repr_go_lit_const_form_A_New() *A_arbace_repr_go_lit_const_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_const_form_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_repr_go_lit_const_form_A) Ctor() {}
//line :391:1
func (t *A_arbace_repr_go_lit_const_form_A) Invoke_O_O_O__O(self, v__0, k__1 any) any { var k__3 any; var or__1927000174__auto____3 any = k__1; if




	jrt.J2g_Truth(or__1927000174__auto____3) { k__3 = or__1927000174__auto____3 } else {
		var tmp1 any; var root_1144 any = A_arbace_repr_go_lit_A_const_133.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_1146 lang.IFn
		if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = v__0; if linked_1145 == nil { tmp1 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp1 = linked_1145.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_1144, arg_1147) }
//line :397:1
		if jrt.J2g_Truth(tmp1) { k__3 = A_arbace_repr_go_lit_A_const_134 } else { var tmp2 any; var root_1148 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1150 lang.IFn

			if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = v__0; if linked_1149 == nil { tmp2 = ifn_1150.Invoke_O__O(arg_1151) } else { tmp2 = linked_1149.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1148, arg_1151) }
//line :397:1
			if jrt.J2g_Truth(tmp2) { k__3 = A_arbace_repr_go_lit_A_const_135 } else { var tmp3 any; var and__1927000168__auto____4 any; var root_1152 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1154 lang.IFn


				if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = v__0; if linked_1153 == nil { and__1927000168__auto____4 = ifn_1154.Invoke_O__O(arg_1155) } else { and__1927000168__auto____4 = linked_1153.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1152, arg_1155) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp4 any = A_arbace_repr_go_lit_A_const_136; var tmp5 any; var root_1156 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = v__0; if linked_1157 == nil { tmp5 = ifn_1158.Invoke_O__O(arg_1159) } else { tmp5 = linked_1157.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1156, arg_1159) }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else { tmp3 = and__1927000168__auto____4 }
//line :397:1
				if jrt.J2g_Truth(tmp3) { k__3 = A_arbace_repr_go_lit_A_const_135 } else { var tmp6 any; var root_1160 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1162 lang.IFn



					if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = v__0; if linked_1161 == nil { tmp6 = ifn_1162.Invoke_O__O(arg_1163) } else { tmp6 = linked_1161.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1160, arg_1163) }
//line :397:1
					if jrt.J2g_Truth(tmp6) { k__3 = A_arbace_repr_go_lit_A_const_137 } else { var tmp7 any; var and__1927000168__auto____4_2 any; var root_1164 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1166 lang.IFn




						if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = v__0; if linked_1165 == nil { and__1927000168__auto____4_2 = ifn_1166.Invoke_O__O(arg_1167) } else { and__1927000168__auto____4_2 = linked_1165.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1164, arg_1167) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp8 any = A_arbace_repr_go_lit_A_const_125; var tmp9 any; var root_1168 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = v__0; if linked_1169 == nil { tmp9 = ifn_1170.Invoke_O__O(arg_1171) } else { tmp9 = linked_1169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1168, arg_1171) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9)).Ref() } else { tmp7 = and__1927000168__auto____4_2 }
//line :397:1
						if jrt.J2g_Truth(tmp7) { k__3 = A_arbace_repr_go_lit_A_const_125 } else { var tmp10 any; var and__1927000168__auto____4_3 any; var root_1172 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1174 lang.IFn





							if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = v__0; if linked_1173 == nil { and__1927000168__auto____4_3 = ifn_1174.Invoke_O__O(arg_1175) } else { and__1927000168__auto____4_3 = linked_1173.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1172, arg_1175) }; if jrt.J2g_Truth(and__1927000168__auto____4_3) { var tmp11 any = A_arbace_repr_go_lit_A_const_138; var tmp12 any; var root_1176 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = v__0; if linked_1177 == nil { tmp12 = ifn_1178.Invoke_O__O(arg_1179) } else { tmp12 = linked_1177.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1176, arg_1179) }; tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp11, tmp12)).Ref() } else { tmp10 = and__1927000168__auto____4_3 }
//line :397:1
							if jrt.J2g_Truth(tmp10) { k__3 = A_arbace_repr_go_lit_A_const_138 } else { k__3 = nil } } } } } } }; var G__790000105__4_ any = k__3; switch






	lang.Util_Hash_O__I_NoInit(G__790000105__4_) >> 7 & 15 { case 0: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_139) {










		var root_1181 any = A_arbace_repr_go_lit_A_const_140.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_repr_go_lit_untyped_float_form_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = v__0; if linked_1182 == nil { return ifn_1183.Invoke_O__O(arg_1184) } else { return linked_1182.(*A_arbace_repr_go_lit_untyped_float_form_A).Invoke_O_O__O(root_1181, arg_1184) } }
//line :404:1
	case 3: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_134) {
		var root_1185 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any; var root_1190 any = A_arbace_repr_go_lit_A_const_19.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = v__0; if linked_1191 == nil { arg_1188 = ifn_1192.Invoke_O__O(arg_1193) } else { arg_1188 = linked_1191.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1190, arg_1193) }; var arg_1189 any = v__0; if linked_1186 == nil { return ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { return linked_1186.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) } }
//line :404:1
	case 4: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_141) { var vec__790000106__5 any; var tmp13 any; var and__1927000168__auto____5 any; var root_1194 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1196 lang.IFn












		if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = v__0; if linked_1195 == nil { and__1927000168__auto____5 = ifn_1196.Invoke_O__O(arg_1197) } else { and__1927000168__auto____5 = linked_1195.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1194, arg_1197) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp14 any = A_arbace_repr_go_lit_A_const_138; var tmp15 any; var root_1198 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = v__0; if linked_1199 == nil { tmp15 = ifn_1200.Invoke_O__O(arg_1201) } else { tmp15 = linked_1199.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1198, arg_1201) }; tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, tmp15)).Ref() } else { tmp13 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp13) { vec__790000106__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000106__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_62) }
//line :404:1
		var re__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000106__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000106__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000109__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_138) { var tmp16 any; var root_1210 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = re__6; if linked_1211 == nil { tmp16 = ifn_1212.Invoke_O__O(arg_1213) } else { tmp16 = linked_1211.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1210, arg_1213) }; var tmp17 any = tmp16; var tmp18 any; var root_1214 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = im__7; if linked_1215 == nil { tmp18 = ifn_1216.Invoke_O__O(arg_1217) } else { tmp18 = linked_1215.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1214, arg_1217) }; vec__790000109__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18) } else { vec__790000109__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6, im__7) }
//line :404:1
		var re__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000109__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000109__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_138) { f__11 = A_arbace_repr_go_lit_A_const_142.GetRawRoot__O() } else { f__11 = A_arbace_repr_go_lit_A_const_140.GetRawRoot__O() }
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_109.GetRawRoot__O()); var tmp20 any = A_arbace_repr_go_lit_A_const_145; return tmp19.Invoke_O_O_O__O(tmp20, lang.IFn_Cast(f__11).Invoke_O__O(re__9), lang.IFn_Cast(f__11).Invoke_O__O(im__10)) }
//line :404:1
	case 5: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_143) {








		var root_1202 any = A_arbace_repr_go_lit_A_const_144.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, A_arbace_repr_go_lit_rune_form_A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1206 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = v__0; if linked_1207 == nil { arg_1205 = ifn_1208.Invoke_O__O(arg_1209) } else { arg_1205 = linked_1207.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1206, arg_1209) }; if linked_1203 == nil { return ifn_1204.Invoke_O__O(arg_1205) } else { return linked_1203.(*A_arbace_repr_go_lit_rune_form_A).Invoke_O_O__O(root_1202, arg_1205) } }
//line :404:1
	case 8: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_138) { var vec__790000112__5 any; var tmp21 any; var and__1927000168__auto____5_2 any; var root_1218 any = A_arbace_repr_go_lit_A_const_124.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1220 lang.IFn












		if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = v__0; if linked_1219 == nil { and__1927000168__auto____5_2 = ifn_1220.Invoke_O__O(arg_1221) } else { and__1927000168__auto____5_2 = linked_1219.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1218, arg_1221) }; if jrt.J2g_Truth(and__1927000168__auto____5_2) { var tmp22 any = A_arbace_repr_go_lit_A_const_138; var tmp23 any; var root_1222 any = A_arbace_repr_go_lit_A_const_26.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = v__0; if linked_1223 == nil { tmp23 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp23 = linked_1223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1222, arg_1225) }; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23)).Ref() } else { tmp21 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp21) { vec__790000112__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000112__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_62) }
//line :404:1
		var re__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000112__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000112__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000115__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_138) { var tmp24 any; var root_1234 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = re__6_2; if linked_1235 == nil { tmp24 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp24 = linked_1235.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1234, arg_1237) }; var tmp25 any = tmp24; var tmp26 any; var root_1238 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = im__7_2; if linked_1239 == nil { tmp26 = ifn_1240.Invoke_O__O(arg_1241) } else { tmp26 = linked_1239.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1238, arg_1241) }; vec__790000115__8 = lang.Tuple_Create_O_O__IPersistentVector(tmp25, tmp26) } else { vec__790000115__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6_2, im__7_2) }
//line :404:1
		var re__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000115__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000115__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11_2 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_138) { f__11_2 = A_arbace_repr_go_lit_A_const_142.GetRawRoot__O() } else { f__11_2 = A_arbace_repr_go_lit_A_const_140.GetRawRoot__O() }
		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_109.GetRawRoot__O()); var tmp28 any = A_arbace_repr_go_lit_A_const_145; return tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(f__11_2).Invoke_O__O(re__9_2), lang.IFn_Cast(f__11_2).Invoke_O__O(im__10_2)) }
//line :404:1
	case 9: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_125) {









		var root_1226 any = A_arbace_repr_go_lit_A_const_142.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, A_arbace_repr_go_lit_double_lit_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var root_1230 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = v__0; if linked_1231 == nil { arg_1229 = ifn_1232.Invoke_O__O(arg_1233) } else { arg_1229 = linked_1231.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1230, arg_1233) }; if linked_1227 == nil { return ifn_1228.Invoke_O__O(arg_1229) } else { return linked_1227.(*A_arbace_repr_go_lit_double_lit_A).Invoke_O_O__O(root_1226, arg_1229) } }
//line :404:1
	case 12: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_137) { var r__5 any; var root_1242 any = A_arbace_repr_go_lit_A_const_130.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, A_arbace_repr_go_lit_val_rational_A_fn_class); var ifn_1244 lang.IFn




		if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = v__0; if linked_1243 == nil { r__5 = ifn_1244.Invoke_O__O(arg_1245) } else { r__5 = linked_1243.(*A_arbace_repr_go_lit_val_rational_A).Invoke_O_O__O(root_1242, arg_1245) }
		var tmp29 any; var root_1246 any = A_arbace_repr_go_lit_A_const_123.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = r__5; if linked_1247 == nil { tmp29 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp29 = linked_1247.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1246, arg_1249) }; if jrt.J2g_Truth(tmp29) {
			var root_1250 any = A_arbace_repr_go_lit_A_const_132.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_repr_go_lit_integer_lit_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = r__5; if linked_1251 == nil { return ifn_1252.Invoke_O__O(arg_1253) } else { return linked_1251.(*A_arbace_repr_go_lit_integer_lit_A).Invoke_O_O__O(root_1250, arg_1253) } } else {
//line :410:1
				var tmp30 any; var root_1254 any = A_arbace_repr_go_lit_A_const_127.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1256 lang.IFn

				if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_128.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var arg_1258 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_129, v__0)); if linked_1255 == nil { tmp30 = ifn_1256.Invoke_O_O__O(arg_1257, arg_1258) } else { tmp30 = linked_1255.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1254, arg_1257, arg_1258) }
//line :410:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp30))) } }
//line :404:1
	case 15: if any(G__790000105__4_) == any(A_arbace_repr_go_lit_A_const_135) {

		var tmp31 any; var root_1263 any = A_arbace_repr_go_lit_A_const_113.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = v__0; if linked_1264 == nil { tmp31 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp31 = linked_1264.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1263, arg_1266) }; if jrt.J2g_Truth(tmp31) {
			var root_1267 any = A_arbace_repr_go_lit_A_const_34.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, A_arbace_repr_go_lit_lit_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var root_1272 any = A_arbace_repr_go_lit_A_const_115.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = v__0; if linked_1273 == nil { arg_1270 = ifn_1274.Invoke_O__O(arg_1275) } else { arg_1270 = linked_1273.(*A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1272, arg_1275) }; var arg_1271 any = v__0; if linked_1268 == nil { return ifn_1269.Invoke_O_O__O(arg_1270, arg_1271) } else { return linked_1268.(*A_arbace_repr_go_lit_lit_A).Invoke_O_O_O__O(root_1267, arg_1270, arg_1271) } } else {
				var root_1276 any = A_arbace_repr_go_lit_A_const_146.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, A_arbace_repr_go_lit_bytes_form_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any; var tmp32 any; var root_1280 any = A_arbace_repr_go_lit_A_const_147.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = A_arbace_repr_go_lit_A_const_148.GetRawRoot__O(); var arg_1284 any; var root_1285 any = A_arbace_repr_go_lit_A_const_126.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = v__0; if linked_1286 == nil { arg_1284 = ifn_1287.Invoke_O__O(arg_1288) } else { arg_1284 = linked_1286.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1285, arg_1288) }; if linked_1281 == nil { tmp32 = ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { tmp32 = linked_1281.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) }; arg_1279 = lang.Numbers_Byte_array_O__B1_NoInit(tmp32).Ref(); if linked_1277 == nil { return ifn_1278.Invoke_O__O(arg_1279) } else { return linked_1277.(*A_arbace_repr_go_lit_bytes_form_A).Invoke_O_O__O(root_1276, arg_1279) } } }
//line :404:1
	default:}; return nil }
//line :402:1
type A_arbace_repr_go_lit_A struct{ jrt.Object }

var A_arbace_repr_go_lit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit_A_const_0 *lang.Var

var A_arbace_repr_go_lit_A_const_1 any

var A_arbace_repr_go_lit_A_const_2 *lang.Var

var A_arbace_repr_go_lit_A_const_3 any

var A_arbace_repr_go_lit_A_const_4 *lang.Var

var A_arbace_repr_go_lit_A_const_5 *lang.Var

var A_arbace_repr_go_lit_A_const_6 *lang.Var

var A_arbace_repr_go_lit_A_const_7 *lang.Var

var A_arbace_repr_go_lit_A_const_8 any

var A_arbace_repr_go_lit_A_const_9 *lang.Var

var A_arbace_repr_go_lit_A_const_10 *lang.Var

var A_arbace_repr_go_lit_A_const_11 *lang.Var

var A_arbace_repr_go_lit_A_const_12 *lang.Var

var A_arbace_repr_go_lit_A_const_13 any

var A_arbace_repr_go_lit_A_const_14 any

var A_arbace_repr_go_lit_A_const_15 any

var A_arbace_repr_go_lit_A_const_16 any

var A_arbace_repr_go_lit_A_const_17 *lang.Var

var A_arbace_repr_go_lit_A_const_18 *lang.Var

var A_arbace_repr_go_lit_A_const_19 *lang.Var

var A_arbace_repr_go_lit_A_const_20 *lang.Var

var A_arbace_repr_go_lit_A_const_21 *lang.Var

var A_arbace_repr_go_lit_A_const_22 *lang.Keyword

var A_arbace_repr_go_lit_A_const_23 *lang.Var

var A_arbace_repr_go_lit_A_const_24 *lang.Var

var A_arbace_repr_go_lit_A_const_25 *lang.Var

var A_arbace_repr_go_lit_A_const_26 *lang.Var

var A_arbace_repr_go_lit_A_const_27 *lang.Var

var A_arbace_repr_go_lit_A_const_28 *lang.Var

var A_arbace_repr_go_lit_A_const_29 *lang.Var

var A_arbace_repr_go_lit_A_const_30 *lang.Var

var A_arbace_repr_go_lit_A_const_31 *lang.Var

var A_arbace_repr_go_lit_A_const_32 *lang.Var

var A_arbace_repr_go_lit_A_const_33 *lang.Var

var A_arbace_repr_go_lit_A_const_34 *lang.Var

var A_arbace_repr_go_lit_A_const_35 *lang.Var

var A_arbace_repr_go_lit_A_const_36 any

var A_arbace_repr_go_lit_A_const_37 *lang.Var

var A_arbace_repr_go_lit_A_const_38 any

var A_arbace_repr_go_lit_A_const_39 any

var A_arbace_repr_go_lit_A_const_40 any

var A_arbace_repr_go_lit_A_const_41 any

var A_arbace_repr_go_lit_A_const_42 *lang.Var

var A_arbace_repr_go_lit_A_const_43 any

var A_arbace_repr_go_lit_A_const_44 *lang.Var

var A_arbace_repr_go_lit_A_const_45 *lang.Var

var A_arbace_repr_go_lit_A_const_46 *lang.Var

var A_arbace_repr_go_lit_A_const_47 *lang.Var

var A_arbace_repr_go_lit_A_const_48 *lang.Var

var A_arbace_repr_go_lit_A_const_49 *lang.Var

var A_arbace_repr_go_lit_A_const_50 *lang.Var

var A_arbace_repr_go_lit_A_const_51 *lang.Var

var A_arbace_repr_go_lit_A_const_52 *lang.Keyword

var A_arbace_repr_go_lit_A_const_53 *lang.Var

var A_arbace_repr_go_lit_A_const_54 *lang.Var

var A_arbace_repr_go_lit_A_const_55 *jrt.Class

var A_arbace_repr_go_lit_A_const_56 *lang.Var

var A_arbace_repr_go_lit_A_const_57 *lang.Var

var A_arbace_repr_go_lit_A_const_58 *lang.Var

var A_arbace_repr_go_lit_A_const_59 *lang.Var

var A_arbace_repr_go_lit_A_const_60 *lang.Var

var A_arbace_repr_go_lit_A_const_61 *lang.Var

var A_arbace_repr_go_lit_A_const_62 any

var A_arbace_repr_go_lit_A_const_63 *lang.Var

var A_arbace_repr_go_lit_A_const_64 *lang.Var

var A_arbace_repr_go_lit_A_const_65 *lang.Var

var A_arbace_repr_go_lit_A_const_66 *lang.Var

var A_arbace_repr_go_lit_A_const_67 *lang.Var

var A_arbace_repr_go_lit_A_const_68 *lang.Var

var A_arbace_repr_go_lit_A_const_69 any

var A_arbace_repr_go_lit_A_const_70 any

var A_arbace_repr_go_lit_A_const_71 *lang.Var

var A_arbace_repr_go_lit_A_const_72 *lang.Var

var A_arbace_repr_go_lit_A_const_73 *lang.Var

var A_arbace_repr_go_lit_A_const_74 any

var A_arbace_repr_go_lit_A_const_75 any

var A_arbace_repr_go_lit_A_const_76 any

var A_arbace_repr_go_lit_A_const_77 any

var A_arbace_repr_go_lit_A_const_78 *lang.Var

var A_arbace_repr_go_lit_A_const_79 any

var A_arbace_repr_go_lit_A_const_80 any

var A_arbace_repr_go_lit_A_const_81 any

var A_arbace_repr_go_lit_A_const_82 any

var A_arbace_repr_go_lit_A_const_83 any

var A_arbace_repr_go_lit_A_const_84 any

var A_arbace_repr_go_lit_A_const_85 any

var A_arbace_repr_go_lit_A_const_86 any

var A_arbace_repr_go_lit_A_const_87 any

var A_arbace_repr_go_lit_A_const_88 *lang.Var

var A_arbace_repr_go_lit_A_const_89 any

var A_arbace_repr_go_lit_A_const_90 any

var A_arbace_repr_go_lit_A_const_91 any

var A_arbace_repr_go_lit_A_const_92 any

var A_arbace_repr_go_lit_A_const_93 any

var A_arbace_repr_go_lit_A_const_94 any

var A_arbace_repr_go_lit_A_const_95 any

var A_arbace_repr_go_lit_A_const_96 any

var A_arbace_repr_go_lit_A_const_97 any

var A_arbace_repr_go_lit_A_const_98 any

var A_arbace_repr_go_lit_A_const_99 any

var A_arbace_repr_go_lit_A_const_100 any

var A_arbace_repr_go_lit_A_const_101 any

var A_arbace_repr_go_lit_A_const_102 any

var A_arbace_repr_go_lit_A_const_103 any

var A_arbace_repr_go_lit_A_const_104 *lang.Var

var A_arbace_repr_go_lit_A_const_105 any

var A_arbace_repr_go_lit_A_const_106 any

var A_arbace_repr_go_lit_A_const_107 any

var A_arbace_repr_go_lit_A_const_108 *lang.Var

var A_arbace_repr_go_lit_A_const_109 *lang.Var

var A_arbace_repr_go_lit_A_const_110 any

var A_arbace_repr_go_lit_A_const_111 *lang.Var

var A_arbace_repr_go_lit_A_const_112 *lang.Var

var A_arbace_repr_go_lit_A_const_113 *lang.Var

var A_arbace_repr_go_lit_A_const_114 *lang.Var

var A_arbace_repr_go_lit_A_const_115 *lang.Var

var A_arbace_repr_go_lit_A_const_116 any

var A_arbace_repr_go_lit_A_const_117 *lang.Var

var A_arbace_repr_go_lit_A_const_118 *lang.Var

var A_arbace_repr_go_lit_A_const_119 *lang.Var

var A_arbace_repr_go_lit_A_const_120 *lang.Var

var A_arbace_repr_go_lit_A_const_121 *lang.Var

var A_arbace_repr_go_lit_A_const_122 *lang.Var

var A_arbace_repr_go_lit_A_const_123 *lang.Var

var A_arbace_repr_go_lit_A_const_124 *lang.Var

var A_arbace_repr_go_lit_A_const_125 *lang.Keyword

var A_arbace_repr_go_lit_A_const_126 *lang.Var

var A_arbace_repr_go_lit_A_const_127 *lang.Var

var A_arbace_repr_go_lit_A_const_128 *lang.Var

var A_arbace_repr_go_lit_A_const_129 *lang.Keyword

var A_arbace_repr_go_lit_A_const_130 *lang.Var

var A_arbace_repr_go_lit_A_const_131 any

var A_arbace_repr_go_lit_A_const_132 *lang.Var

var A_arbace_repr_go_lit_A_const_133 *lang.Var

var A_arbace_repr_go_lit_A_const_134 *lang.Keyword

var A_arbace_repr_go_lit_A_const_135 *lang.Keyword

var A_arbace_repr_go_lit_A_const_136 *lang.Keyword

var A_arbace_repr_go_lit_A_const_137 *lang.Keyword

var A_arbace_repr_go_lit_A_const_138 *lang.Keyword

var A_arbace_repr_go_lit_A_const_139 *lang.Keyword

var A_arbace_repr_go_lit_A_const_140 *lang.Var

var A_arbace_repr_go_lit_A_const_141 *lang.Keyword

var A_arbace_repr_go_lit_A_const_142 *lang.Var

var A_arbace_repr_go_lit_A_const_143 *lang.Keyword

var A_arbace_repr_go_lit_A_const_144 *lang.Var

var A_arbace_repr_go_lit_A_const_145 any

var A_arbace_repr_go_lit_A_const_146 *lang.Var

var A_arbace_repr_go_lit_A_const_147 *lang.Var

var A_arbace_repr_go_lit_A_const_148 *lang.Var

var A_arbace_repr_go_lit_A_init jrt.ClassInit

func A_arbace_repr_go_lit_A_Init() { if !A_arbace_repr_go_lit_A_init.Done() { A_arbace_repr_go_lit_A_init.Run(A_arbace_repr_go_lit_A_clinit) } }

func A_arbace_repr_go_lit_A_clinit() { A_arbace_repr_go_lit_A_clinit_p0(); A_arbace_repr_go_lit_A_clinit_p1(); A_arbace_repr_go_lit_A_clinit_p2(); A_arbace_repr_go_lit_A_clinit_p3(); A_arbace_repr_go_lit_A_clinit_p4(); A_arbace_repr_go_lit_A_clinit_p5(); A_arbace_repr_go_lit_A_clinit_p6(); A_arbace_repr_go_lit_A_clinit_p7(); A_arbace_repr_go_lit_A_clinit_p8(); A_arbace_repr_go_lit_A_clinit_p9(); A_arbace_repr_go_lit_A_clinit_p10(); A_arbace_repr_go_lit_A_clinit_p11() }

func A_arbace_repr_go_lit_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_lit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 170); A_arbace_repr_go_lit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[21]); A_arbace_repr_go_lit_A_const_1 = A_arbace_repr_go_lit_A_const_pool.A[22]; A_arbace_repr_go_lit_A_const_2 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[23]); A_arbace_repr_go_lit_A_const_3 = A_arbace_repr_go_lit_A_const_pool.A[24]; A_arbace_repr_go_lit_A_const_4 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[25]); A_arbace_repr_go_lit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[26]); A_arbace_repr_go_lit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[27]); A_arbace_repr_go_lit_A_const_7 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[28]); A_arbace_repr_go_lit_A_const_8 = A_arbace_repr_go_lit_A_const_pool.A[29]; A_arbace_repr_go_lit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[30]); A_arbace_repr_go_lit_A_const_10 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[31]); A_arbace_repr_go_lit_A_const_11 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[32]) }

func A_arbace_repr_go_lit_A_clinit_p1() { A_arbace_repr_go_lit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[33]); A_arbace_repr_go_lit_A_const_13 = A_arbace_repr_go_lit_A_const_pool.A[34]; A_arbace_repr_go_lit_A_const_14 = A_arbace_repr_go_lit_A_const_pool.A[35]; A_arbace_repr_go_lit_A_const_15 = A_arbace_repr_go_lit_A_const_pool.A[36]; A_arbace_repr_go_lit_A_const_16 = A_arbace_repr_go_lit_A_const_pool.A[37]; A_arbace_repr_go_lit_A_const_17 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[38]); A_arbace_repr_go_lit_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[39]); A_arbace_repr_go_lit_A_const_19 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[40]); A_arbace_repr_go_lit_A_const_20 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[41]); A_arbace_repr_go_lit_A_const_21 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[42]); A_arbace_repr_go_lit_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[43]); A_arbace_repr_go_lit_A_const_23 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[44]); A_arbace_repr_go_lit_A_const_24 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[45]) }

func A_arbace_repr_go_lit_A_clinit_p2() { A_arbace_repr_go_lit_A_const_25 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[46]); A_arbace_repr_go_lit_A_const_26 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[47]); A_arbace_repr_go_lit_A_const_27 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[48]); A_arbace_repr_go_lit_A_const_28 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[49]); A_arbace_repr_go_lit_A_const_29 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[50]); A_arbace_repr_go_lit_A_const_30 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[51]); A_arbace_repr_go_lit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[52]); A_arbace_repr_go_lit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[53]); A_arbace_repr_go_lit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[54]); A_arbace_repr_go_lit_A_const_34 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[55]); A_arbace_repr_go_lit_A_const_35 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[56]); A_arbace_repr_go_lit_A_const_36 = A_arbace_repr_go_lit_A_const_pool.A[57] }

func A_arbace_repr_go_lit_A_clinit_p3() { A_arbace_repr_go_lit_A_const_37 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[58]); A_arbace_repr_go_lit_A_const_38 = A_arbace_repr_go_lit_A_const_pool.A[59]; A_arbace_repr_go_lit_A_const_39 = A_arbace_repr_go_lit_A_const_pool.A[60]; A_arbace_repr_go_lit_A_const_40 = A_arbace_repr_go_lit_A_const_pool.A[61]; A_arbace_repr_go_lit_A_const_41 = A_arbace_repr_go_lit_A_const_pool.A[62]; A_arbace_repr_go_lit_A_const_42 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[63]); A_arbace_repr_go_lit_A_const_43 = A_arbace_repr_go_lit_A_const_pool.A[64]; A_arbace_repr_go_lit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[65]); A_arbace_repr_go_lit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[66]); A_arbace_repr_go_lit_A_const_46 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[67]); A_arbace_repr_go_lit_A_const_47 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[68]); A_arbace_repr_go_lit_A_const_48 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[69]); A_arbace_repr_go_lit_A_const_49 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[70]) }

func A_arbace_repr_go_lit_A_clinit_p4() { A_arbace_repr_go_lit_A_const_50 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[71]); A_arbace_repr_go_lit_A_const_51 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[72]); A_arbace_repr_go_lit_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[73]); A_arbace_repr_go_lit_A_const_53 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[74]); A_arbace_repr_go_lit_A_const_54 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[75]); A_arbace_repr_go_lit_A_const_55 = jrt.Class_Cast(A_arbace_repr_go_lit_A_const_pool.A[76]); A_arbace_repr_go_lit_A_const_56 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[77]); A_arbace_repr_go_lit_A_const_57 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[78]); A_arbace_repr_go_lit_A_const_58 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[79]); A_arbace_repr_go_lit_A_const_59 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[80]); A_arbace_repr_go_lit_A_const_60 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[81]); A_arbace_repr_go_lit_A_const_61 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[82]) }

func A_arbace_repr_go_lit_A_clinit_p5() { A_arbace_repr_go_lit_A_const_62 = A_arbace_repr_go_lit_A_const_pool.A[83]; A_arbace_repr_go_lit_A_const_63 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[84]); A_arbace_repr_go_lit_A_const_64 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[85]); A_arbace_repr_go_lit_A_const_65 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[86]); A_arbace_repr_go_lit_A_const_66 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[87]); A_arbace_repr_go_lit_A_const_67 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[88]); A_arbace_repr_go_lit_A_const_68 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[89]); A_arbace_repr_go_lit_A_const_69 = A_arbace_repr_go_lit_A_const_pool.A[90]; A_arbace_repr_go_lit_A_const_70 = A_arbace_repr_go_lit_A_const_pool.A[91]; A_arbace_repr_go_lit_A_const_71 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[92]); A_arbace_repr_go_lit_A_const_72 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[93]); A_arbace_repr_go_lit_A_const_73 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[94]); A_arbace_repr_go_lit_A_const_74 = A_arbace_repr_go_lit_A_const_pool.A[95] }

func A_arbace_repr_go_lit_A_clinit_p6() { A_arbace_repr_go_lit_A_const_75 = A_arbace_repr_go_lit_A_const_pool.A[96]; A_arbace_repr_go_lit_A_const_76 = A_arbace_repr_go_lit_A_const_pool.A[97]; A_arbace_repr_go_lit_A_const_77 = A_arbace_repr_go_lit_A_const_pool.A[98]; A_arbace_repr_go_lit_A_const_78 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[99]); A_arbace_repr_go_lit_A_const_79 = A_arbace_repr_go_lit_A_const_pool.A[100]; A_arbace_repr_go_lit_A_const_80 = A_arbace_repr_go_lit_A_const_pool.A[101]; A_arbace_repr_go_lit_A_const_81 = A_arbace_repr_go_lit_A_const_pool.A[102]; A_arbace_repr_go_lit_A_const_82 = A_arbace_repr_go_lit_A_const_pool.A[103]; A_arbace_repr_go_lit_A_const_83 = A_arbace_repr_go_lit_A_const_pool.A[104]; A_arbace_repr_go_lit_A_const_84 = A_arbace_repr_go_lit_A_const_pool.A[105]; A_arbace_repr_go_lit_A_const_85 = A_arbace_repr_go_lit_A_const_pool.A[106]; A_arbace_repr_go_lit_A_const_86 = A_arbace_repr_go_lit_A_const_pool.A[107]; A_arbace_repr_go_lit_A_const_87 = A_arbace_repr_go_lit_A_const_pool.A[108]; A_arbace_repr_go_lit_A_const_88 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[109]); A_arbace_repr_go_lit_A_const_89 = A_arbace_repr_go_lit_A_const_pool.A[110] }

func A_arbace_repr_go_lit_A_clinit_p7() { A_arbace_repr_go_lit_A_const_90 = A_arbace_repr_go_lit_A_const_pool.A[111]; A_arbace_repr_go_lit_A_const_91 = A_arbace_repr_go_lit_A_const_pool.A[112]; A_arbace_repr_go_lit_A_const_92 = A_arbace_repr_go_lit_A_const_pool.A[113]; A_arbace_repr_go_lit_A_const_93 = A_arbace_repr_go_lit_A_const_pool.A[114]; A_arbace_repr_go_lit_A_const_94 = A_arbace_repr_go_lit_A_const_pool.A[115]; A_arbace_repr_go_lit_A_const_95 = A_arbace_repr_go_lit_A_const_pool.A[116]; A_arbace_repr_go_lit_A_const_96 = A_arbace_repr_go_lit_A_const_pool.A[117]; A_arbace_repr_go_lit_A_const_97 = A_arbace_repr_go_lit_A_const_pool.A[118]; A_arbace_repr_go_lit_A_const_98 = A_arbace_repr_go_lit_A_const_pool.A[119]; A_arbace_repr_go_lit_A_const_99 = A_arbace_repr_go_lit_A_const_pool.A[120]; A_arbace_repr_go_lit_A_const_100 = A_arbace_repr_go_lit_A_const_pool.A[121]; A_arbace_repr_go_lit_A_const_101 = A_arbace_repr_go_lit_A_const_pool.A[122]; A_arbace_repr_go_lit_A_const_102 = A_arbace_repr_go_lit_A_const_pool.A[123]; A_arbace_repr_go_lit_A_const_103 = A_arbace_repr_go_lit_A_const_pool.A[124]; A_arbace_repr_go_lit_A_const_104 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[125]) }

func A_arbace_repr_go_lit_A_clinit_p8() { A_arbace_repr_go_lit_A_const_105 = A_arbace_repr_go_lit_A_const_pool.A[126]; A_arbace_repr_go_lit_A_const_106 = A_arbace_repr_go_lit_A_const_pool.A[127]; A_arbace_repr_go_lit_A_const_107 = A_arbace_repr_go_lit_A_const_pool.A[128]; A_arbace_repr_go_lit_A_const_108 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[129]); A_arbace_repr_go_lit_A_const_109 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[130]); A_arbace_repr_go_lit_A_const_110 = A_arbace_repr_go_lit_A_const_pool.A[131]; A_arbace_repr_go_lit_A_const_111 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[132]); A_arbace_repr_go_lit_A_const_112 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[133]); A_arbace_repr_go_lit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[134]); A_arbace_repr_go_lit_A_const_114 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[135]); A_arbace_repr_go_lit_A_const_115 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[136]); A_arbace_repr_go_lit_A_const_116 = A_arbace_repr_go_lit_A_const_pool.A[137]; A_arbace_repr_go_lit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[138]) }

func A_arbace_repr_go_lit_A_clinit_p9() { A_arbace_repr_go_lit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[139]); A_arbace_repr_go_lit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[140]); A_arbace_repr_go_lit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[141]); A_arbace_repr_go_lit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[142]); A_arbace_repr_go_lit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[143]); A_arbace_repr_go_lit_A_const_123 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[144]); A_arbace_repr_go_lit_A_const_124 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[145]); A_arbace_repr_go_lit_A_const_125 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[146]); A_arbace_repr_go_lit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[147]); A_arbace_repr_go_lit_A_const_127 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[148]); A_arbace_repr_go_lit_A_const_128 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[149]); A_arbace_repr_go_lit_A_const_129 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[150]) }

func A_arbace_repr_go_lit_A_clinit_p10() { A_arbace_repr_go_lit_A_const_130 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[151]); A_arbace_repr_go_lit_A_const_131 = A_arbace_repr_go_lit_A_const_pool.A[152]; A_arbace_repr_go_lit_A_const_132 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[153]); A_arbace_repr_go_lit_A_const_133 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[154]); A_arbace_repr_go_lit_A_const_134 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[155]); A_arbace_repr_go_lit_A_const_135 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[156]); A_arbace_repr_go_lit_A_const_136 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[157]); A_arbace_repr_go_lit_A_const_137 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[158]); A_arbace_repr_go_lit_A_const_138 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[159]); A_arbace_repr_go_lit_A_const_139 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[160]); A_arbace_repr_go_lit_A_const_140 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[161]); A_arbace_repr_go_lit_A_const_141 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[162]) }

func A_arbace_repr_go_lit_A_clinit_p11() { A_arbace_repr_go_lit_A_const_142 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[163]); A_arbace_repr_go_lit_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[164]); A_arbace_repr_go_lit_A_const_144 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[165]); A_arbace_repr_go_lit_A_const_145 = A_arbace_repr_go_lit_A_const_pool.A[166]; A_arbace_repr_go_lit_A_const_146 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[167]); A_arbace_repr_go_lit_A_const_147 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[168]); A_arbace_repr_go_lit_A_const_148 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[169]) }

func A_arbace_repr_go_lit_A_New() *A_arbace_repr_go_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_A) Ctor() {}

func (t *A_arbace_repr_go_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_A_class }

func (t *A_arbace_repr_go_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_A); return ok }

func A_arbace_repr_go_lit_A_Cast(x any) *A_arbace_repr_go_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_A_class)) }; return v }



type A_arbace_repr_go_lit_bytes_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A struct{ j2g_header uint64; F_s__790000090, F_iter__790000089 any }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__790000092 any }

var A_arbace_repr_go_lit_bytes_form_iter__790000089__790000093_fn__790000094_fn__790000095_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_char_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_char_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_const_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_const_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decimal_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decimal_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decode_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_b__790000074_A struct{ j2g_header uint64; F_bs any }

var A_arbace_repr_go_lit_decode_rune_b__790000074_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A struct{ j2g_header uint64; F_n, F_b any }

var A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000076_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_exact_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_exact_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000004_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000004_A_New() *A_arbace_repr_go_lit_eval790000004_A { t := &A_arbace_repr_go_lit_eval790000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000004_A_class }

func (t *A_arbace_repr_go_lit_eval790000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); return ok }

func A_arbace_repr_go_lit_eval790000004_A_Cast(x any) *A_arbace_repr_go_lit_eval790000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000004_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000008_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000008_A_New() *A_arbace_repr_go_lit_eval790000008_A { t := &A_arbace_repr_go_lit_eval790000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000008_A_class }

func (t *A_arbace_repr_go_lit_eval790000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); return ok }

func A_arbace_repr_go_lit_eval790000008_A_Cast(x any) *A_arbace_repr_go_lit_eval790000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000008_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000008_fn__790000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000008_fn__790000009_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000013_A_New() *A_arbace_repr_go_lit_eval790000013_A { t := &A_arbace_repr_go_lit_eval790000013_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000013_A_class }

func (t *A_arbace_repr_go_lit_eval790000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); return ok }

func A_arbace_repr_go_lit_eval790000013_A_Cast(x any) *A_arbace_repr_go_lit_eval790000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000013_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_exact_double_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_exact_double_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_text_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_text_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hex_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hex_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hexv_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hexv_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_imag_inner_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_imag_inner_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_int_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_int_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_num_den_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_num_den_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow2_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow2_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow5_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A struct{ j2g_header uint64; F_d, F_five any }

var A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rational_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_bytes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_bytes_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_terminating_decimal_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_terminating_decimal_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_put_cp__790000067_A struct{ j2g_header uint64; F_out any }

var A_arbace_repr_go_lit_unescape_put_cp__790000067_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_untyped_float_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_untyped_float_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_utf8_parts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_utf8_parts_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_val_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_val_rational_A_fn_class *jrt.Class
