//line aot_arbace_repr_go_lit.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_New() *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_2); lang.IFn_Cast(A_arbace_repr_go_lit_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_lit_eval790000008_fn__790000009_A_New() *A_arbace_repr_go_lit_eval790000008_fn__790000009_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000008_fn__790000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_lit_eval790000008_fn__790000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_lit_A_const_8), A_arbace_repr_go_lit_A_const_6.GetRawRoot__O(), A_arbace_repr_go_lit_A_const_7) }











func A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_New() *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A) Invoke_O_O_O__O(self, text__1, value__2 any) any { return A_arbace_repr_go_lit_Lit_A_New_O_O(text__1, value__2) }
//line :13:1
func A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_New() *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Ctor() {}
//line :13:1
func (t *A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_9.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), m__231000174__auto____1) }; return A_arbace_repr_go_lit_Lit_A_Create_IPersistentMap__A_arbace_repr_go_lit_Lit_A(lang.IPersistentMap_Cast(tmp1)).Ref() }

func A_arbace_repr_go_lit_lit_A_New() *A_arbace_repr_go_lit_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Ctor() {}
//line :15:1
func (t *A_arbace_repr_go_lit_lit_A) Invoke_O_O_O__O(self, text__0, value__1 any) any { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_10.GetRawRoot__O()).Invoke_O_O__O(text__0, value__1) }

func A_arbace_repr_go_lit_lit_QMARK__A_New() *A_arbace_repr_go_lit_lit_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_lit_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_lit_lit_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(A_arbace_repr_go_lit_Lit_A_InstanceOf(x__0)).Ref() }







func A_arbace_repr_go_lit_printable_QMARK__A_New() *A_arbace_repr_go_lit_printable_QMARK__A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_printable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_repr_go_lit_printable_QMARK__A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var t__3 int32 = jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____4 bool = jrt.Character_IsISOControl_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____4 {




	tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.Character_IsWhitespace_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____5 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.Character_IsSpaceChar_I__Z_NoInit(lang.RT_IntCast_J__I_NoInit(cp__2)); if or__1927000174__auto____6 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_lit_A_const_14; var or__1927000174__auto____7 any = tmp3.Invoke_O_O_O__O(tmp4, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_15); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp2 = or__1927000174__auto____7 } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_lit_A_const_16; var or__1927000174__auto____8 any = tmp5.Invoke_O_O_O__O(tmp6, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_17); if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else {



		tmp2 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_13.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(0)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(19)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(13)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(14)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(18)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_B__I_NoInit(16)).Ref())), jrt.Integer_ValueOf_I__Integer_NoInit(t__3).Ref()) } } } } }; return /*line :30:1*/ tmp1.Invoke_O__O(tmp2) }








func A_arbace_repr_go_lit_string_text_A_New() *A_arbace_repr_go_lit_string_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_text_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_go_lit_string_text_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_go_lit_string_text_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_35); var n__3 int32 = jrt.NN(jrt.String_Cast(s__0)).Length__I(); var i__4 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__3)) { var cp__5 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__4)); var w__6 int32 = jrt.Character_CharCount_I__I_NoInit(cp__5); var G__790000031__7_ int32 = lang.RT_IntCast_I__I_NoInit(cp__5)


	L2: switch { default: switch G__790000031__7_ { case 8:





		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_36)
//line :48:1
		break L2; case 9:



		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_37)
//line :48:1
		break L2; case 10:


		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_38)
//line :48:1
		break L2; case 12:






		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_39)
//line :48:1
		break L2; case 13:




		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_40)
//line :48:1
		break L2; case 34:
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_41)
//line :48:1
		break L2; case 92:

		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_42)
//line :48:1
		break L2; default:
	}






		var tmp1 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_J_J__Z_NoInit(int64(cp__5), 32)
		if or__1927000174__auto____8 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref()) }
//line :56:1
		if jrt.J2g_Truth(tmp1) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).AppendCodePoint_I__StringBuilder(cp__5) } else {
//line :56:1
				if lang.Numbers_Lt_J_J__Z_NoInit(int64(cp__5), 65536) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(cp__5).Ref()))) } else {
//line :56:1
						if A_arbace_repr_go_lit_A_const_21 != nil { var seq_790000032__8 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_22.GetRawRoot__O()).Invoke_O__O(jrt.Character_ToChars_I__C1_NoInit(cp__5).Ref()); var chunk_790000033__9 any; var count_790000034__10 int64 = 0; var i_790000035__11 int64 = 0; L3: for {


							if lang.Numbers_Lt_J_J__Z_NoInit(i_790000035__11, count_790000034__10) { var c__12 any = lang.Indexed_Cast(chunk_790000033__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_790000035__11)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__12)).Ref()))); seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = seq_790000032__8, chunk_790000033__9, count_790000034__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_790000035__11); continue L3 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_790000032__8); if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_790000032__13 any = temp__1927000414__auto____12; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_790000032__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_790000032__13); seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_790000032__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var c__14 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_790000032__13); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__14)).Ref()))); seq_790000032__8, chunk_790000033__9, count_790000034__10, i_790000035__11 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_27.GetRawRoot__O()).Invoke_O__O(seq_790000032__13), nil, 0, 0; continue L3 } } }
//line :56:1
							break L3
						}
						}
					} }}
		i__4 = lang.Numbers_Add_J_J__J_NoInit(i__4, int64(w__6)); continue L1 }
//line :39:1
	break L1 }; return /*line :61:1*/ lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_35).Ref()) }

func A_arbace_repr_go_lit_char_text_A_New() *A_arbace_repr_go_lit_char_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_char_text_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_repr_go_lit_char_text_A) Ctor() {}
//line :63:1
func (t *A_arbace_repr_go_lit_char_text_A) Invoke_O_O__O(self, cp__0 any) any { var ch__2 uint16 = lang.RT_CharCast_O__C_NoInit(cp__0); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_28.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_28.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref()))).Ref() } else {
//line :67:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_19.GetRawRoot__O()).Invoke_O__O(cp__0)) {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Character_ValueOf_C__Character_NoInit(ch__2).Ref())).Ref() } else {
//line :67:1
					if A_arbace_repr_go_lit_A_const_21 != nil {


						return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(cp__0)).Ref()) } else {
//line :67:1
							return nil } } } }






func A_arbace_repr_go_lit_int_lit_A_New() *A_arbace_repr_go_lit_int_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_int_lit_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_repr_go_lit_int_lit_A) Ctor() {}
//line :74:1
func (t *A_arbace_repr_go_lit_int_lit_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(text__0, Lit_22, Lit_23); var lower__3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_30.GetRawRoot__O()).Invoke_O__O(t__2); var vec__790000038__4 any; if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_21)) { var tmp1 any = A_arbace_repr_go_lit_A_const_34; vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp1, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_36)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_26)) { var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_36))).Ref(); var tmp3 any = A_arbace_repr_go_lit_A_const_37; vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_36)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_28)) { var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_36))).Ref(); var tmp5 any = A_arbace_repr_go_lit_A_const_36; vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_36)) } else { var tmp6 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(t__2, Lit_27)



		if jrt.J2g_Truth(and__1927000168__auto____4) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t__2)), 1)).Ref() } else { tmp6 = and__1927000168__auto____4 }
//line :81:1
		if jrt.J2g_Truth(tmp6) { var tmp7 any = A_arbace_repr_go_lit_A_const_37; vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, tmp7, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__2, A_arbace_repr_go_lit_A_const_38)) } else { if A_arbace_repr_go_lit_A_const_21 != nil { vec__790000038__4 = lang.Tuple_Create_O_O_O__IPersistentVector(t__2, A_arbace_repr_go_lit_A_const_39, t__2) } else { vec__790000038__4 = nil } } } } }; var ctext__5 any = /*line :74:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(0), nil); var radix__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(1), nil); var digits__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000038__4, lang.RT_IntCast_J__I_NoInit(2), nil); var v__8 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.BigInteger_New_String_I(jrt.String_Cast(digits__7), lang.RT_IntCast_O__I_NoInit(radix__6))); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()); var tmp9 any; if













	lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(v__8))).BitLength__I()), 64) { tmp9 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__8)).Ref() } else { tmp9 = v__8 }; return tmp8.Invoke_O_O__O(ctext__5, tmp9) }

func A_arbace_repr_go_lit_integer_text_A_New() *A_arbace_repr_go_lit_integer_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_text_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_repr_go_lit_integer_text_A) Ctor() {}
//line :90:1
func (t *A_arbace_repr_go_lit_integer_text_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(v__0); if



	lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref()) } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, b__2, nil)).Ref() } }

func A_arbace_repr_go_lit_integer_lit_A_New() *A_arbace_repr_go_lit_integer_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_integer_lit_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_lit_integer_lit_A) Invoke_O_O__O(self, v__0 any) any { var b__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(v__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_41.GetRawRoot__O()).Invoke_O__O(v__0); var tmp3 any; if

	lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__2)).BitLength__I()), 64) { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__0)).Ref() } else { tmp3 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_32.GetRawRoot__O()).Invoke_O__O(b__2) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }



func A_arbace_repr_go_lit_rational_A_New() *A_arbace_repr_go_lit_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rational_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_repr_go_lit_rational_A) Ctor() {}
//line :102:1
func (t *A_arbace_repr_go_lit_rational_A) Invoke_O_O_O__O(self, num__0, den__1 any) any {


	return lang.Numbers_Divide_O_O__Number_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_32.GetRawRoot__O()).Invoke_O__O(num__0), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_32.GetRawRoot__O()).Invoke_O__O(den__1))
}
func A_arbace_repr_go_lit_pow2_A_New() *A_arbace_repr_go_lit_pow2_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow2_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_lit_pow2_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_lit_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.BigInteger; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 *jrt.BigInteger = tmp1; return jrt.NN(tmp2).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref() }

func A_arbace_repr_go_lit_pow5_exponent_A_New() *A_arbace_repr_go_lit_pow5_exponent_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Ctor() {}
//line :109:1
func (t *A_arbace_repr_go_lit_pow5_exponent_A) Invoke_O_O__O(self, d__0 any) any { var guess__2 int64 = lang.RT_LongCast_D__J_NoInit(jrt.Math_Floor_D__D(lang.Numbers_Divide_D_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(d__0)).BitLength__I()), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_36))), jrt.Math_Log_D__D(lang.RT_DoubleCast_O__D_NoInit(A_arbace_repr_go_lit_A_const_42))))); var five__3 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_43.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(d__0, five__3); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class; if




	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(guess__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(guess__2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(guess__2)).Ref())) }
//line :114:1
func A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Ctor_O_O(c__d, c__five any) { t.F_d = c__d; t.F_five = c__five }
//line :114:1
func (t *A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var na_2 any = k__1; var na_3 int64 = 0; if jrt.Long_InstanceOf(na_2) { var n0_4 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); var n1_5 int64 = na_3; and__1927000168__auto____2 = n0_4 >= n1_5 } else { and__1927000168__auto____2 = lang.Numbers_Gte_O_J__Z_NoInit(na_2, na_3) }; if and__1927000168__auto____2 { var tmp2 any = t.F_d; var tmp3 *jrt.BigInteger = jrt.BigInteger_Cast(t.F_five); tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, jrt.NN(tmp3).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__1)).Ref()) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return k__1 } else { return nil } }


func A_arbace_repr_go_lit_num_den_A_New() *A_arbace_repr_go_lit_num_den_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_num_den_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_repr_go_lit_num_den_A) Ctor() {}
//line :117:1
func (t *A_arbace_repr_go_lit_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_44.GetRawRoot__O()).Invoke_O__O(r__0)) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_45.GetRawRoot__O()).Invoke_O__O(r__0), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_46.GetRawRoot__O()).Invoke_O__O(r__0)) } else { if A_arbace_repr_go_lit_A_const_21 != nil { var tmp1 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(r__0); var tmp2 *jrt.BigInteger; jrt.BigInteger_Init(); tmp2 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Ref()) } else { return nil
	}
	}
}





func A_arbace_repr_go_lit_terminating_decimal_A_New() *A_arbace_repr_go_lit_terminating_decimal_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_terminating_decimal_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_go_lit_terminating_decimal_A) Invoke_O_O_O__O(self, num__0, den__1 any) any { var twos__3 int32 = jrt.NN(jrt.BigInteger_Cast(den__1)).GetLowestSetBit__I(); var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_47.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigInteger_Cast(den__1)).ShiftRight_I__BigInteger(twos__3).Ref()); if



	jrt.J2g_Truth(temp__1927000414__auto____4) { var fives__5 any = temp__1927000414__auto____4; var scale__6 any = lang.Numbers_Max_J_O__O_NoInit(int64(twos__3), fives__5); var unscaled__7 any; var tmp1 *jrt.BigInteger = jrt.BigInteger_Cast(num__0); var tmp2 jrt.Number_I; var na_8 any = scale__6; var na_9 int64 = int64(twos__3)



		if jrt.Long_InstanceOf(na_8) { var n0_10 int64 = jrt.NN(jrt.Long_Cast(na_8)).LongValue__J(); var n1_11 int64 = na_9; var nr_12 int64 = n0_10 - n1_11; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_11 == -9223372036854775808); if tmp4 { tmp4 = (n0_10^n1_11)&(n0_10^nr_12) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_12)) } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_8, na_9) } } else { tmp2 = lang.Numbers_Minus_O_J__Number_NoInit(na_8, na_9) }
		var tmp5 *jrt.BigInteger = jrt.NN(tmp1).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp2)); var tmp6 *jrt.BigInteger = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp7 jrt.Number_I; var na_13 any = scale__6; var na_14 any = fives__5; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_13); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_14) }; tmp8 = tmp9; if tmp8 { var n0_15 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); var n1_16 int64 = jrt.NN(jrt.Long_Cast(na_14)).LongValue__J(); var nr_17 int64 = n0_15 - n1_16; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_16 == -9223372036854775808); if tmp11 { tmp11 = (n0_15^n1_16)&(n0_15^nr_17) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_17)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_13, na_14) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_13); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_14) }; tmp12 = tmp13; if tmp12 { var n0_15_2 float64 = jrt.NN(jrt.Double_Cast(na_13)).DoubleValue__D(); var n1_16_2 float64 = jrt.NN(jrt.Double_Cast(na_14)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_15_2 + -n1_16_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_13, na_14) } }; unscaled__7 = jrt.NN(tmp5).Multiply_BigInteger__BigInteger(jrt.NN(tmp6).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp7))).Ref()
//line :131:1
		return jrt.BigDecimal_New_BigInteger_I(jrt.BigInteger_Cast(unscaled__7), lang.RT_IntCast_O__I_NoInit(scale__6)) } else { return nil } }







func A_arbace_repr_go_lit_double_exact_text_A_New() *A_arbace_repr_go_lit_double_exact_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_exact_text_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_go_lit_double_exact_text_A) Invoke_O_O__O(self, v__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(v__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsInfinite_D__Z_NoInit(d__2); if or__1927000174__auto____3 {




	tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsNaN_D__Z_NoInit(d__2) }; if tmp1 { return nil } else { var s__3 any = jrt.Double_ToString_D__String_NoInit(d__2).Ref(); var bd__4 any = jrt.BigDecimal_New_String(jrt.String_Cast(s__3)); var tmp2 bool


		if jrt.BigDecimal_InstanceOf(v__0) {
			tmp2 = lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(bd__4)).CompareTo_BigDecimal__I(jrt.BigDecimal_Cast(v__0)))) } else {
				tmp2 = lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_48.GetRawRoot__O()).Invoke_O__O(bd__4), v__0) }
//line :147:1
		if tmp2 { return s__3 } else { return nil } } }




func A_arbace_repr_go_lit_decimal_text_A_New() *A_arbace_repr_go_lit_decimal_text_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decimal_text_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Ctor() {}
//line :152:1
func (t *A_arbace_repr_go_lit_decimal_text_A) Invoke_O_O__O(self, bd__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_Cast(bd__0)).StripTrailingZeros__BigDecimal().Ref()); var tmp1 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_8); if



	jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_9) }; if jrt.J2g_Truth(tmp1) { return s__2 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() } }

func A_arbace_repr_go_lit_float_lit_A_New() *A_arbace_repr_go_lit_float_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_lit_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Ctor() {}
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O_O__O(self, v__0, p__790000053__1 any) any { var map__790000054__3 any = p__790000053__1; var map__790000054__4 any; if lang.ISeq_InstanceOf(map__790000054__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_27.GetRawRoot__O()).Invoke_O__O(map__790000054__3)) { map__790000054__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_lit_A_const_50.GetRawRoot__O()).Invoke_O__O(map__790000054__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_22.GetRawRoot__O()).Invoke_O__O(map__790000054__3)) { map__790000054__4 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(map__790000054__3) } else { map__790000054__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__790000054__4 = map__790000054__3 }; var prefer_ratio__5 any = lang.RT_Get_O_O__O_NoInit(map__790000054__4, A_arbace_repr_go_lit_A_const_51); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()).Invoke_O__O(prefer_ratio__5); if







	jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____6 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_52.GetRawRoot__O()).Invoke_O__O(v__0) } else { temp__1927000408__auto____6 = and__1927000168__auto____6 }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var s__7 any = temp__1927000408__auto____6
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(s__7, jrt.Double_ValueOf_D__Double_NoInit(jrt.Double_ParseDouble_String__D_NoInit(jrt.String_Cast(s__7))).Ref()) } else {
			if jrt.BigDecimal_InstanceOf(v__0) { var s__7_2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_53.GetRawRoot__O()).Invoke_O__O(v__0); var tmp1 *jrt.Class = A_arbace_repr_go_lit_A_const_57
				return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__7_2, nil)).Ref(), lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, s__7_2))) } else {
//line :168:1
					var vec__790000056__7 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__0); var num__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(0), nil); var den__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000056__7, lang.RT_IntCast_J__I_NoInit(1), nil); var integral__10 bool; var tmp2 *jrt.BigInteger


					jrt.BigInteger_Init(); tmp2 = jrt.BigInteger_ONE; integral__10 = lang.Util_Equiv_O_O__Z_NoInit(den__9, tmp2.Ref())
//line :168:1
					var bd__11 any; var tmp3 any
					var and__1927000168__auto____11 any = prefer_ratio__5


					if jrt.J2g_Truth(and__1927000168__auto____11) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(integral__10).Ref()) } else { tmp3 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp3) { bd__11 = nil } else { bd__11 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_55.GetRawRoot__O()).Invoke_O_O__O(num__8, den__9) }
					var tmp4 any; var and__1927000168__auto____12 any = bd__11; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 bool = integral__10; if or__1927000174__auto____13 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { var tmp5 bool; var na_18 int64 = int64(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(bd__11))); var na_19 any = A_arbace_repr_go_lit_A_const_56.GetRawRoot__O(); if jrt.Long_InstanceOf(na_19) { var n0_20 int64 = na_18; var n1_21 int64 = jrt.NN(jrt.Long_Cast(na_19)).LongValue__J(); tmp5 = n0_20 <= n1_21 } else { tmp5 = lang.Numbers_Lte_J_O__Z_NoInit(na_18, na_19) }; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } } else { tmp4 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp4) { var s__12 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_53.GetRawRoot__O()).Invoke_O__O(bd__11); var tmp6 *jrt.Class = A_arbace_repr_go_lit_A_const_57
						return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, s__12, nil)).Ref(), lang.Reflector_InvokeConstructor_Class_O1__O(tmp6, jrt.RefArrayOf(jrt.Object_class, s__12))) } else {
							return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, num__8, nil, den__9)).Ref(), v__0) } } } }
//line :158:1
func (t *A_arbace_repr_go_lit_float_lit_A) Invoke_O_O__O(self, v__0 any) any {





	return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_58.GetRawRoot__O()).Invoke_O_O__O(v__0, lang.PersistentArrayMap_EMPTY.Ref())
}











func A_arbace_repr_go_lit_double_lit_A_New() *A_arbace_repr_go_lit_double_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_double_lit_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_repr_go_lit_double_lit_A) Ctor() {}
//line :177:1
func (t *A_arbace_repr_go_lit_double_lit_A) Invoke_O_O__O(self, r__0 any) any { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(r__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()); var tmp2 *jrt.String; if



	jrt.Double_IsNaN_D__Z_NoInit(d__2) { tmp2 = Lit_13 } else { if jrt.Double_IsInfinite_D__Z_NoInit(d__2) {
		if lang.Numbers_IsPos_D__Z_NoInit(d__2) { tmp2 = Lit_14 } else { tmp2 = Lit_15 } } else {
//line :181:1
			if A_arbace_repr_go_lit_A_const_21 != nil {

				tmp2 = jrt.Double_ToString_D__String_NoInit(d__2) } else {
//line :181:1
					tmp2 = nil } } }; return tmp1.Invoke_O_O__O(tmp2.Ref(), jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref()) }




func A_arbace_repr_go_lit_hex_float_value_A_New() *A_arbace_repr_go_lit_hex_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hex_float_value_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Ctor() {}
//line :186:1
func (t *A_arbace_repr_go_lit_hex_float_value_A) Invoke_O_O__O(self, t__0 any) any { var body__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(t__0, A_arbace_repr_go_lit_A_const_36); var pi__3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_59.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_30.GetRawRoot__O()).Invoke_O__O(body__2), Lit_24); var mant__4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(body__2, A_arbace_repr_go_lit_A_const_62, pi__3); var exp__5 int64; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp3 jrt.Number_I; var na_23 any = pi__3; if





	jrt.Long_InstanceOf(na_23) { var n0_24 int64 = jrt.NN(jrt.Long_Cast(na_23)).LongValue__J(); if n0_24 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_23) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_24 + 1)) } } else { if jrt.Double_InstanceOf(na_23) { var n0_24_2 float64 = jrt.NN(jrt.Double_Cast(na_23)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_24_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_23) } }; exp__5 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp1.Invoke_O_O_O__O(tmp2.Invoke_O_O__O(body__2, tmp3), Lit_25, Lit_23))); var dot__6 any = /*line :186:1*/lang.IFn_Cast(A_arbace_repr_go_lit_A_const_59.GetRawRoot__O()).Invoke_O_O__O(mant__4, Lit_8); var int_part__7 any; if







	jrt.J2g_Truth(dot__6) { int_part__7 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(mant__4, A_arbace_repr_go_lit_A_const_62, dot__6) } else { int_part__7 = mant__4 }; var frac__8 any; if
	jrt.J2g_Truth(dot__6) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_25 any = dot__6; if jrt.Long_InstanceOf(na_25) { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); if n0_26 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_25) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_26 + 1)) } } else { if jrt.Double_InstanceOf(na_25) { var n0_26_2 float64 = jrt.NN(jrt.Double_Cast(na_25)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_26_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_25) } }; frac__8 = tmp4.Invoke_O_O__O(mant__4, tmp5) } else { frac__8 = Lit_23 }; var digits__9 any = /*line :186:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, int_part__7, frac__8)).Ref(); var m__10 any; if










	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_60.GetRawRoot__O()).Invoke_O__O(digits__9)) { jrt.BigInteger_Init(); m__10 = jrt.BigInteger_ZERO.Ref() } else { m__10 = jrt.BigInteger_New_String_I(jrt.String_Cast(digits__9), lang.RT_IntCast_J__I_NoInit(16)) }; var e__11 int64 = /*line :186:1*/lang.Numbers_Minus_J_J__J_NoInit(exp__5, lang.Numbers_Multiply_J_J__J_NoInit(4, int64(lang.RT_Count_O__I_NoInit(frac__8)))); if












	lang.Numbers_IsNeg_J__Z_NoInit(e__11) {
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_61.GetRawRoot__O()).Invoke_O_O__O(m__10, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__11)).Ref())) } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_61.GetRawRoot__O()); var tmp7 any = jrt.NN(jrt.BigInteger_Cast(m__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__11)).Ref(); var tmp8 *jrt.BigInteger; jrt.BigInteger_Init(); tmp8 = jrt.BigInteger_ONE; return tmp6.Invoke_O_O__O(tmp7, tmp8.Ref()) } }

func A_arbace_repr_go_lit_float_value_A_New() *A_arbace_repr_go_lit_float_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_value_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_repr_go_lit_float_value_A) Ctor() {}
//line :203:1
func (t *A_arbace_repr_go_lit_float_value_A) Invoke_O_O__O(self, text__0 any) any { var t__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(text__0, Lit_22, Lit_23); if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_30.GetRawRoot__O()).Invoke_O__O(t__2), Lit_21)) {
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_64.GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :208:1
			return jrt.BigDecimal_New_String(jrt.String_Cast(t__2)) } }



func A_arbace_repr_go_lit_float_text_lit_A_New() *A_arbace_repr_go_lit_float_text_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_float_text_lit_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_go_lit_float_text_lit_A) Invoke_O_O__O(self, text__0 any) any { var hex__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_30.GetRawRoot__O()).Invoke_O__O(text__0), Lit_21); return /*line :217:1*/ lang.IFn_Cast(A_arbace_repr_go_lit_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_65.GetRawRoot__O()).Invoke_O__O(text__0), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_51, hex__2))) }

func A_arbace_repr_go_lit_imag_inner_A_New() *A_arbace_repr_go_lit_imag_inner_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_imag_inner_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Ctor() {}
//line :219:1
func (t *A_arbace_repr_go_lit_imag_inner_A) Invoke_O_O__O(self, text__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_62; var t__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O_O_O__O(text__0, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref()), Lit_22, Lit_23); var lower__3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_30.GetRawRoot__O()).Invoke_O__O(t__2); if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_66.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_A_const_69, t__2)) { var v__4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.BigInteger_New_String(jrt.String_Cast(t__2))); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_41.GetRawRoot__O()).Invoke_O__O(v__4); var tmp5 any

		if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(v__4))).BitLength__I()), 64) { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__4)).Ref() } else { tmp5 = v__4 }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
//line :225:1
			var tmp6 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_66.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_A_const_70, lower__3)


			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_24)); if jrt.J2g_Truth(and__1927000168__auto____5) {
				tmp6 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lower__3, Lit_8)) } else {
//line :228:1
					tmp6 = and__1927000168__auto____5 } } else { tmp6 = and__1927000168__auto____4 }
//line :225:1
			if jrt.J2g_Truth(tmp6) {




				return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_67.GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :225:1
					if A_arbace_repr_go_lit_A_const_21 != nil {





						return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_68.GetRawRoot__O()).Invoke_O__O(t__2) } else {
//line :225:1
							return nil } } } }









func A_arbace_repr_go_lit_hexv_A_New() *A_arbace_repr_go_lit_hexv_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_hexv_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_repr_go_lit_hexv_A) Ctor() {}
//line :235:1
func (t *A_arbace_repr_go_lit_hexv_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(s__0), lang.RT_IntCast_J__I_NoInit(16))).Ref() }

func A_arbace_repr_go_lit_unescape_A_New() *A_arbace_repr_go_lit_unescape_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_repr_go_lit_unescape_A) Ctor() {}
//line :237:1
func (t *A_arbace_repr_go_lit_unescape_A) Invoke_O_O__O(self, body__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var n__3 int32 = jrt.NN(jrt.String_Cast(body__0)).Length__I(); var put_cp__4 any; var tmp1 any = A_arbace_repr_go_lit_unescape_put_cp__790000066_A_New_O(out__2); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_lit_unescape_put_cp__790000066_A_fn_class; if




	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_lit_unescape_put_cp__790000066_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; put_cp__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var i__5 int64 = 0; L1:
//line :237:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(n__3)) { var c__6 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__5))

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_71.GetRawRoot__O()).Invoke_O_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__6).Ref(), A_arbace_repr_go_lit_A_const_75)) { var cp__7 int32 = jrt.NN(jrt.String_Cast(body__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__5))

				lang.IFn_Cast(put_cp__4).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(cp__7).Ref())
				i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, int64(jrt.Character_CharCount_I__I_NoInit(cp__7))); continue L1 } else {
//line :248:1
					var e__7 uint16 = jrt.NN(jrt.String_Cast(body__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)))
					var G__790000068__8_ uint16 = e__7



				L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_72) {









					jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(34)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
					break L2 }; case 39: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_73) {








						jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(39)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
						break L2 }; case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_74) {












							lang.IFn_Cast(put_cp__4).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 10)).Ref()))); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 10); continue L1
//line :253:1
							break L2 }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_75) {







								jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(92)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
								break L2 }; case 97: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_77) {
									jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(7)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
									break L2 }; case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_78) {

										jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(8)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
										break L2 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_79) {


											jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(12)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
											break L2 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_80) {



												jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
												break L2 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_81) {




													jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(13)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
													break L2 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_82) {





														jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(9)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
														break L2 }; case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_83) {











															lang.IFn_Cast(put_cp__4).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 6)).Ref()))); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 6); continue L1
//line :253:1
															break L2 }; case 118: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_84) {






																jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(11)); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 2); continue L1
//line :253:1
																break L2 }; case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000068__8_).Ref(), A_arbace_repr_go_lit_A_const_85) {










																	jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 2)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref())))); i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1
//line :253:1
																	break L2 }; default:
				}












					jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(body__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__5)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__5, 4)).Ref())), lang.RT_IntCast_J__I_NoInit(8))))
					i__5 = lang.Numbers_Add_J_J__J_NoInit(i__5, 4); continue L1} } }
//line :237:1
		break L1 }; return out__2 }




func A_arbace_repr_go_lit_unescape_put_cp__790000066_A_New_O(p0 any) *A_arbace_repr_go_lit_unescape_put_cp__790000066_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_unescape_put_cp__790000066_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000066_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :242:1
func (t *A_arbace_repr_go_lit_unescape_put_cp__790000066_A) Invoke_O_O__O(self, cp__1 any) any { var bs__2 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_O__I_NoInit(cp__1))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(t.F_out);

	jrt.NN(tmp1).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))); return nil }


























func A_arbace_repr_go_lit_string_bytes_A_New() *A_arbace_repr_go_lit_string_bytes_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_string_bytes_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Ctor() {}
//line :271:1
func (t *A_arbace_repr_go_lit_string_bytes_A) Invoke_O_O__O(self, text__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(text__0, Lit_33)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_38; return jrt.NN(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O_O_O__O(text__0, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref()), Lit_34, Lit_23))).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref() } else {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_lit_A_const_38; return jrt.NN(jrt.ByteArrayOutputStream_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_86.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O_O__O(text__0, tmp4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref())))).ToByteArray__B1().Ref()
		} }
func A_arbace_repr_go_lit_rune_value_A_New() *A_arbace_repr_go_lit_rune_value_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_value_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_repr_go_lit_rune_value_A) Ctor() {}
//line :278:1
func (t *A_arbace_repr_go_lit_rune_value_A) Invoke_O_O__O(self, text__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_38; var body__2 any = tmp1.Invoke_O_O_O__O(text__0, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(text__0)))).Ref()); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_31.GetRawRoot__O()).Invoke_O_O__O(body__2, Lit_5)) { var G__790000071__3_ uint16 = jrt.NN(jrt.String_Cast(body__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(1))
		switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref()) { case 48: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_87) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 49: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_88) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 50: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_89) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 51: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_90) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 52: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_91) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_92) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 54: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_93) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 55: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_94) {



			return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_38)), lang.RT_IntCast_J__I_NoInit(8))).Ref() }
//line :283:1
		case 85: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_74) {


			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_36)) }
//line :283:1
		case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_83) {

			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_36)) }
//line :283:1
		case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__790000071__3_).Ref(), A_arbace_repr_go_lit_A_const_85) {
			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_35.GetRawRoot__O()).Invoke_O_O__O(body__2, A_arbace_repr_go_lit_A_const_36)) }
//line :283:1
		default:}; var bs__4 any = jrt.NN(jrt.ByteArrayOutputStream_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_86.GetRawRoot__O()).Invoke_O__O(body__2))).ToByteArray__B1().Ref()





		return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.String_Cast(body__2)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)))).Ref() } }

func A_arbace_repr_go_lit_decode_rune_A_New() *A_arbace_repr_go_lit_decode_rune_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Ctor() {}
//line :292:1
func (t *A_arbace_repr_go_lit_decode_rune_A) Invoke_O_O_O_O__O(self, bs__0, i__1, n__2 any) any { var b__4 any; var tmp1 any = A_arbace_repr_go_lit_decode_rune_b__790000073_A_New_O(bs__0); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_lit_decode_rune_b__790000073_A_fn_class; if


	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_lit_decode_rune_b__790000073_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; b__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var cont_QMARK___5 any; var tmp3 any = /*line :292:1*/A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_New_O_O(n__2, b__4); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_fn_class; if



	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; cont_QMARK___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var b0__6 any = /*line :292:1*/lang.IFn_Cast(b__4).Invoke_O__O(i__1); var tmp5 bool; var na_42 any = b0__6; var na_43 int64 = 128; if






	jrt.Long_InstanceOf(na_42) { var n0_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); var n1_45 int64 = na_43; tmp5 = n0_44 < n1_45 } else { tmp5 = lang.Numbers_Lt_O_J__Z_NoInit(na_42, na_43) }; if tmp5 {
//line :298:1
		return lang.Tuple_Create_O_O__IPersistentVector(b0__6, A_arbace_repr_go_lit_A_const_38) } else { var tmp6 bool
			var na_47 any = b0__6; var na_48 int64 = 194
			if jrt.Long_InstanceOf(na_47) { var n0_49 int64 = jrt.NN(jrt.Long_Cast(na_47)).LongValue__J(); var n1_50 int64 = na_48; tmp6 = n0_49 < n1_50 } else { tmp6 = lang.Numbers_Lt_O_J__Z_NoInit(na_47, na_48) }
//line :298:1
			if tmp6 { return A_arbace_repr_go_lit_A_const_95 } else { var tmp7 bool
				var na_52 any = b0__6
				var na_53 int64 = 224
				if jrt.Long_InstanceOf(na_52) { var n0_54 int64 = jrt.NN(jrt.Long_Cast(na_52)).LongValue__J(); var n1_55 int64 = na_53; tmp7 = n0_54 < n1_55 } else { tmp7 = lang.Numbers_Lt_O_J__Z_NoInit(na_52, na_53) }
//line :298:1
				if tmp7 {


					var tmp8 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp9 jrt.Number_I; var na_85 any = i__1; if jrt.Long_InstanceOf(na_85) { var n0_86 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); if n0_86 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_85) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_86 + 1)) } } else { if jrt.Double_InstanceOf(na_85) { var n0_86_2 float64 = jrt.NN(jrt.Double_Cast(na_85)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_86_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_85) } }; if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) { var tmp10 int64; var na_87 any = b0__6; var na_88 int64 = 31
						if jrt.Long_InstanceOf(na_87) { var n0_89 int64 = jrt.NN(jrt.Long_Cast(na_87)).LongValue__J(); var n1_90 int64 = na_88; tmp10 = n0_89 & n1_90 } else { tmp10 = lang.Numbers_And_O_J__J_NoInit(na_87, na_88) }
//line :301:1
						var tmp11 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp10, 6); var tmp12 int64; var na_92 any; var tmp13 lang.IFn = lang.IFn_Cast(b__4); var tmp14 jrt.Number_I; var na_97 any = i__1
						if jrt.Long_InstanceOf(na_97) { var n0_98 int64 = jrt.NN(jrt.Long_Cast(na_97)).LongValue__J(); if n0_98 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_97) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_98 + 1)) } } else { if jrt.Double_InstanceOf(na_97) { var n0_98_2 float64 = jrt.NN(jrt.Double_Cast(na_97)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_98_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_97) } }; na_92 = tmp13.Invoke_O__O(tmp14); var na_93 int64 = 63; if jrt.Long_InstanceOf(na_92) { var n0_94 int64 = jrt.NN(jrt.Long_Cast(na_92)).LongValue__J(); var n1_95 int64 = na_93; tmp12 = n0_94 & n1_95 } else { tmp12 = lang.Numbers_And_O_J__J_NoInit(na_92, na_93) }
//line :301:1
						return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp11, tmp12)).Ref(), A_arbace_repr_go_lit_A_const_36) } else { return A_arbace_repr_go_lit_A_const_96 } } else {
//line :298:1
							var tmp15 bool
							var na_57 any = b0__6
							var na_58 int64 = 240



							if jrt.Long_InstanceOf(na_57) { var n0_59 int64 = jrt.NN(jrt.Long_Cast(na_57)).LongValue__J(); var n1_60 int64 = na_58; tmp15 = n0_59 < n1_60 } else { tmp15 = lang.Numbers_Lt_O_J__Z_NoInit(na_57, na_58) }
//line :298:1
							if tmp15 { var lo__7 int64; var G__790000077__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)





							L1: switch { default: switch G__790000077__7_ { case 224: lo__7 = 160; break L1; default:}; lo__7 = 128}
//line :298:1
								var hi__8 int64; var G__790000078__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)






							L2: switch { default: switch G__790000078__8_ { case 237: hi__8 = 159; break L2; default:}; hi__8 = 191}
								var tmp16 any; var and__1927000168__auto____9 bool; var na_64 any; var na_66 any = i__1; if jrt.Long_InstanceOf(na_66) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_66)).LongValue__J(); if n0_67 == 9223372036854775807 { na_64 = lang.Numbers_Inc_O__Number_NoInit(na_66) } else { na_64 = jrt.Long_ValueOf_J__Long_NoInit(n0_67 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_66) { var n0_67_2 float64 = jrt.NN(jrt.Double_Cast(na_66)).DoubleValue__D(); na_64 = jrt.Double_ValueOf_D__Double_NoInit(n0_67_2 + 1.0).Ref() } else { na_64 = lang.Numbers_Inc_O__Number_NoInit(na_66) } }; var na_65 any = n__2; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_64); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_65) }; tmp17 = tmp18; if tmp17 { var n0_68 int64 = jrt.NN(jrt.Long_Cast(na_64)).LongValue__J(); var n1_69 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); and__1927000168__auto____9 = n0_68 < n1_69 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_64); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_65) }; tmp19 = tmp20; if tmp19 { var n0_68_2 float64 = jrt.NN(jrt.Double_Cast(na_64)).DoubleValue__D(); var n1_69_2 float64 = jrt.NN(jrt.Double_Cast(na_65)).DoubleValue__D(); and__1927000168__auto____9 = n0_68_2 < n1_69_2 } else { and__1927000168__auto____9 = lang.Numbers_Lt_O_O__Z_NoInit(na_64, na_65) } }; if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp22 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(b__4); var tmp24 jrt.Number_I; var na_99 any = i__1; if jrt.Long_InstanceOf(na_99) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); if n0_100 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_99) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_100 + 1)) } } else { if jrt.Double_InstanceOf(na_99) { var n0_100_2 float64 = jrt.NN(jrt.Double_Cast(na_99)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_100_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_99) } }; and__1927000168__auto____10 = tmp21.Invoke_O_O_O__O(tmp22, tmp23.Invoke_O__O(tmp24), jrt.Long_ValueOf_J__Long_NoInit(hi__8).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp25 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp26 jrt.Number_I; var na_101 any = i__1; var na_102 int64 = 2; if jrt.Long_InstanceOf(na_101) { var n0_103 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); var n1_104 int64 = na_102; var nr_105 int64 = n0_103 + n1_104; if (n0_103^nr_105)&(n1_104^nr_105) >= 0 { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_105)) } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_101, na_102) } } else { tmp26 = lang.Numbers_Add_O_J__Number_NoInit(na_101, na_102) }; tmp16 = tmp25.Invoke_O__O(tmp26) } else { tmp16 = and__1927000168__auto____10 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp16) { var tmp27 int64; var na_106 any = b0__6; var na_107 int64 = 15
									if jrt.Long_InstanceOf(na_106) { var n0_108 int64 = jrt.NN(jrt.Long_Cast(na_106)).LongValue__J(); var n1_109 int64 = na_107; tmp27 = n0_108 & n1_109 } else { tmp27 = lang.Numbers_And_O_J__J_NoInit(na_106, na_107) }
//line :306:1
									var tmp28 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp27, 12); var tmp29 int64; var na_111 any; var tmp30 lang.IFn = lang.IFn_Cast(b__4); var tmp31 jrt.Number_I
									var na_121 any = i__1
									if jrt.Long_InstanceOf(na_121) { var n0_122 int64 = jrt.NN(jrt.Long_Cast(na_121)).LongValue__J(); if n0_122 == 9223372036854775807 { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_121) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_122 + 1)) } } else { if jrt.Double_InstanceOf(na_121) { var n0_122_2 float64 = jrt.NN(jrt.Double_Cast(na_121)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_122_2 + 1.0)) } else { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_121) } }; na_111 = tmp30.Invoke_O__O(tmp31); var na_112 int64 = 63; if jrt.Long_InstanceOf(na_111) { var n0_113 int64 = jrt.NN(jrt.Long_Cast(na_111)).LongValue__J(); var n1_114 int64 = na_112; tmp29 = n0_113 & n1_114 } else { tmp29 = lang.Numbers_And_O_J__J_NoInit(na_111, na_112) }
//line :306:1
									var tmp32 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp28, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp29, 6)); var tmp33 int64; var na_116 any; var tmp34 lang.IFn = lang.IFn_Cast(b__4); var tmp35 jrt.Number_I
									var na_123 any = i__1
									var na_124 int64 = 2
									if jrt.Long_InstanceOf(na_123) { var n0_125 int64 = jrt.NN(jrt.Long_Cast(na_123)).LongValue__J(); var n1_126 int64 = na_124; var nr_127 int64 = n0_125 + n1_126; if (n0_125^nr_127)&(n1_126^nr_127) >= 0 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_127)) } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_123, na_124) } } else { tmp35 = lang.Numbers_Add_O_J__Number_NoInit(na_123, na_124) }; na_116 = tmp34.Invoke_O__O(tmp35); var na_117 int64 = 63; if jrt.Long_InstanceOf(na_116) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_116)).LongValue__J(); var n1_119 int64 = na_117; tmp33 = n0_118 & n1_119 } else { tmp33 = lang.Numbers_And_O_J__J_NoInit(na_116, na_117) }
//line :306:1
									return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp32, tmp33)).Ref(), A_arbace_repr_go_lit_A_const_100) } else { return A_arbace_repr_go_lit_A_const_97 } } else {
//line :298:1
										var tmp36 bool
										var na_71 any = b0__6
										var na_72 int64 = 245










										if jrt.Long_InstanceOf(na_71) { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_71)).LongValue__J(); var n1_74 int64 = na_72; tmp36 = n0_73 < n1_74 } else { tmp36 = lang.Numbers_Lt_O_J__Z_NoInit(na_71, na_72) }
//line :298:1
										if tmp36 { var lo__7_2 int64; var G__790000079__7_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)












										L3: switch { default: switch G__790000079__7_ { case 240: lo__7_2 = 144; break L3; default:}; lo__7_2 = 128}
//line :298:1
											var hi__8_2 int64; var G__790000080__8_ int32 = lang.RT_IntCast_O__I_NoInit(b0__6)













										L4: switch { default: switch G__790000080__8_ { case 244: hi__8_2 = 143; break L4; default:}; hi__8_2 = 191}
											var tmp37 any; var and__1927000168__auto____9_2 bool; var na_78 any; var na_80 any = i__1; if jrt.Long_InstanceOf(na_80) { var n0_81 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); if n0_81 == 9223372036854775807 { na_78 = lang.Numbers_Inc_O__Number_NoInit(na_80) } else { na_78 = jrt.Long_ValueOf_J__Long_NoInit(n0_81 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_80) { var n0_81_2 float64 = jrt.NN(jrt.Double_Cast(na_80)).DoubleValue__D(); na_78 = jrt.Double_ValueOf_D__Double_NoInit(n0_81_2 + 1.0).Ref() } else { na_78 = lang.Numbers_Inc_O__Number_NoInit(na_80) } }; var na_79 any = n__2; var tmp38 bool; var tmp39 bool; tmp39 = jrt.Long_InstanceOf(na_78); if tmp39 { tmp39 = jrt.Long_InstanceOf(na_79) }; tmp38 = tmp39; if tmp38 { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_83 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); and__1927000168__auto____9_2 = n0_82 < n1_83 } else { var tmp40 bool; var tmp41 bool; tmp41 = jrt.Double_InstanceOf(na_78); if tmp41 { tmp41 = jrt.Double_InstanceOf(na_79) }; tmp40 = tmp41; if tmp40 { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_83_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); and__1927000168__auto____9_2 = n0_82_2 < n1_83_2 } else { and__1927000168__auto____9_2 = lang.Numbers_Lt_O_O__Z_NoInit(na_78, na_79) } }; if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp43 any = jrt.Long_ValueOf_J__Long_NoInit(lo__7_2).Ref(); var tmp44 lang.IFn = lang.IFn_Cast(b__4); var tmp45 jrt.Number_I; var na_128 any = i__1; if jrt.Long_InstanceOf(na_128) { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_128)).LongValue__J(); if n0_129 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_128) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_129 + 1)) } } else { if jrt.Double_InstanceOf(na_128) { var n0_129_2 float64 = jrt.NN(jrt.Double_Cast(na_128)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_129_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_128) } }; and__1927000168__auto____10_2 = tmp42.Invoke_O_O_O__O(tmp43, tmp44.Invoke_O__O(tmp45), jrt.Long_ValueOf_J__Long_NoInit(hi__8_2).Ref()); if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11 any; var tmp46 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp47 jrt.Number_I; var na_130 any = i__1; var na_131 int64 = 2; if jrt.Long_InstanceOf(na_130) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_130)).LongValue__J(); var n1_133 int64 = na_131; var nr_134 int64 = n0_132 + n1_133; if (n0_132^nr_134)&(n1_133^nr_134) >= 0 { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_134)) } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_130, na_131) } } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_130, na_131) }; and__1927000168__auto____11 = tmp46.Invoke_O__O(tmp47); if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp48 lang.IFn = lang.IFn_Cast(cont_QMARK___5); var tmp49 jrt.Number_I; var na_135 any = i__1; var na_136 int64 = 3; if jrt.Long_InstanceOf(na_135) { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); var n1_138 int64 = na_136; var nr_139 int64 = n0_137 + n1_138; if (n0_137^nr_139)&(n1_138^nr_139) >= 0 { tmp49 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_139)) } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_135, na_136) } } else { tmp49 = lang.Numbers_Add_O_J__Number_NoInit(na_135, na_136) }; tmp37 = tmp48.Invoke_O__O(tmp49) } else { tmp37 = and__1927000168__auto____11 } } else { tmp37 = and__1927000168__auto____10_2 } } else { tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }; if jrt.J2g_Truth(tmp37) { var tmp50 int64; var na_140 any = b0__6; var na_141 int64 = 7
												if jrt.Long_InstanceOf(na_140) { var n0_142 int64 = jrt.NN(jrt.Long_Cast(na_140)).LongValue__J(); var n1_143 int64 = na_141; tmp50 = n0_142 & n1_143 } else { tmp50 = lang.Numbers_And_O_J__J_NoInit(na_140, na_141) }
//line :313:1
												var tmp51 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp50, 18); var tmp52 int64; var na_145 any; var tmp53 lang.IFn = lang.IFn_Cast(b__4); var tmp54 jrt.Number_I
												var na_160 any = i__1
												if jrt.Long_InstanceOf(na_160) { var n0_161 int64 = jrt.NN(jrt.Long_Cast(na_160)).LongValue__J(); if n0_161 == 9223372036854775807 { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_160) } else { tmp54 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_161 + 1)) } } else { if jrt.Double_InstanceOf(na_160) { var n0_161_2 float64 = jrt.NN(jrt.Double_Cast(na_160)).DoubleValue__D(); tmp54 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_161_2 + 1.0)) } else { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_160) } }; na_145 = tmp53.Invoke_O__O(tmp54); var na_146 int64 = 63; if jrt.Long_InstanceOf(na_145) { var n0_147 int64 = jrt.NN(jrt.Long_Cast(na_145)).LongValue__J(); var n1_148 int64 = na_146; tmp52 = n0_147 & n1_148 } else { tmp52 = lang.Numbers_And_O_J__J_NoInit(na_145, na_146) }
//line :313:1
												var tmp55 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp51, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp52, 12)); var tmp56 int64; var na_150 any; var tmp57 lang.IFn = lang.IFn_Cast(b__4); var tmp58 jrt.Number_I
												var na_162 any = i__1
												var na_163 int64 = 2
												if jrt.Long_InstanceOf(na_162) { var n0_164 int64 = jrt.NN(jrt.Long_Cast(na_162)).LongValue__J(); var n1_165 int64 = na_163; var nr_166 int64 = n0_164 + n1_165; if (n0_164^nr_166)&(n1_165^nr_166) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_166)) } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_162, na_163) } } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_162, na_163) }; na_150 = tmp57.Invoke_O__O(tmp58); var na_151 int64 = 63; if jrt.Long_InstanceOf(na_150) { var n0_152 int64 = jrt.NN(jrt.Long_Cast(na_150)).LongValue__J(); var n1_153 int64 = na_151; tmp56 = n0_152 & n1_153 } else { tmp56 = lang.Numbers_And_O_J__J_NoInit(na_150, na_151) }
//line :313:1
												var tmp59 int64 = lang.Numbers_Or_J_J__J_NoInit(tmp55, lang.Numbers_ShiftLeft_J_J__J_NoInit(tmp56, 6)); var tmp60 int64; var na_155 any; var tmp61 lang.IFn = lang.IFn_Cast(b__4); var tmp62 jrt.Number_I
												var na_167 any = i__1
												var na_168 int64 = 3

												if jrt.Long_InstanceOf(na_167) { var n0_169 int64 = jrt.NN(jrt.Long_Cast(na_167)).LongValue__J(); var n1_170 int64 = na_168; var nr_171 int64 = n0_169 + n1_170; if (n0_169^nr_171)&(n1_170^nr_171) >= 0 { tmp62 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_171)) } else { tmp62 = lang.Numbers_Add_O_J__Number_NoInit(na_167, na_168) } } else { tmp62 = lang.Numbers_Add_O_J__Number_NoInit(na_167, na_168) }; na_155 = tmp61.Invoke_O__O(tmp62); var na_156 int64 = 63; if jrt.Long_InstanceOf(na_155) { var n0_157 int64 = jrt.NN(jrt.Long_Cast(na_155)).LongValue__J(); var n1_158 int64 = na_156; tmp60 = n0_157 & n1_158 } else { tmp60 = lang.Numbers_And_O_J__J_NoInit(na_155, na_156) }
//line :313:1
												return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp59, tmp60)).Ref(), A_arbace_repr_go_lit_A_const_101) } else { return A_arbace_repr_go_lit_A_const_98 } } else {
//line :298:1
													if A_arbace_repr_go_lit_A_const_21 != nil { return A_arbace_repr_go_lit_A_const_99 } else { return nil } } } } } } }
//line :295:1
func A_arbace_repr_go_lit_decode_rune_b__790000073_A_New_O(p0 any) *A_arbace_repr_go_lit_decode_rune_b__790000073_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_b__790000073_A{}; t.Ctor_O(p0); return t }
//line :295:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000073_A) Ctor_O(c__bs any) { t.F_bs = c__bs }
//line :295:1
func (t *A_arbace_repr_go_lit_decode_rune_b__790000073_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_bs, jrt.Prim_byte.ArrayClass()); return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(k__1)))))).Ref() }
func A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A) Ctor_O_O(c__n, c__b any) { t.F_n = c__n; t.F_b = c__b }
//line :296:1
func (t *A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A) Invoke_O_O__O(self, k__1 any) any { var and__1927000168__auto____2 bool; var na_31 any = k__1; var na_32 any = t.F_n; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_31); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_32) }; tmp1 = tmp2; if tmp1 { var n0_33 int64 = jrt.NN(jrt.Long_Cast(na_31)).LongValue__J(); var n1_34 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); and__1927000168__auto____2 = n0_33 < n1_34 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_31); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_32) }; tmp3 = tmp4; if tmp3 { var n0_33_2 float64 = jrt.NN(jrt.Double_Cast(na_31)).DoubleValue__D(); var n1_34_2 float64 = jrt.NN(jrt.Double_Cast(na_32)).DoubleValue__D(); and__1927000168__auto____2 = n0_33_2 < n1_34_2 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_O__Z_NoInit(na_31, na_32) } }; if and__1927000168__auto____2 { var tmp5 int64; var na_36 any = lang.IFn_Cast(t.F_b).Invoke_O__O(k__1); var na_37 int64 = 192; if jrt.Long_InstanceOf(na_36) { var n0_38 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var n1_39 int64 = na_37; tmp5 = n0_38 & n1_39 } else { tmp5 = lang.Numbers_And_O_J__J_NoInit(na_36, na_37) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(128, tmp5)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
























func A_arbace_repr_go_lit_utf8_parts_A_New() *A_arbace_repr_go_lit_utf8_parts_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_utf8_parts_A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Ctor() {}
//line :321:1
func (t *A_arbace_repr_go_lit_utf8_parts_A) Invoke_O_O__O(self, bs__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass())); var i__3 int64 = 0; var run__4 any = jrt.StringBuilder_New(); var parts__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_J_J__Z_NoInit(i__3, int64(n__2)) {
		if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_6.GetRawRoot__O()).Invoke_O_O__O(parts__5, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(run__4)) } else { return parts__5 } } else {
//line :326:1
			var vec__790000082__6 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_102.GetRawRoot__O()).Invoke_O_O_O__O(bs__0, jrt.Long_ValueOf_J__Long_NoInit(i__3).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref()); var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var w__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)


			if lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(r__7)) {
				var tmp1 int64 = lang.Numbers_Inc_J__J_NoInit(i__3); var tmp2 any = jrt.StringBuilder_New(); var tmp3 any; var G__790000085__9_ any = parts__5; var G__790000085__10_ any
				if lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.StringBuilder_Cast(run__4)).Length__I())) {
					G__790000085__10_ = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_6.GetRawRoot__O()).Invoke_O_O__O(G__790000085__9_, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(run__4)) } else {
//line :331:1
						G__790000085__10_ = G__790000085__9_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {

							tmp3 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_6.GetRawRoot__O()).Invoke_O_O__O(G__790000085__10_, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_B__J_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__3)))))).Ref()) } else {
//line :331:1
								tmp3 = G__790000085__10_ }
//line :330:1
				i__3, run__4, parts__5 = tmp1, tmp2, tmp3; continue L1 } else {



					i__3, run__4, parts__5 = lang.Numbers_Add_J_J__J_NoInit(i__3, lang.RT_LongCast_O__J_NoInit(w__8)), jrt.NN(jrt.StringBuilder_Cast(run__4)).AppendCodePoint_I__StringBuilder(lang.RT_IntCast_O__I_NoInit(r__7)).Ref(), parts__5; continue L1 } } } }; /*line :321:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_lit_rune_form_A_New() *A_arbace_repr_go_lit_rune_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_rune_form_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_repr_go_lit_rune_form_A) Ctor() {}
//line :336:1
func (t *A_arbace_repr_go_lit_rune_form_A) Invoke_O_O__O(self, cp__0 any) any { var cp__2 int64 = lang.RT_LongCast_O__J_NoInit(cp__0); var tmp1 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_lit_A_const_62; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_104); if




	jrt.J2g_Truth(and__1927000168__auto____3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_12.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_lit_A_const_105; tmp1 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_11.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref(), A_arbace_repr_go_lit_A_const_106)) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_107.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref()), jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_J__C_NoInit(cp__2)).Ref()) } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_lit_A_const_108; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()); var tmp9 any; if lang.Numbers_IsNeg_J__Z_NoInit(cp__2) { tmp9 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref()) } else { tmp9 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_32, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref()) }; return tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, jrt.Long_ValueOf_J__Long_NoInit(cp__2).Ref())) } }

func A_arbace_repr_go_lit_bytes_form_A_New() *A_arbace_repr_go_lit_bytes_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Ctor() {}
//line :345:1
func (t *A_arbace_repr_go_lit_bytes_form_A) Invoke_O_O__O(self, bs__0 any) any { var parts__2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_109.GetRawRoot__O()).Invoke_O__O(bs__0); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_110.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_A_const_112.GetRawRoot__O(), parts__2)) { var s__3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_111.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O(), parts__2)
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_113.GetRawRoot__O()).Invoke_O__O(s__3), s__3) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_111.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_lit_A_const_103.GetRawRoot__O(); var tmp3 any = A_arbace_repr_go_lit_A_const_114; var tmp4 any; var iter__1927001039__auto____3 any; var tmp5 any = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_New(); var tmp6 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_fn_class
			if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_fn_class = fncls__174d; tmp6 = fncls__174d } else { tmp6 = fncls__174 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(parts__2)
//line :351:1
			return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) } }
func A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_New() *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A) Ctor() {}
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A) Invoke_O_O__O(self, s__790000089__1 any) any { var tmp1 any = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_New_O_O(self, s__790000089__1); var tmp2 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_fn_class = fncls__173d; tmp2 = fncls__173d } else { tmp2 = fncls__173 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :352:1
func A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_New_O_O(p0, p1 any) *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A) Ctor_O_O(c__iter__790000088, c__s__790000089 any) { t.F_iter__790000088 = c__iter__790000088; t.F_s__790000089 = c__s__790000089 }
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A) Invoke_O__O(self any) any { { var s__790000089__1 any; var t_ any = t.F_s__790000089; t.F_s__790000089 = nil; s__790000089__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_22.GetRawRoot__O()).Invoke_O__O(s__790000089__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__790000089__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_23.GetRawRoot__O()).Invoke_O__O(s__790000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_24.GetRawRoot__O()).Invoke_O__O(s__790000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__790000091__6 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_115.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_New_I_O_O(size__1927001038__auto____5, b__790000091__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_fn_class = fncls__172d; tmp2 = fncls__172d } else { tmp2 = fncls__172 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__790000088); return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_117.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_119.GetRawRoot__O()).Invoke_O__O(b__790000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_26.GetRawRoot__O()).Invoke_O__O(s__790000089__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_117.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_119.GetRawRoot__O()).Invoke_O__O(b__790000091__6), nil) } } else { var p__4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(s__790000089__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_118.GetRawRoot__O()); var tmp5 any
														if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_112.GetRawRoot__O()).Invoke_O__O(p__4)) { tmp5 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_113.GetRawRoot__O()).Invoke_O__O(p__4), p__4) } else { tmp5 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref()), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__4)).Ref()) }
//line :352:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__790000088); return tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_120.GetRawRoot__O()).Invoke_O__O(s__790000089__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__790000091, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__790000091 = c__b__790000091; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A) Invoke_O__O(self any) any { { var i__790000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__790000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__790000090__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_116.GetRawRoot__O()); var tmp3 any = t.F_b__790000091; var tmp4 any
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_112.GetRawRoot__O()).Invoke_O__O(p__2)) { tmp4 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_113.GetRawRoot__O()).Invoke_O__O(p__2), p__2) } else { tmp4 = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_20.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref()), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__2)).Ref()) }
//line :352:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__790000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__790000090__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_lit_val_rational_A_New() *A_arbace_repr_go_lit_val_rational_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_val_rational_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_repr_go_lit_val_rational_A) Ctor() {}
//line :357:1
func (t *A_arbace_repr_go_lit_val_rational_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_121.GetRawRoot__O()).Invoke_O__O(v__0)) { return v__0 } else { var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)

		if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_repr_go_lit_A_const_123; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0)); if and__1927000168__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }
//line :360:1
		if jrt.J2g_Truth(tmp1) {

			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_124.GetRawRoot__O()).Invoke_O__O(v__0) } else {
//line :360:1
				var tmp3 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)


				if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp4 any = A_arbace_repr_go_lit_A_const_123; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp3 = and__1927000168__auto____2_2 }
//line :360:1
				if jrt.J2g_Truth(tmp3) { var vec__790000099__2 any = v__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000099__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000099__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000099__2, lang.RT_IntCast_J__I_NoInit(2), nil); var m__6 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_40.GetRawRoot__O()).Invoke_O__O(m__4); var e__7 int64 = lang.RT_LongCast_O__J_NoInit(e__5); _ = ___3






					if lang.Numbers_IsNeg_J__Z_NoInit(e__7) { return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_61.GetRawRoot__O()).Invoke_O_O__O(m__6, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__7)).Ref())) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_61.GetRawRoot__O()); var tmp6 any = jrt.NN(jrt.BigInteger_Cast(m__6)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__7)).Ref(); var tmp7 *jrt.BigInteger; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()) } } else {
//line :360:1
						if A_arbace_repr_go_lit_A_const_21 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_125.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_126.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_127, v__0)))))) } else { return nil
						}
					}
			}
	}
}




func A_arbace_repr_go_lit_untyped_float_form_A_New() *A_arbace_repr_go_lit_untyped_float_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_untyped_float_form_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Ctor() {}
//line :370:1
func (t *A_arbace_repr_go_lit_untyped_float_form_A) Invoke_O_O__O(self, v__0 any) any {




	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_repr_go_lit_A_const_123; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0)); if and__1927000168__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(v__0)))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_103.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_lit_A_const_128; return tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_129.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1))), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_129.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2)))) } else {
			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(v__0))
		} }
func A_arbace_repr_go_lit_const_form_A_New() *A_arbace_repr_go_lit_const_form_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_const_form_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_repr_go_lit_const_form_A) Ctor() {}
//line :379:1
func (t *A_arbace_repr_go_lit_const_form_A) Invoke_O_O_O__O(self, v__0, k__1 any) any { var k__3 any; var or__1927000174__auto____3 any = k__1; if




	jrt.J2g_Truth(or__1927000174__auto____3) { k__3 = or__1927000174__auto____3 } else {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_131.GetRawRoot__O()).Invoke_O__O(v__0)) { k__3 = A_arbace_repr_go_lit_A_const_132 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_112.GetRawRoot__O()).Invoke_O__O(v__0)) { k__3 = A_arbace_repr_go_lit_A_const_133 } else { var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)


			if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any = A_arbace_repr_go_lit_A_const_134; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp1 = and__1927000168__auto____4 }
//line :385:1
			if jrt.J2g_Truth(tmp1) { k__3 = A_arbace_repr_go_lit_A_const_133 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_121.GetRawRoot__O()).Invoke_O__O(v__0)) { k__3 = A_arbace_repr_go_lit_A_const_135 } else { var tmp3 any; var and__1927000168__auto____4_2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)




				if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp4 any = A_arbace_repr_go_lit_A_const_123; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp3 = and__1927000168__auto____4_2 }
//line :385:1
				if jrt.J2g_Truth(tmp3) { k__3 = A_arbace_repr_go_lit_A_const_123 } else { var tmp5 any; var and__1927000168__auto____4_3 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)





					if jrt.J2g_Truth(and__1927000168__auto____4_3) { var tmp6 any = A_arbace_repr_go_lit_A_const_136; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp5 = and__1927000168__auto____4_3 }
//line :385:1
					if jrt.J2g_Truth(tmp5) { k__3 = A_arbace_repr_go_lit_A_const_136 } else { k__3 = nil } } } } } } }; var G__790000104__4_ any = k__3; switch






	lang.Util_Hash_O__I_NoInit(G__790000104__4_) >> 7 & 15 { case 0: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_137) {










		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_138.GetRawRoot__O()).Invoke_O__O(v__0) }
//line :392:1
	case 3: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_132) {
		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_18.GetRawRoot__O()).Invoke_O__O(v__0), v__0) }
//line :392:1
	case 4: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_139) { var vec__790000105__5 any; var tmp7 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)












		if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp8 any = A_arbace_repr_go_lit_A_const_136; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp7 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp7) { vec__790000105__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000105__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_62) }
//line :392:1
		var re__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000105__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000105__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000108__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_136) { vec__790000108__8 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(re__6), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(im__7)) } else { vec__790000108__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6, im__7) }
//line :392:1
		var re__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000108__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000108__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_136) { f__11 = A_arbace_repr_go_lit_A_const_140.GetRawRoot__O() } else { f__11 = A_arbace_repr_go_lit_A_const_138.GetRawRoot__O() }
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_103.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_lit_A_const_143; return tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(f__11).Invoke_O__O(re__9), lang.IFn_Cast(f__11).Invoke_O__O(im__10)) }
//line :392:1
	case 5: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_141) {








		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_142.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(v__0)) }
//line :392:1
	case 8: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_136) { var vec__790000111__5 any; var tmp11 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_122.GetRawRoot__O()).Invoke_O__O(v__0)












		if jrt.J2g_Truth(and__1927000168__auto____5_2) { var tmp12 any = A_arbace_repr_go_lit_A_const_136; tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp12, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_25.GetRawRoot__O()).Invoke_O__O(v__0))).Ref() } else { tmp11 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(tmp11) { vec__790000111__5 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(v__0, lang.RT_IntCast_J__I_NoInit(2))) } else { vec__790000111__5 = lang.Tuple_Create_O_O__IPersistentVector(v__0, A_arbace_repr_go_lit_A_const_62) }
//line :392:1
		var re__6_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000111__5, lang.RT_IntCast_J__I_NoInit(0), nil); var im__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000111__5, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__790000114__8 any















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_136) { vec__790000114__8 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(re__6_2), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(im__7_2)) } else { vec__790000114__8 = lang.Tuple_Create_O_O__IPersistentVector(re__6_2, im__7_2) }
//line :392:1
		var re__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000114__8, lang.RT_IntCast_J__I_NoInit(0), nil); var im__10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__790000114__8, lang.RT_IntCast_J__I_NoInit(1), nil); var f__11_2 any
















		if lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_lit_A_const_136) { f__11_2 = A_arbace_repr_go_lit_A_const_140.GetRawRoot__O() } else { f__11_2 = A_arbace_repr_go_lit_A_const_138.GetRawRoot__O() }
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_103.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_lit_A_const_143; return tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(f__11_2).Invoke_O__O(re__9_2), lang.IFn_Cast(f__11_2).Invoke_O__O(im__10_2)) }
//line :392:1
	case 9: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_123) {









		return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_140.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(v__0)) }
//line :392:1
	case 12: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_135) { var r__5 any = lang.IFn_Cast(A_arbace_repr_go_lit_A_const_130.GetRawRoot__O()).Invoke_O__O(v__0)





		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_121.GetRawRoot__O()).Invoke_O__O(r__5)) {
			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_129.GetRawRoot__O()).Invoke_O__O(r__5) } else {
//line :398:1
				panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_125.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_lit_A_const_126.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_lit_A_const_127, v__0)))))) } }
//line :392:1
	case 15: if any(G__790000104__4_) == any(A_arbace_repr_go_lit_A_const_133) {

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_112.GetRawRoot__O()).Invoke_O__O(v__0)) {
			return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_113.GetRawRoot__O()).Invoke_O__O(v__0), v__0) } else {
				return lang.IFn_Cast(A_arbace_repr_go_lit_A_const_144.GetRawRoot__O()).Invoke_O__O(lang.Numbers_Byte_array_O__B1_NoInit(lang.IFn_Cast(A_arbace_repr_go_lit_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_lit_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_lit_A_const_124.GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } }
//line :392:1
	default:}; return nil }
//line :390:1
type A_arbace_repr_go_lit_A struct{ jrt.Object }

var A_arbace_repr_go_lit_A_const_pool *jrt.RefArray

var A_arbace_repr_go_lit_A_const_0 *lang.Var

var A_arbace_repr_go_lit_A_const_1 *lang.Var

var A_arbace_repr_go_lit_A_const_2 any

var A_arbace_repr_go_lit_A_const_3 any

var A_arbace_repr_go_lit_A_const_4 *lang.Var

var A_arbace_repr_go_lit_A_const_5 *lang.Var

var A_arbace_repr_go_lit_A_const_6 *lang.Var

var A_arbace_repr_go_lit_A_const_7 any

var A_arbace_repr_go_lit_A_const_8 *lang.Var

var A_arbace_repr_go_lit_A_const_9 *lang.Var

var A_arbace_repr_go_lit_A_const_10 *lang.Var

var A_arbace_repr_go_lit_A_const_11 *lang.Var

var A_arbace_repr_go_lit_A_const_12 *lang.Var

var A_arbace_repr_go_lit_A_const_13 *lang.Var

var A_arbace_repr_go_lit_A_const_14 any

var A_arbace_repr_go_lit_A_const_15 any

var A_arbace_repr_go_lit_A_const_16 any

var A_arbace_repr_go_lit_A_const_17 any

var A_arbace_repr_go_lit_A_const_18 *lang.Var

var A_arbace_repr_go_lit_A_const_19 *lang.Var

var A_arbace_repr_go_lit_A_const_20 *lang.Var

var A_arbace_repr_go_lit_A_const_21 *lang.Keyword

var A_arbace_repr_go_lit_A_const_22 *lang.Var

var A_arbace_repr_go_lit_A_const_23 *lang.Var

var A_arbace_repr_go_lit_A_const_24 *lang.Var

var A_arbace_repr_go_lit_A_const_25 *lang.Var

var A_arbace_repr_go_lit_A_const_26 *lang.Var

var A_arbace_repr_go_lit_A_const_27 *lang.Var

var A_arbace_repr_go_lit_A_const_28 *lang.Var

var A_arbace_repr_go_lit_A_const_29 *lang.Var

var A_arbace_repr_go_lit_A_const_30 *lang.Var

var A_arbace_repr_go_lit_A_const_31 *lang.Var

var A_arbace_repr_go_lit_A_const_32 *lang.Var

var A_arbace_repr_go_lit_A_const_33 *lang.Var

var A_arbace_repr_go_lit_A_const_34 any

var A_arbace_repr_go_lit_A_const_35 *lang.Var

var A_arbace_repr_go_lit_A_const_36 any

var A_arbace_repr_go_lit_A_const_37 any

var A_arbace_repr_go_lit_A_const_38 any

var A_arbace_repr_go_lit_A_const_39 any

var A_arbace_repr_go_lit_A_const_40 *lang.Var

var A_arbace_repr_go_lit_A_const_41 *lang.Var

var A_arbace_repr_go_lit_A_const_42 any

var A_arbace_repr_go_lit_A_const_43 *lang.Var

var A_arbace_repr_go_lit_A_const_44 *lang.Var

var A_arbace_repr_go_lit_A_const_45 *lang.Var

var A_arbace_repr_go_lit_A_const_46 *lang.Var

var A_arbace_repr_go_lit_A_const_47 *lang.Var

var A_arbace_repr_go_lit_A_const_48 *lang.Var

var A_arbace_repr_go_lit_A_const_49 *lang.Var

var A_arbace_repr_go_lit_A_const_50 *lang.Var

var A_arbace_repr_go_lit_A_const_51 *lang.Keyword

var A_arbace_repr_go_lit_A_const_52 *lang.Var

var A_arbace_repr_go_lit_A_const_53 *lang.Var

var A_arbace_repr_go_lit_A_const_54 *lang.Var

var A_arbace_repr_go_lit_A_const_55 *lang.Var

var A_arbace_repr_go_lit_A_const_56 *lang.Var

var A_arbace_repr_go_lit_A_const_57 *jrt.Class

var A_arbace_repr_go_lit_A_const_58 *lang.Var

var A_arbace_repr_go_lit_A_const_59 *lang.Var

var A_arbace_repr_go_lit_A_const_60 *lang.Var

var A_arbace_repr_go_lit_A_const_61 *lang.Var

var A_arbace_repr_go_lit_A_const_62 any

var A_arbace_repr_go_lit_A_const_63 *lang.Var

var A_arbace_repr_go_lit_A_const_64 *lang.Var

var A_arbace_repr_go_lit_A_const_65 *lang.Var

var A_arbace_repr_go_lit_A_const_66 *lang.Var

var A_arbace_repr_go_lit_A_const_67 *lang.Var

var A_arbace_repr_go_lit_A_const_68 *lang.Var

var A_arbace_repr_go_lit_A_const_69 any

var A_arbace_repr_go_lit_A_const_70 any

var A_arbace_repr_go_lit_A_const_71 *lang.Var

var A_arbace_repr_go_lit_A_const_72 any

var A_arbace_repr_go_lit_A_const_73 any

var A_arbace_repr_go_lit_A_const_74 any

var A_arbace_repr_go_lit_A_const_75 any

var A_arbace_repr_go_lit_A_const_76 *lang.Var

var A_arbace_repr_go_lit_A_const_77 any

var A_arbace_repr_go_lit_A_const_78 any

var A_arbace_repr_go_lit_A_const_79 any

var A_arbace_repr_go_lit_A_const_80 any

var A_arbace_repr_go_lit_A_const_81 any

var A_arbace_repr_go_lit_A_const_82 any

var A_arbace_repr_go_lit_A_const_83 any

var A_arbace_repr_go_lit_A_const_84 any

var A_arbace_repr_go_lit_A_const_85 any

var A_arbace_repr_go_lit_A_const_86 *lang.Var

var A_arbace_repr_go_lit_A_const_87 any

var A_arbace_repr_go_lit_A_const_88 any

var A_arbace_repr_go_lit_A_const_89 any

var A_arbace_repr_go_lit_A_const_90 any

var A_arbace_repr_go_lit_A_const_91 any

var A_arbace_repr_go_lit_A_const_92 any

var A_arbace_repr_go_lit_A_const_93 any

var A_arbace_repr_go_lit_A_const_94 any

var A_arbace_repr_go_lit_A_const_95 any

var A_arbace_repr_go_lit_A_const_96 any

var A_arbace_repr_go_lit_A_const_97 any

var A_arbace_repr_go_lit_A_const_98 any

var A_arbace_repr_go_lit_A_const_99 any

var A_arbace_repr_go_lit_A_const_100 any

var A_arbace_repr_go_lit_A_const_101 any

var A_arbace_repr_go_lit_A_const_102 *lang.Var

var A_arbace_repr_go_lit_A_const_103 *lang.Var

var A_arbace_repr_go_lit_A_const_104 any

var A_arbace_repr_go_lit_A_const_105 any

var A_arbace_repr_go_lit_A_const_106 any

var A_arbace_repr_go_lit_A_const_107 *lang.Var

var A_arbace_repr_go_lit_A_const_108 any

var A_arbace_repr_go_lit_A_const_109 *lang.Var

var A_arbace_repr_go_lit_A_const_110 *lang.Var

var A_arbace_repr_go_lit_A_const_111 *lang.Var

var A_arbace_repr_go_lit_A_const_112 *lang.Var

var A_arbace_repr_go_lit_A_const_113 *lang.Var

var A_arbace_repr_go_lit_A_const_114 any

var A_arbace_repr_go_lit_A_const_115 *lang.Var

var A_arbace_repr_go_lit_A_const_116 *lang.Var

var A_arbace_repr_go_lit_A_const_117 *lang.Var

var A_arbace_repr_go_lit_A_const_118 *lang.Var

var A_arbace_repr_go_lit_A_const_119 *lang.Var

var A_arbace_repr_go_lit_A_const_120 *lang.Var

var A_arbace_repr_go_lit_A_const_121 *lang.Var

var A_arbace_repr_go_lit_A_const_122 *lang.Var

var A_arbace_repr_go_lit_A_const_123 *lang.Keyword

var A_arbace_repr_go_lit_A_const_124 *lang.Var

var A_arbace_repr_go_lit_A_const_125 *lang.Var

var A_arbace_repr_go_lit_A_const_126 *lang.Var

var A_arbace_repr_go_lit_A_const_127 *lang.Keyword

var A_arbace_repr_go_lit_A_const_128 any

var A_arbace_repr_go_lit_A_const_129 *lang.Var

var A_arbace_repr_go_lit_A_const_130 *lang.Var

var A_arbace_repr_go_lit_A_const_131 *lang.Var

var A_arbace_repr_go_lit_A_const_132 *lang.Keyword

var A_arbace_repr_go_lit_A_const_133 *lang.Keyword

var A_arbace_repr_go_lit_A_const_134 *lang.Keyword

var A_arbace_repr_go_lit_A_const_135 *lang.Keyword

var A_arbace_repr_go_lit_A_const_136 *lang.Keyword

var A_arbace_repr_go_lit_A_const_137 *lang.Keyword

var A_arbace_repr_go_lit_A_const_138 *lang.Var

var A_arbace_repr_go_lit_A_const_139 *lang.Keyword

var A_arbace_repr_go_lit_A_const_140 *lang.Var

var A_arbace_repr_go_lit_A_const_141 *lang.Keyword

var A_arbace_repr_go_lit_A_const_142 *lang.Var

var A_arbace_repr_go_lit_A_const_143 any

var A_arbace_repr_go_lit_A_const_144 *lang.Var

var A_arbace_repr_go_lit_A_const_145 *lang.Var

var A_arbace_repr_go_lit_A_const_146 *lang.Var

var A_arbace_repr_go_lit_A_init jrt.ClassInit

func A_arbace_repr_go_lit_A_Init() { if !A_arbace_repr_go_lit_A_init.Done() { A_arbace_repr_go_lit_A_init.Run(A_arbace_repr_go_lit_A_clinit) } }

func A_arbace_repr_go_lit_A_clinit() { A_arbace_repr_go_lit_A_clinit_p0(); A_arbace_repr_go_lit_A_clinit_p1(); A_arbace_repr_go_lit_A_clinit_p2(); A_arbace_repr_go_lit_A_clinit_p3(); A_arbace_repr_go_lit_A_clinit_p4(); A_arbace_repr_go_lit_A_clinit_p5(); A_arbace_repr_go_lit_A_clinit_p6(); A_arbace_repr_go_lit_A_clinit_p7(); A_arbace_repr_go_lit_A_clinit_p8(); A_arbace_repr_go_lit_A_clinit_p9(); A_arbace_repr_go_lit_A_clinit_p10(); A_arbace_repr_go_lit_A_clinit_p11() }

func A_arbace_repr_go_lit_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_lit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 168); A_arbace_repr_go_lit_A_const_0 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[21]); A_arbace_repr_go_lit_A_const_1 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[22]); A_arbace_repr_go_lit_A_const_2 = A_arbace_repr_go_lit_A_const_pool.A[23]; A_arbace_repr_go_lit_A_const_3 = A_arbace_repr_go_lit_A_const_pool.A[24]; A_arbace_repr_go_lit_A_const_4 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[25]); A_arbace_repr_go_lit_A_const_5 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[26]); A_arbace_repr_go_lit_A_const_6 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[27]); A_arbace_repr_go_lit_A_const_7 = A_arbace_repr_go_lit_A_const_pool.A[28]; A_arbace_repr_go_lit_A_const_8 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[29]); A_arbace_repr_go_lit_A_const_9 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[30]); A_arbace_repr_go_lit_A_const_10 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[31]); A_arbace_repr_go_lit_A_const_11 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[32]) }

func A_arbace_repr_go_lit_A_clinit_p1() { A_arbace_repr_go_lit_A_const_12 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[33]); A_arbace_repr_go_lit_A_const_13 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[34]); A_arbace_repr_go_lit_A_const_14 = A_arbace_repr_go_lit_A_const_pool.A[35]; A_arbace_repr_go_lit_A_const_15 = A_arbace_repr_go_lit_A_const_pool.A[36]; A_arbace_repr_go_lit_A_const_16 = A_arbace_repr_go_lit_A_const_pool.A[37]; A_arbace_repr_go_lit_A_const_17 = A_arbace_repr_go_lit_A_const_pool.A[38]; A_arbace_repr_go_lit_A_const_18 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[39]); A_arbace_repr_go_lit_A_const_19 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[40]); A_arbace_repr_go_lit_A_const_20 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[41]); A_arbace_repr_go_lit_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[42]); A_arbace_repr_go_lit_A_const_22 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[43]); A_arbace_repr_go_lit_A_const_23 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[44]); A_arbace_repr_go_lit_A_const_24 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[45]) }

func A_arbace_repr_go_lit_A_clinit_p2() { A_arbace_repr_go_lit_A_const_25 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[46]); A_arbace_repr_go_lit_A_const_26 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[47]); A_arbace_repr_go_lit_A_const_27 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[48]); A_arbace_repr_go_lit_A_const_28 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[49]); A_arbace_repr_go_lit_A_const_29 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[50]); A_arbace_repr_go_lit_A_const_30 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[51]); A_arbace_repr_go_lit_A_const_31 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[52]); A_arbace_repr_go_lit_A_const_32 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[53]); A_arbace_repr_go_lit_A_const_33 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[54]); A_arbace_repr_go_lit_A_const_34 = A_arbace_repr_go_lit_A_const_pool.A[55]; A_arbace_repr_go_lit_A_const_35 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[56]); A_arbace_repr_go_lit_A_const_36 = A_arbace_repr_go_lit_A_const_pool.A[57] }

func A_arbace_repr_go_lit_A_clinit_p3() { A_arbace_repr_go_lit_A_const_37 = A_arbace_repr_go_lit_A_const_pool.A[58]; A_arbace_repr_go_lit_A_const_38 = A_arbace_repr_go_lit_A_const_pool.A[59]; A_arbace_repr_go_lit_A_const_39 = A_arbace_repr_go_lit_A_const_pool.A[60]; A_arbace_repr_go_lit_A_const_40 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[61]); A_arbace_repr_go_lit_A_const_41 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[62]); A_arbace_repr_go_lit_A_const_42 = A_arbace_repr_go_lit_A_const_pool.A[63]; A_arbace_repr_go_lit_A_const_43 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[64]); A_arbace_repr_go_lit_A_const_44 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[65]); A_arbace_repr_go_lit_A_const_45 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[66]); A_arbace_repr_go_lit_A_const_46 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[67]); A_arbace_repr_go_lit_A_const_47 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[68]); A_arbace_repr_go_lit_A_const_48 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[69]); A_arbace_repr_go_lit_A_const_49 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[70]) }

func A_arbace_repr_go_lit_A_clinit_p4() { A_arbace_repr_go_lit_A_const_50 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[71]); A_arbace_repr_go_lit_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[72]); A_arbace_repr_go_lit_A_const_52 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[73]); A_arbace_repr_go_lit_A_const_53 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[74]); A_arbace_repr_go_lit_A_const_54 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[75]); A_arbace_repr_go_lit_A_const_55 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[76]); A_arbace_repr_go_lit_A_const_56 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[77]); A_arbace_repr_go_lit_A_const_57 = jrt.Class_Cast(A_arbace_repr_go_lit_A_const_pool.A[78]); A_arbace_repr_go_lit_A_const_58 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[79]); A_arbace_repr_go_lit_A_const_59 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[80]); A_arbace_repr_go_lit_A_const_60 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[81]); A_arbace_repr_go_lit_A_const_61 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[82]) }

func A_arbace_repr_go_lit_A_clinit_p5() { A_arbace_repr_go_lit_A_const_62 = A_arbace_repr_go_lit_A_const_pool.A[83]; A_arbace_repr_go_lit_A_const_63 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[84]); A_arbace_repr_go_lit_A_const_64 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[85]); A_arbace_repr_go_lit_A_const_65 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[86]); A_arbace_repr_go_lit_A_const_66 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[87]); A_arbace_repr_go_lit_A_const_67 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[88]); A_arbace_repr_go_lit_A_const_68 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[89]); A_arbace_repr_go_lit_A_const_69 = A_arbace_repr_go_lit_A_const_pool.A[90]; A_arbace_repr_go_lit_A_const_70 = A_arbace_repr_go_lit_A_const_pool.A[91]; A_arbace_repr_go_lit_A_const_71 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[92]); A_arbace_repr_go_lit_A_const_72 = A_arbace_repr_go_lit_A_const_pool.A[93]; A_arbace_repr_go_lit_A_const_73 = A_arbace_repr_go_lit_A_const_pool.A[94]; A_arbace_repr_go_lit_A_const_74 = A_arbace_repr_go_lit_A_const_pool.A[95] }

func A_arbace_repr_go_lit_A_clinit_p6() { A_arbace_repr_go_lit_A_const_75 = A_arbace_repr_go_lit_A_const_pool.A[96]; A_arbace_repr_go_lit_A_const_76 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[97]); A_arbace_repr_go_lit_A_const_77 = A_arbace_repr_go_lit_A_const_pool.A[98]; A_arbace_repr_go_lit_A_const_78 = A_arbace_repr_go_lit_A_const_pool.A[99]; A_arbace_repr_go_lit_A_const_79 = A_arbace_repr_go_lit_A_const_pool.A[100]; A_arbace_repr_go_lit_A_const_80 = A_arbace_repr_go_lit_A_const_pool.A[101]; A_arbace_repr_go_lit_A_const_81 = A_arbace_repr_go_lit_A_const_pool.A[102]; A_arbace_repr_go_lit_A_const_82 = A_arbace_repr_go_lit_A_const_pool.A[103]; A_arbace_repr_go_lit_A_const_83 = A_arbace_repr_go_lit_A_const_pool.A[104]; A_arbace_repr_go_lit_A_const_84 = A_arbace_repr_go_lit_A_const_pool.A[105]; A_arbace_repr_go_lit_A_const_85 = A_arbace_repr_go_lit_A_const_pool.A[106]; A_arbace_repr_go_lit_A_const_86 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[107]); A_arbace_repr_go_lit_A_const_87 = A_arbace_repr_go_lit_A_const_pool.A[108]; A_arbace_repr_go_lit_A_const_88 = A_arbace_repr_go_lit_A_const_pool.A[109]; A_arbace_repr_go_lit_A_const_89 = A_arbace_repr_go_lit_A_const_pool.A[110] }

func A_arbace_repr_go_lit_A_clinit_p7() { A_arbace_repr_go_lit_A_const_90 = A_arbace_repr_go_lit_A_const_pool.A[111]; A_arbace_repr_go_lit_A_const_91 = A_arbace_repr_go_lit_A_const_pool.A[112]; A_arbace_repr_go_lit_A_const_92 = A_arbace_repr_go_lit_A_const_pool.A[113]; A_arbace_repr_go_lit_A_const_93 = A_arbace_repr_go_lit_A_const_pool.A[114]; A_arbace_repr_go_lit_A_const_94 = A_arbace_repr_go_lit_A_const_pool.A[115]; A_arbace_repr_go_lit_A_const_95 = A_arbace_repr_go_lit_A_const_pool.A[116]; A_arbace_repr_go_lit_A_const_96 = A_arbace_repr_go_lit_A_const_pool.A[117]; A_arbace_repr_go_lit_A_const_97 = A_arbace_repr_go_lit_A_const_pool.A[118]; A_arbace_repr_go_lit_A_const_98 = A_arbace_repr_go_lit_A_const_pool.A[119]; A_arbace_repr_go_lit_A_const_99 = A_arbace_repr_go_lit_A_const_pool.A[120]; A_arbace_repr_go_lit_A_const_100 = A_arbace_repr_go_lit_A_const_pool.A[121]; A_arbace_repr_go_lit_A_const_101 = A_arbace_repr_go_lit_A_const_pool.A[122]; A_arbace_repr_go_lit_A_const_102 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[123]); A_arbace_repr_go_lit_A_const_103 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[124]); A_arbace_repr_go_lit_A_const_104 = A_arbace_repr_go_lit_A_const_pool.A[125] }

func A_arbace_repr_go_lit_A_clinit_p8() { A_arbace_repr_go_lit_A_const_105 = A_arbace_repr_go_lit_A_const_pool.A[126]; A_arbace_repr_go_lit_A_const_106 = A_arbace_repr_go_lit_A_const_pool.A[127]; A_arbace_repr_go_lit_A_const_107 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[128]); A_arbace_repr_go_lit_A_const_108 = A_arbace_repr_go_lit_A_const_pool.A[129]; A_arbace_repr_go_lit_A_const_109 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[130]); A_arbace_repr_go_lit_A_const_110 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[131]); A_arbace_repr_go_lit_A_const_111 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[132]); A_arbace_repr_go_lit_A_const_112 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[133]); A_arbace_repr_go_lit_A_const_113 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[134]); A_arbace_repr_go_lit_A_const_114 = A_arbace_repr_go_lit_A_const_pool.A[135]; A_arbace_repr_go_lit_A_const_115 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[136]); A_arbace_repr_go_lit_A_const_116 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[137]); A_arbace_repr_go_lit_A_const_117 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[138]) }

func A_arbace_repr_go_lit_A_clinit_p9() { A_arbace_repr_go_lit_A_const_118 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[139]); A_arbace_repr_go_lit_A_const_119 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[140]); A_arbace_repr_go_lit_A_const_120 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[141]); A_arbace_repr_go_lit_A_const_121 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[142]); A_arbace_repr_go_lit_A_const_122 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[143]); A_arbace_repr_go_lit_A_const_123 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[144]); A_arbace_repr_go_lit_A_const_124 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[145]); A_arbace_repr_go_lit_A_const_125 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[146]); A_arbace_repr_go_lit_A_const_126 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[147]); A_arbace_repr_go_lit_A_const_127 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[148]); A_arbace_repr_go_lit_A_const_128 = A_arbace_repr_go_lit_A_const_pool.A[149]; A_arbace_repr_go_lit_A_const_129 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[150]) }

func A_arbace_repr_go_lit_A_clinit_p10() { A_arbace_repr_go_lit_A_const_130 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[151]); A_arbace_repr_go_lit_A_const_131 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[152]); A_arbace_repr_go_lit_A_const_132 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[153]); A_arbace_repr_go_lit_A_const_133 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[154]); A_arbace_repr_go_lit_A_const_134 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[155]); A_arbace_repr_go_lit_A_const_135 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[156]); A_arbace_repr_go_lit_A_const_136 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[157]); A_arbace_repr_go_lit_A_const_137 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[158]); A_arbace_repr_go_lit_A_const_138 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[159]); A_arbace_repr_go_lit_A_const_139 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[160]); A_arbace_repr_go_lit_A_const_140 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[161]); A_arbace_repr_go_lit_A_const_141 = lang.Keyword_Cast(A_arbace_repr_go_lit_A_const_pool.A[162]) }

func A_arbace_repr_go_lit_A_clinit_p11() { A_arbace_repr_go_lit_A_const_142 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[163]); A_arbace_repr_go_lit_A_const_143 = A_arbace_repr_go_lit_A_const_pool.A[164]; A_arbace_repr_go_lit_A_const_144 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[165]); A_arbace_repr_go_lit_A_const_145 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[166]); A_arbace_repr_go_lit_A_const_146 = lang.Var_Cast(A_arbace_repr_go_lit_A_const_pool.A[167]) }

func A_arbace_repr_go_lit_A_New() *A_arbace_repr_go_lit_A { A_arbace_repr_go_lit_A_Init(); t := &A_arbace_repr_go_lit_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_A) Ctor() {}

func (t *A_arbace_repr_go_lit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_A_class }

func (t *A_arbace_repr_go_lit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_A); return ok }

func A_arbace_repr_go_lit_A_Cast(x any) *A_arbace_repr_go_lit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_A_class)) }; return v }



type A_arbace_repr_go_lit_bytes_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A struct{ j2g_header uint64; F_iter__790000088, F_s__790000089 any }

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__790000091, F_c__1927001037__auto__ any }

var A_arbace_repr_go_lit_bytes_form_iter__790000088__790000092_fn__790000093_fn__790000094_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_char_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_char_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_const_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_const_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decimal_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decimal_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_decode_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_b__790000073_A struct{ j2g_header uint64; F_bs any }

var A_arbace_repr_go_lit_decode_rune_b__790000073_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A struct{ j2g_header uint64; F_n, F_b any }

var A_arbace_repr_go_lit_decode_rune_cont_QMARK___790000075_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_exact_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_exact_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_double_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_double_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000004_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000004_A_New() *A_arbace_repr_go_lit_eval790000004_A { t := &A_arbace_repr_go_lit_eval790000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000004_A_class }

func (t *A_arbace_repr_go_lit_eval790000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); return ok }

func A_arbace_repr_go_lit_eval790000004_A_Cast(x any) *A_arbace_repr_go_lit_eval790000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000004_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000004_loading__1927001464__auto____790000005_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000008_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000008_A_New() *A_arbace_repr_go_lit_eval790000008_A { t := &A_arbace_repr_go_lit_eval790000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000008_A_class }

func (t *A_arbace_repr_go_lit_eval790000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); return ok }

func A_arbace_repr_go_lit_eval790000008_A_Cast(x any) *A_arbace_repr_go_lit_eval790000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000008_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000008_fn__790000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000008_fn__790000009_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_A struct{ jrt.Object }

func A_arbace_repr_go_lit_eval790000013_A_New() *A_arbace_repr_go_lit_eval790000013_A { t := &A_arbace_repr_go_lit_eval790000013_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) Ctor() {}

func (t *A_arbace_repr_go_lit_eval790000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_lit_eval790000013_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_lit_eval790000013_A_class }

func (t *A_arbace_repr_go_lit_eval790000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_lit_eval790000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_lit_eval790000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); return ok }

func A_arbace_repr_go_lit_eval790000013_A_Cast(x any) *A_arbace_repr_go_lit_eval790000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_lit_eval790000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_lit_eval790000013_A_class)) }; return v }



type A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013___GT_Lit__790000023_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_eval790000013_map__GT_Lit__790000025_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_text_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_text_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hex_float_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hex_float_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_hexv_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_hexv_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_imag_inner_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_imag_inner_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_int_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_int_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_integer_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_integer_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_lit_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_lit_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_num_den_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_num_den_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow2_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow2_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_pow5_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A struct{ j2g_header uint64; F_d, F_five any }

var A_arbace_repr_go_lit_pow5_exponent_fn__790000046_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rational_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_rune_value_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_rune_value_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_bytes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_bytes_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_string_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_string_text_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_terminating_decimal_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_terminating_decimal_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_unescape_put_cp__790000066_A struct{ j2g_header uint64; F_out any }

var A_arbace_repr_go_lit_unescape_put_cp__790000066_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_untyped_float_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_untyped_float_form_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_utf8_parts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_utf8_parts_A_fn_class *jrt.Class



type A_arbace_repr_go_lit_val_rational_A struct{ j2g_header uint64 }

var A_arbace_repr_go_lit_val_rational_A_fn_class *jrt.Class
