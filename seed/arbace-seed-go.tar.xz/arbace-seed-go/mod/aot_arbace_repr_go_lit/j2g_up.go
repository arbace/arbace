//line j2g_up.ae:1
package aot_arbace_repr_go_lit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_MapEntry_IMapEntry(p *lang.MapEntry) lang.IMapEntry { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_A_arbace_repr_go_lit_Lit_A_IPersistentMap(p *A_arbace_repr_go_lit_Lit_A) lang.IPersistentMap { if p == nil { return nil }; return p }

func Up_Double_Number(p *jrt.Double) jrt.Number_I { if p == nil { return nil }; return p }

func Up_Long_Number(p *jrt.Long) jrt.Number_I { if p == nil { return nil }; return p }
