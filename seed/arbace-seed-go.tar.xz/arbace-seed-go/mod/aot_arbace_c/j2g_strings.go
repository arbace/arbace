//line j2g_strings.ae:1
package aot_arbace_c

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.c.replkn2,asyn4,replyn11,arbace.corekn7,excludeyn4,defnyn3,varyn7,declareyn6,structyn4,enumkn3,docys13,arbace.c.repl5,file!yn5,quotekn4,unitys13,arbace.c.repl8,declare!ys13,arbace.c.repl8,include!v11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,R4,V5,R5,R6,R7,R8,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn8,arbace.cm2,R10,s825,C forms at the REPL (doc/C23-SURVEY.md §6.1, §6.6, CS17 (a), CS20 (a); doc/c/SPEC.md): the macros of C\n  forms, as arbace.go's are Go forms' (doc/go/GOI-SPEC.md §2.2). A translation unit is a namespace; its\n  declaration forms are data entered into the unit by arbace.c.repl (nothing in them is evaluated as\n  Arbace, SPEC principle 1), checked by arbace.c.check and built by arbace.c.build when the program\n  runs. With the alias c:\n\n    (ns c.letters (:require [arbace.c :as c]))\n    (c/file \"letters.c\" :std :c23)\n    (c/include \"<stdio.h>\")\n    (c/defn main ^int [void] (printf \"%d\\n\" 42) (return 0))\n    (c/run-main 'c.letters)                      ; prints 42, => 0\n\n  A unit read by repr/c (bin/repr-c read) loads the same way: its c/include forms name their header units\n  (:unit), which the REPL takes from the read.v11,arbace.core7,ns-namev11,arbace.core4,*ns*v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR11,R12,v8,arbace.c7,repl-nsv11,arbace.core4,someS1,R13,R14,R15,R14,R14,R14,R14,R14,R14,R14,R14,R14,R14,v11,arbace.core5,applyv13,arbace.c.repl8,run-main")

var Lit_1 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,fileyn1,&yn1,_yn4,specyn4,optsyn2,nsyn4,argsv11,arbace.core5,in-nsMyn8,arbace.cm2,R0,s825,C forms at the REPL (doc/C23-SURVEY.md §6.1, §6.6, CS17 (a), CS20 (a); doc/c/SPEC.md): the macros of C\n  forms, as arbace.go's are Go forms' (doc/go/GOI-SPEC.md §2.2). A translation unit is a namespace; its\n  declaration forms are data entered into the unit by arbace.c.repl (nothing in them is evaluated as\n  Arbace, SPEC principle 1), checked by arbace.c.check and built by arbace.c.build when the program\n  runs. With the alias c:\n\n    (ns c.letters (:require [arbace.c :as c]))\n    (c/file \"letters.c\" :std :c23)\n    (c/include \"<stdio.h>\")\n    (c/defn main ^int [void] (printf \"%d\\n\" 42) (return 0))\n    (c/run-main 'c.letters)                      ; prints 42, => 0\n\n  A unit read by repr/c (bin/repr-c read) loads the same way: its c/include forms name their header units\n  (:unit), which the REPL takes from the read.m2,R0,s825,C forms at the REPL (doc/C23-SURVEY.md §6.1, §6.6, CS17 (a), CS20 (a); doc/c/SPEC.md): the macros of C\n  forms, as arbace.go's are Go forms' (doc/go/GOI-SPEC.md §2.2). A translation unit is a namespace; its\n  declaration forms are data entered into the unit by arbace.c.repl (nothing in them is evaluated as\n  Arbace, SPEC principle 1), checked by arbace.c.check and built by arbace.c.build when the program\n  runs. With the alias c:\n\n    (ns c.letters (:require [arbace.c :as c]))\n    (c/file \"letters.c\" :std :c23)\n    (c/include \"<stdio.h>\")\n    (c/defn main ^int [void] (printf \"%d\\n\" 42) (return 0))\n    (c/run-main 'c.letters)                      ; prints 42, => 0\n\n  A unit read by repr/c (bin/repr-c read) loads the same way: its c/include forms name their header units\n  (:unit), which the REPL takes from the read.R1,v8,arbace.c7,repl-nsm10,R2,TR3,L1,V0,R4,i19,R5,i1,R6,s11,arbace/c.aev8,arbace.c4,filem10,R3,L1,V2,R7,R8,R0,s44,c/file: the unit's file and standard (§4.2).R4,i21,R5,i1,R6,s11,arbace/c.aev8,arbace.c7,includem10,R3,L1,V3,R9,R7,R10,R0,s189,c/include: at the REPL, (c/include \"<stdio.h>\") reads the header in the unit's context; in a read\n  unit's forms, (c/include \"<stdio.h>\" :unit U) names its header unit, taken from the read.R4,i24,R5,i1,R6,s11,arbace/c.aev8,arbace.c4,defnm10,R3,L1,V2,R7,R8,R0,s37,c/defn: a function definition (§6.4).R4,i32,R5,i1,R6,s11,arbace/c.aev8,arbace.c3,varm10,R3,L1,V2,R7,R8,R0,s24,c/var: an object (§6.2).R4,i33,R5,i1,R6,s11,arbace/c.aev8,arbace.c7,declarem10,R3,L1,V2,R7,R8,R0,s43,c/declare: a function's declaration (§6.3).R4,i34,R5,i1,R6,s11,arbace/c.aev8,arbace.c7,typedefm10,R3,L1,V2,R7,R8,R0,s17,c/typedef (§6.5).R4,i35,R5,i1,R6,s11,arbace/c.aev8,arbace.c6,structm10,R3,L1,V2,R7,R8,R0,s35,c/struct: a tag declaration (§6.6).R4,i36,R5,i1,R6,s11,arbace/c.aev8,arbace.c5,unionm10,R3,L1,V2,R7,R8,R0,s34,c/union: a tag declaration (§6.6).R4,i37,R5,i1,R6,s11,arbace/c.aev8,arbace.c4,enumm10,R3,L1,V2,R7,R8,R0,s33,c/enum: a tag declaration (§6.6).R4,i38,R5,i1,R6,s11,arbace/c.aev8,arbace.c5,groupm10,R3,L1,V2,R7,R8,R0,s51,c/group: declarators sharing a defined type (§6.7).R4,i39,R5,i1,R6,s11,arbace/c.aev8,arbace.c13,static-assertm10,R3,L1,V2,R7,R8,R0,s23,c/static-assert (§6.8).R4,i40,R5,i1,R6,s11,arbace/c.aev8,arbace.c9,attr-declm10,R3,L1,V2,R7,R8,R0,s19,c/attr-decl (§6.8).R4,i41,R5,i1,R6,s11,arbace/c.aev8,arbace.c6,definem10,R3,L1,V2,R7,R8,R0,s46,c/define: the layer's, ignored by eval (§9.2).R4,i42,R5,i1,R6,s11,arbace/c.aev8,arbace.c5,undefm10,R3,L1,V2,R7,R8,R0,s45,c/undef: the layer's, ignored by eval (§9.2).R4,i43,R5,i1,R6,s11,arbace/c.aev8,arbace.c9,directivem10,R3,L1,V2,R7,R8,R0,s49,c/directive: the layer's, ignored by eval (§9.2).R4,i44,R5,i1,R6,s11,arbace/c.aev8,arbace.c6,pragmam10,R3,L1,V2,R7,R8,R0,s55,c/pragma: entered for the checker (#pragma pack, §9.2).R4,i45,R5,i1,R6,s11,arbace/c.aev8,arbace.c6,headerm10,R3,L1,V2,R7,R8,R0,s44,c/header: a header unit's first form (§4.3).R4,i46,R5,i1,R6,s11,arbace/c.aev8,arbace.c8,run-mainm10,R3,L1,V3,R11,R7,R12,R0,s95,(c/run-main 'c.letters & args): main of the REPL's program run in the program mode: its status.R4,i48,R5,i1,R6,s11,arbace/c.ae")

var Lit_2 *jrt.String = jrt.Intern("arbace.c$eval1501000004$loading__1927001464__auto____1501000005")

var Lit_3 *jrt.String = jrt.Intern("arbace.c$eval1501000008$fn__1501000009")

var Lit_4 *jrt.String = jrt.Intern("arbace.c$repl_ns")

var Lit_5 *jrt.String = jrt.Intern("arbace.c$file")

var Lit_6 *jrt.String = jrt.Intern("arbace.c$include")

var Lit_7 *jrt.String = jrt.Intern("arbace.c$defn")

var Lit_8 *jrt.String = jrt.Intern("arbace.c$var")

var Lit_9 *jrt.String = jrt.Intern("arbace.c$declare")

var Lit_10 *jrt.String = jrt.Intern("arbace.c$typedef")

var Lit_11 *jrt.String = jrt.Intern("arbace.c$struct")

var Lit_12 *jrt.String = jrt.Intern("arbace.c$union")

var Lit_13 *jrt.String = jrt.Intern("arbace.c$enum")

var Lit_14 *jrt.String = jrt.Intern("arbace.c$group")

var Lit_15 *jrt.String = jrt.Intern("arbace.c$static_assert")

var Lit_16 *jrt.String = jrt.Intern("arbace.c$attr_decl")

var Lit_17 *jrt.String = jrt.Intern("arbace.c$define")

var Lit_18 *jrt.String = jrt.Intern("arbace.c$undef")

var Lit_19 *jrt.String = jrt.Intern("arbace.c$directive")

var Lit_20 *jrt.String = jrt.Intern("arbace.c$pragma")

var Lit_21 *jrt.String = jrt.Intern("arbace.c$header")

var Lit_22 *jrt.String = jrt.Intern("arbace.c$run_main")
