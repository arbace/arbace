//line aot_arbace_c.ae:1
package aot_arbace_c

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_New() *A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A { A_arbace_c_A_Init(); t := &A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c_A_const_3, A_arbace_c_A_const_4, A_arbace_c_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_c_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_eval1501000008_fn__1501000009_A_New() *A_arbace_c_eval1501000008_fn__1501000009_A { A_arbace_c_A_Init(); t := &A_arbace_c_eval1501000008_fn__1501000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_eval1501000008_fn__1501000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_eval1501000008_fn__1501000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_c_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_c_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_A_const_9.GetRawRoot__O(), A_arbace_c_A_const_10) }

















func A_arbace_c_repl_ns_A_New() *A_arbace_c_repl_ns_A { A_arbace_c_A_Init(); t := &A_arbace_c_repl_ns_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_c_repl_ns_A) Ctor() {}
//line :19:1
func (t *A_arbace_c_repl_ns_A) Invoke_O__O(self any) any { var root_21 any = A_arbace_c_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_c_A_const_12.Get__O(); if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_21, arg_24) } }

func A_arbace_c_file_A_New() *A_arbace_c_file_A { A_arbace_c_A_Init(); t := &A_arbace_c_file_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_c_file_A) Ctor() {}
//line :21:1
func (t *A_arbace_c_file_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_25 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_16); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_35 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_43 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_40 == nil { arg_38 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_36 == nil { tmp4 = ifn_37.Invoke_O__O(arg_38) } else { tmp4 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_44 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any; var root_48 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_52 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_53 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_c_repl_ns_A_fn_class); var ifn_55 lang.IFn; if
														linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; if linked_54 == nil { tmp9 = ifn_55.Invoke__O() } else { tmp9 = linked_54.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_53) }; arg_52 = /*line :21:1*/tmp8.Invoke_O__O(tmp9); if linked_49 == nil { arg_47 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { arg_47 = linked_49.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }; if linked_45 == nil { tmp7 = ifn_46.Invoke_O__O(arg_47) } else { tmp7 = linked_45.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_44, arg_47) }; arg_28 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_26 == nil { return ifn_27.Invoke_O__O(arg_28) } else { return linked_26.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_25, arg_28) } }


func A_arbace_c_include_A_New() *A_arbace_c_include_A { A_arbace_c_A_Init(); t := &A_arbace_c_include_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_c_include_A) Ctor() {}
//line :24:1
func (t *A_arbace_c_include_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, spec__2, opts__3 any) any {



	var tmp1 any; var root_56 any = A_arbace_c_A_const_19.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_c_A_const_20; var arg_60 any = opts__3; if linked_57 == nil { tmp1 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }; if jrt.J2g_Truth(tmp1) { var root_61 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_21); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp5 any; var root_71 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var root_75 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_79 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_76 == nil { arg_74 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { arg_74 = linked_76.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; if linked_72 == nil { tmp5 = ifn_73.Invoke_O__O(arg_74) } else { tmp5 = linked_72.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_71, arg_74) }; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp8 any; var root_80 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_84 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_88 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp10 any; var root_89 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_c_repl_ns_A_fn_class); var ifn_91 lang.IFn
		if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { tmp10 = ifn_91.Invoke__O() } else { tmp10 = linked_90.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_89) }
//line :28:1
		arg_88 = tmp9.Invoke_O__O(tmp10); if linked_85 == nil { arg_83 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { arg_83 = linked_85.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; if linked_81 == nil { tmp8 = ifn_82.Invoke_O__O(arg_83) } else { tmp8 = linked_81.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_80, arg_83) }; arg_64 = tmp2.Invoke_O_O_O__O(tmp3, tmp6, tmp7.Invoke_O__O(tmp8)); if linked_62 == nil { return ifn_63.Invoke_O__O(arg_64) } else { return linked_62.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_61, arg_64) } } else { var root_92 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp12 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_22); var tmp13 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(spec__2); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp15 any; var root_102 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_106 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_110 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp17 any; var root_111 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_c_repl_ns_A_fn_class); var ifn_113 lang.IFn

			if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; if linked_112 == nil { tmp17 = ifn_113.Invoke__O() } else { tmp17 = linked_112.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_111) }
//line :28:1
			arg_110 = tmp16.Invoke_O__O(tmp17); if linked_107 == nil { arg_105 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_105 = linked_107.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if linked_103 == nil { tmp15 = ifn_104.Invoke_O__O(arg_105) } else { tmp15 = linked_103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_102, arg_105) }; arg_95 = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O__O(tmp15)); if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_92, arg_95)
			}
		}
}
func A_arbace_c_defn_A_New() *A_arbace_c_defn_A { A_arbace_c_A_Init(); t := &A_arbace_c_defn_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_c_defn_A) Ctor() {}
//line :32:1
func (t *A_arbace_c_defn_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_114 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_23); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_124 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_128 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_132 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_129 == nil { arg_127 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { arg_127 = linked_129.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }; if linked_125 == nil { tmp4 = ifn_126.Invoke_O__O(arg_127) } else { tmp4 = linked_125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_124, arg_127) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_133 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var root_137 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_141 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_142 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_c_repl_ns_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; if linked_143 == nil { tmp9 = ifn_144.Invoke__O() } else { tmp9 = linked_143.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_142) }; arg_141 = tmp8.Invoke_O__O(tmp9); if linked_138 == nil { arg_136 = ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { arg_136 = linked_138.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_137, arg_140, arg_141) }; if linked_134 == nil { tmp7 = ifn_135.Invoke_O__O(arg_136) } else { tmp7 = linked_134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_133, arg_136) }; arg_117 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_115 == nil { return ifn_116.Invoke_O__O(arg_117) } else { return linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) } }
func A_arbace_c_var_A_New() *A_arbace_c_var_A { A_arbace_c_A_Init(); t := &A_arbace_c_var_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_c_var_A) Ctor() {}
//line :33:1
func (t *A_arbace_c_var_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_145 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_24); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_155 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_159 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_163 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_160 == nil { arg_158 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { arg_158 = linked_160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; if linked_156 == nil { tmp4 = ifn_157.Invoke_O__O(arg_158) } else { tmp4 = linked_156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_155, arg_158) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_164 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var root_168 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_172 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_173 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_c_repl_ns_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; if linked_174 == nil { tmp9 = ifn_175.Invoke__O() } else { tmp9 = linked_174.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_173) }; arg_172 = tmp8.Invoke_O__O(tmp9); if linked_169 == nil { arg_167 = ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { arg_167 = linked_169.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; if linked_165 == nil { tmp7 = ifn_166.Invoke_O__O(arg_167) } else { tmp7 = linked_165.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_164, arg_167) }; arg_148 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_146 == nil { return ifn_147.Invoke_O__O(arg_148) } else { return linked_146.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_145, arg_148) } }
func A_arbace_c_declare_A_New() *A_arbace_c_declare_A { A_arbace_c_A_Init(); t := &A_arbace_c_declare_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_c_declare_A) Ctor() {}
//line :34:1
func (t *A_arbace_c_declare_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_176 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_25); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_186 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var root_190 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_194 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_191 == nil { arg_189 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_189 = linked_191.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_187 == nil { tmp4 = ifn_188.Invoke_O__O(arg_189) } else { tmp4 = linked_187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_186, arg_189) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_195 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_203 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_204 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_c_repl_ns_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; if linked_205 == nil { tmp9 = ifn_206.Invoke__O() } else { tmp9 = linked_205.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_204) }; arg_203 = tmp8.Invoke_O__O(tmp9); if linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { tmp7 = ifn_197.Invoke_O__O(arg_198) } else { tmp7 = linked_196.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_195, arg_198) }; arg_179 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_177 == nil { return ifn_178.Invoke_O__O(arg_179) } else { return linked_177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_176, arg_179) } }
func A_arbace_c_typedef_A_New() *A_arbace_c_typedef_A { A_arbace_c_A_Init(); t := &A_arbace_c_typedef_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_c_typedef_A) Ctor() {}
//line :35:1
func (t *A_arbace_c_typedef_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_207 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_26); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_217 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_221 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_225 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_222 == nil { arg_220 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { arg_220 = linked_222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_226 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any; var root_230 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_234 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_235 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_c_repl_ns_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; if linked_236 == nil { tmp9 = ifn_237.Invoke__O() } else { tmp9 = linked_236.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_235) }; arg_234 = tmp8.Invoke_O__O(tmp9); if linked_231 == nil { arg_229 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { arg_229 = linked_231.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }; if linked_227 == nil { tmp7 = ifn_228.Invoke_O__O(arg_229) } else { tmp7 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; arg_210 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_208 == nil { return ifn_209.Invoke_O__O(arg_210) } else { return linked_208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_207, arg_210) } }
func A_arbace_c_struct_A_New() *A_arbace_c_struct_A { A_arbace_c_A_Init(); t := &A_arbace_c_struct_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_c_struct_A) Ctor() {}
//line :36:1
func (t *A_arbace_c_struct_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_238 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_27); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_248 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var root_252 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_256 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_253 == nil { arg_251 = ifn_254.Invoke_O_O__O(arg_255, arg_256) } else { arg_251 = linked_253.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_252, arg_255, arg_256) }; if linked_249 == nil { tmp4 = ifn_250.Invoke_O__O(arg_251) } else { tmp4 = linked_249.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_248, arg_251) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_257 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var root_261 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_265 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_266 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_c_repl_ns_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; if linked_267 == nil { tmp9 = ifn_268.Invoke__O() } else { tmp9 = linked_267.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_266) }; arg_265 = tmp8.Invoke_O__O(tmp9); if linked_262 == nil { arg_260 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { arg_260 = linked_262.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) }; if linked_258 == nil { tmp7 = ifn_259.Invoke_O__O(arg_260) } else { tmp7 = linked_258.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_257, arg_260) }; arg_241 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_239 == nil { return ifn_240.Invoke_O__O(arg_241) } else { return linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) } }
func A_arbace_c_union_A_New() *A_arbace_c_union_A { A_arbace_c_A_Init(); t := &A_arbace_c_union_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_c_union_A) Ctor() {}
//line :37:1
func (t *A_arbace_c_union_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_269 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_28); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_279 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any; var root_283 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_287 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_284 == nil { arg_282 = ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { arg_282 = linked_284.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) }; if linked_280 == nil { tmp4 = ifn_281.Invoke_O__O(arg_282) } else { tmp4 = linked_280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_279, arg_282) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_288 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any; var root_292 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_296 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_297 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, A_arbace_c_repl_ns_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; if linked_298 == nil { tmp9 = ifn_299.Invoke__O() } else { tmp9 = linked_298.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_297) }; arg_296 = tmp8.Invoke_O__O(tmp9); if linked_293 == nil { arg_291 = ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { arg_291 = linked_293.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) }; if linked_289 == nil { tmp7 = ifn_290.Invoke_O__O(arg_291) } else { tmp7 = linked_289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_288, arg_291) }; arg_272 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_270 == nil { return ifn_271.Invoke_O__O(arg_272) } else { return linked_270.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_269, arg_272) } }
func A_arbace_c_enum_A_New() *A_arbace_c_enum_A { A_arbace_c_A_Init(); t := &A_arbace_c_enum_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_c_enum_A) Ctor() {}
//line :38:1
func (t *A_arbace_c_enum_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_300 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_29); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_310 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any; var root_314 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_318 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_315 == nil { arg_313 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { arg_313 = linked_315.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if linked_311 == nil { tmp4 = ifn_312.Invoke_O__O(arg_313) } else { tmp4 = linked_311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_310, arg_313) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_319 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any; var root_323 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_327 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_328 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_c_repl_ns_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; if linked_329 == nil { tmp9 = ifn_330.Invoke__O() } else { tmp9 = linked_329.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_328) }; arg_327 = tmp8.Invoke_O__O(tmp9); if linked_324 == nil { arg_322 = ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { arg_322 = linked_324.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_323, arg_326, arg_327) }; if linked_320 == nil { tmp7 = ifn_321.Invoke_O__O(arg_322) } else { tmp7 = linked_320.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_319, arg_322) }; arg_303 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_301 == nil { return ifn_302.Invoke_O__O(arg_303) } else { return linked_301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_300, arg_303) } }
func A_arbace_c_group_A_New() *A_arbace_c_group_A { A_arbace_c_A_Init(); t := &A_arbace_c_group_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_c_group_A) Ctor() {}
//line :39:1
func (t *A_arbace_c_group_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_331 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_30); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_341 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var root_345 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_349 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_346 == nil { arg_344 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { arg_344 = linked_346.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) }; if linked_342 == nil { tmp4 = ifn_343.Invoke_O__O(arg_344) } else { tmp4 = linked_342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_341, arg_344) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_350 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_354 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_358 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_359 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_c_repl_ns_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; if linked_360 == nil { tmp9 = ifn_361.Invoke__O() } else { tmp9 = linked_360.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_359) }; arg_358 = tmp8.Invoke_O__O(tmp9); if linked_355 == nil { arg_353 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_353 = linked_355.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if linked_351 == nil { tmp7 = ifn_352.Invoke_O__O(arg_353) } else { tmp7 = linked_351.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_350, arg_353) }; arg_334 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_332 == nil { return ifn_333.Invoke_O__O(arg_334) } else { return linked_332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_331, arg_334) } }
func A_arbace_c_static_assert_A_New() *A_arbace_c_static_assert_A { A_arbace_c_A_Init(); t := &A_arbace_c_static_assert_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_c_static_assert_A) Ctor() {}
//line :40:1
func (t *A_arbace_c_static_assert_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_362 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_31); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_372 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any; var root_376 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_380 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_377 == nil { arg_375 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { arg_375 = linked_377.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }; if linked_373 == nil { tmp4 = ifn_374.Invoke_O__O(arg_375) } else { tmp4 = linked_373.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_372, arg_375) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_381 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any; var root_385 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_389 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_390 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_c_repl_ns_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; if linked_391 == nil { tmp9 = ifn_392.Invoke__O() } else { tmp9 = linked_391.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_390) }; arg_389 = tmp8.Invoke_O__O(tmp9); if linked_386 == nil { arg_384 = ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { arg_384 = linked_386.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_385, arg_388, arg_389) }; if linked_382 == nil { tmp7 = ifn_383.Invoke_O__O(arg_384) } else { tmp7 = linked_382.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_381, arg_384) }; arg_365 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_363 == nil { return ifn_364.Invoke_O__O(arg_365) } else { return linked_363.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_362, arg_365) } }
func A_arbace_c_attr_decl_A_New() *A_arbace_c_attr_decl_A { A_arbace_c_A_Init(); t := &A_arbace_c_attr_decl_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_c_attr_decl_A) Ctor() {}
//line :41:1
func (t *A_arbace_c_attr_decl_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }
func A_arbace_c_define_A_New() *A_arbace_c_define_A { A_arbace_c_A_Init(); t := &A_arbace_c_define_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_c_define_A) Ctor() {}
//line :42:1
func (t *A_arbace_c_define_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }
func A_arbace_c_undef_A_New() *A_arbace_c_undef_A { A_arbace_c_A_Init(); t := &A_arbace_c_undef_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_c_undef_A) Ctor() {}
//line :43:1
func (t *A_arbace_c_undef_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }
func A_arbace_c_directive_A_New() *A_arbace_c_directive_A { A_arbace_c_A_Init(); t := &A_arbace_c_directive_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_c_directive_A) Ctor() {}
//line :44:1
func (t *A_arbace_c_directive_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }
func A_arbace_c_pragma_A_New() *A_arbace_c_pragma_A { A_arbace_c_A_Init(); t := &A_arbace_c_pragma_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_c_pragma_A) Ctor() {}
//line :45:1
func (t *A_arbace_c_pragma_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { var root_393 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_14.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_32); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp4 any; var root_403 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var root_407 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_411 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(_AMPERSAND_form__0); if linked_408 == nil { arg_406 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { arg_406 = linked_408.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }; if linked_404 == nil { tmp4 = ifn_405.Invoke_O__O(arg_406) } else { tmp4 = linked_404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_403, arg_406) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp7 any; var root_412 any = A_arbace_c_A_const_13.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var root_416 any = A_arbace_c_A_const_14.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_c_A_const_17); var arg_420 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_A_const_15.GetRawRoot__O()); var tmp9 any; var root_421 any = A_arbace_c_A_const_18.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_c_repl_ns_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; if linked_422 == nil { tmp9 = ifn_423.Invoke__O() } else { tmp9 = linked_422.(*A_arbace_c_repl_ns_A).Invoke_O__O(root_421) }; arg_420 = tmp8.Invoke_O__O(tmp9); if linked_417 == nil { arg_415 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { arg_415 = linked_417.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) }; if linked_413 == nil { tmp7 = ifn_414.Invoke_O__O(arg_415) } else { tmp7 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; arg_396 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_394 == nil { return ifn_395.Invoke_O__O(arg_396) } else { return linked_394.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_393, arg_396) } }
func A_arbace_c_header_A_New() *A_arbace_c_header_A { A_arbace_c_A_Init(); t := &A_arbace_c_header_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_c_header_A) Ctor() {}
//line :46:1
func (t *A_arbace_c_header_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ___2 any) any { return nil }

func A_arbace_c_run_main_A_New() *A_arbace_c_run_main_A { A_arbace_c_A_Init(); t := &A_arbace_c_run_main_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_c_run_main_A) Ctor() {}
//line :48:1
func (t *A_arbace_c_run_main_A) DoInvoke_O_O_O__O(self, ns__0, args__1 any) any {


	var root_424 any = A_arbace_c_A_const_33.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = A_arbace_c_A_const_34.GetRawRoot__O(); var arg_428 any = ns__0; var arg_429 any = args__1; if linked_425 == nil { return ifn_426.Invoke_O_O_O__O(arg_427, arg_428, arg_429) } else { return linked_425.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_424, arg_427, arg_428, arg_429)
	}
}

















































































type A_arbace_c_A struct{ jrt.Object }

var A_arbace_c_A_const_pool *jrt.RefArray

var A_arbace_c_A_const_0 *lang.Var

var A_arbace_c_A_const_1 any

var A_arbace_c_A_const_2 *lang.Var

var A_arbace_c_A_const_3 any

var A_arbace_c_A_const_4 *lang.Keyword

var A_arbace_c_A_const_5 any

var A_arbace_c_A_const_6 *lang.Var

var A_arbace_c_A_const_7 *lang.Var

var A_arbace_c_A_const_8 *lang.Var

var A_arbace_c_A_const_9 *lang.Var

var A_arbace_c_A_const_10 any

var A_arbace_c_A_const_11 *lang.Var

var A_arbace_c_A_const_12 *lang.Var

var A_arbace_c_A_const_13 *lang.Var

var A_arbace_c_A_const_14 *lang.Var

var A_arbace_c_A_const_15 *lang.Var

var A_arbace_c_A_const_16 any

var A_arbace_c_A_const_17 any

var A_arbace_c_A_const_18 *lang.Var

var A_arbace_c_A_const_19 *lang.Var

var A_arbace_c_A_const_20 any

var A_arbace_c_A_const_21 any

var A_arbace_c_A_const_22 any

var A_arbace_c_A_const_23 any

var A_arbace_c_A_const_24 any

var A_arbace_c_A_const_25 any

var A_arbace_c_A_const_26 any

var A_arbace_c_A_const_27 any

var A_arbace_c_A_const_28 any

var A_arbace_c_A_const_29 any

var A_arbace_c_A_const_30 any

var A_arbace_c_A_const_31 any

var A_arbace_c_A_const_32 any

var A_arbace_c_A_const_33 *lang.Var

var A_arbace_c_A_const_34 *lang.Var

var A_arbace_c_A_init jrt.ClassInit

func A_arbace_c_A_Init() { if !A_arbace_c_A_init.Done() { A_arbace_c_A_init.Run(A_arbace_c_A_clinit) } }

func A_arbace_c_A_clinit() { A_arbace_c_A_clinit_p0(); A_arbace_c_A_clinit_p1(); A_arbace_c_A_clinit_p2() }

func A_arbace_c_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 51); A_arbace_c_A_const_0 = lang.Var_Cast(A_arbace_c_A_const_pool.A[16]); A_arbace_c_A_const_1 = A_arbace_c_A_const_pool.A[17]; A_arbace_c_A_const_2 = lang.Var_Cast(A_arbace_c_A_const_pool.A[18]); A_arbace_c_A_const_3 = A_arbace_c_A_const_pool.A[19]; A_arbace_c_A_const_4 = lang.Keyword_Cast(A_arbace_c_A_const_pool.A[20]); A_arbace_c_A_const_5 = A_arbace_c_A_const_pool.A[21]; A_arbace_c_A_const_6 = lang.Var_Cast(A_arbace_c_A_const_pool.A[22]); A_arbace_c_A_const_7 = lang.Var_Cast(A_arbace_c_A_const_pool.A[23]); A_arbace_c_A_const_8 = lang.Var_Cast(A_arbace_c_A_const_pool.A[24]); A_arbace_c_A_const_9 = lang.Var_Cast(A_arbace_c_A_const_pool.A[25]); A_arbace_c_A_const_10 = A_arbace_c_A_const_pool.A[26]; A_arbace_c_A_const_11 = lang.Var_Cast(A_arbace_c_A_const_pool.A[27]) }

func A_arbace_c_A_clinit_p1() { A_arbace_c_A_const_12 = lang.Var_Cast(A_arbace_c_A_const_pool.A[28]); A_arbace_c_A_const_13 = lang.Var_Cast(A_arbace_c_A_const_pool.A[29]); A_arbace_c_A_const_14 = lang.Var_Cast(A_arbace_c_A_const_pool.A[30]); A_arbace_c_A_const_15 = lang.Var_Cast(A_arbace_c_A_const_pool.A[31]); A_arbace_c_A_const_16 = A_arbace_c_A_const_pool.A[32]; A_arbace_c_A_const_17 = A_arbace_c_A_const_pool.A[33]; A_arbace_c_A_const_18 = lang.Var_Cast(A_arbace_c_A_const_pool.A[34]); A_arbace_c_A_const_19 = lang.Var_Cast(A_arbace_c_A_const_pool.A[35]); A_arbace_c_A_const_20 = A_arbace_c_A_const_pool.A[36]; A_arbace_c_A_const_21 = A_arbace_c_A_const_pool.A[37]; A_arbace_c_A_const_22 = A_arbace_c_A_const_pool.A[38]; A_arbace_c_A_const_23 = A_arbace_c_A_const_pool.A[39]; A_arbace_c_A_const_24 = A_arbace_c_A_const_pool.A[40]; A_arbace_c_A_const_25 = A_arbace_c_A_const_pool.A[41] }

func A_arbace_c_A_clinit_p2() { A_arbace_c_A_const_26 = A_arbace_c_A_const_pool.A[42]; A_arbace_c_A_const_27 = A_arbace_c_A_const_pool.A[43]; A_arbace_c_A_const_28 = A_arbace_c_A_const_pool.A[44]; A_arbace_c_A_const_29 = A_arbace_c_A_const_pool.A[45]; A_arbace_c_A_const_30 = A_arbace_c_A_const_pool.A[46]; A_arbace_c_A_const_31 = A_arbace_c_A_const_pool.A[47]; A_arbace_c_A_const_32 = A_arbace_c_A_const_pool.A[48]; A_arbace_c_A_const_33 = lang.Var_Cast(A_arbace_c_A_const_pool.A[49]); A_arbace_c_A_const_34 = lang.Var_Cast(A_arbace_c_A_const_pool.A[50]) }

func A_arbace_c_A_New() *A_arbace_c_A { A_arbace_c_A_Init(); t := &A_arbace_c_A{}; t.Ctor(); return t }

func (t *A_arbace_c_A) Ctor() {}

func (t *A_arbace_c_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_A) GetClass__Class() *jrt.Class { return A_arbace_c_A_class }

func (t *A_arbace_c_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_A); return ok }

func A_arbace_c_A_Cast(x any) *A_arbace_c_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_A_class)) }; return v }



type A_arbace_c_attr_decl_A struct{ j2g_header uint64 }

var A_arbace_c_attr_decl_A_fn_class *jrt.Class



type A_arbace_c_declare_A struct{ j2g_header uint64 }

var A_arbace_c_declare_A_fn_class *jrt.Class



type A_arbace_c_define_A struct{ j2g_header uint64 }

var A_arbace_c_define_A_fn_class *jrt.Class



type A_arbace_c_defn_A struct{ j2g_header uint64 }

var A_arbace_c_defn_A_fn_class *jrt.Class



type A_arbace_c_directive_A struct{ j2g_header uint64 }

var A_arbace_c_directive_A_fn_class *jrt.Class



type A_arbace_c_enum_A struct{ j2g_header uint64 }

var A_arbace_c_enum_A_fn_class *jrt.Class



type A_arbace_c_eval1501000004_A struct{ jrt.Object }

func A_arbace_c_eval1501000004_A_New() *A_arbace_c_eval1501000004_A { t := &A_arbace_c_eval1501000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_eval1501000004_A) Ctor() {}

func (t *A_arbace_c_eval1501000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_eval1501000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_eval1501000004_A_class }

func (t *A_arbace_c_eval1501000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_eval1501000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_eval1501000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_eval1501000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_eval1501000004_A); return ok }

func A_arbace_c_eval1501000004_A_Cast(x any) *A_arbace_c_eval1501000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_eval1501000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_eval1501000004_A_class)) }; return v }



type A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A struct{ j2g_header uint64 }

var A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_fn_class *jrt.Class



type A_arbace_c_eval1501000008_A struct{ jrt.Object }

func A_arbace_c_eval1501000008_A_New() *A_arbace_c_eval1501000008_A { t := &A_arbace_c_eval1501000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_eval1501000008_A) Ctor() {}

func (t *A_arbace_c_eval1501000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_eval1501000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_eval1501000008_A_class }

func (t *A_arbace_c_eval1501000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_eval1501000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_eval1501000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_eval1501000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_eval1501000008_A); return ok }

func A_arbace_c_eval1501000008_A_Cast(x any) *A_arbace_c_eval1501000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_eval1501000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_eval1501000008_A_class)) }; return v }



type A_arbace_c_eval1501000008_fn__1501000009_A struct{ j2g_header uint64 }

var A_arbace_c_eval1501000008_fn__1501000009_A_fn_class *jrt.Class



type A_arbace_c_file_A struct{ j2g_header uint64 }

var A_arbace_c_file_A_fn_class *jrt.Class



type A_arbace_c_group_A struct{ j2g_header uint64 }

var A_arbace_c_group_A_fn_class *jrt.Class



type A_arbace_c_header_A struct{ j2g_header uint64 }

var A_arbace_c_header_A_fn_class *jrt.Class



type A_arbace_c_include_A struct{ j2g_header uint64 }

var A_arbace_c_include_A_fn_class *jrt.Class



type A_arbace_c_pragma_A struct{ j2g_header uint64 }

var A_arbace_c_pragma_A_fn_class *jrt.Class



type A_arbace_c_repl_ns_A struct{ j2g_header uint64 }

var A_arbace_c_repl_ns_A_fn_class *jrt.Class



type A_arbace_c_run_main_A struct{ j2g_header uint64 }

var A_arbace_c_run_main_A_fn_class *jrt.Class



type A_arbace_c_static_assert_A struct{ j2g_header uint64 }

var A_arbace_c_static_assert_A_fn_class *jrt.Class



type A_arbace_c_struct_A struct{ j2g_header uint64 }

var A_arbace_c_struct_A_fn_class *jrt.Class



type A_arbace_c_typedef_A struct{ j2g_header uint64 }

var A_arbace_c_typedef_A_fn_class *jrt.Class



type A_arbace_c_undef_A struct{ j2g_header uint64 }

var A_arbace_c_undef_A_fn_class *jrt.Class



type A_arbace_c_union_A struct{ j2g_header uint64 }

var A_arbace_c_union_A_fn_class *jrt.Class



type A_arbace_c_var_A struct{ j2g_header uint64 }

var A_arbace_c_var_A_fn_class *jrt.Class
