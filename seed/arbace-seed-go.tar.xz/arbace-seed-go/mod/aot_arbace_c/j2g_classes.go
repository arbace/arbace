//line j2g_classes.ae:1
package aot_arbace_c

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_attr_decl_A_class, Name: "arbace.c$attr_decl", Modifiers: 25, Simple: "attr_decl", Go: "arbace/aot_arbace_c.A_arbace_c_attr_decl_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_declare_A_class, Name: "arbace.c$declare", Modifiers: 25, Simple: "declare", Go: "arbace/aot_arbace_c.A_arbace_c_declare_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_define_A_class, Name: "arbace.c$define", Modifiers: 25, Simple: "define", Go: "arbace/aot_arbace_c.A_arbace_c_define_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_defn_A_class, Name: "arbace.c$defn", Modifiers: 25, Simple: "defn", Go: "arbace/aot_arbace_c.A_arbace_c_defn_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_directive_A_class, Name: "arbace.c$directive", Modifiers: 25, Simple: "directive", Go: "arbace/aot_arbace_c.A_arbace_c_directive_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_enum_A_class, Name: "arbace.c$enum", Modifiers: 25, Simple: "enum", Go: "arbace/aot_arbace_c.A_arbace_c_enum_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_class, Name: "arbace.c$eval1501000004$loading__1927001464__auto____1501000005", Modifiers: 25, Simple: "loading__1927001464__auto____1501000005", Go: "arbace/aot_arbace_c.A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A", Source: "c.ae", Declaring: &A_arbace_c_eval1501000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_eval1501000008_fn__1501000009_A_class, Name: "arbace.c$eval1501000008$fn__1501000009", Modifiers: 25, Simple: "fn__1501000009", Go: "arbace/aot_arbace_c.A_arbace_c_eval1501000008_fn__1501000009_A", Source: "c.ae", Declaring: &A_arbace_c_eval1501000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_file_A_class, Name: "arbace.c$file", Modifiers: 25, Simple: "file", Go: "arbace/aot_arbace_c.A_arbace_c_file_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_group_A_class, Name: "arbace.c$group", Modifiers: 25, Simple: "group", Go: "arbace/aot_arbace_c.A_arbace_c_group_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_header_A_class, Name: "arbace.c$header", Modifiers: 25, Simple: "header", Go: "arbace/aot_arbace_c.A_arbace_c_header_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_include_A_class, Name: "arbace.c$include", Modifiers: 25, Simple: "include", Go: "arbace/aot_arbace_c.A_arbace_c_include_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_c_pragma_A_class, Name: "arbace.c$pragma", Modifiers: 25, Simple: "pragma", Go: "arbace/aot_arbace_c.A_arbace_c_pragma_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_repl_ns_A_class, Name: "arbace.c$repl_ns", Modifiers: 25, Simple: "repl_ns", Go: "arbace/aot_arbace_c.A_arbace_c_repl_ns_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_run_main_A_class, Name: "arbace.c$run_main", Modifiers: 25, Simple: "run_main", Go: "arbace/aot_arbace_c.A_arbace_c_run_main_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_c_static_assert_A_class, Name: "arbace.c$static_assert", Modifiers: 25, Simple: "static_assert", Go: "arbace/aot_arbace_c.A_arbace_c_static_assert_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_struct_A_class, Name: "arbace.c$struct", Modifiers: 25, Simple: "struct", Go: "arbace/aot_arbace_c.A_arbace_c_struct_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_typedef_A_class, Name: "arbace.c$typedef", Modifiers: 25, Simple: "typedef", Go: "arbace/aot_arbace_c.A_arbace_c_typedef_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_undef_A_class, Name: "arbace.c$undef", Modifiers: 25, Simple: "undef", Go: "arbace/aot_arbace_c.A_arbace_c_undef_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_union_A_class, Name: "arbace.c$union", Modifiers: 25, Simple: "union", Go: "arbace/aot_arbace_c.A_arbace_c_union_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_var_A_class, Name: "arbace.c$var", Modifiers: 25, Simple: "var", Go: "arbace/aot_arbace_c.A_arbace_c_var_A", Source: "c.ae", Declaring: &A_arbace_c_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_A_New()}; return nil }

var A_arbace_c_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_A_new}

var A_arbace_c_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c.A_arbace_c_A"})

func init() { i := A_arbace_c_A_class.Info(); i.IsInstance = A_arbace_c_A_InstanceOf; i.Init = A_arbace_c_A_Init; i.Table = A_arbace_c_A_members }

var A_arbace_c_attr_decl_A_class *jrt.Class

var A_arbace_c_declare_A_class *jrt.Class

var A_arbace_c_define_A_class *jrt.Class

var A_arbace_c_defn_A_class *jrt.Class

var A_arbace_c_directive_A_class *jrt.Class

var A_arbace_c_enum_A_class *jrt.Class

func A_arbace_c_eval1501000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_eval1501000004_A_New()}; return nil }

var A_arbace_c_eval1501000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_eval1501000004_A_new}

var A_arbace_c_eval1501000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c$eval1501000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_A_class, Simple: "eval1501000004", Go: "arbace/aot_arbace_c.A_arbace_c_eval1501000004_A"})

func init() { i := A_arbace_c_eval1501000004_A_class.Info(); i.IsInstance = A_arbace_c_eval1501000004_A_InstanceOf; i.Table = A_arbace_c_eval1501000004_A_members }

var A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_class *jrt.Class

func A_arbace_c_eval1501000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_eval1501000008_A_New()}; return nil }

var A_arbace_c_eval1501000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_eval1501000008_A_new}

var A_arbace_c_eval1501000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c$eval1501000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_A_class, Simple: "eval1501000008", Go: "arbace/aot_arbace_c.A_arbace_c_eval1501000008_A"})

func init() { i := A_arbace_c_eval1501000008_A_class.Info(); i.IsInstance = A_arbace_c_eval1501000008_A_InstanceOf; i.Table = A_arbace_c_eval1501000008_A_members }

var A_arbace_c_eval1501000008_fn__1501000009_A_class *jrt.Class

var A_arbace_c_file_A_class *jrt.Class

var A_arbace_c_group_A_class *jrt.Class

var A_arbace_c_header_A_class *jrt.Class

var A_arbace_c_include_A_class *jrt.Class

var A_arbace_c_pragma_A_class *jrt.Class

var A_arbace_c_repl_ns_A_class *jrt.Class

var A_arbace_c_run_main_A_class *jrt.Class

var A_arbace_c_static_assert_A_class *jrt.Class

var A_arbace_c_struct_A_class *jrt.Class

var A_arbace_c_typedef_A_class *jrt.Class

var A_arbace_c_undef_A_class *jrt.Class

var A_arbace_c_union_A_class *jrt.Class

var A_arbace_c_var_A_class *jrt.Class

func A_arbace_c__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c__init_A_Load__O()}; return nil }

func A_arbace_c__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c__init_A_New()}; return nil }

var A_arbace_c__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c__init_A_invoke, New: A_arbace_c__init_A_new}

var A_arbace_c__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c.A_arbace_c__init_A", Source: "c.ae"})

func init() { i := A_arbace_c__init_A_class.Info(); i.IsInstance = A_arbace_c__init_A_InstanceOf; i.Init = A_arbace_c__init_A_Init; i.Table = A_arbace_c__init_A_members }
