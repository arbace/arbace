//line aot_arbace_c__init.ae:1
package aot_arbace_c

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c__init_A_Unit0__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c__init_A_const_1) }
//line :1:1
func A_arbace_c__init_A_Unit1__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_2)) }
//line :1:1
func A_arbace_c__init_A_Unit2__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_c_eval1501000004_loading__1927001464__auto____1501000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c__init_A_Unit3__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c__init_A_const_1)).Equals_O__Z(A_arbace_c__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_eval1501000008_fn__1501000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_eval1501000008_fn__1501000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c_eval1501000008_fn__1501000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_c__init_A_Load__O() any { A_arbace_c__init_A_Init(); jrt.StartCheck(); A_arbace_c__init_A_Unit0__O(); A_arbace_c__init_A_Unit1__O(); A_arbace_c__init_A_Unit2__O(); A_arbace_c__init_A_Unit3__O(); A_arbace_c__init_A_Unit4__O(); A_arbace_c__init_A_Unit5__O(); A_arbace_c__init_A_Unit6__O(); A_arbace_c__init_A_Unit7__O(); A_arbace_c__init_A_Unit8__O(); A_arbace_c__init_A_Unit9__O(); A_arbace_c__init_A_Unit10__O(); A_arbace_c__init_A_Unit11__O(); A_arbace_c__init_A_Unit12__O(); A_arbace_c__init_A_Unit13__O(); A_arbace_c__init_A_Unit14__O(); A_arbace_c__init_A_Unit15__O(); A_arbace_c__init_A_Unit16__O(); A_arbace_c__init_A_Unit17__O(); A_arbace_c__init_A_Unit18__O(); A_arbace_c__init_A_Unit19__O(); A_arbace_c__init_A_Unit20__O(); A_arbace_c__init_A_Unit21__O(); A_arbace_c__init_A_Unit22__O(); A_arbace_c__init_A_Unit23__O(); A_arbace_c__init_A_Unit24__O(); A_arbace_c__init_A_Unit25__O(); A_arbace_c__init_A_Unit26__O(); A_arbace_c__init_A_Unit27__O(); A_arbace_c__init_A_Unit28__O(); A_arbace_c__init_A_Unit29__O(); A_arbace_c__init_A_Unit30__O(); A_arbace_c__init_A_Unit31__O(); A_arbace_c__init_A_Unit32__O(); A_arbace_c__init_A_Unit33__O(); A_arbace_c__init_A_Unit34__O(); A_arbace_c__init_A_Unit35__O(); A_arbace_c__init_A_Unit36__O(); A_arbace_c__init_A_Unit37__O(); A_arbace_c__init_A_Unit38__O(); A_arbace_c__init_A_Unit39__O(); A_arbace_c__init_A_Unit40__O(); A_arbace_c__init_A_Unit41__O(); A_arbace_c__init_A_Unit42__O(); A_arbace_c__init_A_Unit43__O(); A_arbace_c__init_A_Unit44__O(); A_arbace_c__init_A_Unit45__O(); A_arbace_c__init_A_Unit46__O(); A_arbace_c__init_A_Unit47__O(); A_arbace_c__init_A_Unit48__O(); A_arbace_c__init_A_Unit49__O(); A_arbace_c__init_A_Unit50__O(); A_arbace_c__init_A_Unit51__O(); A_arbace_c__init_A_Unit52__O(); A_arbace_c__init_A_Unit53__O(); A_arbace_c__init_A_Unit54__O(); A_arbace_c__init_A_Unit55__O(); A_arbace_c__init_A_Unit56__O(); return nil }













func A_arbace_c__init_A_Unit4__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_repl_ns_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_repl_ns_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c_repl_ns_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_5)); return A_arbace_c__init_A_const_4 }

func A_arbace_c__init_A_Unit5__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_6; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = A_arbace_c_file_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_file_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, true, nil); A_arbace_c_file_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_7)); return A_arbace_c__init_A_const_6 }
//line :21:1
func A_arbace_c__init_A_Unit6__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_c__init_A_const_6.SetMacro__V(); return nil }
//line :21:1
func A_arbace_c__init_A_Unit7__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); return A_arbace_c__init_A_const_6 }


func A_arbace_c__init_A_Unit8__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_8; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__10 any = A_arbace_c_include_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_include_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, true, nil); A_arbace_c_include_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__10, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_9)); return A_arbace_c__init_A_const_8 }
//line :24:1
func A_arbace_c__init_A_Unit9__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_c__init_A_const_8.SetMacro__V(); return nil }
//line :24:1
func A_arbace_c__init_A_Unit10__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); return A_arbace_c__init_A_const_8 }







func A_arbace_c__init_A_Unit11__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_10; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__12 any = A_arbace_c_defn_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_defn_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, true, nil); A_arbace_c_defn_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__12, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_11)); return A_arbace_c__init_A_const_10 }
//line :32:1
func A_arbace_c__init_A_Unit12__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); A_arbace_c__init_A_const_10.SetMacro__V(); return nil }
//line :32:1
func A_arbace_c__init_A_Unit13__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); return A_arbace_c__init_A_const_10 }
func A_arbace_c__init_A_Unit14__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_12; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__14 any = A_arbace_c_var_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_var_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, true, nil); A_arbace_c_var_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__14, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_13)); return A_arbace_c__init_A_const_12 }
//line :33:1
func A_arbace_c__init_A_Unit15__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_c__init_A_const_12.SetMacro__V(); return nil }
//line :33:1
func A_arbace_c__init_A_Unit16__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); return A_arbace_c__init_A_const_12 }
func A_arbace_c__init_A_Unit17__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_14; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__16 any = A_arbace_c_declare_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_declare_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, true, nil); A_arbace_c_declare_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__16, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_15)); return A_arbace_c__init_A_const_14 }
//line :34:1
func A_arbace_c__init_A_Unit18__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_c__init_A_const_14.SetMacro__V(); return nil }
//line :34:1
func A_arbace_c__init_A_Unit19__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); return A_arbace_c__init_A_const_14 }
func A_arbace_c__init_A_Unit20__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_16; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_c_typedef_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_typedef_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, true, nil); A_arbace_c_typedef_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_17)); return A_arbace_c__init_A_const_16 }
//line :35:1
func A_arbace_c__init_A_Unit21__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); A_arbace_c__init_A_const_16.SetMacro__V(); return nil }
//line :35:1
func A_arbace_c__init_A_Unit22__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); return A_arbace_c__init_A_const_16 }
func A_arbace_c__init_A_Unit23__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_18; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__20 any = A_arbace_c_struct_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_struct_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, true, nil); A_arbace_c_struct_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__20, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_19)); return A_arbace_c__init_A_const_18 }
//line :36:1
func A_arbace_c__init_A_Unit24__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_c__init_A_const_18.SetMacro__V(); return nil }
//line :36:1
func A_arbace_c__init_A_Unit25__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); return A_arbace_c__init_A_const_18 }
func A_arbace_c__init_A_Unit26__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_20; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__22 any = A_arbace_c_union_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_union_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, true, nil); A_arbace_c_union_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__22, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_21)); return A_arbace_c__init_A_const_20 }
//line :37:1
func A_arbace_c__init_A_Unit27__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); A_arbace_c__init_A_const_20.SetMacro__V(); return nil }
//line :37:1
func A_arbace_c__init_A_Unit28__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); return A_arbace_c__init_A_const_20 }
func A_arbace_c__init_A_Unit29__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_22; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__24 any = A_arbace_c_enum_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_enum_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, true, nil); A_arbace_c_enum_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__24, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_23)); return A_arbace_c__init_A_const_22 }
//line :38:1
func A_arbace_c__init_A_Unit30__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_c__init_A_const_22.SetMacro__V(); return nil }
//line :38:1
func A_arbace_c__init_A_Unit31__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_c__init_A_const_22 }
func A_arbace_c__init_A_Unit32__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_24; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__26 any = A_arbace_c_group_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_group_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, true, nil); A_arbace_c_group_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__26, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_25)); return A_arbace_c__init_A_const_24 }
//line :39:1
func A_arbace_c__init_A_Unit33__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_c__init_A_const_24.SetMacro__V(); return nil }
//line :39:1
func A_arbace_c__init_A_Unit34__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); return A_arbace_c__init_A_const_24 }
func A_arbace_c__init_A_Unit35__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_26; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__28 any = A_arbace_c_static_assert_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_static_assert_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, true, nil); A_arbace_c_static_assert_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__28, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_27)); return A_arbace_c__init_A_const_26 }
//line :40:1
func A_arbace_c__init_A_Unit36__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); A_arbace_c__init_A_const_26.SetMacro__V(); return nil }
//line :40:1
func A_arbace_c__init_A_Unit37__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); return A_arbace_c__init_A_const_26 }
func A_arbace_c__init_A_Unit38__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_28; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__30 any = A_arbace_c_attr_decl_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_attr_decl_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, true, nil); A_arbace_c_attr_decl_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__30, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_29)); return A_arbace_c__init_A_const_28 }
//line :41:1
func A_arbace_c__init_A_Unit39__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); A_arbace_c__init_A_const_28.SetMacro__V(); return nil }
//line :41:1
func A_arbace_c__init_A_Unit40__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); return A_arbace_c__init_A_const_28 }
func A_arbace_c__init_A_Unit41__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_30; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__32 any = A_arbace_c_define_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_define_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, true, nil); A_arbace_c_define_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__32, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_31)); return A_arbace_c__init_A_const_30 }
//line :42:1
func A_arbace_c__init_A_Unit42__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_c__init_A_const_30.SetMacro__V(); return nil }
//line :42:1
func A_arbace_c__init_A_Unit43__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); return A_arbace_c__init_A_const_30 }
func A_arbace_c__init_A_Unit44__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_32; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__34 any = A_arbace_c_undef_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_undef_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, true, nil); A_arbace_c_undef_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__34, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_33)); return A_arbace_c__init_A_const_32 }
//line :43:1
func A_arbace_c__init_A_Unit45__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); A_arbace_c__init_A_const_32.SetMacro__V(); return nil }
//line :43:1
func A_arbace_c__init_A_Unit46__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); return A_arbace_c__init_A_const_32 }
func A_arbace_c__init_A_Unit47__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_34; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__36 any = A_arbace_c_directive_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_directive_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, true, nil); A_arbace_c_directive_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__36, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_35)); return A_arbace_c__init_A_const_34 }
//line :44:1
func A_arbace_c__init_A_Unit48__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_c__init_A_const_34.SetMacro__V(); return nil }
//line :44:1
func A_arbace_c__init_A_Unit49__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return A_arbace_c__init_A_const_34 }
func A_arbace_c__init_A_Unit50__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_36; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__38 any = A_arbace_c_pragma_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_pragma_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, true, nil); A_arbace_c_pragma_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__38, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_37)); return A_arbace_c__init_A_const_36 }
//line :45:1
func A_arbace_c__init_A_Unit51__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_c__init_A_const_36.SetMacro__V(); return nil }
//line :45:1
func A_arbace_c__init_A_Unit52__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); return A_arbace_c__init_A_const_36 }
func A_arbace_c__init_A_Unit53__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_38; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__40 any = A_arbace_c_header_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_header_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, true, nil); A_arbace_c_header_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__40, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_39)); return A_arbace_c__init_A_const_38 }
//line :46:1
func A_arbace_c__init_A_Unit54__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_c__init_A_const_38.SetMacro__V(); return nil }
//line :46:1
func A_arbace_c__init_A_Unit55__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); return A_arbace_c__init_A_const_38 }

func A_arbace_c__init_A_Unit56__O() any { A_arbace_c__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_c__init_A_const_40; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__42 any = A_arbace_c_run_main_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_run_main_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, true, nil); A_arbace_c_run_main_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__42, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c__init_A_const_41)); return A_arbace_c__init_A_const_40 }













































































type A_arbace_c__init_A struct{ jrt.Object }

var A_arbace_c__init_A_const_pool *jrt.RefArray

var A_arbace_c__init_A_const_0 *lang.Var

var A_arbace_c__init_A_const_1 any

var A_arbace_c__init_A_const_2 any

var A_arbace_c__init_A_const_3 any

var A_arbace_c__init_A_const_4 *lang.Var

var A_arbace_c__init_A_const_5 any

var A_arbace_c__init_A_const_6 *lang.Var

var A_arbace_c__init_A_const_7 any

var A_arbace_c__init_A_const_8 *lang.Var

var A_arbace_c__init_A_const_9 any

var A_arbace_c__init_A_const_10 *lang.Var

var A_arbace_c__init_A_const_11 any

var A_arbace_c__init_A_const_12 *lang.Var

var A_arbace_c__init_A_const_13 any

var A_arbace_c__init_A_const_14 *lang.Var

var A_arbace_c__init_A_const_15 any

var A_arbace_c__init_A_const_16 *lang.Var

var A_arbace_c__init_A_const_17 any

var A_arbace_c__init_A_const_18 *lang.Var

var A_arbace_c__init_A_const_19 any

var A_arbace_c__init_A_const_20 *lang.Var

var A_arbace_c__init_A_const_21 any

var A_arbace_c__init_A_const_22 *lang.Var

var A_arbace_c__init_A_const_23 any

var A_arbace_c__init_A_const_24 *lang.Var

var A_arbace_c__init_A_const_25 any

var A_arbace_c__init_A_const_26 *lang.Var

var A_arbace_c__init_A_const_27 any

var A_arbace_c__init_A_const_28 *lang.Var

var A_arbace_c__init_A_const_29 any

var A_arbace_c__init_A_const_30 *lang.Var

var A_arbace_c__init_A_const_31 any

var A_arbace_c__init_A_const_32 *lang.Var

var A_arbace_c__init_A_const_33 any

var A_arbace_c__init_A_const_34 *lang.Var

var A_arbace_c__init_A_const_35 any

var A_arbace_c__init_A_const_36 *lang.Var

var A_arbace_c__init_A_const_37 any

var A_arbace_c__init_A_const_38 *lang.Var

var A_arbace_c__init_A_const_39 any

var A_arbace_c__init_A_const_40 *lang.Var

var A_arbace_c__init_A_const_41 any

var A_arbace_c__init_A_init jrt.ClassInit

func A_arbace_c__init_A_Init() { if !A_arbace_c__init_A_init.Done() { A_arbace_c__init_A_init.Run(A_arbace_c__init_A_clinit) } }

func A_arbace_c__init_A_clinit() { A_arbace_c__init_A_clinit_p0(); A_arbace_c__init_A_clinit_p1(); A_arbace_c__init_A_clinit_p2(); A_arbace_c__init_A_clinit_p3() }

func A_arbace_c__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1, 55); A_arbace_c__init_A_const_0 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[13]); A_arbace_c__init_A_const_1 = A_arbace_c__init_A_const_pool.A[14]; A_arbace_c__init_A_const_2 = A_arbace_c__init_A_const_pool.A[15]; A_arbace_c__init_A_const_3 = A_arbace_c__init_A_const_pool.A[16]; A_arbace_c__init_A_const_4 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[17]); A_arbace_c__init_A_const_5 = A_arbace_c__init_A_const_pool.A[18]; A_arbace_c__init_A_const_6 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[19]); A_arbace_c__init_A_const_7 = A_arbace_c__init_A_const_pool.A[20]; A_arbace_c__init_A_const_8 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[21]); A_arbace_c__init_A_const_9 = A_arbace_c__init_A_const_pool.A[22]; A_arbace_c__init_A_const_10 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[23]); A_arbace_c__init_A_const_11 = A_arbace_c__init_A_const_pool.A[24]; A_arbace_c__init_A_const_12 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[25]) }

func A_arbace_c__init_A_clinit_p1() { A_arbace_c__init_A_const_13 = A_arbace_c__init_A_const_pool.A[26]; A_arbace_c__init_A_const_14 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[27]); A_arbace_c__init_A_const_15 = A_arbace_c__init_A_const_pool.A[28]; A_arbace_c__init_A_const_16 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[29]); A_arbace_c__init_A_const_17 = A_arbace_c__init_A_const_pool.A[30]; A_arbace_c__init_A_const_18 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[31]); A_arbace_c__init_A_const_19 = A_arbace_c__init_A_const_pool.A[32]; A_arbace_c__init_A_const_20 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[33]); A_arbace_c__init_A_const_21 = A_arbace_c__init_A_const_pool.A[34]; A_arbace_c__init_A_const_22 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[35]); A_arbace_c__init_A_const_23 = A_arbace_c__init_A_const_pool.A[36]; A_arbace_c__init_A_const_24 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[37]); A_arbace_c__init_A_const_25 = A_arbace_c__init_A_const_pool.A[38] }

func A_arbace_c__init_A_clinit_p2() { A_arbace_c__init_A_const_26 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[39]); A_arbace_c__init_A_const_27 = A_arbace_c__init_A_const_pool.A[40]; A_arbace_c__init_A_const_28 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[41]); A_arbace_c__init_A_const_29 = A_arbace_c__init_A_const_pool.A[42]; A_arbace_c__init_A_const_30 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[43]); A_arbace_c__init_A_const_31 = A_arbace_c__init_A_const_pool.A[44]; A_arbace_c__init_A_const_32 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[45]); A_arbace_c__init_A_const_33 = A_arbace_c__init_A_const_pool.A[46]; A_arbace_c__init_A_const_34 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[47]); A_arbace_c__init_A_const_35 = A_arbace_c__init_A_const_pool.A[48]; A_arbace_c__init_A_const_36 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[49]); A_arbace_c__init_A_const_37 = A_arbace_c__init_A_const_pool.A[50]; A_arbace_c__init_A_const_38 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[51]) }

func A_arbace_c__init_A_clinit_p3() { A_arbace_c__init_A_const_39 = A_arbace_c__init_A_const_pool.A[52]; A_arbace_c__init_A_const_40 = lang.Var_Cast(A_arbace_c__init_A_const_pool.A[53]); A_arbace_c__init_A_const_41 = A_arbace_c__init_A_const_pool.A[54] }

func A_arbace_c__init_A_New() *A_arbace_c__init_A { A_arbace_c__init_A_Init(); t := &A_arbace_c__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c__init_A) Ctor() {}

func (t *A_arbace_c__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c__init_A) GetClass__Class() *jrt.Class { return A_arbace_c__init_A_class }

func (t *A_arbace_c__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c__init_A); return ok }

func A_arbace_c__init_A_Cast(x any) *A_arbace_c__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c__init_A_class)) }; return v }
