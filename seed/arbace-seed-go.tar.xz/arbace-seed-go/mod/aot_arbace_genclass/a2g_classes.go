//line a2g_classes.ae:1
package aot_arbace_genclass

import (
	"arbace/jrt"
	"reflect"
)
//line :6:1
func A_arbace_genclass__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_genclass__init_A_Load__O(); case 1: return A_arbace_genclass__init_A_Unit0__O(); case 2: return A_arbace_genclass__init_A_Unit1__O(); case 3: return A_arbace_genclass__init_A_Unit10__O(); case 4: return A_arbace_genclass__init_A_Unit11__O(); case 5: return A_arbace_genclass__init_A_Unit12__O(); case 6: return A_arbace_genclass__init_A_Unit2__O(); case 7: return A_arbace_genclass__init_A_Unit3__O(); case 8: return A_arbace_genclass__init_A_Unit4__O(); case 9: return A_arbace_genclass__init_A_Unit5__O(); case 10: return A_arbace_genclass__init_A_Unit6__O(); case 11: return A_arbace_genclass__init_A_Unit7__O(); case 12: return A_arbace_genclass__init_A_Unit8__O(); case 13: return A_arbace_genclass__init_A_Unit9__O()}; return nil }

func A_arbace_genclass__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_genclass__init_A_New()}; return nil }

var A_arbace_genclass__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_genclass__init_A_invoke, New: A_arbace_genclass__init_A_new}

var A_arbace_genclass__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.genclass__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_genclass.A_arbace_genclass__init_A", Source: "genclass.ae"})

func init() { i := A_arbace_genclass__init_A_class.Info(); i.IsInstance = A_arbace_genclass__init_A_InstanceOf; i.Init = A_arbace_genclass__init_A_Init; i.Table = A_arbace_genclass__init_A_members; jrt.RegisterGoType(A_arbace_genclass__init_A_class, reflect.TypeFor[A_arbace_genclass__init_A]()) }
