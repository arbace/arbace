//line aot_arbace_genclass__init.ae:1
package aot_arbace_genclass

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_genclass__init_A_Load__O() any { A_arbace_genclass__init_A_Init(); A_arbace_genclass__init_A_Unit0__O(); A_arbace_genclass__init_A_Unit1__O(); A_arbace_genclass__init_A_Unit2__O(); A_arbace_genclass__init_A_Unit3__O(); A_arbace_genclass__init_A_Unit4__O(); A_arbace_genclass__init_A_Unit5__O(); A_arbace_genclass__init_A_Unit6__O(); A_arbace_genclass__init_A_Unit7__O(); A_arbace_genclass__init_A_Unit8__O(); A_arbace_genclass__init_A_Unit9__O(); A_arbace_genclass__init_A_Unit10__O(); A_arbace_genclass__init_A_Unit11__O(); A_arbace_genclass__init_A_Unit12__O(); return nil }











func A_arbace_genclass__init_A_Unit0__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_genclass__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_genclass__init_A_const_1) }


func A_arbace_genclass__init_A_Unit1__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_41)); return nil }
//line :20:1
func A_arbace_genclass__init_A_Unit2__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_42)); return nil }
//line :20:1
func A_arbace_genclass__init_A_Unit3__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_43)); return nil }


func A_arbace_genclass__init_A_Unit4__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_2; var tmp2 any = A_arbace_genclass__init_A_const_3; var tmp3 *jrt.Class; jrt.Integer_Init(); tmp3 = jrt.Integer_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_genclass__init_A_const_4; var tmp6 *jrt.Class; jrt.Byte_Init(); tmp6 = jrt.Byte_TYPE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_genclass__init_A_const_5; var tmp9 any = jrt.Class_ForName_String__Class(Lit_44).Ref(); var tmp10 any = A_arbace_genclass__init_A_const_6; var tmp11 *jrt.Class; jrt.Character_Init(); tmp11 = jrt.Character_TYPE; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_genclass__init_A_const_7; var tmp14 any = jrt.Class_ForName_String__Class(Lit_45).Ref(); var tmp15 any = A_arbace_genclass__init_A_const_8; var tmp16 *jrt.Class; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TYPE; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_genclass__init_A_const_9; var tmp19 *jrt.Class; jrt.Void_Init(); tmp19 = jrt.Void_TYPE; var tmp20 any = tmp19.Ref(); var tmp21 any = A_arbace_genclass__init_A_const_10; var tmp22 any = jrt.Class_ForName_String__Class(Lit_46).Ref(); var tmp23 any = A_arbace_genclass__init_A_const_11; var tmp24 any = jrt.Class_ForName_String__Class(Lit_47).Ref(); var tmp25 any = A_arbace_genclass__init_A_const_12; var tmp26 *jrt.Class; jrt.Float_Init(); tmp26 = jrt.Float_TYPE; var tmp27 any = tmp26.Ref(); var tmp28 any = A_arbace_genclass__init_A_const_13; var tmp29 any = jrt.Class_ForName_String__Class(Lit_48).Ref(); var tmp30 any = A_arbace_genclass__init_A_const_14; var tmp31 any = jrt.Class_ForName_String__Class(Lit_49).Ref(); var tmp32 any = A_arbace_genclass__init_A_const_15; var tmp33 any = jrt.Class_ForName_String__Class(Lit_50).Ref(); var tmp34 any = A_arbace_genclass__init_A_const_16; var tmp35 *jrt.Class; jrt.Double_Init(); tmp35 = jrt.Double_TYPE; var tmp36 any = tmp35.Ref(); var tmp37 any = A_arbace_genclass__init_A_const_17; var tmp38 *jrt.Class; jrt.Short_Init(); tmp38 = jrt.Short_TYPE; var tmp39 any = tmp38.Ref(); var tmp40 any = A_arbace_genclass__init_A_const_18; var tmp41 *jrt.Class; jrt.Long_Init(); tmp41 = jrt.Long_TYPE; var tmp42 any = tmp41.Ref(); var tmp43 any = A_arbace_genclass__init_A_const_19; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5, tmp7, tmp8, tmp9, tmp10, tmp12, tmp13, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp36, tmp37, tmp39, tmp40, tmp42, tmp43, jrt.Class_ForName_String__Class(Lit_51).Ref()))); var tmp44 *lang.Var = A_arbace_genclass__init_A_const_2; jrt.NN(tmp44).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_20)); return A_arbace_genclass__init_A_const_2.Ref() }


















func A_arbace_genclass__init_A_Unit5__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_21; var tmp2 any = aot_arbace_core.A_arbace_core_the_array_class_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_the_array_class_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_the_array_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_22)); return A_arbace_genclass__init_A_const_21.Ref() }







func A_arbace_genclass__init_A_Unit6__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(50, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_23; var tmp2 any = aot_arbace_core.A_arbace_core_the_class_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_the_class_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_the_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_24)); return A_arbace_genclass__init_A_const_23.Ref() }












func A_arbace_genclass__init_A_Unit7__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_25; var tmp2 any = aot_arbace_core.A_arbace_core_gen_class_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_gen_class_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_gen_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_26)); return A_arbace_genclass__init_A_const_25.Ref() }
//line :63:1
func A_arbace_genclass__init_A_Unit8__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); jrt.NN(A_arbace_genclass__init_A_const_25).SetMacro__V(); return nil }
//line :63:1
func A_arbace_genclass__init_A_Unit9__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); return A_arbace_genclass__init_A_const_25.Ref() }







func A_arbace_genclass__init_A_Unit10__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_27; var tmp2 any = aot_arbace_core.A_arbace_core_gen_interface_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_gen_interface_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_gen_interface_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_28)); return A_arbace_genclass__init_A_const_27.Ref() }
//line :71:1
func A_arbace_genclass__init_A_Unit11__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); jrt.NN(A_arbace_genclass__init_A_const_27).SetMacro__V(); return nil }
//line :71:1
func A_arbace_genclass__init_A_Unit12__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); return A_arbace_genclass__init_A_const_27.Ref() }







type A_arbace_genclass__init_A struct{ jrt.Object }

var A_arbace_genclass__init_A_const_0 *lang.Var

var A_arbace_genclass__init_A_const_1 any

var A_arbace_genclass__init_A_const_2 *lang.Var

var A_arbace_genclass__init_A_const_3 any

var A_arbace_genclass__init_A_const_4 any

var A_arbace_genclass__init_A_const_5 any

var A_arbace_genclass__init_A_const_6 any

var A_arbace_genclass__init_A_const_7 any

var A_arbace_genclass__init_A_const_8 any

var A_arbace_genclass__init_A_const_9 any

var A_arbace_genclass__init_A_const_10 any

var A_arbace_genclass__init_A_const_11 any

var A_arbace_genclass__init_A_const_12 any

var A_arbace_genclass__init_A_const_13 any

var A_arbace_genclass__init_A_const_14 any

var A_arbace_genclass__init_A_const_15 any

var A_arbace_genclass__init_A_const_16 any

var A_arbace_genclass__init_A_const_17 any

var A_arbace_genclass__init_A_const_18 any

var A_arbace_genclass__init_A_const_19 any

var A_arbace_genclass__init_A_const_20 any

var A_arbace_genclass__init_A_const_21 *lang.Var

var A_arbace_genclass__init_A_const_22 any

var A_arbace_genclass__init_A_const_23 *lang.Var

var A_arbace_genclass__init_A_const_24 any

var A_arbace_genclass__init_A_const_25 *lang.Var

var A_arbace_genclass__init_A_const_26 any

var A_arbace_genclass__init_A_const_27 *lang.Var

var A_arbace_genclass__init_A_const_28 any

var A_arbace_genclass__init_A_init jrt.ClassInit

func A_arbace_genclass__init_A_Init() { if !A_arbace_genclass__init_A_init.Done() { A_arbace_genclass__init_A_init.Run(A_arbace_genclass__init_A_clinit) } }

func A_arbace_genclass__init_A_clinit() { A_arbace_genclass__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_genclass__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_genclass__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_genclass__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(); A_arbace_genclass__init_A_const_4 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(); A_arbace_genclass__init_A_const_5 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_genclass__init_A_const_6 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(); A_arbace_genclass__init_A_const_7 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(); A_arbace_genclass__init_A_const_8 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(); A_arbace_genclass__init_A_const_9 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(); A_arbace_genclass__init_A_const_10 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(); A_arbace_genclass__init_A_const_11 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref(); A_arbace_genclass__init_A_const_12 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(); A_arbace_genclass__init_A_const_13 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref(); A_arbace_genclass__init_A_const_14 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(); A_arbace_genclass__init_A_const_15 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref(); A_arbace_genclass__init_A_const_16 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(); A_arbace_genclass__init_A_const_17 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref(); A_arbace_genclass__init_A_const_18 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(); A_arbace_genclass__init_A_const_19 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_genclass__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_genclass__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_genclass__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_genclass__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(); var tmp8 any = lang.RT_ClassForNameNonLoading_String__Class(Lit_30).Ref(); var tmp9 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); A_arbace_genclass__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp11, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_genclass__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_genclass__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_35).Ref(), Lit_36, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), Lit_38, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_genclass__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_genclass__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_35).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), Lit_38, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)) }

func A_arbace_genclass__init_A_New() *A_arbace_genclass__init_A { A_arbace_genclass__init_A_Init(); t := &A_arbace_genclass__init_A{}; t.Ctor(); return t }

func (t *A_arbace_genclass__init_A) Ctor() {}

func (t *A_arbace_genclass__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_genclass__init_A) GetClass__Class() *jrt.Class { return A_arbace_genclass__init_A_class }

func (t *A_arbace_genclass__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_genclass__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_genclass__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_genclass__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_genclass__init_A); return ok }

func A_arbace_genclass__init_A_Cast(x any) *A_arbace_genclass__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_genclass__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_genclass__init_A_class)) }; return v }
