//line aot_arbace_genclass__init.ae:1
package aot_arbace_genclass

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_genclass__init_A_Load__O() any { A_arbace_genclass__init_A_Init(); jrt.StartCheck(); A_arbace_genclass__init_A_Unit0__O(); A_arbace_genclass__init_A_Unit1__O(); A_arbace_genclass__init_A_Unit2__O(); A_arbace_genclass__init_A_Unit3__O(); A_arbace_genclass__init_A_Unit4__O(); A_arbace_genclass__init_A_Unit5__O(); A_arbace_genclass__init_A_Unit6__O(); A_arbace_genclass__init_A_Unit7__O(); A_arbace_genclass__init_A_Unit8__O(); A_arbace_genclass__init_A_Unit9__O(); A_arbace_genclass__init_A_Unit10__O(); A_arbace_genclass__init_A_Unit11__O(); A_arbace_genclass__init_A_Unit12__O(); return nil }











func A_arbace_genclass__init_A_Unit0__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_genclass__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_genclass__init_A_const_1) }


func A_arbace_genclass__init_A_Unit1__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :20:1
func A_arbace_genclass__init_A_Unit2__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }
//line :20:1
func A_arbace_genclass__init_A_Unit3__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref() }


func A_arbace_genclass__init_A_Unit4__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_2; var tmp2 any = A_arbace_genclass__init_A_const_3; var tmp3 any = jrt.Integer_TYPE.Ref(); var tmp4 any = A_arbace_genclass__init_A_const_4; var tmp5 any = jrt.Byte_TYPE.Ref(); var tmp6 any = A_arbace_genclass__init_A_const_5; var tmp7 any = jrt.Class_ForName_String__Class(Lit_4).Ref(); var tmp8 any = A_arbace_genclass__init_A_const_6; var tmp9 any = jrt.Character_TYPE.Ref(); var tmp10 any = A_arbace_genclass__init_A_const_7; var tmp11 any = jrt.Class_ForName_String__Class(Lit_5).Ref(); var tmp12 any = A_arbace_genclass__init_A_const_8; var tmp13 any = jrt.Boolean_TYPE.Ref(); var tmp14 any = A_arbace_genclass__init_A_const_9; var tmp15 any = jrt.Void_TYPE.Ref(); var tmp16 any = A_arbace_genclass__init_A_const_10; var tmp17 any = jrt.Class_ForName_String__Class(Lit_6).Ref(); var tmp18 any = A_arbace_genclass__init_A_const_11; var tmp19 any = jrt.Class_ForName_String__Class(Lit_7).Ref(); var tmp20 any = A_arbace_genclass__init_A_const_12; var tmp21 any = jrt.Float_TYPE.Ref(); var tmp22 any = A_arbace_genclass__init_A_const_13; var tmp23 any = jrt.Class_ForName_String__Class(Lit_8).Ref(); var tmp24 any = A_arbace_genclass__init_A_const_14; var tmp25 any = jrt.Class_ForName_String__Class(Lit_9).Ref(); var tmp26 any = A_arbace_genclass__init_A_const_15; var tmp27 any = jrt.Class_ForName_String__Class(Lit_10).Ref(); var tmp28 any = A_arbace_genclass__init_A_const_16; var tmp29 any = jrt.Double_TYPE.Ref(); var tmp30 any = A_arbace_genclass__init_A_const_17; var tmp31 any = jrt.Short_TYPE.Ref(); var tmp32 any = A_arbace_genclass__init_A_const_18; var tmp33 any = jrt.Long_TYPE.Ref(); var tmp34 any = A_arbace_genclass__init_A_const_19; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, jrt.Class_ForName_String__Class(Lit_11).Ref()))); var tmp35 *lang.Var = A_arbace_genclass__init_A_const_2; tmp35.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_20)); return A_arbace_genclass__init_A_const_2 }


















func A_arbace_genclass__init_A_Unit5__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_core.A_arbace_core_the_array_class_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_the_array_class_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); aot_arbace_core.A_arbace_core_the_array_class_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_22)); return A_arbace_genclass__init_A_const_21 }







func A_arbace_genclass__init_A_Unit6__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_core.A_arbace_core_the_class_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_the_class_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); aot_arbace_core.A_arbace_core_the_class_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_24)); return A_arbace_genclass__init_A_const_23 }












func A_arbace_genclass__init_A_Unit7__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_25; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = aot_arbace_core.A_arbace_core_gen_class_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_gen_class_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, true, nil); aot_arbace_core.A_arbace_core_gen_class_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_26)); return A_arbace_genclass__init_A_const_25 }
//line :63:1
func A_arbace_genclass__init_A_Unit8__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); A_arbace_genclass__init_A_const_25.SetMacro__V(); return nil }
//line :63:1
func A_arbace_genclass__init_A_Unit9__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); return A_arbace_genclass__init_A_const_25 }







func A_arbace_genclass__init_A_Unit10__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_genclass__init_A_const_27; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = aot_arbace_core.A_arbace_core_gen_interface_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_gen_interface_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, true, nil); aot_arbace_core.A_arbace_core_gen_interface_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_genclass__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_genclass__init_A_const_28)); return A_arbace_genclass__init_A_const_27 }
//line :71:1
func A_arbace_genclass__init_A_Unit11__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); A_arbace_genclass__init_A_const_27.SetMacro__V(); return nil }
//line :71:1
func A_arbace_genclass__init_A_Unit12__O() any { A_arbace_genclass__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); return A_arbace_genclass__init_A_const_27 }







type A_arbace_genclass__init_A struct{ jrt.Object }

var A_arbace_genclass__init_A_const_pool *jrt.RefArray

var A_arbace_genclass__init_A_const_0 *lang.Var

var A_arbace_genclass__init_A_const_1 any

var A_arbace_genclass__init_A_const_2 *lang.Var

var A_arbace_genclass__init_A_const_3 any

var A_arbace_genclass__init_A_const_4 any

var A_arbace_genclass__init_A_const_5 any

var A_arbace_genclass__init_A_const_6 any

var A_arbace_genclass__init_A_const_7 any

var A_arbace_genclass__init_A_const_8 any

var A_arbace_genclass__init_A_const_9 any

var A_arbace_genclass__init_A_const_10 any

var A_arbace_genclass__init_A_const_11 any

var A_arbace_genclass__init_A_const_12 any

var A_arbace_genclass__init_A_const_13 any

var A_arbace_genclass__init_A_const_14 any

var A_arbace_genclass__init_A_const_15 any

var A_arbace_genclass__init_A_const_16 any

var A_arbace_genclass__init_A_const_17 any

var A_arbace_genclass__init_A_const_18 any

var A_arbace_genclass__init_A_const_19 any

var A_arbace_genclass__init_A_const_20 any

var A_arbace_genclass__init_A_const_21 *lang.Var

var A_arbace_genclass__init_A_const_22 any

var A_arbace_genclass__init_A_const_23 *lang.Var

var A_arbace_genclass__init_A_const_24 any

var A_arbace_genclass__init_A_const_25 *lang.Var

var A_arbace_genclass__init_A_const_26 any

var A_arbace_genclass__init_A_const_27 *lang.Var

var A_arbace_genclass__init_A_const_28 any

var A_arbace_genclass__init_A_init jrt.ClassInit

func A_arbace_genclass__init_A_Init() { if !A_arbace_genclass__init_A_init.Done() { A_arbace_genclass__init_A_init.Run(A_arbace_genclass__init_A_clinit) } }

func A_arbace_genclass__init_A_clinit() { A_arbace_genclass__init_A_clinit_p0(); A_arbace_genclass__init_A_clinit_p1(); A_arbace_genclass__init_A_clinit_p2() }

func A_arbace_genclass__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_genclass__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 59); A_arbace_genclass__init_A_const_0 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[30]); A_arbace_genclass__init_A_const_1 = A_arbace_genclass__init_A_const_pool.A[31]; A_arbace_genclass__init_A_const_2 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[32]); A_arbace_genclass__init_A_const_3 = A_arbace_genclass__init_A_const_pool.A[33]; A_arbace_genclass__init_A_const_4 = A_arbace_genclass__init_A_const_pool.A[34]; A_arbace_genclass__init_A_const_5 = A_arbace_genclass__init_A_const_pool.A[35]; A_arbace_genclass__init_A_const_6 = A_arbace_genclass__init_A_const_pool.A[36]; A_arbace_genclass__init_A_const_7 = A_arbace_genclass__init_A_const_pool.A[37]; A_arbace_genclass__init_A_const_8 = A_arbace_genclass__init_A_const_pool.A[38]; A_arbace_genclass__init_A_const_9 = A_arbace_genclass__init_A_const_pool.A[39]; A_arbace_genclass__init_A_const_10 = A_arbace_genclass__init_A_const_pool.A[40]; A_arbace_genclass__init_A_const_11 = A_arbace_genclass__init_A_const_pool.A[41]; A_arbace_genclass__init_A_const_12 = A_arbace_genclass__init_A_const_pool.A[42]; A_arbace_genclass__init_A_const_13 = A_arbace_genclass__init_A_const_pool.A[43] }

func A_arbace_genclass__init_A_clinit_p1() { A_arbace_genclass__init_A_const_14 = A_arbace_genclass__init_A_const_pool.A[44]; A_arbace_genclass__init_A_const_15 = A_arbace_genclass__init_A_const_pool.A[45]; A_arbace_genclass__init_A_const_16 = A_arbace_genclass__init_A_const_pool.A[46]; A_arbace_genclass__init_A_const_17 = A_arbace_genclass__init_A_const_pool.A[47]; A_arbace_genclass__init_A_const_18 = A_arbace_genclass__init_A_const_pool.A[48]; A_arbace_genclass__init_A_const_19 = A_arbace_genclass__init_A_const_pool.A[49]; A_arbace_genclass__init_A_const_20 = A_arbace_genclass__init_A_const_pool.A[50]; A_arbace_genclass__init_A_const_21 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[51]); A_arbace_genclass__init_A_const_22 = A_arbace_genclass__init_A_const_pool.A[52]; A_arbace_genclass__init_A_const_23 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[53]); A_arbace_genclass__init_A_const_24 = A_arbace_genclass__init_A_const_pool.A[54]; A_arbace_genclass__init_A_const_25 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[55]); A_arbace_genclass__init_A_const_26 = A_arbace_genclass__init_A_const_pool.A[56]; A_arbace_genclass__init_A_const_27 = lang.Var_Cast(A_arbace_genclass__init_A_const_pool.A[57]) }

func A_arbace_genclass__init_A_clinit_p2() { A_arbace_genclass__init_A_const_28 = A_arbace_genclass__init_A_const_pool.A[58] }

func A_arbace_genclass__init_A_New() *A_arbace_genclass__init_A { A_arbace_genclass__init_A_Init(); t := &A_arbace_genclass__init_A{}; t.Ctor(); return t }

func (t *A_arbace_genclass__init_A) Ctor() {}

func (t *A_arbace_genclass__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_genclass__init_A) GetClass__Class() *jrt.Class { return A_arbace_genclass__init_A_class }

func (t *A_arbace_genclass__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_genclass__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_genclass__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_genclass__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_genclass__init_A); return ok }

func A_arbace_genclass__init_A_Cast(x any) *A_arbace_genclass__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_genclass__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_genclass__init_A_class)) }; return v }
