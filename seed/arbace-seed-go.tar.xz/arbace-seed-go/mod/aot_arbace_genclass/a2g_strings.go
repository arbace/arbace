//line a2g_strings.ae:1
package aot_arbace_genclass

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("prim->class")

var Lit_3 *jrt.String = jrt.Intern("int")

var Lit_4 *jrt.String = jrt.Intern("byte")

var Lit_5 *jrt.String = jrt.Intern("floats")

var Lit_6 *jrt.String = jrt.Intern("char")

var Lit_7 *jrt.String = jrt.Intern("chars")

var Lit_8 *jrt.String = jrt.Intern("boolean")

var Lit_9 *jrt.String = jrt.Intern("void")

var Lit_10 *jrt.String = jrt.Intern("longs")

var Lit_11 *jrt.String = jrt.Intern("doubles")

var Lit_12 *jrt.String = jrt.Intern("float")

var Lit_13 *jrt.String = jrt.Intern("booleans")

var Lit_14 *jrt.String = jrt.Intern("shorts")

var Lit_15 *jrt.String = jrt.Intern("bytes")

var Lit_16 *jrt.String = jrt.Intern("double")

var Lit_17 *jrt.String = jrt.Intern("short")

var Lit_18 *jrt.String = jrt.Intern("long")

var Lit_19 *jrt.String = jrt.Intern("ints")

var Lit_20 *jrt.String = jrt.Intern("private")

var Lit_21 *jrt.String = jrt.Intern("line")

var Lit_22 *jrt.String = jrt.Intern("column")

var Lit_23 *jrt.String = jrt.Intern("file")

var Lit_24 *jrt.String = jrt.Intern("arbace/genclass.ae")

var Lit_25 *jrt.String = jrt.Intern("the-array-class")

var Lit_26 *jrt.String = jrt.Intern("arglists")

var Lit_27 *jrt.String = jrt.Intern("sym")

var Lit_28 *jrt.String = jrt.Intern("the-class")

var Lit_29 *jrt.String = jrt.Intern("tag")

var Lit_30 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_31 *jrt.String = jrt.Intern("x")

var Lit_32 *jrt.String = jrt.Intern("gen-class")

var Lit_33 *jrt.String = jrt.Intern("&")

var Lit_34 *jrt.String = jrt.Intern("options")

var Lit_35 *jrt.String = jrt.Intern("doc")

var Lit_36 *jrt.String = jrt.Intern("Clojure's gen-class generates the bytecode of a named class, for AOT compilation only: when\n  not compiling it does nothing. Arbace has no AOT compilation (no bytecode back end, B1-PLAN.md\n  D6; doc/STANDALONE-SURVEY.md D13): it does nothing, so that (ns ... (:gen-class)) loads.")

var Lit_37 *jrt.String = jrt.Intern("added")

var Lit_38 *jrt.String = jrt.Intern("1.0")

var Lit_39 *jrt.String = jrt.Intern("gen-interface")

var Lit_40 *jrt.String = jrt.Intern("Makes an interface with the given package-qualified :name, extending the :extends\n  interfaces, with the :methods [[name [param-types] return-type] ...]; in the Go build it is\n  made at run time (no class file is written), and evaluates to the interface.")

var Lit_41 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_42 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_43 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_44 *jrt.String = jrt.Intern("[F")

var Lit_45 *jrt.String = jrt.Intern("[C")

var Lit_46 *jrt.String = jrt.Intern("[J")

var Lit_47 *jrt.String = jrt.Intern("[D")

var Lit_48 *jrt.String = jrt.Intern("[Z")

var Lit_49 *jrt.String = jrt.Intern("[S")

var Lit_50 *jrt.String = jrt.Intern("[B")

var Lit_51 *jrt.String = jrt.Intern("[I")
