//line j2g_strings.ae:1
package aot_arbace_genclass

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn3,intyn4,byteyn6,floatsyn4,charyn5,charsyn7,booleanyn4,voidyn5,longsyn7,doublesyn5,floatyn8,booleansyn6,shortsyn5,bytesyn6,doubleyn5,shortyn4,longyn4,intskn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn3,symkn3,tagyn1,xyn6,Stringkn4,keysyn7,methodsyn5,Classyn15,invalid-method?yn5,mnameyn8,pclassesyn1,fkn3,docyn11,options-mapkn5,addedyn1,&yn7,optionsv11,arbace.core5,in-nsR0,v11,arbace.core11,prim->classR1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,R12,R13,R14,R15,R16,R17,m8,R18,TR19,i24,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core15,the-array-classm10,R18,TR22,L1,V1,R23,R19,i43,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core9,the-classm12,R24,C15,java.lang.ClassR18,TR22,L1,V1,R25,R19,i51,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core22,valid-java-method-namem10,R18,TR22,L1,V1,Myn1,sm2,R24,R26,R19,i87,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core31,validate-generate-class-optionsm10,R18,TR22,L1,V1,m2,R27,V1,R28,R19,i91,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core17,gc-filter-methodsm10,R18,TR22,L1,V2,Myn1,cm2,R24,R29,R30,R19,i96,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core22,gc-non-private-methodsm10,R18,TR22,L1,V1,Myn1,cm2,R24,R29,R19,i118,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core26,gc-protected-final-methodsm10,R18,TR22,L1,V1,Myn1,cm2,R24,R29,R19,i127,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core19,gc-instance-methodsm10,R18,TR22,L1,V1,Myn1,cm2,R24,R29,R19,i135,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core12,gc-ctor-sigsm10,R18,TR22,L1,V1,Myn5,superm2,R24,R29,R19,i140,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core20,gc-escape-class-namem10,R18,TR22,L1,V1,Myn1,cm2,R24,R29,R19,i145,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core16,gc-overload-namem10,R18,TR22,L1,V2,R31,R32,R19,i149,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core13,gc-find-fieldm12,R24,C23,java.lang.reflect.FieldR18,TR22,L1,V2,Myn1,cm2,R24,R29,R33,R19,i155,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core7,gc-typem12,R18,TR22,L1,V1,Myn1,cm2,R24,R29,R34,s147,The Java forms' type of class c (SPEC §4.3): a primitive's name, an array's element type\n  and dimensions (String/1), else the class's binary name.R19,i164,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core6,gc-tagm10,R18,TR22,L1,V2,R23,Myn1,cm2,R24,R29,R19,i175,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core8,gc-unboxm12,R18,TR22,L1,V2,R25,Myn6,rclassm2,R24,R29,R34,s146,The value x (an Object) as rclass, as ASM's GeneratorAdapter.unbox: a cast for a reference\n  type, the primitive's value of its wrapper otherwise.R19,i177,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core12,gc-load-implm12,R18,TR22,L1,V1,Myn7,impl-nsm2,R24,R26,R34,s176,The generated class's static initializer's load of its implementing namespace (Clojure's\n  Util.loadWithClass of its __init class): required when no lib of that name is loaded.R19,i188,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core14,generate-classm12,R18,TR22,L1,V1,R35,R34,s88,The Java form of the class gen-class's options-map describes (Clojure's generate-class).R19,i197,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core12,gen-class-nsm12,R18,TR22,L1,V0,R34,s281,The namespace gen-class's Java forms are evaluated in, arbace.genclass (arbace.core referred):\n  not the namespace of the gen-class form, which a class need not be imported into (Clojure's\n  gen-class imports nothing) and whose ns form calls gen-class before it refers arbace.core.R19,i381,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core10,gen-class*m12,R22,L1,V1,R35,R34,s450,Defines the class of gen-class's options-map (its :impl-ns the namespace that evaluated\n  gen-class) at run time, as a Java form, and answers it (doc/CLOJURE-DESIGN-REVIEW.md, CDR3).\n  A superclass the Go build's Java forms cannot extend (Compiler$CFGo/canExtend: Object, the\n  world's classes of arbace.j2g.dyn/sub-supers, an interpreted class) gives a class of that name\n  extending Object whose constructor throws, as a proxy of such a class does.R36,s6,arbaceR19,i391,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core9,gen-classm12,R22,L1,V2,R37,R38,R34,s1727,When compiling, generates compiled bytecode for a class with the\n  given package-qualified :name (which, as all names in these\n  parameters, can be a string or symbol), and writes the .class file\n  to the *compile-path* directory.  When not compiling, does\n  nothing. The gen-class construct contains no implementation, as the\n  implementation will be dynamically sought by the generated class in\n  functions in an implementing Clojure namespace. Given a generated\n  class org.mydomain.MyClass with a method named mymethod, gen-class\n  will generate an implementation that looks for a function named by\n  (str prefix mymethod) (default prefix: \"-\") in a\n  Clojure namespace specified by :impl-ns\n  (defaults to the current namespace). All inherited methods,\n  generated methods, and init and main functions (see :methods, :init,\n  and :main below) will be found similarly prefixed. By default, the\n  static initializer for the generated class will attempt to load the\n  Clojure support code for the class as a resource from the classpath,\n  e.g. in the example case, ``org/mydomain/MyClass__init.class``. This\n  behavior can be controlled by :load-impl-ns\n\n  Arbace writes no class files: the class is defined when the gen-class\n  form is evaluated, as a Java form, and its static initializer requires\n  the implementing namespace when it is not loaded (doc/CLOJURE-DESIGN-REVIEW.md,\n  CDR3). Its options are Clojure's: :name, :extends, :implements, :init,\n  :constructors, :post-init, :methods (^{:static true} for a static one),\n  :main, :factory, :state, :exposes, :exposes-methods, :prefix, :impl-ns\n  and :load-impl-ns (Clojure's docstring, genclass.clj). Note that methods\n  with a maximum of 18 parameters are supported.R36,s3,1.0R19,i425,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core8,gi-classm12,R18,TR22,L1,V1,R25,R34,s459,A type of gen-interface's (the-class): Clojure's generate-interface names it in the\n  interface's descriptors without loading it (asm-type), so a hint naming a class of the same\n  file by its namespace's spelling (clojure.test-clojure.genclass.examples.ArrayDefInterface,\n  definterface's class being clojure.test_clojure...) still makes the interface; the Go build\n  needs the Class, so such a name is resolved as munged (- to _), as definterface defines it.R19,i459,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core13,gen-interfacem12,R22,L1,V2,R37,R38,R34,s254,Makes an interface with the given package-qualified :name, extending the :extends\n  interfaces, with the :methods [[name [param-types] return-type] ...]; in the Go build it is\n  made at run time (no class file is written), and evaluates to the interface.R36,s3,1.0R19,i474,R20,i1,R21,s18,arbace/genclass.ae")

var Lit_1 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_2 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_3 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_4 *jrt.String = jrt.Intern("[F")

var Lit_5 *jrt.String = jrt.Intern("[C")

var Lit_6 *jrt.String = jrt.Intern("[J")

var Lit_7 *jrt.String = jrt.Intern("[D")

var Lit_8 *jrt.String = jrt.Intern("[Z")

var Lit_9 *jrt.String = jrt.Intern("[S")

var Lit_10 *jrt.String = jrt.Intern("[B")

var Lit_11 *jrt.String = jrt.Intern("[I")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$the_array_class")

var Lit_13 *jrt.String = jrt.Intern("arbace.core$the_class")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$valid_java_method_name")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$validate_generate_class_options")

var Lit_16 *jrt.String = jrt.Intern("arbace.core$gc_filter_methods")

var Lit_17 *jrt.String = jrt.Intern("arbace.core$gc_non_private_methods")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$gc_protected_final_methods")

var Lit_19 *jrt.String = jrt.Intern("arbace.core$gc_instance_methods")

var Lit_20 *jrt.String = jrt.Intern("arbace.core$gc_ctor_sigs")

var Lit_21 *jrt.String = jrt.Intern("arbace.core$gc_escape_class_name")

var Lit_22 *jrt.String = jrt.Intern("arbace.core$gc_overload_name")

var Lit_23 *jrt.String = jrt.Intern("arbace.core$gc_find_field")

var Lit_24 *jrt.String = jrt.Intern("arbace.core$gc_type")

var Lit_25 *jrt.String = jrt.Intern("arbace.core$gc_tag")

var Lit_26 *jrt.String = jrt.Intern("arbace.core$gc_unbox")

var Lit_27 *jrt.String = jrt.Intern("arbace.core$gc_load_impl")

var Lit_28 *jrt.String = jrt.Intern("arbace.core$generate_class")

var Lit_29 *jrt.String = jrt.Intern("arbace.core$gen_class_ns")

var Lit_30 *jrt.String = jrt.Intern("arbace.core$gen_class_STAR_")

var Lit_31 *jrt.String = jrt.Intern("arbace.core$gen_class")

var Lit_32 *jrt.String = jrt.Intern("arbace.core$gi_class")

var Lit_33 *jrt.String = jrt.Intern("arbace.core$gen_interface")
