//line j2g_strings.ae:1
package aot_arbace_genclass

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn3,intyn4,byteyn6,floatsyn4,charyn5,charsyn7,booleanyn4,voidyn5,longsyn7,doublesyn5,floatyn8,booleansyn6,shortsyn5,bytesyn6,doubleyn5,shortyn4,longyn4,intskn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn3,symkn3,tagyn1,xyn1,&yn7,optionskn3,dockn5,addedv11,arbace.core5,in-nsR0,v11,arbace.core11,prim->classR1,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,R12,R13,R14,R15,R16,R17,m8,R18,TR19,i23,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core15,the-array-classm10,R18,TR22,L1,V1,R23,R19,i42,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core9,the-classm12,R24,C15,java.lang.ClassR18,TR22,L1,V1,R25,R19,i50,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core9,gen-classm12,R22,L1,V2,R26,R27,R28,s279,Clojure's gen-class generates the bytecode of a named class, for AOT compilation only: when\n  not compiling it does nothing. Arbace has no AOT compilation (no bytecode back end, B1-PLAN.md\n  D6; doc/STANDALONE-SURVEY.md D13): it does nothing, so that (ns ... (:gen-class)) loads.R29,s3,1.0R19,i63,R20,i1,R21,s18,arbace/genclass.aev11,arbace.core13,gen-interfacem12,R22,L1,V2,R26,R27,R28,s254,Makes an interface with the given package-qualified :name, extending the :extends\n  interfaces, with the :methods [[name [param-types] return-type] ...]; in the Go build it is\n  made at run time (no class file is written), and evaluates to the interface.R29,s3,1.0R19,i71,R20,i1,R21,s18,arbace/genclass.ae")

var Lit_1 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_2 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_3 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_4 *jrt.String = jrt.Intern("[F")

var Lit_5 *jrt.String = jrt.Intern("[C")

var Lit_6 *jrt.String = jrt.Intern("[J")

var Lit_7 *jrt.String = jrt.Intern("[D")

var Lit_8 *jrt.String = jrt.Intern("[Z")

var Lit_9 *jrt.String = jrt.Intern("[S")

var Lit_10 *jrt.String = jrt.Intern("[B")

var Lit_11 *jrt.String = jrt.Intern("[I")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$the_array_class")

var Lit_13 *jrt.String = jrt.Intern("arbace.core$the_class")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$gen_class")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$gen_interface")
