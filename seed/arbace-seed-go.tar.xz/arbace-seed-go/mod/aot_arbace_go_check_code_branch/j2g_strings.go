//line j2g_strings.ae:1
package aot_arbace_go_check_code_branch

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn7,privatekn8,arglistsyn5,formskn3,dockn4,linekn6,columnkn4,fileyn4,bodyv11,arbace.core5,in-nsR0,v20,arbace.go.check.code12,branch-itemsm12,R1,TR2,L1,V1,R3,R4,s279,A statement list's items as gc sees them: a let's binding pairs are statements of the list\n  ([:var line name label?] for a variable declaration, [:decl label?] for a constant or a type),\n  its body the rest of the list; a let that is not last is a block of its own ([:block f]).R5,i7,R6,i1,R7,s30,arbace/go/check/code_branch.aev20,arbace.go.check.code15,check-branches!m10,R2,L1,V1,R8,R4,s77,gc's checks of labels and branch statements over a function body (its forms).R5,i34,R6,i1,R7,s30,arbace/go/check/code_branch.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$branch_items")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$check_branches_BANG_")
