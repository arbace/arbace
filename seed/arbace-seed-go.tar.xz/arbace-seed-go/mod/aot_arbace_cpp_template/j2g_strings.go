//line j2g_strings.ae:1
package aot_arbace_cpp_template

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn14,arbace.cpp.abikn2,asyn3,abiyn15,arbace.cpp.semayn4,semayn21,arbace.repr.cpp.typesyn2,ctyn13,arbace.stringyn3,stryn11,arbace.corekn3,dockn4,kindkn5,innerkn3,valkn4,tdepkn8,pack-expkn8,tparam-vkn5,texprkn5,tspeckn6,tparamkn4,elsekn1,kkn7,_tctextkn3,_tckn4,namekn8,templatekn4,typekn7,defaultkn8,qualTypekn2,tckn7,tc-argskn7,_tcargskn8,tc-formskn5,valuekn2,qtkn15,isParameterPackkn4,packkn7,tparamskn8,internalkn3,clskn8,extern-ckn1,ekn3,ttpkn1,ikn3,tidkn3,poskn2,tykn4,nttpkn5,elemskn4,tmplkn2,tkkn5,classkn2,idkn10,enumeratorkn4,declkn9,declconstkn4,nullkn1,xkn3,varkn1,ckn4,initkn9,def-scopekn1,okn2,srkn4,basekn5,scopekn4,argskn3,refkn2,opkn7,declvalkn2,tokn3,catkn2,lvkn4,rrefkn2,xvkn6,fieldskn1,nkn7,staticskn6,directkn3,fnskn4,varskn7,classeskn8,noexceptkn8,implicitkn9,defaultedkn4,copykn2,pskn6,tinitskn5,ctorskn2,ofkn5,baseskn4,dtorkn7,virtualkn5,unionkn4,purekn2,fnkn6,vtablekn1,vkn6,scopedkn1,bkn5,finalkn8,finishedyn11,pack-expandys3,cpp4,textkn5,traitkn5,typeskn5,nameskn4,boolkn3,idskn5,fieldks7,codegen7,refusedkn4,textkn3,numkn3,chrys3,cpp5,scopeyn8,templateyn2,<>kn5,mcallkn5,wbaseks19,arbace.cpp.template9,dependentks19,arbace.cpp.template5,targskn5,targskn7,typedefkn5,aliaskn7,conceptyn2,fnkn2,vtyn6,sizeofys3,cpp6,globalkn5,ttdepkn4,pathkn6,parentkn7,mangledkn3,retks2,cx9,sure-dropkn6,isPackkn7,dparamskn6,paramskn7,varpackkn7,writtenkn4,qualkn4,nonekn13,derived-classkn4,callkn2,cqkn2,vqkn4,refqkn4,mptrkn17,ignore-qualifierskn20,param-with-referencekn18,skip-non-dependentkn3,arrkn5,boundkn3,ptrkn2,vakn3,sigkn7,patternkn11,sig-pendingkn5,fnsetkn9,init-listkn5,tmplskn10,mptr-fnsetkn3,objkn14,referencedDeclkn4,exprkn4,atomkn4,deepkn6,opcodekn3,andkn2,orkn5,rangekn5,beginkn4,filekn6,offsetkn2,_bkn10,constraintkn22,trailingRequiresClauseks19,arbace.cpp.template7,unknownkn5,tinstkn5,guidekn9,inheritedkn4,userkn4,ctorkn9,ctor-tmplkn8,completekn8,definingkn5,outerkn7,tagUsedkn6,headerkn5,instskn18,completeDefinitionkn9,dep-baseskn5,waitskn6,remakekn4,bodykn4,nodekn4,lazykn6,inlinekn12,from-primarykn11,ool-pendingkn6,layoutkn12,from-partialkn8,partialskn3,oolks19,arbace.cpp.template4,nonekn5,formskn2,nxkn10,partial-tckn7,partialkn5,depthkn5,specskn9,templateskn12,pack-elementks2,cx4,nodeyn19,__type_pack_elementyn18,__make_integer_seqkn2,inkn2,nskn6,nestedkn6,pnameskn6,methodkn7,methodskn14,keep-def-scopekn5,initskn11,param-nameskn11,pending-defkn8,linkoncekn10,internal-lkn6,of-clskn10,init-stylekn9,ool-tmplsks19,arbace.cpp.template10,unresolvedkn8,defaultskn11,param-packsks2,cx16,constraint-falsekn6,accesskn4,convkn4,tsigkn2,tnkn1,qkn4,pidxkn5,declskn10,mangle-retkn25,isExplicitObjectParameterkn9,qualifiedkn10,targs-textkn11,targs-scopekn17,template-templatekn13,template-packkn10,sure-dropskn12,unsure-dropskn6,globalkn7,definedkn9,_targtextkn10,friend-clskn19,explicitlyDefaultedkn6,externkn11,spec-memberkn8,analyzedkn10,ctor-tmplskn6,_fnamekn5,_textkn6,_ftypekn8,explicitkn14,constraintExprkn14,requiresClausekn10,conv-tmplskn7,_externkn11,extern-instkn17,explicit-inst-defks19,arbace.cpp.template7,defaultkn16,class-constraintkn6,usingskn5,tbodykn19,out-of-line-defaultkn7,tassignkn5,sinitkn13,member-statickn5,ginitkn7,storagekn3,intkn2,prkn6,guideskn9,isVirtualkn13,writtenAccesskn11,ctad-n-userkn11,ctad-guideskn4,ctidkn10,pattern-ofkn2,mkkn8,trailingkn9,user-nodekn10,isBitfieldkn6,unsurekn3,strkn5,clrefkn5,plainkn4,aggrkn5,itemskn6,fscopekn6,resultkn12,deleted-sureks19,arbace.cpp.template6,unsurekn8,ctad-srckn12,ctad-inh-idskn4,ctadkn9,list-copykn11,list-directks19,arbace.cpp.template9,ambiguouskn5,blockv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.cpp.templatem2,R10,s1841,Templates for the code generator (doc/cpp/CODEGEN.md §G3): class and function templates declared, specialized and\n  instantiated on use. The native parser's tree keeps a template's pattern as it was written (clang's dependent\n  nodes as syntax: a type is its spelling, a name its identifier), so an instantiation is the pattern declared again\n  by arbace.cpp.sema in a scope that binds the template's parameters to its arguments -- what clang's TreeTransform\n  does by substitution, done here by re-analysis -- and a member's or a function template's definition is analyzed\n  only when the program uses it (clang's InstantiateFunctionDefinition on odr-use: `:lazy` until a round of analysis\n  references it). Deduction from a call ([temp.deduct.call]: P/A adjusted, then matched structurally as\n  DeduceTemplateArgumentsByTypeMatch does), explicit arguments, default arguments, non-type parameters, explicit\n  specializations of class and function templates, partial specializations of class templates chosen by deduction and\n  ordered as [temp.class.order] says, partial ordering of function templates ([temp.func.order],\n  [temp.deduct.partial]) and the overload tie-breaks of [over.match.best]/2.2-2.5; packs, alias and variable\n  templates, template template parameters, pointer and reference non-type parameters, members defined outside their\n  class (of the primary or of a partial specialization), explicit specializations of members, friends defined in\n  classes, two-phase lookup's dependent bases. The structure follows clang's\n  SemaTemplateDeduction.cpp, SemaTemplateInstantiate.cpp and SemaTemplateInstantiateDecl.cpp at llvmorg-23.1.4 (read\n  as the model; their functions' names are kept where the parts correspond; CODEGEN.md §G3 says what is ported and\n  what written). Refusals as in sema: {:codegen/refused :template ...}.v15,arbace.cpp.sema7,next-idv11,arbace.core5,applyv15,arbace.cpp.sema9,new-scopev15,arbace.cpp.sema6,enter!v11,arbace.core5,swap!v15,arbace.cpp.sema5,*fns*v11,arbace.core6,updatev15,arbace.cpp.sema6,*vars*v11,arbace.core6,filterv11,arbace.core4,map?R11,R12,v15,arbace.cpp.sema9,node-textv11,arbace.core9,contains?R13,v19,arbace.cpp.template7,*tmpls*S6,R14,R15,R16,R17,R18,R19,v11,arbace.core4,somev19,arbace.cpp.template10,dependent?v11,arbace.core4,valsv11,arbace.core11,sequential?R20,R21,v11,arbace.core3,vecv21,arbace.repr.cpp.types6,tokensR22,v19,arbace.cpp.template9,node-textv11,arbace.core4,peekR23,v11,arbace.core5,rangel0,v11,arbace.core5,firstv21,arbace.repr.cpp.types13,template-argsv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferS3,s20,TemplateTypeParmDecls23,NonTypeTemplateParmDecls24,TemplateTemplateParmDeclv11,arbace.core12,chunk-appendR24,R25,R26,R27,v19,arbace.cpp.template4,kidsv11,arbace.core6,removev11,arbace.core6,get-inV2,R26,R28,v11,arbace.core5,assocR29,R30,R31,R32,v19,arbace.cpp.template12,tc-arg-formsR33,R34,v13,arbace.string7,replaceV2,R26,R28,p10,\\s*\\.\\.\\.$R35,v13,arbace.string5,splitp1,=l2,v11,arbace.core4,subsv13,arbace.string13,last-index-ofl-1,v11,arbace.core7,re-findp6,\\.\\.\\.R36,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restS3,s20,TemplateTypeParmDecls23,NonTypeTemplateParmDecls24,TemplateTemplateParmDeclv11,arbace.core4,consV2,R26,R28,V2,R26,R28,v11,arbace.core4,restS4,s20,TemplateTypeParmDecls23,NonTypeTemplateParmDecls24,TemplateTemplateParmDecls16,TemplateArgumentv14,arbace.cpp.abi3,unqv15,arbace.cpp.sema12,resolve-typev19,arbace.cpp.template9,new-scopeR37,R38,R39,R40,v11,arbace.core11,map-indexedv11,arbace.core6,vectorv19,arbace.cpp.template6,enter!R41,R42,R43,R44,R45,R46,R19,R47,v19,arbace.cpp.template10,param-typev19,arbace.cpp.template10,arg-entityv11,arbace.core4,nextv11,arbace.core3,notR48,R49,R50,R51,R52,R53,R16,R54,R55,R56,R17,R57,v11,arbace.core7,number?v14,arbace.cpp.abi9,integral?v15,arbace.cpp.sema7,ce-wrapv15,arbace.cpp.sema6,lookupv15,arbace.cpp.sema16,lookup-qualifiedR58,v15,arbace.cpp.sema4,var*R59,R60,v19,arbace.cpp.template9,var-valuev15,arbace.cpp.sema9,const-intR61,v19,arbace.cpp.template4,failv13,arbace.string4,joinR62,R63,R64,v11,arbace.core3,mapv11,arbace.core6,secondv15,arbace.cpp.sema12,class-lookupR65,v14,arbace.cpp.abi3,clsv19,arbace.cpp.template12,const-entityv14,arbace.cpp.abi6,class?v11,arbace.core4,not=l1,v19,arbace.cpp.template4,u64?v11,arbace.core6,float?v19,arbace.cpp.template3,lngv11,arbace.core3,modv11,arbace.core6,bigintv19,arbace.cpp.template5,two64v11,arbace.core6,every?R66,v19,arbace.cpp.template6,falsy?v19,arbace.cpp.template3,dblS2,s1,%s1,/S2,s2,>>s2,<<v11,arbace.core2,<=l63,v19,arbace.cpp.template3,u64v11,arbace.core5,some?v11,arbace.core4,longv19,arbace.cpp.template10,binary-fnsv13,arbace.string12,starts-with?v13,arbace.string9,includes?S2,s4,chars11,signed charS2,s5,shorts12,signed shortS3,s3,ints10,signed ints6,signedS2,s12,unsigned ints8,unsignedR67,R68,R69,R70,R71,R72,R73,R74,R75,v14,arbace.cpp.abi4,ref?v14,arbace.cpp.abi3,fn?v14,arbace.cpp.abi5,void?v19,arbace.cpp.template14,*constructing*v14,arbace.cpp.abi4,arr?R76,v11,arbace.core6,empty?v19,arbace.cpp.template6,works?v15,arbace.cpp.sema8,init-forv19,arbace.cpp.template12,declval-nodev11,arbace.core4,mapvR77,v11,arbace.core4,atomR78,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapR79,R80,R81,v15,arbace.cpp.sema3,fndR82,R83,R84,v19,arbace.cpp.template9,walk-refsv19,arbace.cpp.template20,trait-constructible?v19,arbace.cpp.template14,calls-nothrow?v15,arbace.cpp.sema11,assign-nodev15,arbace.cpp.sema3,icsR85,v14,arbace.cpp.abi8,dynamic?R86,R87,R88,v19,arbace.cpp.template14,trivial-class?R89,v19,arbace.cpp.template18,trivially-default?R90,R91,R92,v15,arbace.cpp.sema13,trivial-dtor?R93,v19,arbace.cpp.template18,trait-convertible?v14,arbace.cpp.abi7,scalar?v15,arbace.cpp.sema13,trivial-copy?v14,arbace.cpp.abi5,mptr?v14,arbace.cpp.abi8,mfn-ptr?v19,arbace.cpp.template12,object-type?R94,R95,R96,v19,arbace.cpp.template17,trait-assignable?v14,arbace.cpp.abi9,floating?v14,arbace.cpp.abi9,int-ranksv14,arbace.cpp.abi2,bnv14,arbace.cpp.abi11,unsigned-nsv14,arbace.cpp.abi4,ptr?v14,arbace.cpp.abi5,enum?v19,arbace.cpp.template28,trait-nothrow-constructible?R97,v14,arbace.cpp.abi7,non-refv19,arbace.cpp.template25,trait-nothrow-assignable?R98,v14,arbace.cpp.abi3,enmv14,arbace.cpp.abi6,arith?R99,R100,v14,arbace.cpp.abi13,derived-from?R101,v19,arbace.cpp.template10,*unstable*v11,arbace.core6,reset!v14,arbace.cpp.abi12,empty-class?v15,arbace.cpp.sema10,aggregate?v14,arbace.cpp.abi3,ptrv14,arbace.cpp.abi4,lrefv14,arbace.cpp.abi4,rrefv19,arbace.cpp.template5,decayv14,arbace.cpp.abi10,underlyingv11,arbace.core6,dissocv13,arbace.string4,trimS4,c40,c91,c123,c60,S4,c41,c93,c125,c62,c44,v11,arbace.core3,strv19,arbace.cpp.template12,value-traitsv19,arbace.cpp.template11,type-traitsv11,arbace.core6,mapcatv11,arbace.core4,seq?R102,v19,arbace.cpp.template16,expand-type-packR103,v15,arbace.cpp.sema17,resolve-type-formv19,arbace.cpp.template10,trait-argsR104,R105,R14,R106,v19,arbace.cpp.template14,template-name?v11,arbace.core3,incv13,arbace.string10,lower-casev11,arbace.core10,re-matchesp33,(.*?)(bf16|f16|f32|f64|f128|f|l)?S2,s1,fs3,f32p7,[ulz]+$l16,l8,l10,p5,[01]+p6,[0-7]*p9,[0-9a-f]+p6,[0-9]+m36,s2,>>l8,s2,&&l2,s2,!=l6,s1,*l10,s1,%l10,s2,<=l7,s1,|l3,s1,/l10,s1,-l9,s2,>=l7,s1,&l5,s1,<l7,s2,<<l8,s2,||l1,s2,==l6,s1,^l4,s1,+l9,s1,>l7,v11,arbace.core6,subvecR107,v14,arbace.cpp.abi7,size-ofv14,arbace.cpp.abi7,signed?v11,arbace.core8,bit-testv19,arbace.cpp.template10,cast-typesv19,arbace.cpp.template7,cast-tov19,arbace.cpp.template4,foldS3,s10,const_casts11,static_casts16,reinterpret_castv19,arbace.cpp.template11,packs-namedR108,S2,R42,R47,p22,[A-Za-z_][A-Za-z_0-9]*S2,R109,R58,R109,v19,arbace.cpp.template11,trait-valuev13,arbace.string10,ends-with?v11,arbace.core4,listR102,v21,arbace.repr.cpp.types10,parse-typeR103,v19,arbace.cpp.template16,split-top-commasv15,arbace.cpp.sema11,*decltypes*p3,\\s+v15,arbace.cpp.sema7,analyzeR110,v11,arbace.core7,ex-datav11,arbace.core6,re-seqp12,[A-Za-z_]\\w*R111,R112,R113,v15,arbace.cpp.sema10,ce-call-fnv11,arbace.core4,lastv19,arbace.cpp.template24,qualified-template-name?v11,arbace.core3,popv19,arbace.cpp.template17,static-call-valuev21,arbace.repr.cpp.types10,parse-namev19,arbace.cpp.template10,const-formv19,arbace.cpp.template15,member-constantv11,arbace.core7,butlastv13,arbace.string8,index-ofv11,arbace.core10,not-every?R114,R115,R116,v11,arbace.core7,symbol?v11,arbace.core9,namespacev19,arbace.cpp.template17,written-qualifierR117,R118,v19,arbace.cpp.template4,tmplv19,arbace.cpp.template13,complete-argsv19,arbace.cpp.template12,resolve-argsv11,arbace.core7,ex-infoR119,R120,v19,arbace.cpp.template14,instantiate-fnv11,arbace.core5,nnextv11,arbace.core6,symbolv11,arbace.core4,nameR121,R122,R116,R123,v11,arbace.core6,concatp1,/R124,v11,arbace.core5,true?v11,arbace.core6,false?p1,/R114,R103,v19,arbace.cpp.template9,eval-textR125,v11,arbace.core7,vector?R116,R126,v19,arbace.cpp.template17,var-template-instv11,arbace.core6,pr-strR116,v19,arbace.cpp.template13,concept-namedv19,arbace.cpp.template18,concept-satisfied?R125,S2,R114,R116,R125,R125,R127,R125,R128,R114,R115,R129,R130,R103,p1,/S3,R26,R49,R42,R131,R103,S2,s7,nullptrs1,0V1,R56,p2,::R132,v14,arbace.cpp.abi10,mangle-varv14,arbace.cpp.abi11,source-nameR133,v14,arbace.cpp.abi9,mangle-fnv15,arbace.cpp.sema9,checking?p41,\\(\\s*([^()]+?)\\s*\\)\\s*&?\\s*([A-Za-z_]\\w*)v11,arbace.core8,not-any?m4,R110,R25,R134,Tv19,arbace.cpp.template15,template-arg-ofR103,v19,arbace.cpp.template8,decl-argv19,arbace.cpp.template9,value-argV2,R26,R28,V2,R26,R28,v11,arbace.core8,boolean?R135,v19,arbace.cpp.template8,node-argR136,R137,v19,arbace.cpp.template10,bind-scopev15,arbace.cpp.sema8,*cutoff*v19,arbace.cpp.template12,form-symbolsv11,arbace.core7,string?p22,[A-Za-z_][A-Za-z_0-9]*v11,arbace.core8,distinctS2,R36,R138,S2,R36,R138,R138,p1,/v19,arbace.cpp.template11,elementwiseR15,p22,[A-Za-z_][A-Za-z_0-9]*R102,v19,arbace.cpp.template11,resolve-argv11,arbace.core4,intov11,arbace.core4,takev11,arbace.core4,dropS3,R16,R42,R19,v19,arbace.cpp.template6,arr-cvv19,arbace.cpp.template9,unq-arrayv19,arbace.cpp.template10,with-qualsv19,arbace.cpp.template5,qualsS2,R16,R19,v11,arbace.core11,select-keysV4,R21,R43,R59,R97,v19,arbace.cpp.template9,canonicalv19,arbace.cpp.template9,unspelledR139,R140,v19,arbace.cpp.template8,*unsure*v19,arbace.cpp.template6,*sure*v19,arbace.cpp.template9,same-arg?v19,arbace.cpp.template11,subst-valueS3,R16,R42,R19,v11,arbace.core8,tree-seqv11,arbace.core5,coll?v19,arbace.cpp.template10,tparam-of?v19,arbace.cpp.template9,bind-arg!v19,arbace.cpp.template13,dependent-on?v19,arbace.cpp.template10,match-argsv19,arbace.cpp.template20,deduce-by-type-matchR141,S2,R16,R19,v19,arbace.cpp.template13,pack-pattern?v19,arbace.cpp.template9,match-argv11,arbace.core4,keepR18,R142,R143,v19,arbace.cpp.template25,inconsistent-or-superset?v11,arbace.core3,setR144,R145,R146,v19,arbace.cpp.template5,sure!R147,S1,R148,v19,arbace.cpp.template7,unsure!R149,R148,R150,R151,S1,R148,R152,R153,S2,R148,R142,v19,arbace.cpp.template20,deduce-template-specR154,R155,v15,arbace.cpp.sema13,fn-type-scopev19,arbace.cpp.template9,sym-scopeR156,V2,R26,R28,v19,arbace.cpp.template9,upd-tmpl!R157,v11,arbace.core6,reduceR114,R116,R158,R159,v19,arbace.cpp.template21,forwarding-reference?S1,R150,v19,arbace.cpp.template19,simple-template-id?S3,R16,R42,R19,S3,R16,R42,R19,v19,arbace.cpp.template7,sym-sigv11,arbace.core4,keysv19,arbace.cpp.template10,tparams-inv19,arbace.cpp.template17,deducible-tparamsR160,R161,v19,arbace.cpp.template20,adjust-for-deductionv15,arbace.cpp.sema12,mptr-fn-nodeR162,v19,arbace.cpp.template16,finish-deductionV2,R163,R24,v15,arbace.cpp.sema13,ref-qualifierv19,arbace.cpp.template13,explicit-argsv15,arbace.cpp.sema13,written-targsS2,s9,ParenExprs16,ExprWithCleanupsv19,arbace.cpp.template11,normal-formS2,s2,&&s2,||v19,arbace.cpp.template11,concept-refR164,R165,R166,R167,R168,R169,V3,R170,R171,R172,V3,R170,R171,R173,R174,v19,arbace.cpp.template10,concept-ofR175,R176,v11,arbace.core4,nil?v19,arbace.cpp.template3,dnfv19,arbace.cpp.template3,cnfv19,arbace.cpp.template22,associated-constraintsR177,v19,arbace.cpp.template9,subsumes?v11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core6,repeatv19,arbace.cpp.template24,at-least-as-specialized?v11,arbace.core4,juxtv19,arbace.cpp.template20,more-constrained-fn?R178,R179,R180,R181,R182,R183,v19,arbace.cpp.template20,more-specialized-fn?v19,arbace.cpp.template7,next-idv15,arbace.cpp.sema5,*ids*R184,R185,v14,arbace.cpp.abi9,*classes*R186,R187,R188,v15,arbace.cpp.sema12,header-node?v11,arbace.core8,assoc-inR189,R190,v19,arbace.cpp.template11,attach-ool!v14,arbace.cpp.abi11,update-cls!R191,v11,arbace.core12,keep-indexedV2,R26,R28,v15,arbace.cpp.sema10,drop-countv15,arbace.cpp.sema13,declare-node!v19,arbace.cpp.template17,strip-tparam-kidsv19,arbace.cpp.template13,*provisional*v11,arbace.core9,update-inR192,v11,arbace.core4,fnilR193,v19,arbace.cpp.template10,*instance*R194,R195,v19,arbace.cpp.template7,upd-fn!R196,R197,v19,arbace.cpp.template17,name-pack-params!R198,v19,arbace.cpp.template17,declare-instance!R199,v11,arbace.core9,reduce-kvR200,v11,arbace.core4,disjR201,R202,R203,v19,arbace.cpp.template11,attach-one!v19,arbace.cpp.template14,*satisfaction*R204,v19,arbace.cpp.template27,type-constraints-satisfied?v15,arbace.cpp.sema21,constraint-satisfied?R205,v19,arbace.cpp.template12,partial-argsv15,arbace.cpp.sema17,*decltype-failed*R206,v14,arbace.cpp.abi5,bool*R207,R208,v19,arbace.cpp.template19,partial-constraintsv19,arbace.cpp.template25,more-constrained-partial?v19,arbace.cpp.template12,*inst-depth*v19,arbace.cpp.template18,instantiate-class*m2,R110,R209,R210,v15,arbace.cpp.sema12,*main-retry*v15,arbace.cpp.sema15,*incomplete-ok*v19,arbace.cpp.template20,incomplete-instance!v19,arbace.cpp.template16,select-instance!v15,arbace.cpp.sema5,tick!m2,R110,R209,v19,arbace.cpp.template13,partial-matchv19,arbace.cpp.template25,more-specialized-partial?R211,v19,arbace.cpp.template13,drop-layouts!v11,arbace.core4,sortv19,arbace.cpp.template18,complete-instance!S2,R123,R51,m2,R110,R212,v19,arbace.cpp.template12,*alias-node*R213,v11,arbace.core8,integer?V2,R26,R28,v19,arbace.cpp.template17,instantiate-classR214,v19,arbace.cpp.template17,type-pack-elementR215,v19,arbace.cpp.template16,make-integer-seqp1,/v19,arbace.cpp.template14,tmpl-of-entityv11,arbace.core10,take-whileR103,R102,v14,arbace.cpp.abi4,int*V2,R26,R28,R216,S2,R123,R51,R170,S2,s1,,s1,>S10,s3,ints5,classs6,signeds4,longs5,shorts4,bools4,chars5,consts8,unsigneds8,typenameS3,s1,(s1,<s1,[S3,s1,]s1,)s1,>v19,arbace.cpp.template13,ool-qualifierv15,arbace.cpp.sema16,text-before-namep5,~\\s*$p33,::\\s*([A-Za-z_][A-Za-z_0-9]*)\\s*$c62,c60,p28,([A-Za-z_][A-Za-z_0-9]*)\\s*$p38,((?:[A-Za-z_][A-Za-z_0-9]*\\s*::\\s*)*)$p2,\\sp65,\\b(?:class|struct|union)\\s+((?:[A-Za-z_][A-Za-z_0-9]*\\s*::\\s*)+)$v13,arbace.string6,blank?p2,::S2,R217,R26,R217,v14,arbace.cpp.abi6,cls-ofp55,^((?:[A-Za-z_][A-Za-z_0-9]*::)+)[A-Za-z_][A-Za-z_0-9]*<p2,::R218,R219,R220,V2,R26,R28,p18,\\)\\s*const(\\s|$|&)S2,R182,R91,R221,v15,arbace.cpp.sema7,body-ofR222,R223,R224,v19,arbace.cpp.template8,upd-var!R225,R226,R227,R228,R229,R230,v19,arbace.cpp.template23,attach-member-template!v15,arbace.cpp.sema18,*constraint-doubt*V3,R185,R101,R184,v15,arbace.cpp.sema6,doubt!R231,p10,\\.\\.\\.\\s*$V2,R26,R28,R232,R233,V2,R64,R24,R234,v15,arbace.cpp.sema11,declare-fn!v19,arbace.cpp.template16,decltype-failed?v15,arbace.cpp.sema9,*no-user*R235,R236,R237,R238,v19,arbace.cpp.template8,tn-typesR239,R240,R209,v19,arbace.cpp.template14,template-depthR241,R242,v15,arbace.cpp.sema11,adl-classesv15,arbace.cpp.sema15,friend-visible?v15,arbace.cpp.sema9,own-namesv15,arbace.cpp.sema13,adl-class-nssp14,Expr$|Literal$R243,p6,\\.\\.\\.V2,R26,R28,R244,v19,arbace.cpp.template13,adl-templatesv15,arbace.cpp.sema4,*at*v19,arbace.cpp.template13,too-few-args?R245,R246,v19,arbace.cpp.template11,deduce-callS2,R247,R248,R134,S2,R247,R248,v11,arbace.core9,with-metaR249,R250,V2,R26,R28,v19,arbace.cpp.template11,deduce-typeV2,R26,R28,v15,arbace.cpp.sema12,declare-var!R251,R252,S3,s5,classs5,unions6,structS3,s5,classs5,unions6,structR253,V2,R26,R28,V2,R26,R28,v19,arbace.cpp.template7,tparamsR254,R255,v15,arbace.cpp.sema9,same-sig?v19,arbace.cpp.template7,friend!R28,V2,R26,R28,p10,^\\s*auto\\bR256,V2,R26,R28,p18,\\)\\s*const(\\s|$|&)S2,R182,R91,R257,R258,S4,s12,FunctionDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclR259,V2,R26,R28,v11,arbace.core10,re-patternp3,\\s+V2,R26,R28,S4,s12,FunctionDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclp20,^\\s*template\\s*<\\s*>v19,arbace.cpp.template18,ool-class-templatev19,arbace.cpp.template13,header-paramsR260,R261,v11,arbace.core10,re-matcherR262,v15,arbace.cpp.sema7,*order*p3,\\s+S2,s12,FunctionDecls13,CXXMethodDeclp20,^\\s*template\\s*<\\s*>v19,arbace.cpp.template14,ool-class-namev15,arbace.cpp.sema16,qualifier-beforev19,arbace.cpp.template17,explicit-fn-spec!p25,^\\s*template\\s*<\\s*[^>\\s]R116,p39,^\\s*template\\s*<\\s*>\\s*template\\s*<\\s*>p31,^\\s*template\\s*<\\s*>\\s*templatep20,^\\s*template\\s*<\\s*>v19,arbace.cpp.template13,var-text-argsp20,^\\s*template\\s*<\\s*>v19,arbace.cpp.template21,explicit-member-spec!S2,s12,FunctionDecls13,CXXMethodDeclv19,arbace.cpp.template11,user-guide!R263,S2,s12,FunctionDecls13,CXXMethodDeclS2,s12,FunctionDecls13,CXXMethodDeclR264,S4,s12,FunctionDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclv19,arbace.cpp.template20,ool-member-template!S4,s12,FunctionDecls13,CXXMethodDecls18,CXXConstructorDecls17,CXXConversionDeclS2,R217,R26,V2,R26,R28,v19,arbace.cpp.template19,constraint-spellingR265,V2,R26,R28,p3,\\s+v15,arbace.cpp.sema15,*member-access*R266,v19,arbace.cpp.template15,class-key-scopev19,arbace.cpp.template18,template-text-argsR267,v19,arbace.cpp.template26,explicit-fn-instantiation!p34,(?s)\\s*(?:class|struct)\\s+(.*?)\\s*R268,p40,(?s)\\s*(?:class|struct|union)\\s+(.*?)\\s*R269,v19,arbace.cpp.template12,fnaddr-specsS2,s12,FunctionDecls13,CXXMethodDeclR270,S2,s7,VarDecls13,TypeAliasDeclv19,arbace.cpp.template19,incomplete-waiting?S2,s7,VarDecls13,TypeAliasDeclv19,arbace.cpp.template13,find-templatev19,arbace.cpp.template17,template-defined!v19,arbace.cpp.template15,inherit-defaultR271,S6,R131,R65,R195,R61,R272,R106,S6,R131,R65,R195,R61,R272,R106,v19,arbace.cpp.template13,class-closurev15,arbace.cpp.sema12,dtor-deallocR273,v19,arbace.cpp.template9,*scanned*R274,R275,R276,S2,R277,R251,R278,R279,S2,R277,R251,v19,arbace.cpp.template13,extern-class?R280,R281,p28,^<deduction guide for (.*)>$p43,(?<![A-Za-z0-9_$])explicit(?![A-Za-z0-9_$])p26,explicit\\s*\\(\\s*false\\s*\\)v19,arbace.cpp.template16,guide-class-nameS2,R123,R51,R282,v19,arbace.cpp.template15,explicit-guide?S2,s11,TypedefDecls13,TypeAliasDeclS2,s11,TypedefDecls13,TypeAliasDeclV2,R26,R28,V2,R26,R28,v19,arbace.cpp.template10,ctor-nodesR283,R284,R285,R286,R287,v19,arbace.cpp.template11,guide-scopeR288,R289,V2,R26,R28,v19,arbace.cpp.template14,param-defaultsR290,V2,R26,R28,v19,arbace.cpp.template9,self-textv14,arbace.cpp.abi4,voidV1,nV2,R26,R28,R291,V2,R26,R28,V2,R26,R28,R292,V2,R26,R28,p28,\\.\\.\\.|\\(anonymous|\\(unnamedR293,l-2,R294,R295,R296,S1,R293,R297,v19,arbace.cpp.template15,class-and-basesv11,arbace.core9,take-lastR298,R299,R300,R301,V1,V2,R217,s3,stdV2,R26,R28,R302,V2,R26,R28,v19,arbace.cpp.template15,alias-deduciblev19,arbace.cpp.template17,guide-ret-patternv19,arbace.cpp.template15,deduce-from-rhsV2,R26,R28,v19,arbace.cpp.template10,entity-argR303,v19,arbace.cpp.template12,alias-resultv19,arbace.cpp.template11,alias-guideS2,s9,UsingDecls24,UnresolvedUsingValueDeclp42,(\\w+)\\s*(?:<[^;]*>)?\\s*::\\s*(\\w+)\\s*;?\\s*$V2,R26,R28,p36,^\\s*(?:::)?(?:\\w+::)*(\\w+)\\s*(?:<|$)R304,v19,arbace.cpp.template9,alias-rhsv19,arbace.cpp.template12,class-guidesv15,arbace.cpp.sema10,*cxx-year*R305,v15,arbace.cpp.sema17,*pedantic-errors*S2,R306,R307,v19,arbace.cpp.template12,alias-guidesv19,arbace.cpp.template16,inherited-guidesS2,s9,UsingDecls24,UnresolvedUsingValueDeclp42,(\\w+)\\s*(?:<[^;]*>)?\\s*::\\s*(\\w+)\\s*;?\\s*$m4,R249,l0,R250,l0,v19,arbace.cpp.template14,guide-min-argsv19,arbace.cpp.template20,init-list-guide-elemv19,arbace.cpp.template16,guide-candidate!v19,arbace.cpp.template18,aggregate-pattern?v19,arbace.cpp.template15,aggregate-guidev15,arbace.cpp.sema16,resolve-overloadv15,arbace.cpp.sema7,*drops*p34,^codegen: no viable function amongp24,^codegen: ambiguous callR308,p28,^codegen: no viable functionv11,arbace.core8,keyword?R306,v19,arbace.cpp.template12,*conv-specs*v19,arbace.cpp.template11,deduce-convv19,arbace.cpp.template15,call-candidatesS3,R14,R18,R19,v19,arbace.cpp.template10,trait-typep77,(?s)\\s*((?:[A-Za-z_][A-Za-z_0-9]*::)*[A-Za-z_][A-Za-z_0-9]*)\\s*(?:<(.*)>)?\\s*p2,::R309,v19,arbace.cpp.template16,class-completed!")

var Lit_1 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712")

var Lit_2 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713")

var Lit_3 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$fn__960001714")

var Lit_4 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716")

var Lit_5 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716$fn__960001717")

var Lit_6 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716$fn__960001717$iter__960001708__960001718")

var Lit_7 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716$fn__960001717$fn__960001724")

var Lit_8 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716$fn__960001717$iter__960001708__960001718$fn__960001719")

var Lit_9 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates$iter__960001704__960001712$fn__960001713$iter__960001706__960001716$fn__960001717$iter__960001708__960001718$fn__960001719$fn__960001720")

var Lit_10 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$fn__960002602")

var Lit_11 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$fn__960002604")

var Lit_12 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$fn__960002607")

var Lit_13 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$iter__960002612__960002616")

var Lit_14 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$fn__960002638")

var Lit_15 *jrt.String = jrt.Intern("FieldDecl")

var Lit_16 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$fn__960002638$fn__960002639")

var Lit_17 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$iter__960002612__960002616$fn__960002617")

var Lit_18 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$iter__960002612__960002616$fn__960002617$fn__960002618")

var Lit_19 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$iter__960002612__960002616$fn__960002617$fn__960002634")

var Lit_20 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide$iter__960002612__960002616$fn__960002617$fn__960002618$fn__960002625")

var Lit_21 *jrt.String = jrt.Intern("class")

var Lit_22 *jrt.String = jrt.Intern("private")

var Lit_23 *jrt.String = jrt.Intern("public")

var Lit_24 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_pattern_QMARK_$fn__960002549")

var Lit_25 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_pattern_QMARK_$fn__960002551")

var Lit_26 *jrt.String = jrt.Intern("AccessSpecDecl")

var Lit_27 *jrt.String = jrt.Intern("CXXMethodDecl")

var Lit_28 *jrt.String = jrt.Intern("none")

var Lit_29 *jrt.String = jrt.Intern("arbace.cpp.template$alias_deducible$fn__960002679")

var Lit_30 *jrt.String = jrt.Intern("arbace.cpp.template$alias_deducible$fn__960002681")

var Lit_31 *jrt.String = jrt.Intern("arbace.cpp.template$alias_deducible$fn__960002683")

var Lit_32 *jrt.String = jrt.Intern("arbace.cpp.template$alias_deducible$fn__960002685")

var Lit_33 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002715")

var Lit_34 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002717")

var Lit_35 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002719")

var Lit_36 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002721")

var Lit_37 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002723__960002727")

var Lit_38 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002733__960002737")

var Lit_39 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002743__960002747")

var Lit_40 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002753__960002757")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002763")

var Lit_42 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765")

var Lit_43 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002802")

var Lit_44 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002804")

var Lit_45 *jrt.String = jrt.Intern("CPP_TMPL_TRACE")

var Lit_46 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fn__960002804$fn__960002805")

var Lit_47 *jrt.String = jrt.Intern("alias guide")

var Lit_48 *jrt.String = jrt.Intern("not built:")

var Lit_49 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$ent__960002766")

var Lit_50 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002768__960002772")

var Lit_51 *jrt.String = jrt.Intern("ctad: an alias guide's substitution")

var Lit_52 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002790__960002794")

var Lit_53 *jrt.String = jrt.Intern("ctad: an alias guide's parameter ")

var Lit_54 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002768__960002772$fn__960002773")

var Lit_55 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002768__960002772$fn__960002773$fn__960002774")

var Lit_56 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002790__960002794$fn__960002795")

var Lit_57 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$fscope__960002765$iter__960002790__960002794$fn__960002795$fn__960002796")

var Lit_58 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002723__960002727$fn__960002728")

var Lit_59 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002723__960002727$fn__960002728$fn__960002729")

var Lit_60 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002733__960002737$fn__960002738")

var Lit_61 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002733__960002737$fn__960002738$fn__960002739")

var Lit_62 *jrt.String = jrt.Intern("__arbace_f")

var Lit_63 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002743__960002747$fn__960002748")

var Lit_64 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002743__960002747$fn__960002748$fn__960002749")

var Lit_65 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002753__960002757$fn__960002758")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide$iter__960002753__960002757$fn__960002758$fn__960002759")

var Lit_67 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guides$fn__960002814")

var Lit_68 *jrt.String = jrt.Intern("arbace.cpp.template$alias_result$fn__960002710")

var Lit_69 *jrt.String = jrt.Intern("arbace.cpp.template$alias_rhs$fn__960002670")

var Lit_70 *jrt.String = jrt.Intern("arbace.cpp.template$associated_constraints$iter__960001137__960001141")

var Lit_71 *jrt.String = jrt.Intern("arbace.cpp.template$associated_constraints$fn__960001153")

var Lit_72 *jrt.String = jrt.Intern("arbace.cpp.template$associated_constraints$iter__960001137__960001141$fn__960001142")

var Lit_73 *jrt.String = jrt.Intern("arbace.cpp.template$associated_constraints$iter__960001137__960001141$fn__960001142$fn__960001143")

var Lit_74 *jrt.String = jrt.Intern("arbace.cpp.template$at_least_as_specialized_QMARK_$fn__960001116")

var Lit_75 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$fn__960001891")

var Lit_76 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$fn__960001893")

var Lit_77 *jrt.String = jrt.Intern("CXXConstructorDecl")

var Lit_78 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$iter__960001895__960001899")

var Lit_79 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$norm__960001905")

var Lit_80 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$fn__960001913")

var Lit_81 *jrt.String = jrt.Intern("no member template ")

var Lit_82 *jrt.String = jrt.Intern(" to define")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$fn__960001915")

var Lit_84 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$iter__960001895__960001899$fn__960001900")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$iter__960001895__960001899$fn__960001900$fn__960001901")

var Lit_86 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_$norm__960001905$fn__960001907")

var Lit_87 *jrt.String = jrt.Intern(" ")

var Lit_88 *jrt.String = jrt.Intern("\\b")

var Lit_89 *jrt.String = jrt.Intern("#P")

var Lit_90 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$nested_id__960001542")

var Lit_91 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001546")

var Lit_92 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001548")

var Lit_93 *jrt.String = jrt.Intern("no member class ")

var Lit_94 *jrt.String = jrt.Intern(" of ")

var Lit_95 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001551")

var Lit_96 *jrt.String = jrt.Intern("CXXDestructorDecl")

var Lit_97 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001564")

var Lit_98 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001566")

var Lit_99 *jrt.String = jrt.Intern("no member ")

var Lit_100 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001568")

var Lit_101 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001570")

var Lit_102 *jrt.String = jrt.Intern("no static member ")

var Lit_103 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$fn__960001572")

var Lit_104 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_105 *jrt.String = jrt.Intern("CXXRecordDecl")

var Lit_106 *jrt.String = jrt.Intern("ParmVarDecl")

var Lit_107 *jrt.String = jrt.Intern("CXXCtorInitializer")

var Lit_108 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_$nested_id__960001542$fn__960001543")

var Lit_109 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$fn__960001753")

var Lit_110 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759")

var Lit_111 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760")

var Lit_112 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760$fn__960001761")

var Lit_113 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760$fn__960001769")

var Lit_114 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760$fn__960001761$fn__960001763")

var Lit_115 *jrt.String = jrt.Intern("template")

var Lit_116 *jrt.String = jrt.Intern("does not deduce from")

var Lit_117 *jrt.String = jrt.Intern("explicit")

var Lit_118 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760$fn__960001761$fn__960001763$fn__960001764")

var Lit_119 *jrt.String = jrt.Intern("drops out:")

var Lit_120 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates$iter__960001755__960001759$fn__960001760$fn__960001769$fn__960001770")

var Lit_121 *jrt.String = jrt.Intern("arbace.cpp.template$calls_nothrow_QMARK_$fn__960000161")

var Lit_122 *jrt.String = jrt.Intern("arbace.cpp.template$canonical$fn__960000906")

var Lit_123 *jrt.String = jrt.Intern("cast")

var Lit_124 *jrt.String = jrt.Intern("bool")

var Lit_125 *jrt.String = jrt.Intern("float")

var Lit_126 *jrt.String = jrt.Intern("double")

var Lit_127 *jrt.String = jrt.Intern("unsigned char")

var Lit_128 *jrt.String = jrt.Intern("unsigned short")

var Lit_129 *jrt.String = jrt.Intern("__int128")

var Lit_130 *jrt.String = jrt.Intern("a constant of type ")

var Lit_131 *jrt.String = jrt.Intern("unsigned")

var Lit_132 *jrt.String = jrt.Intern("arbace.cpp.template$class_and_bases$fn__960002645")

var Lit_133 *jrt.String = jrt.Intern("arbace.cpp.template$class_closure$fn__960002423")

var Lit_134 *jrt.String = jrt.Intern("arbace.cpp.template$class_closure$fn__960002423$fn__960002424")

var Lit_135 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001271")

var Lit_136 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001278")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001286")

var Lit_138 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001306")

var Lit_139 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001311")

var Lit_140 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001317")

var Lit_141 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001322")

var Lit_142 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001330")

var Lit_143 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001350")

var Lit_144 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001355")

var Lit_145 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001361")

var Lit_146 *jrt.String = jrt.Intern("class completed")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001286$fn__960001287")

var Lit_148 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001286$fn__960001287$iter__960001288__960001292")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001286$fn__960001287$iter__960001288__960001292$fn__960001293")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001286$fn__960001287$iter__960001288__960001292$fn__960001293$fn__960001294")

var Lit_151 *jrt.String = jrt.Intern("provisional instance")

var Lit_152 *jrt.String = jrt.Intern("made again")

var Lit_153 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001317$fn__960001318")

var Lit_154 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001330$fn__960001331")

var Lit_155 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001330$fn__960001331$iter__960001332__960001336")

var Lit_156 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001330$fn__960001331$iter__960001332__960001336$fn__960001337")

var Lit_157 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001330$fn__960001331$iter__960001332__960001336$fn__960001337$fn__960001338")

var Lit_158 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_$fn__960001361$fn__960001362")

var Lit_159 *jrt.String = jrt.Intern("<deduction guide for ")

var Lit_160 *jrt.String = jrt.Intern(">")

var Lit_161 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$reg_BANG___960002555")

var Lit_162 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002561__960002565")

var Lit_163 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$fn__960002581")

var Lit_164 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$fn__960002583")

var Lit_165 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002585__960002589")

var Lit_166 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$fn__960002599")

var Lit_167 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002561__960002565$fn__960002566")

var Lit_168 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002561__960002565$fn__960002566$fn__960002567")

var Lit_169 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002561__960002565$fn__960002566$fn__960002577")

var Lit_170 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002561__960002565$fn__960002566$fn__960002567$fn__960002571")

var Lit_171 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002585__960002589$fn__960002590")

var Lit_172 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002585__960002589$fn__960002590$fn__960002591")

var Lit_173 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002585__960002589$fn__960002590$fn__960002595")

var Lit_174 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$iter__960002585__960002589$fn__960002590$fn__960002591$fn__960002592")

var Lit_175 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$reg_BANG___960002555$fn__960002556")

var Lit_176 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides$reg_BANG___960002555$fn__960002556$fn__960002557")

var Lit_177 *jrt.String = jrt.Intern("guide")

var Lit_178 *jrt.String = jrt.Intern("arbace.cpp.template$class_key_scope$fn__960001518")

var Lit_179 *jrt.String = jrt.Intern("arbace.cpp.template$cnf$iter__960001175__960001181")

var Lit_180 *jrt.String = jrt.Intern("arbace.cpp.template$cnf$iter__960001175__960001181$fn__960001182")

var Lit_181 *jrt.String = jrt.Intern("arbace.cpp.template$cnf$iter__960001175__960001181$fn__960001182$iter__960001177__960001183")

var Lit_182 *jrt.String = jrt.Intern("arbace.cpp.template$cnf$iter__960001175__960001181$fn__960001182$iter__960001177__960001183$fn__960001184")

var Lit_183 *jrt.String = jrt.Intern("arbace.cpp.template$cnf$iter__960001175__960001181$fn__960001182$iter__960001177__960001183$fn__960001184$fn__960001185")

var Lit_184 *jrt.String = jrt.Intern("arbace.cpp.template$complete_args$fn__960000823")

var Lit_185 *jrt.String = jrt.Intern("arbace.cpp.template$complete_args$fn__960000823$fn__960000824")

var Lit_186 *jrt.String = jrt.Intern("arbace.cpp.template$complete_instance_BANG_$fn__960001444")

var Lit_187 *jrt.String = jrt.Intern("arbace.cpp.template$complete_instance_BANG_$fn__960001446")

var Lit_188 *jrt.String = jrt.Intern("incomplete instance")

var Lit_189 *jrt.String = jrt.Intern("completed")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.template$concept_named$fn__960000755")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.template$concept_named$fn__960000757")

var Lit_192 *jrt.String = jrt.Intern("arbace.cpp.template$concept_of$fn__960001586")

var Lit_193 *jrt.String = jrt.Intern("arbace.cpp.template$concept_of$fn__960001588")

var Lit_194 *jrt.String = jrt.Intern("DeclRefExpr")

var Lit_195 *jrt.String = jrt.Intern("arbace.cpp.template$concept_ref$fn__960001124")

var Lit_196 *jrt.String = jrt.Intern("arbace.cpp.template$concept_ref$fn__960001126")

var Lit_197 *jrt.String = jrt.Intern("arbace.cpp.template$concept_ref$fn__960001128")

var Lit_198 *jrt.String = jrt.Intern("arbace.cpp.template$concept_ref$fn__960001130")

var Lit_199 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$fn__960001597")

var Lit_200 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$eval1__960001602")

var Lit_201 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$fn__960001608")

var Lit_202 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$fn__960001610")

var Lit_203 *jrt.String = jrt.Intern("CPP_CONCEPT_TRACE")

var Lit_204 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$fn__960001613")

var Lit_205 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$eval1__960001602$fn__960001603")

var Lit_206 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$eval1__960001602$fn__960001605")

var Lit_207 *jrt.String = jrt.Intern("enter concept")

var Lit_208 *jrt.String = jrt.Intern("concept")

var Lit_209 *jrt.String = jrt.Intern("=>")

var Lit_210 *jrt.String = jrt.Intern("(doubt)")

var Lit_211 *jrt.String = jrt.Intern("")

var Lit_212 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_$fn__960001613$fn__960001614")

var Lit_213 *jrt.String = jrt.Intern("not a constant: ")

var Lit_214 *jrt.String = jrt.Intern("::")

var Lit_215 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000766")

var Lit_216 *jrt.String = jrt.Intern("/")

var Lit_217 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000768")

var Lit_218 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000770")

var Lit_219 *jrt.String = jrt.Intern("the template arguments of ")

var Lit_220 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000772")

var Lit_221 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000774")

var Lit_222 *jrt.String = jrt.Intern("arbace.cpp.template$const_form$fn__960000776")

var Lit_223 *jrt.String = jrt.Intern("constant call ")

var Lit_224 *jrt.String = jrt.Intern("sizeof")

var Lit_225 *jrt.String = jrt.Intern("constant ")

var Lit_226 *jrt.String = jrt.Intern(" | ")

var Lit_227 *jrt.String = jrt.Intern("arbace.cpp.template$constraint_spelling$fn__960001955")

var Lit_228 *jrt.String = jrt.Intern("(?<![A-Za-z0-9_])")

var Lit_229 *jrt.String = jrt.Intern("(?![A-Za-z0-9_])")

var Lit_230 *jrt.String = jrt.Intern("\\$")

var Lit_231 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$walk__960002906")

var Lit_232 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915")

var Lit_234 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915$fn__960002916")

var Lit_235 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915$fn__960002922")

var Lit_236 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915$fn__960002916$fn__960002917")

var Lit_237 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915$fn__960002916$fn__960002917$fn__960002918")

var Lit_238 *jrt.String = jrt.Intern("conversion template of")

var Lit_239 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$iter__960002910__960002914$fn__960002915$fn__960002922$fn__960002923")

var Lit_240 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates$walk__960002906$fn__960002907")

var Lit_241 *jrt.String = jrt.Intern("use of class template '")

var Lit_242 *jrt.String = jrt.Intern("' requires template arguments")

var Lit_243 *jrt.String = jrt.Intern("class template argument deduction for alias templates is a C++20 extension ('")

var Lit_244 *jrt.String = jrt.Intern("')")

var Lit_245 *jrt.String = jrt.Intern("ctad: an alias template's defining-type-id (")

var Lit_246 *jrt.String = jrt.Intern(")")

var Lit_247 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$fn__960002854")

var Lit_248 *jrt.String = jrt.Intern("template '")

var Lit_249 *jrt.String = jrt.Intern("' has no definition and no deduction guides")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$fn__960002856")

var Lit_251 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cands__960002861")

var Lit_252 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$unsure_fail__960002875")

var Lit_253 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$resolve__960002878")

var Lit_254 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cleanup_BANG___960002883")

var Lit_255 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$fn__960002893")

var Lit_256 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$fn__960002895")

var Lit_257 *jrt.String = jrt.Intern("a guide not deduced by the slice")

var Lit_258 *jrt.String = jrt.Intern("inherited constructors' guides")

var Lit_259 *jrt.String = jrt.Intern("no viable constructor or deduction guide for deduction of template arguments of '")

var Lit_260 *jrt.String = jrt.Intern("'")

var Lit_261 *jrt.String = jrt.Intern("ambiguous deduction for template arguments of '")

var Lit_262 *jrt.String = jrt.Intern("class template argument deduction for '")

var Lit_263 *jrt.String = jrt.Intern("' selected an explicit ")

var Lit_264 *jrt.String = jrt.Intern("deduction guide")

var Lit_265 *jrt.String = jrt.Intern("constructor")

var Lit_266 *jrt.String = jrt.Intern(" for copy-list-initialization")

var Lit_267 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cands__960002861$iter__960002862__960002866")

var Lit_268 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cands__960002861$fn__960002872")

var Lit_269 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cands__960002861$iter__960002862__960002866$fn__960002867")

var Lit_270 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cands__960002861$iter__960002862__960002866$fn__960002867$fn__960002868")

var Lit_271 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cleanup_BANG___960002883$fn__960002884")

var Lit_272 *jrt.String = jrt.Intern("arbace.cpp.template$ctad$cleanup_BANG___960002883$fn__960002884$fn__960002886")

var Lit_273 *jrt.String = jrt.Intern("ctad: ")

var Lit_274 *jrt.String = jrt.Intern(" (")

var Lit_275 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes$iter__960002519__960002523")

var Lit_276 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes$iter__960002519__960002523$fn__960002524")

var Lit_277 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes$iter__960002519__960002523$fn__960002524$fn__960002525")

var Lit_278 *jrt.String = jrt.Intern("FunctionTemplateDecl")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes$iter__960002519__960002523$fn__960002524$fn__960002529")

var Lit_280 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes$iter__960002519__960002523$fn__960002524$fn__960002525$fn__960002526")

var Lit_281 *jrt.String = jrt.Intern("nullptr")

var Lit_282 *jrt.String = jrt.Intern("a pointer argument ")

var Lit_283 *jrt.String = jrt.Intern("&")

var Lit_284 *jrt.String = jrt.Intern("an array's address as an argument")

var Lit_285 *jrt.String = jrt.Intern("_Z")

var Lit_286 *jrt.String = jrt.Intern("arbace.cpp.template$decl_arg$fn__960000797")

var Lit_287 *jrt.String = jrt.Intern("no function ")

var Lit_288 *jrt.String = jrt.Intern(" of the parameter's type")

var Lit_289 *jrt.String = jrt.Intern("arbace.cpp.template$decl_arg$fn__960000802")

var Lit_290 *jrt.String = jrt.Intern("arbace.cpp.template$decl_arg$fn__960000804")

var Lit_291 *jrt.String = jrt.Intern("arbace.cpp.template$decl_arg$fn__960000806")

var Lit_292 *jrt.String = jrt.Intern("codegen: a reinterpret_cast as a template argument: ")

var Lit_293 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$iter__960001223__960001227")

var Lit_294 *jrt.String = jrt.Intern("union")

var Lit_295 *jrt.String = jrt.Intern("CPP_INST_TRACE")

var Lit_296 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001233")

var Lit_297 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001235")

var Lit_298 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001239")

var Lit_299 *jrt.String = jrt.Intern("instance")

var Lit_300 *jrt.String = jrt.Intern("again")

var Lit_301 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001235$fn__960001236")

var Lit_302 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001239$fn__960001240")

var Lit_303 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001239$fn__960001244")

var Lit_304 *jrt.String = jrt.Intern("waiting for")

var Lit_305 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001239$fn__960001240$fn__960001241")

var Lit_306 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$fn__960001239$fn__960001244$fn__960001245")

var Lit_307 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$iter__960001223__960001227$fn__960001228")

var Lit_308 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_$iter__960001223__960001227$fn__960001228$fn__960001229")

var Lit_309 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960001990")

var Lit_310 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960001992")

var Lit_311 *jrt.String = jrt.Intern("VarDecl")

var Lit_312 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001")

var Lit_313 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002015")

var Lit_314 *jrt.String = jrt.Intern("an explicit specialization's qualifier")

var Lit_315 *jrt.String = jrt.Intern("an explicit specialization of a member of ")

var Lit_316 *jrt.String = jrt.Intern("an explicit specialization of a member template")

var Lit_317 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002042")

var Lit_318 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002044")

var Lit_319 *jrt.String = jrt.Intern("an explicit specialization of ")

var Lit_320 *jrt.String = jrt.Intern("'s arguments")

var Lit_321 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002046")

var Lit_322 *jrt.String = jrt.Intern("FunctionDecl")

var Lit_323 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002050")

var Lit_324 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002052")

var Lit_325 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061")

var Lit_326 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002075")

var Lit_327 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002102")

var Lit_328 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002104")

var Lit_329 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002106")

var Lit_330 *jrt.String = jrt.Intern("CXXDeductionGuideDecl")

var Lit_331 *jrt.String = jrt.Intern("FriendDecl")

var Lit_332 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002110")

var Lit_333 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002112")

var Lit_334 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121")

var Lit_335 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002135")

var Lit_336 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002162")

var Lit_337 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002164")

var Lit_338 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002166")

var Lit_339 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002170")

var Lit_340 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002172")

var Lit_341 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181")

var Lit_342 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002195")

var Lit_343 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002222")

var Lit_344 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002224")

var Lit_345 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002226")

var Lit_346 *jrt.String = jrt.Intern("ConceptDecl")

var Lit_347 *jrt.String = jrt.Intern("a concept without its constraint")

var Lit_348 *jrt.String = jrt.Intern("VarTemplatePartialSpecializationDecl")

var Lit_349 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pick__960002230")

var Lit_350 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002232")

var Lit_351 *jrt.String = jrt.Intern("no primary variable template ")

var Lit_352 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002234")

var Lit_353 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002236")

var Lit_354 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002238")

var Lit_355 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002240")

var Lit_356 *jrt.String = jrt.Intern("CXXConversionDecl")

var Lit_357 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$same_cons_QMARK___960002242")

var Lit_358 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002244")

var Lit_359 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pspell__960002246")

var Lit_360 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002256")

var Lit_361 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002258")

var Lit_362 *jrt.String = jrt.Intern("CPP_EQ_TRACE")

var Lit_363 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002262")

var Lit_364 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002268")

var Lit_365 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002272")

var Lit_366 *jrt.String = jrt.Intern("ExplicitInstantiationDecl")

var Lit_367 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002280")

var Lit_368 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002282")

var Lit_369 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002284")

var Lit_370 *jrt.String = jrt.Intern("CPP_EXTERN_TRACE")

var Lit_371 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002286")

var Lit_372 *jrt.String = jrt.Intern("ClassTemplatePartialSpecializationDecl")

var Lit_373 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002292")

var Lit_374 *jrt.String = jrt.Intern("no primary template ")

var Lit_375 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$cspell__960002294")

var Lit_376 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$tcs__960002297")

var Lit_377 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002299")

var Lit_378 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002301")

var Lit_379 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002304")

var Lit_380 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002308")

var Lit_381 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002310")

var Lit_382 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319")

var Lit_383 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002333")

var Lit_384 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002360")

var Lit_385 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002362")

var Lit_386 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002364")

var Lit_387 *jrt.String = jrt.Intern("ClassTemplateSpecializationDecl")

var Lit_388 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002368")

var Lit_389 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002370")

var Lit_390 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002376")

var Lit_391 *jrt.String = jrt.Intern("VarTemplateDecl")

var Lit_392 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002378")

var Lit_393 *jrt.String = jrt.Intern("TypeAliasTemplateDecl")

var Lit_394 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002380")

var Lit_395 *jrt.String = jrt.Intern("ClassTemplateDecl")

var Lit_396 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002382")

var Lit_397 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002387")

var Lit_398 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002399")

var Lit_399 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002401")

var Lit_400 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002403")

var Lit_401 *jrt.String = jrt.Intern("TemplateArgument")

var Lit_402 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002015$fn__960002016")

var Lit_403 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002046$fn__960002047")

var Lit_404 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002075$fn__960002076")

var Lit_405 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002106$fn__960002107")

var Lit_406 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002135$fn__960002136")

var Lit_407 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002166$fn__960002167")

var Lit_408 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002195$fn__960002196")

var Lit_409 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002226$fn__960002227")

var Lit_410 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002258$fn__960002259")

var Lit_411 *jrt.String = jrt.Intern("equiv")

var Lit_412 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002262$fn__960002263")

var Lit_413 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002262$fn__960002263$fn__960002264")

var Lit_414 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002268$fn__960002269")

var Lit_415 *jrt.String = jrt.Intern("extern template")

var Lit_416 *jrt.String = jrt.Intern("\\bnoexcept\\s*\\(\\s*")

var Lit_417 *jrt.String = jrt.Intern("\\s*\\)")

var Lit_418 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002304$fn__960002305")

var Lit_419 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002333$fn__960002334")

var Lit_420 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002364$fn__960002365")

var Lit_421 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002370$fn__960002371")

var Lit_422 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002370$fn__960002373")

var Lit_423 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$fn__960002403$fn__960002404")

var Lit_424 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002")

var Lit_425 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002$fn__960002003")

var Lit_426 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002$fn__960002009")

var Lit_427 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002$fn__960002011")

var Lit_428 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002$fn__960002003$fn__960002004")

var Lit_429 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960001997__960002001$fn__960002002$fn__960002003$fn__960002006")

var Lit_430 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062")

var Lit_431 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062$fn__960002063")

var Lit_432 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062$fn__960002069")

var Lit_433 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062$fn__960002071")

var Lit_434 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062$fn__960002063$fn__960002064")

var Lit_435 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002057__960002061$fn__960002062$fn__960002063$fn__960002066")

var Lit_436 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122")

var Lit_437 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122$fn__960002123")

var Lit_438 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122$fn__960002129")

var Lit_439 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122$fn__960002131")

var Lit_440 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122$fn__960002123$fn__960002124")

var Lit_441 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002117__960002121$fn__960002122$fn__960002123$fn__960002126")

var Lit_442 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182")

var Lit_443 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182$fn__960002183")

var Lit_444 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182$fn__960002189")

var Lit_445 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182$fn__960002191")

var Lit_446 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182$fn__960002183$fn__960002184")

var Lit_447 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002177__960002181$fn__960002182$fn__960002183$fn__960002186")

var Lit_448 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320")

var Lit_449 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320$fn__960002321")

var Lit_450 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320$fn__960002327")

var Lit_451 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320$fn__960002329")

var Lit_452 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320$fn__960002321$fn__960002322")

var Lit_453 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$iter__960002315__960002319$fn__960002320$fn__960002321$fn__960002324")

var Lit_454 *jrt.String = jrt.Intern("\\b(")

var Lit_455 *jrt.String = jrt.Intern(")\\b")

var Lit_456 *jrt.String = jrt.Intern("|")

var Lit_457 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pspell__960002246$fn__960002247")

var Lit_458 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pspell__960002246$fn__960002249")

var Lit_459 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pspell__960002246$fn__960002251")

var Lit_460 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template$pspell__960002246$fn__960002251$fn__960002252")

var Lit_461 *jrt.String = jrt.Intern("#")

var Lit_462 *jrt.String = jrt.Intern("arbace.cpp.template$decltype_failed_QMARK_$fn__960001650")

var Lit_463 *jrt.String = jrt.Intern("arbace.cpp.template$decltype_failed_QMARK_$fn__960001652")

var Lit_464 *jrt.String = jrt.Intern("decltype")

var Lit_465 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_by_type_match$fn__960000980")

var Lit_466 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$bare_tparam__960001024")

var Lit_467 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030")

var Lit_468 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$fn__960001062")

var Lit_469 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001064__960001068")

var Lit_470 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$fn__960001084")

var Lit_471 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$fn__960001086")

var Lit_472 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$named_elsewhere__960001088")

var Lit_473 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$fn__960001092")

var Lit_474 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$fn__960001092$fn__960001093")

var Lit_475 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031")

var Lit_476 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031$fn__960001032")

var Lit_477 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031$fn__960001053")

var Lit_478 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031$fn__960001058")

var Lit_479 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031$fn__960001032$fn__960001039")

var Lit_480 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001026__960001030$fn__960001031$fn__960001032$fn__960001044")

var Lit_481 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001064__960001068$fn__960001069")

var Lit_482 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$iter__960001064__960001068$fn__960001069$fn__960001070")

var Lit_483 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call$named_elsewhere__960001088$fn__960001089")

var Lit_484 *jrt.String = jrt.Intern("CPP_CONV_TRACE")

var Lit_485 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_conv$fn__960002902")

var Lit_486 *jrt.String = jrt.Intern("deduce-conv")

var Lit_487 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_from_rhs$targs__960002695")

var Lit_488 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_from_rhs$fn__960002697")

var Lit_489 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_template_spec$one__960000969")

var Lit_490 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_template_spec$fn__960000971")

var Lit_491 *jrt.String = jrt.Intern("arbace.cpp.template$deducible_tparams$walk__960001017")

var Lit_492 *jrt.String = jrt.Intern("arbace.cpp.template$dependent_on_QMARK_$fn__960000927")

var Lit_493 *jrt.String = jrt.Intern("arbace.cpp.template$dnf$iter__960001157__960001163")

var Lit_494 *jrt.String = jrt.Intern("arbace.cpp.template$dnf$iter__960001157__960001163$fn__960001164")

var Lit_495 *jrt.String = jrt.Intern("arbace.cpp.template$dnf$iter__960001157__960001163$fn__960001164$iter__960001159__960001165")

var Lit_496 *jrt.String = jrt.Intern("arbace.cpp.template$dnf$iter__960001157__960001163$fn__960001164$iter__960001159__960001165$fn__960001166")

var Lit_497 *jrt.String = jrt.Intern("arbace.cpp.template$dnf$iter__960001157__960001163$fn__960001164$iter__960001159__960001165$fn__960001166$fn__960001167")

var Lit_498 *jrt.String = jrt.Intern("arbace.cpp.template$drop_layouts_BANG_$fn__960001439")

var Lit_499 *jrt.String = jrt.Intern("arbace.cpp.template$drop_layouts_BANG_$fn__960001439$fn__960001440")

var Lit_500 *jrt.String = jrt.Intern("arbace.cpp.template$elementwise$fn__960000841")

var Lit_501 *jrt.String = jrt.Intern("packs of different lengths in one expansion")

var Lit_502 *jrt.String = jrt.Intern("arbace.cpp.template$elementwise$iter__960000846__960000850")

var Lit_503 *jrt.String = jrt.Intern("arbace.cpp.template$elementwise$iter__960000846__960000850$fn__960000851")

var Lit_504 *jrt.String = jrt.Intern("arbace.cpp.template$elementwise$iter__960000846__960000850$fn__960000851$fn__960000852")

var Lit_505 *jrt.String = jrt.Intern("ctad: an alias guide's parameter entity ")

var Lit_506 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941")

var Lit_507 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942")

var Lit_508 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002943")

var Lit_509 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002951")

var Lit_510 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002943$fn__960002944")

var Lit_511 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002943$fn__960002944$fn__960002945")

var Lit_512 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002943$fn__960002944$fn__960002947")

var Lit_513 *jrt.String = jrt.Intern("constructor template of")

var Lit_514 *jrt.String = jrt.Intern("does not deduce")

var Lit_515 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002951$fn__960002952")

var Lit_516 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936$iter__960002937__960002941$fn__960002942$fn__960002951$fn__960002954")

var Lit_517 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002962$fn__960002963")

var Lit_518 *jrt.String = jrt.Intern("unknown type ")

var Lit_519 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002970$fn__960002974")

var Lit_520 *jrt.String = jrt.Intern("__cx_ret_t")

var Lit_521 *jrt.String = jrt.Intern("<__cx_ret_t")

var Lit_522 *jrt.String = jrt.Intern(", ")

var Lit_523 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002970$fn__960002976")

var Lit_524 *jrt.String = jrt.Intern("type-constraint")

var Lit_525 *jrt.String = jrt.Intern("missing template arguments for ")

var Lit_526 *jrt.String = jrt.Intern("a dependent concept-id")

var Lit_527 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002981$fn__960002982")

var Lit_528 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$peek__960000652")

var Lit_529 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$next_BANG___960000654")

var Lit_530 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$flt__960000656")

var Lit_531 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$num__960000663")

var Lit_532 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$run__960000669")

var Lit_533 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$cast_named__960000674")

var Lit_534 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676")

var Lit_535 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$expr__960000726")

var Lit_536 *jrt.String = jrt.Intern("constant expression ")

var Lit_537 *jrt.String = jrt.Intern("a 128-bit constant expression ")

var Lit_538 *jrt.String = jrt.Intern("?")

var Lit_539 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$flt__960000656$fn__960000660")

var Lit_540 *jrt.String = jrt.Intern("a floating literal ")

var Lit_541 *jrt.String = jrt.Intern("0x")

var Lit_542 *jrt.String = jrt.Intern("p")

var Lit_543 *jrt.String = jrt.Intern(".")

var Lit_544 *jrt.String = jrt.Intern("e")

var Lit_545 *jrt.String = jrt.Intern("0b")

var Lit_546 *jrt.String = jrt.Intern("0")

var Lit_547 *jrt.String = jrt.Intern("not an integer literal ")

var Lit_548 *jrt.String = jrt.Intern("(")

var Lit_549 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000680")

var Lit_550 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000685")

var Lit_551 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000690")

var Lit_552 *jrt.String = jrt.Intern("-")

var Lit_553 *jrt.String = jrt.Intern("neg")

var Lit_554 *jrt.String = jrt.Intern("+")

var Lit_555 *jrt.String = jrt.Intern("!")

var Lit_556 *jrt.String = jrt.Intern("~")

var Lit_557 *jrt.String = jrt.Intern("true")

var Lit_558 *jrt.String = jrt.Intern("false")

var Lit_559 *jrt.String = jrt.Intern("<")

var Lit_560 *jrt.String = jrt.Intern("...")

var Lit_561 *jrt.String = jrt.Intern("sizeof...")

var Lit_562 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000699")

var Lit_563 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000702")

var Lit_564 *jrt.String = jrt.Intern("noexcept")

var Lit_565 *jrt.String = jrt.Intern("noexcept-expr:")

var Lit_566 *jrt.String = jrt.Intern("a noexcept-expression's operand not kept: ")

var Lit_567 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000704")

var Lit_568 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000710")

var Lit_569 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000712")

var Lit_570 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000717")

var Lit_571 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000719")

var Lit_572 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000721")

var Lit_573 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000723")

var Lit_574 *jrt.String = jrt.Intern("CXXNoexceptExpr")

var Lit_575 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000704$fn__960000705")

var Lit_576 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text$primary__960000676$fn__960000704$fn__960000707")

var Lit_577 *jrt.String = jrt.Intern(",")

var Lit_578 *jrt.String = jrt.Intern("a pack expansion without a pack")

var Lit_579 *jrt.String = jrt.Intern("arbace.cpp.template$expand_expr_pack$fn__960000885")

var Lit_580 *jrt.String = jrt.Intern("arbace.cpp.template$expand_type_pack$fn__960000879")

var Lit_581 *jrt.String = jrt.Intern("arbace.cpp.template$expand_type_pack$fn__960000881")

var Lit_582 *jrt.String = jrt.Intern("\\s*<")

var Lit_583 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001936")

var Lit_584 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001938")

var Lit_585 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001940")

var Lit_586 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001942")

var Lit_587 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001949")

var Lit_588 *jrt.String = jrt.Intern("CPP_EXPLICIT_TRACE")

var Lit_589 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_$fn__960001942$fn__960001943")

var Lit_590 *jrt.String = jrt.Intern("explicit instantiation")

var Lit_591 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$fn__960001785")

var Lit_592 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$fn__960001787")

var Lit_593 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$try1__960001789")

var Lit_594 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$fn__960001794")

var Lit_595 *jrt.String = jrt.Intern("no template for the explicit specialization ")

var Lit_596 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$fn__960001794$fn__960001799")

var Lit_597 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_$try1__960001789$fn__960001790")

var Lit_598 *jrt.String = jrt.Intern("(?<![A-Za-z0-9_$])")

var Lit_599 *jrt.String = jrt.Intern("\\s*\\(")

var Lit_600 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001871")

var Lit_601 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001873")

var Lit_602 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001875")

var Lit_603 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001878")

var Lit_604 *jrt.String = jrt.Intern(" to specialize")

var Lit_605 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001880")

var Lit_606 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001882")

var Lit_607 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_$fn__960001882$fn__960001884")

var Lit_608 *jrt.String = jrt.Intern("arbace.cpp.template$extern_class_QMARK_$fn__960002428")

var Lit_609 *jrt.String = jrt.Intern("arbace.cpp.template$find_template$fn__960001842")

var Lit_610 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$fn__960000992")

var Lit_611 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$later_QMARK___960000994")

var Lit_612 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$fn__960000998")

var Lit_613 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$fn__960001000")

var Lit_614 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$fn__960001002")

var Lit_615 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$fn__960001004")

var Lit_616 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction$later_QMARK___960000994$fn__960000995")

var Lit_617 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000195$fn__960000199")

var Lit_618 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000221$fn__960000225")

var Lit_619 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000259$fn__960000263")

var Lit_620 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000291$fn__960000295")

var Lit_621 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000299$fn__960000303")

var Lit_622 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000355$fn__960000359")

var Lit_623 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000377$fn__960000381")

var Lit_624 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000403$fn__960000407")

var Lit_625 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000423$fn__960000427")

var Lit_626 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000485$fn__960000489")

var Lit_627 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101")

var Lit_628 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102")

var Lit_629 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102$fn__960001103")

var Lit_630 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102$fn__960001109")

var Lit_631 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102$fn__960001103$fn__960001104")

var Lit_632 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102$fn__960001103$fn__960001104$fn__960001105")

var Lit_633 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs$iter__960001097__960001101$fn__960001102$fn__960001109$fn__960001110")

var Lit_634 *jrt.String = jrt.Intern("*")

var Lit_635 *jrt.String = jrt.Intern("division by zero in a constant expression")

var Lit_636 *jrt.String = jrt.Intern("!=")

var Lit_637 *jrt.String = jrt.Intern("&&")

var Lit_638 *jrt.String = jrt.Intern("||")

var Lit_639 *jrt.String = jrt.Intern("<=")

var Lit_640 *jrt.String = jrt.Intern("==")

var Lit_641 *jrt.String = jrt.Intern(">=")

var Lit_642 *jrt.String = jrt.Intern("the operator ")

var Lit_643 *jrt.String = jrt.Intern(" on a floating constant")

var Lit_644 *jrt.String = jrt.Intern("arbace.cpp.template$fold$ok__960000134")

var Lit_645 *jrt.String = jrt.Intern("arbace.cpp.template$fold$bit__960000139")

var Lit_646 *jrt.String = jrt.Intern("%")

var Lit_647 *jrt.String = jrt.Intern("arbace.cpp.template$fold$fn__960000142")

var Lit_648 *jrt.String = jrt.Intern("^")

var Lit_649 *jrt.String = jrt.Intern("arbace.cpp.template$fold$fn__960000144")

var Lit_650 *jrt.String = jrt.Intern("arbace.cpp.template$fold$fn__960000146")

var Lit_651 *jrt.String = jrt.Intern("<<")

var Lit_652 *jrt.String = jrt.Intern(">>")

var Lit_653 *jrt.String = jrt.Intern("a shift by ")

var Lit_654 *jrt.String = jrt.Intern(" in a constant expression")

var Lit_655 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_$fn__960001848")

var Lit_656 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_$fn__960001851")

var Lit_657 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_$fn__960001853")

var Lit_658 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_$fn__960001857")

var Lit_659 *jrt.String = jrt.Intern("operator<=>")

var Lit_660 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_$fn__960001860")

var Lit_661 *jrt.String = jrt.Intern("operator==")

var Lit_662 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$cnt__960002652")

var Lit_663 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$fn__960002655")

var Lit_664 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$fn__960002655$ok__960002659")

var Lit_665 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$fn__960002655$fn__960002663")

var Lit_666 *jrt.String = jrt.Intern("ctad: missing arguments")

var Lit_667 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$fn__960002655$fn__960002665")

var Lit_668 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_$fn__960002655$ok__960002659$fn__960002660")

var Lit_669 *jrt.String = jrt.Intern("arbace.cpp.template$guide_min_args$fn__960002649")

var Lit_670 *jrt.String = jrt.Intern("arbace.cpp.template$guide_scope$fn__960002513")

var Lit_671 *jrt.String = jrt.Intern("arbace.cpp.template$guide_scope$fn__960002515")

var Lit_672 *jrt.String = jrt.Intern("arbace.cpp.template$header_params$fn__960001503")

var Lit_673 *jrt.String = jrt.Intern("arbace.cpp.template$header_params$fn__960001505")

var Lit_674 *jrt.String = jrt.Intern("=")

var Lit_675 *jrt.String = jrt.Intern("arbace.cpp.template$incomplete_instance_BANG_$fn__960001436")

var Lit_676 *jrt.String = jrt.Intern("waiting for its template's definition")

var Lit_677 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$fn__960002819")

var Lit_678 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830")

var Lit_679 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831")

var Lit_680 *jrt.String = jrt.Intern("'s base ")

var Lit_681 *jrt.String = jrt.Intern("TypeAliasDecl")

var Lit_682 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831$res__960002832")

var Lit_683 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831$iter__960002826__960002834")

var Lit_684 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831$fn__960002840")

var Lit_685 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831$iter__960002826__960002834$fn__960002835")

var Lit_686 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides$iter__960002824__960002830$fn__960002831$iter__960002826__960002834$fn__960002835$fn__960002836")

var Lit_687 *jrt.String = jrt.Intern("initializer_list")

var Lit_688 *jrt.String = jrt.Intern("codegen: recursive template instantiation exceeded maximum depth (the analysis' stack, under ")

var Lit_689 *jrt.String = jrt.Intern("codegen: recursive template instantiation exceeded maximum depth of 1024 (")

var Lit_690 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_class_STAR_$fn__960001405")

var Lit_691 *jrt.String = jrt.Intern("instance miss")

var Lit_692 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$unsat__960001657")

var Lit_693 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001662")

var Lit_694 *jrt.String = jrt.Intern("type-constraints")

var Lit_695 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001664")

var Lit_696 *jrt.String = jrt.Intern("constraints")

var Lit_697 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001666")

var Lit_698 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001668")

var Lit_699 *jrt.String = jrt.Intern("the signature's substitution")

var Lit_700 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001670")

var Lit_701 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001673")

var Lit_702 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001675")

var Lit_703 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681")

var Lit_704 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001699")

var Lit_705 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$fn__960001699$fn__960001700")

var Lit_706 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682")

var Lit_707 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001683")

var Lit_708 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001691")

var Lit_709 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001695")

var Lit_710 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001683$fn__960001684")

var Lit_711 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001683$fn__960001688")

var Lit_712 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001683$fn__960001684$fn__960001685")

var Lit_713 *jrt.String = jrt.Intern("Attr")

var Lit_714 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$iter__960001677__960001681$fn__960001682$fn__960001691$fn__960001692")

var Lit_715 *jrt.String = jrt.Intern("CPP_CONSTRAINT_TRACE")

var Lit_716 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn$unsat__960001657$fn__960001658")

var Lit_717 *jrt.String = jrt.Intern("codegen: ")

var Lit_718 *jrt.String = jrt.Intern(" not satisfied for ")

var Lit_719 *jrt.String = jrt.Intern("unsatisfied")

var Lit_720 *jrt.String = jrt.Intern("arbace.cpp.template$kids$fn__960000020")

var Lit_721 *jrt.String = jrt.Intern("a floating constant outside long's range: ")

var Lit_722 *jrt.String = jrt.Intern("__make_integer_seq")

var Lit_723 *jrt.String = jrt.Intern("__make_integer_seq's sequence")

var Lit_724 *jrt.String = jrt.Intern("__make_integer_seq of a negative length ")

var Lit_725 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$fn__960000938")

var Lit_726 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$fn__960000940")

var Lit_727 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000942__960000946")

var Lit_728 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000952__960000956")

var Lit_729 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$fn__960000966")

var Lit_730 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000942__960000946$fn__960000947")

var Lit_731 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000942__960000946$fn__960000947$fn__960000948")

var Lit_732 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000952__960000956$fn__960000957")

var Lit_733 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000952__960000956$fn__960000957$fn__960000958")

var Lit_734 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000952__960000956$fn__960000957$fn__960000962")

var Lit_735 *jrt.String = jrt.Intern("arbace.cpp.template$match_args$iter__960000952__960000956$fn__960000957$fn__960000958$fn__960000959")

var Lit_736 *jrt.String = jrt.Intern("a member of a non-class: ")

var Lit_737 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_fn_QMARK_$fn__960001200")

var Lit_738 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_fn_QMARK_$fn__960001202")

var Lit_739 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_fn_QMARK_$fn__960001204")

var Lit_740 *jrt.String = jrt.Intern("more-constrained")

var Lit_741 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_partial_QMARK_$fn__960001392")

var Lit_742 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_partial_QMARK_$fn__960001394")

var Lit_743 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_partial_QMARK_$fn__960001398")

var Lit_744 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_partial_QMARK_$fn__960001394$fn__960001395")

var Lit_745 *jrt.String = jrt.Intern("partial-constraints")

var Lit_746 *jrt.String = jrt.Intern("more-constrained-partial")

var Lit_747 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_fn_QMARK_$upto__960001208")

var Lit_748 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_fn_QMARK_$variadic_QMARK___960001210")

var Lit_749 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_fn_QMARK_$variadic_QMARK___960001210$fn__960001211")

var Lit_750 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_partial_QMARK_$ded__960001401")

var Lit_751 *jrt.String = jrt.Intern("arbace.cpp.template$name_pack_params_BANG_$fn__960001629")

var Lit_752 *jrt.String = jrt.Intern("arbace.cpp.template$name_pack_params_BANG_$fn__960001631")

var Lit_753 *jrt.String = jrt.Intern("arbace.cpp.template$name_pack_params_BANG_$fn__960001638")

var Lit_754 *jrt.String = jrt.Intern("arbace.cpp.template$node_arg$fn__960000816")

var Lit_755 *jrt.String = jrt.Intern("arbace.cpp.template$node_arg$fn__960000818")

var Lit_756 *jrt.String = jrt.Intern("template argument ")

var Lit_757 *jrt.String = jrt.Intern("BinaryOperator")

var Lit_758 *jrt.String = jrt.Intern("arbace.cpp.template$ool_class_template$fn__960001523")

var Lit_759 *jrt.String = jrt.Intern("arbace.cpp.template$ool_class_template$fn__960001525")

var Lit_760 *jrt.String = jrt.Intern("arbace.cpp.template$ool_class_template$fn__960001527")

var Lit_761 *jrt.String = jrt.Intern("no class template ")

var Lit_762 *jrt.String = jrt.Intern("arbace.cpp.template$ool_member_template_BANG_$fn__960001923")

var Lit_763 *jrt.String = jrt.Intern("arbace.cpp.template$ool_qualifier$fn__960001512")

var Lit_764 *jrt.String = jrt.Intern("arbace.cpp.template$ool_qualifier$fn__960001514")

var Lit_765 *jrt.String = jrt.Intern("arbace.cpp.template$packs_named$iter__960000829__960000833")

var Lit_766 *jrt.String = jrt.Intern("arbace.cpp.template$packs_named$iter__960000829__960000833$fn__960000834")

var Lit_767 *jrt.String = jrt.Intern("arbace.cpp.template$packs_named$iter__960000829__960000833$fn__960000834$fn__960000835")

var Lit_768 *jrt.String = jrt.Intern("arbace.cpp.template$param_defaults$fn__960002536")

var Lit_769 *jrt.String = jrt.Intern("arbace.cpp.template$param_defaults$fn__960002540")

var Lit_770 *jrt.String = jrt.Intern("arbace.cpp.template$param_defaults$fn__960002536$fn__960002537")

var Lit_771 *jrt.String = jrt.Intern("arbace.cpp.template$partial_args$fn__960001366")

var Lit_772 *jrt.String = jrt.Intern("arbace.cpp.template$partial_constraints$iter__960001379__960001383")

var Lit_773 *jrt.String = jrt.Intern("arbace.cpp.template$partial_constraints$fn__960001389")

var Lit_774 *jrt.String = jrt.Intern("arbace.cpp.template$partial_constraints$iter__960001379__960001383$fn__960001384")

var Lit_775 *jrt.String = jrt.Intern("arbace.cpp.template$partial_constraints$iter__960001379__960001383$fn__960001384$fn__960001385")

var Lit_776 *jrt.String = jrt.Intern("arbace.cpp.template$partial_match$fn__960001374")

var Lit_777 *jrt.String = jrt.Intern("arbace.cpp.template$partial_match$fn__960001376")

var Lit_778 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002469")

var Lit_779 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002474")

var Lit_780 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002476")

var Lit_781 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002482")

var Lit_782 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002484")

var Lit_783 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002490")

var Lit_784 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002492")

var Lit_785 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002494")

var Lit_786 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002496")

var Lit_787 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002498")

var Lit_788 *jrt.String = jrt.Intern("arbace.cpp.template$pending$fn__960002500")

var Lit_789 *jrt.String = jrt.Intern("arbace.cpp.template$qualified_template_name_QMARK_$fn__960000638")

var Lit_790 *jrt.String = jrt.Intern("arbace.cpp.template$qualified_template_name_QMARK_$fn__960000640")

var Lit_791 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_args$param__960000888")

var Lit_792 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_args$fn__960000890")

var Lit_793 *jrt.String = jrt.Intern("too many template arguments for ")

var Lit_794 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_args$fn__960000890$fn__960000891")

var Lit_795 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_args$fn__960000890$fn__960000893")

var Lit_796 *jrt.String = jrt.Intern("arbace.cpp.template$select_instance_BANG_$fn__960001408")

var Lit_797 *jrt.String = jrt.Intern("arbace.cpp.template$select_instance_BANG_$fn__960001411")

var Lit_798 *jrt.String = jrt.Intern("an incomplete class template ")

var Lit_799 *jrt.String = jrt.Intern("ambiguous partial specializations of ")

var Lit_800 *jrt.String = jrt.Intern(" for ")

var Lit_801 *jrt.String = jrt.Intern("arbace.cpp.template$select_instance_BANG_$fn__960001430")

var Lit_802 *jrt.String = jrt.Intern("arbace.cpp.template$select_instance_BANG_$fn__960001411$fn__960001416")

var Lit_803 *jrt.String = jrt.Intern("arbace.cpp.template$self_text$fn__960002544")

var Lit_804 *jrt.String = jrt.Intern("a member call of a non-class: ")

var Lit_805 *jrt.String = jrt.Intern("arbace.cpp.template$static_call_value$fn__960000741")

var Lit_806 *jrt.String = jrt.Intern("no member function template ")

var Lit_807 *jrt.String = jrt.Intern("dependent")

var Lit_808 *jrt.String = jrt.Intern("arbace.cpp.template$static_call_value$fn__960000743")

var Lit_809 *jrt.String = jrt.Intern("arbace.cpp.template$strip_tparam_kids$fn__960000062")

var Lit_810 *jrt.String = jrt.Intern("arbace.cpp.template$subst_value$fn__960000923")

var Lit_811 *jrt.String = jrt.Intern("arbace.cpp.template$subsumes_QMARK_$fn__960001193")

var Lit_812 *jrt.String = jrt.Intern("arbace.cpp.template$subsumes_QMARK_$fn__960001193$fn__960001194")

var Lit_813 *jrt.String = jrt.Intern("arbace.cpp.template$subsumes_QMARK_$fn__960001193$fn__960001194$fn__960001195")

var Lit_814 *jrt.String = jrt.Intern("a signature that names its own template ")

var Lit_815 *jrt.String = jrt.Intern("arbace.cpp.template$sym_sig$fn__960000985")

var Lit_816 *jrt.String = jrt.Intern("arbace.cpp.template$tc_arg_forms$fn__960000028")

var Lit_817 *jrt.String = jrt.Intern("arbace.cpp.template$template_arg_of$fn__960000785")

var Lit_818 *jrt.String = jrt.Intern("a template template argument ")

var Lit_819 *jrt.String = jrt.Intern("arbace.cpp.template$template_arg_of$fn__960000787")

var Lit_820 *jrt.String = jrt.Intern("arbace.cpp.template$template_arg_of$fn__960000789")

var Lit_821 *jrt.String = jrt.Intern("not a template: ")

var Lit_822 *jrt.String = jrt.Intern("arbace.cpp.template$template_defined_BANG_$fn__960001454")

var Lit_823 *jrt.String = jrt.Intern("arbace.cpp.template$template_defined_BANG_$fn__960001456")

var Lit_824 *jrt.String = jrt.Intern("__type_pack_element")

var Lit_825 *jrt.String = jrt.Intern("arbace.cpp.template$template_id$fn__960001486")

var Lit_826 *jrt.String = jrt.Intern("arbace.cpp.template$template_id$fn__960001488")

var Lit_827 *jrt.String = jrt.Intern("arbace.cpp.template$template_id$fn__960001490")

var Lit_828 *jrt.String = jrt.Intern("not a class or alias template: ")

var Lit_829 *jrt.String = jrt.Intern("arbace.cpp.template$template_id$fn__960001492")

var Lit_830 *jrt.String = jrt.Intern("a dependent template-id with default arguments")

var Lit_831 *jrt.String = jrt.Intern("arbace.cpp.template$template_id$fn__960001492$fn__960001493")

var Lit_832 *jrt.String = jrt.Intern("defaults of")

var Lit_833 *jrt.String = jrt.Intern("arbace.cpp.template$template_name_QMARK_$fn__960000634")

var Lit_834 *jrt.String = jrt.Intern("arbace.cpp.template$template_text_args$key_before_QMARK___960001833")

var Lit_835 *jrt.String = jrt.Intern("arbace.cpp.template$template_text_args$fn__960001835")

var Lit_836 *jrt.String = jrt.Intern("partial specialization's arguments")

var Lit_837 *jrt.String = jrt.Intern("arbace.cpp.template$tiebreak$guide_better__960001219")

var Lit_838 *jrt.String = jrt.Intern("arbace.cpp.template$tmpl_of_entity$fn__960001461")

var Lit_839 *jrt.String = jrt.Intern("arbace.cpp.template$tmpl_of_entity$fn__960001463")

var Lit_840 *jrt.String = jrt.Intern("arbace.cpp.template$tn_types$fn__960001591")

var Lit_841 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$parms__960001734")

var Lit_842 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$dflt_QMARK___960001738")

var Lit_843 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$fn__960001743")

var Lit_844 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$dflt_QMARK___960001738$fn__960001739")

var Lit_845 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$fn__960001743$fn__960001747")

var Lit_846 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_$parms__960001734$fn__960001735")

var Lit_847 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036")

var Lit_848 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037")

var Lit_849 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037$fn__960000038")

var Lit_850 *jrt.String = jrt.Intern("TemplateTemplateParmDecl")

var Lit_851 *jrt.String = jrt.Intern("TemplateTypeParmDecl")

var Lit_852 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037$fn__960000053")

var Lit_853 *jrt.String = jrt.Intern("NonTypeTemplateParmDecl")

var Lit_854 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037$fn__960000038$fn__960000043")

var Lit_855 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037$fn__960000038$fn__960000043$fn__960000044")

var Lit_856 *jrt.String = jrt.Intern("ConceptSpecializationExpr")

var Lit_857 *jrt.String = jrt.Intern("arbace.cpp.template$tparams$iter__960000032__960000036$fn__960000037$fn__960000053$fn__960000054")

var Lit_858 *jrt.String = jrt.Intern("arbace.cpp.template$tparams_in$fn__960001014")

var Lit_859 *jrt.String = jrt.Intern("arbace.cpp.template$trait_args$fn__960000628")

var Lit_860 *jrt.String = jrt.Intern("arbace.cpp.template$trait_assignable_QMARK_$fn__960000171")

var Lit_861 *jrt.String = jrt.Intern("arbace.cpp.template$trait_constructible_QMARK_$fn__960000158")

var Lit_862 *jrt.String = jrt.Intern("arbace.cpp.template$trait_convertible_QMARK_$fn__960000166")

var Lit_863 *jrt.String = jrt.Intern("arbace.cpp.template$trait_convertible_QMARK_$fn__960000168")

var Lit_864 *jrt.String = jrt.Intern("the type trait ")

var Lit_865 *jrt.String = jrt.Intern("arbace.cpp.template$trivially_default_QMARK_$fn__960000177")

var Lit_866 *jrt.String = jrt.Intern("arbace.cpp.template$trivially_default_QMARK_$fn__960000179")

var Lit_867 *jrt.String = jrt.Intern("arbace.cpp.template$trivially_default_QMARK_$fn__960000183")

var Lit_868 *jrt.String = jrt.Intern("arbace.cpp.template$trivially_default_QMARK_$fn__960000179$fn__960000180")

var Lit_869 *jrt.String = jrt.Intern("arbace.cpp.template$type_constraints_satisfied_QMARK_$fn__960001619")

var Lit_870 *jrt.String = jrt.Intern("arbace.cpp.template$type_constraints_satisfied_QMARK_$fn__960001619$fn__960001623")

var Lit_871 *jrt.String = jrt.Intern("arbace.cpp.template$type_pack_element$bad__960001466")

var Lit_872 *jrt.String = jrt.Intern("arbace.cpp.template$type_pack_element$fn__960001469")

var Lit_873 *jrt.String = jrt.Intern("__type_pack_element's index is not an integral constant expression")

var Lit_874 *jrt.String = jrt.Intern("__type_pack_element's index ")

var Lit_875 *jrt.String = jrt.Intern(" is negative")

var Lit_876 *jrt.String = jrt.Intern(" is out of range for ")

var Lit_877 *jrt.String = jrt.Intern(" types")

var Lit_878 *jrt.String = jrt.Intern("arbace.cpp.template$unspelled$fn__960000913")

var Lit_879 *jrt.String = jrt.Intern("arbace.cpp.template$user_guide_BANG_$fn__960002506")

var Lit_880 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst$fn__960001811")

var Lit_881 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst$fn__960001814")

var Lit_882 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst$fn__960001828")

var Lit_883 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst$fn__960001830")

var Lit_884 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst$fn__960001814$fn__960001819")

var Lit_885 *jrt.String = jrt.Intern("arbace.cpp.template$var_text_args$fn__960001838")

var Lit_886 *jrt.String = jrt.Intern("a variable template's partial specialization's arguments")

var Lit_887 *jrt.String = jrt.Intern("arbace.cpp.template$written_qualifier$fn__960000749")

var Lit_888 *jrt.String = jrt.Intern("arbace.cpp.template$written_qualifier$fn__960000751")

var Lit_889 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn4,kindyn6,parentyn1,&yn4,moreyn5,scopeyn2,nmyn1,eyn2,idyn1,fyn4,argsyn1,nkn3,tagyn16,java.lang.Stringkn7,dynamicyn1,ayn1,byn3,tidyn1,xyn1,kyn1,pkn8,declaredyn6,paramsyn7,sym-tidyn1,vyn5,partsyn1,tyn6,Stringyn1,oyn1,uyn4,fromyn2,toyn4,predyn5,formsyn2,psyn6,calleeyn3,clsyn2,ptyn6,pscopeyn4,longyn5,givenyn3,nmsyn5,packsyn1,Xyn3,ctxyn9,group-allyn2,qsv11,arbace.core5,in-nsMyn19,arbace.cpp.templatem2,R0,s1841,Templates for the code generator (doc/cpp/CODEGEN.md §G3): class and function templates declared, specialized and\n  instantiated on use. The native parser's tree keeps a template's pattern as it was written (clang's dependent\n  nodes as syntax: a type is its spelling, a name its identifier), so an instantiation is the pattern declared again\n  by arbace.cpp.sema in a scope that binds the template's parameters to its arguments -- what clang's TreeTransform\n  does by substitution, done here by re-analysis -- and a member's or a function template's definition is analyzed\n  only when the program uses it (clang's InstantiateFunctionDefinition on odr-use: `:lazy` until a round of analysis\n  references it). Deduction from a call ([temp.deduct.call]: P/A adjusted, then matched structurally as\n  DeduceTemplateArgumentsByTypeMatch does), explicit arguments, default arguments, non-type parameters, explicit\n  specializations of class and function templates, partial specializations of class templates chosen by deduction and\n  ordered as [temp.class.order] says, partial ordering of function templates ([temp.func.order],\n  [temp.deduct.partial]) and the overload tie-breaks of [over.match.best]/2.2-2.5; packs, alias and variable\n  templates, template template parameters, pointer and reference non-type parameters, members defined outside their\n  class (of the primary or of a partial specialization), explicit specializations of members, friends defined in\n  classes, two-phase lookup's dependent bases. The structure follows clang's\n  SemaTemplateDeduction.cpp, SemaTemplateInstantiate.cpp and SemaTemplateInstantiateDecl.cpp at llvmorg-23.1.4 (read\n  as the model; their functions' names are kept where the parts correspond; CODEGEN.md §G3 says what is ported and\n  what written). Refusals as in sema: {:codegen/refused :template ...}.m2,R0,s1841,Templates for the code generator (doc/cpp/CODEGEN.md §G3): class and function templates declared, specialized and\n  instantiated on use. The native parser's tree keeps a template's pattern as it was written (clang's dependent\n  nodes as syntax: a type is its spelling, a name its identifier), so an instantiation is the pattern declared again\n  by arbace.cpp.sema in a scope that binds the template's parameters to its arguments -- what clang's TreeTransform\n  does by substitution, done here by re-analysis -- and a member's or a function template's definition is analyzed\n  only when the program uses it (clang's InstantiateFunctionDefinition on odr-use: `:lazy` until a round of analysis\n  references it). Deduction from a call ([temp.deduct.call]: P/A adjusted, then matched structurally as\n  DeduceTemplateArgumentsByTypeMatch does), explicit arguments, default arguments, non-type parameters, explicit\n  specializations of class and function templates, partial specializations of class templates chosen by deduction and\n  ordered as [temp.class.order] says, partial ordering of function templates ([temp.func.order],\n  [temp.deduct.partial]) and the overload tie-breaks of [over.match.best]/2.2-2.5; packs, alias and variable\n  templates, template template parameters, pointer and reference non-type parameters, members defined outside their\n  class (of the primary or of a partial specialization), explicit specializations of members, friends defined in\n  classes, two-phase lookup's dependent bases. The structure follows clang's\n  SemaTemplateDeduction.cpp, SemaTemplateInstantiate.cpp and SemaTemplateInstantiateDecl.cpp at llvmorg-23.1.4 (read\n  as the model; their functions' names are kept where the parts correspond; CODEGEN.md §G3 says what is ported and\n  what written). Refusals as in sema: {:codegen/refused :template ...}.R1,v11,arbace.core20,*warn-on-reflection*v19,arbace.cpp.template4,failv14,arbace.cpp.abi4,failm6,R2,i42,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template7,next-idm10,R5,TR6,L1,V0,R2,i45,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,new-scopem10,R5,TR6,L1,V4,R7,R8,R9,R10,R2,i46,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template6,enter!m10,R5,TR6,L1,V3,R11,R12,R13,R2,i47,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template7,upd-fn!m10,R5,TR6,L1,V4,R14,R15,R9,R16,R2,i48,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template8,upd-var!m10,R5,TR6,L1,V4,R14,R15,R9,R16,R2,i49,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template4,kidsm10,R5,TR6,L1,V1,R17,R2,i50,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,node-textm10,R5,TR6,L1,MV1,R17,m2,R18,R19,R2,i51,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template7,*tmpls*m8,R20,TR2,i61,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template13,*provisional*m8,R20,TR2,i63,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,same-arg?m10,R5,TR6,L1,V2,R21,R22,R2,i65,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,*scanned*m8,R20,TR2,i66,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,*instance*m8,R20,TR2,i67,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template4,tmplm8,R6,L1,V1,R23,R2,i69,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,upd-tmpl!m10,R5,TR6,L1,V4,R23,R15,R9,R16,R2,i70,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,dependent?m10,R6,L1,V1,R24,R0,s56,Whether a type or argument names a template's parameter.R2,i72,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,tc-arg-formsm12,R5,TR6,L1,V1,R25,R0,s222,A type-constraint's template arguments as written (`__eligible_tuple_like<tuple> _UTuple`: [tuple]), as forms, from the\n  parameter's text: the arguments after the concept's last name; nil when the text does not show them.R2,i83,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template7,tparamsm12,R5,TR6,L1,V1,R17,R0,s62,The template parameters of a template declaration node's kids.R2,i92,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template17,strip-tparam-kidsm10,R5,TR6,L1,V1,R17,R2,i117,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,param-typem10,R5,TR6,L1,V2,R11,R26,R2,i123,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,arg-entitym8,R27,TR2,i125,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,*unstable*m10,R20,TR27,TR2,i126,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,bind-scopem12,R5,TR6,L1,V4,R8,R28,R16,R29,R0,s189,A scope of the parameters `params` bound to `args` (a type each, or {:val n}) over `parent`; with `sym-tid` (and no\n  args) each parameter stands for itself, as in the template's signature.R2,i128,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R26,R21,R0,s211,The entity a parameter's name stands for when bound to the argument `a`: a type, a value (an enumerator's\n  entity), a non-type parameter or a dependent expression of a signature, a pack of them ({:pack [...]}).R2,i143,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,resolve-argm8,R27,TR2,i162,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,var-valuem12,R5,TR6,L1,V2,R30,R24,R0,s213,cpp-s4: a constant variable's value as its type holds it, its initializer converted ([conv.integral]/3:\n  `static const _Value __max = ... : ~(_Value)0;` of __numeric_traits_integer<unsigned char> is 255, not -1).R2,i164,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,const-entitym10,R5,TR6,L1,V2,R11,R31,R2,i170,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template15,member-constantm12,R5,TR6,L1,V2,R32,Myn2,nmm2,R18,R33,R0,s151,The constant `nm` of the class type `t` (X<T>::value), or, when `t` is dependent, the expression standing for it\n  ({:k :texpr :o :sr}, mangled sr...).R2,i181,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,binary-fnsv11,arbace.core15,bit-shift-rightv11,arbace.core18,unchecked-multiplyv11,arbace.core3,remv11,arbace.core6,bit-orv11,arbace.core4,quotv11,arbace.core18,unchecked-subtractv11,arbace.core7,bit-andv11,arbace.core14,bit-shift-leftv11,arbace.core7,bit-xorv11,arbace.core13,unchecked-addm8,R5,TR2,i195,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template5,two64r21,18446744073709551616Nm8,R5,TR2,i201,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template4,u64?m12,R5,TR6,L1,V1,R24,R0,s103,An unsigned 64-bit value above Long/MAX_VALUE, the one value of the text's evaluation held as a BigInt.R2,i203,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template3,lngm12,R5,TR6,L1,V1,R24,R0,s222,A value's 64-bit pattern as a long (an unsigned 64-bit BigInt wrapped: 18446744073709551615N is -1); a floating value\n  truncated toward zero ([conv.fpint]/1), one outside long's range (or a NaN) not a constant: a refusal.R2,i208,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template3,dblm12,R5,TR6,L1,V1,R24,R0,s128,A value as a double: a floating value as it is, an integer converted ([conv.fpint]/2; an unsigned 64-bit BigInt by\n  its value).R2,i219,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template6,falsy?m12,R5,TR6,L1,V1,R24,R0,s105,Whether a constant converts to false ([conv.bool]: zero, of an integer or a floating value; 0.5 is true).R2,i225,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template3,u64m12,R5,TR6,L1,V1,R24,R0,s113,A value as unsigned long long's ([conv.integral]/3: modulo 2^64), normalized: a long when it fits, else a BigInt.R2,i230,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template4,foldm12,R5,TR6,L1,V2,R34,R16,R0,s734,An operator applied to constants: its value, or (an operand dependent) the expression {:k :texpr :o o :args [...]}.\n  The values are exact integers, one representation (review 1111 #3, cpp-s5b): a long, or an unsigned 64-bit value above\n  Long/MAX_VALUE as a BigInt (`size_t(-1)`, `18446744073709551615ULL`, `0x8000000000000000`). An operand of that kind\n  makes the operation unsigned long long's, as the usual arithmetic conversions do ([expr.arith.conv]/1.5): the operands\n  taken modulo 2^64 and the result too, a comparison of the converted values; else 64-bit arithmetic wraps as sema's\n  const-int. A division by zero and a shift by a count outside 0..63 are not constants: refusals, never Java's\n  exceptions (review 1111 #5).R2,i236,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,cast-typesS9,s5,floats3,ints6,signeds4,longs5,shorts4,bools4,chars8,unsigneds6,doublem8,R5,TR2,i286,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template7,cast-tom12,R5,TR6,L1,V2,Myn2,tym2,R18,R33,R30,R0,s129,A constant converted to a builtin integral type named by its words (bool: 0 or 1; the others kept, the slice's\n  values fitting).R2,i288,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template16,expand-type-packm8,R27,TR2,i310,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,declval-nodem12,R5,TR6,L1,V1,R32,R0,s110,An expression of type `t` as std::declval<T>() is: an lvalue for T&, an xvalue for T&& and for an object type.R2,i317,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template6,works?m10,R5,TR6,L1,V1,R15,R2,i324,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template15,complete-class?m10,R5,TR6,L1,V1,R32,R2,i326,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,object-type?m10,R5,TR6,L1,V1,R32,R2,i328,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template14,*constructing*m8,R20,TR2,i330,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template20,trait-constructible?m10,R5,TR6,L1,V3,R11,R32,R16,R2,i332,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,walk-refsm8,R27,TR2,i346,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template14,calls-nothrow?m12,R5,TR6,L1,V1,R24,R0,s196,Whether every function an analyzed initialization or expression calls is noexcept (an implicit or defaulted special\n  member counted so: the trivial and the implicit ones of the samples' classes).R2,i348,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template28,trait-nothrow-constructible?m10,R5,TR6,L1,V3,R11,R32,R16,R2,i357,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template25,trait-nothrow-assignable?m10,R5,TR6,L1,V3,R11,R32,R35,R2,i365,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template18,trait-convertible?m10,R5,TR6,L1,V3,R11,R36,R37,R2,i369,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template17,trait-assignable?m10,R5,TR6,L1,V3,R11,R32,R35,R2,i375,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template14,trivial-class?m10,R5,TR6,L1,V2,R32,R38,R2,i378,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template18,trivially-default?m10,R5,TR6,L1,V1,R14,R2,i382,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,value-traitsm8,R5,TR2,i389,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template5,decaym10,R5,TR6,L1,V1,R32,R2,i467,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,type-traitsm8,R5,TR2,i473,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template16,split-top-commasm12,R5,TR6,L1,V1,Myn1,tm2,R18,R33,R0,s60,A text split at its commas outside brackets and parentheses.R2,i488,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,trait-name?m8,R6,L1,V1,R24,R2,i500,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,trait-argsm10,R5,TR6,L1,V2,R11,R39,R2,i502,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,trait-valuem10,R6,L1,V3,R11,Myn2,nmm2,R18,R33,R39,R0,s129,A value trait's constant (0 or 1) of its type arguments' forms, or a dependent {:k :texpr :o :trait} in a template's\n  signature.R2,i509,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,trait-typem10,R6,L1,V3,R11,Myn2,nmm2,R18,R33,R39,R0,s114,A transform trait's type of its type arguments' forms (__remove_cv(T), __decay(T), ...), dependent in a signature.R2,i518,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template14,template-name?m10,R5,TR6,L1,V2,R11,Myn2,nmm2,R18,R33,R2,i527,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template24,qualified-template-name?m12,R5,TR6,L1,V2,R11,R40,R0,s203,cpp-s4: whether the qualified name `ps` (its parts) names a template: `__gnu_cxx::__int_traits<_IntType>::__max` in\n  parse_numbers.h's _Select_int_base, written in another namespace than the template's.R2,i531,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template17,static-call-valuem8,R27,TR2,i540,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,packs-namedm8,R27,TR2,i540,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,const-formm8,R27,TR2,i540,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,eval-textm10,R6,L1,V2,R11,Myn1,sm2,R18,R33,R0,s314,The value of a constant expression's text in `scope` (integers, the operators, parentheses, the conditional\n  operator, names of constants and of non-type parameters, members of classes (X<T>::value), sizeof(type), true and\n  false): a number, or in a template's signature the dependent expression standing for it.R2,i542,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,resolve-argsm8,R27,TR2,i734,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template13,complete-argsm8,R27,TR2,i734,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template14,instantiate-fnm8,R27,TR2,i734,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template17,var-template-instm8,R27,TR2,i734,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template17,written-qualifierm8,R27,TR2,i734,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R11,R41,R0,s377,The value of a call without arguments of a constexpr static member function, or of a specialization of a static\n  member function template given its template arguments (`_PCCP::template _ConstructiblePair<_U1, _U2>()`, libstdc++'s\n  C++17 std::pair constructors' enable_if conditions; G5c: libsupc++'s eh_alloc.cc); dependent in a pattern's signature\n  ({:k :texpr :o :mcall}).R2,i736,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R11,R42,R0,s313,A static member call's qualifier as written, when it is a typedef's name (`_PCCP`) or an alias template's\n  specialization (`_PCCFP<_U1, _U2>`): {:name s} or {:name s :args [...]} (the arguments resolved, as written); nil for a\n  class's own name, a template parameter or a qualified name (mangled from the type).R2,i771,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template13,concept-namedm12,R5,TR6,L1,V2,R11,R12,R0,s92,The entry of the concept the name `nm` (a symbol, n/C qualified) denotes in `scope`, or nil.R2,i786,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template18,concept-satisfied?m8,R27,TR2,i793,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R11,R15,R0,s104,A constant of a template argument's or array bound's form: a number, a name, X<T>::member, (cpp/text s).R2,i795,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,value-argm10,R5,TR6,L1,V3,R30,Myn1,_m2,R18,R33,R32,R2,i860,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template15,template-arg-ofm12,R5,TR6,L1,V2,R11,R15,R0,s138,A template template argument (a class template's name): {:tmpl tid :name :path}, or a signature's template template\n  parameter {:k :ttp}.R2,i863,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template8,decl-argm12,R5,TR6,L1,V3,R11,R43,R15,R0,s257,The argument of a pointer or reference non-type parameter of type `pt` ([temp.arg.nontype]): a function or a\n  variable named (&F, F, &v, v for a reference), {:decl [:fn|:var id] :ty pt :mangled s}, or a null pointer; in a\n  signature a parameter passed on.R2,i896,R3,i1,R4,s22,arbace/cpp/template.aem10,R6,L1,V5,R11,R26,R15,R9,V1,R44,R0,s60,A template argument's form for the parameter `p` in `scope`.R2,i942,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template8,node-argm12,R5,TR6,L1,V3,R11,R26,R17,R0,s88,A TemplateArgument node's argument for the parameter `p` (an explicit specialization's).R2,i953,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template15,inherit-defaultm12,R5,TR6,L1,V4,R26,R36,R37,Myn1,im2,R18,R45,R0,s415,The parameter `p` (the `i`th of the declaration `to`) with the default argument of the `i`th of the declaration `from`;\n  written in terms of `from`'s parameters, which it keeps as :dparams when their names differ from `to`'s\n  ([temp.param]/12: `template <typename _CharT, typename = char_traits<_CharT>> struct basic_string;` then\n  `template <typename, typename, typename> struct basic_string {...}`, pr77550.C).R2,i963,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R32,R46,R0,s195,The arguments `given` (a vector, maybe shorter) completed by the template's default arguments, each resolved in a\n  scope binding the parameters before it ([temp.arg]/9); nil when one is missing.R2,i974,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template12,form-symbolsm10,R5,TR6,L1,V1,R15,R2,i1006,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V2,R11,R47,R0,s84,The packs among the entities the names `nms` denote in `scope`: [[name entity] ...].R2,i1014,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template11,elementwisem12,R5,TR6,L1,V2,R11,R48,R0,s85,The scopes over `scope` binding each pack of `packs` to its i-th element, for each i.R2,i1022,R3,i1,R4,s22,arbace/cpp/template.aem10,R6,L1,V2,R11,R49,R0,s207,The :pack-expand hook: the types a pack expansion's pattern (Ts&... in a parameter list or argument list) stands\n  for, one per element of its packs; in a template's signature, the pattern as {:k :pack-exp}.R2,i1033,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template16,expand-expr-packm10,R6,L1,V2,R50,R17,R0,s107,The :expand-pack hook: a PackExpansionExpr's pattern analyzed once per element of the packs its text names.R2,i1044,R3,i1,R4,s22,arbace/cpp/template.aem12,R5,TR6,L1,V4,R11,R32,R39,R51,R0,s220,Template argument forms for the template `t`: each resolved for its parameter, pack expansions spliced, the\n  arguments of a trailing parameter pack gathered into {:pack [...]} (always with `group-all`, else when given).R2,i1053,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,tparam-of?m10,R5,TR6,L1,V2,R24,R23,R2,i1092,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template6,arr-cvm10,R5,TR6,L1,V1,R32,R2,i1095,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template5,qualsm10,R5,TR6,L1,V1,R32,R2,i1096,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template9,unq-arraym10,R5,TR6,L1,V1,R32,R2,i1097,R3,i1,R4,s22,arbace/cpp/template.aev19,arbace.cpp.template10,with-qualsm10,R5,TR6,L1,V2,R32,R52,R2,i1098,R3,i1,R4,s22,arbace/cpp/template.ae")

var Lit_890 *jrt.String = jrt.Intern("arbace.cpp.template$eval960000004$loading__1927001464__auto____960000005")

var Lit_891 *jrt.String = jrt.Intern("arbace.cpp.template$eval960000008$fn__960000009")

var Lit_892 *jrt.String = jrt.Intern("arbace.cpp.template$next_id")

var Lit_893 *jrt.String = jrt.Intern("arbace.cpp.template$new_scope")

var Lit_894 *jrt.String = jrt.Intern("arbace.cpp.template$enter_BANG_")

var Lit_895 *jrt.String = jrt.Intern("arbace.cpp.template$upd_fn_BANG_")

var Lit_896 *jrt.String = jrt.Intern("arbace.cpp.template$upd_var_BANG_")

var Lit_897 *jrt.String = jrt.Intern("arbace.cpp.template$kids")

var Lit_898 *jrt.String = jrt.Intern("arbace.cpp.template$node_text")

var Lit_899 *jrt.String = jrt.Intern("arbace.cpp.template$same_arg_QMARK_")

var Lit_900 *jrt.String = jrt.Intern("arbace.cpp.template$tmpl")

var Lit_901 *jrt.String = jrt.Intern("arbace.cpp.template$upd_tmpl_BANG_")

var Lit_902 *jrt.String = jrt.Intern("arbace.cpp.template$dependent_QMARK_")

var Lit_903 *jrt.String = jrt.Intern("arbace.cpp.template$tc_arg_forms")

var Lit_904 *jrt.String = jrt.Intern("arbace.cpp.template$tparams")

var Lit_905 *jrt.String = jrt.Intern("arbace.cpp.template$strip_tparam_kids")

var Lit_906 *jrt.String = jrt.Intern("arbace.cpp.template$param_type")

var Lit_907 *jrt.String = jrt.Intern("arbace.cpp.template$bind_scope")

var Lit_908 *jrt.String = jrt.Intern("arbace.cpp.template$arg_entity")

var Lit_909 *jrt.String = jrt.Intern("arbace.cpp.template$var_value")

var Lit_910 *jrt.String = jrt.Intern("arbace.cpp.template$const_entity")

var Lit_911 *jrt.String = jrt.Intern("arbace.cpp.template$member_constant")

var Lit_912 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000103")

var Lit_913 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000105")

var Lit_914 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000107")

var Lit_915 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000109")

var Lit_916 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000111")

var Lit_917 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000113")

var Lit_918 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000115")

var Lit_919 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000117")

var Lit_920 *jrt.String = jrt.Intern("arbace.cpp.template$u64_QMARK_")

var Lit_921 *jrt.String = jrt.Intern("arbace.cpp.template$lng")

var Lit_922 *jrt.String = jrt.Intern("arbace.cpp.template$dbl")

var Lit_923 *jrt.String = jrt.Intern("arbace.cpp.template$falsy_QMARK_")

var Lit_924 *jrt.String = jrt.Intern("arbace.cpp.template$u64")

var Lit_925 *jrt.String = jrt.Intern("arbace.cpp.template$fold")

var Lit_926 *jrt.String = jrt.Intern("arbace.cpp.template$cast_to")

var Lit_927 *jrt.String = jrt.Intern("arbace.cpp.template$declval_node")

var Lit_928 *jrt.String = jrt.Intern("arbace.cpp.template$works_QMARK_")

var Lit_929 *jrt.String = jrt.Intern("arbace.cpp.template$complete_class_QMARK_")

var Lit_930 *jrt.String = jrt.Intern("arbace.cpp.template$object_type_QMARK_")

var Lit_931 *jrt.String = jrt.Intern("arbace.cpp.template$trait_constructible_QMARK_")

var Lit_932 *jrt.String = jrt.Intern("arbace.cpp.template$calls_nothrow_QMARK_")

var Lit_933 *jrt.String = jrt.Intern("arbace.cpp.template$trait_nothrow_constructible_QMARK_")

var Lit_934 *jrt.String = jrt.Intern("arbace.cpp.template$trait_nothrow_assignable_QMARK_")

var Lit_935 *jrt.String = jrt.Intern("arbace.cpp.template$trait_convertible_QMARK_")

var Lit_936 *jrt.String = jrt.Intern("arbace.cpp.template$trait_assignable_QMARK_")

var Lit_937 *jrt.String = jrt.Intern("arbace.cpp.template$trivial_class_QMARK_")

var Lit_938 *jrt.String = jrt.Intern("arbace.cpp.template$trivially_default_QMARK_")

var Lit_939 *jrt.String = jrt.Intern("__has_virtual_destructor")

var Lit_940 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000188")

var Lit_941 *jrt.String = jrt.Intern("__has_trivial_destructor")

var Lit_942 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000195")

var Lit_943 *jrt.String = jrt.Intern("__is_union")

var Lit_944 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000203")

var Lit_945 *jrt.String = jrt.Intern("__is_convertible_to")

var Lit_946 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000209")

var Lit_947 *jrt.String = jrt.Intern("__reference_constructs_from_temporary")

var Lit_948 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000215")

var Lit_949 *jrt.String = jrt.Intern("__is_trivial")

var Lit_950 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000221")

var Lit_951 *jrt.String = jrt.Intern("__is_member_object_pointer")

var Lit_952 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000229")

var Lit_953 *jrt.String = jrt.Intern("__is_nothrow_convertible")

var Lit_954 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000235")

var Lit_955 *jrt.String = jrt.Intern("__is_unbounded_array")

var Lit_956 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000241")

var Lit_957 *jrt.String = jrt.Intern("__is_same_as")

var Lit_958 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000247")

var Lit_959 *jrt.String = jrt.Intern("__is_object")

var Lit_960 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000253")

var Lit_961 *jrt.String = jrt.Intern("__is_standard_layout")

var Lit_962 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000259")

var Lit_963 *jrt.String = jrt.Intern("__is_scalar")

var Lit_964 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000267")

var Lit_965 *jrt.String = jrt.Intern("__is_bounded_array")

var Lit_966 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000273")

var Lit_967 *jrt.String = jrt.Intern("__is_convertible")

var Lit_968 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000279")

var Lit_969 *jrt.String = jrt.Intern("__reference_converts_from_temporary")

var Lit_970 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000285")

var Lit_971 *jrt.String = jrt.Intern("__is_trivially_copyable")

var Lit_972 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000291")

var Lit_973 *jrt.String = jrt.Intern("__is_abstract")

var Lit_974 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000299")

var Lit_975 *jrt.String = jrt.Intern("__is_member_pointer")

var Lit_976 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000307")

var Lit_977 *jrt.String = jrt.Intern("__is_assignable")

var Lit_978 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000313")

var Lit_979 *jrt.String = jrt.Intern("__is_function")

var Lit_980 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000319")

var Lit_981 *jrt.String = jrt.Intern("__is_lvalue_reference")

var Lit_982 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000325")

var Lit_983 *jrt.String = jrt.Intern("__is_rvalue_reference")

var Lit_984 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000331")

var Lit_985 *jrt.String = jrt.Intern("__is_polymorphic")

var Lit_986 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000337")

var Lit_987 *jrt.String = jrt.Intern("__is_signed")

var Lit_988 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000343")

var Lit_989 *jrt.String = jrt.Intern("__has_unique_object_representations")

var Lit_990 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000349")

var Lit_991 *jrt.String = jrt.Intern("__is_const")

var Lit_992 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000355")

var Lit_993 *jrt.String = jrt.Intern("__is_nothrow_constructible")

var Lit_994 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000363")

var Lit_995 *jrt.String = jrt.Intern("__reference_binds_to_temporary")

var Lit_996 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000368")

var Lit_997 *jrt.String = jrt.Intern("__is_pointer")

var Lit_998 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000371")

var Lit_999 *jrt.String = jrt.Intern("__is_volatile")

var Lit_1000 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000377")

var Lit_1001 *jrt.String = jrt.Intern("__is_literal_type")

var Lit_1002 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000385")

var Lit_1003 *jrt.String = jrt.Intern("__is_trivially_assignable")

var Lit_1004 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000391")

var Lit_1005 *jrt.String = jrt.Intern("__is_class")

var Lit_1006 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000397")

var Lit_1007 *jrt.String = jrt.Intern("__is_trivially_constructible")

var Lit_1008 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000403")

var Lit_1009 *jrt.String = jrt.Intern("__is_void")

var Lit_1010 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000411")

var Lit_1011 *jrt.String = jrt.Intern("__is_nothrow_assignable")

var Lit_1012 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000417")

var Lit_1013 *jrt.String = jrt.Intern("__is_pod")

var Lit_1014 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000423")

var Lit_1015 *jrt.String = jrt.Intern("__is_same")

var Lit_1016 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000431")

var Lit_1017 *jrt.String = jrt.Intern("__is_unsigned")

var Lit_1018 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000437")

var Lit_1019 *jrt.String = jrt.Intern("__is_member_function_pointer")

var Lit_1020 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000443")

var Lit_1021 *jrt.String = jrt.Intern("__is_scoped_enum")

var Lit_1022 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000449")

var Lit_1023 *jrt.String = jrt.Intern("__is_arithmetic")

var Lit_1024 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000455")

var Lit_1025 *jrt.String = jrt.Intern("__is_fundamental")

var Lit_1026 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000461")

var Lit_1027 *jrt.String = jrt.Intern("__is_enum")

var Lit_1028 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000467")

var Lit_1029 *jrt.String = jrt.Intern("__is_reference")

var Lit_1030 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000473")

var Lit_1031 *jrt.String = jrt.Intern("__is_integral")

var Lit_1032 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000479")

var Lit_1033 *jrt.String = jrt.Intern("__is_trivially_destructible")

var Lit_1034 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000485")

var Lit_1035 *jrt.String = jrt.Intern("__is_nothrow_destructible")

var Lit_1036 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000493")

var Lit_1037 *jrt.String = jrt.Intern("__is_constructible")

var Lit_1038 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000499")

var Lit_1039 *jrt.String = jrt.Intern("__is_floating_point")

var Lit_1040 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000505")

var Lit_1041 *jrt.String = jrt.Intern("__is_final")

var Lit_1042 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000511")

var Lit_1043 *jrt.String = jrt.Intern("__is_array")

var Lit_1044 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000517")

var Lit_1045 *jrt.String = jrt.Intern("__is_base_of")

var Lit_1046 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000523")

var Lit_1047 *jrt.String = jrt.Intern("__is_destructible")

var Lit_1048 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000530")

var Lit_1049 *jrt.String = jrt.Intern("__is_empty")

var Lit_1050 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000536")

var Lit_1051 *jrt.String = jrt.Intern("__is_aggregate")

var Lit_1052 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000542")

var Lit_1053 *jrt.String = jrt.Intern("arbace.cpp.template$decay")

var Lit_1054 *jrt.String = jrt.Intern("__remove_reference")

var Lit_1055 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000549")

var Lit_1056 *jrt.String = jrt.Intern("__add_lvalue_reference")

var Lit_1057 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000555")

var Lit_1058 *jrt.String = jrt.Intern("__remove_cvref")

var Lit_1059 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000561")

var Lit_1060 *jrt.String = jrt.Intern("__remove_cv")

var Lit_1061 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000567")

var Lit_1062 *jrt.String = jrt.Intern("__add_rvalue_reference")

var Lit_1063 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000573")

var Lit_1064 *jrt.String = jrt.Intern("__decay")

var Lit_1065 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000579")

var Lit_1066 *jrt.String = jrt.Intern("__remove_extent")

var Lit_1067 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000585")

var Lit_1068 *jrt.String = jrt.Intern("__underlying_type")

var Lit_1069 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000591")

var Lit_1070 *jrt.String = jrt.Intern("__remove_volatile")

var Lit_1071 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000597")

var Lit_1072 *jrt.String = jrt.Intern("__remove_all_extents")

var Lit_1073 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000603")

var Lit_1074 *jrt.String = jrt.Intern("__remove_pointer")

var Lit_1075 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000609")

var Lit_1076 *jrt.String = jrt.Intern("__add_pointer")

var Lit_1077 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000615")

var Lit_1078 *jrt.String = jrt.Intern("__remove_const")

var Lit_1079 *jrt.String = jrt.Intern("arbace.cpp.template$fn__960000621")

var Lit_1080 *jrt.String = jrt.Intern("arbace.cpp.template$split_top_commas")

var Lit_1081 *jrt.String = jrt.Intern("arbace.cpp.template$trait_name_QMARK_")

var Lit_1082 *jrt.String = jrt.Intern("arbace.cpp.template$trait_args")

var Lit_1083 *jrt.String = jrt.Intern("arbace.cpp.template$trait_value")

var Lit_1084 *jrt.String = jrt.Intern("arbace.cpp.template$trait_type")

var Lit_1085 *jrt.String = jrt.Intern("arbace.cpp.template$template_name_QMARK_")

var Lit_1086 *jrt.String = jrt.Intern("arbace.cpp.template$qualified_template_name_QMARK_")

var Lit_1087 *jrt.String = jrt.Intern("arbace.cpp.template$eval_text")

var Lit_1088 *jrt.String = jrt.Intern("arbace.cpp.template$static_call_value")

var Lit_1089 *jrt.String = jrt.Intern("arbace.cpp.template$written_qualifier")

var Lit_1090 *jrt.String = jrt.Intern("arbace.cpp.template$concept_named")

var Lit_1091 *jrt.String = jrt.Intern("arbace.cpp.template$const_form")

var Lit_1092 *jrt.String = jrt.Intern("arbace.cpp.template$value_arg")

var Lit_1093 *jrt.String = jrt.Intern("arbace.cpp.template$template_arg_of")

var Lit_1094 *jrt.String = jrt.Intern("arbace.cpp.template$decl_arg")

var Lit_1095 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_arg")

var Lit_1096 *jrt.String = jrt.Intern("arbace.cpp.template$node_arg")

var Lit_1097 *jrt.String = jrt.Intern("arbace.cpp.template$inherit_default")

var Lit_1098 *jrt.String = jrt.Intern("arbace.cpp.template$complete_args")

var Lit_1099 *jrt.String = jrt.Intern("arbace.cpp.template$form_symbols")

var Lit_1100 *jrt.String = jrt.Intern("arbace.cpp.template$packs_named")

var Lit_1101 *jrt.String = jrt.Intern("arbace.cpp.template$elementwise")

var Lit_1102 *jrt.String = jrt.Intern("arbace.cpp.template$expand_type_pack")

var Lit_1103 *jrt.String = jrt.Intern("arbace.cpp.template$expand_expr_pack")

var Lit_1104 *jrt.String = jrt.Intern("arbace.cpp.template$resolve_args")

var Lit_1105 *jrt.String = jrt.Intern("arbace.cpp.template$tparam_of_QMARK_")

var Lit_1106 *jrt.String = jrt.Intern("arbace.cpp.template$arr_cv")

var Lit_1107 *jrt.String = jrt.Intern("arbace.cpp.template$quals")

var Lit_1108 *jrt.String = jrt.Intern("arbace.cpp.template$unq_array")

var Lit_1109 *jrt.String = jrt.Intern("arbace.cpp.template$with_quals")

var Lit_1110 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,Pyn1,Akn3,dockn4,linekn6,columnkn4,fileyn1,tkn8,declaredkn7,dynamicyn1,byn1,iyn1,ayn1,xyn3,tidyn1,pyn2,psyn2,asyn3,tdfyn3,pokkn3,tagyn6,Stringyn5,scopeyn1,eyn8,explicityn4,argsyn2,ftyn4,tid2yn3,p2syn3,p1syn1,nyn7,mappingyn5,depthyn1,fyn1,Qyn4,tid1yn2,fayn2,fbyn1,&yn5,nargsyn4,nodeyn6,paramsyn5,bargsyn9,explicit?yn4,cid0yn2,idyn5,formsyn2,ptyn2,p1yn2,p2yn3,cidyn2,esyn2,sfyn2,tfyn2,nfyn2,cnyn2,qtyn1,oyn2,pbyn1,cyn5,args0yn3,fidyn7,patternyn2,nmyn3,ctxyn6,calleev19,arbace.cpp.template25,inconsistent-or-superset?m12,R0,TR1,L1,V2,R2,R3,R4,s65,hasInconsistentOrSupersetQualifiersOf: P has a qualifier A lacks.R5,i1100,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,canonicalm10,R0,TR1,L1,V1,R8,R5,i1104,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,unspelledm12,R0,TR1,L1,V1,R8,R4,s111,A type without its template-ids' spellings (:written, :qual): functionally equivalent signatures compare equal.R5,i1110,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,deduce-by-type-matchm8,R9,TR5,i1117,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,*satisfaction*m8,R10,TR5,i1118,R6,i1,R7,s22,arbace/cpp/template.aem8,R10,TR5,i1119,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template8,*unsure*m8,R10,TR5,i1127,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template6,*sure*m8,R10,TR5,i1128,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template7,unsure!m10,R0,TR1,L1,V0,R5,i1129,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template5,sure!m10,R0,TR1,L1,V0,R5,i1130,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,bind-arg!m12,R0,TR1,L1,V3,R11,R12,R13,R4,s100,checkDeducedTemplateArguments: the parameter i deduced as `a`, consistent with an earlier deduction.R5,i1132,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,subst-valuem12,R0,TR1,L1,V3,R14,R11,R15,R4,s111,A dependent value with the parameters of `tid` the bindings give substituted (an operator over numbers folded).R5,i1138,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,dependent-on?m10,R0,TR1,L1,V2,R14,R15,R5,i1148,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template10,match-argsm8,R9,TR5,i1150,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,match-argm12,R0,TR1,L1,V4,R11,R15,R16,R13,R4,s215,One template argument of a signature (or a partial specialization's pattern) against an argument: a parameter\n  bound, a value compared, a non-deduced expression checked, a pack matched element-wise, a type deduced.R5,i1152,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,pack-pattern?m12,R0,TR1,L1,V2,R16,R15,R4,s90,A trailing pack expansion of an argument list: a parameter pack of tid, or {:k :pack-exp}.R5,i1166,R6,i1,R7,s22,arbace/cpp/template.aem10,R1,L1,V4,R11,R15,R17,R18,R4,s168,Argument lists matched ([temp.deduct.type]/9-10): a trailing pack expansion takes the remaining arguments, each\n  pack it names bound to the elements deduced from them.R5,i1171,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,deduce-template-specm12,R0,TR1,L1,V5,R11,R15,R2,R3,R19,R4,s254,DeduceTemplateSpecArguments: P a template-id of the template, A a class; the arguments matched pairwise\n  (TDF_None), and with :derived-class, failing that, A's bases searched (DeduceTemplateBases, [temp.deduct.call]/4.3:\n  the deduction must be unique).R5,i1189,R6,i1,R7,s22,arbace/cpp/template.aem10,R1,L1,V6,R11,R15,R2,R3,R19,R20,R4,s478,DeduceTemplateArgumentsByTypeMatch (SemaTemplateDeduction.cpp at llvmorg-23.1.4), ported for the types of the\n  slice: P (a type with the parameters of the template `tid`) matched against A, the deductions bound in the atom `b`\n  ({index argument}); true on success. `tdf` the deduction flags (#{:skip-non-dependent :param-with-reference\n  :ignore-qualifiers :derived-class}), `pok` :call while partially ordering a call's parameters ([temp.deduct.partial]\n  /5-/9), else :none.R5,i1222,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,deduce-typem12,R0,TR1,L1,V4,R11,R15,R2,R3,R4,s34,TDF_None outside partial ordering.R5,i1304,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,sym-scopem10,R0,TR1,L1,V1,R8,R5,i1306,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template7,sym-sigm10,R1,L1,V1,R8,R4,s104,A function template's signature with its own parameters (the type its specializations are mangled with).R5,i1308,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,finish-deductionm12,R0,TR1,L1,V2,R8,R11,R4,s173,The bindings as the template's argument list: the deduced bound of an array ({:bound}) typed by its parameter,\n  defaults for the rest; nil when a parameter stays undeduced.R5,i1322,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,explicit-argsm12,R0,TR1,L1,V3,R8,Myn4,textm2,R21,R22,R23,R4,s109,The explicit template arguments written after a name (`f<int, 3>`), resolved for the template `t` in `scope`.R5,i1349,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template21,forwarding-reference?m12,R0,TR1,L1,V2,R2,R15,R4,s96,isForwardingReference: an rvalue reference to a cv-unqualified parameter of the template itself.R5,i1358,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template19,simple-template-id?m10,R0,TR1,L1,V1,R8,R5,i1363,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,adjust-for-deductionm12,R0,TR1,L1,V3,R2,R24,R15,R4,s154,AdjustFunctionParmAndArgTypesForDeduction ([temp.deduct.call]/2-/4), ported: [P A tdf] for the parameter type P\n  and the argument expression `e`, or nil.R5,i1365,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template10,tparams-inm10,R0,TR1,L1,V2,R2,R15,R5,i1388,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,deducible-tparamsm12,R0,TR1,L1,V2,R2,R15,R4,s137,cpp-s4: the template parameters of `tid` that `P` names outside non-deduced contexts (a dependent member type's\n  qualifier, X<T>::type).R5,i1391,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,deduce-callm10,R1,L1,V3,R8,R25,R26,R4,s287,DeduceTemplateArguments for a call ([temp.deduct.call]): the template arguments of the function template `t` for\n  the call's typed arguments after the explicit ones, each parameter's P and A adjusted (adjust-for-deduction) and\n  matched (deduce-by-type-match); nil when deduction fails.R5,i1403,R6,i1,R7,s22,arbace/cpp/template.aem8,R9,TR5,i1478,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,fnaddr-specsm10,R1,L1,V2,R24,R27,R4,s263,The specializations of an overload set's function templates whose types match the function type `ft` the set's address\n  is taken for ([over.over]/2, [temp.deduct.funcaddr]: each template's function type deduced against `ft`; G5: std::endl\n  given to operator<<).R5,i1480,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template24,at-least-as-specialized?m12,R0,TR1,L1,V3,R28,R29,R30,R4,s210,isAtLeastAsSpecializedAs for a call: the template tid2's parameters deduced from tid1's, pair by pair, with\n  TDF_None in the partial ordering of a call (the references' and qualifiers' rules inside the match).R5,i1499,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template10,concept-ofm8,R9,TR5,i1515,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,concept-refm12,R0,TR1,L1,V2,R23,R31,R4,s187,The concept a constraint's node names (a concept-id, `C<A...>`) with its arguments resolved in `scope`: [concept args],\n  or nil (not a concept-id, or arguments the slice cannot resolve).R5,i1521,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,normal-formm12,R0,TR1,L1,V4,R23,R31,R32,R33,R4,s551,The normal form of the constraint expression `n` in `scope` ([temp.constr.normal]/1): [:and P Q], [:or P Q], or an atomic\n  constraint [:atom KEY], a concept-id replaced by its concept's constraint-expression normalized with the parameter mapping\n  of its arguments; KEY the atom's expression (its position: the same expression of the same concept's definition) and\n  its mapping (the arguments, each template's own parameters by their index, canonical), so that two declarations' atoms\n  are identical only through a concept ([temp.constr.atomic]/2).R5,i1539,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template22,associated-constraintsm12,R0,TR1,L1,V1,R8,R4,s223,A function template's associated constraints ([temp.constr.decl]/3) as one normal form or nil: its type-constraints'\n  immediately-declared constraints in order, its requires-clause, its trailing requires-clause, conjoined.R5,i1557,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template3,dnfm10,R0,TR1,L1,V1,R34,R5,i1573,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template3,cnfm10,R0,TR1,L1,V1,R34,R5,i1579,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,subsumes?m12,R0,TR1,L1,V2,R2,R35,R4,s317,[temp.constr.order]/1: P subsumes Q when every disjunctive clause of P's disjunctive normal form subsumes every\n  conjunctive clause of Q's conjunctive normal form, a clause subsuming another when an atom of the one is identical to\n  one of the other (clang's subsumes; a form of more than 64 clauses is not ordered).R5,i1585,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,more-constrained-fn?m10,R1,L1,V2,R36,R28,R4,s174,[temp.func.order]/6.2.2, [temp.constr.order]/2: the function template tid1's associated constraints subsume tid2's\n  and not the reverse (no constraints are subsumed by any).R5,i1594,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,more-specialized-fn?m10,R1,L1,V3,R36,R28,R31,R4,s107,getMoreSpecialized for a call with `n` arguments: tid1 at least as specialized as tid2 and not the reverse.R5,i1607,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template8,tiebreakm10,R1,L1,V4,R37,R38,R39,V1,R40,R4,s186,[over.match.best]/2.4-2.5 for two candidates no argument ranks apart: a non-template function over a template's\n  specialization; of two specializations, the more specialized template's.R5,i1625,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,attach-ool!m8,R9,TR5,i1658,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,attach-one!m8,R9,TR5,i1658,R6,i1,R7,s22,arbace/cpp/template.aem8,R9,TR5,i1658,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,name-pack-params!m8,R9,TR5,i1660,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,declare-instance!m12,R0,TR1,L2,V6,R8,R26,R41,R42,R43,R44,V7,R8,R26,R41,R42,R43,R44,R45,R4,s221,The class of the template `t` for `args` from the pattern node `node` in a scope binding `params` to `bargs`\n  (a partial specialization's or the primary's); `explicit?`: an explicit specialization (its members ordinary).R5,i1662,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,class-completed!m12,R0,TR1,L1,V1,R46,R4,s442,CP365 (a): the class `id` complete; each provisional instance that waited for it and for no other incomplete class is\n  made again in place (declare-instance! with its class id: the class's record, scope and members made afresh, the old\n  members' functions left unlisted), its partial specialization's out-of-line members attached again, and the classes'\n  layouts computed again on use (a class holding the instance had laid it out broken).R5,i1721,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template27,type-constraints-satisfied?m8,R9,TR5,i1754,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,partial-argsm12,R0,TR1,L1,V3,R23,R8,R47,R4,s590,A partial specialization's arguments as written after its name, resolved in `scope`, and completed by the primary\n  template's default arguments ([temp.spec.partial.general]/8 with [temp.arg.general]/9: `template<class X, class Y>\n  struct __common_ref_impl<X&, Y&&>` of `template<class A, class B, class = void> struct __common_ref_impl` is\n  <X&, Y&&, void>; cpp-s8: before, its two arguments never matched an instance's three, so common_reference_t<char&,\n  char&&> was <type_traits>' bullet 3's char&, and indirectly_readable<char*> false); as written when a default does not\n  resolve.R5,i1756,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,partial-matchm12,R0,TR1,L1,V2,R48,R26,R4,s106,The partial specialization `pt`'s parameters deduced from the arguments, or nil ([temp.class.spec.match]).R5,i1769,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template19,partial-constraintsm12,R0,TR1,L1,V1,R48,R4,s229,A class template partial specialization's associated constraints ([temp.constr.decl]/3) as one normal form or nil: its\n  parameters' type-constraints, then its requires-clause, as associated-constraints's for a function template.R5,i1806,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template25,more-constrained-partial?m10,R0,TR1,L1,V2,R49,R50,R5,i1821,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template25,more-specialized-partial?m12,R0,TR1,L1,V2,R49,R50,R4,s129,[temp.class.order]: the partial specialization p1 more specialized than p2 (p2's arguments deduced from p1's, not\n  the reverse).R5,i1832,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,*inst-depth*l0,m10,R10,TR5,i1846,R6,i1,R7,s22,arbace/cpp/template.aeR4,s139,CP368 (a): the class instantiations under way, nested (clang's -ftemplate-depth, 1024 by default:\n  err_template_recursion_depth_exceeded).v19,arbace.cpp.template18,instantiate-class*m8,R9,TR5,i1851,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,select-instance!m8,R9,TR5,i1851,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,incomplete-instance!m8,R9,TR5,i1851,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,instantiate-classm10,R1,L1,V2,R15,R26,R4,s479,The class of the class template `tid` for the complete arguments `args`: an explicit specialization's, the most\n  specialized matching partial specialization's, or the primary template's ([temp.spec.partial.match]). CP368 (a): at\n  most 1024 instantiations nested, as clang's -ftemplate-depth; the analysis' stack may end first (about 900 on the tools'\n  host's thread), so the outermost one turns a StackOverflowError under it into the same refusal, a diagnostic, not a\n  crash.R5,i1853,R6,i1,R7,s22,arbace/cpp/template.aem10,R0,TR1,L1,V2,R15,R26,R5,i1868,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V3,R8,R26,R45,R4,s216,The class of the template `t` for `args`, its definition chosen ([temp.spec.partial.match]) and declared; `cid0` the class\n  id to make it under (CP372 (a): an incomplete instance completed in place), else a new one.R5,i1885,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R8,R26,R4,s607,CP372 (a): a specialization of a class template not defined yet, named in the main file (prov2.C's `using ctx = Ctx<int,\n  short>;` before Ctx's definition): an incomplete class ([temp.inst]/2: naming it does not instantiate it), cached as the\n  template's instance and completed in place, the same class id, when the template's definition arrives (template-defined!).\n  Before, \"an incomplete class template\" and CP338's retry of the typedef, which a later use of the alias's name did not\n  wait for. The headers keep their retry (sema's *retry*): only while the main file is declared (*main-retry* bound).R5,i1912,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,drop-layouts!m10,R0,TR1,L1,V0,R5,i1930,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template18,complete-instance!m12,R0,TR1,L1,V3,R8,R51,R34,R4,s291,CP372 (a): the incomplete instance `cid` of `t` for `args` made in place by `f` (its definition chosen now, or an explicit\n  specialization's), out of the waiting set; the layouts computed again on use. A refusal leaves it incomplete (a use that\n  needs it complete refuses then, as before).R5,i1933,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template19,incomplete-waiting?m10,R0,TR1,L1,V2,R15,R51,R5,i1946,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,template-defined!m12,R0,TR1,L1,V1,R15,R4,s89,CP372 (a): the class template `tid` defined; its incomplete instances completed in place.R5,i1949,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,tmpl-of-entitym10,R0,TR1,L1,V1,R52,R5,i1957,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,*alias-node*m8,R10,TR5,i1961,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,type-pack-elementm12,R0,TR1,L1,V2,R23,R47,R4,s350,clang's builtin template __type_pack_element<N, T...> (BuiltinTemplateDecl BTK__type_pack_element: the Nth type of the\n  pack, N < sizeof...(T)), which <bits/utility.h>'s _Nth_type uses when __has_builtin answers 1 (cpp/target's clang\n  half, CP248 (a)); dependent in a signature. CP332 (a): std::get<I>(tuple) and every tuple_element<I, tuple<...>>.R5,i1963,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,template-idm8,R9,TR5,i1981,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,make-integer-seqm12,R0,TR1,L1,V2,R23,V3,R53,R54,R55,R4,s245,clang's builtin template __make_integer_seq<Seq, T, N> (BTK__make_integer_seq): Seq<T, 0, 1, ..., N-1>, which\n  <bits/utility.h> uses for std::make_integer_sequence and _Build_index_tuple when __has_builtin answers 1; dependent\n  in a signature.R5,i1983,R6,i1,R7,s22,arbace/cpp/template.aem10,R1,L1,V2,R23,R34,R4,s198,The type a template-id form (<> name args...) names in `scope`: the class template's specialization for the\n  resolved arguments (instantiated), or a dependent {:k :tspec} in a template's signature.R5,i2005,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,header-paramsm12,R0,TR1,L1,V1,Myn4,textm2,R21,R22,R4,s59,The parameter names of the text's leading `template <...>`.R5,i2059,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,ool-qualifierm8,R9,TR5,i2077,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,ool-class-namem12,R0,TR1,L1,V1,R31,R4,s97,The class template a member's qualifier names (`Box<T>::` before the declaration's name), or nil.R5,i2079,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V1,R31,R4,s97,[name template-id-text] of the template-id a member's qualifier ends with (`Box<int>::`), or nil.R5,i2084,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,class-key-scopem12,R0,TR1,L1,V2,R23,R31,R4,s334,The scope a class template's (or its partial or explicit specialization's) declaration names with a\n  nested-name-specifier of plain names after its class-key (`template<...> class __format::_Arg_store {...}`, a member of\n  a namespace defined outside it, [class.pre]/3, [temp.spec.partial.general]/7; cpp-s5: <format>), else `scope`.R5,i2110,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template18,ool-class-templatem12,R0,TR1,L1,V3,R23,R56,R57,R4,s297,The class template an out-of-line member's qualifier `qt` (`any::_Manager_internal<_Tp>`, as ool-qualifier gives it)\n  names by `cn`: looked up unqualified, else through the qualifier's plain names before it (a member template of a class,\n  cpp-s5: <any>'s any::_Manager_internal<_Tp>::_S_manage).R5,i2125,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V5,R15,R51,R58,R39,V1,R59,R4,s208,An out-of-line member definition `o` given to the class `cid`, made from the primary (its arguments bound to the\n  header's names) or from a partial specialization (its deduced arguments, `pb` [params args]).R5,i2138,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template23,attach-member-template!m8,R9,TR5,i2188,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R15,R51,R4,s91,The out-of-line member definitions of the template `tid` given to its specialization `cid`.R5,i2190,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R8,R16,R4,s100,The concept a type-constraint names (its template entry), looked up in the template's scope, or nil.R5,i2199,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template8,tn-typesm12,R0,TR1,L1,V1,R8,R4,s366,For a function template (overloadable, so its arguments name their parameters when not natural:\n  ItaniumMangle.cpp's needToMangleTemplateParam): each non-type parameter's declared type when it is dependent\n  (template <class T, T v>: Tn T_), a constrained type parameter's concept (Tk <name>, clang 17's mangling of a\n  type-constraint without arguments), else nil.R5,i2208,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R60,R61,R4,s161,The satisfaction of the concept `c` (its template entry) for the arguments `args`, memoized (with whether it was\n  doubtful, CP281 (a): sema/*constraint-doubt*).R5,i2223,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V3,R8,R26,R23,R4,s129,Each constrained type parameter's concept satisfied by its argument ([temp.param]/4: the immediately-declared\n  constraint C<T>).R5,i2258,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R62,R63,R4,s170,A specialization's parameters from a function parameter pack (Ts... ts): their names, the pack's name standing for\n  them (:param-packs), the default arguments realigned.R5,i2279,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,template-depthm12,R0,TR1,L1,V1,R23,R4,s177,The template parameter depth of a template declared in `scope`: the number of enclosing class specializations of\n  templates (a member template of pair<int, double> at depth 1).R5,i2295,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,decltype-failed?m12,R0,TR1,L1,V1,R8,R4,s96,Whether the type `t` holds decltype-of's dependent stand-in for an operand that did not analyze.R5,i2304,R6,i1,R7,s22,arbace/cpp/template.aem10,R1,L1,V2,R15,R26,R4,s205,The specialization of the function template `tid` for the complete arguments `args`: its declaration (the pattern\n  declared in a scope binding the parameters; its definition analyzed when used), memoized.R5,i2310,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,adl-templatesm12,R0,TR1,L1,V2,R26,R64,R4,s99,The function templates named `nm` in the namespaces of the class arguments ([basic.lookup.argdep]).R5,i2377,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,too-few-args?m12,R0,TR1,L1,V2,R8,R26,R4,s572,CX12 (the checker): the call's arguments fewer than the function template's parameters that are no pack and have no\n  default argument ([over.match.viable]/2, the deduction's TooFewArguments). A parameter's default argument may be on any\n  declaration of the template ([dcl.fct.default]/4: a later declaration adds to the earlier ones'; CP375 (a), cpp-s9:\n  <format>'s `__do_vformat_to`, whose `const locale* = nullptr` is on its forward declaration only, the definition's pattern\n  without it); an explicit object parameter is the call's object, not one of its arguments.R5,i2391,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,call-candidatesm10,R1,L1,V3,R65,R66,R26,R4,s191,The specializations the function templates of a call's overload set deduce from its arguments (a template whose\n  deduction or substitution fails is not a candidate: [temp.deduct]/8, SFINAE).R5,i2410,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,explicit-fn-spec!m12,R0,TR1,L1,V4,R23,R31,R39,V1,R51,R4,s213,An explicit specialization of a function template (template <> R f<args>(...) {...}): its template found by name\n  and its arguments from the TemplateArgument kids and deduction from its type ([temp.deduct.decl]).R5,i2449,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,var-templatem10,R1,L1,V3,R65,R24,R31,R4,s188,The :var-template hook: the variable a variable template's name with its explicit arguments names (`v<int>`), its\n  specialization declared once; defined (linkonce_odr) only when odr-used.R5,i2483,R6,i1,R7,s22,arbace/cpp/template.aem8,R9,TR5,i2491,R6,i1,R7,s22,arbace/cpp/template.aem8,R9,TR5,i2491,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R8,R26,R4,s326,The variable template `t`'s specialization for the complete arguments `args`, declared once: the most specialized\n  matching partial specialization's (CP338 (a), [temp.spec.partial.match] as for a class; libstdc++'s\n  __detail::__variant::__accepted_index<_Tp, _Variant, void_t<_FUN_type<_Tp, _Variant>>>), else the primary's.R5,i2493,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template18,template-text-argsm12,R0,TR1,L1,V1,R31,R4,s114,A partial specialization's arguments as written after its name (struct Box<T*>), parsed from the main file's text.R5,i2517,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,var-text-argsm12,R0,TR1,L1,V1,R31,R4,s116,CP338 (a): a variable template's partial specialization's arguments as written after its name, parsed from its text.R5,i2541,R6,i1,R7,s22,arbace/cpp/template.ae")

var Lit_1111 *jrt.String = jrt.Intern("arbace.cpp.template$inconsistent_or_superset_QMARK_")

var Lit_1112 *jrt.String = jrt.Intern("arbace.cpp.template$canonical")

var Lit_1113 *jrt.String = jrt.Intern("arbace.cpp.template$unspelled")

var Lit_1114 *jrt.String = jrt.Intern("arbace.cpp.template$unsure_BANG_")

var Lit_1115 *jrt.String = jrt.Intern("arbace.cpp.template$sure_BANG_")

var Lit_1116 *jrt.String = jrt.Intern("arbace.cpp.template$bind_arg_BANG_")

var Lit_1117 *jrt.String = jrt.Intern("arbace.cpp.template$subst_value")

var Lit_1118 *jrt.String = jrt.Intern("arbace.cpp.template$dependent_on_QMARK_")

var Lit_1119 *jrt.String = jrt.Intern("arbace.cpp.template$match_arg")

var Lit_1120 *jrt.String = jrt.Intern("arbace.cpp.template$pack_pattern_QMARK_")

var Lit_1121 *jrt.String = jrt.Intern("arbace.cpp.template$match_args")

var Lit_1122 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_template_spec")

var Lit_1123 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_by_type_match")

var Lit_1124 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_type")

var Lit_1125 *jrt.String = jrt.Intern("arbace.cpp.template$sym_scope")

var Lit_1126 *jrt.String = jrt.Intern("arbace.cpp.template$sym_sig")

var Lit_1127 *jrt.String = jrt.Intern("arbace.cpp.template$finish_deduction")

var Lit_1128 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_args")

var Lit_1129 *jrt.String = jrt.Intern("arbace.cpp.template$forwarding_reference_QMARK_")

var Lit_1130 *jrt.String = jrt.Intern("arbace.cpp.template$simple_template_id_QMARK_")

var Lit_1131 *jrt.String = jrt.Intern("arbace.cpp.template$adjust_for_deduction")

var Lit_1132 *jrt.String = jrt.Intern("arbace.cpp.template$tparams_in")

var Lit_1133 *jrt.String = jrt.Intern("arbace.cpp.template$deducible_tparams")

var Lit_1134 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_call")

var Lit_1135 *jrt.String = jrt.Intern("arbace.cpp.template$fnaddr_specs")

var Lit_1136 *jrt.String = jrt.Intern("arbace.cpp.template$at_least_as_specialized_QMARK_")

var Lit_1137 *jrt.String = jrt.Intern("arbace.cpp.template$concept_ref")

var Lit_1138 *jrt.String = jrt.Intern("arbace.cpp.template$normal_form")

var Lit_1139 *jrt.String = jrt.Intern("arbace.cpp.template$associated_constraints")

var Lit_1140 *jrt.String = jrt.Intern("arbace.cpp.template$dnf")

var Lit_1141 *jrt.String = jrt.Intern("arbace.cpp.template$cnf")

var Lit_1142 *jrt.String = jrt.Intern("arbace.cpp.template$subsumes_QMARK_")

var Lit_1143 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_fn_QMARK_")

var Lit_1144 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_fn_QMARK_")

var Lit_1145 *jrt.String = jrt.Intern("arbace.cpp.template$tiebreak")

var Lit_1146 *jrt.String = jrt.Intern("arbace.cpp.template$declare_instance_BANG_")

var Lit_1147 *jrt.String = jrt.Intern("arbace.cpp.template$class_completed_BANG_")

var Lit_1148 *jrt.String = jrt.Intern("arbace.cpp.template$partial_args")

var Lit_1149 *jrt.String = jrt.Intern("arbace.cpp.template$partial_match")

var Lit_1150 *jrt.String = jrt.Intern("arbace.cpp.template$partial_constraints")

var Lit_1151 *jrt.String = jrt.Intern("arbace.cpp.template$more_constrained_partial_QMARK_")

var Lit_1152 *jrt.String = jrt.Intern("arbace.cpp.template$more_specialized_partial_QMARK_")

var Lit_1153 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_class")

var Lit_1154 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_class_STAR_")

var Lit_1155 *jrt.String = jrt.Intern("arbace.cpp.template$select_instance_BANG_")

var Lit_1156 *jrt.String = jrt.Intern("arbace.cpp.template$incomplete_instance_BANG_")

var Lit_1157 *jrt.String = jrt.Intern("arbace.cpp.template$drop_layouts_BANG_")

var Lit_1158 *jrt.String = jrt.Intern("arbace.cpp.template$complete_instance_BANG_")

var Lit_1159 *jrt.String = jrt.Intern("arbace.cpp.template$incomplete_waiting_QMARK_")

var Lit_1160 *jrt.String = jrt.Intern("arbace.cpp.template$template_defined_BANG_")

var Lit_1161 *jrt.String = jrt.Intern("arbace.cpp.template$tmpl_of_entity")

var Lit_1162 *jrt.String = jrt.Intern("arbace.cpp.template$type_pack_element")

var Lit_1163 *jrt.String = jrt.Intern("arbace.cpp.template$make_integer_seq")

var Lit_1164 *jrt.String = jrt.Intern("arbace.cpp.template$template_id")

var Lit_1165 *jrt.String = jrt.Intern("arbace.cpp.template$header_params")

var Lit_1166 *jrt.String = jrt.Intern("arbace.cpp.template$ool_class_name")

var Lit_1167 *jrt.String = jrt.Intern("arbace.cpp.template$ool_qualifier")

var Lit_1168 *jrt.String = jrt.Intern("arbace.cpp.template$class_key_scope")

var Lit_1169 *jrt.String = jrt.Intern("arbace.cpp.template$ool_class_template")

var Lit_1170 *jrt.String = jrt.Intern("arbace.cpp.template$attach_one_BANG_")

var Lit_1171 *jrt.String = jrt.Intern("arbace.cpp.template$attach_ool_BANG_")

var Lit_1172 *jrt.String = jrt.Intern("arbace.cpp.template$concept_of")

var Lit_1173 *jrt.String = jrt.Intern("arbace.cpp.template$tn_types")

var Lit_1174 *jrt.String = jrt.Intern("arbace.cpp.template$concept_satisfied_QMARK_")

var Lit_1175 *jrt.String = jrt.Intern("arbace.cpp.template$type_constraints_satisfied_QMARK_")

var Lit_1176 *jrt.String = jrt.Intern("arbace.cpp.template$name_pack_params_BANG_")

var Lit_1177 *jrt.String = jrt.Intern("arbace.cpp.template$template_depth")

var Lit_1178 *jrt.String = jrt.Intern("arbace.cpp.template$decltype_failed_QMARK_")

var Lit_1179 *jrt.String = jrt.Intern("arbace.cpp.template$instantiate_fn")

var Lit_1180 *jrt.String = jrt.Intern("arbace.cpp.template$adl_templates")

var Lit_1181 *jrt.String = jrt.Intern("arbace.cpp.template$too_few_args_QMARK_")

var Lit_1182 *jrt.String = jrt.Intern("arbace.cpp.template$call_candidates")

var Lit_1183 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_spec_BANG_")

var Lit_1184 *jrt.String = jrt.Intern("arbace.cpp.template$var_template")

var Lit_1185 *jrt.String = jrt.Intern("arbace.cpp.template$var_template_inst")

var Lit_1186 *jrt.String = jrt.Intern("arbace.cpp.template$template_text_args")

var Lit_1187 *jrt.String = jrt.Intern("arbace.cpp.template$var_text_args")

var Lit_1188 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn5,scopeyn2,nmyn2,tkkn4,linekn6,columnkn4,filekn8,declaredyn1,nkn3,docyn3,cidyn1,oyn12,outer-paramsyn2,cnyn2,qtyn6,paramsyn2,rcyn3,trcyn3,accyn1,xyn5,cnameyn2,gdkn7,dynamicyn6,parentyn4,argsyn3,gidyn7,patternyn1,tyn3,tidyn5,itemsyn1,cyn1,gyn2,ilyn5,dropsyn2,atyn1,eyn3,clsyn1,byn1,Ryn1,Xyn6,resultyn4,ctidyn2,gsyn3,ctxyn4,kindyn4,inityn2,A0yn1,Akn7,declarekn11,template-idkn11,const-boundkn15,call-candidateskn8,tiebreakkn4,ctadkn15,ctor-candidateskn11,pack-expandkn11,expand-packkn11,pack-scopeskn12,var-templatekn14,dependent-namekn10,trait-typekn10,trait-textkn15,type-constraintkn10,concept-idkn7,pendingkn9,glam-speckn12,fnaddr-specskn15,conv-candidateskn17,instantiate-classkn8,is-traitkn4,wrapkn15,class-completedv19,arbace.cpp.template13,find-templatem10,R0,TR1,L1,V3,R2,R3,R4,R5,i2550,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,declare-templatem8,R8,TR5,i2553,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,user-guide!m8,R8,TR5,i2553,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template7,friend!m12,R0,TR1,L1,V2,R2,R9,R10,s281,A friend declaration in a class: a function (or function template) defined there is a member of the innermost\n  enclosing namespace ([class.friend]/6-7), inline, its body's names those of the class; a declaration alone or a\n  friend class adds nothing here (access is not checked).R5,i2556,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template21,explicit-member-spec!m12,R0,TR1,L1,V2,R2,R9,R10,s204,An explicit specialization of a member of an implicitly instantiated class template specialization\n  ([temp.expl.spec]/14): the specialization's member given this definition, an ordinary (not inline) one.R5,i2611,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V3,R11,R12,R13,R10,s216,A member template defined outside its class (o: {:node FunctionTemplateDecl :pnames outer names}) given to the\n  class `cid`'s member template of its name: its pattern, parameters and a scope binding the outer names.R5,i2647,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,ool-member-template!m12,R0,TR1,L1,V3,R2,R9,V2,R14,R15,R10,s209,template <class T> template <class U> R A<T>::f(U) {...}: the member template's definition for each specialization\n  of the primary; template <> template <class U> R A<int>::f(U): for that specialization only.R5,i2676,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template26,explicit-fn-instantiation!m12,R0,TR1,L1,V2,R2,R9,R10,s578,CP305 (a), the checker: an explicit instantiation definition of a function template ([temp.explicit]/10: `template R\n  f<args>(params);` instantiates the definition there), its specialization found as an explicit specialization's is\n  ([temp.deduct.decl]: the written arguments, then deduction from its type) and its definition analyzed as a used one's\n  (made eager, entered in the order), so its errors are judged. A declaration whose template or arguments the slice\n  cannot resolve is left (the code generator's explicit instantiations stay as they were: emitted when used).R5,i2691,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template19,constraint-spellingm12,R0,TR1,L1,V3,R16,R17,R18,R10,s316,CP300 (a), [temp.over.link]/7: a function template's constraints as written (its type-constraints, its requires-clause,\n  its trailing requires-clause), the template parameters' names replaced by their positions: two declarations of the same\n  template spell them alike (equivalent), else they declare two templates.R5,i2731,R6,i1,R7,s22,arbace/cpp/template.aem10,R1,L1,V2,R2,R9,R10,s104,The :declare hook: a template's declaration node entered (nil when the node is not one of a template's).R5,i2744,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V2,R19,R20,R10,s166,Collects into `acc` (atom {:fns #{} :vars #{} :classes #{}}) the functions, variables and classes a typed body\n  references (not the native tree's nodes, not scopes).R5,i3040,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,class-closurem12,R0,TR1,L1,V1,R11,R10,s69,The class with its bases and the classes of its members, recursively.R5,i3054,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,extern-class?m12,R0,TR1,L1,V1,R11,R10,s94,Whether the class (or a class enclosing it) is named by an explicit instantiation declaration.R5,i3067,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template7,pendingm10,R1,L1,V0,R10,s109,The :pending hook: the lazy definitions the analyzed bodies reference, made eager ([[:fn id] [:var id] ...]).R5,i3076,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,guide-class-namem10,R0,TR1,L1,V1,R9,R5,i3136,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,explicit-guide?m12,R0,TR1,L1,V2,R9,R21,R10,s198,A deduction guide's or constructor's explicit-specifier, read from its text before the name's ( (`explicit(false)`\n  not explicit; another explicit(...) explicit, as sema's explicit-spec counts it).R5,i3138,R6,i1,R7,s22,arbace/cpp/template.aem12,R0,TR1,L1,V4,R2,R9,R16,R22,R10,s163,A deduction guide declared (a CXXDeductionGuideDecl, `n` its FunctionTemplateDecl or itself): recorded on its class\n  template, nil when none is found by its name.R5,i3148,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template13,*ctad-unsure*m8,R23,TR5,i3158,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,guide-scopem12,R0,TR1,L1,V5,R24,R16,R25,R26,R27,R10,s283,The scope of a guide's parameters over `parent`: symbolic (`gid`, no args) or bound to `args`; the pattern's member\n  typedefs and alias declarations entered, resolved in it (a member typedef in a constructor's parameter stands for its\n  type, TransformTypedefType of the transform).R5,i3160,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template10,ctor-nodesm12,R0,TR1,L1,V1,R27,R10,s75,The pattern's declared constructors: [node ctor-template-node-or-nil] each.R5,i3172,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,param-defaultsm10,R0,TR1,L1,V1,R9,R5,i3181,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,self-textm12,R0,TR1,L1,V1,R28,R10,s86,The class template's own template-id written with its parameters' names (C<T, Ts...>).R5,i3184,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template18,aggregate-pattern?m12,R0,TR1,L1,V1,R27,R10,s298,[dcl.init.aggr]/1 for the primary template's pattern ([over.match.class.deduct]/1.4, a dependent base assumed to have\n  no virtual functions or bases): no user-declared constructor, no private or protected direct non-static data member,\n  no virtual function, no virtual, private or protected base.R5,i3189,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,class-guidesm12,R0,TR1,L1,V1,R29,R10,s220,The class template `tid`'s guides: its constructors' implicit ones, C() when it declares none, the copy deduction\n  candidate, its user deduction guides (DeclareImplicitDeductionGuides), registered as templates and kept.R5,i3205,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,aggregate-guidem12,R0,TR1,L1,V2,R29,R30,R10,s508,C++20's aggregate deduction candidate for the braced or parenthesized initializer's `items` ([over.match.class.deduct]\n  /1.4-1.10; DeclareAggregateDeductionGuideFromInitList with the InitListChecker's element types): the parameters T_i of\n  the elements x_i initializes, bases first, an array's an rvalue reference to it for a braced item, a const lvalue one\n  for a string literal; nil when the list has more items than elements (no guide), :unsure when brace elision might\n  apply or an element is a pack.R5,i3255,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,class-and-basesm10,R0,TR1,L1,V1,R31,R5,i3297,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template14,guide-min-argsm10,R0,TR1,L1,V1,R32,R5,i3299,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,guide-candidate!m12,R0,TR1,L1,V4,R32,R25,R33,R34,R10,s238,The guide `g` deduced from the arguments `args` (`il`: its first parameter an initializer_list<E> deduced from the\n  list's elements, [temp.deduct.call]/1), its specialization registered as a function, or nil (a drop, counted in `drops`).R5,i3303,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template20,init-list-guide-elemm12,R0,TR1,L1,V1,R32,R10,s157,E when the guide's first parameter is std::initializer_list<E> or a reference to one and the rest have default\n  arguments (isInitListConstructor), else nil.R5,i3348,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template9,alias-rhsm12,R0,TR1,L1,V1,R35,R10,s196,The alias template `at`'s defining-type-id with the alias's own parameters (symbolic), aliases substituted:\n  [class-template-id type] when it names a specialization of a class template, else nil.R5,i3373,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template10,entity-argm12,R0,TR1,L1,V1,R36,R10,s89,The template argument a scope's entity for a parameter stands for (arg-entity's inverse).R5,i3384,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template17,guide-ret-patternm12,R0,TR1,L1,V1,R32,R10,s165,The template-id a class guide `g` returns, written with its own parameters (symbolic, its id): the user guide's\n  return type, else the class template's own C<T...>.R5,i3398,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,alias-deduciblem12,R0,TR1,L1,V3,R35,R20,R37,R10,s339,buildIsDeducibleConstraint's check (__is_deducible(A, R)) for the alias template `at` whose defining-type-id is `x`\n  (symbolic): the alias's arguments deduced from the class `cls` and the alias's own constraints (its parameters'\n  type-constraints, its requires-clause) satisfied by them: the arguments, false (a sure failure) or :unsure.R5,i3409,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,deduce-from-rhsm12,R0,TR1,L1,V4,R38,R26,R39,R40,R10,s445,[over.match.class.deduct]/3's deduction of the guide `gid`'s return type R's template arguments from the alias's\n  defining-type-id X ([temp.deduct.type], deduction not failing when some stay undeduced): the same class template,\n  argument by argument, an argument that does not deduce left (clang's DeduceTemplateArguments with\n  NumberOfArgumentsMustMatch false); a pack expansion among them matched as a list. False when the templates differ.R5,i3438,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,alias-resultm12,R0,TR1,L1,V2,R35,R20,R10,s111,The :result of the alias template `at`'s guides: the class itself when the alias's arguments deduce back to it.R5,i3455,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,alias-guidem12,R0,TR1,L1,V4,R35,R20,R32,R41,R10,s419,The guide f' of the alias template `at` (its defining-type-id `x`, symbolic) from its class template's guide `g`\n  (registered), registered as a template; nil when f's return type cannot be deduced from `x` (never a specialization of\n  the alias). `result` maps the class f' returns to the deduced class (the alias's specialization: that class itself;\n  CP323's inherited guides: the derived class) or false or :unsure.R5,i3460,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,alias-guidesm12,R0,TR1,L1,V3,R35,V2,R42,R20,R43,R10,s227,The alias template `at`'s guides from the class template's `gs` (DeclareImplicitDeductionGuidesForTypeAlias), with\n  [ctid x] its defining-type-id's (alias-rhs); kept on the alias while the class template's guides are the same.R5,i3518,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template16,inherited-guidesm12,R0,TR1,L1,V1,R42,R10,s636,CP323 (a), C++23's [over.match.class.deduct]/1.10 (P2582R1), from the standard's text (clang 23 builds none; the\n  standard is the reference where clang lags): for each direct base B of the class template `ctid`'s pattern whose\n  constructors it inherits (`using B::B;`), A the alias template with C's template parameters whose defining-type-id is\n  B: A's guides (alias-guide over B's class template's guides), each returning C with the arguments A's deduce from the\n  class the guide returns (the partial specialization CC<A<P...>> of the text: no such deduction, no guide), marked\n  :inherited for [over.match.best]/2.10's tie-break.R5,i3529,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template4,ctadm10,R1,L1,V4,R44,R29,R45,R46,R10,s338,The :ctad hook: the class a placeholder for the class template or alias template `tid` deduces from an initializer\n  of `kind` (:direct, :copy, :list-direct, :list-copy) with `init` (the arguments' vector, an expression, an\n  init-list), as DeduceTemplateSpecializationFromInitializer does; a refusal :ctad when the program is ill-formed.R5,i3570,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template12,*conv-specs*m8,R23,TR5,i3676,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template11,deduce-convm10,R1,L1,V2,R28,R47,R10,s784,[temp.deduct.conv]: the arguments of the conversion function template `t` deduced from the conversion's target type\n  `A0` (a reference when a reference binds to the result), or nil. P is the template's return type, the type referred to\n  when it is a reference (/2); when A0 is no reference, an array P decays to a pointer, a function P to a pointer to\n  function, else P's top-level cv-qualifiers are dropped (/3), and A's are (/4); when A0 is a reference, A is the type it\n  refers to, which may be more cv-qualified than the deduced A (/4, clang's TDF_ArgWithReferenceType), and a pointer\n  or pointer to member A may differ from the deduced one by a qualification conversion (/5, TDF_IgnoreQualifiers):\n  the specialization's own type is then checked by the conversion's ranking.R5,i3678,R6,i1,R7,s22,arbace/cpp/template.aev19,arbace.cpp.template15,conv-candidatesm10,R1,L1,V2,R11,R48,R10,s216,The specializations of the conversion function templates of class `cid` and its bases for the target type `A`\n  (deduce-conv, then instantiated: its constraints checked, a failure no candidate), memoized per program.R5,i3704,R6,i1,R7,s22,arbace/cpp/template.aev11,arbace.core6,reset!v15,arbace.cpp.sema5,hooksR49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,")

var Lit_1189 *jrt.String = jrt.Intern("arbace.cpp.template$find_template")

var Lit_1190 *jrt.String = jrt.Intern("arbace.cpp.template$friend_BANG_")

var Lit_1191 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_member_spec_BANG_")

var Lit_1192 *jrt.String = jrt.Intern("arbace.cpp.template$attach_member_template_BANG_")

var Lit_1193 *jrt.String = jrt.Intern("arbace.cpp.template$ool_member_template_BANG_")

var Lit_1194 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_fn_instantiation_BANG_")

var Lit_1195 *jrt.String = jrt.Intern("arbace.cpp.template$constraint_spelling")

var Lit_1196 *jrt.String = jrt.Intern("arbace.cpp.template$declare_template")

var Lit_1197 *jrt.String = jrt.Intern("arbace.cpp.template$walk_refs")

var Lit_1198 *jrt.String = jrt.Intern("arbace.cpp.template$class_closure")

var Lit_1199 *jrt.String = jrt.Intern("arbace.cpp.template$extern_class_QMARK_")

var Lit_1200 *jrt.String = jrt.Intern("arbace.cpp.template$pending")

var Lit_1201 *jrt.String = jrt.Intern("arbace.cpp.template$guide_class_name")

var Lit_1202 *jrt.String = jrt.Intern("arbace.cpp.template$explicit_guide_QMARK_")

var Lit_1203 *jrt.String = jrt.Intern("arbace.cpp.template$user_guide_BANG_")

var Lit_1204 *jrt.String = jrt.Intern("arbace.cpp.template$guide_scope")

var Lit_1205 *jrt.String = jrt.Intern("arbace.cpp.template$ctor_nodes")

var Lit_1206 *jrt.String = jrt.Intern("arbace.cpp.template$param_defaults")

var Lit_1207 *jrt.String = jrt.Intern("arbace.cpp.template$self_text")

var Lit_1208 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_pattern_QMARK_")

var Lit_1209 *jrt.String = jrt.Intern("arbace.cpp.template$class_guides")

var Lit_1210 *jrt.String = jrt.Intern("arbace.cpp.template$aggregate_guide")

var Lit_1211 *jrt.String = jrt.Intern("arbace.cpp.template$class_and_bases")

var Lit_1212 *jrt.String = jrt.Intern("arbace.cpp.template$guide_min_args")

var Lit_1213 *jrt.String = jrt.Intern("arbace.cpp.template$guide_candidate_BANG_")

var Lit_1214 *jrt.String = jrt.Intern("arbace.cpp.template$init_list_guide_elem")

var Lit_1215 *jrt.String = jrt.Intern("arbace.cpp.template$alias_rhs")

var Lit_1216 *jrt.String = jrt.Intern("arbace.cpp.template$entity_arg")

var Lit_1217 *jrt.String = jrt.Intern("arbace.cpp.template$guide_ret_pattern")

var Lit_1218 *jrt.String = jrt.Intern("arbace.cpp.template$alias_deducible")

var Lit_1219 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_from_rhs")

var Lit_1220 *jrt.String = jrt.Intern("arbace.cpp.template$alias_result")

var Lit_1221 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guide")

var Lit_1222 *jrt.String = jrt.Intern("arbace.cpp.template$alias_guides")

var Lit_1223 *jrt.String = jrt.Intern("arbace.cpp.template$inherited_guides")

var Lit_1224 *jrt.String = jrt.Intern("arbace.cpp.template$ctad")

var Lit_1225 *jrt.String = jrt.Intern("arbace.cpp.template$deduce_conv")

var Lit_1226 *jrt.String = jrt.Intern("arbace.cpp.template$conv_candidates")

var Lit_1227 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002932")

var Lit_1228 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002934")

var Lit_1229 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002936")

var Lit_1230 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002960")

var Lit_1231 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002962")

var Lit_1232 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002966")

var Lit_1233 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002968")

var Lit_1234 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002970")

var Lit_1235 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002979")

var Lit_1236 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002981")

var Lit_1237 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002985")

var Lit_1238 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002987")

var Lit_1239 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002989")

var Lit_1240 *jrt.String = jrt.Intern("arbace.cpp.template$eval960002931$fn__960002991")
